import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {INTENTS,frame,persona,pvpFromDual,toTensors} from './dialogue.js'
import {PerceptionTransformer} from './model.js'
import {examples} from './teacher.js'

const [workspace, checkpoint, destination] = process.argv.slice(2)
if (!workspace || !checkpoint || !destination)
  throw Error('usage: train-replays.js <workspace> <base checkpoint> <output directory>')

const actors = {
  punengbho: 'WaveDog', son: 'WaveDogSon', brother: 'WaveDogBrother',
  father: 'WaveDogFather', sister: 'WaveDogSister'
}

function recentMatches(component) {
  const directory = path.join(workspace, 'work', 'wavedog-' + component, 'runtime')
  const reports = fs.readdirSync(directory).filter(name => name.endsWith('-report.json'))
    .map(name => ({file: path.join(directory, name), name}))
  reports.sort((a, b) => fs.statSync(b.file).mtimeMs - fs.statSync(a.file).mtimeMs)
  const selected = []
  for (const {file, name} of reports) {
    const report = JSON.parse(fs.readFileSync(file, 'utf8'))
    const trace = path.join(directory, name.replace('-report.json', '-native-frames.jsonl'))
    if (report.backend !== 'server-native' || report.outcome?.reason !== 'death'
      || !report.outcome.winner || !fs.existsSync(trace)) continue
    selected.push({trace,winner:report.outcome.winner})
    if (selected.length === 4) break
  }
  return selected
}

function label(events) {
  if (events.boutEnd) return events.won ? 'gg_win' : 'gg_loss'
  if (events.boutStart) return 'opener'
  if (events.enemyCrystalHit) return 'nice_crystal'
  if (events.enemyMaceHit) return 'nice_mace'
  if (events.enemyBowHit) return 'nice_bow'
  if (events.enemyRetreat && events.ownLowHealth) return 'tilt'
  if (events.ownLowHealth) return 'clutch'
  if (events.ownCombo) return 'combo_hype'
  if (events.enemyShield) return 'shield_respect'
  if (events.enemyRetreat) return 'retreat_roast'
  return 'silence'
}

async function replay({trace, winner}, speaker) {
  const history = [], rows = [], lastLabelTick = new Map()
  let previous = null, last = null, hitTicks = [], lastSample = -Infinity
  const identity = persona(speaker)
  function append(row, events) {
    const sonVector = nativeObservation(row, {})
    if (sonVector.some(value => !Number.isFinite(value))) return
    const pvpVector = pvpFromDual(row.neuralFallback?.proposal ?? {})
    history.push(frame({sonVector,pvpVector,events}))
    if (history.length > 8) history.shift()
    const intent = label(events)
    if (row.tick - (lastLabelTick.get(intent) ?? -Infinity) < 35) return
    lastLabelTick.set(intent, row.tick)
    rows.push({history:history.slice(), persona:identity, label:INTENTS.indexOf(intent)})
  }
  const input = readline.createInterface({input: fs.createReadStream(trace, {encoding:'utf8'}), crlfDelay:Infinity})
  for await (const line of input) {
    const row = JSON.parse(line)
    row.tick = row.observation?.tick
    if (!row.self || !row.seen || !Number.isInteger(row.tick)) continue
    const events = row.nativeEvents ?? []
    const damage = events.filter(event => event.type === 'damage' && !event.cancelled && event.amount > 0)
    if (row.tick - lastSample < 20 && !events.some(event => event.type === 'damage')) continue
    if (damage.some(event => event.attacker === speaker && event.melee === true) && hitTicks.at(-1) !== row.tick)
      hitTicks.push(row.tick)
    hitTicks = hitTicks.filter(tick => row.tick - tick <= 30)
    const enemyHit = damage.find(event => event.victim === speaker && event.weapon !== 'end_crystal')
    const retreat = previous?.seen.visible && row.seen.visible && row.tick - previous.tick >= 2
      && row.tick - previous.tick <= 20 && !damage.length
      && Math.hypot(row.seen.x - previous.seen.x,row.seen.z - previous.seen.z) > .75
      && row.observation.distance - previous.observation.distance > .7
    append(row, {
      boutStart: !last, enemyRetreat: Boolean(retreat), ownLowHealth: row.self.health <= 6,
      enemyBowHit: Boolean(enemyHit && !enemyHit.melee && ['bow','crossbow'].includes(row.observation.targetShotWeapon)),
      enemyMaceHit: Boolean(enemyHit?.melee && row.seen.held === 'MACE'),
      enemyCrystalHit: damage.some(event => event.weapon === 'end_crystal' && event.victim === speaker),
      ownCrystalHit: damage.some(event => event.weapon === 'end_crystal' && event.attacker === speaker),
      ownCombo: hitTicks.length >= 2,
      enemyShield: Boolean(row.observation.targetShieldRaised) || events.some(event => event.type === 'damage'
        && !event.cancelled && event.attacker === speaker && event.melee && event.amount === 0 && event.shieldModifier < 0)
    })
    if (!previous || row.tick - previous.tick >= 8) previous = row
    lastSample = row.tick
    last = row
  }
  if (last) append(last, {boutEnd:true,won:winner === speaker,lost:winner !== speaker})
  return rows
}

function groupByIntent(rows) {
  const groups = INTENTS.map(() => [])
  for (const row of rows) groups[row.label].push(row)
  return groups
}

function score(model, rows) {
  let correct = 0, loss = 0
  for (let i = 0; i < rows.length; i += 12) {
    const batch = rows.slice(i,i + 12)
    const input = toTensors(batch)
    try {
      const result = tf.tidy(() => {
        const logits = model.logits(input)
        const prediction = [...logits.argMax(1).dataSync()]
        const labels = tf.oneHot(tf.tensor1d(batch.map(row => row.label),'int32'),INTENTS.length)
        return {correct:prediction.filter((value,j) => value === batch[j].label).length,
          loss:tf.losses.softmaxCrossEntropy(labels,logits).dataSync()[0]}
      })
      correct += result.correct
      loss += result.loss * batch.length
    } finally {
      Object.values(input).forEach(tensor => tensor.dispose())
    }
  }
  return {samples:rows.length,accuracy:correct / rows.length,loss:loss / rows.length}
}

const train = [], heldOut = []
let trainMatches = 0, heldOutMatches = 0
for (const [component,speaker] of Object.entries(actors)) {
  const matches = recentMatches(component)
  for (const [index,match] of matches.entries()) {
    const rows = await replay(match,speaker)
    if (!rows.length) continue
    if (index === 0) { heldOut.push(...rows); heldOutMatches++ }
    else { train.push(...rows); trainMatches++ }
  }
  console.log(JSON.stringify({speaker,completeMatches:matches.length}))
}
if (!train.length || !heldOut.length) throw Error('complete matches are needed in both splits')

await tf.setBackend('cpu')
await tf.ready()
const saved = JSON.parse(fs.readFileSync(checkpoint,'utf8'))
const model = new PerceptionTransformer(saved.classes,saved.config)
model.restore(saved)
const balanced = groupByIntent(train).filter(group => group.length > 0)
const validation = groupByIntent(heldOut).flatMap(group => {
  const stride = Math.max(1,Math.ceil(group.length / 7))
  return group.filter((_,i) => i % stride === 0)
})
const originalTeacher = examples(48,9172001)
const baseline = {replay:score(model,validation),teacher:score(model,originalTeacher)}
const optimizer = tf.train.adam(.0002)
const steps = 20
for (let step = 0; step < steps; step++) {
  const batch = balanced.map((group,i) => group[(step * 19 + i * 7) % group.length])
    .concat(examples(6,20261126 + step * 37))
  tf.tidy(() => {
    const labels = tf.oneHot(tf.tensor1d(batch.map(row => row.label),'int32'),INTENTS.length)
    const input = toTensors(batch)
    optimizer.minimize(() => tf.losses.softmaxCrossEntropy(labels,model.logits(input)),
      false,[...model.head.params,...model.eventHead.params])
  })
  if ((step + 1) % 5 === 0) console.log(JSON.stringify({step:step + 1,steps}))
}
const evaluation = {replay:score(model,validation),teacher:score(model,originalTeacher)}
if (!Number.isFinite(evaluation.replay.loss + evaluation.teacher.loss)) throw Error('nonfinite evaluation')
fs.mkdirSync(destination,{recursive:true})
fs.writeFileSync(path.join(destination,'checkpoint.json'),JSON.stringify(model.snapshot()))
fs.writeFileSync(path.join(destination,'speech-profile.json'),'{"mode":"intent-v1"}\n')
const report = {profile:'intent-v1',steps,parameters:model.parameterCount(),trainMatches,heldOutMatches,
  labeledReplayFrames:train.length,heldOutReplayFrames:heldOut.length,
  trainable:'intent and event heads',labelSource:'rule labels from native match events and synthetic teacher rehearsal',
  baseline,evaluation}
fs.writeFileSync(path.join(destination,'training-report.json'),JSON.stringify(report,null,2)+'\n')
console.log(JSON.stringify(report))
optimizer.dispose()
model.dispose()
