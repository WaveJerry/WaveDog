"""Package the shared WaveDog speech worker without combat data or player logs."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--v1', action='store_true', help='export the original intent-based model')
parser.add_argument('--trained', type=Path, help='export an offline-trained intent-v1 checkpoint')
parser.add_argument('--plugins', type=Path, help='directory containing the current Paper integration JARs')
options = parser.parse_args()
if options.trained and not options.plugins:
    parser.error('--trained requires --plugins')
if options.trained:
    options.v1 = True
root = Path(__file__).resolve().parent
workspace = root.parents[2]
output = workspace / 'outputs/pvp-perception-language'
sources = [file for file in root.iterdir()
    if file.suffix in ('.js', '.mjs', '.md', '.py')]
dependencies = [root.parent / name for name in ('package.json', 'package-lock.json',
    'native-observation.js', 'technique-conditioning.js', 'combat-observation.js')]
artifact_names = ['checkpoint.json', 'training-report.json']
if not options.v1:
    artifact_names += ['reply.int8.bin', 'reply-context.int8.bin', 'reply-combat.int8.bin',
        'contextual/report.json', 'contextual/sample-input.jsonl', 'contextual/tokenized-supervision.jsonl']
artifacts = [output / name for name in artifact_names if not options.trained]
files = {file.relative_to(workspace).as_posix(): file.read_bytes()
    for file in sources + dependencies + artifacts}
if options.trained:
    for name in artifact_names:
        files[f'outputs/pvp-perception-language/{name}'] = (options.trained / name).read_bytes()
release = workspace / 'outputs/wavedog-brother-release'
files['integration/PerceptionDialogueBridge.java'] = (release /
    'work/wavedog-native/src/local/wavedog/nativecontrol/PerceptionDialogueBridge.java').read_bytes()
files['integration/ChatSense.java'] = (workspace /
    'work/wavedog-chat-sense/src/local/wavedog/chatsense/ChatSense.java').read_bytes()
files['outputs/pvp-perception-language/speech-profile.json'] = json.dumps(
    {'mode': 'intent-v1' if options.v1 else 'token'}).encode()
if options.v1:
    project = root.relative_to(workspace).as_posix()
    files['integration/WaveDogNativeControl.jar'] = (
        options.plugins / 'WaveDogNativeControl.jar' if options.trained else
        release / 'native-online-training/WaveDogNativeControl.jar').read_bytes()
    files['integration/WaveDogChatSense.jar'] = (
        options.plugins / 'WaveDogChatSense.jar' if options.trained else
        release / 'chat-sense-build/WaveDogChatSense.jar').read_bytes()
    readme = (root / 'README.zh-CN.md').read_text(encoding='utf-8')
    if options.trained:
        readme = '''# Tiny Language Transformer WaveDog

这是主服当前 `intent-v1` 的离线微调版。沿用当前词库、Transformer 结构和 Paper 接入方式，从原有权重继续训练意图与事件输出层。训练使用近期完成对局的结构化事件。训练和验证按整局划分，报告在 [training-report.json](outputs/pvp-perception-language/training-report.json)。

已有 WaveDog 服务端接入时，把 `checkpoint.json` 和 `speech-profile.json` 放到服务器工作区的 `outputs/pvp-perception-language`。替换检查点前移开旧版意图适配器（如果有），适配器与基础权重的 SHA-256 绑定。插件会在下次启动时加载权重。首次接入与离线测试见下文。

下文默认模型的历史指标对应原始权重，本次微调指标以训练报告为准。大厅通用聊天及语音由单独的 Troalin 提供。

''' + readme.split('\n', 1)[1]
    files['README.zh-CN.md'] = readme.replace('](./', f']({project}/').encode()
else:
    files['integration/WaveDogChatSense.jar'] = (output / 'chat-sense-techniques/WaveDogChatSense.jar').read_bytes()
    files['README.zh-CN.md'] = (root / 'CONTEXTUAL.zh-CN.md').read_bytes()
manifest = {'ideaBy': 'WaveJ', 'scope': 'PvP perception and teaching' if options.v1 else 'PvP and lobby dialogue for WaveDog',
    'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
archive_dir = options.trained if options.trained else output
archive = archive_dir / ('WaveDog-Perception-Transformer-v1.zip' if options.v1 and not options.trained
    else 'Tiny Language Transformer WaveDog.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipfile_out:
    for name, data in sorted(files.items()):
        zipfile_out.writestr(name, data)
    zipfile_out.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
assert archive.stat().st_size < 25_000_000, archive.stat().st_size
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
    'checkpointBytes': len(files['outputs/pvp-perception-language/checkpoint.json']),
    'files': len(files)}, ensure_ascii=False))
