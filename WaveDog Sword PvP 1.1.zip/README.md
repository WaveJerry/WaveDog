# WaveDog Sword PvP

WaveDogBrother 是 Minecraft Java 版的服务端剑斗机器人，运行于 Paper 1.21.11。对局双方使用钻石剑和钻石护甲。对局结束后恢复真人原背包。

Brother 在远距离用 Son 的路线和控距逻辑持剑逼近，在服务端判定的 2.95～3.00 格窗口尝试地面击退刀。进入 2.50 格后调用 WaveDog 的冻结 GRU＋GTrXL 剑斗控制。同一 checkpoint 用独立的对局状态做推理，分开后回到 Son 控距。两段共用一个服务端动作执行器。

## 接敌控距

第一次有效命中前，持续走位接敌，入距出刀，遇有效盾执行原有眩晕破盾。普通控距瞄准 2.95～3.00 格，已经越过区间时可在合法范围内直接截击。双方近战按服务端当时的位置判定，从眼睛到对方碰撞箱最近点最多 3.00 格。

## 安装

1. 准备 Windows x64、Paper 1.21.11、Java 21 和 Node.js。在本项目的 `work/pvp-dual-brain` 运行 `npm ci --omit=dev`。
2. 关闭目标服，合并 `plugins` 下的 JAR 和配置。已有服务器可保留现有 WaveDog 和 WaveDogSon 的身份 JSON，并新增 `WaveDogBrother-identity.json`。把示例身份的位置调到目标世界的安全大厅坐标。
3. 启动参数在 `-jar` 前加 `"-Dwavedog.workspace=本项目绝对路径"` 和 `"-Dwavedog.node=node.exe绝对路径"`。升级旧版时，如果 `WaveDogNativeControl/config.yml` 配了 `policy-directory`，清空该项即可使用随包的剑斗策略。
4. 在兼容的主竞技场地图上，运行 `/wdarena install-brother` 安装西墙按钮和提示。默认按钮位于 `992 227 1028`。所有玩家都可右键按钮报名，开局前有 10 秒玻璃罩倒计时。
5. 控制台可用 `wavedogbrother status` 查看状态、`wavedogbrother duel 玩家名` 发起对战、`wavedogbrother stop` 停止。`wdnative status` 显示三个服务端机器人，`wdneural` 显示冻结模型状态。

## 源码与构建

`work` 包含服务端控制、裁判、竞技场入口、Son 策略和冻结模型。`python build-sword.py --server-root "Paper 1.21.11 服务端目录" --java-bin "Java 21 bin 目录"` 可重编译本项目改动的插件。构建用随包 Native JAR 的 Javet 依赖，需要目标 Paper 的启动产物和库。

需要另备兼容竞技场地图。发布包包含编译后的插件和模型权重。Paper 服务端、世界存档、玩家数据、登录凭据、对局日志和 `node_modules` 需要由各部署环境自行管理。
