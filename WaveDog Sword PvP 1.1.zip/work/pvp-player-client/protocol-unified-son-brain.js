'use strict'
// Exactly one combat phase chooses a complete command. Shared helpers only
// propose geometry, trajectories or model actions; none owns an executor.
const {eyeBoxReach,route}=require('./protocol-legacy86-threat')
const {syncRanged,rangedApplied}=require('./protocol-legacy86-ranged')
const {criticalReply}=require('../wavedog-protocol/ground-son-critical.cjs')
const {planBShieldAttack}=require('./protocol-son-shield-script')
const {planArrowDodge}=require('./wavedog-arrow-predictor')
const PHASES=Object.freeze({A:'A',B:'B',SWORD:'SWORD'})
const PUNISHMENT_ENTRY=2.90
const ESCAPE_MARGIN=.04
const SPACING_MIN=2.95, MELEE_MAX=3
const WALK_ACCEL=.098

// Compare the defender's route to the first reachable falling hit. A moment
// inside 2.90 during ascent can still be safe if the route clears in time.
function retreatCriticalWindow(frame,probe,movement){
 const own=frame.self,enemy=frame.seen,o=frame.observation,v=frame.targetVelocity
 const reach=frame.combatGeometry?.opponentBaseRange??3
 const latency=frame.latency?.opponentRttMs??0
 const visibleDelay=Math.min(4,Math.max(1,Math.ceil(latency/100)+1))
 const horizon=12, floor=frame.targetFloorY??enemy.y
 const displacement=movement?.sprint?route(own,movement.heading,horizon,probe):null
 const points=displacement?.points
 let x=enemy.x,y=enemy.y,z=enemy.z,vx=v.x,vz=v.z
 const airborne=o.targetAirborne&&enemy.y>floor+.015
 const dx=own.x-x,dz=own.z-z,length=Math.max(.001,Math.hypot(dx,dz))
 const toward=(vx*dx+vz*dz)/length
 let vy=airborne?v.y:.42
 if(!airborne&&toward>.08){vx+=.2*dx/length;vz+=.2*dz/length}
 let firstCriticalTick=null,minimumReach=Infinity
 for(let tick=0;tick<=horizon;tick++){
  if(tick>0&&y<=floor+.015&&vy<=0)break
  if(vy<-.015){
   const attacker={...enemy,x,y,z}
   const oldest=Math.max(0,tick-visibleDelay)
   let distance=Infinity
   for(let i=oldest;i<=tick;i++)distance=Math.min(distance,eyeBoxReach(attacker,points?.[i]??own))
   for(const past of frame.combatGeometry?.defenseCandidates??[]){
    if(past.ticksRemaining>=tick)distance=Math.min(distance,eyeBoxReach(attacker,{...own,...past}))
   }
   minimumReach=Math.min(minimumReach,distance)
   if(distance<=reach+ESCAPE_MARGIN&&firstCriticalTick===null)firstCriticalTick=tick
  }
  x+=vx;y+=vy;z+=vz
  vx*=.91;vz*=.91;vy=(vy-.08)*.98
 }
 return {firstCriticalTick,minimumReach:Number.isFinite(minimumReach)?minimumReach:null,visibleDelay,
  routeClear:Boolean(points),safe:Boolean(points&&firstCriticalTick===null)}
}

function createUnifiedSonBrain({profile,helpers:h}){
 let current=null
 function createState(opponent,fighter='Punengbho'){
  return {opponent,fighter,mode:PHASES.A,decisionVersion:0,nextId:1,pending:new Map(),
   lastAttempt:-1000,lastGroundAttempt:-1000,lastAxeStrikeTick:-1000,lastEnemyAttack:-1000,lastMeleeImpact:-1000,
   lastBlock:-1000,spentBlock:-1000,lastFullBlock:-1000,blockRiposteTick:-1000,lastStunAt:-1000,lastHit:-1000,lastDamage:-1000,
   closeFight:null,punishmentShield:null,engagementAxeDone:false,separatedSince:null,retreating:false,exitRun:null,
   rangedSync:null,previousShield:false,shieldSeenAt:-1000,runJumpRecovery:null}
 }
 function transition(s,mode,tick,reason){
  if(s.mode===mode)return
  s.mode=mode;s.phaseEnteredAt=tick;s.phaseReason=reason
  s.retreating=false
  s.closeFight=mode===PHASES.SWORD?{enteredAt:tick,firstHitDone:false,afterStunAt:null,unified:true,
   axeOpenerDone:Boolean(s.engagementAxeDone),reason}:null
  s.punishmentShield=mode===PHASES.B?{enteredAt:tick,reason:'uncovered-critical-window-after-retreat-entry'}:null
  s.swordExitArmed=null
 }
 function neutral(tick){return {kind:'legacy86-ground',phase:'GROUND_CONTROL',combatMode:'A',slot:7,
  offhand:'shield',shield:false,attack:false,doubleAttack:false,critical:false,jump:false,sneak:false,
  ranged:null,forward:0,side:0,sprint:false,worldHeading:null,keepLook:false,keepTargetLook:true,
  decidedTick:tick,ppoEligible:false,spacingProfile:'axe',rangedShieldOnly:true}}
 function moveCommand(c,move){return {...c,worldHeading:move?.heading||null,sprint:Boolean(move?.sprint),motionRetreat:Boolean(move?.retreat),
  keepTargetLook:!move?.retreat&&move?.reason!=='brake-before-first-contact',forward:0,side:0}}
 function fineGroundContact(frame,probe){
  const a=frame.self,t=frame.seen,v=frame.targetVelocity
  const drift={...a,x:a.x+a.vx,z:a.z+a.vz}
  const enemy={...t,x:t.x+v.x,z:t.z+v.z}
  const dx=enemy.x-drift.x,dz=enemy.z-drift.z,half=t.half??.3
  const x=Math.sign(dx)*Math.max(0,Math.abs(dx)-half),z=Math.sign(dz)*Math.max(0,Math.abs(dz)-half)
  const distance=Math.hypot(x,z),mid=(SPACING_MIN+MELEE_MAX)/2
  if(distance<.01)return null
  // Walk input is continuous on the native player. Account for the existing
  // drift first so one full reverse sprint cannot skip the whole hit band.
  const input=(eyeBoxReach(drift,enemy)-mid)/WALK_ACCEL
  if(Math.abs(input)>1)return null
  const heading={x:x/distance*input,z:z/distance*input}
  const next={...drift,x:drift.x+heading.x*WALK_ACCEL,z:drift.z+heading.z*WALK_ACCEL}
  if((next.x-a.x)*(t.x-a.x)+(next.z-a.z)*(t.z-a.z)<0)return null
  const ground=probe(next,a)
  if(!ground?.clear||!ground.supported)return null
  return {heading,sprint:false,retreat:false,reason:'fine-ground-contact',predictedNextReach:eyeBoxReach(next,enemy)}
 }
 function rangedDefense(frame,probe,base){
  const a=frame.self,o=frame.observation,arrow=o.arrowThreat
  if(arrow){
   const delay=a.shielding?0:Math.max(0,5-(frame.usingKind==='shield'?a.useTicks||0:0))+(o.offhandShieldReady?0:1)
   if(a.shieldAvailable&&(a.shielding||arrow.time>=delay))return {...neutral(o.tick),slot:a.held,
    kind:'legacy86-guard',shield:true,arrowYaw:arrow.yaw,keepTargetLook:true,intent:'arrow-shield'}
   const dodge=planArrowDodge(frame,probe,base)
   if(dodge)return {...neutral(o.tick),slot:a.held,worldHeading:dodge.heading,sprint:dodge.sprint,
    jump:Boolean(dodge.jump&&a.ground&&a.vy<=.001),keepLook:true,keepTargetLook:false,intent:'arrow-dodge'}
  }
  if(o.visible&&o.targetBow&&a.shieldAvailable)return {...neutral(o.tick),slot:a.held,
   kind:'legacy86-guard',shield:true,intent:'ranged-shield'}
  return null
 }
 function commitDecision(s,p){
  if(p.baseStateVersion!==s.decisionVersion)return false
  Object.assign(s,p.statePatch);s.decisionVersion++
  if(p.command.attack)p.command.attackId=s.nextId++
  p.committedStateVersion=s.decisionVersion;return true
 }
 function decide(live,frame,probe,tick,{preview=false,isCurrent=null,transactional=false}={}){
  if(current!==live)throw Error('Unified Son bout was not reset')
  if(!preview)for(const [id,p] of live.pending)if(tick-p.tick>=3)live.pending.delete(id)
  const version=live.decisionVersion,s={...live,closeFight:live.closeFight?{...live.closeFight}:null,
   punishmentShield:live.punishmentShield?{...live.punishmentShield}:null,
   rangedSync:live.rangedSync?structuredClone(live.rangedSync):undefined}
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  const charge=a.attackChargeAtHit??a.charge,damageReady=!Number.isFinite(t.noDamageTicks)||t.noDamageTicks<=(t.maxNoDamageTicks??20)/2
  const raised=Boolean(o.targetShieldRaised&&o.targetFacingDot>0),effective=raised&&Boolean(o.targetShieldFacing)
  const enemyReach=Number.isFinite(o.otherReach)?o.otherReach:eyeBoxReach(t,a)
  const entryRisk={threat:false,entered:enemyReach<=PUNISHMENT_ENTRY,current:enemyReach,threshold:PUNISHMENT_ENTRY,
   source:'current-server-opponent-eye-to-self-box'}
  if(o.reach>3.4&&enemyReach>3.4){s.separatedSince??=tick;if(tick-s.separatedSince>=2)s.engagementAxeDone=false}
  else s.separatedSince=null
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz)),closing=((a.vx-v.x)*dx+(a.vz-v.z)*dz)/n
  const nextReach=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},{...t,x:t.x+v.x,z:t.z+v.z})
  const response=criticalReply({enabled:true,self:a,target:{...t,airborne:o.targetAirborne,floorY:frame.targetFloorY??a.y},
   velocity:v,reach:o.reach,charge,shieldReady:a.shieldAvailable,ageMs:frame.latency?.observationAgeMs??0,
   pingMs:frame.latency?.opponentRttMs??0,defenseCandidates:frame.combatGeometry?.defenseCandidates??[],
   incomingRange:frame.combatGeometry?.opponentBaseRange??3})
  const swordOnly=s.fighter==='WaveDogBrother'
  const recovering=charge<=.9&&tick-s.lastMeleeImpact<=20
  let movement=!recovering?h.originalSonMotion(frame,probe,{approachOnly:true})
   :swordOnly?h.originalSonMotion(frame,probe)
    :a.held===7?h.axeChargeMotion(frame,probe):h.originalSonMotion({...frame,self:{...a,charge:0}},probe)
  const recovery=h.sonRecoveryPlan(frame,probe)
  const readyAxe=a.ground&&a.held===7&&charge>.9&&damageReady&&!raised&&o.visible&&o.reach<=3
  const finishingExit=s.exitRun&&tick-s.exitRun.tick<=2
   &&Math.hypot(a.x-s.exitRun.origin.x,a.z-s.exitRun.origin.z)<1e-6
  if(!finishingExit)s.exitRun=null
  else movement={heading:s.exitRun.heading,retreat:true,sprint:true,reason:'finish-exit-step'}
  let canControl=Boolean(readyAxe||recovery)
  if(s.mode===PHASES.A&&s.retreating&&entryRisk.entered&&o.visible&&!finishingExit){
   const retreat=movement?.retreat?movement:recovery
   const window=retreatCriticalWindow(frame,probe,retreat)
   const interrupt=readyAxe&&!live.pending.size&&(window.firstCriticalTick??Infinity)>1
   const alternate=!window.safe&&recovery&&recovery!==retreat?retreatCriticalWindow(frame,probe,recovery):null
   const canRetreat=window.safe||alternate?.safe
   if(!interrupt&&canRetreat)movement=window.safe?retreat:recovery
   entryRisk.threat=!interrupt&&!canRetreat
   entryRisk.criticalWindow=alternate?.safe?alternate:window
   entryRisk.canInterrupt=interrupt
   canControl=Boolean(interrupt||canRetreat)
  }
  // Fixture injection uses this public state too; in real play it is created
  // only by the one transition below.
  if(s.punishmentShield&&s.mode!==PHASES.B)transition(s,PHASES.B,tick,'retained-B')
  let brokenB=false
  if(s.mode===PHASES.B){
   if(!a.shieldAvailable){transition(s,PHASES.A,tick,'shield-broken');brokenB=true}
  }
  if(s.mode===PHASES.SWORD&&o.reach>3&&enemyReach>3&&nextReach>3)
   transition(s,PHASES.A,tick,'actual-sword-separation')
  if(swordOnly){
   if(s.mode===PHASES.A&&o.visible&&o.reach<=2.5)transition(s,PHASES.SWORD,tick,'sword-kit-close-range')
  }else if(s.mode===PHASES.A&&!brokenB){
   if(entryRisk.threat&&a.shieldAvailable)transition(s,PHASES.B,tick,'retreat-punishment-window')
   else if(o.visible&&o.reach<=2.5&&!canControl&&(entryRisk.threat||o.reach<=2.3||closing>.03&&nextReach<=2.5))
    transition(s,PHASES.SWORD,tick,'actual-lost-spacing')
  }
  if(s.mode!==PHASES.SWORD)s.closeFight=null
  if(s.mode!==PHASES.B)s.punishmentShield=null
  const groundContactReady=s.mode===PHASES.A&&!finishingExit&&a.ground&&o.targetGrounded
   &&a.held===(swordOnly?0:7)&&charge>.9&&damageReady&&!raised&&o.visible&&!live.pending.size
  let c=neutral(tick),skill='ground-spacing'
  if(swordOnly)Object.assign(c,{slot:0,offhand:'air',spacingProfile:'sword',rangedShieldOnly:false})
  const freshBlock=s.lastFullBlock>s.spentBlock&&tick-s.lastFullBlock<=1
  const riposte=!swordOnly&&freshBlock&&charge>=1&&!live.pending.size&&planBShieldAttack(frame,null,null)
  if(riposte){
   c={...c,...riposte,intent:'full-axe-shield-riposte',combatMode:s.mode,consumesBlock:s.lastFullBlock}
   s.spentBlock=s.lastFullBlock;s.blockRiposteTick=tick;skill=c.intent
  }else if(s.blockRiposteTick===tick&&a.shieldAvailable){
   c={...c,kind:'legacy86-guard',combatMode:s.mode,shield:true,intent:'hold-shield-after-riposte'};skill=c.intent
  }else if(s.mode===PHASES.B){
   c={...c,kind:'legacy86-guard',combatMode:'B',shield:true,intent:'B-hold',forward:o.visible&&o.distance>.9?1:0};skill='B-punishment-shield'
   if(profile().bGuardActions&&!live.pending.size){
    const poke=planBShieldAttack(frame,response,recovery)
    if(poke){c={...c,...poke};skill=poke.intent}
   }
  }else if(s.mode===PHASES.SWORD){
   if(!swordOnly&&effective&&o.visible&&o.reach<=3&&tick-s.lastStunAt>=10&&!live.pending.size){
    c={...c,kind:'legacy86-stun',attack:true,doubleAttack:true,stunReturnSlot:7}
    skill='stun'
   }else if(!swordOnly&&!s.closeFight.axeOpenerDone){
    c={...c,kind:'legacy86-close-axe-opener',intent:'axe-before-transformer-sword',
     attack:Boolean(a.held===7&&o.visible&&o.reach<=3&&!live.pending.size)};skill=c.intent
   }else{
    const model=h.legacySwordCommand(s,frame)
    c=model?{...c,...model}:{...moveCommand(c,recovery),kind:'legacy86-close',slot:0,intent:'frozen-model-pending-sword'}
    skill=c.intent
    const exit=h.swordExitCommand(s,frame,probe)
    if(exit&&!live.pending.size){c={...c,...exit};skill=exit.intent}
    if(swordOnly)c.offhand='air'
   }
  }else{
   const fine=groundContactReady&&o.reach>MELEE_MAX&&o.reach<=3.22?fineGroundContact(frame,probe):null
   if(fine)movement=fine
   c=moveCommand(c,movement);skill=movement?.retreat?'short-recovery-run':'ground-spacing'
   if(swordOnly){
    const spacing=o.reach>=SPACING_MIN
    if(!finishingExit&&a.ground&&a.held===0&&charge>.9&&damageReady&&o.visible&&o.reach<=MELEE_MAX&&!live.pending.size){
     c={...c,attack:true,sprint:true,attackRole:spacing?'spacing':'ground-catch',impactDirection:{x:dx/n,z:dz/n}}
     if(spacing)c.requestedReachBand=[SPACING_MIN,MELEE_MAX]
     skill='ground-hit'
    }
   }else if(brokenB){
    const counter=o.visible&&o.reach<=3&&!o.targetShieldFacing&&a.held===7&&charge>=.7&&!live.pending.size
    if(counter)c={...c,kind:'legacy86-counter',attack:true,consumesBlock:s.lastBlock}
    skill=counter?'B-shield-break-counter-to-A':'B-shield-break-to-A'
   }else if(!finishingExit&&effective&&o.visible&&o.reach<=3&&tick-s.lastStunAt>=10&&!live.pending.size){
    c={...c,kind:'legacy86-stun',slot:7,attack:true,doubleAttack:true,stunReturnSlot:7};skill='stun'
   }else if(!finishingExit&&readyAxe&&!live.pending.size){
    c={...c,attack:true,sprint:true,attackRole:o.reach>=2.95?'spacing':'ground-catch',
     impactDirection:{x:dx/n,z:dz/n}};skill='ground-hit'
    if(o.reach>=2.95)c.requestedReachBand=[2.95,3]
   }
  }
  // Ranged defense chooses a complete command and does not mutate the combat
  // mode. Crossbow synchronization can only use an unoccupied A decision.
  const defense=swordOnly?null:rangedDefense(frame,probe,movement)
  if(defense&&!c.attack){syncRanged(s,frame,c,{emergency:true,allowBow:false,crossbowShotsOnly:true});c=defense;skill=defense.intent}
  else if(!swordOnly&&s.mode===PHASES.A&&!c.attack&&!movement?.retreat){
   const ranged=syncRanged(s,frame,c,{emergency:o.reach<=3,allowBow:false,crossbowShotsOnly:true})
   if(ranged){c={...c,...ranged,doubleAttack:false};skill='sync-'+ranged.ranged}
  }
  if(!o.visible||o.reach>3||live.pending.size)c.attack=c.doubleAttack=false
  h.applyJumpOwnership(c,frame,skill,profile())
  if(!o.targetAirborne)s.bowJumpMirrored=false
  const bowReleasedInAir=o.targetShotWeapon==='bow'&&tick-o.targetShotTick>=0&&tick-o.targetShotTick<=1
  if(c.shield&&(skill==='ranged-shield'||skill==='arrow-shield')&&o.visible&&o.targetAirborne
      &&(o.targetBow&&v.y>0||bowReleasedInAir)&&!s.bowJumpMirrored
      &&a.ground&&a.vy<=.001&&a.jumpAvailable!==false&&a.ceilingClear!==false){
   c.jump=true;c.jumpOwner='bow-defense'
  }
  const original={axeSpacing:!swordOnly,shieldScript:false,phase:c.phase,counterHopActive:false,
   hasPendingAttack:live.pending.size>0,sprintKnockback:s.mode!==PHASES.SWORD}
  const patch={...s};delete patch.pending;delete patch.decisionVersion;delete patch.nextId
  const p={mode:'GROUND_SON',phase:s.mode,owners:Object.fromEntries(['movement','sprint','jump','look','sneak','mainhand','attack','shield','offhand'].map(k=>[k,'ground-son'])),
   command:c,original,originalCommand:{...c},commandChanges:{},selectedBranch:'son:'+skill,
   sonArbitration:{skill,decisionOwner:'ground-son',retreatEntryRisk:entryRisk,combatPhase:s.mode},
   airPlan:{...response,valid:response.threat},closeFight:s.closeFight,groundContact:{controller:'unified-son',axeSpacing:!swordOnly,
    movement,recovery:null,shortRecovery:recovery,canControl,response,closing,nextReach,
    strictGround:true,requestedReachBand:[2.95,3],phase:s.mode,retreatEntryRisk:entryRisk,
    runJumpRecovery:null,blockReply:s.lastBlock>s.spentBlock&&tick-s.lastBlock<=6},
   statePatch:patch,runtimeMs:0,baseStateVersion:version}
  if(isCurrent&&!isCurrent()||version!==live.decisionVersion)return null
  if(!transactional&&!commitDecision(live,p))return null
  return p
 }
 function applied(s,c,actual,tick){
  if(c.jumpOwner==='bow-defense'&&actual.jump)s.bowJumpMirrored=true
  if(c.intent==='old-transformer-sword-fallback'||c.intent==='frozen-model-pending-sword')s.swordExitArmed={tick}
  const axe=(actual.attacks||[]).some(x=>x.attempted&&!x.cancelled&&x.held===7)
  if(axe){s.engagementAxeDone=true;s.lastAxeStrikeTick=tick;if(s.closeFight)s.closeFight.axeOpenerDone=true}
  if(actual.attacked){
   if((actual.attacks||[]).some(hit=>hit.attempted&&!hit.cancelled&&(hit.targetDamage>0||hit.targetShieldCooldown>0)))
    s.lastMeleeImpact=tick
   s.lastAttempt=tick;if(c.kind==='legacy86-ground')s.lastGroundAttempt=tick
   if(c.kind==='legacy86-stun')s.lastStunAt=tick
   if(s.closeFight&&c.kind==='legacy86-close')s.closeFight.firstHitDone=true
   if(Number.isFinite(c.consumesBlock))s.spentBlock=c.consumesBlock
   for(const hit of actual.attacks||[])s.pending.set(hit.id,{tick})
   const exitHit=(actual.attacks||[]).some(hit=>hit.attempted&&!hit.cancelled&&hit.targetDamage>0
    &&(!c.exitBOnAttack||hit.hitKind==='sprint-knockback'&&hit.outwardMotionConfirmed))
   if(exitHit&&(c.exitBOnAttack||c.intent==='close-exit-hit')){
    transition(s,PHASES.A,tick,'confirmed-exit-attack')
    if(c.exitOrigin&&c.worldHeading)s.exitRun={tick,origin:c.exitOrigin,heading:c.worldHeading}
   }
  }
  if(s.mode===PHASES.A){
   const effectiveAxe=(actual.attacks||[]).some(hit=>hit.attempted&&hit.held===7&&(hit.targetDamage>0||hit.targetShieldCooldown>0))
   s.retreating=Boolean(c.motionRetreat&&actual.sprint&&actual.forward>.5||effectiveAxe||s.exitRun)
  }
 }
 function receipt(s,e,tick){
  if(e.type==='blocked_melee'){s.lastBlock=tick;s.lastEnemyAttack=tick}
  if(e.type==='damage'&&e.axeReadyAtBlock===true)s.lastFullBlock=tick
  if(e.type==='shield_disabled')s.lastFullBlock=-1000
  if(e.type==='damage'&&!e.cancelled){
   if(e.victim===s.fighter&&e.amount>0)s.lastDamage=tick
   if(e.attacker===s.opponent&&e.victim===s.fighter&&e.melee)s.lastEnemyAttack=tick
   if(e.attacker===s.fighter&&e.victim===s.opponent&&e.melee){s.pending.delete(e.attackId);if(e.amount>0)s.lastHit=tick}
  }
  if(e.type==='attack_packet'&&e.willAttack===false)s.pending.delete(e.attackId)
 }
 return {ready:Promise.resolve(),runtime:null,createState,reset(s){current=s},decide,applied,receipt,rangedApplied,
  commitDecision,isDecisionCurrent:(s,p)=>s.decisionVersion===p.baseStateVersion,close:async()=>{}}
}
module.exports={createUnifiedSonBrain,retreatCriticalWindow,PHASES}
