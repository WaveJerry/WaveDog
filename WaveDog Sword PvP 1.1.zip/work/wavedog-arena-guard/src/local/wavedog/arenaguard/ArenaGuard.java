package local.wavedog.arenaguard;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

/** Arena maintenance only; never alters combat inputs, kits or player damage. */
public final class ArenaGuard extends JavaPlugin implements Listener, CommandExecutor {
    private static final int X0=990,X1=1038,Y0=219,Y1=240,Z0=990,Z1=1038;
    private static final int NX=X1-X0+1,NY=Y1-Y0+1,NZ=Z1-Z0+1,COUNT=NX*NY*NZ;
    private static final String MAGIC="WaveDogArenaGuard-v1";
    private World world;
    private BlockData[] baseline;
    private final Map<PluginCommand,CommandExecutor> originals=new LinkedHashMap<>();
    private final Map<PluginCommand,CommandExecutor> wrappers=new LinkedHashMap<>();
    private boolean enabled,initializing,cleaning,failed;
    private int scan,changed,removed,rounds,lastCycleTick;
    private boolean wasFighting;
    private String lastReason="startup";

    @Override public void onEnable(){
        getConfig().addDefault("enabled",true);
        getConfig().options().copyDefaults(true);saveConfig();
        enabled=getConfig().getBoolean("enabled",true);
        world=Objects.requireNonNull(Bukkit.getWorld("world"),"Main arena world missing");
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("wdarenaguard")).setExecutor(this);
        try {load();}catch(Exception error){failed=true;getLogger().severe("Baseline read failed: "+error);}
        wrap("wavedog_punengbho");wrap("wavedogson");
        if(Bukkit.getPluginCommand("wavedogbrother")!=null)wrap("wavedogbrother");
        getServer().getScheduler().runTaskTimer(this,this::tick,1,1);
        getLogger().info("Arena terrain preservation="+enabled+"; bounded maintenance, both duel controllers");
    }
    @Override public void onDisable(){
        for(var entry:originals.entrySet())if(entry.getKey().getExecutor()==wrappers.get(entry.getKey()))entry.getKey().setExecutor(entry.getValue());
    }
    private boolean inside(Location l){
        return l.getWorld()==world&&l.getX()>=X0&&l.getX()<X1+1&&l.getY()>=Y0&&l.getY()<Y1+1&&l.getZ()>=Z0&&l.getZ()<Z1+1;
    }
    private Block block(int i){
        int y=i%NY,q=i/NY,z=q%NZ,x=q/NZ;
        return world.getBlockAt(X0+x,Y0+y,Z0+z);
    }
    private boolean fixedButton(Block b){
        return b.getX()==992&&b.getY()==227&&(b.getZ()==1030||b.getZ()==1032||b.getZ()==1034);
    }
    private BlockData cleanBaseline(Block b){
        if(fixedButton(b))return Bukkit.createBlockData("minecraft:stone_button[face=wall,facing=east,powered=false]");
        // Floor block Y=220; the ceiling is exactly five block levels above.
        if(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036&&b.getY()==225)
            return Material.BARRIER.createBlockData();
        // The arena's established design is an open floor. Do not freeze
        // existing player obstacles or referee preparation cages as terrain.
        if(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036&&b.getY()>=221)
            return Material.AIR.createBlockData();
        if(b.getY()==219)return Material.BEDROCK.createBlockData();
        if(b.getY()==220&&b.getType().isAir())return floor(b.getX(),b.getZ()).createBlockData();
        return b.getBlockData();
    }
    private Material floor(int x,int z){
        if(x>=1013&&x<=1015&&z>=1013&&z<=1015)return Material.YELLOW_TERRACOTTA;
        if(x>=1012&&x<=1016&&z>=1012&&z<=1016)return Material.RED_TERRACOTTA;
        if(x>=1008&&x<=1020&&z>=1008&&z<=1020&&(x==1008||x==1020||z==1008||z==1020))return Material.POLISHED_BLACKSTONE;
        if(x>=1000&&x<=1028&&z>=1000&&z<=1028&&(x==1000||x==1028||z==1000||z==1028))return Material.CUT_SANDSTONE;
        if(x>=992&&x<=1036&&z>=992&&z<=1036&&(x==992||x==1036||z==992||z==1036))return Material.POLISHED_DEEPSLATE;
        return Material.SMOOTH_SANDSTONE;
    }
    private void load()throws IOException{
        Path file=getDataFolder().toPath().resolve("terrain.dat.gz");
        if(!Files.exists(file)){initializing=true;baseline=new BlockData[COUNT];return;}
        try(var in=new DataInputStream(new GZIPInputStream(Files.newInputStream(file)))){
            if(!MAGIC.equals(in.readUTF())||in.readInt()!=COUNT)throw new IOException("Unknown arena baseline");
            int n=in.readInt();if(n<1||n>COUNT)throw new IOException("Invalid palette");
            BlockData[] palette=new BlockData[n];for(int i=0;i<n;i++)palette[i]=Bukkit.createBlockData(in.readUTF());
            baseline=new BlockData[COUNT];
            for(int i=0;i<COUNT;i++){int p=in.readInt();if(p<0||p>=n)throw new IOException("Invalid block palette index");baseline[i]=palette[p];}
        }
    }
    private void save(){
        // Bukkit states are serialized on the main thread. Compression and
        // disk writes use the scheduler's I/O thread, never the combat thread.
        var palette=new LinkedHashMap<String,Integer>();int[] indices=new int[COUNT];
        for(int i=0;i<COUNT;i++)indices[i]=palette.computeIfAbsent(baseline[i].getAsString(),key->palette.size());
        String[] data=palette.keySet().toArray(String[]::new);
        Path file=getDataFolder().toPath().resolve("terrain.dat.gz");
        getServer().getScheduler().runTaskAsynchronously(this,()->{
            try{
                Files.createDirectories(file.getParent());Path temp=file.resolveSibling("terrain.dat.gz.tmp");
                try(var out=new DataOutputStream(new GZIPOutputStream(Files.newOutputStream(temp)))){
                    out.writeUTF(MAGIC);out.writeInt(COUNT);out.writeInt(data.length);
                    for(String s:data)out.writeUTF(s);for(int p:indices)out.writeInt(p);
                }
                Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            }catch(IOException error){getLogger().severe("Baseline write failed: "+error);}
        });
    }
    private boolean fighting(){
        for(var entry:Map.of("PunengbhoProtocolCore","WaveDog","WaveDogSonCore","WaveDogSon","WaveDogBrotherCore","WaveDogBrother").entrySet()){
            String name=entry.getKey();
            var core=Bukkit.getPluginManager().getPlugin(name);
            if(core==null||!core.isEnabled())continue;
            try{
                var a=core.getClass().getDeclaredField("active");var p=core.getClass().getDeclaredField("preparing");
                var o=core.getClass().getDeclaredField("opponent");a.setAccessible(true);p.setAccessible(true);o.setAccessible(true);
                if(a.getBoolean(core)||p.getBoolean(core)){
                    Player human=Bukkit.getPlayerExact((String)o.get(core));
                    Player bot=Bukkit.getPlayerExact(entry.getValue());
                    if(human!=null&&inside(human.getLocation())||bot!=null&&inside(bot.getLocation()))return true;
                }
            }catch(ReflectiveOperationException error){failed=true;getLogger().severe("Cannot read duel state: "+error);return true;}
        }
        return false;
    }
    private void wrap(String name){
        PluginCommand cmd=Objects.requireNonNull(Bukkit.getPluginCommand(name),name);
        CommandExecutor original=cmd.getExecutor();originals.put(cmd,original);
        CommandExecutor wrapper=(sender,command,label,args)->{
            if(!enabled||args.length!=2||!args[0].equalsIgnoreCase("duel")||!sender.hasPermission("wavedog.control"))
                return original.onCommand(sender,command,label,args);
            Player human=Bukkit.getPlayerExact(args[1]);
            if(human==null)return original.onCommand(sender,command,label,args);
            if(fighting()){
                sender.sendMessage("§e主竞技场已有对局，结束并清理后可开始下一局。");return true;
            }
            if(failed||initializing||cleaning){sender.sendMessage("§e竞技场正在恢复，请稍后再按按钮。");return true;}
            // Bounded restore completes before the referee receives DUEL.
            // It therefore cannot modify terrain beneath an active fight.
            clean("before:"+name,()->original.onCommand(sender,command,label,args));
            return true;
        };
        wrappers.put(cmd,wrapper);cmd.setExecutor(wrapper);
    }
    private void clean(String reason,Runnable done){
        if(!enabled||failed||initializing||cleaning||fighting())return;
        cleaning=true;scan=changed=removed=0;lastReason=reason;
        var entry=Bukkit.getPluginManager().getPlugin("WaveDogArenaEntry").getConfig();
        Block swordButton=entry.getBoolean("brother-button")&&world.getName().equals(entry.getString("world","world"))
            ?world.getBlockAt(entry.getInt("x"),entry.getInt("y"),entry.getInt("z")-4):null;
        BlockData swordButtonData=Bukkit.createBlockData("minecraft:stone_button[face=wall,facing=east,powered=false]");
        // One small batch per server tick; no world-wide entity scans and no
        // 50,000-block synchronous rewrite on the PvP tick.
        new org.bukkit.scheduler.BukkitRunnable(){
            @Override public void run(){
                if(!isEnabled()||fighting()){cleaning=false;cancel();return;}
                int end=Math.min(COUNT,scan+1500);
                for(;scan<end;scan++){
                    Block b=block(scan);BlockData expected=b.equals(swordButton)?swordButtonData:baseline[scan];
                    if(!b.getBlockData().matches(expected)){b.setBlockData(expected,false);changed++;}
                }
                if(scan<COUNT)return;
                var box=new org.bukkit.util.BoundingBox(X0,Y0,Z0,X1+1,Y1+1,Z1+1);
                for(Entity entity:world.getNearbyEntities(box)){
                    if(entity instanceof Player)continue;
                    if(entity instanceof TextDisplay&&(entity.getScoreboardTags().contains("wavedog_arena_entry_v1")
                        ||entity.getScoreboardTags().contains("wavedog_pvp_guide_20261113")))continue;
                    entity.remove();removed++;
                }
                cleaning=false;lastCycleTick=Bukkit.getCurrentTick();rounds++;
                getLogger().info("Arena restored: reason="+reason+", blocks="+changed+", entities="+removed);
                cancel();if(done!=null)done.run();
            }
        }.runTaskTimer(this,1,1);
    }
    private void tick(){
        if(!enabled||failed)return;
        boolean busy=fighting();
        if(initializing){
            if(busy)return;
            int end=Math.min(COUNT,scan+1500);
            for(;scan<end;scan++)baseline[scan]=cleanBaseline(block(scan));
            if(scan==COUNT){initializing=false;scan=0;save();clean("initial-enable",null);}
        }else if(!busy&&!cleaning&&wasFighting)clean("round-end",null);
        wasFighting=busy;
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void place(BlockPlaceEvent e){
        // UHC_TOOLS_BOUNDED: only active Son participants, original empty interior.
        if(!enabled||!inside(e.getBlock().getLocation()))return;
        Block b=e.getBlock();

        boolean uhc=false;var core=Bukkit.getPluginManager().getPlugin("WaveDogSonCore");
        if(core!=null&&core.isEnabled())try{
            var state=core.getClass().getDeclaredField("active");state.setAccessible(true);
            if(state.getBoolean(core))for(var tag:e.getPlayer().getMetadata("wavedog-duel-owner"))
                if(tag.getOwningPlugin()==core&&tag.asString().equals("WaveDogSon"))uhc=true;
        }catch(ReflectiveOperationException error){uhc=false;}

        if(!uhc||!(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036
            &&b.getY()>=221&&b.getY()<225
            &&baseline[(((b.getX()-X0)*NZ+b.getZ()-Z0)*NY+b.getY()-Y0)].getMaterial().isAir())){e.setCancelled(true);return;}
        if(!(true&&(b.getType()==Material.COBBLESTONE||b.getType()==Material.COBWEB)))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void breakBlock(BlockBreakEvent e){
        // UHC_TOOLS_BOUNDED: only active Son participants, original empty interior.
        if(!enabled||!inside(e.getBlock().getLocation()))return;
        Block b=e.getBlock();

        boolean uhc=false;var core=Bukkit.getPluginManager().getPlugin("WaveDogSonCore");
        if(core!=null&&core.isEnabled())try{
            var state=core.getClass().getDeclaredField("active");state.setAccessible(true);
            if(state.getBoolean(core))for(var tag:e.getPlayer().getMetadata("wavedog-duel-owner"))
                if(tag.getOwningPlugin()==core&&tag.asString().equals("WaveDogSon"))uhc=true;
        }catch(ReflectiveOperationException error){uhc=false;}

        if(!uhc||!(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036
            &&b.getY()>=221&&b.getY()<225
            &&baseline[(((b.getX()-X0)*NZ+b.getZ()-Z0)*NY+b.getY()-Y0)].getMaterial().isAir())){e.setCancelled(true);return;}
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void bucket(PlayerBucketEmptyEvent e){
        // UHC_TOOLS_BOUNDED: only active Son participants, original empty interior.
        if(!enabled||!inside(e.getBlock().getLocation()))return;
        Block b=e.getBlock();

        boolean uhc=false;var core=Bukkit.getPluginManager().getPlugin("WaveDogSonCore");
        if(core!=null&&core.isEnabled())try{
            var state=core.getClass().getDeclaredField("active");state.setAccessible(true);
            if(state.getBoolean(core))for(var tag:e.getPlayer().getMetadata("wavedog-duel-owner"))
                if(tag.getOwningPlugin()==core&&tag.asString().equals("WaveDogSon"))uhc=true;
        }catch(ReflectiveOperationException error){uhc=false;}

        if(!uhc||!(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036
            &&b.getY()>=221&&b.getY()<225
            &&baseline[(((b.getX()-X0)*NZ+b.getZ()-Z0)*NY+b.getY()-Y0)].getMaterial().isAir())){e.setCancelled(true);return;}
        if(!(true&&(e.getBucket()==Material.WATER_BUCKET||e.getBucket()==Material.LAVA_BUCKET)))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void bucketFill(PlayerBucketFillEvent e){
        // UHC_TOOLS_BOUNDED: only active Son participants, original empty interior.
        if(!enabled||!inside(e.getBlock().getLocation()))return;
        Block b=e.getBlock();

        boolean uhc=false;var core=Bukkit.getPluginManager().getPlugin("WaveDogSonCore");
        if(core!=null&&core.isEnabled())try{
            var state=core.getClass().getDeclaredField("active");state.setAccessible(true);
            if(state.getBoolean(core))for(var tag:e.getPlayer().getMetadata("wavedog-duel-owner"))
                if(tag.getOwningPlugin()==core&&tag.asString().equals("WaveDogSon"))uhc=true;
        }catch(ReflectiveOperationException error){uhc=false;}

        if(!uhc||!(b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036
            &&b.getY()>=221&&b.getY()<225
            &&baseline[(((b.getX()-X0)*NZ+b.getZ()-Z0)*NY+b.getY()-Y0)].getMaterial().isAir())){e.setCancelled(true);return;}
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void entityPlace(EntityPlaceEvent e){if(enabled&&inside(e.getEntity().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void hanging(HangingPlaceEvent e){if(enabled&&inside(e.getEntity().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void explode(EntityExplodeEvent e){if(enabled)e.blockList().removeIf(b->inside(b.getLocation()));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void blockExplode(BlockExplodeEvent e){if(enabled)e.blockList().removeIf(b->inside(b.getLocation()));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void burn(BlockBurnEvent e){if(enabled&&inside(e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void fire(BlockIgniteEvent e){if(enabled&&inside(e.getBlock().getLocation()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void fluid(BlockFromToEvent e){
        if(!enabled||!inside(e.getBlock().getLocation())&&!inside(e.getToBlock().getLocation()))return;
        Block from=e.getBlock(),to=e.getToBlock();boolean uhc=false;
        var core=Bukkit.getPluginManager().getPlugin("WaveDogSonCore");
        if(core!=null&&core.isEnabled())try{
            var state=core.getClass().getDeclaredField("active");state.setAccessible(true);uhc=state.getBoolean(core);
        }catch(ReflectiveOperationException error){uhc=false;}
        if(!uhc||!(from.getX()>=992&&from.getX()<=1036&&from.getZ()>=992&&from.getZ()<=1036
            &&from.getY()>=221&&from.getY()<225
            &&baseline[(((from.getX()-X0)*NZ+from.getZ()-Z0)*NY+from.getY()-Y0)].getMaterial().isAir())||!(to.getX()>=992&&to.getX()<=1036&&to.getZ()>=992&&to.getZ()<=1036
            &&to.getY()>=221&&to.getY()<225
            &&baseline[(((to.getX()-X0)*NZ+to.getZ()-Z0)*NY+to.getY()-Y0)].getMaterial().isAir()))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void piston(BlockPistonExtendEvent e){if(enabled&&(inside(e.getBlock().getLocation())||e.getBlocks().stream().anyMatch(b->inside(b.getLocation())||inside(b.getRelative(e.getDirection()).getLocation()))))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void pistonBack(BlockPistonRetractEvent e){if(enabled&&(inside(e.getBlock().getLocation())||e.getBlocks().stream().anyMatch(b->inside(b.getLocation()))))e.setCancelled(true);}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!sender.hasPermission("wavedog.control"))return true;
        String sub=args.length==0?"status":args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("on")||sub.equals("off")){
            enabled=sub.equals("on");getConfig().set("enabled",enabled);saveConfig();
            if(enabled&&!initializing&&!fighting())clean("operator-enable",null);
        }else if(sub.equals("lobby")){
            if(failed||initializing||cleaning||fighting()){sender.sendMessage("§e等场地空闲后再迁移入口。");return true;}
            for(int z:new int[]{1030,1032,1034}){
                baseline[((992-X0)*NZ+z-Z0)*NY+222-Y0]=Material.AIR.createBlockData();
                baseline[((992-X0)*NZ+z-Z0)*NY+227-Y0]=Bukkit.createBlockData("minecraft:stone_button[face=wall,facing=east,powered=false]");
            }
            save();sender.sendMessage("§b入口还原位置已迁移到屏障上方 Y=227，旧位置不再恢复。");
        }else if(sub.equals("ceiling")){
            if(failed||initializing||cleaning){sender.sendMessage("§e场地正在初始化或恢复，请稍后设置屏障顶。");return true;}
            BlockData roof=Material.BARRIER.createBlockData();
            for(int x=992;x<=1036;x++)for(int z=992;z<=1036;z++)
                baseline[((x-X0)*NZ+z-Z0)*NY+225-Y0]=roof;
            save();sender.sendMessage("§b屏障顶已写入每局还原基准：992 225 992 至 1036 225 1036。");
        }else if(sub.equals("clean")){
            if(fighting()){sender.sendMessage("§e对局中不重置场地，结束后自动清理。");return true;}
            clean("operator-clean",null);
        }
        sender.sendMessage("§b竞技场地形保持="+enabled+"，初始化="+initializing+"，清理中="+cleaning+"，故障="+failed
            +"，维护次数="+rounds+"，上次修复方块="+changed+"，清除实体="+removed+"，原因="+lastReason);
        return true;
    }
}
