"""Rebuild the Sword PvP additions against a Paper 1.21.11 installation."""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
CONTROLLER = 'WaveDogNativeControl'
MODULE = 'protocol-unified-son-brain.js'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def jar_bytes(original, replacements):
    packed = io.BytesIO()
    with zipfile.ZipFile(packed, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as jar:
        for name in sorted(original.keys() | replacements.keys()):
            jar.writestr(name, replacements[name] if name in replacements else original[name])
    return packed.getvalue()


def build_plugins(files, server, java):
    components = {
        CONTROLLER: 'wavedog-native',
        'PunengbhoProtocolCore': 'wavedog-punengbho',
        'WaveDogArenaEntry': 'wavedog-arena-entry',
        'WaveDogArenaGuard': 'wavedog-arena-guard',
        'WaveDogSonCore': 'wavedog-son',
        'WaveDogNeuralFallback': 'wavedog-neural-fallback',
    }
    api = next((server / 'libraries/io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT').glob('*.jar'))
    libraries = [server / 'versions/1.21.11/paper-1.21.11.jar', api,
                 *sorted((server / 'libraries').rglob('*.jar'), reverse=True)]
    with tempfile.TemporaryDirectory(prefix='wavedog-sword-build-', dir=ROOT) as build_dir:
        build = Path(build_dir)
        staged = build / f'{CONTROLLER}.jar'
        staged.write_bytes(files[f'plugins/{staged.name}'])
        cp = os.pathsep.join(map(str, [*libraries, staged]))
        for plugin, component in components.items():
            path = ROOT / 'work' / component
            classes = build / component
            classes.mkdir()
            args = ['-proc:none', '--release', '21', '-encoding', 'UTF-8', '-cp', cp, '-d', str(classes),
                    *map(str, sorted((path / 'src').rglob('*.java')))]
            response = build / 'javac.args'
            response.write_text('\n'.join(json.dumps(arg, ensure_ascii=False) for arg in args), encoding='utf8')
            result = subprocess.run([str(java / 'javac.exe'), '-J-Duser.language=en', '@' + str(response)],
                                    capture_output=True, encoding='utf8', errors='replace',
                                    creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode:
                raise SystemExit(f'{plugin}: {result.stdout}{result.stderr}')
            compiled = {file.relative_to(classes).as_posix(): file.read_bytes() for file in classes.rglob('*.class')}
            name = f'plugins/{plugin}.jar'
            with zipfile.ZipFile(io.BytesIO(files[name])) as existing:
                entries = {file: existing.read(file) for file in existing.namelist()}
            files[name] = jar_bytes(entries, {**compiled, 'plugin.yml': (path / 'plugin.yml').read_bytes()})
            if plugin == 'PunengbhoProtocolCore':
                files['plugins/WaveDogBrotherCore.jar'] = jar_bytes({}, {
                    **compiled, 'plugin.yml': (path / 'plugin-brother.yml').read_bytes()})

    name = f'plugins/{CONTROLLER}.jar'
    with zipfile.ZipFile(io.BytesIO(files[name])) as existing:
        entries = {file: existing.read(file) for file in existing.namelist()}
    policy = json.loads(entries['policy-manifest.json'])
    policy['files'][MODULE] = digest(files['work/pvp-player-client/' + MODULE])
    policy['sha256'] = digest(json.dumps(policy['files'], sort_keys=True).encode())
    entries['policy/' + MODULE] = files['work/pvp-player-client/' + MODULE]
    entries['policy-manifest.json'] = (json.dumps(policy, indent=2) + '\n').encode()
    files[name] = jar_bytes(entries, {})
    return policy, entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--server-root', required=True, type=Path)
    parser.add_argument('--java-bin', type=Path)
    args = parser.parse_args()
    server = args.server_root.resolve()
    java = args.java_bin.resolve() if args.java_bin else server / 'runtime/java21/bin'
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf8'))
    files = {name: (ROOT / name).read_bytes() for name in manifest['files']}
    policy, _ = build_plugins(files, server, java)
    for name in files:
        if name.startswith('plugins/') and name.endswith('.jar'):
            (ROOT / name).write_bytes(files[name])
            manifest['plugins'][Path(name).name] = {'sha256': digest(files[name])}
    manifest['loadedPolicySha256'] = policy['sha256']
    manifest['startupJarSha256'] = digest(files[f'plugins/{CONTROLLER}.jar'])
    manifest['files'] = {name: digest((ROOT / name).read_bytes()) for name in sorted(files)}
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf8')
    print(f"Built Sword PvP policy {policy['sha256']}")


if __name__ == '__main__':
    main()
