package local.wavedog.nativecontrol;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.bukkit.Bukkit;

/** One local, read-only speech worker for all native fighters. Never blocks combat. */
final class PerceptionDialogueBridge implements AutoCloseable {
    private final NativeControl owner;
    private final Process worker;
    private final BlockingQueue<String> pending=new ArrayBlockingQueue<>(128);
    private final Map<String,Integer> sentTick=new HashMap<>();
    private final Map<String,String> sentSignature=new HashMap<>();
    private final Thread writer,reader;
    private volatile boolean ready,running=true;

    PerceptionDialogueBridge(NativeControl owner)throws Exception{
        this.owner=owner;
        Path script=NativeControl.ROOT.resolve("work/pvp-dual-brain/perception-language/live-worker.js");
        Path checkpoint=NativeControl.ROOT.resolve("outputs/pvp-perception-language/checkpoint.json");
        if(!Files.isRegularFile(script)||!Files.isRegularFile(checkpoint))
            throw new FileNotFoundException("Local perception speech model is missing");
        String node=System.getProperty("wavedog.node","E:/node/node.exe");
        owner.getDataFolder().mkdirs();
        worker=new ProcessBuilder(node,script.toString(),checkpoint.toString())
            .directory(NativeControl.ROOT.toFile())
            .redirectError(owner.getDataFolder().toPath().resolve("perception.err.log").toFile()).start();
        writer=new Thread(()->{
            try(var output=new BufferedWriter(new OutputStreamWriter(worker.getOutputStream(),StandardCharsets.UTF_8))){
                while(running){String line=pending.poll(250,TimeUnit.MILLISECONDS);
                    if(line!=null){output.write(line);output.newLine();output.flush();}}
            }catch(Exception error){if(running)owner.getLogger().warning("Perception speech writer: "+error);}
        },"WaveDog-perception-speech-writer");writer.setDaemon(true);writer.start();
        reader=new Thread(()->{
            try(var input=new BufferedReader(new InputStreamReader(worker.getInputStream(),StandardCharsets.UTF_8))){
                for(String line;(line=input.readLine())!=null&&running;){
                    JsonObject row=JsonParser.parseString(line).getAsJsonObject();
                    if(row.has("ready")){
                        ready=row.get("ready").getAsBoolean();
                        if(ready)owner.getLogger().info("Local PvP perception speech ready");
                        continue;
                    }
                    if(row.has("error")){owner.getLogger().warning("Perception speech: "+row.get("error").getAsString());continue;}
                    if(row.has("feedbackStatus")){
                        String teacher=row.get("teacher").getAsString();
                        String message=row.get("message").getAsString();
                        if(message.length()>200)continue;
                        row.addProperty("speaker",teacher);row.addProperty("matchId","");
                        row.addProperty("text",message);row.addProperty("kind","feedback");
                    }
                    if(!row.has("speaker")||!row.has("matchId")||!row.has("text"))continue;
                    String speaker=row.get("speaker").getAsString(),match=row.get("matchId").getAsString();
                    String text=row.get("text").getAsString(),kind=row.has("kind")?row.get("kind").getAsString():"frame";
                    if(text.length()>(kind.equals("feedback")?200:40)||text.isBlank()
                        ||text.chars().anyMatch(Character::isISOControl))continue;
                    if(!owner.isEnabled())continue;
                    Bukkit.getScheduler().runTask(owner,()->{
                        if(!owner.isEnabled())return;
                        if(kind.equals("feedback")){
                            var teacher=Bukkit.getPlayerExact(speaker);
                            if(teacher!=null)teacher.sendMessage("§b[感知训练] §f"+text);
                            return;
                        }
                        var actor=owner.actors.get(speaker);
                        if(actor==null||actor.player()==null||!Objects.equals(actor.match,match)
                            ||!actor.active&&!kind.equals("end")
                                &&!(kind.equals("prepare")&&actor.player().hasMetadata("wavedog-preparation-cage")
                                    &&actor.lastAimTick-Bukkit.getCurrentTick()>20))return;
                        actor.player().chat(text);
                    });
                }
            }catch(Exception error){if(running)owner.getLogger().warning("Perception speech reader: "+error);}
            finally{ready=false;}
        },"WaveDog-perception-speech-reader");reader.setDaemon(true);reader.start();
    }

    private Map<String,Object> publicFrame(Map<String,Object> frame){
        var clean=new LinkedHashMap<String,Object>();
        for(String key:List.of("self","seen","observation","targetFloorY","neuralFallback","nativeEvents"))
            if(frame.containsKey(key))clean.put(key,frame.get(key));
        return clean;
    }
    void offer(NativeControl.Actor actor,Map<String,Object> frame){
        boolean preparing=actor.player()!=null&&actor.player().hasMetadata("wavedog-preparation-cage")&&!actor.active;
        if(!ready||!actor.active&&!preparing||actor.match==null||!frame.containsKey("observation"))return;
        @SuppressWarnings("unchecked") var observation=(Map<String,Object>)frame.get("observation");
        int tick=((Number)observation.get("tick")).intValue();
        int events=frame.get("nativeEvents") instanceof List<?> list?list.size():0;
        String signature=actor.match+":"+tick+":"+events;
        if(signature.equals(sentSignature.get(actor.name)))return;
        if(events==0&&tick-sentTick.getOrDefault(actor.name,-1000)<20)return;
        sentSignature.put(actor.name,signature);sentTick.put(actor.name,tick);
        pending.offer(NativeControl.JSON.toJson(Map.of("kind",preparing?"prepare":"frame","speaker",actor.name,
            "matchId",actor.match,"frame",publicFrame(frame))));
    }
    void end(NativeControl.Actor actor,Map<String,Object> row){
        if(!ready||actor.match==null||actor.frames.isEmpty())return;
        var frame=actor.frames.getLast();
        pending.offer(NativeControl.JSON.toJson(Map.of("kind","end","speaker",actor.name,
            "matchId",actor.match,"winner",String.valueOf(row.getOrDefault("winner","")),
            "frame",publicFrame(frame))));
    }
    boolean isReady(){return ready;}
    @Override public void close(){
        running=false;ready=false;writer.interrupt();reader.interrupt();worker.destroy();
    }
}
