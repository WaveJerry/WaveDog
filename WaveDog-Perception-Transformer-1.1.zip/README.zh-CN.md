# WaveDog 感受型语言 Transformer v1

WaveJ 的 PvP 发言模型。它结合 Son 战况向量、冻结战斗模型的动作输出和已结算的游戏事件，判断这时候该说哪类短句，或保持沉默。战斗控制仍由现有 WaveDog 策略执行。

## 解压后先跑模型

准备 Node.js 24 和 npm。在解压目录打开 PowerShell。

```powershell
npm.cmd --prefix .\work\pvp-dual-brain ci --omit=dev
node .\work\pvp-dual-brain\perception-language\demo.js
node .\work\pvp-dual-brain\perception-language\test.js
node .\work\pvp-dual-brain\perception-language\test-online.js
node .\work\pvp-dual-brain\perception-language\test-live-online.js
```

如果 Node.js 没加到 PATH，先把其安装目录加到当前 PowerShell 的 PATH。检查点默认位于 `outputs/pvp-perception-language/checkpoint.json`。首次 `npm ci` 会从 npm 下载依赖。更详细的模型结构和源码说明见 [核心代码教程](./work/pvp-dual-brain/perception-language/README.zh-CN.md)。

## 接入已有的 WaveDog Paper 1.21.11 服务器

1. 准备已有可运行的 WaveDog 服务端机器人和竞技场，使用 Java 21。把包内 `work`、`outputs` 合并到 WaveDog 项目目录，保留目录结构，再运行上面的依赖安装命令。已有 `online-adapter.json` 时先核对它对应的基础检查点哈希。
2. 若控制器已支持 `/wdnative restart-speech` 和 `/wdnative teach`，沿用该控制器。包内 `integration/plugins/WaveDogNativeControl.jar` 是这套发言桥接的编译快照，包含配套的战斗控制器。需要用它更新旧控制器时，先备份旧 JAR，在目标版本隔离服核对机器人能加载，再停服替换；同时检查 `plugins/update` 中是否有待覆盖的其他版本。把 `integration/plugins/WaveDogChatSense.jar` 放进服务器的 `plugins`。
3. 在服务器启动命令的 `-jar` 前加 `"-Dwavedog.workspace=合并后的项目绝对路径"` 和 `"-Dwavedog.node=你的 node.exe 绝对路径"`。在 `plugins/WaveDogNativeControl/config.yml` 加入 `dialogue-enabled: true`，然后启动服务器。
4. 在日志中确认 `Local PvP perception speech ready`。在已有新版桥接且发言已启用时，管理员可用 `/wdnative restart-speech` 单独重启发言进程。对战中可以用 `/wdnative teach son 弓箭 好箭` 或 `/wdnative quiet son` 提交教学。教学以对局事件和对手身份为准，详细参数在核心代码教程里。

独立接入时可直接导入 `infer.js` 的 `DialogueEngine`。输入含机器人名、98 维 Son 战况、367 维 PvP 向量和已确认事件，返回 `said`、`intent` 和 `text`。现有 Worker 用九个动作索引编码最后 47 维，GRU 和 GTrXL 的前 320 维仍为零。在线教学更新发言头和聊天特征适配器，基础检查点保持只读。

ZIP 提供基础检查点、训练报告、Node 源码、依赖锁文件、Java 桥接源码及编译快照。已有 Paper 服务端、竞技场、战斗模型依赖和历史教学数据由各服管理。命令参数用你本机的路径填写。
