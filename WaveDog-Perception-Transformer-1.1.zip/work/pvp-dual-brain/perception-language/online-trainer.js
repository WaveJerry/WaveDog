import fs from 'node:fs'
import path from 'node:path'
import {parentPort,workerData} from 'node:worker_threads'
import * as tf from '@tensorflow/tfjs'
import {PerceptionTransformer} from './model.js'
import {INTENTS,toTensors} from './dialogue.js'
import {applyAdapter,baseHash,captureAdapter,chatBias,chatFeatures,CHAT_WIDTH,makeAdapter} from './online-adapter.js'

if(!parentPort)throw Error('online trainer must run in a worker thread')
await tf.setBackend('cpu');await tf.ready()
const checkpoint=JSON.parse(fs.readFileSync(workerData.checkpoint,'utf8'))
const hash=baseHash(workerData.checkpoint)
const model=new PerceptionTransformer(checkpoint.classes,checkpoint.config)
model.restore(checkpoint)
let adapter=makeAdapter(model,hash)
if(fs.existsSync(workerData.adapter)){
  const saved=JSON.parse(fs.readFileSync(workerData.adapter,'utf8'))
  applyAdapter(model,saved,hash);adapter=saved
}
const optimizer=tf.train.adam(.0003)
const trainable=[...model.head.params,...model.eventHead.params]
let queue=Promise.resolve()

function save(){
  const target=workerData.adapter,temp=`${target}.tmp`
  fs.mkdirSync(path.dirname(target),{recursive:true})
  fs.writeFileSync(temp,JSON.stringify(captureAdapter(model,adapter)))
  fs.renameSync(temp,target)
}
function train(sample,nextOffset=null){
  if(!sample||typeof sample.id!=='string'||!Array.isArray(sample.history)
    ||sample.history.length<1||sample.history.length>8
    ||!Number.isInteger(sample.label)||sample.label<0||sample.label>=INTENTS.length)
    throw Error('invalid online teaching example')
  if(adapter.seenIds.includes(sample.id)){
    if(nextOffset!==null){adapter.processedOffset=nextOffset;save()}
    return {duplicate:true,id:sample.id}
  }
  const input=toTensors([{history:sample.history,persona:sample.persona}])
  const label=tf.tensor1d([sample.label],'int32')
  let loss=0
  try{
    for(let step=0;step<2;step++){
      const cost=optimizer.minimize(()=>tf.tidy(()=>{
        const truth=tf.oneHot(label,INTENTS.length)
        return tf.mean(tf.losses.softmaxCrossEntropy(truth,model.logits(input)))
      }),true,trainable)
      loss=cost.dataSync()[0];cost.dispose()
    }
  }finally{label.dispose();for(const tensor of Object.values(input))tensor.dispose()}
  if(!Number.isFinite(loss))throw Error('nonfinite online loss')
  if(sample.chatText){
    const features=chatFeatures(sample.chatText)
    const bias=chatBias(adapter,sample.chatText)
    const input=toTensors([{history:sample.history,persona:sample.persona}])
    const logits=tf.tidy(()=>[...model.logits(input).dataSync()])
    for(const tensor of Object.values(input))tensor.dispose()
    const score=logits.map((value,index)=>value+bias[index])
    const peak=Math.max(...score),exp=score.map(value=>Math.exp(value-peak))
    const sum=exp.reduce((a,b)=>a+b,0)
    for(let i=0;i<CHAT_WIDTH;i++)if(features[i])for(let j=0;j<INTENTS.length;j++){
      const index=i*INTENTS.length+j,error=exp[j]/sum-(j===sample.label?1:0)
      adapter.chatWeights[index]=Math.max(-2,Math.min(2,
        adapter.chatWeights[index]-.8*error*features[i]))
    }
  }
  if(sample.phrase){
    const key=INTENTS[sample.label]
    if(!adapter.phrases[key])adapter.phrases[key]=[]
    if(!adapter.phrases[key].includes(sample.phrase))adapter.phrases[key].push(sample.phrase)
    if(adapter.phrases[key].length>32)adapter.phrases[key].shift()
  }
  adapter.seenIds.push(sample.id)
  if(adapter.seenIds.length>512)adapter.seenIds.shift()
  adapter.revision++;adapter.trainedExamples++
  if(nextOffset!==null)adapter.processedOffset=nextOffset
  save()
  return {trained:true,id:sample.id,revision:adapter.revision,loss,adapter}
}
parentPort.on('message',sample=>{
  queue=queue.then(()=>{
    try{parentPort.postMessage(train(sample))}
    catch(error){parentPort.postMessage({id:sample?.id,error:String(error).slice(0,300)})}
  })
})
parentPort.postMessage({ready:true,revision:adapter.revision})
function pollExamples(){
  const file=workerData.examples
  if(!file||!fs.existsSync(file))return
  const size=fs.statSync(file).size,offset=adapter.processedOffset||0
  if(size<offset)throw Error('online examples log was truncated')
  const length=Math.min(size-offset,1024*1024)
  if(length<=0)return
  const bytes=Buffer.alloc(length),handle=fs.openSync(file,'r')
  try{fs.readSync(handle,bytes,0,length,offset)}finally{fs.closeSync(handle)}
  const last=bytes.lastIndexOf(10)
  if(last<0)return
  let next=offset
  for(const row of bytes.subarray(0,last+1).toString('utf8').split('\n')){
    if(!row)continue
    next+=Buffer.byteLength(row+'\n')
    try{parentPort.postMessage(train(JSON.parse(row),next))}
    catch(error){
      adapter.processedOffset=next;save()
      parentPort.postMessage({error:String(error).slice(0,300)})
    }
  }
}
setInterval(()=>{try{pollExamples()}catch(error){parentPort.postMessage({error:String(error)})}},250).unref()
