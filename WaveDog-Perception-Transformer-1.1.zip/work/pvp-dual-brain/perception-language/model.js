import * as tf from '@tensorflow/tfjs'

export const SON_WIDTH = 98
export const PVP_WIDTH = 367 // 64 GRU + 256 GTrXL + 47 action probabilities
export const EVENT_WIDTH = 16
export const HISTORY = 8
export const PERSONA_WIDTH = 4
export const DEFAULT_CONFIG = Object.freeze({width: 128, layers: 4, heads: 4})

let serial = 0
class Dense {
  constructor(input, output, prefix) {
    this.input=input;this.output=output
    this.w = tf.variable(tf.randomNormal([input, output], 0, 1 / Math.sqrt(input)),
      true, `${prefix}.w`)
    this.b = tf.variable(tf.zeros([output]), true, `${prefix}.b`)
    this.params = [this.w, this.b]
  }
  apply(x) {return tf.add(tf.matMul(x.reshape([-1,this.input]),this.w),this.b)
    .reshape([...x.shape.slice(0,-1),this.output])}
}
class LayerNorm {
  constructor(width, prefix) {
    this.scale = tf.variable(tf.ones([width]), true, `${prefix}.scale`)
    this.bias = tf.variable(tf.zeros([width]), true, `${prefix}.bias`)
    this.params = [this.scale, this.bias]
  }
  apply(x) {
    const {mean, variance} = tf.moments(x, -1, true)
    return tf.add(tf.mul(tf.div(tf.sub(x, mean), tf.sqrt(tf.add(variance, 1e-5))),
      this.scale), this.bias)
  }
}
class AttentionBlock {
  constructor(width, heads, prefix) {
    this.width = width; this.heads = heads; this.headWidth = width / heads
    this.q = new Dense(width, width, `${prefix}.q`)
    this.k = new Dense(width, width, `${prefix}.k`)
    this.v = new Dense(width, width, `${prefix}.v`)
    this.out = new Dense(width, width, `${prefix}.out`)
    this.ff1 = new Dense(width, width * 4, `${prefix}.ff1`)
    this.ff2 = new Dense(width * 4, width, `${prefix}.ff2`)
    this.norm1 = new LayerNorm(width, `${prefix}.norm1`)
    this.norm2 = new LayerNorm(width, `${prefix}.norm2`)
    this.params = [this.q,this.k,this.v,this.out,this.ff1,this.ff2,
      this.norm1,this.norm2].flatMap(part => part.params)
  }
  apply(x) {
    const [batch, tokens] = x.shape
    const split = projection => projection.apply(x)
      .reshape([batch, tokens, this.heads, this.headWidth]).transpose([0,2,1,3])
    const q = split(this.q), k = split(this.k), v = split(this.v)
    const attention = tf.softmax(tf.div(tf.matMul(q,k,false,true), Math.sqrt(this.headWidth)), -1)
    const values = tf.matMul(attention,v).transpose([0,2,1,3])
      .reshape([batch,tokens,this.width])
    const first = this.norm1.apply(tf.add(x,this.out.apply(values)))
    return this.norm2.apply(tf.add(first,this.ff2.apply(tf.relu(this.ff1.apply(first)))))
  }
}

export class PerceptionTransformer {
  constructor(classes, config = DEFAULT_CONFIG) {
    if(config.width % config.heads !== 0)throw Error('width must divide heads')
    this.classes = classes
    this.config = {...config}
    const id = `perception-${++serial}`
    this.son = new Dense(SON_WIDTH,config.width,`${id}.son`)
    this.pvp = new Dense(PVP_WIDTH,config.width,`${id}.pvp`)
    this.event = new Dense(EVENT_WIDTH,config.width,`${id}.event`)
    this.persona = new Dense(PERSONA_WIDTH,config.width,`${id}.persona`)
    this.cls = tf.variable(tf.randomNormal([1,1,config.width],0,.02),true,`${id}.cls`)
    this.position = tf.variable(tf.randomNormal([1,2+HISTORY*3,config.width],0,.02),true,`${id}.position`)
    this.blocks = Array.from({length:config.layers},(_,i)=>new AttentionBlock(config.width,config.heads,`${id}.block${i}`))
    this.head = new Dense(config.width,classes,`${id}.head`)
    // A short factual path prevents a rare confirmed hit from being diluted
    // among 26 history tokens. The Transformer still models timing and style.
    this.eventHead = new Dense(EVENT_WIDTH,classes,`${id}.event-head`)
    this.params = [this.son,this.pvp,this.event,this.persona,
      ...this.blocks,this.head,this.eventHead].flatMap(part=>part.params).concat([this.cls,this.position])
  }
  parameterCount(){return this.params.reduce((total,p)=>total+p.size,0)}
  logits(input){
    const {son,pvp,event,persona} = input
    const batch = son.shape[0]
    if(JSON.stringify(son.shape.slice(1))!==JSON.stringify([HISTORY,SON_WIDTH])
      ||JSON.stringify(pvp.shape)!==JSON.stringify([batch,HISTORY,PVP_WIDTH])
      ||JSON.stringify(event.shape)!==JSON.stringify([batch,HISTORY,EVENT_WIDTH])
      ||JSON.stringify(persona.shape)!==JSON.stringify([batch,PERSONA_WIDTH]))
      throw Error('invalid perception vector shapes')
    const tokens = tf.stack([this.son.apply(son),this.pvp.apply(pvp),this.event.apply(event)],2)
      .reshape([batch,HISTORY*3,this.config.width])
    const sequence = tf.add(tf.concat([this.cls.tile([batch,1,1]),
      this.persona.apply(persona).reshape([batch,1,this.config.width]),tokens],1),this.position)
    let state=sequence
    for(const block of this.blocks)state=block.apply(state)
    const summary=state.slice([0,0,0],[batch,1,this.config.width]).reshape([batch,this.config.width])
    const latest=event.slice([0,HISTORY-1,0],[batch,1,EVENT_WIDTH]).reshape([batch,EVENT_WIDTH])
    return tf.add(this.head.apply(summary),this.eventHead.apply(latest))
  }
  dispose(){for(const parameter of this.params)parameter.dispose()}
  snapshot(){return {schema:'wavedog-perception-language-v1',classes:this.classes,
    config:this.config,parameterCount:this.parameterCount(),weights:this.params.map(p=>({shape:p.shape,values:[...p.dataSync()]}))}}
  restore(snapshot){
    if(snapshot.schema!=='wavedog-perception-language-v1'||snapshot.classes!==this.classes
      ||JSON.stringify(snapshot.config)!==JSON.stringify(this.config)
      ||snapshot.weights.length!==this.params.length)throw Error('checkpoint schema mismatch')
    for(let i=0;i<this.params.length;i++){
      const parameter=this.params[i],saved=snapshot.weights[i]
      if(JSON.stringify(parameter.shape)!==JSON.stringify(saved.shape))throw Error('weight shape mismatch '+i)
      const tensor=tf.tensor(saved.values,saved.shape);parameter.assign(tensor);tensor.dispose()
    }
  }
}
