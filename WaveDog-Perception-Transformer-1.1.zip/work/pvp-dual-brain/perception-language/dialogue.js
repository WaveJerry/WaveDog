import * as tf from '@tensorflow/tfjs'
import {SON_WIDTH,PVP_WIDTH,EVENT_WIDTH,HISTORY,PERSONA_WIDTH} from './model.js'

export const ACTION_WIDTHS = [9,2,2,2,5,5,13,7,2]
export const EVENTS = ['boutStart','boutEnd','won','lost','enemyRetreat','enemyBowHit',
  'enemyMaceHit','enemyCrystalHit','ownCombo','ownLowHealth','enemyShield',
  'ownBowHit','ownMaceHit','ownCrystalHit','enemyNear','quiet']
export const INTENTS = ['silence','opener','retreat_roast','nice_bow','nice_mace',
  'nice_crystal','combo_hype','shield_respect','clutch','gg_win','gg_loss','tilt']

export const PHRASES = {
  opener:['来，认真打一把','开了开了','来点强度','这把看操作',
    'glhf','来，碰一把','先打再说','准备好没'],
  retreat_roast:['666后撤怪','你这拉扯可以啊','跑得挺有章法','这波搁这练折返跑呢','别跑，来换血',
    '还跑？','拉扯大师是吧','跑图呢？','你这后撤步挺熟','追不上，真有你的','拉扯得真细','跑男来了',
    '你跑尼玛个东方明珠塔跑'],
  nice_bow:['好弓箭','nice shot','这箭有东西','弓是真的准','这箭我认',
    '好箭','这预判可以','箭挺刁钻','弓法可以','准得离谱','nice aim','弓狗'],
  nice_mace:['这锤可以','好砸！','重锤时机抓得准','这下砸得漂亮',
    '好锤','这落点抓得准','这一下真疼','重锤有说法','nice mace'],
  nice_crystal:['水晶放得漂亮','这颗水晶有东西','这波水晶我服','好炸',
    '这水晶真细','这颗放得妙','炸得漂亮','nice crystal'],
  combo_hype:['666这波连上了','这波节奏对了','哎，连起来了','这段换血舒服',
    '这波连招丝滑','666这波','连得真顺','这套有点东西','给你连上了'],
  shield_respect:['这盾举得真及时','盾反有点东西','这波防得漂亮',
    '盾举得够快','好防','这下盾用得对'],
  clutch:['差点给我送走','血压上来了','这波太极限了','还能打，还能打',
    'not even close','差点寄了','这都活下来了','真悬','就差那么一点','心跳了一下'],
  gg_win:['gg','good game','打得不错，gg','这把过瘾，gg',
    'wp','gf','漂亮，gg','这局打得真爽','ez','L','git gud','?',':)','：）'],
  gg_loss:['gg','这把你赢了，gg','打得好，认了','good game',
    'gf','wp','这把你强','认了，打得好','下把再来','好局'],
  tilt:['LL','666后撤怪','你是真的能跑','我服了这走位','又来这套？',
    'L','还拉扯？','拉扯怪是吧','别拉了我真红了','你这后撤我服了','666，又跑','也够','野狗']
}
const REQUIRED = {
  opener:e=>e.boutStart,
  retreat_roast:e=>e.enemyRetreat,
  nice_bow:e=>e.enemyBowHit,
  nice_mace:e=>e.enemyMaceHit,
  nice_crystal:e=>e.enemyCrystalHit,
  combo_hype:e=>e.ownCombo,
  shield_respect:e=>e.enemyShield,
  clutch:e=>e.ownLowHealth,
  gg_win:e=>e.boutEnd&&e.won,
  gg_loss:e=>e.boutEnd&&e.lost,
  tilt:e=>e.enemyRetreat&&e.ownLowHealth
}
export function canSpeak(intent,events={}){
  return intent==='silence'||Boolean(REQUIRED[intent]?.(events))
}
const zeros = length => Array(length).fill(0)
const bounded = (values,length,label) => {
  if(!Array.isArray(values)||values.length!==length||values.some(v=>!Number.isFinite(v)))
    throw Error(`${label} must have ${length} finite numbers`)
  return values.map(v=>Math.max(-3,Math.min(3,v)))
}

export function pvpFromDual({fast=null,slow=null,probabilities=null,actions=null}={}){
  const front=[...(fast?bounded(fast,64,'GRU vector'):zeros(64)),
    ...(slow?bounded(slow,256,'Transformer vector'):zeros(256))]
  if(probabilities){
    if(probabilities.length!==ACTION_WIDTHS.length)throw Error('nine PvP action heads required')
    return front.concat(probabilities.flatMap((head,i)=>bounded(head,ACTION_WIDTHS[i],`head ${i}`)))
  }
  if(actions){
    if(actions.length!==ACTION_WIDTHS.length)throw Error('nine PvP actions required')
    return front.concat(actions.flatMap((action,i)=>ACTION_WIDTHS[i]===0?[]:
      Array.from({length:ACTION_WIDTHS[i]},(_,j)=>j===action?1:0)))
  }
  return front.concat(zeros(47))
}

export function eventVector(events={}) {return EVENTS.map(name=>events[name]?1:0)}
export function frame({sonVector,pvpVector,events={}}){
  return {son:bounded(sonVector,SON_WIDTH,'Son vector'),
    pvp:bounded(pvpVector,PVP_WIDTH,'PvP vector'),event:eventVector(events),events}
}

export function persona(name){
  if(name==='WaveDogSon')return [1,0,0,0]
  if(name==='WaveDogBrother')return [0,1,0,0]
  if(name==='WaveDogFather')return [0,0,1,0]
  if(name==='WaveDogSister')return [0,0,0,1]
  return [.25,.25,.25,.25]
}

export function toTensors(samples){
  const son=[],pvp=[],event=[],personal=[]
  for(const sample of samples){
    const rows=sample.history.slice(-HISTORY)
    const padded=Array.from({length:Math.max(0,HISTORY-rows.length)},()=>({son:zeros(SON_WIDTH),
      pvp:zeros(PVP_WIDTH),event:zeros(EVENT_WIDTH)})).concat(rows)
    son.push(padded.map(row=>row.son));pvp.push(padded.map(row=>row.pvp))
    event.push(padded.map(row=>row.event));personal.push(sample.persona)
  }
  return {son:tf.tensor3d(son),pvp:tf.tensor3d(pvp),event:tf.tensor3d(event),
    persona:tf.tensor2d(personal)}
}

/** Context guard keeps generated words true to observed PvP events. */
export function speak(intent,events,session={},now=Date.now(),rng=Math.random){
  if(intent==='silence'||!PHRASES[intent]||!canSpeak(intent,events))return null
  const terminal=intent.startsWith('gg_')
  if(!terminal&&now-(session.lastAt||0)<8000)return null
  if(session.lastIntent===intent&&now-(session.lastAt||0)<18000)return null
  const choices=PHRASES[intent].filter(text=>text!==session.lastText)
  const pool=choices.length?choices:PHRASES[intent]
  const text=pool[Math.floor(Math.max(0,Math.min(.999999,rng()))*pool.length)]
  session.lastAt=now;session.lastIntent=intent;session.lastText=text
  return text
}
