import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {spawn} from 'node:child_process'
import readline from 'node:readline'

const root=path.resolve('outputs/pvp-perception-language')
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-live-online-'))
const checkpoint=path.join(directory,'checkpoint.json')
fs.copyFileSync(path.join(root,'checkpoint.json'),checkpoint)
const frame={
  self:{x:1000,y:221,z:1000,eyeY:222.62,health:20,charge:1,ground:true,
    vx:0,vy:0,vz:0,shieldAvailable:true,shielding:false,using:false,useTicks:0,
    arrows:8,crossbowLoaded:false,held:0,nativeYaw:-90,nativePitch:0},
  seen:{x:1004,y:221,z:1000,visible:true,using:false,held:'DIAMOND_SWORD',
    nativeYaw:90,arrows:[]},
  observation:{tick:100,reach:3.7,distance:4,targetShieldRaised:false}
}
const child=spawn(process.execPath,[path.resolve('work/pvp-dual-brain/perception-language/live-worker.js'),checkpoint],
  {stdio:['pipe','pipe','pipe']})
const rows=[],lines=readline.createInterface({input:child.stdout})
lines.on('line',line=>{try{rows.push(JSON.parse(line))}catch{}})
let errors='';child.stderr.on('data',chunk=>{errors+=chunk})
async function until(predicate,limitMs=15000){
  const started=Date.now()
  while(Date.now()-started<limitMs){
    const found=rows.find(predicate)
    if(found)return found
    if(child.exitCode!==null)throw Error('speech worker exited: '+errors)
    await new Promise(resolve=>setTimeout(resolve,100))
  }
  throw Error('speech worker timed out: '+JSON.stringify(rows)+' '+errors)
}
try{
  await until(row=>row.ready)
  await until(row=>row.trainingReady)
  child.stdin.write(JSON.stringify({speaker:'WaveDogSon',matchId:'test-live-online',
    frame,kind:'prepare'})+'\n')
  await new Promise(resolve=>setTimeout(resolve,700))
  fs.writeFileSync(path.join(directory,'player-chat.jsonl'),JSON.stringify({
    speaker:'WaveDogSon',matchId:'test-live-online',player:'WaveJerry',
    text:'你好，来打一把',tick:frame.observation.tick})+'\n')
  await new Promise(resolve=>setTimeout(resolve,700))
  const teaching={id:'test-live-1',teacher:'WaveJerry',speaker:'WaveDogSon',
    matchId:'test-live-online',intent:'opener',phrase:'来，认真打一把',
    tick:frame.observation.tick,submittedAt:Date.now()}
  fs.writeFileSync(path.join(directory,'live-feedback.jsonl'),JSON.stringify(teaching)+'\n')
  const result=await until(row=>row.feedbackStatus&&row.teacher==='WaveJerry')
  assert(result.message.includes('已学到'),result.message)
  const adapter=JSON.parse(fs.readFileSync(path.join(directory,'online-adapter.json'),'utf8'))
  assert.equal(adapter.revision,1)
  assert(adapter.chatWeights.some(value=>value!==0))
  console.log(JSON.stringify({pass:true,revision:adapter.revision,
    adapterBytes:fs.statSync(path.join(directory,'online-adapter.json')).size}))
}finally{
  child.kill()
  if(child.exitCode===null)await new Promise(resolve=>child.once('exit',resolve))
  assert(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep))
  assert(path.basename(directory).startsWith('wavedog-live-online-'))
  fs.rmSync(directory,{recursive:true,force:true})
}
