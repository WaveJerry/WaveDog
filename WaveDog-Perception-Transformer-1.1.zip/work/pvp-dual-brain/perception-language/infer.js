import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {PerceptionTransformer} from './model.js'
import {INTENTS,frame,persona,pvpFromDual,toTensors,speak} from './dialogue.js'

export class DialogueEngine {
  constructor(checkpoint){
    const saved=typeof checkpoint==='string'?JSON.parse(fs.readFileSync(checkpoint,'utf8')):checkpoint
    this.model=new PerceptionTransformer(saved.classes,saved.config)
    this.model.restore(saved)
    this.sessions=new Map()
  }
  reset(speaker){this.sessions.delete(speaker)}
  decide({speaker,sonVector,pvpVector=null,pvp=null,events={},chatBias=null,now=Date.now(),rng=Math.random}){
    if(!speaker)throw Error('speaker required')
    let session=this.sessions.get(speaker)
    if(!session){session={history:[],lastAt:0,lastIntent:null,lastText:null};this.sessions.set(speaker,session)}
    const row=frame({sonVector,pvpVector:pvpVector||pvpFromDual(pvp||{}),events})
    session.history.push(row);if(session.history.length>8)session.history.shift()
    const input=toTensors([{history:session.history,persona:persona(speaker)}])
    const probabilities=tf.tidy(()=>{
      const logits=this.model.logits(input)
      const adjusted=chatBias?tf.add(logits,tf.tensor2d([chatBias])):logits
      return [...tf.softmax(adjusted).dataSync()]
    })
    for(const tensor of Object.values(input))tensor.dispose()
    const ranked=INTENTS.map((intent,i)=>({intent,p:probabilities[i]})).sort((a,b)=>b.p-a.p)
    for(const option of ranked){
      if(option.intent==='silence'||option.p<.25)break
      const text=speak(option.intent,events,session,now,rng)
      if(text)return {speaker,intent:option.intent,text,probability:option.p,
        provenance:'public-pvp-events',said:true}
    }
    return {speaker,intent:'silence',text:null,probability:probabilities[0],said:false}
  }
  dispose(){this.model.dispose()}
}

if(process.argv[1]&&import.meta.url===new URL('file:///'+process.argv[1].replaceAll('\\','/')).href){
  await tf.setBackend('cpu');await tf.ready()
  const checkpoint=process.argv[2]||path.resolve('outputs/pvp-perception-language/checkpoint.json')
  const engine=new DialogueEngine(checkpoint)
  for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
    try{process.stdout.write(JSON.stringify(engine.decide(JSON.parse(line)))+'\n')}
    catch(error){process.stdout.write(JSON.stringify({error:String(error)})+'\n')}
  }
  engine.dispose()
}
