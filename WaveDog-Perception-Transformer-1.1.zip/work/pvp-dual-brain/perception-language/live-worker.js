import readline from 'node:readline'
import fs from 'node:fs'
import path from 'node:path'
import {Worker} from 'node:worker_threads'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {DialogueEngine} from './infer.js'
import {INTENTS,canSpeak,persona,pvpFromDual} from './dialogue.js'
import {applyAdapter,baseHash,chatBias,intentName} from './online-adapter.js'

await tf.setBackend('cpu');await tf.ready()
const checkpoint=path.resolve(process.argv[2])
const directory=path.dirname(checkpoint),hash=baseHash(checkpoint)
const adapterPath=path.join(directory,'online-adapter.json')
const feedbackPath=path.join(directory,'live-feedback.jsonl')
const examplesPath=path.join(directory,'online-examples.jsonl')
const cursorPath=path.join(directory,'live-feedback.cursor')
const chatPath=path.join(directory,'player-chat.jsonl')
const chatCursorPath=path.join(directory,'player-chat.cursor')
const engine=new DialogueEngine(checkpoint)
let onlineAdapter=fs.existsSync(adapterPath)?JSON.parse(fs.readFileSync(adapterPath,'utf8')):null
if(onlineAdapter)applyAdapter(engine.model,onlineAdapter,hash)
const actors=new Map(),emit=row=>process.stdout.write(JSON.stringify(row)+'\n')
const pendingFeedback=new Map()
const trainer=new Worker(new URL('./online-trainer.js',import.meta.url),
  {workerData:{checkpoint,adapter:adapterPath,examples:examplesPath}})
trainer.on('message',row=>{
  if(row.ready){emit({trainingReady:true,revision:row.revision});return}
  const original=pendingFeedback.get(row.id)
  if(!original)return
  pendingFeedback.delete(row.id)
  if(row.error){emit({feedbackStatus:true,teacher:original.teacher,message:'教学未生效：'+row.error});return}
  if(row.trained){
    try{applyAdapter(engine.model,row.adapter,hash);onlineAdapter=row.adapter}
    catch(error){emit({error:'Online adapter rejected: '+String(error)});return}
    emit({feedbackStatus:true,teacher:original.teacher,
      message:`${original.speaker} 已学到这条示范（第 ${row.revision} 次更新）。`})
  }
})
trainer.on('error',error=>emit({error:'Online trainer: '+String(error)}))
let cursor=Number(fs.existsSync(cursorPath)?fs.readFileSync(cursorPath,'utf8'):0)||0
let chatCursor=Number(fs.existsSync(chatCursorPath)?fs.readFileSync(chatCursorPath,'utf8'):0)||0
function pollChat(){
  if(!fs.existsSync(chatPath))return
  const size=fs.statSync(chatPath).size
  if(size<chatCursor)chatCursor=0
  const length=Math.min(size-chatCursor,1024*1024)
  if(length<=0)return
  const bytes=Buffer.alloc(length),file=fs.openSync(chatPath,'r')
  try{fs.readSync(file,bytes,0,length,chatCursor)}finally{fs.closeSync(file)}
  const last=bytes.lastIndexOf(10)
  if(last<0)return
  for(const line of bytes.subarray(0,last+1).toString('utf8').trimEnd().split('\n')){
    try{
      const row=JSON.parse(line),actor=actors.get(row.speaker)
      if(actor&&actor.matchId===row.matchId&&typeof row.text==='string'
        &&row.text.length<=160&&Number.isFinite(row.tick))
        actor.lastChat={text:row.text,tick:row.tick,player:row.player}
    }catch(error){emit({error:'Invalid duel chat record: '+String(error)})}
  }
  chatCursor+=last+1
  fs.writeFileSync(chatCursorPath,String(chatCursor))
}
function pollFeedback(){
  if(!fs.existsSync(feedbackPath))return
  const size=fs.statSync(feedbackPath).size
  if(size<cursor)cursor=0
  const length=Math.min(size-cursor,1024*1024)
  if(length<=0)return
  const bytes=Buffer.alloc(length),file=fs.openSync(feedbackPath,'r')
  try{fs.readSync(file,bytes,0,length,cursor)}finally{fs.closeSync(file)}
  const last=bytes.lastIndexOf(10)
  if(last<0)return
  const rows=bytes.subarray(0,last+1).toString('utf8').trimEnd().split('\n')
  for(const line of rows){
    try{
      const row=JSON.parse(line),actor=actors.get(row.speaker)
      if(!actor||actor.matchId!==row.matchId||!Array.isArray(actor.states))
        throw Error('duel context is no longer available')
      const intent=intentName(row.intent)
      if(!intent)throw Error('unknown intent '+row.intent)
      const phrase=String(row.phrase||'')
      if(intent!=='silence'&&(!phrase||phrase.length>40||/[\r\n\u0000-\u001f]/u.test(phrase)))
        throw Error('phrase must be 1–40 characters on one line')
      const state=[...actor.states].reverse().find(s=>s.tick<=row.tick
        &&row.tick-s.tick<=100&&canSpeak(intent,s.events))
      if(!state)throw Error('no matching verified PvP event in the last five seconds')
      const chatText=actor.lastChat&&row.tick-actor.lastChat.tick>=0
        &&row.tick-actor.lastChat.tick<=160?actor.lastChat.text:''
      const sample={id:row.id,history:state.history,persona:persona(row.speaker),
        label:INTENTS.indexOf(intent),phrase:intent==='silence'?'':phrase,chatText}
      pendingFeedback.set(row.id,{teacher:row.teacher,speaker:row.speaker})
      fs.appendFileSync(examplesPath,JSON.stringify(sample)+'\n')
    }catch(error){
      try{const row=JSON.parse(line);emit({feedbackStatus:true,teacher:row.teacher,
        message:'教学未生效：'+String(error.message||error).slice(0,120)})}
      catch{emit({error:'Invalid teaching record'})}
    }
  }
  cursor+=last+1
  fs.writeFileSync(cursorPath,String(cursor))
}
setInterval(()=>{try{pollFeedback()}catch(error){emit({error:'Teaching input: '+String(error)})}},500).unref()
setInterval(()=>{try{pollChat()}catch(error){emit({error:'Duel chat input: '+String(error)})}},500).unref()
emit({ready:true,model:'WaveDog-PvP-Perception-v1'})
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
  try{
    const input=JSON.parse(line),{speaker,matchId}=input
    if(!speaker||!matchId||!input.frame)continue
    let actor=actors.get(speaker)
    if(!actor||actor.matchId!==matchId){
      engine.reset(speaker)
      actor={matchId,first:true,previous:null,recentHits:[],lastVector:null,lastPvp:null,states:[],lastChat:null}
      actors.set(speaker,actor)
    }
    const f=input.frame
    f.tick=Number(f.observation?.tick)
    if(!Number.isFinite(f.tick))continue
    const damage=(f.nativeEvents||[]).filter(e=>e.type==='damage'&&!e.cancelled&&e.amount>0)
    if(damage.some(e=>e.attacker===speaker)&&actor.recentHits.at(-1)!==f.tick)
      actor.recentHits.push(f.tick)
    actor.recentHits=actor.recentHits.filter(tick=>f.tick-tick<=30)
    const enemyHit=damage.find(e=>e.victim===speaker&&e.weapon!=='end_crystal')
    const previous=input.kind==='prepare'?null:actor.previous
    const retreat=previous&&f.seen?.visible&&previous.seen?.visible
      &&f.tick-previous.tick>=2&&f.tick-previous.tick<=20
      &&Math.hypot(f.seen.x-previous.seen.x,f.seen.z-previous.seen.z)>.75
      &&f.observation.distance-previous.observation.distance>.7&&!damage.length
    const events=input.kind==='prepare'?{boutStart:true,quiet:true}:input.kind==='end'
      ?{boutEnd:true,won:input.winner===speaker,lost:Boolean(input.winner&&input.winner!==speaker)}
      :{boutStart:actor.first,enemyRetreat:Boolean(retreat),
        enemyCrystalHit:damage.some(e=>e.weapon==='end_crystal'&&e.victim===speaker),
        ownCrystalHit:damage.some(e=>e.weapon==='end_crystal'&&e.attacker===speaker),
        enemyBowHit:Boolean(enemyHit&&!enemyHit.melee
          &&['bow','crossbow'].includes(f.observation.targetShotWeapon)),
        enemyMaceHit:Boolean(enemyHit?.melee&&f.seen.held==='MACE'),
        ownCombo:actor.recentHits.length>=2,ownLowHealth:f.self.health<=6,
        enemyShield:Boolean(f.observation.targetShieldRaised)}
    const son=nativeObservation(f,{})
    const actions=f.neuralFallback?.proposal?.actions
    const pvp=pvpFromDual(actions?{actions}:{})
    actor.lastVector=son;actor.lastPvp=pvp;actor.first=false
    if(input.kind==='prepare')actor.previous=null
    else if(!previous||f.tick-previous.tick>=8)actor.previous=f
    const chatText=actor.lastChat&&f.tick-actor.lastChat.tick>=0
      &&f.tick-actor.lastChat.tick<=160?actor.lastChat.text:''
    const result=engine.decide({speaker,sonVector:son,pvpVector:pvp,events,
      chatBias:chatText?chatBias(onlineAdapter,chatText):null})
    const history=engine.sessions.get(speaker)?.history
    if(history){
      actor.states.push({tick:f.tick,events,history:structuredClone(history)})
      actor.states=actor.states.filter(state=>f.tick-state.tick<=100)
    }
    if(result.said)emit({speaker,matchId,kind:input.kind||'frame',intent:result.intent,text:result.text})
  }catch(error){emit({error:String(error).slice(0,300)})}
}
engine.dispose()
