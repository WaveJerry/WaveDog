import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {PerceptionTransformer} from './model.js'
import {INTENTS,PHRASES,frame,pvpFromDual,persona,toTensors,speak} from './dialogue.js'

await tf.setBackend('cpu');await tf.ready()
const model=new PerceptionTransformer(INTENTS.length,{width:64,layers:2,heads:4})
const son=Array(98).fill(0),pvp=pvpFromDual({actions:[0,0,0,0,0,1,0,0,0]})
assert.equal(pvp.length,367)
const sample={history:[frame({sonVector:son,pvpVector:pvp,events:{enemyBowHit:true}})],
  persona:persona('WaveDogSon')}
const input=toTensors([sample])
const logits=model.logits(input)
assert.deepEqual(logits.shape,[1,INTENTS.length])
assert.equal(speak('nice_bow',{}, {},Date.now(),()=>0),null)
assert.equal(speak('nice_bow',{enemyBowHit:true},{},Date.now(),()=>0),'好弓箭')
assert.equal(speak('gg_win',{boutEnd:true,lost:true},{},Date.now(),()=>0),null)
assert.equal(speak('tilt',{enemyRetreat:true,ownLowHealth:true},{},Date.now(),()=>0),'LL')
assert.equal(speak('gg_win',{boutEnd:true,won:true},{},Date.now(),()=>.58),'ez')
assert.equal(speak('clutch',{}, {},Date.now(),()=>.4),null)
assert.equal(speak('clutch',{ownLowHealth:true},{},Date.now(),()=>.4),'not even close')
const phrases=Object.values(PHRASES).flat()
assert.equal(phrases.length,112)
assert(phrases.every(text=>text.length<=40))
assert(!phrases.includes('鼠标失灵了？'))
assert(!phrases.includes('锚锚虫'))
assert(phrases.includes('弓狗')&&phrases.includes('跑男来了'))
assert(phrases.includes('也够')&&phrases.includes('野狗'))
assert(phrases.includes(':)')&&phrases.includes('：）'))
assert(phrases.includes('你跑尼玛个东方明珠塔跑'))
assert(!phrases.includes('卧槽颗秒了'))
const snapshot=model.snapshot(),restored=new PerceptionTransformer(INTENTS.length,snapshot.config)
restored.restore(snapshot)
const copied=restored.logits(input)
const a=[...logits.dataSync()],b=[...copied.dataSync()]
assert(a.every((value,i)=>Math.abs(value-b[i])<1e-5))
for(const tensor of Object.values(input))tensor.dispose()
logits.dispose();copied.dispose();model.dispose();restored.dispose()
process.stdout.write(JSON.stringify({pass:true,classes:INTENTS.length,checkpointRoundTrip:true,
  falsePraiseBlocked:true,insultRequiresContext:true})+'\n')
