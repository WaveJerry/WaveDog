'use strict'

// Placement, blast scoring and item use share the native world's current state.
function createFatherBrain(){
  function createState(){return {}}
  function decide(s,frame,probe,tick){
    const a=frame.self,b=frame.seen,o=frame.observation,arena=frame.crystalPractice
    const distance=Math.hypot(a.x-b.x,a.z-b.z)
    const sheltered=Boolean(arena.targetSheltered)
    const command={kind:'legacy86-ground',phase:'CRYSTAL',slot:0,forward:!arena.inArena||sheltered||distance<=2?0:1,
      side:0,sprint:!sheltered,jump:false,shield:false,attack:false,doubleAttack:false,keepTargetLook:true,crystal:{}}
    return {mode:'CRYSTAL',phase:'CRYSTAL',selectedBranch:sheltered?'father:wait-for-opening':'father:blast-control',command}
  }
  return {createState,reset(){},decide,receipt(){},applied(){},rangedApplied(){}}
}

module.exports={createFatherBrain}
