'use strict'
// Local Paper strategy adapted from the upstream wind-charge -> mace sequence.
// Commands are requests; SisterActions verifies stock, cooldown, fall and reach.
function createSisterBrain(){
  return {
    createState(opponent,name){return {opponent,name}},
    reset(){},
    decide(state,frame){
      const self=frame.self, seen=frame.seen, obs=frame.observation
      const kit=frame.macePractice||{}
      const horizontal=Math.hypot(seen.x-self.x,seen.z-self.z)
      const reach=Number(obs.reach)
      let action='approach'
      if(!self.ground&&self.fallDistance>=1.5&&reach<=3.1)action='slam'
      else if(self.ground&&kit.windCharges>0&&kit.windCooldown===0
          &&horizontal>=1.6&&horizontal<=6.5&&seen.visible)action='launch'
      else if(reach<=2.85&&Number(self.attackChargeAtHit)>=.8)action='melee'
      return {command:{sisterAction:action,attack:action==='slam'||action==='melee',kind:'native-sister-mace'},
        policy:'local-wind-mace-v1'}
    },
    receipt(){},applied(){},rangedApplied(){}
  }
}
module.exports={createSisterBrain}
