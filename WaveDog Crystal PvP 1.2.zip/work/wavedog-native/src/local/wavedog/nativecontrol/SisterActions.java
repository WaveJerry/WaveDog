package local.wavedog.nativecontrol;

import com.google.gson.JsonObject;
import java.util.*;
import net.minecraft.world.InteractionHand;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

/** Mace inputs only: inventory use, look, walking and vanilla player attack. */
final class SisterActions {
    private SisterActions(){}

    static Map<String,Object> observation(NativeControl.Actor a){
        Player p=a.player();ItemStack off=p.getInventory().getItemInOffHand();
        return Map.of("windCharges",off.getType()==Material.WIND_CHARGE?off.getAmount():0,
            "windCooldown",p.getCooldown(Material.WIND_CHARGE),"lastWindTick",a.lastWindTick,
            "maceReady",p.getInventory().getItemInMainHand().getType()==Material.MACE,
            "fallDistance",p.getFallDistance());
    }

    private static float toward(float now,float goal,float limit){
        float delta=(goal-now+540)%360-180;
        return now+Math.clamp(delta,-limit,limit);
    }

    static void aimBounded(NativeControl.Actor a,Player target){
        int tick=Bukkit.getCurrentTick();if(a.lastAimTick==tick)return;
        Player p=a.player();var eye=p.getEyeLocation();var box=target.getBoundingBox();
        double x=Math.clamp(eye.getX(),box.getMinX()+1e-7,box.getMaxX()-1e-7);
        double y=Math.clamp(eye.getY(),box.getMinY()+1e-7,box.getMaxY()-1e-7);
        double z=Math.clamp(eye.getZ(),box.getMinZ()+1e-7,box.getMaxZ()-1e-7);
        var direction=new Vector(x-eye.getX(),y-eye.getY(),z-eye.getZ());
        if(direction.lengthSquared()<1e-8)return;
        var aim=eye.clone().setDirection(direction);
        p.setRotation(toward(p.getYaw(),aim.getYaw(),45),
            Math.clamp(aim.getPitch(),p.getPitch()-45,p.getPitch()+45));
        a.lastAimTick=tick;
    }

    static Map<String,Object> execute(NativeControl owner,NativeControl.Actor a,Player target,JsonObject command,int tick){
        Player p=a.player();var handle=a.handle;
        String action=NativeControl.string(command,"sisterAction","approach");
        var actual=new LinkedHashMap<String,Object>();
        actual.put("action",action);actual.put("windUsed",false);actual.put("attacked",false);
        handle.setJumping(false);p.setSneaking(false);
        if(p.hasActiveItem())handle.stopUsingItem();
        if(action.equals("launch")&&p.isOnGround()&&tick-a.lastWindTick>=10
            &&p.getCooldown(Material.WIND_CHARGE)==0
            &&p.getInventory().getItemInOffHand().getType()==Material.WIND_CHARGE){
            p.setSprinting(false);
            if(a.lastAimTick!=tick){p.setRotation(p.getYaw(),Math.min(90,p.getPitch()+45));a.lastAimTick=tick;}
            if(p.getPitch()>=89.9){
                int before=p.getInventory().getItemInOffHand().getAmount();
                handle.gameMode.useItem(handle,handle.level(),handle.getOffhandItem(),InteractionHand.OFF_HAND);
                ItemStack after=p.getInventory().getItemInOffHand();
                boolean used=after.getType()!=Material.WIND_CHARGE||after.getAmount()<before;
                actual.put("windUsed",used);actual.put("windBefore",before);
                actual.put("windAfter",after.getType()==Material.WIND_CHARGE?after.getAmount():0);
                if(used)a.lastWindTick=tick;
            }
        }else aimBounded(a,target);
        double dx=target.getX()-p.getX(),dz=target.getZ()-p.getZ();
        double distance=Math.hypot(dx,dz),yaw=Math.toRadians(p.getYaw());
        double forward=0,side=0;
        if(!action.equals("launch")&&distance>.7){
            double hx=dx/distance,hz=dz/distance;
            forward=-Math.sin(yaw)*hx+Math.cos(yaw)*hz;
            side=Math.cos(yaw)*hx+Math.sin(yaw)*hz;
        }
        boolean sprint=p.isOnGround()&&distance>3&&p.getFoodLevel()>6&&forward>.5;
        p.setSprinting(sprint);
        if((action.equals("slam")&&p.getFallDistance()>=1.5&&!p.isOnGround()||action.equals("melee"))
            &&p.getInventory().getItemInMainHand().getType()==Material.MACE
            &&p.getCooledAttackStrength(.5f)>=.7f&&a.lastDispatchTick!=tick){
            Map<String,Object> attack=owner.strike(a,target,command,tick);
            actual.put("attack",attack);actual.put("attacked",Boolean.TRUE.equals(attack.get("attempted")));
        }
        handle.zza=(float)Math.clamp(forward,-1,1)*.2f;
        handle.xxa=(float)Math.clamp(side,-1,1)*.2f;
        actual.put("held",p.getInventory().getHeldItemSlot());actual.put("windCooldown",p.getCooldown(Material.WIND_CHARGE));
        actual.put("fallDistance",p.getFallDistance());actual.put("sprint",p.isSprinting());
        actual.put("forward",handle.zza);actual.put("side",handle.xxa);
        actual.put("physicsTick",handle.lastPhysicsTick);
        return actual;
    }
}
