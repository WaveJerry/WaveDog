package local.wavedog.nativecontrol;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.*;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Candidate analysis and ordinary player interactions for Father. */
final class CrystalActions {
    private static final int FLOOR=221;
    private static final String TAG="wavedog-father-crystal";
    private static final Map<NativeControl.Actor,Bout> BOUTS=new WeakHashMap<>();
    private static final BlockFace[] SIDES={BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST};
    private static final BlockFace[] SUPPORTS={BlockFace.DOWN,BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST,BlockFace.UP};
    private static final double[][] TOP_AIMS={{.5,.5},{.12,.12},{.12,.88},{.88,.12},{.88,.88}};

    private static final class Bout {
        final String match;
        int decidedTick=-1,pearlUntil=-1,pearlRetry=-1,landedAt=-1;
        int blockedSince=-1,crystalUntil=-1;
        boolean landed,hold,reposition,pearlCrystal,backoff;
        boolean flankRoute;
        Vector route,blockedOpponent;
        Placement pearlPlacement;
        Block pendingAnchor,failedAnchor;
        int pendingUntil,retryAnchorAt;
        Bout(String match){this.match=match;}
    }
    private record Placement(Block base,Block cover,Block second,BlastDamage.Score score){
        Placement(Block base,Block cover,BlastDamage.Score score){this(base,cover,null,score);}
        double value(){return score.value()-(cover==null?0:.15)-(second==null?0:.25);}
    }
    private record Click(Location aim,BlockHitResult hit){}
    private record CrystalHit(EnderCrystal crystal,Location look,BlastDamage.Score score){}
    private record PearlLanding(Location position,int ticks){}
    private record PearlPlan(Location look,PearlLanding landing,Location opponent,Placement placement){}
    private record BlastThreat(Vec3 origin,boolean anchor,float damage){}

    private static boolean inside(Location p){
        return p.getWorld().getName().equals("world")&&p.getX()>=992&&p.getX()<1037
            &&p.getZ()>=992&&p.getZ()<1037&&p.getY()>=FLOOR&&p.getY()<225;
    }
    static Map<String,Object> observation(NativeControl.Actor actor){
        var p=actor.player();int totems=0;
        for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.TOTEM_OF_UNDYING)totems+=item.getAmount();
        return Map.of("inArena",inside(p.getLocation()),"anchorReady",anchorReady(actor),"totems",totems);
    }
    private static boolean anchorReady(NativeControl.Actor actor){
        var p=actor.player();return amount(p,5,Material.RESPAWN_ANCHOR)>0&&amount(p,6,Material.GLOWSTONE)>0
            &&!RespawnAnchorBlock.canSetSpawn(actor.handle.level(),position(p.getLocation().getBlock()));
    }
    private static Vector anchorRoute(Player player,Player opponent){
        var at=player.getLocation();var toward=opponent.getLocation().toVector().subtract(at.toVector()).setY(0);
        double distance=toward.length();if(distance>5||distance<.001)return toward;
        toward.multiply(1/distance);
        var center=new Vector(1014.5-at.getX(),0,1014.5-at.getZ());
        var side=toward.clone().rotateAroundY(Math.PI/2);
        if(side.dot(center)<0)side.multiply(-1);
        return toward.multiply(Math.clamp(distance-3.8,-.75,.65)).add(side.multiply(.9)).normalize();
    }

    static void pearlLanded(NativeControl.Actor actor){
        Bout bout=BOUTS.get(actor);
        if(bout!=null&&Objects.equals(bout.match,actor.match)&&bout.pearlUntil>=0){
            bout.landed=true;bout.landedAt=Bukkit.getCurrentTick();bout.pearlUntil=-1;
        }
    }

    static boolean equipTotem(Player player){
        var inventory=player.getInventory();
        if(!inventory.getItemInOffHand().getType().isAir())return false;
        int slot=inventory.first(Material.TOTEM_OF_UNDYING);
        if(slot<0)return false;
        var totem=inventory.getItem(slot);
        inventory.setItem(slot,null);inventory.setItemInOffHand(totem);
        return true;
    }

    private static Vec3 center(Block block,double y){return new Vec3(block.getX()+.5,block.getY()+y,block.getZ()+.5);}
    private static List<Integer> coordinates(Block block){return block==null?List.of():List.of(block.getX(),block.getY(),block.getZ());}
    private static boolean emptyPlacement(Block block){
        if(!inside(block.getLocation())||!block.getType().isAir())return false;
        return block.getWorld().getNearbyEntities(new org.bukkit.util.BoundingBox(block.getX(),block.getY(),block.getZ(),
            block.getX()+1,block.getY()+1,block.getZ()+1),e->e instanceof LivingEntity||e instanceof EnderCrystal).isEmpty();
    }
    private static boolean canPlace(Block block){
        return block.getRelative(BlockFace.DOWN).getType().isSolid()&&emptyPlacement(block);
    }
    private static double range(Player player){return Objects.requireNonNull(player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE)).getValue();}
    private static Click aimBlock(Player player,Block block,boolean top){
        return aimBlock(player.getEyeLocation(),range(player),block,top,null);
    }
    private static Click aimBlock(Location eye,double range,Block block,boolean top,Block cover){
        if(!top){
            var side=aimBlock(eye,range,block,.5,.5,.5,false,cover);
            if(side!=null)return side;
        }
        for(var offset:TOP_AIMS){
            var click=aimBlock(eye,range,block,offset[0],.999,offset[1],top,cover);
            if(click!=null)return click;
        }
        return null;
    }
    private static Click aimBlock(Location eye,double range,Block block,double x,double y,double z,boolean top,Block cover){
        var spot=block.getLocation().add(x,y,z);
        if(cover!=null&&blocksRay(eye,cover,new Vec3(spot.getX(),spot.getY(),spot.getZ())))return null;
        var aim=eye.clone().setDirection(spot.toVector().subtract(eye.toVector()));
        var hit=eye.getWorld().rayTraceBlocks(eye,aim.getDirection(),range,FluidCollisionMode.NEVER,true);
        if(hit==null||!block.equals(hit.getHitBlock())||top&&hit.getHitBlockFace()!=BlockFace.UP)return null;
        var at=hit.getHitPosition();var face=hit.getHitBlockFace();
        var faceNms=Direction.valueOf(face.name());
        return new Click(aim,new BlockHitResult(new Vec3(at.getX(),at.getY(),at.getZ()),faceNms,position(block),false));
    }
    private static Click placementClick(Location eye,double reach,Block cell,Block cover,Block second){
        for(BlockFace side:SUPPORTS){
            Block support=cell.getRelative(side);
            if(!support.getType().isSolid()||support.getType()==Material.RESPAWN_ANCHOR)continue;
            var face=side.getOppositeFace();
            for(var sample:TOP_AIMS){
                double x=side.getModX()!=0?.5-side.getModX()*.499:sample[0];
                double y=side.getModY()!=0?.5-side.getModY()*.499:sample[1];
                double z=side.getModZ()!=0?.5-side.getModZ()*.499:side.getModX()!=0?sample[0]:sample[1];
                if(second!=null&&blocksRay(eye,second,new Vec3(support.getX()+x,support.getY()+y,support.getZ()+z)))continue;
                var click=aimBlock(eye,reach,support,x,y,z,false,cover);
                if(click!=null&&click.hit().getDirection().name().equals(face.name()))return click;
            }
        }
        return null;
    }
    private static boolean place(NativeControl.Actor actor,int slot,Material material,Block cell){
        Player player=actor.player();
        return emptyPlacement(cell)&&click(actor,slot,material,
            placementClick(player.getEyeLocation(),range(player),cell,null,null))==1&&cell.getType()==material;
    }
    private static BlockPos position(Block b){return new BlockPos(b.getX(),b.getY(),b.getZ());}
    private static Vec3 eye(Player player){var l=player.getEyeLocation();return new Vec3(l.getX(),l.getY(),l.getZ());}
    private static boolean blocksRay(Location start,Block cover,Vec3 target){
        var cube=BlastDamage.cube(cover);var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        return cube.contains(eye)||cube.clip(eye,target).isPresent();
    }
    private static int amount(Player player,int slot,Material expected){
        var item=player.getInventory().getItem(slot);
        return item!=null&&item.getType()==expected?item.getAmount():0;
    }
    private static int click(NativeControl.Actor actor,int slot,Material material,Block block,boolean top){
        return click(actor,slot,material,aimBlock(actor.player(),block,top));
    }
    private static int click(NativeControl.Actor actor,int slot,Material material,Click aim){
        Player player=actor.player();var inv=player.getInventory();int before=amount(player,slot,material);
        if(aim==null||before==0||player.getGameMode()!=GameMode.SURVIVAL||player.hasCooldown(material))return 0;
        int previous=inv.getHeldItemSlot();inv.setHeldItemSlot(slot);player.setRotation(aim.aim().getYaw(),aim.aim().getPitch());
        try{actor.handle.gameMode.useItemOn(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND,aim.hit());}
        finally{inv.setHeldItemSlot(previous);}
        return before-amount(player,slot,material);
    }

    private static Placement select(Player player,Player opponent,boolean anchor){
        return select(player,opponent,anchor,player.getLocation(),opponent.getLocation(),null);
    }
    private static Placement select(Player player,Player opponent,boolean anchor,Location own,Location enemy,Placement planned){
        return select(player,opponent,anchor,own,enemy,planned,null);
    }
    private static Placement select(Player player,Player opponent,boolean anchor,Location own,Location enemy,
                                    Placement planned,Block excluded){
        var origin=planned==null?enemy.getBlock():planned.base();var world=player.getWorld();
        var start=own.clone().add(0,player.getEyeHeight(),0);var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        var projected=player.getBoundingBox().clone().shift(own.toVector().subtract(player.getLocation().toVector()));
        var enemyBox=opponent.getBoundingBox().clone().shift(enemy.toVector().subtract(opponent.getLocation().toVector()));
        double range=range(player),rangeSquared=range*range;Placement best=null,bare=null;
        boolean haveCover=amount(player,1,Material.OBSIDIAN)>0;
        int radius=planned==null?(anchor&&own.equals(player.getLocation())?2:1):0;
        // Elevated opponents can be blasted from a reachable supported base,
        // not only from the arena floor. The existing ray, entity and damage
        // checks still reject impossible or unsafe placements.
        int top=anchor?224:Math.min(223,Math.max(FLOOR,enemy.getBlockY()));
        int covers=amount(player,1,Material.OBSIDIAN);
        for(int y=FLOOR;y<=top;y++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
            var b=world.getBlockAt(origin.getX()+dx,y,origin.getZ()+dz);
            if(b.equals(excluded))continue;
            var support=b.getRelative(BlockFace.DOWN);
            boolean readyBase=!anchor&&(b.getType()==Material.OBSIDIAN||b.getType()==Material.BEDROCK);
            if(!inside(b.getLocation()))continue;
            if(anchor){
                if(eye.distanceToSqr(center(b,.5))>(range+1)*(range+1)||!b.getType().isAir()
                    ||projected.overlaps(BoundingBox.of(b))||enemyBox.overlaps(BoundingBox.of(b))
                    ||placementClick(start,range,b,null,null)==null||!emptyPlacement(b))continue;
            }else{
                if(eye.distanceToSqr(center(b,0))>rangeSquared)continue;
                if(!readyBase&&(!canPlace(b)||projected.overlaps(BoundingBox.of(b))||enemyBox.overlaps(BoundingBox.of(b))
                    ||aimBlock(start,range,support,true,null)==null))continue;
            }
            if(!anchor){
                var spawn=b.getRelative(BlockFace.UP);
                var c=BlastDamage.cube(spawn).expandTowards(0,1,0);
                var box=new org.bukkit.util.BoundingBox(c.minX,c.minY,c.minZ,c.maxX,c.maxY,c.maxZ);
                var crystalBox=new AABB(c.minX-.5,c.minY,c.minZ-.5,c.maxX+.5,c.maxY,c.maxZ+.5);
                var exposed=crystalBox.clip(eye,crystalBox.getCenter());
                if(!spawn.getType().isAir()||!world.getNearbyEntities(box).isEmpty()
                    ||(!crystalBox.contains(eye)&&(exposed.isEmpty()||eye.distanceToSqr(exposed.get())>9))
                    ||(readyBase&&aimBlock(start,range,b,false,null)==null)||(!readyBase&&amount(player,1,Material.OBSIDIAN)==0))continue;
                var score=BlastDamage.estimate(player,opponent,center(b,1),false,readyBase?null:b,own,enemy);
                if(score.worthwhile(player)&&(best==null||score.value()>best.score().value()))best=new Placement(b,null,score);
                continue;
            }
            var blast=center(b,.5);
            var uncovered=BlastDamage.estimate(player,opponent,blast,true,null,own,enemy);
            if((planned==null||planned.cover()==null)&&canBlastWithoutCover(player,uncovered)
                &&(bare==null||uncovered.value()>bare.score().value()))bare=new Placement(b,null,uncovered);
            if(!haveCover||planned!=null&&planned.cover()==null)continue;
            var validCovers=new ArrayList<Block>(4);
            for(BlockFace side:SIDES){
                var cover=b.getRelative(side);
                if(planned!=null&&!cover.equals(planned.cover())&&!cover.equals(planned.second()))continue;
                if(!emptyPlacement(cover)||projected.overlaps(BoundingBox.of(cover))||enemyBox.overlaps(BoundingBox.of(cover))
                    ||placementClick(start,range,cover,null,null)==null
                    ||placementClick(start,range,b,cover,null)==null
                    ||blocksRay(start,cover,center(b,.999)))continue;
                var score=BlastDamage.estimate(player,opponent,blast,true,cover,own,enemy);
                var single=new Placement(b,cover,score);
                if(score.self()+.05f<uncovered.self()&&canBlastWithoutCover(player,score)
                    &&(best==null||single.value()>best.value()))best=single;
                if(covers>=2&&score.target()>=1&&score.self()>.08)for(Block previous:validCovers){
                    if(placementClick(start,range,cover,previous,null)==null
                        ||placementClick(start,range,b,previous,cover)==null)continue;
                    var combined=BlastDamage.estimate(player,opponent,blast,true,previous,cover,own,enemy);
                    var pair=new Placement(b,previous,cover,combined);
                    if(canBlastWithoutCover(player,combined)&&(best==null||pair.value()>best.value()))best=pair;
                }
                validCovers.add(cover);
            }
        }
        return best!=null&&(bare==null||best.value()>bare.value())?best:bare;
    }

    private static boolean canBlastWithoutCover(Player player,BlastDamage.Score score){
        return score.worthwhile(player);
    }

    private static boolean finishAnchor(NativeControl.Actor actor,Player opponent,Block anchor,Map<String,Object> receipt){
        Player player=actor.player();
        if(!(anchor.getBlockData() instanceof RespawnAnchor data))return false;
        var score=BlastDamage.estimate(player,opponent,center(anchor,.5),true,null);
        if(!canBlastWithoutCover(player,score))return false;
        if(data.getCharges()==0){
            if(click(actor,6,Material.GLOWSTONE,anchor,false)!=1)return false;
            receipt.put("glowstoneConsumed",1);
        }
        if(!(anchor.getBlockData() instanceof RespawnAnchor charged)||charged.getCharges()!=1)return false;
        score=BlastDamage.estimate(player,opponent,center(anchor,.5),true,null);
        if(!canBlastWithoutCover(player,score))return false;
        receipt.put("anchorDamage",Map.of("self",score.self(),"target",score.target(),"charge",1));
        click(actor,0,Material.NETHERITE_SWORD,anchor,false);
        if(anchor.getType()==Material.RESPAWN_ANCHOR)return false;
        receipt.put("anchorDetonated",true);return true;
    }

    private static CrystalHit scoreCrystal(Player player,Player opponent,EnderCrystal crystal){
        if(crystal.isDead()||NativeControl.reach(player,crystal)>3)return null;
        var at=crystal.getLocation();var score=BlastDamage.estimate(player,opponent,new Vec3(at.getX(),at.getY(),at.getZ()),false,null);
        if(!score.worthwhile(player))return null;
        Location start=player.getEyeLocation(),look=start.clone().setDirection(crystal.getBoundingBox().getCenter().subtract(start.toVector()));
        RayTraceResult ray=player.getWorld().rayTraceEntities(start,look.getDirection(),3,0,
            entity->entity!=player&&entity.isValid()&&(entity instanceof LivingEntity||entity instanceof EnderCrystal));
        if(ray==null||ray.getHitEntity()!=crystal)return null;
        var obstruction=player.getWorld().rayTraceBlocks(start,look.getDirection(),ray.getHitPosition().distance(start.toVector()),FluidCollisionMode.NEVER,true);
        return obstruction==null?new CrystalHit(crystal,look,score):null;
    }
    private static boolean hitCrystal(NativeControl.Actor actor,CrystalHit hit,int tick,Map<String,Object> receipt){
        if(hit==null||actor.lastDispatchTick==tick)return false;
        Player player=actor.player();actor.lastDispatchTick=tick;
        player.setRotation(hit.look().getYaw(),hit.look().getPitch());player.swingMainHand();player.attack(hit.crystal());
        receipt.put("crystalDamage",Map.of("self",hit.score().self(),"target",hit.score().target()));
        if(!hit.crystal().isDead()&&hit.crystal().isValid())return false;
        receipt.put("crystalStruck",true);return true;
    }

    private static PearlLanding predictPearl(NativeControl.Actor actor,Player opponent,Location look){
        var self=actor.player();var level=actor.handle.level();
        Vec3 start=eye(self).subtract(0,.1,0);
        var direction=look.getDirection();var momentum=actor.handle.getDeltaMovement();
        Vec3 speed=new Vec3(direction.getX(),direction.getY(),direction.getZ()).scale(1.5)
            .add(momentum.x,self.isOnGround()?0:momentum.y,momentum.z);
        var enemy=opponent.getBoundingBox();
        var target=new AABB(enemy.getMinX(),enemy.getMinY(),enemy.getMinZ(),enemy.getMaxX(),enemy.getMaxY(),enemy.getMaxZ()).inflate(.35);
        for(int tick=0;tick<12;tick++){
            speed=speed.subtract(0,.03,0);var end=start.add(speed);
            var hit=level.clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,actor.handle));
            if(target.contains(start)||target.clip(start,hit.getLocation()).isPresent())return null;
            if(hit.getType()!=HitResult.Type.MISS){
                var p=hit.getLocation();var landing=new Location(self.getWorld(),start.x,start.y,start.z);
                if(hit.getDirection()!=Direction.UP||p.y<FLOOR-.02||landing.getY()>FLOOR+1.45||!inside(landing)
                    ||!landing.getBlock().isPassable()||!landing.clone().add(0,1,0).getBlock().isPassable())return null;
                return new PearlLanding(landing,tick+1);
            }
            start=end;speed=speed.scale(.99);
        }
        return null;
    }
    private static Location projectOpponent(Player opponent,Vector velocity,int ticks){
        var handle=((CraftPlayer)opponent).getHandle();var at=opponent.getLocation();
        // Limit extrapolation over a pearl's flight. Recheck the accepted pose at impact.
        double horizon=Math.min(ticks,4);
        var travel=new Vec3(velocity.getX()*horizon,opponent.isOnGround()?0:velocity.getY()*horizon,velocity.getZ()*horizon);
        if(travel.lengthSqr()>2.25)travel=travel.normalize().scale(1.5);
        var valid=net.minecraft.world.entity.Entity.collideBoundingBox(handle,travel,handle.getBoundingBox(),handle.level(),List.of());
        var predicted=at.clone().add(valid.x,valid.y,valid.z);
        return inside(predicted)?predicted:at;
    }

    private static PearlPlan planPearl(NativeControl.Actor actor,Player opponent,Vector velocity,boolean anchor){
        Player player=actor.player();Location lookFrom=player.getEyeLocation(),self=player.getLocation(),enemy=opponent.getLocation();
        double dx=self.getX()-enemy.getX(),dz=self.getZ()-enemy.getZ(),n=Math.hypot(dx,dz);
        if(n<.01||n>9)return null;
        double ux=dx/n,uz=dz/n;
        var destination=n<4.3?self.clone().add(-uz*2,0,ux*2):enemy.clone().add(ux*3.3,0,uz*3.3);
        PearlPlan best=null;
        var destinations=new ArrayList<Location>();
        for(double lateral:n<4.3?new double[]{0,1.4,-1.4,2.8,-2.8,-4}:new double[]{0,1.4,-1.4,2.8,-2.8})
            destinations.add(destination.clone().add(-uz*lateral,0,ux*lateral));
        if(!anchor)for(int angle:new int[]{65,-65,115,-115,165})
            destinations.add(enemy.clone().add(new Vector(ux,0,uz).rotateAroundY(Math.toRadians(angle)).multiply(3.1)));
        for(var target:destinations){
            target.setY(FLOOR+.02);
            if(!inside(target))continue;
            var direction=target.toVector().subtract(lookFrom.toVector());if(direction.lengthSquared()<.5)continue;
            var look=lookFrom.clone().setDirection(direction);var landing=predictPearl(actor,opponent,look);
            if(landing==null)continue;
            var predicted=projectOpponent(opponent,velocity,landing.ticks());
            var placement=select(player,opponent,anchor,landing.position(),predicted,null);
            if(placement!=null&&predicted.distanceSquared(enemy)>.16
                &&select(player,opponent,anchor,landing.position(),enemy,placement)==null)continue;
            if(placement!=null&&(best==null||placement.score().value()>best.placement().score().value()))
                best=new PearlPlan(look,landing,predicted,placement);
        }
        return best;
    }

    private static BlastThreat blastThreat(Player player,Player opponent){
        var feet=opponent.getLocation().getBlock();
        var wielding=opponent.getInventory().getItemInMainHand().getType();
        boolean loading=wielding==Material.GLOWSTONE||opponent.getInventory().getItemInOffHand().getType()==Material.GLOWSTONE;
        BlastThreat best=null;
        var world=player.getWorld();
        var enemyEye=eye(opponent);
        double interaction=Math.pow(range(opponent)+.8,2);
        for(int dx=-3;dx<=3;dx++)for(int dz=-3;dz<=3;dz++)for(int y=FLOOR;y<=224;y++){
            var b=world.getBlockAt(feet.getX()+dx,y,feet.getZ()+dz);
            if(b.getType()!=Material.RESPAWN_ANCHOR||!(b.getBlockData() instanceof RespawnAnchor a)
                ||a.getCharges()==0&&!loading||!inside(b.getLocation()))continue;
            var point=center(b,.5);
            if(enemyEye.distanceToSqr(point)>interaction)continue;
            float damage=BlastDamage.exposureDamage(player,point,true,null);
            if(damage>=2.5&&(best==null||damage>best.damage()))best=new BlastThreat(point,true,damage);
        }
        for(var entity:opponent.getNearbyEntities(4,4,4))if(entity instanceof EnderCrystal crystal&&NativeControl.reach(opponent,crystal)<=3){
            var at=crystal.getLocation();
            var point=new Vec3(at.getX(),at.getY(),at.getZ());
            float damage=BlastDamage.exposureDamage(player,point,false,null);
            if(damage>=2.5&&(best==null||damage>best.damage()))best=new BlastThreat(point,false,damage);
        }
        return best;
    }

    private static boolean defendBlast(NativeControl.Actor actor,BlastThreat threat,Map<String,Object> receipt){
        var player=actor.player();
        if(threat==null||amount(player,1,Material.OBSIDIAN)==0)return false;
        var at=player.getLocation();
        var start=player.getEyeLocation();
        var ownBox=player.getBoundingBox();
        var direction=new Vector(threat.origin().x-at.getX(),0,threat.origin().z-at.getZ());
        if(direction.lengthSquared()<.2)return false;
        direction.normalize();
        var candidates=new LinkedHashSet<Block>();
        for(double distance:new double[]{.8,1.25,1.7})for(double side:new double[]{0,.5,-.5}){
            var cell=at.clone().add(direction.clone().multiply(distance))
                .add(direction.clone().rotateAroundY(Math.PI/2).multiply(side)).getBlock();
            candidates.add(cell);
            candidates.add(cell.getRelative(BlockFace.UP));
        }
        Block best=null;
        float remaining=threat.damage()-1.25f;
        for(var cell:candidates){
            if(ownBox.overlaps(BoundingBox.of(cell))||!emptyPlacement(cell)||
                placementClick(start,range(player),cell,null,null)==null)continue;
            float damage=BlastDamage.exposureDamage(player,threat.origin(),threat.anchor(),cell);
            if(damage<remaining){remaining=damage;best=cell;}
        }
        if(best==null)return false;
        UhcTools.stopMining(actor);
        if(!place(actor,1,Material.OBSIDIAN,best))return false;
        receipt.put("defensiveCover",Map.of("block",coordinates(best),"before",threat.damage(),"after",remaining));
        receipt.put("obsidianConsumed",1);
        return true;
    }
    private static boolean throwPearl(NativeControl.Actor actor,PearlPlan plan){
        Player player=actor.player();
        int before=amount(player,7,Material.ENDER_PEARL);
        if(before==0||player.hasCooldown(Material.ENDER_PEARL))return false;
        var inventory=player.getInventory();int previous=inventory.getHeldItemSlot();
        inventory.setHeldItemSlot(7);player.setRotation(plan.look().getYaw(),plan.look().getPitch());
        try{actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND);}
        finally{inventory.setHeldItemSlot(previous);}
        return amount(player,7,Material.ENDER_PEARL)==before-1;
    }

    static Map<String,Object> execute(NativeControl.Actor actor,Player opponent,Vector velocity,int tick){
        Player player=actor.player();
        if(!inside(player.getLocation())||!inside(opponent.getLocation())||player.getGameMode()!=GameMode.SURVIVAL)return Map.of();
        Bout bout=BOUTS.get(actor);
        if(bout==null||!Objects.equals(bout.match,actor.match)){bout=new Bout(actor.match);BOUTS.put(actor,bout);}
        if(bout.decidedTick==tick){
            if(bout.hold)return Map.of("holdPosition",true);
            if(bout.reposition){var repeat=new LinkedHashMap<String,Object>();routeReceipt(bout,repeat);return repeat;}
            return anchorReady(actor)&&opponent.getY()-player.getY()<=.6?Map.of("anchorPriority",true):Map.of();
        }
        bout.decidedTick=tick;bout.hold=false;bout.reposition=false;
        var receipt=new LinkedHashMap<String,Object>();
        var inventory=player.getInventory();
        var offhand=inventory.getItemInOffHand();
        if(offhand.getType()==Material.GOLDEN_APPLE){
            if(player.hasActiveItem()&&player.getActiveItem().getType()==Material.GOLDEN_APPLE){
                receipt.put("appleEating",true);hold(bout,receipt);return receipt;
            }
            inventory.setItemInOffHand(inventory.getItem(4));inventory.setItem(4,offhand);
            receipt.put("appleFinished",true);
        }
        if(equipTotem(player))receipt.put("totemEquipped",true);
        double distance=player.getLocation().distanceSquared(opponent.getLocation());
        if(velocity!=null&&distance<=100&&tick%2==0&&
            (opponent.getInventory().getItemInMainHand().getType()!=Material.GOLDEN_APPLE||bout.blockedSince>=0)){
            if(defendBlast(actor,blastThreat(player,opponent),receipt)){hold(bout,receipt);return receipt;}
        }
        var apples=inventory.getItem(4);
        if(apples!=null&&apples.getType()==Material.GOLDEN_APPLE&&apples.getAmount()>0
            &&player.getAbsorptionAmount()<.5&&player.getFireTicks()<=0&&!player.isInLava()
            &&!player.hasActiveItem()&&!actor.handle.handActionLocked()
            &&(distance>=36||distance>=16&&!player.hasLineOfSight(opponent))){
            var saved=inventory.getItemInOffHand();
            inventory.setItem(4,saved);inventory.setItemInOffHand(apples);
            actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),InteractionHand.OFF_HAND);
            if(player.hasActiveItem()&&player.getActiveItem().getType()==Material.GOLDEN_APPLE){
                receipt.put("appleStarted",true);hold(bout,receipt);return receipt;
            }
            inventory.setItemInOffHand(saved);inventory.setItem(4,apples);
        }
        if(velocity==null)return receipt; // Allow apple upkeep without overriding a non-crystal combat order.
        boolean anchor=anchorReady(actor);
        boolean crystal=amount(player,2,Material.END_CRYSTAL)>0;
        if(bout.pendingAnchor!=null){
            if(tick<=bout.pendingUntil&&bout.pendingAnchor.getType()==Material.RESPAWN_ANCHOR){
                if(finishAnchor(actor,opponent,bout.pendingAnchor,receipt)){bout.pendingAnchor=null;bout.landed=false;}
                hold(bout,receipt);return receipt;
            }
            bout.pendingAnchor=null;
        }
        if(tick<=bout.pearlUntil){hold(bout,receipt);return receipt;}
        if(bout.pearlUntil>=0){bout.pearlUntil=-1;bout.pearlPlacement=null;receipt.put("pearlFlightExpired",true);}
        if(bout.landed&&bout.pearlCrystal){
            bout.crystalUntil=tick+12;receipt.put("crystalAfterPearl",true);
            bout.pearlCrystal=false;
        }
        if(bout.backoff&&bout.blockedOpponent!=null&&opponent.getLocation().toVector().distanceSquared(bout.blockedOpponent)>2.25){
            bout.backoff=false;bout.blockedSince=-1;
        }
        var current=anchor&&distance<=36?select(player,opponent,true,player.getLocation(),opponent.getLocation(),
            null,tick<bout.retryAnchorAt?bout.failedAnchor:null):null;
        if(distance<=81&&(anchor||crystal)&&current==null&&bout.blockedSince<0)bout.blockedSince=tick;
        int blocked=bout.blockedSince<0?0:tick-bout.blockedSince;
        var alternate=crystal&&distance<=36&&(current==null||tick<=bout.crystalUntil||opponent.getY()-player.getY()>.6)
            ?select(player,opponent,false):null;
        boolean useCrystal=alternate!=null&&(current==null||tick<=bout.crystalUntil||alternate.value()>current.value()+.5);
        if((current==null||useCrystal)&&distance<=36){
            var best=bestCrystal(player,opponent);
            if(hitCrystal(actor,best,tick,receipt)){
                crystalComplete(bout);receipt.put("crystalMode",true);hold(bout,receipt);return receipt;
            }
        }
        if(useCrystal){
            receipt.put("crystalMode",true);
            if(spawnCrystal(actor,opponent,alternate,tick,receipt)){crystalComplete(bout);hold(bout,receipt);return receipt;}
        }
        if(current==null&&distance<=81&&!bout.landed&&amount(player,7,Material.ENDER_PEARL)>0&&(anchor||crystal)){
            if(tick>=bout.pearlRetry&&!player.hasCooldown(Material.ENDER_PEARL)){
                bout.pearlRetry=tick+8;
                boolean flank=crystal&&(!anchor||blocked>=10);
                var plan=planPearl(actor,opponent,velocity,!flank);
                if(plan!=null&&throwPearl(actor,plan)){
                    bout.pearlUntil=tick+plan.landing().ticks()+4;bout.pearlRetry=tick;
                    bout.pearlPlacement=plan.placement();
                    bout.pearlCrystal=flank;
                    receipt.put("pearlThrown",true);
                    receipt.put("pearlMode",flank?"crystal":"anchor");
                    var landing=plan.landing().position();var enemy=plan.opponent();var base=plan.placement().base();var cover=plan.placement().cover();
                    receipt.put("pearlPlan",Map.of("landing",List.of(landing.getX(),landing.getY(),landing.getZ()),
                        "flightTicks",plan.landing().ticks(),"opponent",List.of(enemy.getX(),enemy.getY(),enemy.getZ()),
                        "anchor",coordinates(base),"cover",coordinates(cover),
                        "damage",Map.of("self",plan.placement().score().self(),"target",plan.placement().score().target())));
                    hold(bout,receipt);return receipt;
                }
            }
        }
        if(current!=null){
            receipt.put("anchorPriority",true);
            var remembered=bout.pearlPlacement;
            var plan=current;
            if(bout.landed&&remembered!=null)receipt.put("pearlPlanReused",plan!=null&&remembered.base().equals(plan.base())
                &&Objects.equals(remembered.cover(),plan.cover())&&Objects.equals(remembered.second(),plan.second()));
            bout.pearlPlacement=null;
            int placed=0;
            if(plan!=null&&plan.cover()!=null){
                if(place(actor,1,Material.OBSIDIAN,plan.cover())){
                    placed=1;
                    if(plan.second()!=null&&place(actor,1,Material.OBSIDIAN,plan.second()))placed++;
                    receipt.put("obsidianConsumed",placed);receipt.put("basePlaced",true);hold(bout,receipt);
                }else{
                    var score=BlastDamage.estimate(player,opponent,center(plan.base(),.5),true,null);
                    receipt.put("coverPlacementFailed",true);
                    plan=canBlastWithoutCover(player,score)?new Placement(plan.base(),null,score):null;
                }
            }
            if(plan==null){
                if(bout.blockedSince<0)bout.blockedSince=tick;
                reposition(bout,receipt,player,opponent,distance,blocked);return receipt;
            }
            var base=plan.base();
            if(!place(actor,5,Material.RESPAWN_ANCHOR,base)){
                bout.failedAnchor=base;bout.retryAnchorAt=tick+12;
                if(bout.blockedSince<0)bout.blockedSince=tick;
                receipt.put("anchorPlacementFailed",true);
                reposition(bout,receipt,player,opponent,distance,blocked);return receipt;
            }
            clearStall(bout);
            hold(bout,receipt);
            receipt.put("anchorConsumed",1);
            receipt.put("anchorPlacement",Map.of("anchor",coordinates(base),"cover",coordinates(plan.cover())));
            if(placed>1)receipt.put("secondCover",coordinates(plan.second()));
            bout.pendingAnchor=base;bout.pendingUntil=tick+4;
            if(finishAnchor(actor,opponent,base,receipt)){
                if(bout.landed)receipt.put("pearlLandingToBlastTicks",tick-bout.landedAt);
                bout.pendingAnchor=null;bout.landed=false;
            }
            return receipt;
        }
        if(bout.landed&&bout.pearlPlacement!=null){
            bout.pearlPlacement=null;receipt.put("pearlLandingPlanLost",true);
        }
        bout.landed=false;
        if(bout.backoff||(anchor||crystal)&&distance<=81)reposition(bout,receipt,player,opponent,distance,blocked);
        return receipt;
    }

    private static CrystalHit bestCrystal(Player player,Player opponent){
        CrystalHit best=null;
        for(Entity e:player.getNearbyEntities(3.5,3.5,3.5))if(e instanceof EnderCrystal crystal){
            var hit=scoreCrystal(player,opponent,crystal);
            if(hit!=null&&(best==null||hit.score().value()>best.score().value()))best=hit;
        }
        return best;
    }
    private static boolean spawnCrystal(NativeControl.Actor actor,Player opponent,Placement plan,int tick,Map<String,Object> receipt){
        var player=actor.player();
        var base=plan.base();
        if(base.getType().isAir()){
            if(click(actor,1,Material.OBSIDIAN,base.getRelative(BlockFace.DOWN),true)!=1)return false;
            receipt.put("basePlaced",true);receipt.put("obsidianConsumed",1);
        }
        if(click(actor,2,Material.END_CRYSTAL,base,false)==1){
            var at=base.getLocation().add(.5,1,.5);
            receipt.put("crystalSpawned",true);receipt.put("crystalConsumed",1);
            for(var entity:player.getWorld().getNearbyEntities(at,.25,.25,.25,e->e instanceof EnderCrystal)){
                entity.addScoreboardTag(TAG);hitCrystal(actor,scoreCrystal(player,opponent,(EnderCrystal)entity),tick,receipt);
            }
            return true;
        }
        return false;
    }

    private static void clearStall(Bout bout){
        bout.blockedSince=-1;bout.backoff=false;bout.blockedOpponent=null;
    }
    private static void crystalComplete(Bout bout){
        clearStall(bout);bout.landed=false;bout.pearlPlacement=null;
    }
    private static void reposition(Bout bout,Map<String,Object> receipt,Player player,Player opponent,double distance,int blocked){
        if(!bout.backoff&&blocked>=38){
            bout.backoff=true;bout.blockedOpponent=opponent.getLocation().toVector();
        }
        bout.reposition=true;bout.flankRoute=bout.backoff||blocked>=10;
        bout.route=bout.backoff&&distance>=64?new Vector():bout.flankRoute
            ?UhcTools.crystalReposition(player,opponent,bout.backoff,blocked/12):anchorRoute(player,opponent);
        routeReceipt(bout,receipt);
    }
    private static void routeReceipt(Bout bout,Map<String,Object> receipt){
        receipt.put("repositionForAnchor",true);receipt.put("anchorPriority",true);
        receipt.put("anchorHeading",List.of(bout.route.getX(),bout.route.getZ()));
        if(bout.flankRoute)receipt.put("crystalFlank",bout.backoff?"backoff":"flank");
    }
    private static void hold(Bout bout,Map<String,Object> receipt){bout.hold=true;receipt.put("holdPosition",true);}
}
