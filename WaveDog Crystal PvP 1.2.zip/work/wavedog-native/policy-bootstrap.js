'use strict'
// Run the existing, pinned Son policy in the server process. Only scheduling
// syntax is adapted; there is no second movement/attack controller.
globalThis.structuredClone ??= function clone(v){
  if(v===null||typeof v!=='object')return v
  if(Array.isArray(v))return v.map(clone)
  return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,clone(x)]))
}
const modules=new Map()
function load(name){
  const aliases={'../wavedog-protocol/ground-son-critical.cjs':'ground-son-critical.cjs'}
  name=aliases[name]||name.replace(/^\.\//,'')
  if(!name.endsWith('.js')&&!name.endsWith('.cjs'))name+='.js'
  if(modules.has(name))return modules.get(name).exports
  const module={exports:{}};modules.set(name,module)
  let source=String(nativeSource(name))
  if(name==='protocol-ground-son-brain.js'){
    if((source.match(/async reset\(s\)/g)||[]).length!==1
      ||(source.match(/async decide\(/g)||[]).length!==1||/\bawait\b/.test(source))
      throw Error('Son scheduling adapter requires review')
    source=source.replace('async reset(s)','reset(s)').replace('async decide(','decide(')
  }
  new Function('module','exports','require',source)(module,module.exports,load)
  return module.exports
}
const {createGroundBrain}=load('protocol-ground-son-brain')
const {createRouteProbe}=load('protocol-legacy86-route')
const {publicArrowThreat}=load('wavedog-arrow-predictor')
globalThis.nativeControlProfile=load('protocol-son-profile')
const brains=new Map()
function nativeReset(name,opponent){
  const selected=()=>globalThis.nativeFixtureLegacy===true?{axeSpacing:false,shieldScript:false}:nativeControlProfile
  const ground=()=>createGroundBrain({unifiedSon:true,criticalDefense:true,sideSteps:true,
    axeSpacing:selected().axeSpacing,shieldScript:selected().shieldScript,profile:selected})
  const prep=brain=>{const state=brain.createState(opponent,name);brain.reset(state);return {brain,state}}
  const primary=prep(name==='WaveDogSister'?load('protocol-sister-brain').createSisterBrain()
    :name==='WaveDogFather'?load('protocol-father-brain').createFatherBrain():ground())
  const sword=name==='WaveDogFather'?prep(ground()):null
  brains.set(name,{primary,sword,current:primary})
}
function nativeDecide(name,frameText){
  const own=brains.get(name),frame=JSON.parse(frameText)
  const fatherSword=Boolean(own.sword&&frame.crystalPractice?.swordOnly&&!frame.crystalPractice.targetSheltered)
  const next=fatherSword?own.sword:own.primary
  if(next===own.sword&&next!==own.current){
    next.state=next.brain.createState(next.state.opponent,name)
    next.brain.reset(next.state)
  }
  own.current=next
  const {brain,state}=next
  if(name==='WaveDogSister'||name==='WaveDogFather'&&!fatherSword)
    return JSON.stringify(brain.decide(state,frame,null,frame.observation.tick))
  const cache=new Map(),blockAt=(x,y,z)=>{
    const key=x+','+y+','+z
    if(!cache.has(key))cache.set(key,JSON.parse(String(nativeBlock(name,x,y,z))))
    return cache.get(key)
  }
  const probe=createRouteProbe({origin:frame.self,blockAt})
  const wall=(dx,dz)=>{
    for(const d of [.4,.8,1.2,1.5]){
      const p={...frame.self,x:frame.self.x+dx*d,z:frame.self.z+dz*d}
      if(!probe(p,frame.self).clear)return d
    }
    return 1.5
  }
  const clear=(a,b)=>Boolean(nativeClear(name,a.x,a.y,a.z,b.x,b.y,b.z))
  frame.observation.arrowThreat=publicArrowThreat(frame.seen.arrows,
    {...frame.self,entityId:frame.self.entityId},wall,clear,name==='WaveDogSon')
  const arrow=frame.seen.arrows.find(a=>a.id===frame.observation.arrowThreat?.id)
  if(arrow)frame.observation.arrowThreat.yaw=Math.atan2(-(arrow.x-frame.self.x),-(arrow.z-frame.self.z))
  const plan=brain.decide(state,frame,probe,frame.observation.tick)
  if(fatherSword){
    plan.selectedBranch='father:sword:'+plan.selectedBranch
    plan.command.fatherSword=true
  }
  return JSON.stringify(plan)
}
function nativeReceipt(name,text,tick){
  const own=brains.get(name)?.current;if(own)own.brain.receipt(own.state,JSON.parse(text),tick)
}
function nativeApplied(name,commandText,actualText,tick){
  const own=brains.get(name)?.current;if(!own)return
  const command=JSON.parse(commandText),actual=JSON.parse(actualText)
  own.brain.applied(own.state,command,actual,tick)
  own.brain.rangedApplied(own.state,command,actual.rangedResult||{},tick)
}
function nativeRangedAim(text){return JSON.stringify(load('protocol-ranged-aim').solveRangedAim(JSON.parse(text)))}
