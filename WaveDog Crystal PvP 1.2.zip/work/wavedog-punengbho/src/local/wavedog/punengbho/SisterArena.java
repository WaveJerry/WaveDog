package local.wavedog.punengbho;

import org.bukkit.*;
import org.bukkit.entity.Player;

/** Separate 96 by 96 elevated mace arena, built only by an operator command. */
final class SisterArena {
    static final int MIN=1152,MAX=1247,FLOOR=271,FEET=272,GLASS_TOP=279,ROOF=300;
    static final double CENTER=1199.5;
    private SisterArena(){}

    static String install(){
        World world=Bukkit.getWorld("world");
        if(world==null)throw new IllegalStateException("主世界未加载。");
        // Check the entire site first; never erase an existing build.
        for(int x=MIN;x<=MAX;x++)for(int z=MIN;z<=MAX;z++){
            var floor=world.getBlockAt(x,FLOOR,z).getType();
            if(floor!=Material.AIR&&floor!=Material.STONE)
                throw new IllegalStateException("上层竞技场地板位置被占用："+x+","+FLOOR+","+z);
            boolean edge=x==MIN||x==MAX||z==MIN||z==MAX;
            for(int y=FEET;y<=ROOF;y++){
                Material block=world.getBlockAt(x,y,z).getType();
                Material expected=y==ROOF||edge&&y>GLASS_TOP?Material.BARRIER:edge?Material.GLASS:Material.AIR;
                if(block!=Material.AIR&&block!=expected)
                    throw new IllegalStateException("上层竞技场空间被占用："+x+","+y+","+z);
            }
        }
        for(int x=MIN;x<=MAX;x++)for(int z=MIN;z<=MAX;z++){
            world.getBlockAt(x,FLOOR,z).setType(Material.STONE,false);
            if(x==MIN||x==MAX||z==MIN||z==MAX){
                for(int y=FEET;y<=GLASS_TOP;y++)world.getBlockAt(x,y,z).setType(Material.GLASS,false);
                for(int y=GLASS_TOP+1;y<ROOF;y++)world.getBlockAt(x,y,z).setType(Material.BARRIER,false);
            }
            world.getBlockAt(x,ROOF,z).setType(Material.BARRIER,false);
        }
        world.save();
        return "§bWaveDogSister 独立封闭竞技场已建造：世界 world，地面 Y="+FEET+"，96×96 格，玻璃下墙、屏障上墙与顶面 Y="+ROOF+"。";
    }

    static Location opponentStart(Location bot){
        return new Location(bot.getWorld(),2*CENTER-bot.getX(),FEET,2*CENTER-bot.getZ(),
            bot.getYaw()+180,0);
    }

    static Location startLocation(Player ignored){
        World world=Bukkit.getWorld("world");if(world==null)return null;
        int first=Math.floorMod(Bukkit.getCurrentTick()/20,4);
        for(int turn=0;turn<4;turn++){
            int side=(first+turn)%4;
            double x=CENTER+(side==0?-12:side==1?12:0);
            double z=CENTER+(side==2?-12:side==3?12:0);
            Location bot=new Location(world,x,FEET,z),human=opponentStart(bot);
            if(!safe(bot)||!safe(human))continue;
            bot.setYaw((float)Math.toDegrees(Math.atan2(-(human.getX()-x),human.getZ()-z)));
            return bot;
        }
        return null;
    }

    private static boolean safe(Location at){
        if(at.clone().add(0,-1,0).getBlock().getType()!=Material.STONE)return false;
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)for(int dy=0;dy<=3;dy++)
            if(!at.clone().add(dx,dy,dz).getBlock().getType().isAir())return false;
        return true;
    }

    static boolean contains(Location at){
        return at.getWorld()!=null&&at.getWorld().getName().equals("world")
            &&at.getX()>=MIN-1&&at.getX()<=MAX+1&&at.getZ()>=MIN-1&&at.getZ()<=MAX+1
            &&at.getY()>=FLOOR-1&&at.getY()<=ROOF+1;
    }
}
