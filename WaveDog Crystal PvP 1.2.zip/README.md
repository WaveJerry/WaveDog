# WaveDog Crystal PvP

这是 WaveDogFather 的服务端玩家版本，包含已编译的插件、竞技场入口、装备配置、控制源码和近身剑斗权重。支持合法的高层和侧面放锚，可根据爆炸暴露量放黑曜石减伤。锚缺乏有效伤害时检查水晶、珍珠换角和撤离。

## 安装

1. 使用 Windows x64、Paper 1.21.11、Java 21 和 Node.js。将本包解压到固定目录。
2. 在解压目录的 `work/pvp-dual-brain` 内运行 `npm ci --omit=dev`。
3. 服务器停止后，把包内 `plugins` 合并到目标服务器。使用与配置坐标一致的竞技场地图。
4. 在 Java 启动命令的 `-jar` 前加 `"-Dwavedog.workspace=解压目录的绝对路径"`、`"-Dwavedog.node=node.exe 的绝对路径"`。
5. 启动后用 `wdnative status` 和 `wdneural` 检查加载，再从竞技场按钮或 `/wavedogfather duel 玩家名` 进入。

语言模型由独立的 Tiny Language Transformer ZIP 提供。皮肤使用示例身份，可在目标服设置外观。公开包只包含插件及其运行依赖，世界存档须另行提供。
