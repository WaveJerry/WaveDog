# WaveDog Crystal PvP

这是 WaveDogFather 的服务端玩家版本，包含已编译的插件、竞技场入口、装备配置、控制源码和近身剑斗权重。重生锚和水晶使用同一伤害门槛。预计扣除至少 4 点有效血量或能打出致死伤害，且自身有利可存活，才执行爆炸。接战距离内没有高伤方案时，先尝试用黑曜石围起对手全身并封顶，再退至约 9 格。等待期间通过原版挖掘和拾取清理交战放置的方块，避开对手周围 7 格。遇到可挖且可到达的低处，逐块下挖。遇到基岩等不可挖方块时，走入附近最低的可达空位。竞技场原有地板保持受保护。出现新的高伤方案时恢复进攻。耗尽可用爆炸物后，使用 WaveDogBrother 的控距与 GRU＋Transformer 剑斗。

## 安装

1. 使用 Windows x64、Paper 1.21.11、Java 21 和 Node.js。将本包解压到固定目录。
2. 在解压目录的 `work/pvp-dual-brain` 内运行 `npm ci --omit=dev`。
3. 服务器停止后，把包内 `plugins` 合并到目标服务器。使用与配置坐标一致的竞技场地图。
4. 在 Java 启动命令的 `-jar` 前加 `"-Dwavedog.workspace=解压目录的绝对路径"`、`"-Dwavedog.node=node.exe 的绝对路径"`。
5. 启动后用 `wdnative status` 和 `wdneural` 检查加载，再从竞技场按钮或 `/wavedogfather duel 玩家名` 进入。

语言模型由独立的 Tiny Language Transformer ZIP 提供。皮肤使用示例身份，可在目标服设置外观。公开包只包含插件及其运行依赖，世界存档须另行提供。
