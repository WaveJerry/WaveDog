'use strict'
// Validate that local body simulations belong to THIS observation geometry.
// Legacy recordings retain their original cardinal-ray representation.
function navigationClearance(request){
  const n=request.publicTerrain?.navigation,s=request.self,t=request.seen
  if(n?.version!==1||n.tick!==request.tick||!s||!t?.visible)return null
  if(![n.origin?.x,n.origin?.y,n.origin?.z,n.toward?.x,n.toward?.z,s.x,s.y,s.z,t.x,t.z].every(Number.isFinite))return null
  if(!n.origin||!n.toward||Math.hypot(n.origin.x-s.x,n.origin.y-s.y,n.origin.z-s.z)>1e-6)return null
  const d=Math.hypot(t.x-s.x,t.z-s.z)
  if(d<1e-6||Math.hypot(n.toward.x-(t.x-s.x)/d,n.toward.z-(t.z-s.z)/d)>1e-6)return null
  const names=['away','toward','right','left'],values=names.map(k=>n.routes?.[k]?.clearance)
  if(!values.every(v=>Number.isFinite(v)&&v>=0&&v<=8))return null
  return Object.fromEntries(names.map((k,i)=>[k,values[i]]))
}
module.exports={navigationClearance}
