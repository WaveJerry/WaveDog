// Read-only old GRU/GTrXL inference. No training, Minecraft connection, world
// reads or action execution. Native Son remains the only command submitter.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,ACTION_WIDTHS,maskActionLogits,biasedActionLogits} from './fresh-policy.js'
import {publicSpatialFeatures} from './public-spatial-features.js'
import {publicThreatFeatures} from './public-threat-features.js'
import {nativeObservation} from './native-observation.js'
await tf.setBackend('cpu');await tf.ready()
const manifestPath=path.resolve(process.argv[2]),manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'))
const bytes=fs.readFileSync(path.join(path.dirname(manifestPath),manifest.binary))
if(crypto.createHash('sha256').update(bytes).digest('hex')!==manifest.sha256)throw Error('Frozen model checksum mismatch')
const model=new DualPolicy(manifest.config,manifest.gateMode)
const layout=manifest.layout.filter(p=>p.group===0)
if(layout.length!==model.params.length)throw Error('Frozen model parameter count mismatch')
for(const [i,p] of layout.entries()){
 const variable=model.params[i];if(JSON.stringify(variable.shape)!==JSON.stringify(p.shape)||p.bytes!==variable.size*4)throw Error('Frozen parameter shape mismatch '+i)
 const values=new Float32Array(p.bytes/4);for(let k=0;k<values.length;k++)values[k]=bytes.readFloatLE(p.offset+k*4)
 const tensor=tf.tensor(values,p.shape);variable.assign(tensor);tensor.dispose()
}
const actors=new Map(),emit=x=>process.stdout.write(JSON.stringify(x)+'\n')
const tensors=(s,out=new Set())=>{if(s&&typeof s==='object'){if(s instanceof tf.Tensor)out.add(s);else for(const v of Object.values(s))tensors(v,out)}return out}
const argmax=a=>a.reduce((j,v,i)=>v>a[j]?i:j,0)
function infer(f){
 let actor=actors.get(f.fighter)
 if(!actor||actor.match!==f.matchId||actor.opponent!==f.opponent){
  if(actor)for(const t of tensors(actor.state))t.dispose()
  actor={match:f.matchId,opponent:f.opponent,state:model.initialState(),lastTick:-1};actors.set(f.fighter,actor)
 }
 if(f.tick<=actor.lastTick)return null
 f.previousObservation=actor.previousObservation
 const started=performance.now(),x=nativeObservation(f,model.config),before=actor.state
 actor.previousObservation=x
 // The fallback's available tools are sword movement/jump/attack only.
 // Shield, ranged, axe and aim stay with Son/native execution.
 const masks=ACTION_WIDTHS.map(w=>Array(w).fill(true));masks[3]=[true,false];masks[4]=[true,false,true,false,false];masks[5]=[false,true,false,false,false]
 const result=tf.tidy(()=>{
  const output=model.step(tf.tensor2d([x]),before,masks,null,publicSpatialFeatures(f),publicThreatFeatures(f))
  const context={distributionVersion:model.config.distributionVersion||1,calibratedHeads:model.config.calibratedHeads,
    weaponConditionedAttack:model.config.weaponConditionedAttack||0,behaviorPriorVersion:0}
  let logits=maskActionLogits(biasedActionLogits(output.logits,x,context),masks),probabilities=logits.map(h=>[...tf.softmax(h).dataSync()]),actions=probabilities.map(argmax)
  if([1,2].includes(context.weaponConditionedAttack)){
    logits=maskActionLogits(biasedActionLogits(output.logits,x,context,actions,model),masks)
    probabilities[4]=[...tf.softmax(logits[4]).dataSync()];actions[4]=argmax(probabilities[4])
  }
  if(model.config.actionConditionedAttack===1){logits=maskActionLogits(model.conditionActionLogits(output.logits,x,actions),masks)
   probabilities[4]=[...tf.softmax(logits[4]).dataSync()];actions[4]=argmax(probabilities[4])}
  return {state:output.state,actions,probabilities}
 })
 actor.state=result.state;actor.lastTick=f.tick;const retained=tensors(result.state);for(const t of tensors(before))if(!retained.has(t))t.dispose()
 const a=result.actions,fw=[0,1,-1,0,0,1,1,-1,-1],side=[0,0,0,-1,1,-1,1,-1,1]
 return {fighter:f.fighter,opponent:f.opponent,matchId:f.matchId,tick:f.tick,checkpointSha256:manifest.sourceCheckpointSha256||manifest.sha256,
  inferenceWeightsSha256:manifest.sha256,model:'GRU64+GTrXL4x256',policyMs:performance.now()-started,
  actions:a,probabilities:result.probabilities,command:{slot:0,forward:fw[a[0]],side:side[a[0]],sprint:a[1]===1,jump:a[2]===1,attack:a[4]===2}}
}
emit({ready:true,model:'GRU64+GTrXL4x256',checkpointSha256:manifest.sourceCheckpointSha256||manifest.sha256,inferenceWeightsSha256:manifest.sha256,readOnly:true})
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
 try{const f=JSON.parse(line),out=infer(f);emit(out||{skipped:true,fighter:f.fighter,tick:f.tick})}
 catch(e){emit({error:String(e)})}
}
