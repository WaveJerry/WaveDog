// Causal public estimates, not an opponent's private cooldown/fallDistance.
// Stateless: missing, stale, invisible or cross-bout observations are unknown.
export const PUBLIC_THREAT_SIZE = 12
export function publicThreatFeatures(request = {}) {
  const s=request.self,t=request.seen,o=request.publicActionContext
  const zero=()=>Array(PUBLIC_THREAT_SIZE).fill(0)
  if(!s||!t?.visible||!o?.visible||!Number.isInteger(request.tick)||o.tick!==request.tick
      ||![s.x,s.y,s.z,t.x,t.y,t.z].every(Number.isFinite))return zero()
  if(o.matchId!==undefined&&o.matchId!==request.matchId
      ||o.opponent!==undefined&&o.opponent!==request.opponent)return zero()
  const v=o.targetVelocity,clip=(x,scale=1)=>Math.max(-1,Math.min(1,x/scale))
  if(!v||![v.x,v.y,v.z].every(Number.isFinite)||Math.abs(v.y)>=1.5
      ||Math.hypot(v.x,v.z)>=1.5||typeof o.targetGrounded!=='boolean')return zero()
  const dx=t.x-s.x,dz=t.z-s.z,d=Math.hypot(dx,dz),e=o.airEnvelope
  const known=e?.valid===true&&Number.isInteger(e.ticks)&&e.ticks>=0
    &&Number.isInteger(e.criticalTick)&&Number.isInteger(e.meleeTick)
  const critical=known&&e.criticalTick>=0&&e.criticalTick<=e.ticks
  const melee=known&&e.meleeTick>=0&&e.meleeTick<=e.ticks
  // Flags separate no predicted contact from immediate contact (time zero).
  return [1,Number(o.targetGrounded),clip(v.y),clip(t.y-s.y,3),
    d>1e-6?clip(-(v.x*dx+v.z*dz)/d):0,Number(known),Number(critical),
    critical?1/(1+e.criticalTick):0,Number(melee),melee?1/(1+e.meleeTick):0,
    known?Math.min(1,e.ticks/20):0,Number(o.targetCriticalPossible===true)]
}
