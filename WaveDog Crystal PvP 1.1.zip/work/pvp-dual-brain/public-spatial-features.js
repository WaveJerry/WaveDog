// Causal geometry only. These features never choose a movement or attack.
import {navigationClearance}from './navigation-clearance.cjs'
// Distances derived from cardinal wall rays describe a local enclosure estimate,
// not an exact diagonal collision ray and not hidden map geometry.
export function publicSpatialFeatures(request){
  const s=request.self,t=request.seen,w=request.publicTerrain?.walls
  if(!s||!t?.visible||!Array.isArray(w)||w.length!==4||!w.every(Number.isFinite))return Array(8).fill(0)
  const dx=t.x-s.x,dz=t.z-s.z,d=Math.hypot(dx,dz)
  if(d<1e-6)return Array(8).fill(0)
  const ray=(x,z)=>Math.max(0,Math.min(8,
    Math.abs(x)>1e-6?w[x<0?0:1]/Math.abs(x):8,
    Math.abs(z)>1e-6?w[z<0?2:3]/Math.abs(z):8)-.3)/8
  const toward=[dx/d,dz/d],away=ray(-toward[0],-toward[1])
  const navigation=navigationClearance(request)
  const reach=Math.hypot(Math.max(0,Math.abs(dx)-.3),Math.max(0,Math.abs(dz)-.3),
    Math.max(0,s.y-(t.y+1.62),t.y+1.62-(s.y+1.8)))
  const motion=request.observedOpponentMotion
  const v=motion?{x:motion.vx,z:motion.vz}:request.publicActionContext?.targetVelocity||{}
  const closing=((s.vx||0)-(v.x||0))*toward[0]+((s.vz||0)-(v.z||0))*toward[1]
  return [1,...(navigation?[navigation.away/8,navigation.toward/8,navigation.right/8,navigation.left/8]
    :[away,ray(...toward),ray(-toward[1],toward[0]),ray(toward[1],-toward[0])]),
    Math.min(1,reach/8),Math.max(-1,Math.min(1,closing)),Math.min(1,d/8)]
}
