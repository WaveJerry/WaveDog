import * as tf from '@tensorflow/tfjs'

export const OBS_SIZE = 98
export const ACTION_WIDTHS = [9, 2, 2, 2, 5, 5, 13, 7, 2]
export const DEFAULT_CONFIG = Object.freeze({ fast: 64, slow: 256, heads: 8,
  layers: 4, ff: 1024, interval: 8, memory: 32 })
export const GATE_TARGET = [.20, .25, .25, .25, .45, .55, .35, .35, .35]
let modelCount = 0
const gelu = x => tf.mul(.5, tf.mul(x, tf.add(1,
  tf.tanh(tf.mul(Math.sqrt(2 / Math.PI),
    tf.add(x, tf.mul(.044715, tf.pow(x, 3))))))))

// Public-observation curriculum priors only change exploration logits. PPO
// trains against the resulting distribution and can learn to override them.
export function curriculumLogitBias (x, context = {}, actions = null) {
  if (!Array.isArray(x) || x.length !== OBS_SIZE)
    throw Error('curriculum bias needs one public observation')
  const bias = ACTION_WIDTHS.map(width => Array(width).fill(0))
  // New whole-fight policies learn their preferences from demonstrations.
  // Preserve the old distribution only for old checkpoints and PPO replay.
  if (context.behaviorPriorVersion === 0) return bias
  if (x[31] < .5) return bias
  const outOfReach = x[97] > .12
  const nearEdge = x[97] > -.55 && x[97] < .2
  const noRangedAmmo = x[10] <= 0 && x[11] < .5
  const aggressive = x[73] > .5
  const defensive = x[72] > .5
  const flank = x[74] > .5
  const groundCombo = x[75] > .5
  const contestedFall = context.entryCurriculum >= 5 && context.fallingMeleeThreat
    && !context.ownFallingWindow
  const interceptionRisk = context.edgeComboRisk
    || context.entryCurriculum >= 6 && context.risingEntryThreat
    || context.entryCurriculum >= 9 && context.groundChainReentry
  // Replay-only compatibility for already journaled version-1 trajectories.
  if (context.entryCurriculum === 1 && x[2] > .5 && x[7] < .5
      && (actions?.[4] === 2 || x[97] < .65 || context.opponentApproaching)) {
    bias[0][1] += 1.15
    bias[0][5] += .35
    bias[0][6] += .35
    bias[1][1] += 1.35
  }
  // Replay-only context 2: withdrawn proximity-entry curriculum. New actors
  // emit context 3; do not reactivate these biases in live inference.
  // Encourage a ground sprint toward a nearby or visibly approaching enemy.
  // Do not bind movement to the sampled hand action or touch airborne timing.
  if (context.entryCurriculum === 2 && x[2] > .5 && x[7] < .5
      && x[8] < .5 && Math.abs(x[78]) < .25
      && (x[97] < .65 || context.opponentApproaching)) {
    bias[0][1] += 1.15
    bias[0][5] += .35
    bias[0][6] += .35
    bias[1][1] += 1.35
  }
  // Prefer the first legal, charged entry window. Rising flight may be a
  // deliberate critical setup; this cue never changes jump or sprint keys.
  if (context.entryCurriculum === 2 && context.enteredReach && x[97] <= 0
      && x[1] >= .85 && x[7] < .5 && x[8] < .5 && x[23] < .5
      && Math.abs(x[78]) < .15 && (x[2] > .5 || x[4] < -.08))
    bias[4][2] += .9
  if (outOfReach && noRangedAmmo) {
    bias[0][1] += 2.2
    bias[0][2] -= 1.4
    bias[0][5] += .65
    bias[0][6] += .65
    // Reaching a distant melee opponent is usually a sprint action. The
    // sampled keys remain independent and PPO still credits actual progress.
    bias[1][1] += 4.2
    if (x[97] > .65) bias[4][1] -= 1.8
  }
  if (noRangedAmmo && x[97] > -.55 && x[97] <= .12)
    bias[1][1] += .45
  // Changing the main-hand item resets vanilla attack cooldown. A stable
  // weapon should be the default; a close combo can still choose to switch.
  const held = x[12] < .25 ? 1 : x[12] > .7 ? 0 : null
  const swordFollowup = context.entryCurriculum >= 6 && context.swordDpsWindow
    && x[1] < .55 && x[8] < .5 && x[23] < .5 && x[97] <= 0
  const swordSustain = context.entryCurriculum >= 8 && context.swordSustainWindow
    && held === 1 && x[8] < .5 && x[23] < .5 && x[97] <= 0
  const shieldSwitch = context.entryCurriculum >= 8 && context.swordShieldBreakWindow
    && held === 1 && x[8] < .5 && x[23] > .5 && x[97] <= 0
  if (held !== null) {
    const plannedCloseCombo = x[89] > .95 && x[97] < -.55
    bias[5][held] += swordFollowup || shieldSwitch ? .7
      : swordSustain ? 5.2 : plannedCloseCombo && x[1] < .35 ? 2.6 : 3.7
  }
  if (swordFollowup) bias[5][1] += 1.2
  if (shieldSwitch) bias[5][0] += 1.2
  if (context.entryCurriculum >= 8 && context.axeShieldBreakWindow
      && held === 0 && x[23] > .5 && x[97] <= 0) bias[4][2] += 1.2
  if (context.entryCurriculum >= 8 && context.swordCriticalSetupWindow && x[2] > .5)
    bias[2][1] += .25
  if (aggressive) {
    if (outOfReach) { bias[0][1] += .8; bias[0][2] -= .7 }
    if (nearEdge && x[1] > .75) bias[4][2] += .9
  }
  if (defensive && nearEdge && x[6] > .5) bias[4][1] += .4
  if (flank && outOfReach) { bias[0][5] += .5; bias[0][6] += .5 }
  if (groundCombo && nearEdge && x[23] < .5) bias[5][1] += 1.5
  if (nearEdge && x[1] > .85 && x[8] < .5) bias[4][2] += 1.1
  if (x[1] > .85 && x[8] < .5 && x[23] < .5
      && x[97] > -.97 && x[97] < .2) bias[4][2] += 1.5
  // A legal, aimed, full-charge melee window must not turn into a long
  // observation loop after the fighter has already entered range. This is a
  // conditional exploration cue, not a forced attack: PPO can still choose
  // movement, a critical setup, or another legal response.
  if (x[1] >= .85 && x[8] < .5 && x[23] < .5 && x[97] < .2 && !contestedFall
      && !(context.entryCurriculum >= 8 && context.swordRisingWindow))
    bias[4][2] += 24.0
  // Written method cues become conditional exploration opportunities. They
  // never replace the learned action distribution or fabricate a hit.
  if (x[82] > .95 && x[6] > .5 && x[8] < .5
      && x[97] > -.95 && x[97] < .3) {
    bias[4][1] += 1.3
    if (x[96] > .4) bias[4][1] += .8
  }
  if (x[86] > .95 && x[89] > .25 && x[96] > .4
      && x[97] < .25 && x[97] > -.95) {
    bias[0][2] += .9
    bias[1][1] += .4
  }
  if (x[84] > .95 && x[85] > .25 && x[2] > .5
      && x[97] > .5 && x[8] < .5) {
    bias[0][1] += 1.0
    bias[1][1] += 2.6
    // Start a purposeful jump after forward speed has built up; a standing
    // hop or every-frame jump does not satisfy the long-run entry goal.
    bias[2][1] += Math.hypot(x[3], x[5]) > .05 ? 4.8 : .9
  }
  if (x[90] > .95 && x[10] > 0 && x[97] > .9) {
    bias[5][2] += 1.5
    bias[4][3] += 1.1
  }
  if (x[91] > .95 && (x[10] > 0 || x[11] > .5)
      && x[97] > .9) {
    bias[5][3] += 1.5
    bias[4][3] += 1.1
  }
  // Jump reset is a public-swing timing experiment, never a permanent jump.
  // The SYNC goal and its two method cues identify this particular lesson.
  if (x[87] > .5 && x[85] > .4 && x[89] > .25
      && x[2] > .5 && x[96] > .4 && x[97] > -.95 && x[97] < .25)
    bias[2][1] += 1.0
  // Current self-play still clicks at low charge in almost every melee frame.
  // Keep light hits available for shield breaks and low-health emergencies;
  // shift ordinary exploration toward waiting for a useful damage window.
  const swordCadence = context.entryCurriculum >= 6 && context.swordCadenceWindow
    && x[1] >= .75 && x[1] < .85 && x[97] <= 0 && !contestedFall
  if (x[23] < .5 && x[0] > .3 && x[1] < .85 && !swordCadence
      && !(context.entryCurriculum >= 4 && interceptionRisk && x[97] <= 0
        && !contestedFall)) {
    bias[4][2] -= x[1] < .55 ? 5.5 : 2.5
  }
  // Sneaking cuts horizontal speed. Keep it available for rare fine spacing,
  // but ordinary sword/axe movement should not flicker crouch every frame.
  if (x[31] > .5) bias[3][1] -= 2.5
  return bias
}

// Use the same public-observation prior during acting and PPO replay. Keeping
// it in both distributions makes the stored behavior log probability valid.
export function biasedActionLogits (logits, observation, context = {}, actions = null, policy = null, publicHealth = null) {
  if(context.actionConditionedAttack===1&&actions){
    if(!policy)throw Error('Conditional actions require the same learned policy during acting and replay')
    return tf.tidy(()=>biasedActionLogits(policy.conditionActionLogits(logits,observation,actions),
      observation,{...context,actionConditionedAttack:0,weaponConditionedAttack:0},actions))
  }
  // Version 1 conditions only the legacy curriculum prior. Version 2 also
  // reevaluates the learned instantaneous attack residual on the selected
  // weapon and reset charge, while keeping the recurrent history unchanged.
  // Both attack and wait remain legal; low-charge axe shield breaks survive.
  if ([1, 2].includes(context.weaponConditionedAttack) && [0, 1].includes(actions?.[5])) {
    const held = observation[12] < .25 ? 1 : observation[12] > .7 ? 0 : null
    if (held !== null && held !== actions[5]) return tf.tidy(() => {
      const unconditioned = { ...context, weaponConditionedAttack: 0 }
      const ordinary = biasedActionLogits(logits, observation, unconditioned, actions)
      const switched = [...observation]
      switched[1] = actions[5] === 1 ? .04 : .025
      switched[12] = actions[5] === 1 ? 0 : .875
      if (context.weaponConditionedAttack === 2 && !policy)
        throw Error('Learned conditional attack requires the same policy during acting and replay')
      const correctedRaw = context.weaponConditionedAttack === 2
        ? policy.conditionAttackLogits(logits, observation, switched, publicHealth) : logits
      const corrected = biasedActionLogits(correctedRaw, switched, unconditioned, actions)
      return ordinary.map((head, index) => index === 4 ? corrected[4] : head)
    })
  }
  // The repaired distribution is already a calibrated probability mixture.
  // Keep historical logit priors byte-compatible for old PPO trajectories;
  // new actors learn timing without the old +24 attack / weapon overrides.
  if (context.distributionVersion === 2 || context.behaviorPriorVersion === 0) return logits
  const bias = curriculumLogitBias(observation, context, actions)
  const followup = context.entryCurriculum >= 6 && context.swordDpsWindow
    && observation[1] < .55 && observation[8] < .5 && observation[23] < .5
    && observation[31] > .5 && observation[97] <= 0
  const cadence = context.entryCurriculum >= 6 && context.swordCadenceWindow
    && observation[1] >= .75 && observation[1] < .85 && observation[8] < .5
    && observation[23] < .5 && observation[31] > .5 && observation[97] <= 0
    && (!context.fallingMeleeThreat || context.ownFallingWindow)
  const sustain = context.entryCurriculum >= 8 && context.swordSustainWindow
    && observation[12] < .25 && observation[8] < .5 && observation[23] < .5
    && observation[31] > .5 && observation[97] <= 0
  const shieldSwitch = context.entryCurriculum >= 8 && context.swordShieldBreakWindow
    && observation[12] < .25 && observation[8] < .5 && observation[23] > .5
    && observation[31] > .5 && observation[97] <= 0
  const shieldStrike = context.entryCurriculum >= 8 && context.axeShieldBreakWindow
    && observation[12] > .7 && observation[8] < .5 && observation[23] > .5
    && observation[31] > .5 && observation[97] <= 0
  const criticalSetup = sustain && context.swordCriticalSetupWindow && observation[2] > .5
  const boundaryLight = context.entryCurriculum >= 9 && context.groundChainReentry
    && observation[31] > .5 && observation[97] <= 0 && observation[2] > .5
    && observation[1] >= .2 && !context.fallingMeleeThreat
  const heads = logits.map((head, index) => {
    // Actual WaveDog logits had an axe/sword gap of ~19: dividing by two
    // still left the sword effectively unreachable. Reopen only the evidenced
    // follow-up/cadence windows with a smooth, shift-invariant softsign. Its
    // gradient stays nonzero for large finite logits. Old PPO contexts retain
    // their exact distribution; no movement command or weapon is forced.
    let source = head
    if (index === 5 && (followup || sustain || shieldSwitch)
        || index === 4 && (cadence || shieldStrike || boundaryLight) || index === 2 && criticalSetup) {
      const second = index === 5 || index === 2 ? 1 : 2
      const center = tf.mul(.5, tf.add(head.slice([0, 0], [1, 1]),
        head.slice([0, second], [1, 1])))
      const shifted = tf.sub(head, center)
      source = tf.mul(sustain && index === 5 || criticalSetup && index === 2
        || context.entryCurriculum >= 10 && followup && index === 5 ? 1 : 2,
        tf.div(shifted, tf.add(1, tf.abs(shifted))))
    }
    return tf.add(source, tf.tensor2d([bias[index]], [1, bias[index].length]))
  })
  // Only the new, replay-versioned public combo-risk context relaxes the old
  // learned wait-for-charge preference. Temperature keeps both wait and attack
  // learnable; it never sends an attack, changes reach, or guarantees knockback.
  const contestedFall = context.entryCurriculum >= 5 && context.fallingMeleeThreat
    && !context.ownFallingWindow
  const interceptionRisk = context.edgeComboRisk
    || context.entryCurriculum >= 6 && context.risingEntryThreat
    || context.entryCurriculum >= 9 && context.groundChainReentry
  if (context.entryCurriculum >= 4 && interceptionRisk && !contestedFall && observation[31] > .5
      && observation[97] <= 0 && observation[1] < .85
      && observation[7] < .5 && observation[8] < .5 && observation[23] < .5) {
    const old = heads[4]
    heads[4] = tf.add(tf.div(old, 4), tf.tensor2d([[0, 0, 1.25, 0, 0]]))
    old.dispose()
  }
  if (contestedFall && observation[31] > .5) {
    // Broaden exploration in the demonstrated losing situation. No retreat,
    // jump or hit is selected here; actual net exchange still supplies reward.
    // The two observed losses do not prove a counterfactual dodge would win.
    for (const index of [0, 4]) {
      const old = heads[index]
      heads[index] = tf.div(old, 2)
      old.dispose()
    }
  }
  if (context.entryCurriculum >= 5 && context.jumpResetTrial && observation[2] > .5) {
    const old = heads[2]
    heads[2] = tf.div(old, 4)
    old.dispose()
  }
  if (context.entryCurriculum >= 5 && context.swordComboPressure && !followup
      && !sustain && !shieldSwitch) {
    // Make a close sword counter learnable without forcing a switch that
    // throws away charge. Native damage and switch cost remain the feedback.
    const old = heads[5]
    heads[5] = tf.div(old, 2)
    old.dispose()
  }
  if (context.distributionVersion >= 3) {
    // Calibrate ONLY the named heads. The previous v2 switch removed every
    // curriculum prior even for uncalibrated movement/timing heads. Keep the
    // established distribution byte-identical outside the targeted repair.
    for (const index of context.calibratedHeads || [2, 5]) {
      heads[index].dispose()
      heads[index] = logits[index]
    }
  }
  return heads
}

class Dense {
  constructor (input, output, name) {
    this.w = tf.variable(tf.randomNormal([input, output], 0, 1 / Math.sqrt(input)),
      true, `${name}.w`)
    this.b = tf.variable(tf.zeros([output]), true, `${name}.b`)
    this.params = [this.w, this.b]
  }
  apply (x) { return tf.add(tf.matMul(x, this.w), this.b) }
}
class LayerNorm {
  constructor (width, name) {
    this.scale = tf.variable(tf.ones([width]), true, `${name}.scale`)
    this.bias = tf.variable(tf.zeros([width]), true, `${name}.bias`)
    this.params = [this.scale, this.bias]
  }
  apply (x) {
    const { mean, variance } = tf.moments(x, -1, true)
    return tf.add(tf.mul(tf.div(tf.sub(x, mean), tf.sqrt(tf.add(variance, 1e-5))),
      this.scale), this.bias)
  }
}
class FastGRU {
  constructor (input, hidden, name) {
    this.hidden = hidden
    this.reset = new Dense(input + hidden, hidden, `${name}.reset`)
    this.update = new Dense(input + hidden, hidden, `${name}.update`)
    this.candidate = new Dense(input + hidden, hidden, `${name}.candidate`)
    this.params = [...this.reset.params, ...this.update.params, ...this.candidate.params]
  }
  step (observation, previous) {
    const joined = tf.concat([observation, previous], 1)
    const reset = tf.sigmoid(this.reset.apply(joined))
    const update = tf.sigmoid(this.update.apply(joined))
    const candidate = tf.tanh(this.candidate.apply(tf.concat([
      observation, tf.mul(reset, previous)], 1)))
    return tf.add(tf.mul(update, previous), tf.mul(tf.sub(1, update), candidate))
  }
}
class GatedXLBlock {
  constructor (width, heads, ff, name) {
    if (width % heads !== 0) throw Error('slow width must divide attention heads')
    this.width = width; this.heads = heads; this.headWidth = width / heads
    this.normAttention = new LayerNorm(width, `${name}.norm-attention`)
    this.query = new Dense(width, width, `${name}.query`)
    this.key = new Dense(width, width, `${name}.key`)
    this.value = new Dense(width, width, `${name}.value`)
    this.attentionOut = new Dense(width, width, `${name}.attention-out`)
    this.attentionGate = new Dense(width * 2, heads, `${name}.attention-gate`)
    this.normFF = new LayerNorm(width, `${name}.norm-ff`)
    this.ffIn = new Dense(width, ff, `${name}.ff-in`)
    this.ffOut = new Dense(ff, width, `${name}.ff-out`)
    this.ffGate = new Dense(width * 2, heads, `${name}.ff-gate`)
    this.slopes = tf.tensor3d(Array.from({ length: heads }, (_, i) =>
      .003 + .027 * i / Math.max(1, heads - 1)), [1, heads, 1])
    this.params = [this.normAttention, this.query, this.key, this.value,
      this.attentionOut, this.attentionGate, this.normFF, this.ffIn,
      this.ffOut, this.ffGate].flatMap(layer => layer.params)
  }
  gate (x, proposal, layer) {
    const batch = x.shape[0]
    const perHead = tf.sigmoid(layer.apply(tf.concat([x, proposal], 1)))
    const expanded = tf.reshape(tf.tile(tf.expandDims(perHead, -1),
      [1, 1, this.headWidth]), [batch, this.width])
    return tf.add(x, tf.mul(expanded, proposal))
  }
  step (input, cache, limit) {
    const batch = input.shape[0]
    const normalized = this.normAttention.apply(input)
    const shape = [batch, this.heads, 1, this.headWidth]
    const query = tf.reshape(this.query.apply(normalized), shape)
    const nextKey = tf.reshape(this.key.apply(normalized), shape)
    const nextValue = tf.reshape(this.value.apply(normalized), shape)
    let key = cache ? tf.concat([cache.key, nextKey], 2) : nextKey
    let value = cache ? tf.concat([cache.value, nextValue], 2) : nextValue
    const length = Math.min(key.shape[2], limit)
    if (key.shape[2] > limit) {
      key = key.slice([0, 0, key.shape[2] - limit, 0], [batch, this.heads, length, this.headWidth])
      value = value.slice([0, 0, value.shape[2] - limit, 0], [batch, this.heads, length, this.headWidth])
    }
    const age = tf.reshape(tf.range(length - 1, -1, -1), [1, 1, length])
    const score = tf.sub(tf.div(tf.sum(tf.mul(query, key), -1), Math.sqrt(this.headWidth)),
      tf.mul(this.slopes, age))
    const weights = tf.softmax(score, -1)
    const attended = tf.reshape(tf.sum(tf.mul(tf.expandDims(weights, -1), value), 2),
      [batch, this.width])
    const attention = this.attentionOut.apply(attended)
    const afterAttention = this.gate(input, attention, this.attentionGate)
    const ff = this.ffOut.apply(gelu(this.ffIn.apply(this.normFF.apply(afterAttention))))
    return { output: this.gate(afterAttention, ff, this.ffGate), cache: { key, value } }
  }
}

export class DualPolicy {
  constructor (config = {}, gateMode = 'learned') {
    if (!['learned', 'fixed'].includes(gateMode)) throw Error('invalid gate mode')
    this.config = { ...DEFAULT_CONFIG, ...config }
    this.gateMode = gateMode
    const { fast, slow, heads, layers, ff } = this.config
    const name = `dual${++modelCount}`
    this.fast = new FastGRU(OBS_SIZE, fast, `${name}.fast`)
    this.fastHeads = ACTION_WIDTHS.map((width, index) =>
      new Dense(fast, width, `${name}.fast-head-${index}`))
    this.fastValue = new Dense(fast, 1, `${name}.fast-value`)
    this.slowToken = new Dense(OBS_SIZE * 2, slow, `${name}.slow-token`)
    this.slowBlocks = Array.from({ length: layers }, (_, index) =>
      new GatedXLBlock(slow, heads, ff, `${name}.slow-${index}`))
    this.slowHeads = ACTION_WIDTHS.map((width, index) =>
      new Dense(slow, width, `${name}.slow-head-${index}`))
    this.gateIn = new Dense(OBS_SIZE + fast + slow, 128, `${name}.gate-in`)
    this.gateOut = new Dense(128, ACTION_WIDTHS.length, `${name}.gate-out`)
    this.valueIn = new Dense(OBS_SIZE + fast + slow, 256, `${name}.value-in`)
    this.valueOut = new Dense(256, 1, `${name}.value-out`)
    this.fixedGate = tf.tensor2d([GATE_TARGET])
    this.params = [this.fast, ...this.fastHeads, this.fastValue, this.slowToken,
      ...this.slowBlocks, ...this.slowHeads, this.gateIn, this.gateOut,
      this.valueIn, this.valueOut].flatMap(layer => layer.params)
    if (this.config.publicHealthInputs) {
      if (this.config.publicHealthInputs !== 5) throw Error('Unsupported public health input schema')
      // Zero-initialized learned side input: all old parameters and the 98
      // established channels retain their meaning. Unknown health is all zero
      // and cannot silently become "opponent has zero HP".
      this.publicHealthProjection = tf.variable(tf.zeros([5, OBS_SIZE]), true, `${name}.public-health`)
      this.params.push(this.publicHealthProjection)
    }
    if (this.config.publicThreatInputs) {
      if(this.config.publicThreatInputs!==12)throw Error('Unsupported public threat input schema')
      // Zero migration preserves all old outputs. Learning decides what these
      // public trajectory estimates mean for GRU, GTrXL and action heads.
      this.publicThreatProjection=tf.variable(tf.zeros([12,OBS_SIZE]),true,`${name}.public-threat`)
      this.params.push(this.publicThreatProjection)
    }
    if(this.config.publicMotionInputs){
      if(this.config.publicMotionInputs!==32)throw Error('Unsupported public motion schema')
      this.publicMotionProjection=tf.variable(tf.zeros([32,OBS_SIZE]),true,`${name}.public-motion`)
      this.params.push(this.publicMotionProjection)
    }
    if (this.config.actionContextHeads) {
      if (!Array.isArray(this.config.actionContextHeads)
          || !['[2,5]','[2,5,4]','[2,5,4,0,1]','[2,5,4,0,1,6,7,8]'].includes(JSON.stringify(this.config.actionContextHeads)))
        throw Error('Unsupported contextual action head schema')
      this.actionContextIn = new Dense(OBS_SIZE, 32, `${name}.action-context-in`)
      this.actionContextOut = this.config.actionContextHeads.map(head => new Dense(32,
        ACTION_WIDTHS[head], `${name}.action-context-out-${head}`))
      // A zero residual preserves all learned outputs during migration. The
      // small learned head can see exact current weapon/charge even when an
      // inherited recurrent representation has discarded these distinctions.
      tf.tidy(()=>{for (const layer of this.actionContextOut) { layer.w.assign(tf.zerosLike(layer.w)); layer.b.assign(tf.zerosLike(layer.b)) }})
      this.params.push(...this.actionContextIn.params,...this.actionContextOut.flatMap(layer=>layer.params))
    }
    if(this.config.contextBaseCalibration===1){
      if(!this.actionContextIn)throw Error('Context calibration requires learned residual heads')
      // Learned confidence calibration for the two parent action heads.
      // 2*sigmoid(0)=1 preserves the complete inherited policy initially.
      // This cannot force a weapon/jump or invert the recurrent preference.
      this.contextBaseCalibration=tf.variable(tf.zeros([2]),true,`${name}.context-base-calibration`)
      this.params.push(this.contextBaseCalibration)
    }
    if(this.config.actionContextFeatures){
      const features=this.config.actionContextFeatures
      if(!this.actionContextIn||!Array.isArray(features)||!features.length||new Set(features).size!==features.length
        ||features.some(i=>!Number.isInteger(i)||i<0||i>=OBS_SIZE))throw Error('Invalid current context feature schema')
      this.actionContextMask=tf.tensor2d([Array.from({length:OBS_SIZE},(_,i)=>features.includes(i)?1:0)])
    }
    if (this.config.attackContextFeatures) {
      const features = this.config.attackContextFeatures
      if (!this.config.actionContextHeads?.includes(4) || !Array.isArray(features) || !features.length
          || new Set(features).size !== features.length || features.some(i => !Number.isInteger(i) || i < 0 || i >= OBS_SIZE))
        throw Error('Invalid attack context feature schema')
      this.attackContextMask = tf.tensor2d([Array.from({ length: OBS_SIZE }, (_, i) => features.includes(i) ? 1 : 0)])
    }
    if(this.config.actionConditionedAttack===1){
      // Autoregressive p(attack | observation, selected weapon/sprint/jump).
      // Dependencies are learned, with the identical conditional used by BC/PPO.
      this.actionChoiceIn=new Dense(OBS_SIZE+9,64,`${name}.action-choice-in`)
      this.actionChoiceOut=new Dense(64,ACTION_WIDTHS[4],`${name}.action-choice-out`)
      tf.tidy(()=>{this.actionChoiceOut.w.assign(tf.zerosLike(this.actionChoiceOut.w));
        this.actionChoiceOut.b.assign(tf.zerosLike(this.actionChoiceOut.b))})
      this.params.push(...this.actionChoiceIn.params,...this.actionChoiceOut.params)
    }
    if(this.config.spatialMovementVersion===1){
      // Additional public geometry in the opponent's coordinate frame. The
      // inherited recurrent inputs and all combat heads remain intact.
      this.spatialMovementHeads=this.config.spatialMovementHeads||[0,1,6]
      if(!['[0,1,6]','[0,1,6,5,4]','[0,1,6,5,4,2]'].includes(JSON.stringify(this.spatialMovementHeads)))throw Error('Unsupported spatial tactical heads')
      this.spatialMovementIn=new Dense(OBS_SIZE+8,32,`${name}.spatial-movement-in`)
      this.spatialMovementOut=this.spatialMovementHeads.map(h=>new Dense(32,ACTION_WIDTHS[h],`${name}.spatial-movement-out-${h}`))
      tf.tidy(()=>{for(const p of this.spatialMovementOut){p.w.assign(tf.zerosLike(p.w));p.b.assign(tf.zerosLike(p.b))}})
      this.params.push(...this.spatialMovementIn.params,...this.spatialMovementOut.flatMap(p=>p.params))
      if(this.config.spatialControlSplitHeads){
        // A separate learned projection permits control adaptation without
        // rewriting the input representation of preserved attack/sprint/aim.
        this.spatialControlSplitHeads=this.config.spatialControlSplitHeads
        if(JSON.stringify(this.spatialControlSplitHeads)!=='[0,2,5]'
            ||!this.spatialControlSplitHeads.every(h=>this.spatialMovementHeads.includes(h)))
          throw Error('Unsupported split spatial control heads')
        this.spatialControlIn=new Dense(OBS_SIZE+8,32,`${name}.spatial-movement-control-in`)
        this.spatialControlIn.w.assign(this.spatialMovementIn.w)
        this.spatialControlIn.b.assign(this.spatialMovementIn.b)
        this.params.push(...this.spatialControlIn.params)
      }
      if(this.config.spatialTemporalFusionVersion===1){
        if(this.config.publicThreatInputs!==12)throw Error('Temporal spatial fusion requires public forecast inputs')
        this.spatialTemporalHeads=[0,1,4,5,6]
        if(!this.spatialTemporalHeads.every(h=>this.spatialMovementHeads.includes(h)))
          throw Error('Temporal spatial fusion requires complete movement/combat spatial heads')
        // A learned residual sees the forecast AND both recurrent states.
        // Zero output preserves the inherited policy exactly. No trajectory
        // threshold selects an action or switches a controller at runtime.
        this.spatialTemporalIn=new Dense(OBS_SIZE+8+12+fast+slow,64,`${name}.spatial-movement-temporal-in`)
        this.spatialTemporalOut=this.spatialTemporalHeads.map(h=>new Dense(64,ACTION_WIDTHS[h],`${name}.spatial-movement-temporal-out-${h}`))
        tf.tidy(()=>{for(const p of this.spatialTemporalOut){p.w.assign(tf.zerosLike(p.w));p.b.assign(tf.zerosLike(p.b))}})
        this.params.push(...this.spatialTemporalIn.params,...this.spatialTemporalOut.flatMap(p=>p.params))
        if(this.config.spatialTemporalRouteSplit===1){
          this.spatialTemporalRouteIn=new Dense(OBS_SIZE+8+12+fast+slow,64,`${name}.spatial-movement-temporal-route-in`)
          this.spatialTemporalRouteIn.w.assign(this.spatialTemporalIn.w)
          this.spatialTemporalRouteIn.b.assign(this.spatialTemporalIn.b)
          this.params.push(...this.spatialTemporalRouteIn.params)
        }
      }
    }
  }
  parameterCount () { return this.params.reduce((n, variable) => n + variable.size, 0) }
  initialState (batch = 1) {
    return { fast: tf.zeros([batch, this.config.fast]), slow: null,
      caches: Array(this.config.layers).fill(null), pending: [], frames: 0 }
  }
  projectObservation (observation, publicHealth = null) {
    if (!this.publicHealthProjection) return observation
    const values = publicHealth || Array(5).fill(0)
    if (!Array.isArray(values) || values.length !== 5 || !values.every(Number.isFinite))
      throw Error('Invalid public health features')
    const side = tf.tile(tf.tensor2d([values], [1, 5]), [observation.shape[0], 1])
    return tf.add(observation, tf.matMul(side, this.publicHealthProjection))
  }
  projectActionContext(observation){
    return this.actionContextMask?tf.mul(observation,this.actionContextMask):observation
  }
  projectPolicyInputs(observation,publicHealth=null,publicThreat=null,publicMotion=null){
    observation=this.projectObservation(observation,publicHealth)
    if(this.publicThreatProjection){
      const values=publicThreat||Array(12).fill(0)
      if(!Array.isArray(values)||values.length!==12||!values.every(Number.isFinite))
        throw Error('Invalid public threat features')
      const side=tf.tile(tf.tensor2d([values]),[observation.shape[0],1])
      observation=tf.add(observation,tf.matMul(side,this.publicThreatProjection))
    }
    if(this.publicMotionProjection){
      const values=publicMotion||Array(32).fill(0)
      if(!Array.isArray(values)||values.length!==32||!values.every(Number.isFinite))throw Error('Invalid public motion features')
      observation=tf.add(observation,tf.matMul(tf.tile(tf.tensor2d([values]),[observation.shape[0],1]),this.publicMotionProjection))
    }
    return observation
  }
  conditionAttackLogits (logits, before, after, publicHealth = null) {
    const index = this.config.actionContextHeads?.indexOf(4) ?? -1
    if (index < 0) throw Error('Learned conditional attack needs the attack context output')
    const input = this.projectObservation(tf.tensor2d([before, after], [2, OBS_SIZE]), publicHealth)
    const contextInput=this.projectActionContext(input)
    const selected = this.attackContextMask ? tf.mul(contextInput, this.attackContextMask) : contextInput
    const residual = this.actionContextOut[index].apply(tf.tanh(this.actionContextIn.apply(selected)))
    const change = tf.sub(residual.slice([1, 0], [1, ACTION_WIDTHS[4]]),
      residual.slice([0, 0], [1, ACTION_WIDTHS[4]]))
    // Replace only the instantaneous attack context after a sampled switch.
    // Recurrent history, jump, movement, chosen weapon and value stay intact.
    return logits.map((head, h) => h === 4 ? tf.add(head, change) : head)
  }
  conditionActionLogits(logits,observation,actions){
    if(!this.actionChoiceIn)throw Error('Missing autoregressive action head')
    const choices=[...[0,1].map(i=>Number(actions[1]===i)),
      ...[0,1].map(i=>Number(actions[2]===i)),...[0,1,2,3,4].map(i=>Number(actions[5]===i))]
    const residual=this.actionChoiceOut.apply(tf.tanh(this.actionChoiceIn.apply(tf.tensor2d([[...observation,...choices]]))))
    return logits.map((head,h)=>h===4?tf.add(head,residual):head)
  }
  spatialMovementResidual(observation,spatial,publicThreat=null,recurrent=null){
    if(!Array.isArray(spatial)||spatial.length!==8||!spatial.every(Number.isFinite))throw Error('Spatial movement requires recorded public geometry')
    const side=tf.tile(tf.tensor2d([spatial]),[observation.shape[0],1])
    let threat=null
    if(this.spatialTemporalIn){
      const values=publicThreat||Array(12).fill(0)
      if(!Array.isArray(values)||values.length!==12||!values.every(Number.isFinite))throw Error('Invalid spatial forecast inputs')
      threat=tf.tile(tf.tensor2d([values]),[observation.shape[0],1])
    }
    return this.spatialMovementResidualBatch(observation,side,threat,recurrent)
  }
  spatialMovementResidualBatch(observation,spatial,threat=null,recurrent=null){
    const input=tf.concat([observation,spatial],1)
    const hidden=tf.tanh(this.spatialMovementIn.apply(input))
    const control=this.spatialControlIn?tf.tanh(this.spatialControlIn.apply(input)):null
    const residual=this.spatialMovementOut.map((layer,i)=>layer.apply(
      control&&this.spatialControlSplitHeads.includes(this.spatialMovementHeads[i])?control:hidden))
    if(this.spatialTemporalIn){
      if(!threat||threat.shape[0]!==observation.shape[0]||threat.shape[1]!==12
          ||!recurrent?.fast||!recurrent?.slow)throw Error('Temporal spatial fusion needs causal forecast and recurrent state')
      const temporalInput=tf.concat([observation,spatial,threat,recurrent.fast,recurrent.slow],1)
      const context=tf.tanh(this.spatialTemporalIn.apply(temporalInput))
      const route=this.spatialTemporalRouteIn?tf.tanh(this.spatialTemporalRouteIn.apply(temporalInput)):null
      for(const[i,h]of this.spatialTemporalHeads.entries()){
        const j=this.spatialMovementHeads.indexOf(h)
        residual[j]=tf.add(residual[j],this.spatialTemporalOut[i].apply(route&&[0,6].includes(h)?route:context))
      }
    }
    return residual
  }
  step (observation, state, legalMasks = null, publicHealth = null, publicSpatial = null, publicThreat = null, publicMotion = null) {
    if (observation.shape.length !== 2 || observation.shape[1] !== OBS_SIZE)
      throw Error(`expected [batch,${OBS_SIZE}] public observation`)
    state ||= this.initialState(observation.shape[0])
    if (state.fast.shape[0] !== observation.shape[0]) throw Error('actor state batch mismatch')
    observation = this.projectPolicyInputs(observation, publicHealth, publicThreat, publicMotion)
    const fast = this.fast.step(observation, state.fast)
    let pending = [...state.pending, observation]
    let slow = state.slow
    let caches = state.caches
    if (!slow || state.frames % this.config.interval === 0) {
      const average = tf.mean(tf.stack(pending), 0)
      slow = tf.tanh(this.slowToken.apply(tf.concat([observation, average], 1)))
      caches = []
      for (let index = 0; index < this.slowBlocks.length; index++) {
        const result = this.slowBlocks[index].step(slow, state.caches[index], this.config.memory)
        slow = result.output; caches.push(result.cache)
      }
      pending = []
    }
    const output = this.readout(observation, fast, slow, legalMasks, publicSpatial, publicThreat)
    return { ...output, state: { fast, slow, caches, pending, frames: state.frames + 1 } }
  }
  // A packet can change the current state between two physical ticks. Refine
  // from the SAME committed recurrent anchor; never append a fictitious tick,
  // advance Transformer caches, or feed a prediction back as an observation.
  refine (observation, state, legalMasks = null, publicHealth = null, publicSpatial = null, publicThreat = null, publicMotion = null) {
    if (!state?.slow || observation.shape.length !== 2 || observation.shape[1] !== OBS_SIZE
        || state.fast.shape[0] !== observation.shape[0]) throw Error('Refinement needs an initialized physical-tick anchor')
    observation = this.projectPolicyInputs(observation, publicHealth, publicThreat, publicMotion)
    const fast = this.fast.step(observation, state.fast)
    return this.readout(observation, fast, state.slow, legalMasks, publicSpatial, publicThreat)
  }
  readout (observation, fast, slow, legalMasks, publicSpatial, publicThreat) {
    const features = tf.concat([observation, fast, slow], 1)
    const gate = this.gateMode === 'learned'
      ? tf.sigmoid(this.gateOut.apply(tf.tanh(this.gateIn.apply(features))))
      : tf.tile(this.fixedGate, [observation.shape[0], 1])
    const fastLogits = this.fastHeads.map(layer => layer.apply(fast))
    const slowLogits = this.slowHeads.map(layer => layer.apply(slow))
    const legacyLogits = fastLogits.map((head, index) => {
      const weight = gate.slice([0, index], [observation.shape[0], 1])
      return tf.add(tf.mul(tf.sub(1, weight), head), tf.mul(weight, slowLogits[index]))
    })
    const calibrated = this.config.distributionVersion >= 2
      ? probabilityMixture(fastLogits, slowLogits, gate, legalMasks) : null
    const logits = calibrated ? calibrated.map((head, index) =>
      !this.config.calibratedHeads || this.config.calibratedHeads.includes(index)
        ? head : legacyLogits[index]) : legacyLogits
    if (this.actionContextIn) {
      if(this.contextBaseCalibration){
        const scales=tf.mul(2,tf.sigmoid(this.contextBaseCalibration))
        for(const [i,h]of [2,5].entries())logits[h]=tf.mul(logits[h],scales.slice([i],[1]))
      }
      const contextInput=this.projectActionContext(observation)
      const context = tf.tanh(this.actionContextIn.apply(contextInput))
      for (const [index, head] of this.config.actionContextHeads.entries()) {
        // The timing residual can learn from stable physical quantities rather
        // than arena coordinates, style labels or compass heading. Both main
        // recurrent branches still see the complete public observation.
        const features = head === 4 && this.attackContextMask
          ? tf.tanh(this.actionContextIn.apply(tf.mul(contextInput, this.attackContextMask))) : context
        logits[head] = tf.add(logits[head], this.actionContextOut[index].apply(features))
      }
    }
    if(this.spatialMovementIn){
      const residual=this.spatialMovementResidual(observation,publicSpatial||Array(8).fill(0),publicThreat,{fast,slow})
      for(const[i,h]of this.spatialMovementHeads.entries())logits[h]=tf.add(logits[h],residual[i])
    }
    const value = tf.add(this.fastValue.apply(fast),
      tf.mul(tf.mean(gate, 1, true),
        this.valueOut.apply(tf.tanh(this.valueIn.apply(features)))))
    return { logits, fastLogits, slowLogits, value, gate }
  }
  dispose () { for (const variable of this.params) variable.dispose(); this.fixedGate.dispose(); this.attackContextMask?.dispose(); this.actionContextMask?.dispose() }
}

// Fuse comparable probabilities, not unbounded scores. A large slow-head
// logit can no longer erase the fast branch merely by having a larger scale.
// The small architectural floor keeps gradients available to both branches;
// it does not prescribe a combat action or depend on distance/weapon state.
export function probabilityMixture (fast, slow, gate, legalMasks = null) {
  const left = maskActionLogits(fast, legalMasks)
  const right = maskActionLogits(slow, legalMasks)
  return left.map((head, index) => {
    const weight = tf.add(.02, tf.mul(.96, gate.slice([0, index], [gate.shape[0], 1])))
    const logFast = tf.add(tf.logSoftmax(head), tf.log(tf.sub(1, weight)))
    const logSlow = tf.add(tf.logSoftmax(right[index]), tf.log(weight))
    return tf.logSumExp(tf.stack([logFast, logSlow]), 0)
  })
}

export function maskActionLogits (logits, legalMasks = null) {
  if (legalMasks == null) return logits
  if (!Array.isArray(legalMasks) || legalMasks.length !== logits.length)
    throw Error('legal mask head count mismatch')
  return logits.map((head, index) => {
    const legal = legalMasks[index]
    if (!Array.isArray(legal) || legal.length !== head.shape[1]
        || legal.some(value => typeof value !== 'boolean') || !legal.some(Boolean))
      throw Error(`invalid legal mask at head ${index}`)
    const mask = tf.tensor2d([legal], [1, legal.length], 'bool')
    const limited = tf.where(mask, head, tf.fill(head.shape, -1e9))
    mask.dispose()
    return limited
  })
}
export function actionLogProbability (logits, actions, executedHeads = null,
  legalMasks = null) {
  const masked = maskActionLogits(logits, legalMasks)
  const terms = masked.map((head, index) => {
    if (executedHeads?.[index] === false) return tf.scalar(0)
    const action = actions[index]
    if (!Number.isInteger(action) || action < 0 || action >= head.shape[1]
        || legalMasks?.[index]?.[action] === false)
      throw Error(`illegal executed action at head ${index}`)
    const oneHot = tf.oneHot([action], head.shape[1])
    const logProb = tf.sum(tf.mul(oneHot, tf.logSoftmax(head, -1)))
    return logProb
  })
  return tf.addN(terms)
}
export function gateRegularizer (gates, gateMode, warmup = 1) {
  if (gateMode !== 'learned') return tf.scalar(0)
  const values = tf.concat(gates, 0)
  const target = tf.tensor1d(GATE_TARGET)
  const balance = tf.mean(tf.square(tf.sub(tf.mean(values, 0), target)))
  const specialization = tf.mean(tf.mul(values, tf.sub(1, values)))
  return tf.mul(warmup, tf.add(tf.mul(.01, balance), tf.mul(.001, specialization)))
}
export function computeGAE (episodes, gamma = .997, lambda = .99) {
  const prepared = episodes.map(episode => {
    let advantage = 0, nextValue = episode.bootstrapValue || 0
    const frames = episode.map(frame => ({ ...frame }))
    for (let index = frames.length - 1; index >= 0; index--) {
      const frame = frames[index]
      const live = frame.done ? 0 : 1
      const delta = frame.reward + gamma * nextValue * live - frame.oldValue
      advantage = delta + gamma * lambda * live * advantage
      frame.advantage = advantage
      frame.target = advantage + frame.oldValue
      nextValue = frame.oldValue
    }
    return frames
  })
  const all = prepared.flat().map(frame => frame.advantage)
  const mean = all.reduce((sum, value) => sum + value, 0) / all.length
  const variance = all.reduce((sum, value) => sum + (value - mean) ** 2, 0) / all.length
  for (const frame of prepared.flat())
    frame.advantage = (frame.advantage - mean) / (Math.sqrt(variance) + 1e-6)
  return prepared
}
export function ppoLoss (model, episodes, { clip = .2, valueCoef = .5,
  entropyCoef = .0001, gateWarmup = 1 } = {}) {
  if (!episodes.length || episodes.some(episode => !episode.length))
    throw Error('PPO needs completed actor episodes')
  const policyLosses = [], valueLosses = [], entropies = [], gates = []
  for (const episode of episodes) {
    let state = episode.initialState || model.initialState()
    for (const frame of episode) {
      const observation = tf.tensor2d([frame.observation], [1, OBS_SIZE])
      const output = model.step(observation, state, frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures)
      state = output.state
      const biased = biasedActionLogits(output.logits, frame.observation, frame.context, frame.actions,
        model, frame.publicHealthFeatures)
      const masked = maskActionLogits(biased, frame.legalMasks)
      const advantage = tf.scalar(frame.advantage)
      // Clip each executed control head separately. A product of seven head
      // probabilities can yield a huge ratio from one bad frame and push every
      // action head toward the same deterministic move.
      const headLosses = masked.flatMap((head, index) => {
        if (!frame.executedHeads[index]) return []
        const action = frame.actions[index]
        const oneHot = tf.oneHot([action], head.shape[1])
        const newLog = tf.sum(tf.mul(oneHot, tf.logSoftmax(head, -1)))
        const ratio = tf.exp(tf.sub(newLog, frame.oldHeadLogProbs[index]))
        const unclipped = tf.mul(ratio, advantage)
        const clipped = tf.mul(tf.clipByValue(ratio, 1 - clip, 1 + clip), advantage)
        return [tf.neg(tf.minimum(unclipped, clipped))]
      })
      policyLosses.push(headLosses.length
        ? tf.mean(tf.stack(headLosses)) : tf.scalar(0))
      valueLosses.push(tf.square(tf.sub(tf.squeeze(output.value), frame.target)))
      const headEntropies = masked.map((head, index) => {
        if (!frame.executedHeads[index]) return tf.scalar(0)
        const probability = tf.softmax(head, -1)
        return tf.neg(tf.sum(tf.mul(probability, tf.logSoftmax(head, -1))))
      })
      entropies.push(tf.div(tf.addN(headEntropies),
        Math.max(1, frame.executedHeads.filter(Boolean).length)))
      gates.push(output.gate)
    }
  }
  const policy = tf.mean(tf.stack(policyLosses))
  const value = tf.mean(tf.stack(valueLosses))
  const entropy = tf.mean(tf.stack(entropies))
  return tf.addN([policy, tf.mul(valueCoef, value), tf.mul(-entropyCoef, entropy),
    gateRegularizer(gates, model.gateMode, gateWarmup)])
}
export function ppoUpdate (model, optimizer, episodes, options = {}) {
  return tf.tidy(() => {
    const { value, grads } = tf.variableGrads(
      () => ppoLoss(model, episodes, options), model.params)
    const squared = Object.values(grads).map(gradient =>
      tf.sum(tf.square(gradient)))
    const norm = Math.sqrt(tf.addN(squared).dataSync()[0])
    if (!Number.isFinite(norm)) throw Error('Non-finite PPO gradient')
    const scale = Math.min(1, 1 / Math.max(norm, 1e-12))
    const clipped = Object.fromEntries(Object.entries(grads).map(([name, gradient]) =>
      [name, tf.mul(gradient, scale)]))
    const result = { loss: value.dataSync()[0], gradientNorm: norm,
      clipScale: scale }
    optimizer.applyGradients(clipped)
    return result
  })
}
