package local.wavedog.protocol;

import com.google.gson.*;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import io.papermc.paper.event.player.PlayerShieldDisableEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

/** Referee and native receipts only. Combat movement, use and attacks are client inputs. */
public final class ProtocolCore extends JavaPlugin implements Listener, PluginMessageListener {
    private static final String CHANNEL="wavedog:control", BOT="WaveDog_test";
    private final Gson json=new Gson();
    private String token, match, opponent, policySha="unknown";
    private int preparedAt, startAt, endAt;
    private long heartbeat;
    private boolean ready, active, preparing, learning;
    private final Map<Long,Intent> intents=new HashMap<>();
    private Intent actual;
    private final java.util.concurrent.BlockingQueue<String> records=new java.util.concurrent.LinkedBlockingQueue<>(16384);
    private volatile boolean writing;
    private Thread writer;
    private static final class Intent {
        final long id; final String kind; final UUID target; final int requested;
        int actualTick=-1; boolean consumed;
        Intent(long id,String kind,UUID target,int tick){this.id=id;this.kind=kind;this.target=target;this.requested=tick;}
    }
    @Override public void onEnable(){
        try {
            Files.createDirectories(getDataFolder().toPath());
            token=UUID.randomUUID().toString();
            Files.writeString(getDataFolder().toPath().resolve("client-token.txt"),token);
        } catch(Exception e){throw new IllegalStateException(e);}
        getServer().getMessenger().registerIncomingPluginChannel(this,CHANNEL,this);
        getServer().getMessenger().registerOutgoingPluginChannel(this,CHANNEL);
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("wdcore")).setExecutor(this);
        writing=true;
        writer=new Thread(()->{
            Path file=getDataFolder().toPath().resolve("native-events.jsonl");
            while(writing||!records.isEmpty())try{
                String line=records.poll(250,java.util.concurrent.TimeUnit.MILLISECONDS);
                if(line!=null)Files.writeString(file,line+"\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);
            }catch(InterruptedException e){break;}catch(Exception e){getLogger().warning("Native journal: "+e);}
        },"WaveDog-native-journal");writer.setDaemon(true);writer.start();
        getServer().getScheduler().runTaskTimer(this,this::tick,1,1);
    }
    @Override public void onDisable(){finish("plugin-disable",null);writing=false;
        try{if(writer!=null)writer.join(2000);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private Player bot(){return Bukkit.getPlayerExact(BOT);}
    private boolean authenticated(Player p){
        var auth=Bukkit.getPluginManager().getPlugin("AuthMe");
        if(auth==null)return true;
        try{Class<?> api=Class.forName("fr.xephi.authme.api.v3.AuthMeApi",true,auth.getClass().getClassLoader());
            Object instance=api.getMethod("getInstance").invoke(null);
            return (boolean)api.getMethod("isAuthenticated",Player.class).invoke(instance,p);
        }catch(Exception e){return false;}
    }
    private void send(Map<String,Object> row){Player p=bot();if(p==null)return;
        var data=new LinkedHashMap<String,Object>(row);data.put("serverTick",Bukkit.getCurrentTick());
        if(match!=null)data.put("matchId",match);
        p.sendPluginMessage(this,CHANNEL,json.toJson(data).getBytes(StandardCharsets.UTF_8));}
    private void record(String type,Map<String,Object> fields){
        var row=new LinkedHashMap<String,Object>();row.put("at",java.time.Instant.now().toString());
        row.put("type",type);row.put("serverTick",Bukkit.getCurrentTick());row.put("matchId",match);row.putAll(fields);
        if(!records.offer(json.toJson(row)))getLogger().severe("Native journal full; record incomplete");
    }
    @Override public void onPluginMessageReceived(String channel,Player source,byte[] bytes){
        if(!CHANNEL.equals(channel)||!source.getName().equals(BOT)||!authenticated(source)||bytes.length>16000)return;
        try{
            JsonObject row=json.fromJson(new String(bytes,StandardCharsets.UTF_8),JsonObject.class);
            if(!token.equals(row.get("token").getAsString()))return;
            String type=row.get("type").getAsString();
            if(type.equals("heartbeat")){
                heartbeat=System.currentTimeMillis();ready=row.has("modelReady")&&row.get("modelReady").getAsBoolean();
                if(row.has("policySha"))policySha=row.get("policySha").getAsString();
                // Recover a persisted receipt after an old client or a lost
                // acknowledgement, never by clearing the gate on a timeout.
                if(learning&&!active&&!preparing&&match!=null){
                    Path runtime=Path.of("D:/CodexWorkspace/ban/work/wavedog-protocol/runtime");
                    Path report=runtime.resolve(match+"-report.json"),trained=runtime.resolve(match+"-training.json");
                    if(Files.isRegularFile(report)&&Files.isRegularFile(trained)){
                        JsonObject saved=json.fromJson(Files.readString(trained),JsonObject.class);
                        JsonObject bout=json.fromJson(Files.readString(report),JsonObject.class);
                        String event=saved.get("event").getAsString();
                        if((event.equals("trained")||event.equals("trained_partial"))
                            &&(!saved.has("quarantined")||!saved.get("quarantined").getAsBoolean())
                            &&"WaveDog".equals(saved.get("fighter").getAsString())&&match.equals(bout.get("matchId").getAsString())
                            &&bout.get("frames").getAsInt()>0&&Files.isRegularFile(Path.of(bout.get("completedFrames").getAsString()))){
                            learning=false;record("shared_merge_recovered",Map.of("sha256",saved.get("sha256").getAsString()));
                            Bukkit.broadcastMessage("§b[WaveDog_test] 本局轨迹、学习回执及检查点已保存，开战入口已就绪。");
                        }
                    }
                }
                send(Map.of("type","heartbeat_ack","active",active,"preparing",preparing));return;
            }
            if(type.equals("reviewed")&&row.has("matchId")){
                record("qwen_review",Map.of("reviewedMatchId",row.get("matchId").getAsString()));
                Bukkit.broadcastMessage("§b[WaveDog_test] Qwen 对局复盘已保存（"+row.get("matchId").getAsString().substring(0,8)+"）。");return;
            }
            if(!row.has("matchId")||!Objects.equals(match,row.get("matchId").getAsString()))return;
            if(type.equals("attack_intent")&&active){
                Player target=Bukkit.getPlayerExact(opponent);
                if(target==null||!opponent.equals(row.get("target").getAsString()))return;
                long id=row.get("attackId").getAsLong();
                intents.put(id,new Intent(id,row.get("kind").getAsString(),target.getUniqueId(),Bukkit.getCurrentTick()));
            }else if(type.equals("merged")){
                if(!row.has("persisted")||!row.get("persisted").getAsBoolean()){
                    record("merge_not_persisted",Map.of("reason","missing durable client receipt"));return;
                }
                learning=false;record("shared_merge",Map.of("sha256",row.get("sha256").getAsString()));
                Bukkit.broadcastMessage("§b[WaveDog_test] 本局分身已汇总：PPO 更新 GRU / Transformer / 门控，检查点已保存。开战入口已开放。");
            }else if(type.equals("learning_error")){
                learning=true;record("learning_error",Map.of("reason",row.get("reason").getAsString()));
                Bukkit.broadcastMessage("§c[WaveDog_test] 本局学习尚未成功，原始轨迹已保留。");
            }
        }catch(Exception e){getLogger().warning("Invalid WaveDog control message: "+e.getClass().getSimpleName());}
    }
    private void tick(){
        // These are the player's own HUD/item states, never hidden opponent
        // telemetry. A use packet is a request, not confirmation of blocking.
        Player own=bot();
        if(active&&own!=null)send(Map.of("type","self_state",
            "shieldCooldown",own.getCooldown(Material.SHIELD),"shielding",own.isBlocking(),
            "using",own.hasActiveItem(),"useTicks",own.getHandRaisedTime(),
            "activeItem",own.hasActiveItem()?own.getActiveItem().getType().name():"AIR",
            "charge",own.getCooledAttackStrength(0),"held",own.getInventory().getHeldItemSlot(),
            "fallDistance",own.getFallDistance()));
        intents.values().removeIf(i->Bukkit.getCurrentTick()-i.requested>6);
        if((active||preparing)&&(bot()==null||!ready||System.currentTimeMillis()-heartbeat>6000)){
            finish("controller-offline",null);return;}
        if(preparing&&Bukkit.getCurrentTick()>=startAt){
            preparing=false;active=true;endAt=Bukkit.getCurrentTick()+2400;
            send(Map.of("type","start","opponent",opponent));record("start",Map.of("opponent",opponent,"policySha",policySha));
            Player p=Bukkit.getPlayerExact(opponent);if(p!=null)p.sendMessage("§bWaveDog_test 对战开始。");
        }
        if(active&&Bukkit.getCurrentTick()>=endAt)finish("time-limit",null);
    }
    private ItemStack crossbow(){
        ItemStack item=new ItemStack(Material.CROSSBOW);CrossbowMeta meta=(CrossbowMeta)item.getItemMeta();
        meta.addChargedProjectile(new ItemStack(Material.ARROW));item.setItemMeta(meta);return item;
    }
    private void equipBot(Player p){
        var i=p.getInventory();i.clear();i.setItem(0,new ItemStack(Material.DIAMOND_SWORD));
        i.setItem(1,new ItemStack(Material.BOW));i.setItem(2,new ItemStack(Material.ARROW,5));
        i.setItem(4,crossbow());i.setItem(7,new ItemStack(Material.DIAMOND_AXE));i.setHeldItemSlot(7);
        i.setItemInOffHand(new ItemStack(Material.SHIELD));
        i.setHelmet(new ItemStack(Material.DIAMOND_HELMET));i.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        i.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));i.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.setGameMode(GameMode.SURVIVAL);p.setHealth(20);p.setFoodLevel(20);p.setSaturation(5);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
        p.updateInventory();
    }
    private void humanKit(Player p){
        var i=p.getInventory();
        for(Material m:List.of(Material.DIAMOND_SWORD,Material.DIAMOND_AXE,Material.BOW,Material.CROSSBOW,Material.SHIELD))
            if(!i.contains(m)&&i.getItemInOffHand().getType()!=m)i.addItem(new ItemStack(m));
        if(!i.contains(Material.ARROW))i.addItem(new ItemStack(Material.ARROW,5));
        if(i.getItemInOffHand().getType()==Material.AIR){i.removeItem(new ItemStack(Material.SHIELD));i.setItemInOffHand(new ItemStack(Material.SHIELD));}
        if(i.getHelmet()==null||i.getHelmet().getType().isAir())i.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        if(i.getChestplate()==null||i.getChestplate().getType().isAir())i.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        if(i.getLeggings()==null||i.getLeggings().getType().isAir())i.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        if(i.getBoots()==null||i.getBoots().getType().isAir())i.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.setHealth(20);p.setFoodLevel(20);p.setSaturation(5);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
    }
    private Location startLocation(Player p){
        Location origin=p.getLocation();
        for(int r:new int[]{7,6,5,4,3})for(int a=0;a<8;a++){
            Location at=origin.clone().add(Math.cos(a*Math.PI/4)*r,0,Math.sin(a*Math.PI/4)*r);
            if(at.getBlock().isPassable()&&at.clone().add(0,1,0).getBlock().isPassable()
                &&at.clone().add(0,-.15,0).getBlock().getType().isSolid())return at;
        }
        return null;
    }
    private void finish(String reason,String winner){
        if(!active&&!preparing)return;
        boolean hadFrames=active;active=preparing=false;learning=hadFrames;endAt=Bukkit.getCurrentTick();
        send(Map.of("type","end","reason",reason,"winner",winner==null?"":winner,"hadFrames",hadFrames));
        record("end",Map.of("reason",reason,"winner",winner==null?"":winner));
        World arena=Bukkit.getWorld("world");int removed=0;
        if(arena!=null)for(Entity entity:arena.getEntities()){
            if(!(entity instanceof Item)&&!(entity instanceof ExperienceOrb))continue;
            Location l=entity.getLocation();
            if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<219||l.getY()>240)continue;
            entity.remove();removed++;
        }
        record("arena_cleanup",Map.of("phase","end","removed",removed));
        Player p=opponent==null?null:Bukkit.getPlayerExact(opponent);
        if(p!=null)p.sendMessage("§bWaveDog_test 本局结束："+(winner==null?reason:"胜者 "+winner)
            +(hadFrames?"。正在保存轨迹并进行 PPO 更新，期间不能开下一局；蓝字提示入口开放后即可再按。":"。准备已取消，入口已开放。"));
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.hasPermission("wavedog.control"))return true;
        String sub=args.length>0?args[0].toLowerCase(Locale.ROOT):"status";
        if(sub.equals("status")){
            sender.sendMessage("§bWaveDog_test 协议玩家="+(bot()!=null)+"，模型="+ready+"，对局="+(active?"进行中":preparing?"准备中":"空闲")
                +"，汇总="+learning+"，权重="+policySha.substring(0,Math.min(16,policySha.length()))
                +(learning?"；上一局已结束，正在保存／更新，入口暂未开放。":""));return true;}
        if(sub.equals("stop")){finish("operator-stop",null);sender.sendMessage("§b已停止 WaveDog 对战。");return true;}
        if(!sub.equals("duel")||args.length!=2){sender.sendMessage("/wavedog duel 玩家名 | stop | status");return true;}
        if(active||preparing){sender.sendMessage("§e当前仍在"+(active?"对战":"准备")+" "+opponent+"，请等本局结束。");return true;}
        if(learning){
            String phase="正在保存轨迹并等待 PPO 更新回执";
            try{
                Path runtime=Path.of("D:/CodexWorkspace/ban/work/wavedog-protocol/runtime");
                if(Files.isRegularFile(runtime.resolve(match+"-report.json")))phase="轨迹已保存，PPO 正在排队或更新";
                Path trained=runtime.resolve(match+"-training.json");
                if(Files.isRegularFile(trained)){
                    JsonObject saved=json.fromJson(Files.readString(trained),JsonObject.class);
                    if(saved.has("event")&&saved.get("event").getAsString().equals("training_error")
                        ||saved.has("quarantined")&&saved.get("quarantined").getAsBoolean())
                        phase="更新未通过，原始轨迹已保留，请管理员检查学习回执";
                    else phase="学习回执已落盘，正在确认入口开放";
                }
            }catch(Exception ignored){phase="正在核对保存状态";}
            sender.sendMessage("§e上一局已经结束；"+phase+"。收到蓝字‘开战入口已开放’后再按即可。");return true;
        }
        Player target=Bukkit.getPlayerExact(args[1]), bot=bot();
        if(bot==null||!ready||System.currentTimeMillis()-heartbeat>5000){sender.sendMessage("§cWaveDog 协议客户端或共享模型尚未就绪。");return true;}
        if(target==null||target==bot||target.isDead()||target.getName().startsWith("NBot")
            ||target.getGameMode()!=GameMode.SURVIVAL||!authenticated(target)||!authenticated(bot)){
            sender.sendMessage("§c目标须为已登录、存活的生存模式真人玩家。");return true;}
        Location at=startLocation(target);
        if(at==null){sender.sendMessage("§c附近没有安全站位，请在空旷平地发起对战。");return true;}
        match=UUID.randomUUID().toString();opponent=target.getName();intents.clear();actual=null;
        World arena=Bukkit.getWorld("world");int removed=0;
        if(arena!=null)for(Entity entity:arena.getEntities()){
            if(!(entity instanceof Item)&&!(entity instanceof ExperienceOrb))continue;
            Location l=entity.getLocation();
            if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<219||l.getY()>240)continue;
            entity.remove();removed++;
        }
        record("arena_cleanup",Map.of("phase","prepare","removed",removed));
        equipBot(bot);humanKit(target);bot.teleport(at); // Referee setup only, never combat movement.
        preparedAt=Bukkit.getCurrentTick();startAt=preparedAt+100;preparing=true;
        send(Map.of("type","prepare","opponent",opponent,"startAfterTicks",100));
        sender.sendMessage("§bWaveDog_test（机械＋Transformer／GRU）将在 5 秒后对战 "+opponent+"。");
        target.sendMessage("§b已安排你对战 WaveDog，5 秒准备。使用 /wavedog_test stop 停止。");
        record("prepare",Map.of("opponent",opponent,"policySha",policySha));return true;
    }
    private boolean participant(Player p){return p.getName().equals(BOT)||p.getName().equals(opponent);}
    @EventHandler(priority=EventPriority.HIGHEST) public void preparationDamage(EntityDamageEvent e){
        if(preparing&&e.getEntity() instanceof Player p&&participant(p))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.MONITOR) public void packet(PrePlayerAttackEntityEvent e){
        if(e.getPlayer().getName().equals(BOT))actual=null;
        if(!active||!e.getPlayer().getName().equals(BOT)||!(e.getAttacked() instanceof Player target)
            ||!target.getName().equals(opponent))return;
        Intent found=intents.values().stream().filter(i->!i.consumed&&i.actualTick<0&&i.target.equals(target.getUniqueId())
            &&Bukkit.getCurrentTick()-i.requested<=2).max(Comparator.comparingLong(i->i.id)).orElse(null);
        if(found==null){record("unclaimed_attack_packet",Map.of("target",target.getName()));return;}
        found.actualTick=Bukkit.getCurrentTick();if(e.willAttack())actual=found;
        send(Map.of("type","attack_packet","attackId",found.id,"kind",found.kind,"willAttack",e.willAttack()));
        record("attack_packet",Map.of("attackId",found.id,"kind",found.kind,"target",target.getName(),"willAttack",e.willAttack()));
    }
    @EventHandler(priority=EventPriority.MONITOR) public void damage(EntityDamageByEntityEvent e){
        if(!e.isCancelled()&&e.getEntity() instanceof Player hit){
            Player source=e.getDamager() instanceof Player p?p:e.getDamager() instanceof Projectile shot&&shot.getShooter() instanceof Player p?p:null;
            Location l=hit.getLocation();
            if(source!=null&&source!=hit&&l.getWorld().getName().equals("world")&&l.getX()>=990&&l.getX()<=1039
                &&l.getZ()>=990&&l.getZ()<=1039&&l.getY()>=219&&l.getY()<=240){
                var mark=new org.bukkit.metadata.FixedMetadataValue(this,Bukkit.getCurrentTick());
                hit.setMetadata("wavedog-last-combat",mark);source.setMetadata("wavedog-last-combat",mark);
            }
        }
        if(!active||!(e.getEntity() instanceof Player victim)||!participant(victim))return;
        Player attacker=e.getDamager() instanceof Player p?p:e.getDamager() instanceof Projectile shot&&shot.getShooter() instanceof Player p?p:null;
        if(attacker==null||!participant(attacker)||attacker==victim)return;
        boolean melee=e.getDamager() instanceof Player;
        double shield=e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)?e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING):0;
        if(melee&&!e.isCancelled()&&victim.getName().equals(BOT)&&shield<-.001){
            var block=Map.<String,Object>of("type","blocked_melee","attacker",attacker.getName(),"blockId",Bukkit.getCurrentTick(),"shieldDisabled",victim.hasCooldown(Material.SHIELD));
            send(block);record("blocked_melee",block);
        }
        long id=-1;
        if(melee&&attacker.getName().equals(BOT)&&actual!=null&&!actual.consumed&&actual.target.equals(victim.getUniqueId())
            &&Bukkit.getCurrentTick()-actual.actualTick<=1){id=actual.id;actual.consumed=true;}
        var row=new LinkedHashMap<String,Object>();row.put("type","damage");row.put("attacker",attacker.getName());row.put("victim",victim.getName());
        row.put("amount",e.getFinalDamage());row.put("cancelled",e.isCancelled());row.put("melee",melee);row.put("attackId",id);
        row.put("nativeCritical",e.isCritical());row.put("shieldModifier",shield);
        send(row);record("damage",row);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void disable(PlayerShieldDisableEvent e){
        if(active&&e.getPlayer().getName().equals(BOT)){
            send(Map.of("type","shield_disabled","cooldownTicks",e.getCooldown()));
            record("shield_disabled",Map.of("cooldownTicks",e.getCooldown()));
        }
    }
    @EventHandler public void death(PlayerDeathEvent e){
        Location here=e.getEntity().getLocation();
        if(here.getWorld().getName().equals("world")&&here.getX()>=990&&here.getX()<=1039
            &&here.getZ()>=990&&here.getZ()<=1039&&here.getY()>=219&&here.getY()<=240){
            // Human-v-human rounds use the same pen without a core duel.
            // Their death is also a round boundary; suppress this death's
            // pending drops and remove only existing items/XP inside the pen.
            e.getDrops().clear();e.setDroppedExp(0);int removed=0;
            for(Entity entity:here.getWorld().getEntities()){
                if(!(entity instanceof Item)&&!(entity instanceof ExperienceOrb))continue;
                Location l=entity.getLocation();
                if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<219||l.getY()>240)continue;
                entity.remove();removed++;
            }
            record("arena_cleanup",Map.of("phase","player-death","removed",removed));
        }
        if(!active||!participant(e.getEntity()))return;
        e.setKeepInventory(true);e.getDrops().clear();e.setKeepLevel(true);e.setDroppedExp(0);
        finish("death",e.getEntity().getName().equals(BOT)?opponent:BOT);
    }
    @EventHandler public void quit(PlayerQuitEvent e){if((active||preparing)&&participant(e.getPlayer()))finish("disconnect",null);
        if(e.getPlayer().getName().equals(BOT))ready=false;}
    @EventHandler public void respawn(PlayerRespawnEvent e){if(e.getPlayer().getName().equals(BOT))ready=false;}
}
