'use strict'
// Only public motion plus our own inventory/cooldown. Prediction is bounded
// evidence for a defensive option, never an opponent-key or crit guarantee.
function eyeBox(eye,box){
  return Math.hypot(Math.max(0,Math.abs(eye.x-box.x)-.3),
    Math.max(0,box.y-eye.y,eye.y-box.y-1.8),Math.max(0,Math.abs(eye.z-box.z)-.3))
}
function criticalReply({enabled,self,target,velocity,reach,charge,shieldReady,ageMs=0,pingMs=0,
  defenseCandidates=[],incomingRange=3}){
  if(!enabled||!target.airborne||ageMs>120)return {action:'ground',threat:false}
  const delay=Math.max(1,Math.ceil((50+pingMs/2+ageMs)/50))
  let p={...target},v={...velocity},first=null,ascent=null
  for(let dt=0;dt<=10;dt++){
    if(dt>0&&p.y<=target.floorY+.01&&v.y<=0)break
    const own={x:self.x+self.vx*dt,y:self.y,z:self.z+self.vz*dt}
    const uncertainty=.04+.035*dt+.013*dt*(dt+1)
    const eye={x:p.x,y:p.y+1.62,z:p.z}
    let distance=eyeBox(eye,own)-uncertainty
    for(const candidate of defenseCandidates){
      if(candidate.ticksRemaining<dt||!['x','y','z'].every(k=>Number.isFinite(candidate[k])))continue
      distance=Math.min(distance,eyeBox(eye,candidate)-uncertainty)
    }
    if(v.y<=.04&&ascent===null)ascent=dt
    if(v.y<=.04&&distance<=incomingRange+.05&&first===null)first=dt
    p.x+=v.x;p.y+=v.y;p.z+=v.z;v.x*=.91;v.z*=.91;v.y=(v.y-.08)*.98
  }
  if(first===null)return {action:'ground',threat:false}
  const interrupt=velocity.y>.1&&ascent>delay+1&&reach<=3&&charge>.9
  return {action:interrupt?'interrupt':shieldReady?'shield':'ground-escape',threat:true,
    criticalEta:first,ascentRemaining:ascent,attackDelayTicks:delay,
    defenseHistoryUsed:defenseCandidates.length>0,clientViewEstimated:defenseCandidates.length>0}
}
module.exports={criticalReply}
