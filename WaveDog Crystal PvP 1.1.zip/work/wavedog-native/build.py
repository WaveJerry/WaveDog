from pathlib import Path
import hashlib,json,os,subprocess,zipfile,sys,argparse
sys.stdout.reconfigure(encoding='utf8')
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['A'],default='A');parser.add_argument('--output-dir',type=Path,default=BASE)
options=parser.parse_args();destination=options.output_dir.resolve();destination.mkdir(parents=True,exist_ok=True)
SERVER=Path(os.environ.get('WAVEDOG_SERVER_ROOT','D:/Walt Disney/Minecraft-1.21.1-Server'));JAVA=Path(os.environ.get('WAVEDOG_JAVA_BIN',str(SERVER/'runtime/java21/bin')))
classes=BASE/'classes';classes.mkdir(exist_ok=True)
api=next((SERVER/'libraries/io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT').glob('*.jar'))
cp=os.pathsep.join(map(str,[SERVER/'versions/1.21.11/paper-1.21.11.jar',api,*sorted((SERVER/'libraries').rglob('*.jar'),reverse=True),*sorted((BASE/'lib').glob('*.jar'))]))
sources=sorted((BASE/'src').rglob('*.java'))
args=['-proc:none','--release','21','-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,sources)]
argfile=BASE/'compile.args'
argfile.write_text('\n'.join('"'+arg.replace('\\','\\\\').replace('"','\\"')+'"' for arg in args))
result=subprocess.run([str(JAVA/'javac.exe'),'-J-Duser.language=en','@'+str(argfile)],capture_output=True,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
(BASE/'compile.log').write_text(result.stdout+result.stderr,encoding='utf8')
if result.returncode:print((result.stdout+result.stderr)[-10000:]);raise SystemExit(result.returncode)
files={name:(ROOT/'work/pvp-player-client'/name) for name in ['protocol-ground-son-brain.js','protocol-unified-son-brain.js','protocol-legacy86-threat.js','protocol-legacy86-ranged.js','wavedog-arrow-predictor.js','protocol-legacy86-route.js','protocol-ranged-aim.js']}
files['ground-son-critical.cjs']=ROOT/'work/wavedog-protocol/ground-son-critical.cjs'
for name in ['protocol-son-shield-script.js','protocol-pilot-mechanical-brain.js','protocol-mechanical-math.js']:
    files[name]=ROOT/'work/pvp-player-client'/name
resources={name:file.read_bytes() for name,file in files.items()}
profile={'id':'A','name':'axe-short-recovery','axeSpacing':True,'shieldScript':False,'retreatMode':'short-ground','punishmentShieldMode':True,'bGuardActions':True,'requireAxeBeforeSword':True,'unifiedShortPhases':True,
    'bowSynchronization':False,'crossbowSynchronization':True,'legacySwordFallback':True,'rangedShieldOnly':True}
resources['protocol-son-profile.js']=('"use strict";module.exports=Object.freeze('+json.dumps(profile,separators=(',',':'))+');\n').encode()
manifest={name:hashlib.sha256(raw).hexdigest() for name,raw in resources.items()}
sha=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
jar=destination/'WaveDogNativeControl.jar';services={};written=set()
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as output:
    def put(name,data):
        if name in written:raise RuntimeError('Duplicate native bundle entry '+name)
        written.add(name);output.writestr(name,data)
    put('META-INF/MANIFEST.MF',b'Manifest-Version: 1.0\r\npaperweight-mappings-namespace: mojang\r\n\r\n')
    for file in sorted(classes.rglob('*.class')):put(file.relative_to(classes).as_posix(),file.read_bytes())
    for name in ['plugin.yml','policy-bootstrap.js']:put(name,(BASE/name).read_bytes())
    put('policy-manifest.json',json.dumps({'files':manifest,'sha256':sha,'bootstrapSha256':hashlib.sha256((BASE/'policy-bootstrap.js').read_bytes()).hexdigest()}).encode())
    for name,raw in resources.items():put('policy/'+name,raw)
    for dep in sorted((BASE/'lib').glob('javet*.jar')):
        with zipfile.ZipFile(dep) as archive:
            for entry in archive.infolist():
                name=entry.filename
                if entry.is_dir() or name=='META-INF/MANIFEST.MF' or name.endswith(('module-info.class','.SF','.RSA','.DSA')):continue
                data=archive.read(entry)
                if name.startswith('META-INF/services/'):services.setdefault(name,set()).update(data.decode().splitlines())
                elif name not in written:put(name,data)
    for name,items in services.items():put(name,('\n'.join(sorted(items))+'\n').encode())
receipt={'jar':str(jar),'bytes':jar.stat().st_size,'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'policySha256':sha,'sourceSha256':manifest,'profile':profile,'installed':False}
(destination/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
