package local.wavedog.nativecontrol;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.util.Vector;

/** Available only with the isolated JVM fixture flag; never opens a main-server duel. */
class NativeMechanicsProbe implements Listener {
    final NativeControl owner;final NativeControl.Actor a,b;final List<Map<String,Object>> results=new ArrayList<>();
    int elapsed,shots;double startZ,maxY,lastDamage;boolean falling,done,nativeCritical;double healthBefore;int shieldBefore;
    boolean cancelNextAttack;int jumps,groundControlHits;double shieldPreZ;final List<Double> sprintTrace=new ArrayList<>();
    final List<Map<String,Object>> comboHits=new ArrayList<>();
    boolean punishmentTried,punishmentBlocked;double punishmentHealthBefore;
    boolean advancedOnly,filterGroundKnockback,axeProfile,jumpRecoveryProfile;String filteredHitKind;int retreatStun=-1,retreatSword=-1;
    final List<Map<String,Object>> activeComboHits=new ArrayList<>();
    boolean recoveryLaunched,recoveryAirSeen,recoveryLanded,recoveryHeld;double recoveryHx,recoveryHz;int recoveryFlightFrames;
    boolean bModeEntered,bCriticalAttempted,bCriticalBlocked,bReturnedToA;double bHealth;int nonSwordRecoveryJumps;
    boolean bStealDone,bStealReblocked;Map<String,Object> bStealActual,bExitActual;
    void beginRecoveryCheck(){recoveryLaunched=recoveryAirSeen=recoveryLanded=false;recoveryHeld=true;recoveryFlightFrames=0;nonSwordRecoveryJumps=0;}
    void checkRecoveryFrame(Map<String,Object> actual,Map<String,Object> plan){
        @SuppressWarnings("unchecked") var c=(Map<String,Object>)plan.get("command");
        @SuppressWarnings("unchecked") var h=(Map<String,Object>)c.get("worldHeading");
        if(Boolean.TRUE.equals(actual.get("jump"))&&!"old-transformer-sword-fallback".equals(c.get("intent")))nonSwordRecoveryJumps++;
        if(Boolean.TRUE.equals(actual.get("jump"))&&!recoveryLaunched&&h!=null){
            recoveryLaunched=true;recoveryHx=((Number)h.get("x")).doubleValue();recoveryHz=((Number)h.get("z")).doubleValue();
        }
        if(!recoveryLaunched||recoveryLanded)return;
        if(!p().isOnGround())recoveryAirSeen=true;
        if(recoveryAirSeen&&p().isOnGround()){recoveryLanded=true;return;}
        recoveryFlightFrames++;
        double dot=h==null?-1:recoveryHx*((Number)h.get("x")).doubleValue()+recoveryHz*((Number)h.get("z")).doubleValue();
        recoveryHeld&=Boolean.TRUE.equals(actual.get("sprint"))&&((Number)actual.get("forward")).doubleValue()>.99
            &&Math.abs(((Number)actual.get("side")).doubleValue())<.01&&dot>.99;
    }
    NativeMechanicsProbe(NativeControl owner)throws Exception{
        this.owner=owner;a=owner.actors.get("WaveDog");b=owner.actors.get("WaveDogSon");
        if(a.handle==null||b.handle==null)throw new IllegalStateException("Spawn both isolated actors first");
        owner.policy.runtime.getGlobalObject().set("nativeFixtureLegacy",true);
        axeProfile=owner.policy.runtime.getExecutor("nativeControlProfile.axeSpacing").executeBoolean();
        jumpRecoveryProfile=owner.policy.runtime.getExecutor("nativeControlProfile.retreatMode !== 'short-ground'").executeBoolean();
        owner.policy.reset(a.name,b.name);owner.policy.reset(b.name,a.name);
        Bukkit.getPluginManager().registerEvents(this,owner);pose(12);
    }
    Player p(){return a.player();}Player q(){return b.player();}
    void mark(String name,boolean pass,Map<String,Object> evidence){
        var row=new LinkedHashMap<String,Object>(evidence);row.put("case",name);row.put("pass",pass);results.add(row);
        owner.getLogger().info("NATIVE_FIXTURE "+NativeControl.JSON.toJson(row));
    }
    void pose(double gap){
        World world=p().getWorld();
        for(int x=998;x<=1030;x++)for(int z=998;z<=1032;z++)world.getBlockAt(x,220,z).setType(Material.STONE,false);
        for(var actor:List.of(a,b)){
            owner.hold(actor);var player=actor.player();player.setHealth(20);player.setFoodLevel(20);player.setSaturation(5);player.setNoDamageTicks(0);player.setCooldown(Material.SHIELD,0);
            player.getInventory().clear();player.getInventory().setItem(0,new ItemStack(Material.DIAMOND_SWORD));player.getInventory().setItem(7,new ItemStack(Material.DIAMOND_AXE));player.getInventory().setItem(2,new ItemStack(Material.ARROW,8));
            player.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));player.getInventory().setHeldItemSlot(0);
        }
        p().teleport(new Location(world,1014.5,221,1005.5,0,0));q().teleport(new Location(world,1014.5,221,1005.5+gap,180,0));
        for(var actor:List.of(a,b)){actor.handle.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);actor.handle.queuedMotion=null;actor.handle.setOnGround(true);
            owner.positions.put(actor.player().getUniqueId(),actor.player().getLocation());owner.motion.put(actor.player().getUniqueId(),new Vector());}
    }
    void use(NativeControl.Actor actor){actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),net.minecraft.world.InteractionHand.OFF_HAND);}
    JsonObject command(String kind){var c=new JsonObject();c.addProperty("kind",kind);return c;}
    void crossbow(Player player,int slot,boolean charged){var item=new ItemStack(Material.CROSSBOW);
        if(charged){var meta=(CrossbowMeta)item.getItemMeta();meta.setChargedProjectiles(List.of(new ItemStack(Material.ARROW)));item.setItemMeta(meta);}
        player.getInventory().setItem(slot,item);
    }
    JsonObject policyStep(int tick){
        var plan=owner.policy.decide(a.name,owner.frame(a,q(),tick));var c=plan.getAsJsonObject("command").deepCopy();
        // Isolate offhand semantics from walking; the decision remains logged unchanged.
        c.add("worldHeading",JsonNull.INSTANCE);c.addProperty("forward",0);c.addProperty("side",0);c.addProperty("sprint",false);
        var actual=owner.execute(a,q(),c,tick);owner.policy.applied(a.name,c,actual,tick);
        plan.add("fixtureActual",NativeControl.JSON.toJsonTree(actual));return plan;
    }
    void tick(int tick)throws Exception{
        elapsed++;
        if(elapsed==1){startZ=p().getZ();p().setSprinting(true);a.handle.zza=1;}
        if(elapsed<=20){a.handle.zza=1;sprintTrace.add(p().getZ());}
        if(elapsed==21){mark("native-forward-sprint",p().getZ()-startZ>5,Map.of("travelled20Ticks",p().getZ()-startZ,"sprintFlag",p().isSprinting(),"trace",sprintTrace));pose(12);maxY=p().getY();a.handle.jumpFromGround();}
        if(elapsed>21&&elapsed<=43){maxY=Math.max(maxY,p().getY());falling|=p().getFallDistance()>0;}
        if(elapsed==44){mark("native-jump-and-fall",maxY>222.1&&falling&&p().isOnGround(),Map.of("maxY",maxY,"fallingObserved",falling,"landed",p().isOnGround()));pose(2.5);use(b);}
        if(elapsed==52){lastDamage=0;healthBefore=q().getHealth();shieldPreZ=q().getZ();owner.strike(a,q(),command("fixture-sword"),tick);mark("effective-shield-blocks-sword",q().isBlocking()&&lastDamage==0&&q().getHealth()==healthBefore,Map.of("blocking",q().isBlocking(),"damage",lastDamage));p().getInventory().setHeldItemSlot(7);a.handle.resetAttackStrengthTicker();}
        if(elapsed==60)mark("blocked-shield-no-phantom-motion",Math.abs(q().getZ()-shieldPreZ)<1e-6,Map.of("travel",q().getZ()-shieldPreZ));
        if(elapsed==84){owner.strike(a,q(),command("fixture-axe"),tick);mark("native-axe-disables-shield",q().hasCooldown(Material.SHIELD),Map.of("cooldown",q().getCooldown(Material.SHIELD)));pose(12);p().getInventory().setItemInOffHand(new ItemStack(Material.CROSSBOW));use(a);}
        if(elapsed==112){mark("native-crossbow-load",NativeControl.loaded(p().getInventory().getItemInOffHand()),Map.of("loaded",NativeControl.loaded(p().getInventory().getItemInOffHand()),"useTicks",p().getHandRaisedTime()));a.handle.releaseUsingItem();use(a);}
        if(elapsed==114){mark("native-crossbow-fire-once",shots==1&&!NativeControl.loaded(p().getInventory().getItemInOffHand()),Map.of("shots",shots));pose(3.25);}
        if(elapsed==130){healthBefore=q().getHealth();lastDamage=0;var actual=owner.strike(a,q(),command("fixture-limit"),tick);mark("native-reach-and-damage",Boolean.TRUE.equals(actual.get("attempted"))&&lastDamage>0&&Math.abs((double)actual.get("reach")-2.95)<1e-6,Map.of("actual",actual,"damage",lastDamage));}
        if(elapsed==132){mark("native-knockback-integrates",q().getZ()>1008.5,Map.of("targetZ",q().getZ()));
            pose(3.29);a.opponent=b.name;var f=owner.frame(a,q(),tick);long began=System.nanoTime();var plan=owner.policy.decide(a.name,f);
            mark("live-world-policy-decision",plan.has("command"),Map.of("ms",(System.nanoTime()-began)/1e6,"command",plan.get("command")));
            pose(3.31);lastDamage=0;var outside=owner.strike(a,q(),command("fixture-outside"),tick);
            mark("native-rejects-out-of-range",Boolean.FALSE.equals(outside.get("attempted"))&&lastDamage==0,Map.of("actual",outside));
            pose(2.5);lastDamage=0;cancelNextAttack=true;var cancelled=owner.strike(a,q(),command("fixture-cancel"),tick);
            mark("plugin-attack-cancellation-respected",Boolean.FALSE.equals(cancelled.get("attempted"))&&lastDamage==0,Map.of("actual",cancelled));
            var guard=command("fixture-shield");guard.addProperty("shield",true);guard.addProperty("forward",1);
            var guardActual=owner.execute(a,q(),guard,tick);
            mark("shield-slowdown-first-tick",p().hasActiveItem()&&Math.abs(a.handle.zza-.2)<1e-6,Map.of("actual",guardActual));
            pose(2.5);a.handle.jumpFromGround();jumps=1;nativeCritical=false;
        }
        if(elapsed>132&&elapsed<177){
            if(p().isOnGround()&&jumps<3){a.handle.jumpFromGround();jumps++;}
            if(p().getFallDistance()>0&&!p().isOnGround()&&p().getCooledAttackStrength(0)>.9&&!nativeCritical){
                q().teleport(p().getLocation().clone().add(0,-.5,2.5));q().setNoDamageTicks(0);
                lastDamage=0;owner.strike(a,q(),command("fixture-critical"),tick);
            }
        }
        if(elapsed==178){mark("native-critical-confirmed",nativeCritical,Map.of("nativeCritical",nativeCritical));
            mark("landing-immediate-rejump",jumps==3,Map.of("jumps",jumps));pose(2.5);use(b);
        }
        if(elapsed==186){p().getInventory().setHeldItemSlot(7);a.handle.resetAttackStrengthTicker();
            var stunCommand=command("legacy86-stun");
            var firstStun=owner.strike(a,q(),stunCommand,tick);var secondStun=owner.strike(a,q(),stunCommand,tick);
            mark("same-tick-low-charge-stun",q().hasCooldown(Material.SHIELD),Map.of("cooldown",q().getCooldown(Material.SHIELD)));
            mark("native-stun-feedback-captures-real-motion",(int)secondStun.get("targetShieldCooldown")>0
                &&(double)firstStun.get("targetDamage")==0&&(double)secondStun.get("targetDamage")>0
                &&secondStun.containsKey("targetMotionPacketObserved")&&secondStun.containsKey("targetMotionOrigin"),
                Map.of("first",firstStun,"second",secondStun));
            pose(12);a.opponent=b.name;a.active=true;owner.policy.reset(a.name,b.name);
            q().getInventory().setItem(1,new ItemStack(Material.BOW));q().getInventory().setHeldItemSlot(1);
            b.handle.gameMode.useItem(b.handle,b.handle.level(),b.handle.getMainHandItem(),net.minecraft.world.InteractionHand.MAIN_HAND);
        }
        if(elapsed==188){var plan=policyStep(tick);var c=plan.getAsJsonObject("command");
            mark("bow-draw-blocked-without-return-fire",NativeControl.flag(c,"shield")&&(!c.has("ranged")||c.get("ranged").isJsonNull())&&p().hasActiveItem(),Map.of("plan",plan));
        }
        if(elapsed==190){pose(12);owner.policy.reset(a.name,b.name);crossbow(p(),8,true);crossbow(q(),0,true);
            q().setRotation(0,0); // Fires away: this fixture isolates synchronization from dodging.
            b.handle.gameMode.useItem(b.handle,b.handle.level(),b.handle.getMainHandItem(),net.minecraft.world.InteractionHand.MAIN_HAND);
        }
        if(elapsed==191){var plan=policyStep(tick);
            mark("native-crossbow-shot-synchronization",NativeControl.string(plan.getAsJsonObject("command"),"ranged","").equals("fire-crossbow")
                &&plan.getAsJsonObject("fixtureActual").getAsJsonObject("rangedResult").has("fireSent"),Map.of("plan",plan));
        }
        if(elapsed==193){policyStep(tick);mark("synchronized-shot-not-repeated",shots==2,Map.of("shotsIncludingInitialFixture",shots));}
        if(elapsed==196){pose(12);owner.policy.reset(a.name,b.name);crossbow(p(),8,false);crossbow(q(),0,false);
            b.handle.gameMode.useItem(b.handle,b.handle.level(),b.handle.getMainHandItem(),net.minecraft.world.InteractionHand.MAIN_HAND);
        }
        if(elapsed>=197&&elapsed<=226)policyStep(tick);
        if(elapsed==227){var observation=owner.frame(a,q(),tick);
            mark("native-load-sync-and-confirmation",NativeControl.loaded(NativeControl.crossbow(p()))&&a.loadCycle>0&&"charged".equals(a.loadResult),
                Map.of("loaded",NativeControl.loaded(NativeControl.crossbow(p())),"observation",observation.get("observation")));
            pose(2.9);q().getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(1000);q().setHealth(1000);
            a.opponent=b.name;owner.policy.reset(a.name,b.name);
            a.active=true;a.handle.resetAttackStrengthTicker();a.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(0,-.078,-.06));
            b.handle.setOnGround(false);b.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(0,.4,-.42));
            jumps=0;groundControlHits=0;shieldBefore=0;falling=false;nativeCritical=false;
        }
        if(elapsed>=228&&elapsed<=282){
            q().setRotation((float)Math.toDegrees(Math.atan2(-(p().getX()-q().getX()),p().getZ()-q().getZ())),0);
            q().setSprinting(true);b.handle.zza=1;b.handle.xxa=0;
            double beforeReach=NativeControl.reach(p(),q());owner.decide(a,tick);
            var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            falling|=plan.get("closeFight")!=null;
            @SuppressWarnings("unchecked") var selected=(Map<String,Object>)plan.get("command");
            if(Boolean.TRUE.equals(actual.get("attacked"))&&"legacy86-ground".equals(selected.get("kind")))groundControlHits++;
            if(Boolean.TRUE.equals(actual.get("jump"))){jumps++;if(beforeReach>2.5)shieldBefore++;}
        }
        if(elapsed==283){
            mark("native-incoming-rush-control-or-contact",groundControlHits>0||falling,Map.of("closePlanObserved",falling,"jumps",jumps,"groundControlHits",groundControlHits));
            mark("native-rush-tries-ground-control",groundControlHits>0,Map.of("nativeCriticalDamage",nativeCritical,"jumps",jumps,"groundControlHits",groundControlHits));
            mark("native-close-no-jump-outside-contact",shieldBefore==0,Map.of("outsideContactJumps",shieldBefore));
            a.active=false;q().setHealth(20);q().getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(20);
            pose(12);
        }
        if(elapsed==298)pose(3.25);
        if(elapsed==300){
            q().teleport(q().getLocation().clone().add(0,.6,0));
            b.handle.setOnGround(false);b.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(0,-.2,-.15));
            a.opponent=b.name;a.active=true;owner.policy.reset(a.name,b.name);lastDamage=0;nativeCritical=false;
            owner.decide(a,tick);var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
            @SuppressWarnings("unchecked") var c=(Map<String,Object>)plan.get("command");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            mark("native-grounded-hit-on-descending-target",Boolean.TRUE.equals(actual.get("attacked"))
                &&!Boolean.TRUE.equals(actual.get("jump"))&&plan.get("closeFight")==null&&"legacy86-ground".equals(c.get("kind"))
                &&p().isOnGround()&&lastDamage>0&&!nativeCritical,
                Map.of("command",c,"actual",actual,"damage",lastDamage,"targetVelocityAfterHit",q().getVelocity().toString()));
            mark("native-air-hit-queues-outward-knockback",b.handle.queuedMotion!=null&&b.handle.queuedMotion.z>0,
                Map.of("queuedMotion",String.valueOf(b.handle.queuedMotion),"targetWasDescending",true));
        }
        if(elapsed==301){
            owner.decide(a,tick);var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            mark("native-air-hit-retains-ground-control",plan.get("closeFight")==null
                &&!Boolean.TRUE.equals(actual.get("jump"))&&p().isOnGround()&&q().getVelocity().getZ()>0,
                Map.of("plan",plan,"actual",actual,"targetZVelocity",q().getVelocity().getZ()));
        }
        if(elapsed==302){a.active=false;pose(3.25);use(b);}
        if(elapsed==320){
            a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=true;owner.decide(a,tick);
            var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            mark("native-stun-transaction-returns-sword",Boolean.TRUE.equals(actual.get("attacked"))&&p().getInventory().getHeldItemSlot()==0,
                Map.of("actual",actual));shots=0;
        }
        if(elapsed==326){
            // A legal voluntary jump after stun, matching the human trace.
            // Low-charge stun itself may send no upward impulse at all.
            b.handle.jumpFromGround();
        }
        if(elapsed>=321&&elapsed<=335){
            owner.decide(a,tick);var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
            @SuppressWarnings("unchecked") var c=(Map<String,Object>)plan.get("command");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            if("post-stun-air-followup".equals(c.get("attackRole"))&&Boolean.TRUE.equals(actual.get("attacked"))){
                shots++;mark("native-post-stun-air-sword-hit",lastDamage>0&&p().isOnGround()&&!Boolean.TRUE.equals(actual.get("jump")),
                    Map.of("plan",plan,"actual",actual,"damage",lastDamage));
            }
        }
        if(elapsed==336){
            Files.writeString(owner.getDataFolder().toPath().resolve("stun-followup-fixture-frames.json"),NativeControl.JSON.toJson(a.frames));
            mark("native-stun-followup-removed",shots==0,Map.of("followupAttacks",shots));
            a.active=false;
            pose(12);
        }
        // Real native attacks during recharge recovery, from four compass
        // directions. Eleven actual ticks of sword cooldown give .88 at the
        // observation point and .92 at Player.attack's half-tick evaluation.
        for(int direction=0;direction<4;direction++){
            int begin=340+direction*24;
            if(elapsed==begin){
                pose(12);a.opponent=b.name;a.active=true;owner.policy.reset(a.name,b.name);
                a.handle.resetAttackStrengthTicker();
            }
            if(elapsed==begin+11){
                double angle=direction*Math.PI/2,ux=Math.cos(angle),uz=Math.sin(angle);
                q().teleport(p().getLocation().clone().add(ux*3.275,0,uz*3.275));
                b.handle.setOnGround(true);b.handle.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);b.handle.queuedMotion=null;
                a.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(-ux*.1,0,-uz*.1));a.handle.setOnGround(true);
                p().setRotation(0,0);q().setNoDamageTicks(0);lastDamage=0;
                owner.decide(a,tick);var row=a.frames.getLast();
                @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
                @SuppressWarnings("unchecked") var selected=(Map<String,Object>)plan.get("command");
                @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
                @SuppressWarnings("unchecked") var self=(Map<String,Object>)row.get("self");
                @SuppressWarnings("unchecked") var heading=(Map<String,Object>)selected.get("worldHeading");
                double hx=((Number)heading.get("x")).doubleValue(),hz=((Number)heading.get("z")).doubleValue();
                double expectedYaw=Math.toDegrees(Math.atan2(-hx,hz)),angleError=Math.abs(Math.IEEEremainder(p().getYaw()-expectedYaw,360));
                double radial=b.handle.queuedMotion==null?0:b.handle.queuedMotion.x*ux+b.handle.queuedMotion.z*uz;
                mark("native-recovery-intercept-"+direction,Boolean.TRUE.equals(actual.get("attacked"))&&lastDamage>0
                    &&radial>.5&&p().isSprinting()&&angleError<.001&&a.handle.zza>.9&&!Boolean.TRUE.equals(actual.get("jump")),
                    Map.of("actual",actual,"damage",lastDamage,"outwardVelocity",radial,"aimRestorationErrorDegrees",angleError,
                        "charge",self.get("charge"),"attackChargeAtHit",self.get("attackChargeAtHit"),"command",selected));
                int attacks=a.lastDispatchTick;owner.decide(a,tick);
                @SuppressWarnings("unchecked") var duplicate=(Map<String,Object>)a.frames.getLast().get("actual");
                mark("native-recovery-no-same-tick-repeat-"+direction,!Boolean.TRUE.equals(duplicate.get("attacked"))&&a.lastDispatchTick==attacks,
                    Map.of("actual",duplicate));
                a.active=false;owner.hold(a);
            }
        }
        // Reproduce movement+attack in one main-thread batch without yielding
        // to the deferred movement callback or probe clock in between.
        for(int direction=0;direction<4;direction++){
            int begin=440+direction*24;
            if(elapsed==begin){
                pose(12);a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=false;
            }
            if(elapsed==begin+14){
                double angle=direction*Math.PI/2,ux=Math.cos(angle),uz=Math.sin(angle);
                q().teleport(p().getLocation().clone().add(ux*3.275,0,uz*3.275));
                a.handle.setOnGround(true);b.handle.setOnGround(true);
                a.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(-ux*.1,0,-uz*.1));
                p().setRotation(0,0);q().setNoDamageTicks(0);p().setNoDamageTicks(0);a.active=true;
                int before=a.frames.size();double ownHealth=p().getHealth();lastDamage=0;
                var incoming=owner.strike(b,p(),command("fixture-incoming"),tick);
                var row=a.frames.size()>before?a.frames.getLast():Map.<String,Object>of();
                @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.getOrDefault("actual",Map.of());
                mark("native-same-batch-intercept-"+direction,"incoming-attack".equals(row.get("decisionTrigger"))
                    &&Boolean.TRUE.equals(actual.get("attacked"))&&a.lastDispatchTick==tick&&lastDamage>0,
                    Map.of("reactionFrames",a.frames.size()-before,"actual",actual,"damage",lastDamage,"incoming",incoming));
                mark("native-incoming-attack-not-cancelled-"+direction,Boolean.TRUE.equals(incoming.get("attempted"))
                    &&p().getHealth()<ownHealth,Map.of("incoming",incoming,"damageTaken",ownHealth-p().getHealth()));
                a.active=false;owner.hold(a);
            }
        }
        if(elapsed==550){
            pose(5.8);a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=true;
            q().getInventory().setItem(1,new ItemStack(Material.BOW));q().getInventory().setHeldItemSlot(1);
            q().setRotation(180,0);healthBefore=p().getHealth();shots=0;shieldBefore=0;
            b.handle.gameMode.useItem(b.handle,b.handle.level(),b.handle.getMainHandItem(),net.minecraft.world.InteractionHand.MAIN_HAND);
        }
        if(elapsed==559||elapsed==575)b.handle.releaseUsingItem();
        if(elapsed==567)b.handle.gameMode.useItem(b.handle,b.handle.level(),b.handle.getMainHandItem(),net.minecraft.world.InteractionHand.MAIN_HAND);
        if(elapsed>=551&&elapsed<=590)owner.decide(a,tick);
        if(elapsed==591){
            Files.writeString(owner.getDataFolder().toPath().resolve("light-bow-fixture-frames.json"),NativeControl.JSON.toJson(a.frames));
            mark("native-repeated-light-bow-defense",p().getHealth()==healthBefore&&shieldBefore>=2,
                Map.of("healthBefore",healthBefore,"healthAfter",p().getHealth(),"arrowsBlocked",shieldBefore));
            a.active=false;
        }

        if(elapsed==600||elapsed==680){
            pose(3.275);a.frames.clear();p().getInventory().setHeldItemSlot(axeProfile?7:0);
            p().setCooldown(Material.SHIELD,1000);
            owner.policy.runtime.getGlobalObject().set("nativeFixtureLegacy",false);
            a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=false;
            if(elapsed==680)p().getInventory().setItemInOffHand(null);
            jumps=0;falling=false;groundControlHits=0;lastDamage=0;filteredHitKind="";maxY=p().getY();
            beginRecoveryCheck();
        }
        if(elapsed==622||elapsed==702){
            filterGroundKnockback=elapsed==702;a.active=true;owner.decide(a,tick);
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");
            @SuppressWarnings("unchecked") var hits=(List<Map<String,Object>>)actual.get("attacks");
            if(!hits.isEmpty()){
                var hit=hits.getFirst();filteredHitKind=String.valueOf(hit.get("hitKind"));
                double reach=((Number)hit.get("reach")).doubleValue();
                groundControlHits=Boolean.TRUE.equals(hit.get("attempted"))&&((Number)hit.get("targetDamage")).doubleValue()>0
                    &&((Number)hit.get("held")).intValue()==(axeProfile?7:0)&&reach>=2.95&&reach<=3?1:0;
                owner.policy.receipt(a.name,Map.of("type","damage","attacker",a.name,"victim",b.name,"melee",true,
                    "amount",hit.get("targetDamage"),"attackId",hit.get("id")),tick);
            }
        }
        if(elapsed>=623&&elapsed<=654||elapsed>=703&&elapsed<=734){
            owner.decide(a,tick);var row=a.frames.getLast();
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)row.get("actual");
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)row.get("plan");
            @SuppressWarnings("unchecked") var contact=(Map<String,Object>)plan.get("groundContact");
            @SuppressWarnings("unchecked") var move=(Map<String,Object>)contact.get("movement");
            checkRecoveryFrame(actual,plan);
            if(Boolean.TRUE.equals(actual.get("jump"))){
                jumps++;if(move!=null&&Boolean.TRUE.equals(move.get("groundSprintPrepared"))
                    &&Boolean.TRUE.equals(actual.get("sprint"))&&((Number)actual.get("forward")).doubleValue()>.99)falling=true;
            }
            maxY=Math.max(maxY,p().getY());
        }
        if(elapsed==655||elapsed==735){
            boolean noKb=elapsed==735;
            mark(axeProfile?(noKb?(jumpRecoveryProfile?"native-zero-kb-axe-hit-full-jump-recovery":"native-zero-kb-axe-hit-short-ground-recovery")
                    :(jumpRecoveryProfile?"native-axe-hit-full-jump-recovery":"native-axe-hit-short-ground-recovery")):
                    (noKb?"native-zero-kb-sword-spacing":"native-sword-spacing"),
                groundControlHits==1&&(axeProfile&&jumpRecoveryProfile?jumps>0&&falling&&maxY>222.1&&recoveryLanded&&recoveryHeld:nonSwordRecoveryJumps==0)
                    &&(!noKb||filteredHitKind.equals("damage-without-horizontal-knockback")),
                Map.of("initialHitAtRequestedBand",groundControlHits==1,"jumps",jumps,"fullLaunchConfirmed",falling,"maxY",maxY,"hitKind",filteredHitKind,
                    "heldForwardSprintUntilLanding",recoveryHeld,"observedActualLanding",recoveryLanded,"flightFrames",recoveryFlightFrames));
            Files.writeString(owner.getDataFolder().toPath().resolve(noKb?"axe-zero-kb-cycle-frames.json":"axe-cycle-frames.json"),NativeControl.JSON.toJson(a.frames));
            a.active=false;filterGroundKnockback=false;
        }
        if(elapsed==760){
            pose(8);a.frames.clear();p().getInventory().setHeldItemSlot(7);
            a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=false;
            var plan=policyStep(tick);var c=plan.getAsJsonObject("command");
            mark("native-a-no-opening-melee-shield",!c.get("shield").getAsBoolean()&&c.get("slot").getAsInt()==7,
                Map.of("command",c));
        }
        if(elapsed==770){
            pose(3.275);p().getInventory().setHeldItemSlot(7);a.opponent=b.name;owner.policy.reset(a.name,b.name);
            p().setCooldown(Material.SHIELD,1000); // Isolate A movement from B defense.
            a.active=false;use(b);jumps=0;falling=false;groundControlHits=0;maxY=p().getY();
            beginRecoveryCheck();
        }
        if(elapsed==778){
            a.active=true;owner.decide(a,tick);
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");
            @SuppressWarnings("unchecked") var hits=(List<Map<String,Object>>)actual.get("attacks");
            if(hits.size()==2&&q().hasCooldown(Material.SHIELD)&&p().getInventory().getHeldItemSlot()==7)groundControlHits=1;
        }
        if(elapsed>=779&&elapsed<=810){
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)a.frames.getLast().get("plan");checkRecoveryFrame(actual,plan);
            if(Boolean.TRUE.equals(actual.get("jump")))jumps++;
            maxY=Math.max(maxY,p().getY());
        }
        if(elapsed==811){
            mark(jumpRecoveryProfile?"native-a-stun-full-jump-recovery":"native-a-stun-short-ground-recovery",
                groundControlHits==1&&(jumpRecoveryProfile?jumps>0&&maxY>222.1&&recoveryLanded&&recoveryHeld:nonSwordRecoveryJumps==0),
                Map.of("twoHitStunAndAxeReturn",groundControlHits==1,"jumps",jumps,"maxY",maxY,
                    "heldForwardSprintUntilLanding",recoveryHeld,"observedActualLanding",recoveryLanded,"flightFrames",recoveryFlightFrames));a.active=false;
        }
        if(elapsed==820){
            pose(1.5);q().getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(1000);q().setHealth(1000);
            q().getAttribute(org.bukkit.attribute.Attribute.KNOCKBACK_RESISTANCE).setBaseValue(1);
            a.opponent=b.name;owner.policy.reset(a.name,b.name);a.active=true;shots=0;
        }
        if(elapsed>=821&&elapsed<=865){
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)a.frames.getLast().get("plan");
            @SuppressWarnings("unchecked") var selected=(Map<String,Object>)plan.get("command");
            if("db54f4a3e96639129fb52b7061826e60def65fa37174411da414d8df2de9e698".equals(selected.get("neuralCheckpointSha256"))
                &&p().getInventory().getHeldItemSlot()==0)shots++;
        }
        if(elapsed==866){
            mark("native-a-actual-frozen-transformer-sword-fallback",shots>0,Map.of("nativeFramesUsingFrozenModel",shots));
            a.active=false;q().setHealth(20);q().getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(20);
            q().getAttribute(org.bukkit.attribute.Attribute.KNOCKBACK_RESISTANCE).setBaseValue(0);
        }
        if(elapsed==870){
            pose(3.3);p().getInventory().setHeldItemSlot(7);a.handle.resetAttackStrengthTicker();a.frames.clear();a.opponent=b.name;
            owner.policy.reset(a.name,b.name);a.active=false;b.active=false;
            owner.policy.runtime.getExecutor("brains.get('WaveDog').state.retreating=true;").executeVoid();
            q().getInventory().setHeldItemSlot(0);q().setSprinting(true);b.handle.zza=1;
            // A warmed vanilla sprint jump, threatening the defender's charge recovery.
            b.handle.setDeltaMovement(new net.minecraft.world.phys.Vec3(0,0,-.1532168));b.handle.jumpFromGround();
            bHealth=p().getHealth();
        }
        if(elapsed>=871&&elapsed<=889){
            if(!bCriticalAttempted){q().setSprinting(true);b.handle.zza=1;}
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var row=(Map<String,Object>)a.frames.getLast().get("plan");
            @SuppressWarnings("unchecked") var arbitration=(Map<String,Object>)row.get("sonArbitration");
            bModeEntered|="B-punishment-shield".equals(arbitration.get("skill"));
            if(!bCriticalAttempted&&q().getFallDistance()>0&&NativeControl.reach(q(),p())<=3){
                q().setSprinting(false);b.handle.zza=0;
                b.opponent=a.name;var incoming=owner.strike(b,p(),command("fixture-B-incoming-critical"),tick);
                bCriticalAttempted=Boolean.TRUE.equals(incoming.get("attempted"));
                bCriticalBlocked=bCriticalAttempted&&((Number)incoming.get("targetDamage")).doubleValue()==0&&p().getHealth()==bHealth;
            }
            if(bCriticalAttempted)b.handle.zza=0;
        }
        if(elapsed==890){
            mark("native-B-punishment-critical-shield",bModeEntered&&bCriticalAttempted&&bCriticalBlocked,
                Map.of("enteredB",bModeEntered,"actualFallingAttack",bCriticalAttempted,"fullyBlocked",bCriticalBlocked,"health",p().getHealth()));
            q().getInventory().setHeldItemSlot(7);
            owner.strike(b,p(),command("fixture-B-shield-break"),tick);
            owner.strike(b,p(),command("fixture-B-shield-break-second"),tick);
        }
        if(elapsed==891){
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var row=(Map<String,Object>)a.frames.getLast().get("plan");
            @SuppressWarnings("unchecked") var arbitration=(Map<String,Object>)row.get("sonArbitration");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");
            String skill=String.valueOf(arbitration.get("skill"));
            bReturnedToA=skill.startsWith("B-shield-break-")&&!Boolean.TRUE.equals(actual.get("jump"));
            mark("native-B-break-returns-A",p().hasCooldown(Material.SHIELD)&&bReturnedToA,
                Map.of("shieldDisabled",p().hasCooldown(Material.SHIELD),"skill",skill,"actual",actual));
        }
        if(elapsed==900){
            pose(3.15);p().getInventory().setHeldItemSlot(7);a.handle.resetAttackStrengthTicker();a.frames.clear();a.opponent=b.name;
            owner.policy.reset(a.name,b.name);a.active=false;b.active=false;use(a);
            owner.policy.runtime.getExecutor("brains.get('WaveDog').state.punishmentShield={enteredAt:"+tick+",lastRiskAt:"+tick+"};").executeVoid();
        }
        if(elapsed>=901&&elapsed<=921){
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)a.frames.getLast().get("plan");
            @SuppressWarnings("unchecked") var c=(Map<String,Object>)plan.get("command");
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");
            if("B-steal-and-reblock".equals(c.get("intent"))&&Boolean.TRUE.equals(actual.get("attacked"))){
                bStealDone=true;bStealActual=actual;
                bStealReblocked=Boolean.TRUE.equals(actual.get("using"))&&p().getActiveItem().getType()==Material.SHIELD;
            }
        }
        if(elapsed==922){
            mark("native-B-steal-immediate-reblock",bStealDone&&bStealReblocked,
                Map.of("actualAttack",bStealDone,"usingShieldInSameExecution",bStealReblocked,
                    "vanillaWarmupStillRequired",true,"actual",bStealActual==null?Map.of():bStealActual));
        }
        if(elapsed==930){
            pose(3.075);p().getInventory().setHeldItemSlot(7);a.opponent=b.name;owner.policy.reset(a.name,b.name);use(a);
        }
        if(elapsed==950){
            // An ordinary accepted 0.2-block ground retreat enters the final legal range window.
            q().teleport(q().getLocation().add(0,0,.2));
            owner.policy.runtime.getExecutor("brains.get('WaveDog').state.punishmentShield={enteredAt:"+tick+",lastRiskAt:"+tick+"};").executeVoid();
            owner.decide(a,tick);
            @SuppressWarnings("unchecked") var actual=(Map<String,Object>)a.frames.getLast().get("actual");bExitActual=actual;
            @SuppressWarnings("unchecked") var plan=(Map<String,Object>)a.frames.getLast().get("plan");
            @SuppressWarnings("unchecked") var c=(Map<String,Object>)plan.get("command");
            @SuppressWarnings("unchecked") var hits=(List<Map<String,Object>>)actual.get("attacks");
            boolean hit=!hits.isEmpty()&&Boolean.TRUE.equals(hits.getFirst().get("sprintBefore"))
                &&((Number)hits.getFirst().get("targetDamage")).doubleValue()>0
                &&((Number)hits.getFirst().get("reach")).doubleValue()>=2.95;
            mark("native-B-extreme-knockback-exit","B-knockback-exit".equals(c.get("intent"))&&hit
                &&!Boolean.TRUE.equals(actual.get("using"))&&!Boolean.TRUE.equals(actual.get("jump")),
                Map.of("command",c,"actual",actual,"realSprintKnockbackHit",hit));
        }
        if(elapsed==952){
            done=true;HandlerList.unregisterAll(this);boolean pass=results.stream().allMatch(r->Boolean.TRUE.equals(r.get("pass")));
            Files.writeString(owner.getDataFolder().toPath().resolve(advancedOnly?"native-advanced-fixture.json":"native-mechanics-fixture.json"),NativeControl.JSON.toJson(Map.of("pass",pass,"cases",results,"mainServerTest",false)));
            owner.policy.runtime.getGlobalObject().set("nativeFixtureLegacy",false);owner.policy.reset(a.name,b.name);owner.policy.reset(b.name,a.name);
            owner.hold(a);owner.hold(b);
        }
    }
    @EventHandler(priority=EventPriority.MONITOR)public void damage(EntityDamageByEntityEvent e){
        if(e.getDamager()==p()&&e.getEntity()==q()){lastDamage=e.getFinalDamage();nativeCritical|=e.isCritical();}
        if(elapsed>=550&&e.getEntity()==p()&&e.getDamager() instanceof AbstractArrow
            &&e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)&&e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING)<0)shieldBefore++;
        if(elapsed>=760&&e.getDamager()==q()&&e.getEntity()==p()&&e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)
            &&e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING)<0&&e.getFinalDamage()==0)punishmentBlocked=true;
    }
    @EventHandler(priority=EventPriority.HIGHEST)public void cancel(io.papermc.paper.event.player.PrePlayerAttackEntityEvent e){if(cancelNextAttack&&e.getPlayer()==p()){e.setCancelled(true);cancelNextAttack=false;}}
    @EventHandler(priority=EventPriority.MONITOR)public void shot(EntityShootBowEvent e){if(e.getEntity()==p())shots++;}
    @EventHandler(priority=EventPriority.HIGHEST)public void filter(org.bukkit.event.player.PlayerVelocityEvent e){
        if(filterGroundKnockback&&e.getPlayer()==q())e.setVelocity(new Vector(0,.4,0));
    }
}
