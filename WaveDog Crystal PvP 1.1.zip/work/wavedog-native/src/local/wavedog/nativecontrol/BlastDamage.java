package local.wavedog.nativecontrol;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.Location;

/** Minecraft's exposure samples and damage formula, evaluated without a real explosion. */
final class BlastDamage {
    record Score(float self,float target) {
        float value(){return target-1.35f*self;}
        boolean worthwhile(Player p){return target>=1&&value()>0&&self<p.getHealth()+p.getAbsorptionAmount();}
    }

    static Score estimate(Player self,Player target,Vec3 origin,boolean anchor,Block cover){
        return estimate(self,target,origin,anchor,cover,self.getLocation(),target.getLocation());
    }

    static Score estimate(Player self,Player target,Vec3 origin,boolean anchor,Block cover,Location own,Location enemy){
        return estimate(self,target,origin,anchor,cover,null,own,enemy);
    }
    static Score estimate(Player self,Player target,Vec3 origin,boolean anchor,Block cover,Block second,Location own,Location enemy){
        return new Score(estimate(self,origin,anchor,cover,second,own),estimate(target,origin,anchor,cover,second,enemy));
    }

    static AABB cube(Block block){
        return new AABB(block.getX(),block.getY(),block.getZ(),block.getX()+1,block.getY()+1,block.getZ()+1);
    }

    private static float estimate(Player player,Vec3 origin,boolean anchor,Block cover,Block second,Location projected){
        ServerPlayer p=((CraftPlayer)player).getHandle();var level=p.level();
        Vec3 position=new Vec3(projected.getX(),projected.getY(),projected.getZ());
        double radius=anchor?10:12, distance=position.distanceTo(origin)/radius;
        if(distance>1||p.getAbilities().invulnerable||p.isSpectator())return 0;
        var box=p.getBoundingBox().move(position.subtract(p.position()));
        double dx=1/((box.maxX-box.minX)*2+1),dy=1/((box.maxY-box.minY)*2+1),dz=1/((box.maxZ-box.minZ)*2+1);
        double ox=(1-Math.floor(1/dx)*dx)/2,oz=(1-Math.floor(1/dz)*dz)/2;
        AABB virtual=cover==null?null:cube(cover);
        AABB other=second==null?null:cube(second);
        int total=0,clear=0;
        for(double x=0;x<=1;x+=dx)for(double y=0;y<=1;y+=dy)for(double z=0;z<=1;z+=dz){
            var sample=new Vec3(Mth.lerp(x,box.minX,box.maxX)+ox,Mth.lerp(y,box.minY,box.maxY),Mth.lerp(z,box.minZ,box.maxZ)+oz);
            total++;
            if(virtual!=null&&(virtual.contains(sample)||virtual.clip(sample,origin).isPresent())
                ||other!=null&&(other.contains(sample)||other.clip(sample,origin).isPresent()))continue;
            var hit=level.clip(new ClipContext(sample,origin,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
            if(hit.getType()==HitResult.Type.MISS||anchor&&hit.getBlockPos().equals(net.minecraft.core.BlockPos.containing(origin)))clear++;
        }
        double impact=(1-distance)*clear/total;
        float damage=(float)((impact*impact+impact)*3.5*radius+1);
        var source=anchor?level.damageSources().badRespawnPointExplosion(origin):level.damageSources().explosion(null,null);
        if(source.scalesWithDifficulty())damage=switch(level.getDifficulty()){
            case PEACEFUL->0;case EASY->Math.min(damage/2+1,damage);case NORMAL->damage;case HARD->damage*1.5f;
        };
        if(player.getNoDamageTicks()>player.getMaximumNoDamageTicks()/2)damage=Math.max(0,damage-p.lastHurt);
        if(!source.is(DamageTypeTags.BYPASSES_ARMOR))damage=CombatRules.getDamageAfterAbsorb(p,damage,source,
            p.getArmorValue(),(float)p.getAttributeValue(Attributes.ARMOR_TOUGHNESS));
        var resistance=p.getEffect(MobEffects.RESISTANCE);
        if(resistance!=null&&!source.is(DamageTypeTags.BYPASSES_EFFECTS)&&!source.is(DamageTypeTags.BYPASSES_RESISTANCE))
            damage=Math.max(0,damage*(1-.2f*(resistance.getAmplifier()+1)));
        if(!source.is(DamageTypeTags.BYPASSES_EFFECTS)&&!source.is(DamageTypeTags.BYPASSES_ENCHANTMENTS))
            damage=CombatRules.getDamageAfterMagicAbsorb(damage,EnchantmentHelper.getDamageProtection(level,p,source));
        return damage;
    }
}
