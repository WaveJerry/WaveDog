package local.wavedog.nativecontrol;

import java.nio.file.Files;
import java.util.*;
import org.bukkit.*;
import org.bukkit.event.HandlerList;
import net.minecraft.world.phys.Vec3;

/** Single moving player on a flat stone runway; no referee or main-server duel. */
final class NativeSprintJumpProbe extends NativeMechanicsProbe {
    final String[] modes={"held-from-rest","son-from-rest","held-after-sprint","son-after-sprint","held-after-turn","son-after-turn"};
    final List<Map<String,Object>> runs=new ArrayList<>(),trace=new ArrayList<>(),flights=new ArrayList<>();
    int run=-1,step,originTick;boolean air;double originZ,launchZ,launchY,launchSpeed,previousZ,previousY,previousSpeed;
    NativeSprintJumpProbe(NativeControl owner)throws Exception{
        super(owner);
        for(int x=1010;x<=1018;x++)for(int z=950;z<=1100;z++){
            p().getWorld().getBlockAt(x,220,z).setType(Material.STONE,false);
            for(int y=221;y<=225;y++)p().getWorld().getBlockAt(x,y,z).setType(Material.AIR,false);
        }
        a.active=b.active=false;
        q().teleport(new Location(p().getWorld(),1017.5,221,1005.5));
        owner.policy.runtime.getGlobalObject().set("nativeFixtureLegacy",false);
    }
    void begin(int tick)throws Exception{
        run++;step=0;air=false;trace.clear();flights.clear();
        owner.hold(a);a.frames.clear();a.opponent=b.name;
        p().teleport(new Location(p().getWorld(),1014.5,221,1020.5,0,0));
        a.handle.setDeltaMovement(Vec3.ZERO);a.handle.queuedMotion=null;a.handle.setOnGround(true);
        p().setFoodLevel(20);p().setSaturation(20);p().getInventory().setHeldItemSlot(7);
        owner.policy.reset(a.name,b.name);
        originZ=previousZ=p().getZ();previousY=p().getY();previousSpeed=0;
    }
    void record(int tick){
        double z=p().getZ(),y=p().getY(),v=a.handle.getDeltaMovement().z;
        var row=new LinkedHashMap<String,Object>();row.put("step",step);row.put("z",z);row.put("y",y);
        row.put("ground",p().isOnGround());row.put("vz",v);row.put("vy",a.handle.getDeltaMovement().y);
        row.put("sprinting",p().isSprinting());row.put("forward",a.handle.zza);row.put("side",a.handle.xxa);row.put("yaw",p().getYaw());
        trace.add(row);
        if(!air&&!p().isOnGround()&&y>221.01){air=true;launchZ=previousZ;launchY=previousY;launchSpeed=previousSpeed;originTick=tick-1;}
        if(air&&p().isOnGround()){
            flights.add(Map.of("distance",z-launchZ,"ticks",tick-originTick,"launchZ",launchZ,"landingZ",z,"launchSpeed",launchSpeed,"launchY",launchY));air=false;
        }
        previousZ=z;previousY=y;previousSpeed=v;
    }
    @Override void tick(int tick)throws Exception{
        if(run<0)begin(tick);
        record(tick);
        if(step>=130){
            runs.add(Map.of("mode",modes[run],"flights",new ArrayList<>(flights),"trace",new ArrayList<>(trace),"policyFrames",new ArrayList<>(a.frames)));
            if(run==modes.length-1){
                done=true;owner.hold(a);owner.hold(b);HandlerList.unregisterAll(this);
                Files.writeString(owner.getDataFolder().toPath().resolve("native-sprint-jump.json"),NativeControl.JSON.toJson(Map.of("mainServerTest",false,"runs",runs)));
                return;
            }
            begin(tick);
        }
        boolean son=modes[run].startsWith("son"),warm=run>=2,reverse=run>=4;
        int warmTicks=warm?30:0;
        if(step<warmTicks){
            p().setRotation(reverse?180:0,0);p().setSprinting(true);a.handle.zza=1;a.handle.xxa=0;a.handle.setJumping(false);
        }else if(!son){
            p().setRotation(0,0);p().setSprinting(true);a.handle.zza=1;a.handle.xxa=0;a.handle.setJumping(true);
        }else{
            if(step==warmTicks){
                q().teleport(new Location(p().getWorld(),1014.5,221,p().getZ()-8,0,0));
                owner.policy.runtime.getExecutor("brains.get('WaveDog').state.runJumpRecovery={startedAt:"+tick+",jumpedAt:null,heading:{x:0,z:1}};").executeVoid();
            }
            // Only the recovery flight belongs in this comparison, not later pursuit.
            if(flights.isEmpty())owner.decide(a,tick);else owner.hold(a);
        }
        step++;
    }
}
