package local.wavedog.nativecontrol;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.caoccao.javet.interop.*;
import com.caoccao.javet.interop.callback.*;

final class NativePolicy implements AutoCloseable {
    final V8Runtime runtime;
    final NativeControl owner;
    NativePolicy(NativeControl owner)throws Exception{
        this.owner=owner;
        String selected=owner.getConfig().getString("policy-directory","");
        if(!selected.isBlank()){
            var directory=java.nio.file.Path.of(selected).toRealPath();
            var managed=NativeControl.ROOT.resolve("work/wavedog-native/policies").toRealPath();
            if(!directory.getParent().equals(managed))throw new IllegalStateException("Policy directory is outside managed policy storage");
            var manifest=JsonParser.parseString(java.nio.file.Files.readString(directory.resolve("policy-manifest.json"))).getAsJsonObject();
            if(!directory.getFileName().toString().equals(manifest.get("sha256").getAsString()))throw new IllegalStateException("Policy directory hash mismatch");
            for(var entry:manifest.getAsJsonObject("files").entrySet()){
                if(!entry.getKey().matches("[a-z0-9.-]+\\.(js|cjs)"))throw new IllegalStateException("Invalid policy manifest file");
                String actual=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(java.nio.file.Files.readAllBytes(directory.resolve("policy").resolve(entry.getKey()))));
                if(!actual.equals(entry.getValue().getAsString()))throw new IllegalStateException("Policy source hash mismatch: "+entry.getKey());
            }
            String bootstrap=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(java.nio.file.Files.readAllBytes(directory.resolve("policy-bootstrap.js"))));
            if(!bootstrap.equals(manifest.get("bootstrapSha256").getAsString()))throw new IllegalStateException("Policy bootstrap hash mismatch");
        }
        runtime=V8Host.getV8Instance().createV8Runtime();
        runtime.getGlobalObject().bindFunction(new JavetCallbackContext("nativeSource",JavetCallbackType.DirectCallNoThisAndResult,
            (IJavetDirectCallable.NoThisAndResult<Exception>)args->{
            String name=args[0].toString();
            if(!name.matches("[a-z0-9.-]+\\.(js|cjs)"))throw new IllegalArgumentException("Invalid policy resource");
            String directory=owner.getConfig().getString("policy-directory","");
            try(var input=directory.isBlank()?owner.getResource("policy/"+name):java.nio.file.Files.newInputStream(java.nio.file.Path.of(directory).resolve("policy").resolve(name))){
                if(input==null)throw new IllegalArgumentException("Missing policy resource: "+name);
                return runtime.createV8ValueString(new String(input.readAllBytes(),StandardCharsets.UTF_8));
            }catch(java.io.IOException e){throw new IllegalStateException(e);}
        }));
        runtime.getGlobalObject().bindFunction(new JavetCallbackContext("nativeBlock",JavetCallbackType.DirectCallNoThisAndResult,
            (IJavetDirectCallable.NoThisAndResult<Exception>)args->runtime.createV8ValueString(owner.block(args[0].toString(),
                Integer.parseInt(args[1].toString()),Integer.parseInt(args[2].toString()),Integer.parseInt(args[3].toString())))));
        runtime.getGlobalObject().bindFunction(new JavetCallbackContext("nativeClear",JavetCallbackType.DirectCallNoThisAndResult,
            (IJavetDirectCallable.NoThisAndResult<Exception>)args->runtime.createV8ValueBoolean(owner.clear(args[0].toString(),
                Double.parseDouble(args[1].toString()),Double.parseDouble(args[2].toString()),Double.parseDouble(args[3].toString()),
                Double.parseDouble(args[4].toString()),Double.parseDouble(args[5].toString()),Double.parseDouble(args[6].toString())))));
        try(var input=selected.isBlank()?owner.getResource("policy-bootstrap.js"):java.nio.file.Files.newInputStream(java.nio.file.Path.of(selected).resolve("policy-bootstrap.js"))){
            runtime.getExecutor(new String(Objects.requireNonNull(input).readAllBytes(),StandardCharsets.UTF_8)).executeVoid();
        }
    }
    void reset(String name,String opponent){try{runtime.getGlobalObject().invokeVoid("nativeReset",name,opponent);}catch(Exception e){throw new IllegalStateException(e);}}
    JsonObject decide(String name,Map<String,Object> frame){
        try{return JsonParser.parseString(runtime.getGlobalObject().invokeString("nativeDecide",name,NativeControl.JSON.toJson(frame))).getAsJsonObject();}
        catch(Exception e){throw new IllegalStateException(e);}
    }
    String rangedAim(String params){try{return runtime.getGlobalObject().invokeString("nativeRangedAim",params);}catch(Exception e){throw new IllegalStateException(e);}}
    void receipt(String name,Map<String,Object> receipt,int tick){try{runtime.getGlobalObject().invokeVoid("nativeReceipt",name,NativeControl.JSON.toJson(receipt),tick);}catch(Exception e){throw new IllegalStateException(e);}}
    void applied(String name,JsonObject command,Map<String,Object> actual,int tick){try{runtime.getGlobalObject().invokeVoid("nativeApplied",name,command.toString(),NativeControl.JSON.toJson(actual),tick);}catch(Exception e){throw new IllegalStateException(e);}}
    @Override public void close(){try{
        for(String name:List.of("nativeSource","nativeBlock","nativeClear"))runtime.getGlobalObject().delete(name);
        runtime.lowMemoryNotification();runtime.close();
    }catch(Exception e){throw new IllegalStateException(e);}}
}
