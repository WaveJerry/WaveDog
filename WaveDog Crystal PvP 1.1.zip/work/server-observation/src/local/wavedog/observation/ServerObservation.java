package local.wavedog.observation;

import com.google.gson.Gson;
import com.destroystokyo.paper.event.server.ServerTickEndEvent;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.DeflaterOutputStream;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;

/** Main-thread, accepted server state. Observations never move or attack a player. */
public final class ServerObservation extends JavaPlugin implements Listener {
    private static final String CHANNEL="wavedog:server_state";
    private final Gson json=new Gson();
    private final Map<UUID,Location> previous=new HashMap<>();
    private final Map<UUID,Integer> previousTick=new HashMap<>();
    private final Map<UUID,Map<String,Object>> terrain=new HashMap<>();
    private long samples, sent, lastNanos, peakNanos;
    @Override public void onEnable(){
        getServer().getMessenger().registerOutgoingPluginChannel(this,CHANNEL);
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("wdserverstate")).setExecutor(this);
    }
    private double attribute(Player p,Attribute key,double fallback){
        var value=p.getAttribute(key);return value==null?fallback:value.getValue();
    }
    private Map<String,Object> player(Player p,int tick){
        var at=p.getLocation();var old=previous.get(p.getUniqueId());
        int dt=tick-previousTick.getOrDefault(p.getUniqueId(),tick);
        boolean valid=old!=null&&old.getWorld()==at.getWorld()&&dt>0&&old.distanceSquared(at)<64;
        var velocity=p.getVelocity();var box=p.getBoundingBox();
        var row=new LinkedHashMap<String,Object>();
        row.put("name",p.getName());row.put("uuid",p.getUniqueId().toString());row.put("id",p.getEntityId());
        row.put("world",p.getWorld().getName());row.put("x",at.getX());row.put("y",at.getY());row.put("z",at.getZ());
        row.put("eyeY",p.getEyeLocation().getY());row.put("yaw",at.getYaw());row.put("pitch",at.getPitch());
        row.put("ground",p.isOnGround());row.put("fallDistance",p.getFallDistance());row.put("sprint",p.isSprinting());
        row.put("width",box.getWidthX());row.put("height",box.getHeight());
        row.put("box",List.of(box.getMinX(),box.getMinY(),box.getMinZ(),box.getMaxX(),box.getMaxY(),box.getMaxZ()));
        row.put("motionKnown",valid);row.put("motionTicks",dt);
        row.put("vx",valid?(at.getX()-old.getX())/dt:0);row.put("vy",valid?(at.getY()-old.getY())/dt:0);
        row.put("vz",valid?(at.getZ()-old.getZ())/dt:0);
        row.put("serverVelocity",Map.of("x",velocity.getX(),"y",velocity.getY(),"z",velocity.getZ()));
        row.put("attackRange",attribute(p,Attribute.ENTITY_INTERACTION_RANGE,3));
        row.put("attackSpeed",attribute(p,Attribute.ATTACK_SPEED,4));
        row.put("attackDamage",attribute(p,Attribute.ATTACK_DAMAGE,1));
        row.put("charge",p.getCooledAttackStrength(0));row.put("health",p.getHealth());row.put("food",p.getFoodLevel());
        row.put("shielding",p.isBlocking());row.put("shieldCooldown",p.getCooldown(Material.SHIELD));
        row.put("using",p.hasActiveItem());row.put("useTicks",p.getHandRaisedTime());
        row.put("activeHand",p.hasActiveItem()?p.getHandRaised().name():"NONE");
        row.put("activeItem",p.hasActiveItem()?p.getActiveItem().getType().name():"AIR");
        var main=p.getInventory().getItemInMainHand();var off=p.getInventory().getItemInOffHand();
        row.put("mainhand",main.getType().name());row.put("offhand",off.getType().name());
        row.put("mainLoaded",main.getItemMeta() instanceof CrossbowMeta m&&m.hasChargedProjectiles());
        row.put("offLoaded",off.getItemMeta() instanceof CrossbowMeta m&&m.hasChargedProjectiles());
        row.put("held",p.getInventory().getHeldItemSlot());
        previous.put(p.getUniqueId(),at);previousTick.put(p.getUniqueId(),tick);
        return row;
    }
    private Map<String,Object> environment(Player p,int tick)throws Exception{
        int radius=12,size=radius*2+1,height=9,x0=p.getLocation().getBlockX()-radius,
            y0=p.getLocation().getBlockY()-3,z0=p.getLocation().getBlockZ()-radius;
        var palette=new ArrayList<Map<String,Object>>();var indices=new HashMap<String,Integer>();
        var buffer=java.nio.ByteBuffer.allocate(size*size*height*2);
        for(int x=x0;x<x0+size;x++)for(int z=z0;z<z0+size;z++)for(int y=y0;y<y0+height;y++){
            if(!p.getWorld().isChunkLoaded(x>>4,z>>4)||y<p.getWorld().getMinHeight()||y>=p.getWorld().getMaxHeight()){
                buffer.putShort((short)65535);continue;
            }
            var block=p.getWorld().getBlockAt(x,y,z);String state=block.getBlockData().getAsString();
            Integer index=indices.get(state);
            if(index==null){
                index=palette.size();indices.put(state,index);var shapes=new ArrayList<List<Double>>();
                if(!block.getType().isAir())for(var b:block.getCollisionShape().getBoundingBoxes())
                    shapes.add(List.of(b.getMinX(),b.getMinY(),b.getMinZ(),b.getMaxX(),b.getMaxY(),b.getMaxZ()));
                palette.add(Map.of("name",block.getType().name().toLowerCase(Locale.ROOT),"state",state,"shapes",shapes));
            }
            buffer.putShort(index.shortValue());
        }
        var compressed=new ByteArrayOutputStream();
        try(var zip=new DeflaterOutputStream(compressed)){zip.write(buffer.array());}
        return Map.of("world",p.getWorld().getName(),"serverTick",tick,"sampledAtMs",System.currentTimeMillis(),
            "x0",x0,"y0",y0,"z0",z0,"size",size,"height",height,"palette",palette,
            "indices",Base64.getEncoder().encodeToString(compressed.toByteArray()));
    }
    private void combat(String type,Player attacker,Player victim,Map<String,Object> detail){
        var eye=attacker.getEyeLocation();var box=victim.getBoundingBox();
        double dx=eye.getX()-Math.max(box.getMinX(),Math.min(eye.getX(),box.getMaxX())),
            dy=eye.getY()-Math.max(box.getMinY(),Math.min(eye.getY(),box.getMaxY())),
            dz=eye.getZ()-Math.max(box.getMinZ(),Math.min(eye.getZ(),box.getMaxZ()));
        var row=new LinkedHashMap<String,Object>(detail);row.put("type",type);
        row.put("source","server-attack-handler-v1");row.put("serverTick",Bukkit.getCurrentTick());
        row.put("sampledAtMs",System.currentTimeMillis());row.put("attacker",attacker.getName());row.put("victim",victim.getName());
        row.put("eye",List.of(eye.getX(),eye.getY(),eye.getZ()));
        row.put("targetBox",List.of(box.getMinX(),box.getMinY(),box.getMinZ(),box.getMaxX(),box.getMaxY(),box.getMaxZ()));
        row.put("serverReach",Math.sqrt(dx*dx+dy*dy+dz*dz));
        row.put("attackRange",attribute(attacker,Attribute.ENTITY_INTERACTION_RANGE,3));
        byte[] data=json.toJson(row).getBytes(StandardCharsets.UTF_8);
        for(String name:List.of("WaveDog","WaveDogSon")){
            var own=Bukkit.getPlayerExact(name);if(own!=null&&!own.hasMetadata("wavedog-native-player"))own.sendPluginMessage(this,CHANNEL,data);
        }
    }
    @EventHandler(priority=EventPriority.MONITOR) public void attack(PrePlayerAttackEntityEvent event){
        if(event.getAttacked() instanceof Player victim)
            combat("server_attack_observation",event.getPlayer(),victim,Map.of("willAttack",event.willAttack(),"cancelled",event.isCancelled()));
    }
    @EventHandler(priority=EventPriority.MONITOR) public void damage(EntityDamageByEntityEvent event){
        if(event.getDamager() instanceof Player attacker&&event.getEntity() instanceof Player victim)
            combat("server_damage_observation",attacker,victim,Map.of("damage",event.getFinalDamage(),
                "critical",event.isCritical(),"cancelled",event.isCancelled()));
    }
    @EventHandler public void tick(ServerTickEndEvent event){
        long began=System.nanoTime();int tick=Bukkit.getCurrentTick();
        var peers=new ArrayList<Player>();
        for(String name:List.of("WaveDog","WaveDogSon")){var p=Bukkit.getPlayerExact(name);if(p!=null&&!p.hasMetadata("wavedog-native-player"))peers.add(p);}
        if(peers.isEmpty())return;
        var players=new ArrayList<Map<String,Object>>();
        for(var p:Bukkit.getOnlinePlayers())players.add(player(p,tick));
        var online=new HashSet<UUID>();for(var p:Bukkit.getOnlinePlayers())online.add(p.getUniqueId());
        previous.keySet().retainAll(online);previousTick.keySet().retainAll(online);terrain.keySet().retainAll(online);
        for(var own:peers)try{
            var row=new LinkedHashMap<String,Object>();row.put("type","server_observation");
            row.put("source","server-accepted-position-v1");row.put("phase","server-tick-end");
            row.put("serverTick",tick);row.put("sampledAtMs",System.currentTimeMillis());row.put("players",players);
            var arrows=new ArrayList<Map<String,Object>>();
            for(var entity:own.getNearbyEntities(32,16,32))if(entity instanceof AbstractArrow arrow){
                var at=arrow.getLocation();var v=arrow.getVelocity();
                var a=new LinkedHashMap<String,Object>();a.put("id",arrow.getEntityId());
                a.put("x",at.getX());a.put("y",at.getY());a.put("z",at.getZ());
                a.put("vx",v.getX());a.put("vy",v.getY());a.put("vz",v.getZ());
                a.put("inGround",arrow.isInBlock());a.put("ageMs",0);
                if(arrow.getShooter() instanceof Entity shooter)a.put("shooterId",shooter.getEntityId());
                arrows.add(a);
            }
            row.put("arrows",arrows);
            var cached=terrain.get(own.getUniqueId());
            if(cached==null||tick-((Number)cached.get("serverTick")).intValue()>=10
                ||!cached.get("world").equals(own.getWorld().getName())){
                cached=environment(own,tick);terrain.put(own.getUniqueId(),cached);row.put("environment",cached);
            }
            own.sendPluginMessage(this,CHANNEL,json.toJson(row).getBytes(StandardCharsets.UTF_8));sent++;
        }catch(Exception error){getLogger().warning("Server observation failed: "+error.getClass().getSimpleName());}
        samples++;lastNanos=System.nanoTime()-began;peakNanos=Math.max(peakNanos,lastNanos);
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.isOp()){sender.sendMessage("Operator only");return true;}
        if(args.length>0&&args[0].equals("snapshot")){
            try{
                if(!Bukkit.isPrimaryThread())throw new IllegalStateException("World snapshot outside main thread");
                String name=args.length>1?args[1]:"WaveDog";var own=Bukkit.getPlayerExact(name);
                if(own==null){sender.sendMessage(json.toJson(Map.of("error","Player is offline","focus",name)));return true;}
                int tick=Bukkit.getCurrentTick();var players=new ArrayList<Map<String,Object>>();
                var nativeController=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
                java.lang.reflect.Method acceptedVelocity=null;
                if(nativeController!=null&&nativeController.isEnabled()){
                    acceptedVelocity=nativeController.getClass().getDeclaredMethod("velocity",Player.class);acceptedVelocity.setAccessible(true);
                }
                for(var p:Bukkit.getOnlinePlayers()){
                    var body=player(p,tick);
                    if(acceptedVelocity!=null){
                        var motion=(org.bukkit.util.Vector)acceptedVelocity.invoke(nativeController,p);
                        body.put("vx",motion.getX());body.put("vy",motion.getY());body.put("vz",motion.getZ());
                        body.put("motionKnown",true);body.put("motionTicks",1);
                        body.put("motionSource",p.hasMetadata("wavedog-native-player")?"native-physics-impulse":"accepted-position-delta-per-tick");
                    }else body.put("motionSource","snapshot-interval-average");
                    players.add(body);
                }
                var row=new LinkedHashMap<String,Object>();row.put("source","server-live-readonly-v1");
                row.put("serverTick",tick);row.put("sampledAtMs",System.currentTimeMillis());row.put("focus",name);
                row.put("world",own.getWorld().getName());row.put("players",players);
                row.put("environment",environment(own,tick));
                var entities=new ArrayList<Map<String,Object>>();
                for(var entity:own.getNearbyEntities(24,12,24)){
                    var at=entity.getLocation();var v=entity.getVelocity();
                    var item=new LinkedHashMap<String,Object>();item.put("id",entity.getEntityId());item.put("type",entity.getType().name());
                    item.put("x",at.getX());item.put("y",at.getY());item.put("z",at.getZ());
                    item.put("vx",v.getX());item.put("vy",v.getY());item.put("vz",v.getZ());
                    if(entity instanceof AbstractArrow arrow){item.put("inGround",arrow.isInBlock());
                        if(arrow.getShooter() instanceof Entity shooter)item.put("shooterId",shooter.getEntityId());}
                    entities.add(item);if(entities.size()>=128)break;
                }
                row.put("nearbyEntities",entities);row.put("entityLimit",128);
                row.put("worldTickRate",20);row.put("hasClientPrivateState",false);
                sender.sendMessage(json.toJson(row));
            }catch(Exception error){sender.sendMessage(json.toJson(Map.of("error",error.toString())));}
            return true;
        }
        sender.sendMessage(json.toJson(Map.of("source","server-accepted-position-v1","phase","server-tick-end",
            "samples",samples,"sent",sent,"lastMs",lastNanos/1e6,"peakMs",peakNanos/1e6,
            "positionHz",20,"environmentHz",2,"terrainRadius",12,"terrainHeight",9)));
        return true;
    }
}
