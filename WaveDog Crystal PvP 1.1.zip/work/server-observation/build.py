from pathlib import Path
import os, subprocess, zipfile
BASE=Path(__file__).resolve().parent
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classes=BASE/'classes';classes.mkdir(exist_ok=True)
api=next((SERVER/'libraries/io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT').glob('*.jar'))
classpath=os.pathsep.join(map(str,[api,*sorted((SERVER/'libraries').rglob('*.jar'))]))
subprocess.run([str(SERVER/'runtime/java21/bin/javac.exe'),'-proc:none','--release','21','-encoding','UTF-8',
    '-cp',classpath,'-d',str(classes),str(BASE/'src/local/wavedog/observation/ServerObservation.java')],
    check=True,creationflags=subprocess.CREATE_NO_WINDOW)
with zipfile.ZipFile(BASE/'WaveDogServerObservation.jar','w',zipfile.ZIP_DEFLATED) as jar:
    jar.write(BASE/'plugin.yml','plugin.yml')
    for file in sorted(classes.rglob('*.class')):jar.write(file,file.relative_to(classes).as_posix())
print('SERVER_OBSERVATION_BUILD_PASS')
