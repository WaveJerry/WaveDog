'use strict'
// Freeze only publicly loaded collision shapes for one physical frame. The
// 500 Hz planner reuses this observation; it never pretends the world updated.
function createRouteProbe({origin,blockAt,radius=10,minY=Math.floor(origin.y)-3,maxY=Math.floor(origin.y)+5}){
  const x0=Math.floor(origin.x)-radius,z0=Math.floor(origin.z)-radius,n=radius*2+1
  const height=maxY-minY+1,cells=new Array(n*n*height)
  const index=(x,y,z)=>((x-x0)*n+z-z0)*height+y-minY
  // Probe only cells touched by a candidate. Repeated lookups of that frozen
  // cell use its shape array directly instead of allocating another Block.
  const at=(x,y,z)=>{
    if(x<x0||x>=x0+n||z<z0||z>=z0+n||y<minY||y>maxY)return null
    const i=index(x,y,z)
    if(cells[i]===undefined){const b=blockAt(x,y,z);cells[i]=b?b.shapes||[]:null}
    return cells[i]
  }
  const shapeHit=(p)=>{
    for(let x=Math.floor(p.x-.3);x<=Math.floor(p.x+.3);x++)
      for(let z=Math.floor(p.z-.3);z<=Math.floor(p.z+.3);z++)
        for(let y=Math.floor(p.y+1e-6);y<=Math.floor(p.y+1.8-1e-6);y++){
          const shapes=at(x,y,z);if(!shapes)return true
          for(const b of shapes)if(p.x+.3>x+b[0]+1e-7&&p.x-.3<x+b[3]-1e-7
            &&p.y+1.8>y+b[1]+1e-7&&p.y<y+b[4]-1e-7
            &&p.z+.3>z+b[2]+1e-7&&p.z-.3<z+b[5]-1e-7)return true
        }
    return false
  }
  const probe=(next,previous=next)=>{
    if(next.x-.3<x0||next.x+.3>=x0+n||next.z-.3<z0||next.z+.3>=z0+n)
      return {clear:false,supported:false,margin:0}
    let floor=-Infinity
    // Require support under the entire player footprint, not only its centre.
    for(const dx of [-.27,.27])for(const dz of [-.27,.27]){
      const x=Math.floor(next.x+dx),z=Math.floor(next.z+dz);let top=-Infinity
      for(let y=Math.min(maxY,Math.floor(Math.max(next.y,previous.y)));y>=minY;y--){
        const shapes=at(x,y,z)
        if(!shapes)return {clear:false,supported:false,margin:0}
        for(const b of shapes)if(next.x+dx>=x+b[0]&&next.x+dx<=x+b[3]
          &&next.z+dz>=z+b[2]&&next.z+dz<=z+b[5]
          &&y+b[4]<=Math.max(next.y,previous.y)+.01)top=Math.max(top,y+b[4])
        if(Number.isFinite(top))break
      }
      if(!Number.isFinite(top))return {clear:false,supported:false,margin:0}
      floor=Math.max(floor,top)
    }
    const p={...next,y:Math.max(next.y,floor)}
    // Segment samples prevent a high knockback velocity tunnelling through a
    // thin wall in the planner even though the final endpoint is open.
    const steps=Math.max(1,Math.ceil(Math.hypot(p.x-previous.x,p.y-previous.y,p.z-previous.z)/.15))
    for(let i=1;i<=steps;i++){
      const t=i/steps,q={x:previous.x+(p.x-previous.x)*t,y:previous.y+(p.y-previous.y)*t,z:previous.z+(p.z-previous.z)*t}
      if(shapeHit(q))return {clear:false,supported:true,margin:0,floorY:floor}
    }
    let margin=1.5
    for(const [dx,dz]of [[-1,0],[1,0],[0,-1],[0,1]])for(const distance of [.4,.8,1.2,1.5]){
      if(shapeHit({...p,x:p.x+dx*distance,z:p.z+dz*distance})){margin=Math.min(margin,distance);break}
    }
    return {clear:true,supported:true,margin,floorY:floor}
  }
  // Preserve the original Son's six clearance samples and floor/head checks.
  // These use the same frozen public cells as the other collision queries.
  probe.sonClearRoute=(p,h)=>{
    for(const d of [.45,.9,1.4])for(const side of [-.3,.3]){
      const x=p.x+h.x*d-h.z*side,z=p.z+h.z*d+h.x*side
      const foot=at(Math.floor(x),Math.floor(p.y+.05),Math.floor(z))
      const head=at(Math.floor(x),Math.floor(p.y+1.5),Math.floor(z))
      const floor=at(Math.floor(x),Math.floor(p.y-.15),Math.floor(z))
      if(!foot||!head||!floor||foot.length||head.length||!floor.length)return false
    }
    return true
  }
  // Transfer immutable public shapes, never a Mineflayer/World object.
  let frozen
  probe.snapshot=()=>{
    if(!frozen){
      for(let x=x0;x<x0+n;x++)for(let z=z0;z<z0+n;z++)for(let y=minY;y<=maxY;y++)at(x,y,z)
      frozen={origin:{x:origin.x,y:origin.y,z:origin.z},radius,x0,z0,minY,maxY,n,cells,
        key:globalThis.crypto.randomUUID()}
    }
    return frozen
  }
  return probe
}
module.exports={createRouteProbe}
