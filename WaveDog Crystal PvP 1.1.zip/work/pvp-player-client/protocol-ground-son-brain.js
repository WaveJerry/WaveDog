'use strict'
const {arenaCenter,route,eyeBoxReach,airborneEnvelope,clearance}=require('./protocol-legacy86-threat')
const {syncRanged,rangedApplied}=require('./protocol-legacy86-ranged')
const {criticalReply}=require('../wavedog-protocol/ground-son-critical.cjs')
const {planArrowDodge}=require('./wavedog-arrow-predictor')
const {createShieldState,shieldReceipt,selectShieldScript,shieldApplied,planBShieldAttack}=require('./protocol-son-shield-script')
const fields=['previousShield','shieldSeenAt','lastStunAt','lastBlock','spentBlock','rangedSync','closeFight','runJumpRecovery','spacingImpact','contactGuardUntil','shieldScriptState','punishmentShield','lastAxeStrikeTick','stunSwordOpportunity','swordExitArmed','bExitRun']
function createState(opponent,fighter='Punengbho'){
  return {opponent,fighter,mode:'GROUND_SON',nextId:1,decisionVersion:0,pending:new Map(),
    lastAttempt:-1000,lastGroundAttempt:-1000,lastHit:-1000,lastDamage:-1000,lastBlock:-1000,spentBlock:-1000,
    lastEnemyAttack:-1000,lastAxeStrikeTick:-1000,
    shieldSeenAt:-1000,lastStunAt:-1000,previousShield:false,closeFight:null,runJumpRecovery:null,spacingImpact:null,contactGuardUntil:-1000}
}
// Before declaring lost spacing, try the real short recovery run. The old
// one-tick, no-input projection classified OUR incoming momentum as a reason
// to jump forwards immediately after a spacing hit. These bounded routes
// include forward-sprint acceleration, current knockback and wall collision.
function sonRecoveryPlan(frame,probe){
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  if(!o.visible||o.reach>4.2)return null
  const n=Math.max(.001,Math.hypot(t.x-a.x,t.z-a.z)),ux=(t.x-a.x)/n,uz=(t.z-a.z)/n
  let best=null
  for(const side of [0,-.5,.5]){
    const scale=Math.hypot(1,side),h={x:(-ux-uz*side)/scale,z:(-uz+ux*side)/scale}
    const checked=route(a,h,6,probe);if(!checked)continue
    let minimumReach=o.reach,endingReach=o.reach,enemyY=t.y,vy=v.y
    for(let tick=1;tick<checked.points.length;tick++){
      if(!o.targetGrounded){enemyY+=vy;vy=(vy-.08)*.98;enemyY=Math.max(frame.targetFloorY??a.y,enemyY)}
      // Do not assume the opponent loses forward speed merely because we run.
      const enemy={...t,x:t.x+v.x*tick,y:enemyY,z:t.z+v.z*tick}
      endingReach=eyeBoxReach(checked.points[tick],enemy)
      minimumReach=Math.min(minimumReach,endingReach)
    }
    if(minimumReach<1.75||endingReach<2.9||endingReach<o.reach+.15)continue
    const score=Math.min(endingReach,4.2)+Math.min(checked.margin,1.5)*.1-(side? .02:0)
    if(!best||score>best.score)best={heading:h,sprint:true,retreat:true,score,
      minimumReach,endingReach,reason:'short-run-restores-ground-control'}
  }
  return best
}
function retreatEntryRisk(frame,probe,movement){
  const a=frame.self,o=frame.observation,v=frame.targetVelocity
  const current=o.otherReach??eyeBoxReach(frame.seen,a)
  const range=frame.combatGeometry?.opponentBaseRange??3
  if(current<=range+.03)return {threat:true,entered:true,current,minimum:current}
  if(!movement?.retreat)return {threat:false,current,minimum:current}
  const checked=route(a,movement.heading,6,probe)
  if(!checked)return {threat:false,current,minimum:current,routeBlocked:true}
  let enemy={...frame.seen},vy=v.y,vx=v.x,vz=v.z,minimum=current
  for(let dt=1;dt<checked.points.length;dt++){
    enemy={...enemy,x:enemy.x+vx,y:Math.max(frame.targetFloorY??a.y,enemy.y+vy),z:enemy.z+vz}
    if(o.targetAirborne){vx*=.91;vz*=.91;vy=(vy-.08)*.98}
    minimum=Math.min(minimum,eyeBoxReach(enemy,checked.points[dt]))
  }
  return {threat:minimum<=range+.05&&minimum<current-.03,entered:false,current,minimum,
    horizonTicks:6,source:'opponent-entry-during-selected-retreat'}
}

// One retreat phase: turn and build genuine outward sprint speed, jump only
// once aligned, finish that flight, then re-evaluate normal axe contact.
// No next-hit latch, landing chase, automatic light hit or combo planner.
function fullRunJumpRecovery(s,frame,probe,movement){
  const a=frame.self,o=frame.observation,t=frame.seen
  if(!movement&&!s.runJumpRecovery)return movement
  movement??={heading:s.runJumpRecovery.heading||{x:0,z:0},sprint:true,retreat:true}
  const impact=s.spacingImpact,age=impact?o.tick-impact.tick:Infinity
  if(impact&&age>=0&&age<=8){
    const v=frame.targetVelocity,observed=v.x*impact.ux+v.z*impact.uz
    const expected=impact.outwardSpeed*Math.pow(.91,age)
    const reduced=impact.reducedKB||expected>.12&&observed<expected*.55&&expected-observed>.08
    s.spacingImpact={...impact,observedOutwardSpeed:observed,expectedOutwardSpeed:expected,
      reducedKB:reduced,jumpResetObserved:impact.jumpResetObserved||Boolean(o.targetAirborne&&v.y>.1&&reduced)}
  }
  let recovery=s.runJumpRecovery
  // A native jump request can precede the first physics integration. The
  // following tick may still report onGround=true with upward velocity.
  // That is not a landing. Require an observed airborne phase first.
  if(recovery?.jumpedAt!=null){
    if(!a.ground)recovery={...recovery,airborneSeen:true}
    if(recovery.airborneSeen&&a.ground&&o.tick>recovery.jumpedAt){s.runJumpRecovery=null;return movement}
  }
  if(recovery&&!recovery.airborneSeen&&o.tick-recovery.startedAt>32){s.runJumpRecovery=null;recovery=null}
  if(!recovery)return movement
  const n=Math.max(.001,Math.hypot(t.x-a.x,t.z-a.z)),ux=(t.x-a.x)/n,uz=(t.z-a.z)/n
  const desired=recovery.heading||{x:-ux,z:-uz}
  let selected=null
  for(const side of [0,-.5,.5,-1,1]){
    const d=Math.hypot(1,side),h={x:(desired.x-desired.z*side)/d,z:(desired.z+desired.x*side)/d}
    const speed=a.vx*h.x+a.vz*h.z,lateral=Math.abs(a.vx*h.z-a.vz*h.x)
    const prepared=recovery.groundSprintAt!=null
      &&(Number.isFinite(a.physicsTick)?Number.isFinite(recovery.groundSprintAfterPhysics)
        &&a.physicsTick>recovery.groundSprintAfterPhysics:o.tick>recovery.groundSprintAt)
      &&recovery.preparedHeading&&recovery.preparedHeading.x*h.x+recovery.preparedHeading.z*h.z>.99
    // One real ground-sprint input precedes the jump; do not spend eight
    // ticks accelerating to a numerical speed target before leaving ground.
    const jump=a.ground&&a.jumpAvailable!==false&&recovery.jumpedAt==null&&Boolean(prepared)
    let horizon=jump?12:4
    if(!a.ground){
      // Check the remaining flight, not another twelve ticks beyond it.
      // The latter steered away from distant terrain before even landing.
      const floor=recovery.launchY??frame.targetFloorY??a.y
      let y=a.y,vy=a.vy;horizon=0
      do{y+=vy;vy=(vy-.08)*.98;horizon++}while(horizon<20&&(y>floor+.01||vy>0))
    }
    const checked=route(a,h,horizon,probe,{jump})
    if(!checked)continue
    const score=(side===0?2:0)+Math.min(checked.margin,1.5)*.1
    if(!selected||score>selected.score)selected={...movement,heading:h,sprint:true,retreat:true,jump,score,
      reason:'full-sprint-jump-recovery',launchSpeed:speed,launchAligned:lateral<=.04}
    if(selected?.heading===h)selected.groundSprintPrepared=Boolean(prepared)
  }
  if(!selected){s.runJumpRecovery=null;return {...movement,jump:false,fullJumpBlocked:true}}
  s.runJumpRecovery={...recovery,heading:selected.heading,...(selected.jump?{launchY:a.y}:{})}
  return selected
}

function disengagePlan(frame,probe){
  const a=frame.self,t=frame.seen,v=frame.targetVelocity,o=frame.observation
  if(!o.visible)return null
  const n=Math.max(.001,Math.hypot(t.x-a.x,t.z-a.z)),ux=(t.x-a.x)/n,uz=(t.z-a.z)/n
  const separating=(v.x-a.vx)*ux+(v.z-a.vz)*uz
  const airborne=o.targetAirborne
  // Walking straight backwards is not used: these are real forward-sprint
  // headings, subject to observed momentum, floors and wall collision.
  const envelope=airborne?airborneEnvelope({x:t.x,y:t.y,z:t.z,vx:v.x,vy:v.y,vz:v.z,grounded:false},
    {floorY:frame.targetFloorY??a.y,horizon:10,positionError:.04,velocityError:.025,steering:.026}):[]
  const crit=envelope.filter(e=>e.criticalPossible)
  const movementDelay=Math.min(4,Math.max(1,Math.ceil(((frame.latency?.oneWayMs??25)
    +(frame.latency?.serverQueueMs??50))/50)))
  const steps=Math.max(4,envelope.length-1),candidates=[{x:-ux,z:-uz},
    {x:(-ux-uz)/Math.SQRT2,z:(-uz+ux)/Math.SQRT2},
    {x:(-ux+uz)/Math.SQRT2,z:(-uz-ux)/Math.SQRT2}]
  let best=null
  for(const heading of candidates){
    const checked=route(a,heading,steps,probe)
    if(!checked)continue
    // A currently unavoidable falling hit cannot be wished away by a future
    // escape endpoint. Every possible critical tick must clear our body.
    if(crit.some(e=>Math.min(clearance(checked.points[e.tick],e),
      clearance(checked.points[Math.max(0,e.tick-movementDelay)],e))<3.05))continue
    const end=checked.points.at(-1),future={...t,x:t.x+v.x*steps,z:t.z+v.z*steps}
    const endingReach=eyeBoxReach(end,future)
    if(endingReach<3.15||endingReach<=o.reach+.15)continue
    const score=Math.min(endingReach,5)+Math.min(checked.margin,1.5)*.1
    if(!best||score>best.score)best={heading,score,endingReach,separating,
      firstCriticalTick:crit[0]?.tick??null,clearanceChecked:true}
  }
  return best
}
// Retains the established close-sword timing: confirmed falling criticals,
// landing re-jump, one exit hit and immediate sword recovery after stun.
function closeCommand(s,frame,probe){
  const a=frame.self,o=frame.observation,v=frame.targetVelocity
  const dx=frame.seen.x-a.x,dz=frame.seen.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const separating=((v.x-a.vx)*dx+(v.z-a.vz)*dz)/n
  const next=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},
    {...frame.seen,x:frame.seen.x+v.x,z:frame.seen.z+v.z})
  const exiting=o.reach>=2.6&&separating>.03&&next>3
  const critical=Boolean(a.critical&&a.charge>.9)
  const opening=!s.closeFight.firstHitDone&&a.ground&&a.charge>=.9&&!o.targetAirborne
  const stunFallback=s.closeFight.afterStunAt!==null&&(a.critical||s.closeFight.unified&&a.ground)&&a.charge>=.2
  const attack=(a.held??0)===0&&!o.targetShieldFacing&&(critical||opening||stunFallback||exiting&&a.charge>=.2)
  // Current contact, not a future inward projection, authorizes jumping.
  // Do not offer an airborne sword attack to an already raised front shield.
  const frontShield=o.targetShieldFacing||o.targetShieldRaised&&o.targetFacingDot>0
  const jumpRange=s.closeFight.unified?o.reach<=2.5&&!frontShield:(o.reach<=2.3||next<=2.3)
  const center=frame.arenaCenter||arenaCenter(a)
  let side=0,forward=1,best=-Infinity,bestCenter=-Infinity
  for(const k of [0,-1,1]){
    const scale=Math.hypot(1,k),hx=(dx/n-k*dz/n)/scale,hz=(dz/n+k*dx/n)/scale
    const point={x:a.x+hx*.65,y:a.y,z:a.z+hz*.65},checked=probe(point,a)
    if(!checked?.clear||!checked.supported)continue
    const gain=center?Math.hypot(a.x-center.x,a.z-center.z)-Math.hypot(point.x-center.x,point.z-center.z):0
    const score=Math.min(checked.margin??0,1.5)*.2+(k===0?.05:0)
    if(score>best+1e-9||Math.abs(score-best)<=1e-9&&gain>bestCenter){best=score;bestCenter=gain;side=k}
  }
  if(best===-Infinity)forward=0
  return {slot:0,shield:false,offhand:'shield',ranged:null,kind:'legacy86-close',
    intent:exiting?'close-exit-hit':'close-sword-dps',attackRole:exiting?'exit':'close-dps',
    forward,side,sprint:!critical&&a.ground&&forward>0,
    // Release in flight so a short knockback/reset flight does not carry the
    // held-key jump delay into the next landing. Re-press on the ground tick.
    jump:!exiting&&jumpRange&&(!s.closeFight.unified||a.ground&&a.jumpAvailable!==false),sneak:false,
    attack,critical:attack&&critical,doubleAttack:false,worldHeading:null,aimAway:false,keepLook:false}
}
function legacySwordCommand(s,frame){
  const proposal=frame.neuralFallback?.proposal,o=frame.observation,a=frame.self
  if(!proposal||proposal.checkpointSha256!=='db54f4a3e96639129fb52b7061826e60def65fa37174411da414d8df2de9e698'
      ||proposal.fighter!==s.fighter||proposal.opponent!==s.opponent||proposal.matchId!==frame.matchId
      ||o.tick-proposal.tick<0||o.tick-proposal.tick>3)return null
  const n=proposal.command,charge=a.attackChargeAtHit??a.charge
  const immune=Number.isFinite(frame.seen.noDamageTicks)&&frame.seen.noDamageTicks>(frame.seen.maxNoDamageTicks??20)/2
  const attack=Boolean(n.attack&&a.held===0&&charge>.9&&!immune&&!o.targetShieldFacing&&o.reach<=3)
  return {kind:'legacy86-close',intent:'old-transformer-sword-fallback',slot:0,shield:false,offhand:'shield',ranged:null,
    forward:n.forward,side:n.side,sprint:Boolean(n.sprint&&a.ground),jump:Boolean(n.jump&&a.ground&&a.vy<=.001&&o.reach<=2.5),
    attack,critical:Boolean(attack&&a.critical),sneak:false,doubleAttack:false,worldHeading:null,keepLook:false,keepTargetLook:true,
    neuralCheckpointSha256:proposal.checkpointSha256,neuralActions:proposal.actions,neuralDecidedTick:proposal.tick,neuralPolicyMs:proposal.policyMs}
}
function swordExitCommand(s,frame,probe){
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  if(a.held!==0||!s.closeFight&&(!s.swordExitArmed||o.tick-s.swordExitArmed.tick>12)
      ||!o.visible||o.reach<2.6||o.reach>3||o.targetShieldFacing||(a.attackChargeAtHit??a.charge)<.2
      ||Number.isFinite(t.noDamageTicks)&&t.noDamageTicks>(t.maxNoDamageTicks??20)/2)return null
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const separating=((v.x-a.vx)*dx+(v.z-a.vz)*dz)/n
  const next=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},{...t,x:t.x+v.x,z:t.z+v.z})
  if(separating<=.03||next<=3)return null
  const escape=sonRecoveryPlan(frame,probe)
  if(!escape)return null
  return {kind:'legacy86-close',slot:0,intent:'close-exit-hit',attackRole:'exit',attack:true,doubleAttack:false,
    shield:false,ranged:null,jump:false,critical:Boolean(a.critical&&(a.attackChargeAtHit??a.charge)>.9),
    worldHeading:escape.heading,sprint:!a.critical,forward:0,side:0,keepTargetLook:false,keepLook:false,
    exitReach:o.reach,nextReach:next,escapeChecked:true,preferredReachBand:[2.95,3]}
}
function applyJumpOwnership(c,frame,skill,profile){
  if(profile?.retreatMode!=='short-ground')return
  const a=frame.self,o=frame.observation
  const exit=c.intent==='close-exit-hit'
  const sword=c.slot===0&&c.kind==='legacy86-close'&&!exit&&c.intent==='old-transformer-sword-fallback'
  const projectile=skill==='arrow-dodge'||skill==='dodge-arrow'
  c.actionPhase=c.combatMode==='B'?'SHIELD_B':exit?'SWORD_EXIT':sword?'SWORD_DPS':projectile?'PROJECTILE_EVASION':'GROUND_A'
  const canJump=Boolean(a.ground&&a.jumpAvailable!==false&&a.vy<=.001)
  c.jump=Boolean(c.jump&&canJump&&(sword&&o.reach<=2.5||projectile))
  c.jumpOwner=c.jump?sword?'sword-transformer':'projectile-evasion':'none'
  if(sword){delete c.prepareReverseSprint;c.worldHeading=null}
}
function groundMotion(frame,probe,escape=false){
  const a=frame.self,t=frame.seen,o=frame.observation,v=frame.targetVelocity
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz)),ux=dx/n,uz=dz/n
  const closing=(a.vx-v.x)*ux+(a.vz-v.z)*uz,ready=a.charge>.9
  const retreat=escape||!ready&&o.reach<4.2||o.reach<2.85
  const advance=!retreat&&(o.reach>3.02||ready&&closing<.03)
  const desired=retreat?{x:-ux,z:-uz}:advance?{x:ux,z:uz}:{x:-uz,z:ux}
  const center=frame.arenaCenter||arenaCenter(a)
  let best=null
  for(const h of [desired,{x:-uz,z:ux},{x:uz,z:-ux}]){
    const checked=route(a,h,3,probe)
    if(!checked)continue
    const end=checked.points.at(-1),margin=Math.min(checked.margin,2)
    const score=(h===desired?2:0)+margin*.1
    const gain=center?Math.hypot(a.x-center.x,a.z-center.z)-Math.hypot(end.x-center.x,end.z-center.z):0
    if(!best||score>best.score||score===best.score&&gain>best.centerGain)
      best={heading:h,sprint:true,score,centerGain:gain,retreat,closing}
  }
  return best||{heading:{x:0,z:0},sprint:false,retreat,closing}
}
// The original ground-control-son.cjs navigation, including its brief charge
// recovery run. No hit receipt, critical forecast or combo latch extends it.
function originalSonMotion(frame,probe,{forceRetreat=false,approachOnly=false}={}){
  const a=frame.self,t=frame.seen,o=frame.observation,v=frame.targetVelocity
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz)),ux=dx/n,uz=dz/n
  const ready=a.charge>.9,closing=(a.vx-v.x)*ux+(a.vz-v.z)*uz
  const retreat=!approachOnly&&(forceRetreat||!ready&&o.reach<4.2||o.reach<2.85)
  const towards=approachOnly||!retreat&&(o.reach>3.02||ready&&closing<.03)
  const desired=retreat?{x:-ux,z:-uz}:towards?{x:ux,z:uz}:{x:-uz,z:ux}
  const center=arenaCenter(a)
  let best=null
  for(const h of [desired,{x:-uz,z:ux},{x:uz,z:-ux}]){
    const clear=probe.sonClearRoute?probe.sonClearRoute(a,h):Boolean(route(a,h,3,probe))
    if(!clear)continue
    const gain=center?Math.hypot(a.x-center.x,a.z-center.z)-Math.hypot(a.x+h.x-center.x,a.z+h.z-center.z):0
    const score=(h===desired?2:0)+gain*.35
    if(!best||score>best.score)best={heading:h,sprint:true,score,retreat,closing}
  }
  return best||{heading:{x:0,z:0},sprint:false,retreat,closing}
}
// Budget both the outward run and the return trip against the real axe
// cooldown. A short ground retreat has no jump/landing latch.
function axeChargeMotion(frame,probe){
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  const charge=a.attackChargeAtHit??a.charge,speed=a.attackSpeed??1
  const remaining=Math.max(0,Math.ceil((.900001-charge)*20/speed))
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const outward=(v.x*dx+v.z*dz)/n,returnSpeed=.28-outward
  const returnTicks=returnSpeed>.05?2+Math.max(0,o.reach-2.975)/returnSpeed:Infinity
  const justHit=Number.isFinite(a.attackAgeTicks)&&a.attackAgeTicks<2
  const wait=remaining>returnTicks+1||justHit&&remaining>0
  const movement=originalSonMotion({...frame,self:{...a,charge:wait?0:1}},probe,{forceRetreat:wait})
  return {...movement,reason:movement.retreat?'axe-short-charge-recovery':'axe-return-for-charge-window',
    remainingChargeTicks:remaining,estimatedReturnTicks:Number.isFinite(returnTicks)?returnTicks:null,
    returnIncludesTurn:true}
}
// Optional navigation-only side steps. Combat eligibility, aim and cooldown
// are left to the original Son. Side choice changes by physical tick, never
// on each 1 ms preview, and near walls we compare clearance before choosing.
function sonSideSteps(frame,probe,movement){
  if(!movement)return movement
  const a=frame.self,tick=frame.observation.tick
  const blocked=Math.hypot(movement.heading.x,movement.heading.z)<.5
  const target=frame.seen,dx=target.x-a.x,dz=target.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const h=blocked?{x:dx/n*(movement.retreat?-1:1),z:dz/n*(movement.retreat?-1:1)}:movement.heading
  const phase=((tick%24)+24)%24,side=phase<12?1:-1,pulse=phase%12<4
  const normalize=(x,z)=>{const n=Math.hypot(x,z);return {x:x/n,z:z/n}}
  const diagonal=k=>normalize(h.x-h.z*k*.5,h.z+h.x*k*.5)
  const center=arenaCenter(a),current=probe(a,a),margin=current?.margin??1.5
  const candidates=[{h:diagonal(side),bias:pulse?.2:-.2},{h:diagonal(-side),bias:pulse?.1:-.25},
    {h,bias:pulse?0:.2},{h:{x:-h.z,z:h.x},bias:-.6},{h:{x:h.z,z:-h.x},bias:-.6}]
  if(center)candidates.push({h:normalize(center.x-a.x||.000001,center.z-a.z),bias:-1})
  let best=null
  for(const candidate of candidates){
    const next={x:a.x+candidate.h.x*.65,y:a.y,z:a.z+candidate.h.z*.65},checked=probe(next,a)
    if(!checked?.clear||!checked.supported)continue
    const full=probe.sonClearRoute?probe.sonClearRoute(a,candidate.h):true
    const clearance=Math.min(checked.margin??1.5,1.5)
    const wallGain=margin<1.2?clearance-margin:0
    const score=candidate.bias+(full?0:-.4)+wallGain*2-Math.max(0,.8-clearance)
    if(!best||score>best.score)best={heading:candidate.h,score}
  }
  return best?{...movement,heading:best.heading,sprint:true,sideSteps:true,shortRouteFallback:blocked}:movement
}
// Son owns the entire command. A skill is selected here before the ONE commit;
// no shield model or executor callback can replace an already selected run.
function sonSkills(s,frame,probe,command,movement,enemyChargeUpper,response,selectedProfile={}){
  const c={...command},a=frame.self,o=frame.observation,arrow=o.arrowThreat
  const running=Boolean(movement?.retreat&&movement.sprint&&Math.hypot(movement.heading.x,movement.heading.z)>.5)
  const striking=Boolean(c.attack),contact=o.reach<=3||o.otherReach<=3
  const close=Boolean(s.closeFight)
  const incoming=Boolean(!c.rangedShieldOnly&&c.spacingProfile==='axe'&&contact&&o.targetAirborne&&response?.threat)
  const readyTicks=Math.max(0,Math.ceil((.900001-(a.attackChargeAtHit??a.charge))/((a.attackSpeed??1)/20)))
  const useTicks=frame.usingKind==='shield'?(a.useTicks||0):0
  if(striking||!a.shieldAvailable||!contact)s.contactGuardUntil=-1000
  if(incoming&&!striking&&a.shieldAvailable&&response.criticalEta<=readyTicks
      &&(a.shielding||response.criticalEta+useTicks>=(o.offhandShieldReady?5:6)))
    s.contactGuardUntil=Math.max(s.contactGuardUntil??-1000,o.tick+Math.max(5,response.criticalEta+2))
  const emergencyShield=contact&&!striking&&a.shieldAvailable&&o.tick<=s.contactGuardUntil
    &&(incoming||a.shielding||frame.usingKind==='shield')
  let skill=c.doubleAttack?'stun':close?(c.intent||'close-sword-dps'):striking?'ground-hit':running?'short-recovery-run':'ground-spacing'
  let reason=null
  let arrowDecision=null
  const cancelRanged=()=>syncRanged(s,frame,c,{emergency:true,allowBow:false,crossbowShotsOnly:true})
  const exitRun=s.bExitRun
  const exitUnmoved=Boolean(exitRun&&o.tick-exitRun.tick<=2
    &&Math.hypot(a.x-exitRun.origin.x,a.z-exitRun.origin.z)<1e-6&&!response?.threat&&!arrow)
  if(exitRun&&!exitUnmoved)s.bExitRun=null
  const entryRisk=selectedProfile.punishmentShieldMode&&(running||s.punishmentShield)?retreatEntryRisk(frame,probe,movement):{threat:false}
  const useB=selectedProfile.punishmentShieldMode&&running&&!close&&!striking&&!exitUnmoved
  if(useB&&entryRisk.threat&&a.shieldAvailable&&!s.punishmentShield)
    s.punishmentShield={enteredAt:o.tick,lastRiskAt:o.tick,reason:'opponent-entry-during-short-retreat',entryRisk}
  if(s.punishmentShield&&a.shieldAvailable){
    if(entryRisk.threat)s.punishmentShield={...s.punishmentShield,lastRiskAt:o.tick,entryRisk}
    else if(o.tick-(s.punishmentShield.lastRiskAt??s.punishmentShield.enteredAt)>=2)s.punishmentShield=null
  }
  const shieldBroken=Boolean(s.punishmentShield&&!a.shieldAvailable)
  if(shieldBroken){
    s.punishmentShield=null
    const legalReply=o.visible&&o.reach<=3&&!o.targetShieldFacing&&a.held===7
      &&(a.attackChargeAtHit??a.charge)>=.7&&!s.pending.size
    if(legalReply)Object.assign(c,{kind:'legacy86-counter',slot:7,shield:false,ranged:null,
      attack:true,doubleAttack:false,jump:false,critical:false,consumesBlock:s.lastBlock})
    skill=legalReply?'B-shield-break-counter-to-A':'B-shield-break-to-A'
  }
  if(s.punishmentShield&&a.shieldAvailable){
    cancelRanged()
    Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,jump:false,sprint:false,
      slot:7,worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true,combatMode:'B'})
    skill='B-punishment-shield';reason='retreat-entry-threat; break-or-clearance-returns-A'
    if(selectedProfile.bGuardActions&&!s.pending.size){
      const poke=planBShieldAttack(frame,response,sonRecoveryPlan(frame,probe))
      if(poke){Object.assign(c,poke);skill=poke.intent;reason=poke.exposedRear?'confirmed-existing-rear-window':poke.intent}
    }
  }else if(shieldBroken){
    c.combatMode='A'
  }else if(exitUnmoved){
    Object.assign(c,{shield:false,ranged:null,attack:false,doubleAttack:false,jump:false,sprint:true,
      worldHeading:exitRun.heading,forward:0,side:0,keepLook:false,keepTargetLook:false,combatMode:'A'})
    skill='B-exit-short-run';reason='one-real-ground-step-after-knockback-exit'
  }else if(s.runJumpRecovery?.jumpedAt!=null){
    cancelRanged()
    Object.assign(c,{shield:false,ranged:null,attack:false,doubleAttack:false,jump:false,sprint:true,
      worldHeading:s.runJumpRecovery.heading,forward:0,side:0,keepLook:false,keepTargetLook:false})
    skill='full-recovery-flight';reason='keep-forward-sprint-until-observed-landing'
  }else if(arrow){
    cancelRanged()
    const shieldUse=frame.usingKind==='shield'?a.useTicks||0:0
    const shieldDelay=a.shielding?0:Math.max(0,5-shieldUse)+(o.offhandShieldReady?0:1)
      +Math.max(1,Math.ceil(((frame.latency?.oneWayMs??0)+(frame.latency?.serverQueueMs??0))/50))
    const canBlock=!striking&&a.shieldAvailable
      &&(a.shielding||!running&&arrow.time>=shieldDelay)
    if(canBlock){
      Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,sprint:false,jump:false,
        worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true,arrowYaw:arrow.yaw})
      skill='arrow-shield'
    }else{
      // The predictor's side is relative to the actual current view. Keep that
      // view while dodging; aiming at the target first would invert the dodge.
      const projected=planArrowDodge(frame,probe,movement)
      arrowDecision=projected?{trajectoryUsed:true,trajectoryCount:projected.trajectoryCount,
        predictedHits:projected.predictedHits,firstImpactTick:projected.firstImpactTick,
        unavoidable:projected.unavoidable,continuingOriginal:projected.continuingOriginal}:null
      const yaw=a.yaw??o.targetYaw??0,left={x:-Math.cos(yaw),z:Math.sin(yaw)}
      const direction=arrow.dodgeHeading||{x:left.x*-(arrow.side||0),z:left.z*-(arrow.side||0)}
      let heading=projected?.heading||null
      if(!projected&&arrow.side)for(const k of [1,-1]){
        const h={x:direction.x*k,z:direction.z*k}
        const checked=probe({x:a.x+h.x*.65,y:a.y,z:a.z+h.z*.65},a)
        if(checked?.clear&&checked.supported){heading=h;break}
      }
      // If both sides are blocked, retain the original safe run rather than
      // turn into a wall. Jump is only the predictor's cleared-headroom action.
      if(heading||arrow.jump){
        const keepTargetLook=projected?.continuingOriginal?c.keepTargetLook:true
        Object.assign(c,{shield:false,ranged:null,attack:false,doubleAttack:false,sprint:Boolean(projected?.sprint),
          jump:projected?projected.jump:Boolean(a.ground&&arrow.jump),worldHeading:heading,forward:0,side:0,
          keepLook:true,keepTargetLook,airDodgeUrgent:true})
        delete c.arrowYaw;skill='arrow-dodge'
      }else reason='arrow-no-clear-lateral-route'
    }
  }else if(emergencyShield){
    cancelRanged()
    Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,sprint:false,jump:false,
      worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true})
    skill='contact-emergency-shield';reason='actual-in-range-punishment-before-recharge'
  }else if(!c.rangedShieldOnly&&close&&!striking&&!c.jump&&a.shieldAvailable&&a.charge<.55&&enemyChargeUpper>=.65
      &&o.otherReach<=3&&/_AXE$/.test(frame.seen.held||'')
      &&!(s.lastBlock>s.spentBlock&&o.tick-s.lastBlock<=6)
      &&(!o.targetAirborne||a.shielding
        ||(frame.usingKind==='shield'?a.useTicks||0:0)+(response?.criticalEta??0)>=(o.offhandShieldReady?5:6))
      &&(s.closeFight.guardStartedAt==null||o.tick-s.closeFight.guardStartedAt<=6)){
    cancelRanged();s.closeFight.guardStartedAt??=o.tick
    Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,sprint:false,jump:false,
      worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true})
    skill='close-axe-rhythm-shield';reason='cover-recharge-before-the-next-ready-sword-window'
  }else if(!striking&&!close&&!contact&&o.visible&&o.targetBow&&a.shieldAvailable){
    cancelRanged()
    Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,sprint:false,jump:false,
      worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true})
    skill='ranged-shield';reason='visible-bow-draw-prepares-shield-before-a-short-release'
  }else if(striking||running||close){
    cancelRanged();reason=close?'close-exchange-owns-command':striking?'melee-attack-owns-command':'short-run-owns-command'
  }else{
    // A shield can change rhythm only where it cannot cancel Son's attack or
    // real sprint recovery. Outside enemy reach it is never a default stance.
    const guard=!c.rangedShieldOnly&&contact&&a.shieldAvailable&&a.charge<.55&&enemyChargeUpper>=.65
      &&!(s.lastBlock>s.spentBlock&&o.tick-s.lastBlock<=6)&&!o.targetBow&&!o.targetLoading
    const bowThreat=o.visible&&o.targetBow&&a.shieldAvailable
    if(guard||bowThreat){
      cancelRanged()
      Object.assign(c,{shield:true,ranged:null,attack:false,doubleAttack:false,sprint:false,jump:false,
        worldHeading:null,forward:0,side:0,keepLook:false,keepTargetLook:true})
      skill=bowThreat?'ranged-shield':'rhythm-shield'
    }else{
      const ranged=syncRanged(s,frame,c,{emergency:contact,allowBow:false,crossbowShotsOnly:true})
      if(ranged){Object.assign(c,ranged,{doubleAttack:false,sprint:false});skill='sync-'+ranged.ranged}
    }
  }
  return {command:c,skill,reason,shortRunActive:running,retreatEntryRisk:entryRisk,arrowDecision,decisionOwner:'ground-son'}
}
function createGroundBrain({criticalDefense=true,offhandControl=true,strictGround=false,sideSteps=false,unifiedSon=false,axeSpacing=false,shieldScript=false,profile=null}={}){
  if(unifiedSon&&profile?.().unifiedShortPhases)return require('./protocol-unified-son-brain').createUnifiedSonBrain({profile,
    helpers:{axeChargeMotion,originalSonMotion,sonRecoveryPlan,legacySwordCommand,swordExitCommand,applyJumpOwnership}})
  if(unifiedSon){strictGround=true;offhandControl=false}
  let current=null
  const isDecisionCurrent=(s,p)=>p.baseStateVersion===s.decisionVersion
  function commitDecision(s,p){
    if(!isDecisionCurrent(s,p))return false
    Object.assign(s,p.statePatch);s.decisionVersion++
    if(p.command.attack)p.command.attackId=s.nextId++
    if(p.command.shieldScriptKind&&s.shieldScriptState?.pending&&p.command.attack)
      s.shieldScriptState.pending.id=p.command.attackId
    p.committedStateVersion=s.decisionVersion
    return true
  }
  return {ready:Promise.resolve(),runtime:null,createState,isDecisionCurrent,commitDecision,
    async reset(s){current=s;if(shieldScript)s.shieldScriptState=createShieldState(s.opponent,s.fighter)},
    receipt(s,e,tick){
      shieldReceipt(s,e,tick)
      if(e.type==='blocked_melee'){s.lastBlock=tick
        if(e.attacker===s.opponent)s.lastEnemyAttack=tick}
      if(e.type==='damage'&&!e.cancelled){
        if(e.victim===s.fighter&&e.amount>0)s.lastDamage=tick
        if(e.attacker===s.opponent&&e.victim===s.fighter&&e.melee)s.lastEnemyAttack=tick
        if(e.attacker===s.fighter&&e.victim===s.opponent&&e.melee){
          s.pending.delete(e.attackId);if(e.amount>0)s.lastHit=tick
        }
      }
      if(e.type==='attack_packet'&&e.willAttack===false)s.pending.delete(e.attackId)
    },
    async decide(live,frame,probe,tick,{preview=false,isCurrent=null,transactional=false}={}){
      if(profile){const selected=profile();axeSpacing=selected.axeSpacing;shieldScript=selected.shieldScript}
      if(current!==live)throw Error('Ground controller bout was not reset')
      if(!preview)for(const [id,p] of live.pending)if(tick-p.tick>=3)live.pending.delete(id)
      const baseStateVersion=live.decisionVersion,s={...live,rangedSync:live.rangedSync?structuredClone(live.rangedSync):undefined,
        closeFight:live.closeFight?{...live.closeFight}:null,runJumpRecovery:live.runJumpRecovery?{...live.runJumpRecovery}:null,
        spacingImpact:live.spacingImpact?{...live.spacingImpact}:null,
        punishmentShield:live.punishmentShield?{...live.punishmentShield}:null,
        shieldScriptState:live.shieldScriptState?structuredClone(live.shieldScriptState):null}
      const a=frame.self,o=frame.observation
      const groundCharge=unifiedSon&&Number.isFinite(a.attackChargeAtHit)?a.attackChargeAtHit:a.charge
      const groundHitReady=groundCharge>.9&&(!axeSpacing||a.held===7)
      const targetDamageReady=!Number.isFinite(frame.seen.noDamageTicks)
        ||frame.seen.noDamageTicks<=(frame.seen.maxNoDamageTicks??20)/2
      // Only a confirmed incoming melee attack constrains enemy cooldown.
      // A public arm swing by itself is not proof that charge was spent.
      const weapon=frame.seen.held||'',period=/_SWORD$/.test(weapon)?12.5:/_AXE$/.test(weapon)?20:5
      const lag=Math.max(1,Math.ceil(((frame.latency?.oneWayMs??25)+(frame.latency?.serverQueueMs??50))/50))
      const enemyChargeUpper=Math.min(1,Math.max(0,(tick-live.lastEnemyAttack+lag+.5)/period))
      const raised=Boolean(o.targetShieldRaised&&o.targetFacingDot>0)
      const response=criticalReply({enabled:criticalDefense&&(!strictGround||unifiedSon),self:a,
        target:{...frame.seen,airborne:o.targetAirborne,floorY:frame.targetFloorY??a.y},
        velocity:frame.targetVelocity,reach:o.reach,charge:a.charge,shieldReady:a.shieldAvailable,
        ageMs:frame.latency?.observationAgeMs??0,pingMs:frame.latency?.opponentRttMs??frame.latency?.rttMs??0,
        defenseCandidates:frame.combatGeometry?.defenseCandidates??[],incomingRange:frame.combatGeometry?.opponentBaseRange??3})
      // Reachable, uninterruptible melee commits to sword pressure. It never
      // chooses the old shield/escape recommendation of the public forecaster.
      const enemyInReach=Number.isFinite(o.otherReach)&&o.otherReach<=3
      const ownRaised=Boolean(a.shielding||o.shieldRaised||frame.usingKind==='shield')
      const mutualShieldHold=offhandControl&&ownRaised&&raised&&enemyInReach&&a.shieldAvailable&&enemyChargeUpper>=.65
      const blockReply=s.lastBlock>s.spentBlock&&tick-s.lastBlock<=6
      const nextReach=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},
        {...frame.seen,x:frame.seen.x+frame.targetVelocity.x,z:frame.seen.z+frame.targetVelocity.z})
      const dx=frame.seen.x-a.x,dz=frame.seen.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
      const separating=((frame.targetVelocity.x-a.vx)*dx+(frame.targetVelocity.z-a.vz)*dz)/n
      const afterOurHit=tick-s.lastHit<=5&&separating>.03&&nextReach>2.3
      const recovery=!strictGround&&!mutualShieldHold&&(afterOurHit||response.threat&&response.action!=='interrupt')
        ?disengagePlan(frame,probe):null
      const meleeShieldWarmup=o.offhandShieldReady?5:6
      const shieldCanCover=a.shielding||!o.targetAirborne
        ||(frame.usingKind==='shield'?(a.useTicks||0):0)+(response.criticalEta??0)>=meleeShieldWarmup
      const axePressure=offhandControl&&/_AXE$/.test(weapon)&&enemyInReach&&a.shieldAvailable&&!blockReply&&!recovery
        &&(response.action!=='interrupt'||Boolean(s.closeFight))&&enemyChargeUpper>=.65
        &&(Boolean(s.closeFight)||o.reach<=2.3||nextReach<=2.3)&&shieldCanCover
      // Keep the original Son hit/run at controllable reach. Enter the close
      // skill only after deep contact or predicted inward momentum. A falling
      // opponent is NOT, by itself, evidence that ground control has failed.
      const groundCanInterrupt=a.ground&&groundHitReady&&(!unifiedSon||targetDamageReady)&&o.reach<=3&&!raised
        &&(!response.threat||response.action==='interrupt'||!enemyInReach)
      const closing=-separating
      const shortRecovery=unifiedSon&&((axeSpacing&&a.held!==7)||a.charge<=.9||o.reach<2.85||s.closeFight)
        ?sonRecoveryPlan(frame,probe):null
      response.shieldUnavailable=Boolean(response.threat&&!a.shieldAvailable)
      const groundAttackJustSent=unifiedSon&&tick===s.lastGroundAttempt&&a.ground&&o.reach>2.3
      const canControl=Boolean(shortRecovery||groundAttackJustSent||axeSpacing&&s.runJumpRecovery||groundCanInterrupt&&o.reach>=2.3)
      const lostSpacing=o.visible&&(!unifiedSon||o.reach<=2.5)&&(o.reach<=2.3&&nextReach<=3
        ||closing>.03&&nextReach<=2.3&&!groundCanInterrupt)&&!canControl
      const closeAfterStun=Boolean(profile?.().requireAxeBeforeSword&&s.stunSwordOpportunity
        &&tick-s.stunSwordOpportunity.tick<=8&&o.visible&&o.reach<=2.5&&!raised
        &&(closing>.01||nextReach<=2.5))
      const threatenedContact=!recovery&&(unifiedSon?lostSpacing:
        response.threat&&response.action!=='interrupt'&&enemyInReach)
      const restoredInterrupt=response.action==='interrupt'&&a.ground&&groundHitReady&&(!unifiedSon||targetDamageReady)&&o.reach<=3
        &&s.closeFight&&!s.closeFight.firstHitDone&&!axePressure
      if(restoredInterrupt)s.closeFight=null
      let closeExit=null
      if(unifiedSon&&s.closeFight&&!closeAfterStun&&(o.reach>2.5||shortRecovery&&(separating>.02||o.reach>=2.3))){
        const last=closeCommand(s,frame,probe)
        if(last.intent==='close-exit-hit'&&last.attack)closeExit=last
        s.closeFight=null
      }
      if(s.closeFight&&(!o.visible||o.reach>3&&o.otherReach>3&&nextReach>3||offhandControl&&o.arrowThreat||mutualShieldHold||axePressure))s.closeFight=null
      if(!s.closeFight&&threatenedContact&&(!offhandControl||!o.arrowThreat)&&!mutualShieldHold&&!axePressure)
        s.closeFight={enteredAt:tick,firstHitDone:false,afterStunAt:null,unified:unifiedSon,
          axeOpenerDone:!profile?.().requireAxeBeforeSword||tick-s.lastAxeStrikeTick<=6,
          reason:unifiedSon?'lost-spacing-sword-exchange':'incoming-critical-sword-exchange'}
      if(closeAfterStun&&!s.punishmentShield)s.closeFight={...(s.closeFight||{}),enteredAt:s.closeFight?.enteredAt??tick,
        firstHitDone:false,afterStunAt:s.stunSwordOpportunity.tick,unified:unifiedSon,axeOpenerDone:true,
        reason:'close-stun-sword-exchange'}
      if(recovery)s.closeFight=null
      // Shield is a close-range rhythm change while our sword recharges,
      // never an opening stance or an alternative to an incoming crit combo.
      const rhythmGuard=offhandControl&&enemyInReach&&a.shieldAvailable&&a.charge<.55&&enemyChargeUpper>=.65
        &&o.targetGrounded&&!s.closeFight&&!recovery&&!blockReply&&!o.targetBow&&!o.targetLoading
      response.groundInterruptAvailable=response.action==='interrupt'&&groundCanInterrupt
      response.action=mutualShieldHold||rhythmGuard||axePressure?'shield':s.closeFight?'close-combo':response.action==='interrupt'?'interrupt':'ground'
      const guarding=mutualShieldHold||rhythmGuard||axePressure
      let movement=recovery?{heading:recovery.heading,sprint:true,retreat:true,reason:'checked-sword-disengage'}
        :o.visible&&!s.closeFight?(strictGround?(axeSpacing&&profile?.().retreatMode==='short-ground'&&a.held===7
          ?axeChargeMotion(frame,probe):originalSonMotion(axeSpacing&&a.held!==7?{...frame,self:{...a,charge:0}}:frame,probe)):groundMotion(frame,probe,guarding)):null
      if(unifiedSon&&!s.closeFight&&shortRecovery&&(movement?.retreat||o.reach<2.85))movement=shortRecovery
      // Recovery already compared straight and diagonal runs. Do not rotate
      // its collision-checked heading again in the optional side-step layer.
      if(strictGround&&sideSteps&&movement?.reason!=='short-run-restores-ground-control')movement=sonSideSteps(frame,probe,movement)
      if(profile?.().retreatMode==='short-ground')s.runJumpRecovery=null
      else if((axeSpacing||s.runJumpRecovery)&&!s.closeFight)movement=fullRunJumpRecovery(s,frame,probe,movement)
      if(s.closeFight)s.runJumpRecovery=null
      const c={kind:'legacy86-ground',phase:'GROUND_CONTROL',slot:axeSpacing?7:0,offhand:'shield',shield:guarding,
        attack:false,doubleAttack:false,critical:false,jump:Boolean(movement?.jump),sneak:false,ranged:null,
        forward:0,side:0,sprint:!guarding&&Boolean(movement?.sprint),worldHeading:movement?.heading||null,
        aimAway:false,keepLook:false,decidedTick:tick,ppoEligible:false}
      if(axeSpacing){c.spacingProfile='axe';c.rangedShieldOnly=true;c.impactDirection={x:dx/n,z:dz/n}}
      if(movement?.reason==='full-sprint-jump-recovery'&&a.ground&&!c.jump&&s.runJumpRecovery?.jumpedAt==null)
        c.prepareReverseSprint=true
      c.keepTargetLook=!(movement?.retreat&&o.reach>3.4&&!guarding)
      // A real recovery sprint faces its route. A legal contact attack snaps
      // to the closest hitbox point and restores that running view atomically.
      if(unifiedSon&&movement?.retreat&&movement.sprint&&!guarding)c.keepTargetLook=false
      if(unifiedSon&&movement?.retreat&&groundAttackJustSent)c.spacingUrgent=true
      // Guarding must face the enemy, even when a checked retreat exists.
      // Movement then uses ordinary backward/lateral shield walking.
      if(guarding){c.worldHeading=null;c.forward=-1;c.sprint=false}
      if(raised&&!s.previousShield)s.shieldSeenAt=tick
      s.previousShield=raised
      // targetShieldFacing already includes the public use warm-up. Do not
      // wait another five ticks after an effective shield is observed.
      const effective=raised&&(o.targetShieldFacing||tick-s.shieldSeenAt>=5)
      if(o.visible&&o.reach<=3&&!guarding&&(!offhandControl||!o.arrowThreat)&&!live.pending.size){
        if(effective&&tick-s.lastStunAt>=10){
          c.kind='legacy86-stun';c.slot=7;c.attack=c.doubleAttack=true
          if(axeSpacing)c.stunReturnSlot=7
        }else if(!raised&&groundHitReady&&(!unifiedSon||targetDamageReady)){
          c.attack=true
          // The isolated Son skill preserves its navigation while striking,
          // matching ground-control-son.cjs. Legacy default remains intact.
          if(offhandControl){c.forward=1;c.side=0;c.sprint=true;c.worldHeading=null}
          c.attackRole=strictGround||o.reach>=2.95?'spacing':'ground-catch'
          if(c.attackRole==='spacing')c.requestedReachBand=[2.95,3]
        }
      }
      if(recovery){
        const exit=o.reach>=2.6&&o.reach<=3&&separating>.03&&nextReach>3&&a.charge>=.2&&!raised
        c.kind=exit?'legacy86-close':'legacy86-ground';c.slot=0;c.shield=false
        c.attack=exit;c.doubleAttack=false;c.critical=exit&&a.critical&&a.charge>.9
        c.worldHeading=movement.heading;c.sprint=!c.critical;c.keepTargetLook=false
        c.intent=exit?'close-exit-hit':'sword-disengage';c.attackRole=exit?'exit':undefined
        delete c.requestedReachBand
      }
      if(closeExit&&c.kind!=='legacy86-stun'){
        Object.assign(c,{kind:'legacy86-close',slot:0,intent:'close-exit-hit',attackRole:'exit',
          attack:true,doubleAttack:false,critical:closeExit.critical,shield:false,jump:false,
          sprint:!closeExit.critical&&Boolean(movement?.sprint),keepTargetLook:false})
        delete c.requestedReachBand
      }
      if(s.closeFight){
        if(profile?.().requireAxeBeforeSword&&!s.closeFight.axeOpenerDone){
          const stun=c.kind==='legacy86-stun'
          Object.assign(c,{kind:stun?'legacy86-stun':'legacy86-close-axe-opener',slot:7,
            intent:'axe-before-transformer-sword',attack:stun||a.held===7&&o.visible&&o.reach<=3&&!live.pending.size,
            doubleAttack:stun,jump:false,critical:false,shield:false,ranged:null,
            forward:0,side:0,sprint:false,worldHeading:null,keepTargetLook:true})
          delete c.requestedReachBand
        }else{
        const modelFallback=Boolean(profile?.().legacySwordFallback)
        const close=modelFallback?legacySwordCommand(s,frame):closeCommand(s,frame,probe)
        if(!close){
          const retreat=sonRecoveryPlan(frame,probe)||originalSonMotion(frame,probe)
          Object.assign(c,{slot:0,jump:false,shield:false,intent:'frozen-model-pending-sword',worldHeading:retreat?.heading||null,
            sprint:Boolean(retreat?.sprint),keepTargetLook:false})
        }
        else {
        if(c.kind==='legacy86-stun')Object.assign(c,{forward:close.forward,side:close.side,sprint:close.sprint,
          jump:close.jump,worldHeading:null,keepLook:false,shield:false})
        else Object.assign(c,close)
        delete c.requestedReachBand
        }
        }
      }
      const finalSwordExit=profile?.().legacySwordFallback?swordExitCommand(s,frame,probe):null
      if(finalSwordExit&&!live.pending.size){Object.assign(c,finalSwordExit);delete c.requestedReachBand}
      if(blockReply&&c.attack)c.consumesBlock=s.lastBlock
      let selectedBranch=mutualShieldHold?'ground-son:mutual-shield-hold':axePressure?'ground-son:axe-pressure-shield':rhythmGuard?'ground-son:rhythm-shield'
        :recovery?c.intent:c.kind==='legacy86-stun'?'ground-son:stun-double':s.closeFight?c.intent:'ground-son:'+response.action
      if(offhandControl&&o.arrowThreat){
        const canShield=a.shielding||a.shieldAvailable&&o.arrowThreat.time>=(o.offhandShieldReady?5:6)
        Object.assign(c,{shield:canShield,attack:false,doubleAttack:false,
          jump:!canShield&&Boolean(a.ground&&o.arrowThreat.jump),sprint:false,
          worldHeading:null,forward:0,side:canShield?0:o.arrowThreat.side||0,
          keepLook:!canShield,arrowYaw:canShield?o.arrowThreat.yaw:undefined,slot:a.held})
        selectedBranch=canShield?'ground-son:guard-arrow':'ground-son:dodge-arrow'
      }
      const ranged=offhandControl?syncRanged(s,frame,c,{emergency:guarding||Boolean(s.closeFight)||response.action==='interrupt',mirrorBowWithShield:true}):null
      if(ranged){Object.assign(c,ranged);selectedBranch='sync-ranged:'+ranged.rangedReason}
      // No weapon fire may inherit a pending axe double-strike. This is also
      // consumed by the common executor's immediate sword-return transaction.
      if(c.ranged)c.doubleAttack=false
      if(!o.visible||o.reach>3||live.pending.size)c.attack=c.doubleAttack=false
      const scripted=shieldScript?selectShieldScript(s,frame,movement,response):null
      if(scripted){Object.assign(c,scripted);delete c.requestedReachBand;delete c.attackRole;s.closeFight=null;s.runJumpRecovery=null}
      // A block is actionable immediately, including the tick a shield is
      // disabled. It is an optional legal counter, never a wait/handoff phase.
      if(axeSpacing&&!scripted&&!a.shieldAvailable&&blockReply&&a.held===7&&groundCharge>=.7
          &&o.visible&&o.reach<=3&&!o.targetShieldRaised&&!live.pending.size&&!s.closeFight){
        Object.assign(c,{kind:'legacy86-counter',slot:7,attack:true,doubleAttack:false,shield:false,
          jump:false,critical:false,consumesBlock:s.lastBlock})
      }
      const arbitration=unifiedSon?sonSkills(s,frame,probe,c,movement,enemyChargeUpper,response,profile?.()):null
      if(arbitration){Object.assign(c,arbitration.command);selectedBranch='son:'+arbitration.skill}
      applyJumpOwnership(c,frame,arbitration?.skill,profile?.())
      if(isCurrent&&!isCurrent()||baseStateVersion!==live.decisionVersion)return null
      const original={axeSpacing,shieldScript:Boolean(scripted),phase:c.phase,counterHopActive:false,hasPendingAttack:live.pending.size>0,sprintKnockback:!s.closeFight}
      const p={mode:'GROUND_SON',owners:Object.fromEntries(['movement','sprint','jump','look','sneak','mainhand','attack','shield','offhand'].map(k=>[k,'ground-son'])),
        command:c,original,originalCommand:{...c},commandChanges:{},selectedBranch,airPlan:{...response,valid:response.threat},
        groundContact:{axeSpacing,runJumpRecovery:s.runJumpRecovery,spacingImpact:s.spacingImpact,controller:'former-WaveDogSon',response,movement,recovery,shortRecovery,canControl,groundAttackJustSent,afterOurHit,enemyInReach,mutualShieldHold,rhythmGuard,axePressure,blockReply,
          enemyChargeUpper,enemyChargeSource:'confirmed-own-receipt-with-delay-upper-bound',
          strictGround,requestedReachBand:strictGround?[2.95,3]:undefined,
          centerPriority:strictGround?'original-son-navigation':'exact-combat-tie-only'},
        sonArbitration:arbitration?{...arbitration,command:undefined}:undefined,
        closeFight:s.closeFight?{...s.closeFight}:null,
        runtimeMs:0,baseStateVersion,statePatch:Object.fromEntries(fields.map(k=>[k,s[k]]))}
      if(!transactional&&!commitDecision(live,p))return null
      return p
    },
    applied(s,c,actual,tick){
      shieldApplied(s,c,actual,tick)
      if(c.exitBOnAttack&&actual.attacked){
        s.punishmentShield=null;s.bExitRun={tick,origin:c.exitOrigin,heading:c.worldHeading}
      }
      if(c.intent==='old-transformer-sword-fallback'||c.intent==='frozen-model-pending-sword')s.swordExitArmed={tick}
      if(c.intent==='close-exit-hit'&&actual.attacked){s.swordExitArmed=null;s.closeFight=null}
      if((actual.attacks||[]).some(h=>h.attempted&&!h.cancelled&&h.held===7)){
        s.lastAxeStrikeTick=tick
        if(s.closeFight)s.closeFight={...s.closeFight,axeOpenerDone:true}
      }
      if(c.kind==='legacy86-stun'&&(actual.attacks||[]).some(h=>h.attempted&&h.targetShieldCooldown>0))
        s.stunSwordOpportunity={tick,confirmedShieldBreak:true}
      if(c.prepareReverseSprint&&s.runJumpRecovery&&actual.sprint&&actual.forward>.99&&!actual.jump){
        const old=s.runJumpRecovery,h=c.worldHeading
        const same=old.preparedHeading&&h&&old.preparedHeading.x*h.x+old.preparedHeading.z*h.z>.99
        // Preserve the first receipt for this direction across sub-tick polls.
        // A changing tick number alone does not prove input reached physics.
        if(!same||old.groundSprintAt==null)s.runJumpRecovery={...old,groundSprintAt:tick,
          groundSprintAfterPhysics:actual.physicsTick,preparedHeading:h}
      }
      if(actual.jump&&s.runJumpRecovery)s.runJumpRecovery={...s.runJumpRecovery,jumpedAt:tick}
      if(actual.attacked){s.lastAttempt=tick
        if(c.kind==='legacy86-ground')s.lastGroundAttempt=tick
        if(c.slot===7&&['legacy86-ground','legacy86-stun','legacy86-counter'].includes(c.kind)){
          const hit=[...(actual.attacks||[])].reverse().find(h=>h.targetDamage>0)
          if(hit){
            const v=hit.targetVelocityPacket||{},speed=Math.hypot(v.x||0,v.z||0)
            const h=c.impactDirection||{x:speed?(v.x||0)/speed:0,z:speed?(v.z||0)/speed:1}
            s.spacingImpact={tick,ux:h.x,uz:h.z,outwardSpeed:hit.targetOutwardSpeed??speed,
              reducedKB:hit.outwardMotionConfirmed===false,jumpResetObserved:false}
            if(!c.shieldScriptKind){
              s.runJumpRecovery=profile?.().retreatMode==='short-ground'?null:{startedAt:tick,jumpedAt:null,reason:'unshielded-axe-hit'}
              s.closeFight=null
            }
          }
        }
        if(Number.isFinite(c.consumesBlock))s.spentBlock=Math.max(s.spentBlock,c.consumesBlock)
        if(c.kind==='legacy86-stun')s.lastStunAt=tick
        if(s.closeFight&&c.kind==='legacy86-stun')s.closeFight.afterStunAt=tick
        if(s.closeFight&&c.kind==='legacy86-close'){s.closeFight.firstHitDone=true;s.closeFight.afterStunAt=null}
        for(const attack of actual.attacks||[])s.pending.set(attack.id,{tick})
      }
    },rangedApplied,close:async()=>{}}
}
module.exports={createGroundBrain,groundMotion,originalSonMotion,axeChargeMotion,retreatEntryRisk,swordExitCommand,applyJumpOwnership,sonSideSteps,sonSkills,disengagePlan,sonRecoveryPlan,fullRunJumpRecovery,legacySwordCommand}
