'use strict'
// Port of the supplied RangedAim: solve target motion and vanilla projectile
// flight together. This returns mouse direction only; it never controls firing.
const HORIZON=32,DRAG=.99,GRAVITY=.05
const power=[1],sums=[0]
for(let i=1;i<=HORIZON;i++){sums[i]=sums[i-1]+power[i-1];power[i]=power[i-1]*DRAG}
const finite=v=>v&&['x','y','z'].every(k=>Number.isFinite(v[k]))
function learnedLead(profile,airborne,time){
  const points=[[2,'near'],[6,'medium'],[12,'far'],[24,'long']]
  const baseline=Number.isFinite(profile?.baselineLead)?Math.max(-.25,Math.min(2,profile.baselineLead)):1
  const at=name=>{const item=profile?.buckets?.[(airborne?'air':'ground')+':'+name]
    return item?.accepted&&Number.isFinite(item.lead)?Math.max(-.25,Math.min(2,item.lead)):baseline}
  if(time<=points[0][0])return at(points[0][1])
  for(let i=1;i<points.length;i++)if(time<=points[i][0]){
    const fraction=(time-points[i-1][0])/(points[i][0]-points[i-1][0])
    return at(points[i-1][1])*(1-fraction)+at(points[i][1])*fraction
  }
  return at('long')
}
function solveRangedAim({eye,inherited={x:0,y:0,z:0},feet,motion,airborne=false,floorY,height=1.8,speed,profile=null}){
  if(!finite(eye)||!finite(inherited)||!finite(feet)||!finite(motion)||!Number.isFinite(floorY)
    ||!Number.isFinite(height)||height<=0||!Number.isFinite(speed)||speed<=.05)return null
  const heights=[airborne?Math.max(floorY,feet.y):feet.y]
  let vy=motion.y,landed=!airborne
  for(let i=1;i<=HORIZON;i++){
    if(landed)heights[i]=heights[i-1]
    else {vy=(vy-.08)*.98;heights[i]=heights[i-1]+vy
      if(heights[i]<=floorY){heights[i]=floorY;landed=true}}
  }
  function required(time){
    const whole=Math.min(HORIZON,Math.floor(time)),fraction=time-whole
    const sum=sums[whole]+fraction*power[whole],gravityY=-GRAVITY/(1-DRAG)*(time-sum)
    const predictedY=heights[whole]+(whole<HORIZON?fraction*(heights[whole+1]-heights[whole]):0)
    const lead=learnedLead(profile,airborne,time),aimY=predictedY+.55*height
    return {x:(feet.x+lead*motion.x*time-eye.x)/sum-inherited.x,
      y:(aimY-eye.y-gravityY)/sum-inherited.y,
      z:(feet.z+lead*motion.z*time-eye.z)/sum-inherited.z}
  }
  const error=t=>{const v=required(t);return Math.hypot(v.x,v.y,v.z)-speed}
  let low=1e-6
  for(let i=1;i<=HORIZON*4;i++){
    let high=i*.25
    if(error(high)<=0){
      for(let j=0;j<32;j++){const mid=(low+high)/2;if(error(mid)>0)low=mid;else high=mid}
      const flightTicks=(low+high)/2,v=required(flightTicks),length=Math.hypot(v.x,v.y,v.z)
      if(!Number.isFinite(length)||length<1e-12||Math.abs(length-speed)>.001)return null
      return {direction:{x:v.x/length,y:v.y/length,z:v.z/length},flightTicks,
        lead:learnedLead(profile,airborne,flightTicks),airborne,
        calibrationSha256:profile?.sourceSha256??null}
    }
    low=high
  }
  return null
}
module.exports={solveRangedAim,learnedLead}
