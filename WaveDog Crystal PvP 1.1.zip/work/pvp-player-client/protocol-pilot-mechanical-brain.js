'use strict'
const {orbitGoal,orbitHeading,confirmedRear}=require('./protocol-mechanical-math')
// One planner. No network, inventory, movement or attack side effects here.
// Public observations only; receipt IDs bind counter ownership to an actual hit.
function createState (opponent = 'opponent', fighter = 'WaveDog') {
  return { opponent, fighter, mode: 'GUARD', blocked: null, pending: null, shieldUntil: 0,
    orbitUntil: 0, nextOrbit: 0, side: 1,
    ranged: null, rangedAt: 0, rangedPhase:null,rangedSerial:0,spentShotEvent:0,
    rangedUseAt:0,spentBowCycle:0,spentLoadCycle:0,loadingReply:null,orbitGoal:null,orbitLastAt:-1000,orbitWoundAt:-1000,
    guardWound:null,woundSerial:0,woundSpent:0,orbitAttempt:false,orbitReblock:false,
    rearSeen:false,rearAt:-1000,rearSpent:-1000,sideUntil:0,
    previousReach:Infinity,openingSeen:false,openingAt:-1000,takeOpening:false,
    nextRanged: 0, transitions: [], nextId: 1 }
}
function transition (s, mode, tick, reason) {
  if (s.mode === mode) return
  s.transitions.push({ tick, from: s.mode, to: mode, reason })
  s.mode = mode
}
function receipt (s, e, tick) {
  if (e.type === 'shield_disabled') s.shieldUntil = tick + e.cooldownTicks
  if (e.type === 'self_state') s.shieldUntil = tick + e.shieldCooldown
  // A disable receipt can arrive after the counter packet. That receipt must
  // not leave the actor waiting for damage or start an old escape sequence.
  if(tick<s.shieldUntil&&s.mode==='COUNTER'&&s.pending?.kind==='counter'&&s.pending.packet)
    transition(s,'NEURAL',tick,'shield-disabled-after-counter-packet')
  if (e.type === 'blocked_melee') s.blocked = { tick, id: e.blockId }
  if(e.type==='damage'&&e.victim===s.fighter&&e.attacker===s.opponent
      &&e.melee&&!e.cancelled&&e.amount>0&&s.mode==='GUARD') {
    const orbit=s.orbitAttempt||tick<s.orbitUntil||tick-s.orbitLastAt<=1
    s.guardWound={tick,serial:++s.woundSerial,kind:orbit?'orbit-reply':'guard-reply'}
    if(orbit)s.orbitWoundAt=tick
    s.orbitUntil=0;s.orbitAttempt=false;s.orbitReblock=true
  }
  if (e.type === 'attack_packet' && s.pending?.id === e.attackId){
    s.pending.packet = e.willAttack !== false
    if(s.pending.packet&&s.pending.kind==='counter'&&tick<s.shieldUntil){
      s.blocked=null
      transition(s,'NEURAL',tick,'counter-packet-receipt-direct-neural')
    }
  }
  if (e.type !== 'damage' || e.cancelled || !(e.amount > 0)) return
  if (e.attacker === s.fighter && e.victim === s.opponent
      && s.pending?.id === e.attackId && s.pending.packet && tick - s.pending.tick <= 8) {
    if (s.pending.kind === 'counter') {
      if (tick < s.shieldUntil) transition(s,'NEURAL',tick,'counter-hit-shield-disabled')
      else if(s.mode==='COUNTER') transition(s, 'GUARD', tick, 'counter-hit-shield-available')
    }
    s.pending = null
  }
}
const neutral = () => ({ forward: 0, side: 0, sprint: false, jump: false,
  sneak: false, slot: null, attack: false, shield: false, offhand: 'shield', ranged: null })
function requestAttack (s, c, kind, tick) {
  c.attack = true; c.shield = false; c.kind = kind; c.attackId = s.nextId++
  s.pending = { id: c.attackId, kind, tick, packet: false }
}
function safeShieldReturn(o){
  if(!o.visible||o.mutualOutOfReach!==true||!Number.isFinite(o.reach)
      ||o.targetAirborneThreat||o.targetCriticalThreat)return false
  const dx=(o.target?.x??0)-(o.self?.x??0),dz=(o.target?.z??0)-(o.self?.z??0),d=Math.hypot(dx,dz)
  const v=o.selfVelocity,tv=o.targetVelocity
  const closing=d>.001&&v&&tv?((v.x-tv.x)*dx+(v.z-tv.z)*dz)/d:o.targetApproachSpeed
  // Protection needs five native warm-up ticks, plus a packet interval.
  // Include current relative motion and a normal sprint approach reserve;
  // merely having left reach this instant is not a safe ownership boundary.
  const reserve=Math.max(.32,Number.isFinite(closing)?closing:.32)*6
  return Math.min(o.reach,Number.isFinite(o.otherReach)?o.otherReach:o.reach)-3>reserve
}
function plan (s, o, neural) {
  const t = o.tick, c = neutral()
  const owners = { movement: 'mechanical', sprint: 'mechanical', jump: 'mechanical', look:'mechanical',
    sneak: 'disabled', mainhand: 'mechanical', attack: 'mechanical', shield: 'mechanical', offhand: 'mechanical' }
  const shieldReady = o.shieldReady && t >= s.shieldUntil
  // Charge belongs to the observed held weapon, not the slot we plan to select.
  const holdingAxe = o.held === 7
  // Shield disable attempts and damage/knockback readiness are different.
  // Do not invent a damage-charge floor against an actually effective shield.
  const counterChargeReady=o.charge>=.7||o.targetShieldFacing===true
  const orbitAllowed=Number.isFinite(o.health)&&o.health>5
  if(!orbitAllowed){
    if(s.orbitAttempt)s.orbitReblock=true
    s.orbitUntil=0;s.orbitAttempt=false
  }
  const airGuard=shieldReady&&s.mode!=='NEURAL'&&o.visible&&Boolean(o.targetAirborneThreat||o.targetCriticalThreat)
  // Original OrbitContact: a newly seen rear window is independent of whether
  // this controller started an orbit. Claim it once; never turn it into spam.
  const rear = o.visible && o.reach <= 3 && confirmedRear(o.self,o.sentPosition,o.target,o.targetYaw)
    && !o.targetCriticalThreat
  if(s.orbitAttempt&&t>=s.orbitUntil){s.orbitAttempt=false;s.orbitReblock=true}
  if(s.orbitReblock&&o.shieldEffective)s.orbitReblock=false
  if (rear && !s.rearSeen) s.rearAt = t
  s.rearSeen = rear
  const enteredReach=o.visible&&o.reach<=3&&s.previousReach>3
  s.previousReach=o.visible?o.reach:Infinity
  // Raised-but-not-yet-effective is not evidence that the shield is down.
  // While using a shield, only a packet-confirmed rear can arm an opening.
  const exposed=o.visible&&(o.targetShieldRaised?rear:!o.targetShieldFacing)
  if(!exposed){s.openingSeen=false;s.takeOpening=false}
  else if(!s.openingSeen||t-s.openingAt>=2){
    s.openingSeen=true;s.openingAt=t
    const chance=(rear ? .85 : .3)*(o.targetSwingRecent ? .15 : 1)
    s.takeOpening=(o.openingDraw??Math.random())<chance
  }
  if (s.pending && t - s.pending.tick > 8) {
    if (s.pending.kind === 'counter'&&s.mode==='COUNTER') transition(s, shieldReady ? 'GUARD' : 'NEURAL', t, 'counter-no-confirmed-hit')
    s.pending = null
  }
  if(!['GUARD','COUNTER','SHIELD_RETURN','NEURAL'].includes(s.mode))
    transition(s,'NEURAL',t,'unsupported-mechanical-phase-to-neural')
  const counterReady=s.blocked&&t-s.blocked.tick<=6&&o.visible&&o.reach<=3
    &&holdingAxe&&counterChargeReady
  if (s.mode === 'GUARD' && !shieldReady && !counterReady)
    transition(s, 'NEURAL', t, 'shield-disabled-no-ready-counter')
  if (s.mode === 'NEURAL' && shieldReady&&safeShieldReturn(o)) transition(s, 'SHIELD_RETURN', t, 'shield-ready-safe-separation')
  if(s.mode==='SHIELD_RETURN'&&!shieldReady)transition(s,'NEURAL',t,'shield-disabled-during-return')
  if (s.mode === 'SHIELD_RETURN' && o.shieldEffective && shieldReady)
    transition(s, 'GUARD', t, 'shield-effective-five-ticks')

  if (s.mode === 'NEURAL') {
    if (neural && t - neural.decidedTick >= 0 && t - neural.decidedTick <= 3) {
      Object.assign(c, neural, {slot:[0,7].includes(neural.slot)?neural.slot:o.held,
        kind:'neural',shield:false,use:false,release:false,offhand:'shield',ranged:null,
        blockedModelHeads:[...(neural.shield||neural.use||neural.release?[4]:[]),
          ...(![0,7].includes(neural.slot)?[5]:[])]})
      for (const k of ['movement','sprint','jump','mainhand','attack','look','sneak']) owners[k] = 'neural'
    } else for (const k of ['movement','sprint','jump','mainhand','attack','look','sneak']) owners[k] = 'neutral-expired'
  } else {
    c.slot = 7
    c.shield = shieldReady
    if (s.mode === 'GUARD' && !airGuard) {
      if (t >= s.sideUntil) {
        s.side = (o.sideDraw ?? Math.random()) < .5 ? -1 : 1
        s.sideUntil = t + 8 + Math.floor((o.sideDurationDraw ?? Math.random()) * 9)
      }
      // Original pressureMove: approach diagonally, side-step only in overlap.
      c.forward = o.reach > .65 ? 1 : 0
      c.side = o.visible ? s.side : 0
      const wasOrbit=t<s.orbitUntil||t-s.orbitLastAt<=1
      const wounded=s.guardWound&&s.guardWound.serial>s.woundSpent
        &&t>=s.guardWound.tick&&t-s.guardWound.tick<=3
      const rearWindow=rear && (s.rearAt>s.rearSpent || o.charge>=.999)
      // A real block outranks a speculative rear opening. With our shield
      // still available, original ORBIT_TRADE takes priority over a retained
      // block record; otherwise its lower-charge wound reply expires unused.
      // Shield-disabled counter -> sword-hop retains its original priority.
      const blockPending=s.blocked && t-s.blocked.tick<=6
      if((!blockPending||shieldReady)&&!s.pending&&wounded&&exposed&&o.visible&&o.reach<=3
          &&holdingAxe&&!o.targetCriticalThreat){
        requestAttack(s,c,s.guardWound.kind,t);c.woundSerial=s.guardWound.serial
        c.forward=1;c.side=0;c.sprint=true
        s.orbitUntil=0;s.orbitAttempt=false;s.orbitReblock=true
      } else if(!blockPending&&!s.pending&&rear&&(rearWindow||wasOrbit)
          &&o.visible&&o.reach<=3&&!o.targetShieldFacing&&!o.targetCriticalThreat
          &&holdingAxe&&o.charge>=.999) {
        requestAttack(s,c,'orbit-rear',t)
        c.forward=1;c.side=0;c.sprint=true;s.orbitUntil=0;s.orbitAttempt=false
      } else if(s.orbitReblock){
        c.shield=shieldReady;c.sprint=false;c.orbitStatus='reblock-after-orbit'
      } else if(!blockPending&&!s.pending&&exposed&&o.reach<=3&&holdingAxe&&o.charge>=.999
          &&!o.targetCriticalThreat&&(enteredReach||s.takeOpening)){
        // Original pressure(): take a newly entered/exposed window, rather
        // than waiting forever for a block when the opponent does not attack.
        requestAttack(s,c,'guard-opening',t)
        c.forward=1;c.side=0;s.orbitUntil=0
      } else if(t<s.orbitUntil) {
        if(!o.ground||o.wallMargin<.8||o.targetCriticalThreat){s.orbitUntil=0;s.orbitAttempt=false;s.orbitReblock=true}
        else {
          c.worldHeading=orbitHeading(o.self,o.target,s.orbitGoal)
          if(!c.worldHeading){s.orbitUntil=0;s.orbitAttempt=false;s.orbitReblock=true}
          else {c.shield=false;c.forward=1;c.side=0;c.sprint=true;c.orbit=true}
        }
      } else if(orbitAllowed&&!s.pending&&!wounded&&o.shieldEffective&&o.targetShieldFacing
          &&o.distance<=.85&&o.reach<.85&&o.ground
          &&o.targetGrounded!==false&&!o.targetCriticalThreat&&!o.targetSwingRecent
          &&holdingAxe&&o.charge>=.999&&t>=s.nextOrbit&&o.wallMargin>1.2&&o.self&&o.target) {
        s.nextOrbit=t+8
        if((o.orbitDraw??Math.random())<.45) {
          s.side=o.orbitSide??(Math.random()<.5?-1:1)
          s.orbitGoal=orbitGoal(o.targetYaw,s.side<0);s.orbitUntil=t+5
          s.orbitAttempt=true
          c.worldHeading=orbitHeading(o.self,o.target,s.orbitGoal)
          if(c.worldHeading){c.shield=false;c.forward=1;c.side=0;c.sprint=true;c.orbit=true}
        }
      }
      if (blockPending && o.visible && o.reach <= 3
          && holdingAxe && counterChargeReady && !s.pending && !c.attack) {
        requestAttack(s, c, 'counter', t)
        // After the actual packet, an unavailable shield ends mechanical
        // melee ownership. The model chooses its own next weapon and movement.
        c.sprint = true; c.forward = 1
        transition(s, 'COUNTER', t, 'confirmed-own-melee-block')
      }
    }
    // COUNTER immediately asks to re-raise; an attack command itself releases.
  }
  if (s.mode === 'COUNTER' && !c.attack) c.shield = shieldReady

  // Ranged is an offhand overlay, never a movement command or an early return.
  const legalStrike = c.attack && o.visible && o.reach <= 3
  // A usable shield handles opposing bows. Do not drop it to mirror a draw;
  // if it recovers during our draw, cancel that bow instead of releasing it.
  // A disabled/inaccessible shield still permits the existing bow mirror.
  if(shieldReady&&s.ranged==='bow'){s.ranged=null;s.rangedPhase=null}
  const mirrorBowShot=s.ranged==='bow'&&(o.targetShotEvent||0)>(s.rangedShotEvent||0)
    &&t-(o.targetShotTick??-1000)>=0&&t-o.targetShotTick<=3
  const arrowShield=shieldReady&&o.offhandShieldReady
    &&(o.shieldEffective||o.arrowThreat?.time>=5)
  const bowDodgeReply=mirrorBowShot&&o.arrowThreat&&!arrowShield
  const crossbowDodgeReply=o.loaded&&(o.targetShotEvent||0)>s.spentShotEvent
    &&t-(o.targetShotTick??-1000)>=0&&t-o.targetShotTick<=3&&o.arrowThreat&&!arrowShield
  const urgent = legalStrike || ['COUNTER','SHIELD_RETURN'].includes(s.mode)
    || Boolean(s.orbitReblock&&shieldReady)
    || Boolean(s.blocked && t - s.blocked.tick < 7) || o.arrowThreat&&!bowDodgeReply&&!crossbowDodgeReply
  // A fresh public load authorizes one loaded shot, one reload and (only if
  // still unshielded when that reload completes) one follow-up. Equipment
  // acknowledgements advance this sequence, never elapsed load time alone.
  const unshielded=!o.targetShieldRaised&&!o.targetShieldFacing
  const loadingReply=o.loaded&&o.targetLoading&&unshielded&&Number.isSafeInteger(o.targetLoadCycle)
    &&o.targetLoadCycle>s.spentLoadCycle
  // Mirroring a public ranged action is legal at close range too. The former
  // blanket six-block cutoff silently disabled the original close bow mirror
  // and repeatedly cancelled crossbow loading when either player approached.
  // Real melee/arrow emergencies still preempt within this same command.
  const safe = o.visible && !urgent
  if (!safe) {s.ranged=null;s.rangedPhase=null;s.loadingReply=null}
  if(s.loadingReply&&t>s.loadingReply.until)s.loadingReply=null
  if(s.loadingReply?.phase==='await-spent'&&!o.loaded)s.loadingReply.phase='reload'
  if(s.ranged==='fire-crossbow'&&!o.loaded){s.ranged=null;s.rangedPhase=null}
  if(s.rangedSource==='loading-reply-first'&&s.rangedPhase==='prepare'&&!loadingReply){
    s.ranged=null;s.rangedPhase=null
  }
  if(s.rangedSource==='loading-reply-followup'&&s.rangedPhase==='prepare'
      &&(!s.loadingReply||!unshielded)){
    s.ranged=null;s.rangedPhase=null;s.loadingReply=null
  }
  // A stop-use packet can precede charged equipment by one or two ticks.
  // Only preserve an ALREADY running mirrored load; this never starts one.
  const loadConfirmationPending=o.visible&&o.targetLoadResult==='unconfirmed'
    &&t-o.targetLoadEndedAt>=0&&t-o.targetLoadEndedAt<=2
  const sequenceReload=s.loadingReply&&['reload','await-loaded'].includes(s.loadingReply.phase)
  if(s.ranged==='load-crossbow'&&!sequenceReload&&!o.targetLoading&&!o.targetKnownLoaded&&!loadConfirmationPending){s.ranged=null;s.rangedPhase=null}
  if(s.ranged==='bow'&&!o.targetBow&&!mirrorBowShot){s.ranged=null;s.rangedPhase=null}
  if(s.rangedPhase==='verify-fire') {
    if(!o.loaded||t-s.rangedUseAt>=8){
      // Only an observed spent bolt allows our promised reload. If loaded
      // metadata never changes, stop rather than shooting the same event twice.
      if(s.loadingReply?.phase==='await-spent'&&o.loaded)s.loadingReply=null
      const reload=s.loadingReply?.phase==='reload'
      s.ranged=null;s.rangedPhase=null;s.nextRanged=reload?t:Math.max(s.nextRanged,t+15)
    }
  }
  if(s.rangedPhase==='verify-load'&&o.loaded){
    const follow=s.rangedSource==='loading-reply-reload'&&s.loadingReply?.phase==='await-loaded'
    if(follow)s.loadingReply.phase='followup'
    s.ranged=null;s.rangedPhase=null;s.nextRanged=follow?t:t+15
  }
  // Shield warm-up already counts as raising a shield. Do not park a shot
  // authorization until it drops later; this opportunity is checked now.
  if(s.loadingReply?.phase==='followup'&&!unshielded)s.loadingReply=null
  if(s.ranged&&t-s.rangedAt>45){s.ranged=null;s.rangedPhase=null;s.nextRanged=t+15}
  if (safe && !s.ranged && t >= s.nextRanged) {
    s.rangedSource=null
    if (o.loaded && (o.targetShotEvent || 0) > s.spentShotEvent
        && t - (o.targetShotTick ?? -1000) >= 0 && t - o.targetShotTick <= 3) {
      s.ranged = 'fire-crossbow';s.rangedSource='ranged-sync'
    }
    else if(s.loadingReply?.phase==='followup'&&o.loaded&&unshielded){
      s.ranged='fire-crossbow';s.rangedSource='loading-reply-followup'
    }
    else if(s.loadingReply?.phase==='reload'&&!o.loaded&&o.arrows>0){
      s.ranged='load-crossbow';s.rangedSource='loading-reply-reload'
    }
    else if(loadingReply){s.ranged='fire-crossbow';s.rangedSource='loading-reply-first';s.rangedLoadCycle=o.targetLoadCycle}
    else if (!o.loaded && o.arrows > 0 && o.targetLoading)
      s.ranged = 'load-crossbow'
    else if (!shieldReady && o.arrows > 0 && o.targetBow
        &&(!Number.isSafeInteger(o.targetBowCycle)||o.targetBowCycle>s.spentBowCycle)) s.ranged = 'bow'
    if (s.ranged) {
      if(s.ranged!=='fire-crossbow'&&s.rangedSource!=='loading-reply-reload')s.rangedSource='ranged-sync'
      s.rangedAt=t;s.rangedPhase='prepare';s.rangedSerial++;s.rangedShotEvent=o.targetShotEvent||0
      s.rangedBowCycle=o.targetBowCycle
    }
  }
  if (s.ranged&&!s.rangedPhase.startsWith('verify')) {
    c.shield = false; c.offhand = s.ranged === 'bow' ? 'bow' : 'crossbow'
    c.ranged=s.ranged;c.rangedId=s.rangedSerial
    c.rangedRelease=s.ranged==='bow'&&mirrorBowShot
    if(c.rangedRelease)s.rangedShotEvent=o.targetShotEvent
    // A main-hand slot update also interrupts offhand use in vanilla. Only
    // the ranged overlay owns these two channels until it ends/preempts.
    c.slot = o.held; c.attack = false
    owners.mainhand = owners.attack = 'mechanical-ranged'
    owners.offhand=owners.shield='mechanical-ranged'
    c.rangedReason=s.rangedSource||'ranged-sync'
    if(s.ranged==='load-crossbow'&&o.loaded){c.ranged=null;s.ranged=null;s.rangedPhase=null}
  }
  // Arrow emergency can cancel ranged use or a planned strike in the same tick.
  if (o.arrowThreat) {
    const releaseWhileDodging=!legalStrike&&(bowDodgeReply&&c.ranged==='bow'&&c.rangedRelease
      ||crossbowDodgeReply&&c.ranged==='fire-crossbow')
    if(!releaseWhileDodging){s.ranged = null;s.rangedPhase=null;c.ranged = null}
    c.attack = false;c.worldHeading=null;delete c.travelYaw;c.orbit=false
    owners.attack = owners.shield = 'mechanical-arrow'
    owners.look='mechanical-arrow'
    // Side keys were predicted in the current view, so preserve that view
    // during a dodge; turning toward the target would reverse the dodge.
    if (arrowShield) {
      c.shield = true; c.offhand = 'shield'; c.arrowYaw = o.arrowThreat.yaw
      c.aimAway=false;c.forward=c.side=0;c.sprint=c.jump=false
      owners.movement=owners.sprint=owners.jump='mechanical-arrow'
      owners.offhand = 'mechanical-arrow'
    } else {
      c.shield = false; c.side = o.arrowThreat.side || 0
      c.forward = 0; c.sprint = false; c.jump = Boolean(o.ground && o.arrowThreat.jump)
      c.aimAway = false
      c.keepLook = true
      owners.movement = owners.sprint = owners.jump = 'mechanical-arrow'
    }
  }
  // Original shieldAirborne has priority over pressure/opening/orbit/counter
  // and ranged use whenever a usable shield faces a current/future air threat.
  // A truly disabled shield leaves neural melee and its helpers untouched.
  if(airGuard){
    s.orbitUntil=0;s.ranged=null;s.rangedPhase=null
    c.shield=true;c.offhand='shield';c.attack=false;c.ranged=null;c.orbit=false
    c.worldHeading=null;delete c.travelYaw;c.aimAway=false;c.keepLook=false;c.jump=false;c.sprint=false
    // Prepare the axe BEFORE starting shield use. Once raised (including its
    // five-tick warm-up), keep the active stack: switching would drop protection.
    c.slot=o.shieldRaised||o.shieldEffective?o.held:7;c.guardAirborne=true
    c.forward=0;c.side=0;delete c.arrowYaw
    for(const key of ['movement','sprint','jump','mainhand','attack','shield','offhand','look','sneak'])owners[key]='mechanical-airborne-guard'
  }
  if(owners.sneak!=='neural')c.sneak = false
  return { command: c, owners, mode: s.mode }
}
function rangedApplied(s,command,result,tick) {
  if(!command.ranged||command.rangedId!==s.rangedSerial)return
  if(result.fireRejected){s.ranged=null;s.rangedPhase=null;s.loadingReply=null;return}
  if(result.fireSent) {
    s.rangedPhase='verify-fire';s.rangedUseAt=tick
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
    if(s.rangedSource==='loading-reply-first'){
      s.spentLoadCycle=Math.max(s.spentLoadCycle,s.rangedLoadCycle||0)
      s.loadingReply={cycle:s.rangedLoadCycle,phase:'await-spent',until:tick+80}
    }else s.loadingReply=null // any real shot after reload spends the follow-up
  } else if(result.loadReleased) {
    s.rangedPhase='verify-load';s.rangedUseAt=tick
    if(s.rangedSource==='loading-reply-reload'&&s.loadingReply)s.loadingReply.phase='await-loaded'
  }
  else if(result.bowReleased) {
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
    if(Number.isSafeInteger(s.rangedBowCycle))s.spentBowCycle=Math.max(s.spentBowCycle,s.rangedBowCycle)
    // A fresh observed draw may start next frame. The consumed cycle, rather
    // than an eight-tick cooldown, prevents reusing stale pre-release metadata.
    s.ranged=null;s.rangedPhase=null;s.nextRanged=tick+1
  }
  else if(result.useStarted)s.rangedPhase='using'
}
function applied (s, command, attacked, tick) {
  if (s.pending && !s.pending.packet && s.pending.tick === tick && !attacked) {
    const counter=s.pending.kind==='counter';s.pending=null
    if(counter)transition(s,'GUARD',tick,'counter-not-sent-retry-original-block')
  }
  if (attacked && command.kind === 'counter') {
    s.blocked=null
    if(s.pending?.id===command.attackId)s.pending.packet=true
    if(tick<s.shieldUntil)transition(s,'NEURAL',tick,'counter-packet-direct-neural')
  }
  if (attacked && command.kind === 'orbit-rear') s.rearSpent=s.rearAt
  if(attacked&&['orbit-reply','guard-reply'].includes(command.kind))
    s.woundSpent=Math.max(s.woundSpent,command.woundSerial||0)
  if(command.orbit&&Number.isFinite(tick))s.orbitLastAt=tick
}
module.exports = { createState, receipt, plan, applied, rangedApplied, safeShieldReturn }
