'use strict'
// Port only PrecisionFootwork.orbitGoal/orbit; the retired control() is absent.
function orbitGoal (targetYaw, left) {
  const x=-Math.sin(targetYaw), z=-Math.cos(targetYaw), a=(left?150:-150)*Math.PI/180
  return {x:.35*(x*Math.cos(a)-z*Math.sin(a)),z:.35*(x*Math.sin(a)+z*Math.cos(a))}
}
function orbitHeading (self,target,goal) {
  if(!goal)return null
  const x=target.x+goal.x-self.x,z=target.z+goal.z-self.z,length=Math.hypot(x,z)
  return length<.02?null:{x:x/length,z:z/length}
}
function headingKeys (heading,yaw) {
  const forward=-Math.sin(yaw)*heading.x-Math.cos(yaw)*heading.z
  const left=-Math.cos(yaw)*heading.x+Math.sin(yaw)*heading.z
  const angle=Math.atan2(left,forward),octant=Math.round(angle/(Math.PI/4))
  return {forward:Math.abs(octant)<=1?1:Math.abs(octant)>=3?-1:0,
    side:octant>0&&octant<4?-1:octant<0&&octant>-4?1:0}
}
// Project our actual eye onto the target's client-visible collision box. Keep
// an inward epsilon so floating-point rounding cannot put the ray outside it.
function nearestHitPoint (eye, target) {
  const feet=target.position,half=(target.width||.6)/2,height=target.height||1.8
  const clamp=(v,low,high)=>Math.max(low+.0001,Math.min(high-.0001,v))
  const point={x:clamp(eye.x,feet.x-half,feet.x+half),
    y:clamp(eye.y,feet.y,feet.y+height),z:clamp(eye.z,feet.z-half,feet.z+half)}
  if(Math.hypot(point.x-eye.x,point.y-eye.y,point.z-eye.z)<.00001)
    return {x:feet.x,y:feet.y+height/2,z:feet.z}
  return point
}
// Same closest-box projection, with a scale-aware floating-point inset.
// The historical 0.0001 inset is an entire requested 2.9999..3.0 window.
// Keep the legacy export unchanged for other running controller lineages.
function nearestHitPointExact (eye, target) {
  const feet=target.position,half=(target.width||.6)/2,height=target.height||1.8
  const scale=Math.max(1,...[eye.x,eye.y,eye.z,feet.x,feet.y,feet.z].map(Math.abs))
  const inset=Math.min(half/4,height/4,8*Number.EPSILON*scale)
  const clamp=(v,low,high)=>Math.max(low+inset,Math.min(high-inset,v))
  const point={x:clamp(eye.x,feet.x-half,feet.x+half),
    y:clamp(eye.y,feet.y,feet.y+height),z:clamp(eye.z,feet.z-half,feet.z+half)}
  if(Math.hypot(point.x-eye.x,point.y-eye.y,point.z-eye.z)<inset)
    return {x:feet.x,y:feet.y+height/2,z:feet.z}
  return point
}
// Reach is measured to the physical box surface, never to the deliberately
// inset point used to aim into that box.
function nearestBoxPoint(eye,target){
  const p=target.position,half=(target.width||.6)/2,height=target.height||1.8
  const clamp=(v,low,high)=>Math.max(low,Math.min(high,v))
  return {x:clamp(eye.x,p.x-half,p.x+half),y:clamp(eye.y,p.y,p.y+height),
    z:clamp(eye.z,p.z-half,p.z+half)}
}
// Mineflayer's look() rounds by mouse sensitivity and may leave its private
// last-sent view unchanged on tiny turns. Its later physics packet must carry
// the current commanded view rather than overwrite it with that older angle.
function currentViewPacket(name,data,entity){
  if(!['look','position_look'].includes(name)||!Number.isFinite(entity?.yaw)||!Number.isFinite(entity?.pitch))return data
  return {...data,yaw:(Math.PI-entity.yaw)*180/Math.PI,pitch:-entity.pitch*180/Math.PI}
}
// Mineflayer look(force) changes local state but does not write a look packet.
// Combat turns must reach the wire before the following attack, without await.
function immediateLook(bot,yaw,pitch=0){
  bot.look(yaw,pitch,true)
  bot.entity.yaw=yaw;bot.entity.pitch=pitch
  bot._client.write('look',{yaw:(Math.PI-yaw)*180/Math.PI,pitch:-pitch*180/Math.PI,
    onGround:bot.entity.onGround})
}
// A local physics step can cross the shield plane before its position packet
// is sent. Require both positions behind the currently observed shield; never
// send an extra movement packet to manufacture a back hit.
function confirmedRear(self,sent,target,yaw){
  if(!self||!sent||!target||!Number.isFinite(yaw))return false
  const behind=point=>{
    if(![point.x,point.z,target.x,target.z].every(Number.isFinite))return false
    const x=point.x-target.x,z=point.z-target.z,length=Math.hypot(x,z)
    const projection=-Math.sin(yaw)*x-Math.cos(yaw)*z
    return length>.05&&projection<-.1&&projection/length<-.15
  }
  return behind(self)&&behind(sent)
}
module.exports={orbitGoal,orbitHeading,headingKeys,nearestHitPoint,nearestHitPointExact,nearestBoxPoint,currentViewPacket,immediateLook,confirmedRear}
