'use strict'

// Placement, blast scoring and item use share the native world's current state.
function createFatherBrain(){
  function createState(){return {}}
  function decide(s,frame,probe,tick){
    const a=frame.self,b=frame.seen,o=frame.observation,arena=frame.crystalPractice
    const distance=Math.hypot(a.x-b.x,a.z-b.z)
    const attack=arena.inArena&&!arena.anchorReady&&o.visible&&o.reach<=3&&(a.attackChargeAtHit??a.charge)>.9
    const command={kind:'legacy86-ground',phase:'CRYSTAL',slot:0,forward:distance<=2?0:1,side:0,sprint:true,jump:false,
      shield:false,attack,doubleAttack:false,keepTargetLook:true,crystal:{}}
    return {mode:'CRYSTAL',phase:'CRYSTAL',selectedBranch:'father:blast-control',command}
  }
  return {createState,reset(){},decide,receipt(){},applied(){},rangedApplied(){}}
}

module.exports={createFatherBrain}
