package local.wavedog.probe;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.LockSupport;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Function;
import com.sun.jna.Pointer;
import com.sun.jna.Memory;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.command.*;
import org.bukkit.plugin.java.JavaPlugin;
import net.minecraft.server.MinecraftServer;

/** Main-thread sensing only; urgent decisions still use the one native policy. */
public final class FastProbe extends JavaPlugin implements CommandExecutor {
    static final long PERIOD=2_000_000L;
    final AtomicBoolean queued=new AtomicBoolean();final AtomicLong coalesced=new AtomicLong(),clockMissed=new AtomicLong();
    final long[] gaps=new long[4096];final Map<String,Long> signatures=new HashMap<>();
    volatile boolean running;Thread clock;Object controller;Field actors,failed,nameField,opponentField,activeField,loadingField,framesField;Method decide;
    long began,last,samples,pairReads,changed,decisions,maxGap,maxQueue,maxWork;int gapIndex;String error="";
    @Override public void onEnable(){
        try{
            controller=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
            if(controller==null)throw new IllegalStateException("Native controller missing");
            actors=controller.getClass().getDeclaredField("actors");actors.setAccessible(true);
            failed=controller.getClass().getDeclaredField("failed");failed.setAccessible(true);
            var actor=actors.get(controller);Object first=((Map<?,?>)actor).values().iterator().next();
            decide=controller.getClass().getDeclaredMethod("decide",first.getClass(),int.class);decide.setAccessible(true);
            nameField=field(first,"name");opponentField=field(first,"opponent");activeField=field(first,"active");
            loadingField=field(first,"loading");framesField=field(first,"frames");
            Objects.requireNonNull(getCommand("wdprobe")).setExecutor(this);start();
        }catch(Throwable problem){throw new IllegalStateException("Cannot start native probe",problem);}
    }
    void start(){
        if(running)return;error="";running=true;began=System.nanoTime();var server=MinecraftServer.getServer();
        clock=new Thread(()->{
            Function endPeriod=null,setTimer=null,waitTimer=null,closeTimer=null;
            Pointer timer=null;
            try{
                // parkNanos alone may inherit Windows' ~15.6 ms timer granularity.
                // Request a 1 ms process timer only for this clock's lifetime.
                if(System.getProperty("os.name","").startsWith("Windows")){
                    try{
                        var kernel=NativeLibrary.getInstance("kernel32");
                        timer=(Pointer)kernel.getFunction("CreateWaitableTimerExW").invoke(Pointer.class,
                            new Object[]{Pointer.NULL,Pointer.NULL,2,0x001F0003});
                        if(timer==null)throw new IllegalStateException("No high-resolution waitable timer");
                        closeTimer=kernel.getFunction("CloseHandle");
                        setTimer=kernel.getFunction("SetWaitableTimer");waitTimer=kernel.getFunction("WaitForSingleObject");
                        System.setProperty("wavedog.probe.timerResolution","high-resolution-waitable-timer");
                    }catch(Throwable unsupported){
                        if(timer!=null&&closeTimer!=null)closeTimer.invokeInt(new Object[]{timer});timer=null;
                        var winmm=NativeLibrary.getInstance("winmm");
                        int result=winmm.getFunction("timeBeginPeriod").invokeInt(new Object[]{1});
                        if(result!=0)throw new IllegalStateException("timeBeginPeriod failed: "+result);
                        endPeriod=winmm.getFunction("timeEndPeriod");
                        System.setProperty("wavedog.probe.timerResolution","1ms-requested-fallback");
                    }
                }
            }catch(Throwable timerError){
                System.setProperty("wavedog.probe.timerResolution","unavailable");
                getLogger().warning("High-resolution timer unavailable: "+timerError);
            }
            try(var dueTime=new Memory(8)){
            long next=System.nanoTime();
            while(running&&Thread.currentThread()==clock){
                long now=System.nanoTime(),remaining=next-now;
                if(remaining>900_000){
                    if(timer==null)LockSupport.parkNanos(remaining-800_000);
                    else{
                        dueTime.setLong(0,-Math.max(1,(remaining-800_000)/100));
                        if(setTimer.invokeInt(new Object[]{timer,dueTime,0,Pointer.NULL,Pointer.NULL,0})==0)
                            throw new IllegalStateException("SetWaitableTimer failed");
                        int waited=waitTimer.invokeInt(new Object[]{timer,10});
                        // Timeout is a missed deadline, not a corrupt timer.
                        // The loop records elapsed skipped periods on resuming.
                        if(waited!=0&&waited!=258)throw new IllegalStateException("WaitForSingleObject failed: "+waited);
                    }
                    continue;
                }
                if(remaining>0){Thread.onSpinWait();continue;}
                if(now-next>=PERIOD){long skipped=(now-next)/PERIOD;clockMissed.addAndGet(skipped);next+=skipped*PERIOD;}
                next+=PERIOD;
                if(queued.compareAndSet(false,true)){
                    long requested=now;
                    // execute() wakes the server event loop; Bukkit/world reads
                    // happen exclusively inside this main-thread callback.
                    server.execute(()->{try{if(requested>=began)sample(requested);}finally{queued.set(false);}});
                }else coalesced.incrementAndGet();
            }
            }catch(Throwable clockError){
                if(running&&Thread.currentThread()==clock){
                    error=clockError.toString();running=false;getLogger().severe("Native probe clock stopped: "+error);
                }
            }finally{
                if(timer!=null&&closeTimer!=null)closeTimer.invokeInt(new Object[]{timer});
                if(endPeriod!=null)endPeriod.invokeInt(new Object[]{1});
            }
        },"WaveDog-500Hz-probe-clock");clock.setDaemon(true);clock.setPriority(Thread.MAX_PRIORITY-1);clock.start();
    }
    static Field field(Object instance,String name)throws Exception{var f=instance.getClass().getDeclaredField(name);f.setAccessible(true);return f;}
    static long mix(long hash,double v){return hash*31+Double.doubleToLongBits(v);}
    @SuppressWarnings("unchecked") void sample(long requested){
        if(!running)return;
        long now=System.nanoTime();
        try{
            if(!Bukkit.isPrimaryThread())throw new IllegalStateException("World read off main thread");
            if(failed.getBoolean(controller))return;
            if(last!=0){long gap=now-last;gaps[gapIndex++%gaps.length]=gap;maxGap=Math.max(maxGap,gap);}
            last=now;samples++;maxQueue=Math.max(maxQueue,now-requested);
            for(Object a:((Map<?,?>)actors.get(controller)).values()){
                if(!activeField.getBoolean(a)||loadingField.getBoolean(a))continue;
                String name=(String)nameField.get(a),opponent=(String)opponentField.get(a);
                Player own=Bukkit.getPlayerExact(name),target=opponent==null?null:Bukkit.getPlayerExact(opponent);
                if(own==null||target==null||own.getWorld()!=target.getWorld()||own.isDead()||target.isDead())continue;
                var eye=own.getEyeLocation();var box=target.getBoundingBox();
                double dx=Math.max(0,Math.max(box.getMinX()-eye.getX(),eye.getX()-box.getMaxX()));
                double dy=Math.max(0,Math.max(box.getMinY()-eye.getY(),eye.getY()-box.getMaxY()));
                double dz=Math.max(0,Math.max(box.getMinZ()-eye.getZ(),eye.getZ()-box.getMaxZ()));
                double reach=Math.sqrt(dx*dx+dy*dy+dz*dz),charge=own.getCooledAttackStrength(.5f);
                long signature=1;signature=mix(signature,eye.getX());signature=mix(signature,eye.getY());signature=mix(signature,eye.getZ());
                signature=mix(signature,box.getMinX());signature=mix(signature,box.getMinY());signature=mix(signature,box.getMinZ());signature=mix(signature,charge);
                signature=mix(signature,target.getNoDamageTicks());
                if(target.hasActiveItem())signature=mix(signature,target.getYaw());
                boolean bow=target.hasActiveItem()&&target.getActiveItem().getType()==Material.BOW,projectile=false;
                // Ranged threats exist beyond melee reach, including slow
                // deflected arrows. Main-thread-only scan; unchanged positions
                // still share the one decision/signature and dispatch gates.
                for(var entity:own.getNearbyEntities(12,6,12))if(entity instanceof AbstractArrow arrow&&!arrow.isInBlock()
                    &&!(arrow.getShooter() instanceof Player shooter&&shooter.getUniqueId().equals(own.getUniqueId()))){
                    projectile=true;var at=arrow.getLocation();var velocity=arrow.getVelocity();
                    signature=mix(signature,arrow.getEntityId());signature=mix(signature,at.getX());signature=mix(signature,at.getY());signature=mix(signature,at.getZ());
                    signature=mix(signature,velocity.getX());signature=mix(signature,velocity.getY());signature=mix(signature,velocity.getZ());
                }
                signature=mix(signature,target.hasActiveItem()?target.getHandRaisedTime()+1:0);pairReads++;
                Long previous=signatures.put(name,signature);if(previous!=null&&previous==signature)continue;changed++;
                if(reach<.001||reach>4.5&&!bow&&!projectile)continue;
                var frames=(List<Map<String,Object>>)framesField.get(a);
                // Recharge and the approach just outside reach still change
                // recovery routes. They are not permission to stop sensing.
                // The one policy continues to decide whether a hit is legal.
                decide.invoke(controller,a,Bukkit.getCurrentTick());decisions++;
                if(!frames.isEmpty()){
                    var row=frames.getLast();row.put("decisionTrigger","500hz-live-probe");
                    row.put("fastProbe",Map.of("sampleNanos",now,"queueNanos",now-requested,"liveReach",reach,"targetReachBand",List.of(2.95,3.0)));
                }
            }
        }catch(Throwable problem){error=problem.toString();running=false;getLogger().severe("Native probe stopped: "+error);}
        finally{maxWork=Math.max(maxWork,System.nanoTime()-now);}
    }
    @Override public void onDisable(){running=false;if(clock!=null)clock.interrupt();}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.isOp())return true;
        if(args.length>0&&args[0].equals("stop")){onDisable();sender.sendMessage("Native sensing stopped; main native controller unchanged.");return true;}
        if(args.length>0&&args[0].equals("start")){start();sender.sendMessage("Native sensing started.");return true;}
        if(args.length>0&&args[0].equals("reset")){
            samples=pairReads=changed=decisions=maxGap=maxQueue=maxWork=last=gapIndex=0;Arrays.fill(gaps,0);coalesced.set(0);clockMissed.set(0);began=System.nanoTime();
        }
        double seconds=(System.nanoTime()-began)/1e9;long[] sorted=Arrays.stream(gaps).filter(x->x>0).sorted().toArray();
        double p95=sorted.length==0?0:sorted[(int)((sorted.length-1)*.95)]/1e6;
        sender.sendMessage(String.format(Locale.ROOT,"{\"running\":%s,\"targetHz\":500,\"samples\":%d,\"seconds\":%.3f,\"actualHz\":%.3f,\"pairReads\":%d,\"changedGeometry\":%d,\"urgentDecisions\":%d,\"p95GapMs\":%.4f,\"maxGapMs\":%.4f,\"maxQueueMs\":%.4f,\"maxWorkMs\":%.4f,\"clockMissed\":%d,\"coalescedRequests\":%d,\"error\":\"%s\",\"timerResolution\":\"%s\",\"worldReadsOnMainThread\":true,\"syntheticSamples\":false}",
            running,samples,seconds,samples/Math.max(.001,seconds),pairReads,changed,decisions,p95,maxGap/1e6,maxQueue/1e6,maxWork/1e6,clockMissed.get(),coalesced.get(),error.replace("\\","/").replace("\"","'"),System.getProperty("wavedog.probe.timerResolution","platform-default")));
        return true;
    }
}
