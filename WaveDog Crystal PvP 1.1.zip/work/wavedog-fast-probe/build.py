from pathlib import Path
import subprocess,os,zipfile,json,hashlib
BASE=Path(__file__).resolve().parent;SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server');classes=BASE/'classes';classes.mkdir(exist_ok=True)
api=next((SERVER/'libraries/io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT').glob('*.jar'))
cp=os.pathsep.join(map(str,[SERVER/'versions/1.21.11/paper-1.21.11.jar',api,*sorted((SERVER/'libraries').rglob('*.jar'),reverse=True)]))
args=['-proc:none','--release','21','-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,(BASE/'src').rglob('*.java'))]
p=BASE/'compile.args';p.write_text('\n'.join('"'+s.replace('\\','\\\\').replace('"','\\"')+'"' for s in args))
r=subprocess.run([str(SERVER/'runtime/java21/bin/javac.exe'),'@'+str(p)],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
(BASE/'compile.log').write_text(r.stdout+r.stderr,encoding='utf8')
if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
jar=BASE/'WaveDogFastProbe.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\r\npaperweight-mappings-namespace: mojang\r\n\r\n');z.write(BASE/'plugin.yml','plugin.yml')
 for file in classes.rglob('*.class'):z.write(file,file.relative_to(classes).as_posix())
print(json.dumps({'jar':str(jar),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'bytes':jar.stat().st_size}))
