from pathlib import Path
import hashlib, json, os, subprocess, zipfile

BASE = Path(__file__).resolve().parent
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classes = BASE / 'classes'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(str(p) for p in sorted((SERVER / 'libraries').rglob('*.jar')))
subprocess.run([str(SERVER / 'runtime/java21/bin/javac.exe'), '-proc:none', '-encoding', 'UTF-8',
    '--release', '21', '-cp', classpath, '-d', str(classes),
    str(BASE / 'src/local/wavedog/command/WaveDogCommandPlugin.java')], check=True)
target = BASE / 'WaveDogCommand.jar'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as jar:
    jar.write(BASE / 'plugin.yml', 'plugin.yml')
    for file in sorted(classes.rglob('*.class')):
        jar.write(file, file.relative_to(classes).as_posix())
print(json.dumps({'jar': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
