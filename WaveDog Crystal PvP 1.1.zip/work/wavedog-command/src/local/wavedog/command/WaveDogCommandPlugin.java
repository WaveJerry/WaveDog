package local.wavedog.command;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Stable public command; delegates only to the actual WaveDog combat core. */
public final class WaveDogCommandPlugin extends JavaPlugin {
    @Override public void onEnable() {
        Objects.requireNonNull(getCommand("wavedog")).setExecutor(this);
        Objects.requireNonNull(getCommand("wavedog")).setTabCompleter(this);
        Objects.requireNonNull(getCommand("wavedog_test")).setExecutor(this);
        Objects.requireNonNull(getCommand("wavedog_test")).setTabCompleter(this);
    }
    private boolean eligible(Player player) {
        String name = player.getName().toLowerCase(Locale.ROOT);
        return !name.equals("wavedog") && !name.equals("wavedog_test") && !name.equals("punengbho") && !name.equals("wavedog2")
            && !name.startsWith("nbot") && !name.startsWith("wplayer");
    }
    private PluginCommand coreCommand() {
        Plugin protocol = Bukkit.getPluginManager().getPlugin("PunengbhoProtocolCore");
        PluginCommand network = Bukkit.getPluginCommand("wavedog_punengbho");
        return protocol != null && protocol.isEnabled() && network != null && network.getPlugin() == protocol
            ? network : null;
    }
    private void help(CommandSender sender) {
        sender.sendMessage("§b/wavedog duel <在线玩家名> §f召出 WaveDog 与该玩家对战");
        sender.sendMessage("§b/wavedog stop §f停止；§b/wavedog status §f查看核心状态");
    }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("wavedog.control")) {
            sender.sendMessage("§c需要 wavedog.control 权限或 OP。"); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) { help(sender); return true; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (!(sub.equals("duel") && args.length == 2
                || (sub.equals("stop") || sub.equals("status")) && args.length == 1)) {
            help(sender); return true;
        }
        PluginCommand core = command.getName().equalsIgnoreCase("wavedog_test")
            ? Bukkit.getPluginCommand("wdcore") : coreCommand();
        if (core == null) {
            sender.sendMessage("§cWaveDog 对战核心未加载，尚未开始对战。");
            sender.sendMessage("§e当前 /wavedog 指令已注册；服务器升级后的 PvPArenaAI / 协议玩家接入仍待恢复。");
            return true;
        }
        if (sub.equals("duel")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null || !eligible(target)) {
                sender.sendMessage("§c请填写在线真人玩家的完整名字。"); return true;
            }
            if (target.isDead() || target.getGameMode() != GameMode.SURVIVAL) {
                sender.sendMessage("§c目标需要存活并处于生存模式。"); return true;
            }
            // Preserve the original core's AuthMe checks, kit, arena, mechanics,
            // hybrid policy and bout lifecycle. No fallback NBot substitutes.
            core.execute(sender, core.getName(), new String[] { "duel", target.getName() });
        } else core.execute(sender, core.getName(), new String[] { sub });
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("wavedog.control")) return List.of();
        if (args.length == 1) return List.of("duel", "stop", "status", "help").stream()
            .filter(value -> value.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 2 && args[0].equalsIgnoreCase("duel")) return Bukkit.getOnlinePlayers().stream()
            .filter(this::eligible).map(Player::getName)
            .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        return List.of();
    }
}
