from pathlib import Path
import subprocess,os,zipfile,json,hashlib
BASE=Path(__file__).resolve().parent;SERVER=Path(os.environ.get('WAVEDOG_SERVER_ROOT','D:/Walt Disney/Minecraft-1.21.1-Server'))
api=next((SERVER/'libraries/io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT').glob('*.jar'))
classes=BASE/'classes';classes.mkdir(exist_ok=True)
cp=os.pathsep.join(map(str,[api,*sorted((SERVER/'libraries').rglob('*.jar'))]))
p=subprocess.run([str(SERVER/'runtime/java21/bin/javac.exe'),'-proc:none','--release','21','-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,(BASE/'src').rglob('*.java'))],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
if p.returncode:print(p.stderr);raise SystemExit(p.returncode)
jar=BASE/'WaveDogNeuralFallback.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 z.write(BASE/'plugin.yml','plugin.yml')
 for f in classes.rglob('*.class'):z.write(f,f.relative_to(classes).as_posix())
print(json.dumps({'jar':str(jar),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest()}))
