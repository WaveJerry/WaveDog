package local.wavedog.neural;
import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/** Immutable observations only; worker IO and inference never block Bukkit. */
public final class NeuralFallback extends JavaPlugin implements CommandExecutor {
    static final Gson JSON=new Gson();
    final ConcurrentHashMap<String,String> pending=new ConcurrentHashMap<>();
    final ConcurrentHashMap<String,Map<String,Object>> latest=new ConcurrentHashMap<>();
    final Map<String,Integer> submitted=new HashMap<>();
    volatile boolean ready,running;volatile String error="";volatile long results;
    Process worker;Thread io;
    @Override public void onEnable(){
        try{
            Path root=Path.of(System.getProperty("wavedog.workspace","D:/CodexWorkspace/ban"));
            String node=System.getProperty("wavedog.node",getConfig().getString("node","E:/node/node.exe"));
            getDataFolder().mkdirs();
            worker=new ProcessBuilder(node,root.resolve("work/pvp-dual-brain/native-sword-fallback.js").toString(),
                root.resolve("work/wavedog-neural-fallback/model/model.json").toString())
                .directory(root.toFile()).redirectError(getDataFolder().toPath().resolve("inference.err.log").toFile()).start();
            running=true;io=new Thread(()->{
                try(var input=new BufferedReader(new InputStreamReader(worker.getInputStream(),StandardCharsets.UTF_8));
                    var output=new BufferedWriter(new OutputStreamWriter(worker.getOutputStream(),StandardCharsets.UTF_8))){
                    var hello=JSON.fromJson(input.readLine(),JsonObject.class);ready=hello.has("ready")&&hello.get("ready").getAsBoolean();
                    if(!ready)throw new IllegalStateException("Frozen model not ready");
                    Files.writeString(getDataFolder().toPath().resolve("model-ready.json"),hello.toString());
                    while(running){
                        var batch=new TreeMap<>(pending);if(batch.isEmpty()){Thread.sleep(2);continue;}
                        for(var entry:batch.entrySet()){
                            if(!pending.remove(entry.getKey(),entry.getValue()))continue;
                            output.write(entry.getValue());output.newLine();output.flush();String line=input.readLine();
                            if(line==null)throw new EOFException("Frozen inference worker stopped");
                            @SuppressWarnings("unchecked") var row=(Map<String,Object>)JSON.fromJson(line,Map.class);
                            if(row.containsKey("error"))throw new IllegalStateException(String.valueOf(row.get("error")));
                            if(row.containsKey("command")){row.remove("probabilities");latest.put(entry.getKey(),row);results++;}
                        }
                    }
                }catch(Throwable e){error=e.toString();ready=false;getLogger().severe(error);}
            },"WaveDog-readonly-model-io");io.setDaemon(true);io.start();
            Objects.requireNonNull(getCommand("wdneural")).setExecutor(this);
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    public boolean isModelReady(){return ready;}
    public Map<String,Object> propose(String fighter,Map<String,Object> frame,int tick){
        if(!Bukkit.isPrimaryThread())throw new IllegalStateException("Observation must be accepted on the main thread");
        var result=new LinkedHashMap<String,Object>();result.put("ready",ready);result.put("error",error);
        if(!ready)return result;
        @SuppressWarnings("unchecked") var o=(Map<String,Object>)frame.get("observation");
        if(((Number)o.get("reach")).doubleValue()<=4.5&&submitted.getOrDefault(fighter,-1)!=tick){
            submitted.put(fighter,tick);var request=new LinkedHashMap<String,Object>(frame);request.put("fighter",fighter);request.put("tick",tick);
            var p=Bukkit.getPlayerExact(fighter);var walls=new ArrayList<Double>();
            for(var d:List.of(new Vector(-1,0,0),new Vector(1,0,0),new Vector(0,0,-1),new Vector(0,0,1))){
                var origin=p.getLocation().add(0,.8,0);var hit=p.getWorld().rayTraceBlocks(origin,d,8,FluidCollisionMode.NEVER,false);
                walls.add(hit==null?8:origin.distance(hit.getHitPosition().toLocation(p.getWorld())));
            }
            request.put("publicTerrain",Map.of("walls",walls,"groundY",frame.get("targetFloorY")));
            @SuppressWarnings("unchecked") var target=(Map<String,Object>)frame.get("seen");
            request.put("publicActionContext",Map.of("tick",tick,"visible",true,"targetVelocity",frame.get("targetVelocity"),
                "targetGrounded",o.get("targetGrounded"),"targetCriticalPossible",Boolean.FALSE));
            request.put("opponent",frame.get("opponent"));pending.put(fighter,JSON.toJson(request));
        }
        var proposal=latest.get(fighter);if(proposal!=null)result.put("proposal",proposal);return result;
    }
    @Override public boolean onCommand(CommandSender s,Command c,String label,String[] args){
        s.sendMessage(JSON.toJson(Map.of("ready",ready,"readOnly",true,"results",results,"queuedActors",pending.size(),"error",error,
            "checkpointSha256","db54f4a3e96639129fb52b7061826e60def65fa37174411da414d8df2de9e698")));return true;
    }
    @Override public void onDisable(){running=false;if(worker!=null)worker.destroy();if(io!=null)io.interrupt();}
}
