"""Compile the independent read-only ArrowSense Paper 1.21.1 plugin."""
from pathlib import Path
import hashlib
import os
import subprocess

base = Path(__file__).resolve().parent
server = Path(r'D:\Walt Disney\Minecraft-1.21.1-Server')
java = server / 'runtime/java21/bin'
api = server / 'libraries/com/destroystokyo/paper/paper-mojangapi/1.21.1-R0.1-SNAPSHOT/paper-mojangapi-1.21.1-R0.1-SNAPSHOT.jar'
adventure = server / 'libraries/net/kyori/adventure-api/4.17.0/adventure-api-4.17.0.jar'
key = next((server / 'libraries/net/kyori/adventure-key').rglob('*.jar'))
bungee = next((server / 'libraries/net/md-5/bungeecord-chat').rglob('*.jar'))
classes = base / 'classes'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, (api, adventure, key, bungee)))
subprocess.run([java / 'javac.exe', '-encoding', 'UTF-8', '--release', '21',
                '-cp', classpath, '-d', classes, *sorted((base / 'src').rglob('*.java'))], check=True)
jar = base / 'ArrowSense.jar'
subprocess.run([java / 'jar.exe', 'cf', jar, '-C', classes, '.', '-C', base, 'plugin.yml'], check=True)
digest = hashlib.sha256(jar.read_bytes()).hexdigest()
(base / 'ArrowSense.jar.sha256').write_text(digest + '\n', encoding='ascii')
print('BUILT', jar, jar.stat().st_size, digest)
