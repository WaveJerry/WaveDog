package local.pvpbot.sense;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** All entity sampling is confined to the visibility gate in observe(). */
final class DefaultArrowSense implements ArrowSenseService {
    private static final int MEMORY_TICKS=6, MAX_ARROWS=12, PREDICTION_TICKS=24;
    private static final double RANGE_XZ=48, RANGE_Y=32;
    private static final Snapshot EMPTY=new Snapshot(List.of(),0,0);
    private final Map<UUID, ObserverMemory> memories=new HashMap<>();

    private record Motion(double x,double y,double z,double vx,double vy,double vz) {
        Motion advance(boolean gravity,double drag) {
            return new Motion(x+vx,y+vy,z+vz,vx*drag,vy*drag-(gravity?0.05:0),vz*drag);
        }
    }
    private record Sample(UUID uuid,int id,Motion motion,boolean gravity,double drag,int piercing,long seenAt) {}
    private record Candidate(Sample sample,Motion estimate,int age,double priority) {}
    private static final class ObserverMemory {
        final UUID world;
        final Map<UUID,Sample> samples=new HashMap<>();
        long snapshotAt=Long.MIN_VALUE;
        Snapshot snapshot=EMPTY;
        ObserverMemory(UUID world) { this.world=world; }
    }

    @Override public Snapshot observe(Player observer) {
        if (!Bukkit.isPrimaryThread()) throw new IllegalStateException("ArrowSense.observe must run on the server thread");
        if (observer==null || !observer.isOnline() || observer.isDead()) return EMPTY;
        World world=observer.getWorld();
        ObserverMemory memory=memories.get(observer.getUniqueId());
        if (memory==null || !memory.world.equals(world.getUID())) {
            memory=new ObserverMemory(world.getUID());memories.put(observer.getUniqueId(),memory);
        }
        long now=Bukkit.getCurrentTick();
        if (memory.snapshotAt==now) return memory.snapshot;
        Location eye=observer.getEyeLocation();
        Vector feet=observer.getLocation().toVector(), ownVelocity=observer.getVelocity();
        Map<UUID,Sample> known=new HashMap<>(memory.samples);

        for (Entity entity:world.getNearbyEntities(eye,RANGE_XZ,RANGE_Y,RANGE_XZ,
                candidate -> candidate instanceof AbstractArrow)) {
            // No velocity, gravity, pierce level, in-ground flag or saved
            // position is sampled until the observer can see this candidate.
            if (!observer.canSee(entity) || !observer.hasLineOfSight(entity)) continue;
            Location position=entity.getLocation();
            // Requested panoramic third-person sensing: all directions, still
            // gated by actual visibility and walls before velocity is sampled.
            AbstractArrow arrow=(AbstractArrow)entity;
            UUID uuid=arrow.getUniqueId();
            Vector velocity=arrow.getVelocity();
            if (arrow.isInBlock() || velocity.lengthSquared()<0.0001) { known.remove(uuid);continue; }
            Vector relative=position.toVector().subtract(feet);
            boolean freshSelfAway=arrow.getShooter() instanceof Player shooter
                    && shooter.getUniqueId().equals(observer.getUniqueId())
                    && relative.lengthSquared()<16 && relative.dot(velocity)>0;
            if (freshSelfAway) { known.remove(uuid);continue; }
            Motion motion=new Motion(position.getX(),position.getY(),position.getZ(),
                    velocity.getX(),velocity.getY(),velocity.getZ());
            known.put(uuid,new Sample(uuid,arrow.getEntityId(),motion,arrow.hasGravity(),
                    arrow.isInWater()?0.6:0.99,arrow.getPierceLevel(),now));
        }

        List<Candidate> candidates=new ArrayList<>();
        for (Sample sample:known.values()) {
            long elapsed=now-sample.seenAt;
            if (elapsed<0 || elapsed>MEMORY_TICKS) continue;
            int age=(int)elapsed;
            Motion estimate=sample.motion;
            // Unseen entities are never looked up here: only the last visible
            // state and its recorded physical parameters are extrapolated.
            for (int i=0;i<age;i++) estimate=estimate.advance(sample.gravity,sample.drag);
            if (Math.abs(estimate.x-eye.getX())>RANGE_XZ || Math.abs(estimate.y-eye.getY())>RANGE_Y
                    || Math.abs(estimate.z-eye.getZ())>RANGE_XZ) continue;
            double closest=closestApproach(estimate,sample.gravity,sample.drag,feet,ownVelocity);
            if (age>0 && closest>3.0) continue;
            double distance=Math.sqrt(square(estimate.x-feet.getX())+square(estimate.y-feet.getY())
                    +square(estimate.z-feet.getZ()));
            double priority=(closest<=3.0?0:100)+closest+distance*0.015+age*0.02;
            candidates.add(new Candidate(sample,estimate,age,priority));
        }
        candidates.sort(Comparator.comparingDouble(Candidate::priority));
        List<ObservedArrow> arrows=new ArrayList<>();
        Map<UUID,Sample> retained=new HashMap<>();
        int visible=0,predicted=0;
        for (Candidate candidate:candidates) {
            if (arrows.size()>=MAX_ARROWS) break;
            Sample sample=candidate.sample;Motion estimate=candidate.estimate;
            List<Point> path=trajectory(world,eye,estimate,sample.gravity,sample.drag);
            if (path.size()<2) continue;
            arrows.add(new ObservedArrow(sample.id,estimate.x,estimate.y,estimate.z,
                    estimate.vx,estimate.vy,estimate.vz,sample.gravity,sample.drag,sample.piercing,
                    candidate.age,Math.max(0.25,1-candidate.age*0.1),path));
            retained.put(sample.uuid,sample);
            if (candidate.age==0) visible++;else predicted++;
        }
        memory.samples.clear();memory.samples.putAll(retained);
        memory.snapshotAt=now;
        memory.snapshot=new Snapshot(arrows,visible,predicted);
        return memory.snapshot;
    }

    private double closestApproach(Motion motion,boolean gravity,double drag,Vector feet,Vector ownVelocity) {
        Motion current=motion;
        double best=Double.POSITIVE_INFINITY;
        for (int t=0;t<=PREDICTION_TICKS;t++) {
            double dx=current.x-feet.getX()-ownVelocity.getX()*t;
            double dy=current.y-(feet.getY()+0.9);
            double dz=current.z-feet.getZ()-ownVelocity.getZ()*t;
            best=Math.min(best,Math.sqrt(dx*dx+dy*dy+dz*dz));
            current=current.advance(gravity,drag);
        }
        return best;
    }

    private List<Point> trajectory(World world,Location eye,Motion start,boolean gravity,double initialDrag) {
        List<Point> path=new ArrayList<>(PREDICTION_TICKS+1);
        path.add(new Point(start.x,start.y,start.z));
        Motion current=start;
        for (int tick=0;tick<PREDICTION_TICKS;tick++) {
            Motion next=current.advance(gravity,initialDrag);
            if (!loadedLine(world,current.x,current.z,next.x,next.z)) break;
            Vector direction=new Vector(next.x-current.x,next.y-current.y,next.z-current.z);
            double distance=direction.length();
            if (distance<1.0e-8) break;
            RayTraceResult hit=world.rayTraceBlocks(new Location(world,current.x,current.y,current.z),
                    direction,distance,FluidCollisionMode.NEVER,true);
            if (hit!=null) {
                Vector point=hit.getHitPosition();
                // A hidden collision face must not turn into a precise new
                // observation. Stop at the preceding predicted point instead.
                if (visibleStaticPoint(world,eye,point)) path.add(new Point(point.getX(),point.getY(),point.getZ()));
                break;
            }
            path.add(new Point(next.x,next.y,next.z));
            current=next;
        }
        return path;
    }

    private boolean visibleStaticPoint(World world,Location eye,Vector point) {
        if (!loadedLine(world,eye.getX(),eye.getZ(),point.getX(),point.getZ())) return false;
        Vector direction=point.clone().subtract(eye.toVector());
        double distance=direction.length();
        if (distance<1.0e-7) return true;
        RayTraceResult sight=world.rayTraceBlocks(eye,direction,distance+0.01,FluidCollisionMode.NEVER,true);
        return sight==null || sight.getHitPosition().distanceSquared(point)<0.0225;
    }

    private boolean loadedLine(World world,double ax,double az,double bx,double bz) {
        int x=((int)Math.floor(ax))>>4,z=((int)Math.floor(az))>>4;
        int endX=((int)Math.floor(bx))>>4,endZ=((int)Math.floor(bz))>>4;
        double dx=bx-ax,dz=bz-az;
        int stepX=Double.compare(dx,0),stepZ=Double.compare(dz,0);
        double deltaX=stepX==0?Double.POSITIVE_INFINITY:16/Math.abs(dx);
        double deltaZ=stepZ==0?Double.POSITIVE_INFINITY:16/Math.abs(dz);
        double nextX=stepX==0?Double.POSITIVE_INFINITY:((stepX>0?(x+1)*16:x*16)-ax)/dx;
        double nextZ=stepZ==0?Double.POSITIVE_INFINITY:((stepZ>0?(z+1)*16:z*16)-az)/dz;
        for (int remaining=2+Math.abs(endX-x)+Math.abs(endZ-z);remaining>0;remaining--) {
            if (!world.isChunkLoaded(x,z)) return false;
            if (x==endX && z==endZ) return true;
            if (Math.abs(nextX-nextZ)<1.0e-12) {
                // At a chunk corner, preflight both touched neighbours too.
                if (!world.isChunkLoaded(x+stepX,z) || !world.isChunkLoaded(x,z+stepZ)) return false;
                x+=stepX;z+=stepZ;nextX+=deltaX;nextZ+=deltaZ;
            } else if (nextX<nextZ) { x+=stepX;nextX+=deltaX; }
            else { z+=stepZ;nextZ+=deltaZ; }
        }
        return false;
    }

    private static double square(double value) { return value*value; }

    void forgetArrow(UUID uuid) {
        for (ObserverMemory memory:memories.values()) {
            memory.samples.remove(uuid);
            // Invalidate a same-tick cached snapshot after a known collision.
            memory.snapshotAt=Long.MIN_VALUE;
        }
    }
    void forgetObserver(UUID uuid) { memories.remove(uuid); }
    void clear() { memories.clear(); }
}
