package local.pvpbot.sense;

import java.util.List;
import org.bukkit.entity.Player;

/** Read-only, observer-relative arrow perception. Call on the server thread. */
public interface ArrowSenseService {
    Snapshot observe(Player observer);

    record Point(double x, double y, double z) {}

    /**
     * seenAge=0 is currently visible; 1..6 is extrapolation of the last visible
     * sample, never a new read of an unseen entity. path[0] is the current
     * estimate, followed by up to 24 predicted tick endpoints. A shorter path
     * ends at static geometry or the boundary of loaded/known geometry.
     */
    record ObservedArrow(int id, double x, double y, double z,
                         double vx, double vy, double vz,
                         boolean gravity, double drag, int piercing,
                         int seenAge, double confidence, List<Point> path) {
        public ObservedArrow { path = List.copyOf(path); }
    }

    /** Counts refer to returned samples; visibleCount+predictedCount=arrows.size(). */
    record Snapshot(List<ObservedArrow> arrows, int visibleCount, int predictedCount) {
        public Snapshot { arrows = List.copyOf(arrows); }
    }
}
