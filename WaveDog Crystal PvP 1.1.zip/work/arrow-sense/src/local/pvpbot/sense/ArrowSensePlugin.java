package local.pvpbot.sense;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public final class ArrowSensePlugin extends JavaPlugin implements Listener {
    private DefaultArrowSense service;

    @Override public void onEnable() {
        service = new DefaultArrowSense();
        getServer().getServicesManager().register(ArrowSenseService.class, service, this, ServicePriority.Normal);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Read-only visible-arrow sensing registered: 24-tick prediction, 6-tick memory, 12 samples.");
    }

    @Override public void onDisable() {
        getServer().getServicesManager().unregisterAll(this);
        if (service != null) service.clear();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof AbstractArrow arrow)) return;
        // Piercing arrows can continue through entities; a block or a
        // non-piercing entity hit terminates this known tracked projectile.
        if (event.getHitBlock() != null || event.getHitEntity() != null && arrow.getPierceLevel() == 0)
            service.forgetArrow(arrow.getUniqueId());
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { service.forgetObserver(event.getPlayer().getUniqueId()); }
    @EventHandler public void onWorldChange(PlayerChangedWorldEvent event) { service.forgetObserver(event.getPlayer().getUniqueId()); }
}
