from pathlib import Path
import os
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
JAVA=SERVER/'runtime/java21/bin'
classes=BASE/'classes';classes.mkdir(exist_ok=True)
libs=[SERVER/'versions/1.21.1/paper-1.21.1.jar',*sorted((SERVER/'libraries').rglob('*.jar'))]
args=['-proc:none','-encoding','UTF-8','--release','21','-cp',os.pathsep.join(map(str,libs)),
      '-d',str(classes),*map(str,(BASE/'src').rglob('*.java'))]
argfile=BASE/'compile.args'
argfile.write_text('\n'.join('"'+s.replace('\\','\\\\').replace('"','\\"')+'"' for s in args),encoding='utf-8')
subprocess.run([str(JAVA/'javac.exe'),'@'+str(argfile)],check=True)
with zipfile.ZipFile(BASE/'PvPFrameRecorder.jar','w',zipfile.ZIP_DEFLATED) as archive:
    for file in classes.rglob('*.class'):archive.write(file,file.relative_to(classes))
    archive.writestr('plugin.yml','name: PvPFrameRecorder\nversion: 1.0.0\nmain: local.wavedog.recorder.PvPFrameRecorder\napi-version: "1.21"\ncommands:\n  pvprecord:\n    description: Public PvP trajectory recorder\n    permission: pvprecord.admin\npermissions:\n  pvprecord.admin:\n    default: op\n')
agent=ROOT/'work/hot-update-java';agentclasses=agent/'classes';agentclasses.mkdir(exist_ok=True)
subprocess.run([str(JAVA/'javac.exe'),'--release','21','--add-modules','jdk.attach',
    '-d',str(agentclasses),str(agent/'HotUpdateAgent.java'),str(agent/'AttachHotUpdate.java')],check=True)
with zipfile.ZipFile(agent/'HotUpdateAgent.jar','w',zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nAgent-Class: HotUpdateAgent\nCan-Redefine-Classes: true\n\n')
    for file in agentclasses.glob('HotUpdateAgent*.class'):archive.write(file,file.name)
print('BUILT PvPFrameRecorder.jar and explicit single-class hot-update agent')
