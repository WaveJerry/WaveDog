package local.wavedog.recorder;

import com.google.gson.Gson;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPOutputStream;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/** Read-only, public-observation PvP trajectories. Never issues player inputs. */
public final class PvPFrameRecorder extends JavaPlugin implements Listener {
    private final Gson json = new Gson();
    private final Map<UUID, Track> tracks = new HashMap<>();
    private final Map<UUID, ArrayDeque<Map<String,Object>>> preRoll = new HashMap<>();
    private final Map<UUID, Long> swings = new HashMap<>();
    private final Set<UUID> watched = new HashSet<>();
    private final BlockingQueue<Runnable> writes = new ArrayBlockingQueue<>(8192);
    private Thread writer;
    private long tick, dropped, frames;
    private volatile boolean writing = true;
    private final String runId = Long.toString(System.currentTimeMillis());
    private static final class Track {
        final String id; final UUID player, opponent;
        final String opponentName;
        long until; int rows;
        BufferedWriter out;
        Track(String id, Player player, Player opponent, long until) {
            this.id=id;this.player=player.getUniqueId();this.opponent=opponent.getUniqueId();
            this.opponentName=opponent.getName();this.until=until;
        }
    }
    @Override public void onEnable() {
        getDataFolder().mkdirs(); new File(getDataFolder(), "bouts").mkdirs();
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("pvprecord")).setExecutor(this);
        writer = new Thread(() -> {
            while(writing || !writes.isEmpty()) {
                try { var task=writes.poll(250,TimeUnit.MILLISECONDS);if(task!=null)task.run(); }
                catch(InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
                catch(Throwable error) { getLogger().severe("Recorder write failed: "+error); }
            }
        },"PvPFrameRecorder-disk");writer.setDaemon(true);writer.start();
        getServer().getScheduler().runTaskTimer(this,this::sample,1,1);
        getLogger().info("Recording public 20-tick PvP observations; no player control. /pvprecord status");
    }
    @Override public void onDisable() {
        for(var track:List.copyOf(tracks.values()))end(track,"plugin-disable");
        writing=false;
        try { if(writer!=null)writer.join(4000); } catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    private void enqueue(Runnable task) {
        if(!writes.offer(task)) { dropped++;getLogger().severe("Recorder queue full; incomplete trajectory, dropped="+dropped); }
    }
    private void row(Track track,Map<String,Object> row) {
        String line=json.toJson(row);
        enqueue(()-> {try {
            if(track.out==null) {
                Path file=getDataFolder().toPath().resolve("bouts/"+track.id+".jsonl.gz");
                track.out=new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(file)),StandardCharsets.UTF_8));
            }
            track.out.write(line);track.out.newLine();track.rows++;
            if(track.rows%100==0)track.out.flush();
        } catch(IOException e){throw new UncheckedIOException(e);} });
    }
    private void begin(Player player,Player opponent) {
        Track old=tracks.get(player.getUniqueId());
        if(old!=null&&old.opponent.equals(opponent.getUniqueId())) {old.until=tick+240;return;}
        if(old!=null)end(old,"opponent-changed");
        Track track=new Track(runId+"-"+tick+"-"+player.getUniqueId(),player,opponent,tick+240);
        tracks.put(player.getUniqueId(),track);
        row(track,Map.of("type","start","schema","wavedog-public-pvp-v1","id",track.id,
            "fighter",player.getName(),"opponent",opponent.getName(),"tick",tick,"tickRate",20,
            "boundary","self state; visible public entities; ray-visible block surfaces; no opponent health/charge/inventory/inputs"));
        for(var frame:preRoll.getOrDefault(player.getUniqueId(),new ArrayDeque<>()))row(track,frame);
    }
    private void end(Track track,String reason) {
        tracks.remove(track.player,track);
        row(track,Map.of("type","end","tick",tick,"reason",reason,"droppedGlobal",dropped));
        enqueue(()->{try{if(track.out!=null)track.out.close();}catch(IOException e){throw new UncheckedIOException(e);}});
    }
    private Map<String,Object> item(ItemStack item) {
        if(item==null)return Map.of("type","AIR");
        var row=new LinkedHashMap<String,Object>();row.put("type",item.getType().name());row.put("count",item.getAmount());
        if(item.getItemMeta() instanceof CrossbowMeta meta)row.put("loaded",meta.hasChargedProjectiles());
        return row;
    }
    private Map<String,Object> self(Player player) {
        var p=player.getLocation();var v=player.getVelocity();var row=new LinkedHashMap<String,Object>();
        row.put("x",p.getX());row.put("y",p.getY());row.put("z",p.getZ());row.put("eyeY",player.getEyeLocation().getY());
        row.put("yaw",p.getYaw());row.put("pitch",p.getPitch());row.put("vx",v.getX());row.put("vy",v.getY());row.put("vz",v.getZ());
        row.put("ground",player.isOnGround());row.put("sprint",player.isSprinting());row.put("sneak",player.isSneaking());
        row.put("health",player.getHealth());row.put("food",player.getFoodLevel());row.put("charge",player.getCooledAttackStrength(0));
        row.put("shieldAvailable",!player.hasCooldown(Material.SHIELD));row.put("shielding",player.isBlocking());
        row.put("using",player.hasActiveItem());row.put("useTicks",player.getHandRaisedTime());
        row.put("main",item(player.getInventory().getItemInMainHand()));row.put("off",item(player.getInventory().getItemInOffHand()));
        row.put("selectedSlot",player.getInventory().getHeldItemSlot());row.put("swingTick",swings.getOrDefault(player.getUniqueId(),-1L));
        int arrows=0;boolean bow=false,crossbow=false;
        for(var item:player.getInventory().getContents())if(item!=null) {
            if(item.getType()==Material.ARROW)arrows+=item.getAmount();
            if(item.getType()==Material.BOW)bow=true;
            if(item.getType()==Material.CROSSBOW)crossbow=true;
        }
        row.put("arrows",arrows);row.put("hasBow",bow);row.put("hasCrossbow",crossbow);
        return row;
    }
    private List<Map<String,Object>> environment(Player player) {
        var tokens=new ArrayList<Map<String,Object>>();var origin=player.getEyeLocation();
        // Query loaded chunks only; public first surfaces across a legal 360 view.
        for(int height=0;height<3;height++)for(int i=0;i<12;i++) {
            double yaw=2*Math.PI*i/12;var direction=new Vector(Math.cos(yaw),height==0?-.7:height==1?0:.6,Math.sin(yaw)).normalize();
            var hit=player.getWorld().rayTraceBlocks(origin,direction,8,FluidCollisionMode.ALWAYS,true);
            if(hit==null||hit.getHitBlock()==null)continue;
            var block=hit.getHitBlock();var pos=hit.getHitPosition();
            tokens.add(Map.of("type",block.getType().name(),"dx",pos.getX()-origin.getX(),
                "dy",pos.getY()-origin.getY(),"dz",pos.getZ()-origin.getZ(),
                "face",hit.getHitBlockFace()==null?"UNKNOWN":hit.getHitBlockFace().name(),
                "solid",block.getType().isSolid(),"liquid",block.isLiquid()));
        }
        return tokens;
    }
    private Map<String,Object> snapshot(Player player,boolean terrain) {
        var entities=new ArrayList<Map<String,Object>>();var arrows=new ArrayList<Map<String,Object>>();
        for(Entity entity:player.getNearbyEntities(16,8,16)) {
            if(entity instanceof Player other && player.canSee(other)&&player.hasLineOfSight(other)&&entities.size()<12) {
                var p=other.getLocation();var row=new LinkedHashMap<String,Object>();
                row.put("name",other.getName());row.put("x",p.getX());row.put("y",p.getY());row.put("z",p.getZ());
                row.put("yaw",p.getYaw());row.put("pitch",p.getPitch());row.put("shield",other.isBlocking());
                row.put("main",item(other.getInventory().getItemInMainHand()));row.put("off",item(other.getInventory().getItemInOffHand()));
                row.put("using",other.isHandRaised());row.put("swingTick",swings.getOrDefault(other.getUniqueId(),-1L));
                entities.add(row);
            } else if(entity instanceof AbstractArrow arrow&&player.hasLineOfSight(arrow)&&arrows.size()<12) {
                var p=arrow.getLocation();var v=arrow.getVelocity();
                arrows.add(Map.of("id",arrow.getEntityId(),"x",p.getX(),"y",p.getY(),"z",p.getZ(),
                    "vx",v.getX(),"vy",v.getY(),"vz",v.getZ()));
            }
        }
        var result=new LinkedHashMap<String,Object>();result.put("type","frame");result.put("tick",tick);
        result.put("at",System.currentTimeMillis());result.put("world",player.getWorld().getUID().toString());
        result.put("self",self(player));result.put("visiblePlayers",entities);result.put("arrows",arrows);
        if(terrain)result.put("terrain",environment(player));
        // Key presses are not available through Bukkit. Never invent them.
        result.put("actionLabels","observed-events-only; movement keys unknown");frames++;
        return result;
    }
    private boolean eligible(Player player) {return !player.getName().matches("(?i)NBot\\d+")&&player.getGameMode()!=GameMode.SPECTATOR;}
    private void sample() {
        tick++;
        for(Player player:getServer().getOnlinePlayers()) {
            if(!eligible(player)&&!watched.contains(player.getUniqueId()))continue;
            var track=tracks.get(player.getUniqueId());
            var frame=snapshot(player,track!=null&&tick%10==0);
            var ring=preRoll.computeIfAbsent(player.getUniqueId(),id->new ArrayDeque<>());
            ring.addLast(frame);while(ring.size()>40)ring.removeFirst();
            if(track!=null) {
                row(track,frame);
                if(player.isDead()||tick>track.until&&!watched.contains(player.getUniqueId()))end(track,player.isDead()?"death":"exchange-ended");
            }
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=false)
    public void damage(EntityDamageByEntityEvent event) {
        if(!(event.getEntity() instanceof Player victim))return;
        Player attacker=event.getDamager() instanceof Player p?p:event.getDamager() instanceof Projectile shot&&shot.getShooter() instanceof Player p?p:null;
        if(attacker==null||!eligible(attacker)&&!eligible(victim))return;
        if(eligible(attacker))begin(attacker,victim);if(eligible(victim))begin(victim,attacker);
        var row=new LinkedHashMap<String,Object>();row.put("type","damage");row.put("tick",tick);
        row.put("attacker",attacker.getName());row.put("victim",victim.getName());row.put("cause",event.getCause().name());
        row.put("damage",event.getFinalDamage());row.put("cancelled",event.isCancelled());
        for(var track:tracks.values())if(track.player.equals(attacker.getUniqueId())||track.player.equals(victim.getUniqueId()))row(track,row);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void swing(PlayerAnimationEvent event) {
        swings.put(event.getPlayer().getUniqueId(),tick);event(event.getPlayer(),"swing",Map.of("animation",event.getAnimationType().name()));
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void held(PlayerItemHeldEvent event) {event(event.getPlayer(),"held",Map.of("slot",event.getNewSlot()));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void interact(PlayerInteractEvent event) {event(event.getPlayer(),"use-attempt",Map.of("action",event.getAction().name(),"hand",String.valueOf(event.getHand())));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void jump(com.destroystokyo.paper.event.player.PlayerJumpEvent event) {event(event.getPlayer(),"jump",Map.of("observedNativeJump",true));}
    @EventHandler(priority=EventPriority.MONITOR)
    public void death(PlayerDeathEvent event) {
        for(var track:List.copyOf(tracks.values()))if(track.player.equals(event.getEntity().getUniqueId())||track.opponent.equals(event.getEntity().getUniqueId())) {
            row(track,Map.of("type","terminal","tick",tick,"dead",event.getEntity().getName()));end(track,"death");
        }
    }
    private void event(Player player,String kind,Map<String,Object> data) {
        var track=tracks.get(player.getUniqueId());if(track==null)return;
        row(track,Map.of("type","action-event","tick",tick,"event",kind,"data",data));
    }
    @EventHandler public void quit(PlayerQuitEvent event) {
        var track=tracks.get(event.getPlayer().getUniqueId());if(track!=null)end(track,"disconnect");
        preRoll.remove(event.getPlayer().getUniqueId());swings.remove(event.getPlayer().getUniqueId());
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args) {
        if(!sender.hasPermission("pvprecord.admin"))return true;
        if(args.length>=2&&args[0].equalsIgnoreCase("watch")) {
            Player player=Bukkit.getPlayerExact(args[1]);if(player!=null)watched.add(player.getUniqueId());
            sender.sendMessage("PvP recorder watch="+(player!=null));return true;
        }
        sender.sendMessage("PvPFrameRecorder frames="+frames+" active="+tracks.size()+" queue="+writes.size()+" dropped="+dropped
            +"; auto captures combat, /pvprecord watch <player>; output plugins/PvPFrameRecorder/bouts");return true;
    }
}
