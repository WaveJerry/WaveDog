package local.wavedog.punengbho;

import com.google.gson.*;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import io.papermc.paper.event.player.PlayerShieldDisableEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

/** Referee and native receipts only. Combat movement, use and attacks are client inputs. */
public final class PunengbhoCore extends JavaPlugin implements Listener, PluginMessageListener {
    private boolean swordOnly;
    private boolean crystalOnly;
    private ItemStack[] crystalBotKit, crystalPlayerKit;
    private String channel, botName, duelCommand, receiptFighter;
    private Path runtime;
    private ItemStack[] originalInventory;
    private int originalHeldSlot;
    private final Gson json=new Gson();
    private String token, match, opponent, policySha="unknown";
    private int preparedAt, startAt;
    private long heartbeat;
    private boolean ready, active, preparing, learning;
    private final Map<Long,Intent> intents=new HashMap<>();
    private Intent actual;
    private final java.util.concurrent.BlockingQueue<String> records=new java.util.concurrent.LinkedBlockingQueue<>(16384);
    private volatile boolean writing;
    private Thread writer;
    private static final class Intent {
        final long id; final String kind; final UUID target; final int requested;
        int actualTick=-1; boolean consumed;
        Intent(long id,String kind,UUID target,int tick){this.id=id;this.kind=kind;this.target=target;this.requested=tick;}
    }
    @Override public void onEnable(){
        swordOnly=getName().equals("WaveDogBrotherCore");
        crystalOnly=getName().equals("WaveDogFatherCore");
        botName=crystalOnly?"WaveDogFather":swordOnly?"WaveDogBrother":"WaveDog";
        duelCommand=crystalOnly?"wavedogfather":swordOnly?"wavedogbrother":"wavedog_punengbho";
        channel=(swordOnly||crystalOnly?duelCommand:"punengbho")+":control";
        receiptFighter=swordOnly||crystalOnly?botName:"Punengbho";
        runtime=Path.of(System.getProperty("wavedog.workspace","D:/CodexWorkspace/ban"),
            "work",crystalOnly?"wavedog-father":swordOnly?"wavedog-brother":"wavedog-punengbho","runtime");
        if(crystalOnly)try(var stream=Objects.requireNonNull(getResource("crystal-kit.json"))){
            var kits=JsonParser.parseString(new String(stream.readAllBytes(),StandardCharsets.UTF_8)).getAsJsonObject();
            crystalPlayerKit=readKit(kits.getAsJsonArray("player"));crystalBotKit=readKit(kits.getAsJsonArray("bot"));
        }catch(java.io.IOException error){throw new IllegalStateException("Crystal kit unavailable",error);}
        try {
            Files.createDirectories(getDataFolder().toPath());
            token=UUID.randomUUID().toString();
            Files.writeString(getDataFolder().toPath().resolve("client-token.txt"),token);
        } catch(Exception e){throw new IllegalStateException(e);}
        getServer().getMessenger().registerIncomingPluginChannel(this,channel,this);
        getServer().getMessenger().registerOutgoingPluginChannel(this,channel);
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand(duelCommand)).setExecutor(this);
        writing=true;
        writer=new Thread(()->{
            Path file=getDataFolder().toPath().resolve("native-events.jsonl");
            while(writing||!records.isEmpty())try{
                String line=records.poll(250,java.util.concurrent.TimeUnit.MILLISECONDS);
                if(line!=null)Files.writeString(file,line+"\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);
            }catch(InterruptedException e){break;}catch(Exception e){getLogger().warning("Native journal: "+e);}
        },botName+"-native-journal");writer.setDaemon(true);writer.start();
        getServer().getScheduler().runTaskTimer(this,this::tick,1,1);
    }
    @Override public void onDisable(){finish("plugin-disable",null);writing=false;
        try{if(writer!=null)writer.join(2000);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private Player bot(){return Bukkit.getPlayerExact(botName);}
    private boolean authenticated(Player p){
        var auth=Bukkit.getPluginManager().getPlugin("AuthMe");
        if(auth==null)return true;
        try{Class<?> api=Class.forName("fr.xephi.authme.api.v3.AuthMeApi",true,auth.getClass().getClassLoader());
            Object instance=api.getMethod("getInstance").invoke(null);
            return (boolean)api.getMethod("isAuthenticated",Player.class).invoke(instance,p);
        }catch(Exception e){return false;}
    }
    private void send(Map<String,Object> row){Player p=bot();if(p==null)return;
        var data=new LinkedHashMap<String,Object>(row);data.put("serverTick",Bukkit.getCurrentTick());
        if(match!=null)data.put("matchId",match);
        var nativeController=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
        if(nativeController!=null&&nativeController.isEnabled())try{
            if(Boolean.TRUE.equals(nativeController.getClass().getMethod("receiveCore",String.class,Map.class).invoke(nativeController,botName,data)))return;
        }catch(ReflectiveOperationException error){throw new IllegalStateException("Native control transport failed",error);}
        p.sendPluginMessage(this,channel,json.toJson(data).getBytes(StandardCharsets.UTF_8));}
    private void record(String type,Map<String,Object> fields){
        var row=new LinkedHashMap<String,Object>();row.put("at",java.time.Instant.now().toString());
        row.put("type",type);row.put("serverTick",Bukkit.getCurrentTick());row.put("matchId",match);row.putAll(fields);
        if(!records.offer(json.toJson(row)))getLogger().severe("Native journal full; record incomplete");
    }
    @Override public void onPluginMessageReceived(String inputChannel,Player source,byte[] bytes){
        if(!channel.equals(inputChannel)||!source.getName().equals(botName)||!authenticated(source)||bytes.length>16000)return;
        try{
            JsonObject row=json.fromJson(new String(bytes,StandardCharsets.UTF_8),JsonObject.class);
            if(!token.equals(row.get("token").getAsString()))return;
            String type=row.get("type").getAsString();
            if(type.equals("heartbeat")){
                heartbeat=System.currentTimeMillis();ready=row.has("modelReady")&&row.get("modelReady").getAsBoolean();
                if(row.has("policySha"))policySha=row.get("policySha").getAsString();
                // Recover a persisted receipt after an old client or a lost
                // acknowledgement, never by clearing the gate on a timeout.
                if(learning&&!active&&!preparing&&match!=null){
                    Path report=runtime.resolve(match+"-report.json"),trained=runtime.resolve(match+"-training.json");
                    if(Files.isRegularFile(report)&&Files.isRegularFile(trained)){
                        JsonObject saved=json.fromJson(Files.readString(trained),JsonObject.class);
                        JsonObject bout=json.fromJson(Files.readString(report),JsonObject.class);
                        String event=saved.get("event").getAsString();
                        if((event.equals("trained")||event.equals("trained_partial"))
                            &&receiptFighter.equals(saved.get("fighter").getAsString())&&match.equals(bout.get("matchId").getAsString())
                            &&bout.get("frames").getAsInt()>0&&Files.isRegularFile(Path.of(bout.get("completedFrames").getAsString()))){
                            learning=false;record("shared_merge_recovered",Map.of("sha256",saved.get("sha256").getAsString()));
                            Bukkit.broadcastMessage("§b["+botName+"] 本局轨迹、学习回执及检查点已保存，开战入口已就绪。");
                        }
                        if(event.equals("evaluation_saved")&&saved.has("trainingSkipped")&&saved.get("trainingSkipped").getAsBoolean()
                            &&receiptFighter.equals(saved.get("fighter").getAsString())&&match.equals(bout.get("matchId").getAsString())
                            &&bout.get("frames").getAsInt()>0&&Files.isRegularFile(Path.of(bout.get("completedFrames").getAsString()))
                            &&Path.of(saved.get("file").getAsString()).toAbsolutePath().normalize().equals(
                                runtime.resolve("../model/evaluations/"+match+".json.gz").toAbsolutePath().normalize())
                            &&Files.isRegularFile(Path.of(saved.get("file").getAsString()))){
                            learning=false;record("evaluation_saved_recovered",Map.of("sha256",saved.get("checkpointSha256").getAsString()));
                            Bukkit.broadcastMessage("§b["+botName+"] 本局冻结验收轨迹已保存，权重未更新，开战入口已就绪。");
                        }
                    }
                }
                send(Map.of("type","heartbeat_ack","active",active,"preparing",preparing));return;
            }
            if(type.equals("reviewed")&&row.has("matchId")){
                record("qwen_review",Map.of("reviewedMatchId",row.get("matchId").getAsString()));
                Bukkit.broadcastMessage("§b["+botName+"] Qwen 对局复盘已保存（"+row.get("matchId").getAsString().substring(0,8)+"）。");return;
            }
            if(!row.has("matchId")||!Objects.equals(match,row.get("matchId").getAsString()))return;
            if(type.equals("attack_intent")&&active){
                Player target=Bukkit.getPlayerExact(opponent);
                if(target==null||!opponent.equals(row.get("target").getAsString()))return;
                long id=row.get("attackId").getAsLong();
                intents.put(id,new Intent(id,row.get("kind").getAsString(),target.getUniqueId(),Bukkit.getCurrentTick()));
            }else if(type.equals("merged")){
                if(!row.has("persisted")||!row.get("persisted").getAsBoolean()){
                    record("merge_not_persisted",Map.of("reason","missing durable client receipt"));return;
                }
                learning=false;record("shared_merge",Map.of("sha256",row.get("sha256").getAsString()));
                Bukkit.broadcastMessage("§b["+botName+"] 本局分身已汇总：PPO 更新 GRU / Transformer / 门控，检查点已保存。");
            }else if(type.equals("learning_error")){
                learning=true;record("learning_error",Map.of("reason",row.get("reason").getAsString()));
                Bukkit.broadcastMessage("§c["+botName+"] 本局学习尚未成功，原始轨迹已保留。");
            }
        }catch(Exception e){getLogger().warning("Invalid "+botName+" control message: "+e.getClass().getSimpleName());}
    }
    private void tick(){
        // These are the player's own HUD/item states, never hidden opponent
        // telemetry. A use packet is a request, not confirmation of blocking.
        Player own=bot();
        if(own!=null&&!own.getDisplayName().equals(botName)){
            own.setDisplayName(botName);own.setPlayerListName(botName);
            var scoreboard=Bukkit.getScoreboardManager().getMainScoreboard();
            String teamName=crystalOnly?"wd-father":swordOnly?"wd-brother":"wd-punengbho";
            var team=scoreboard.getTeam(teamName);
            if(team==null)team=scoreboard.registerNewTeam(teamName);
            team.setPrefix("");team.addEntry(botName);
        }
        if(active&&own!=null)send(Map.of("type","self_state",
            "shieldCooldown",own.getCooldown(Material.SHIELD),"shielding",own.isBlocking(),
            "using",own.hasActiveItem(),"useTicks",own.getHandRaisedTime(),
            "activeItem",own.hasActiveItem()?own.getActiveItem().getType().name():"AIR",
            "charge",own.getCooledAttackStrength(0),"held",own.getInventory().getHeldItemSlot(),
            "fallDistance",own.getFallDistance()));
        intents.values().removeIf(i->Bukkit.getCurrentTick()-i.requested>6);
        if((active||preparing)&&(bot()==null||!ready||System.currentTimeMillis()-heartbeat>6000)){
            finish("controller-offline",null);return;}
        if(preparing&&(startAt-Bukkit.getCurrentTick())>0&&(startAt-Bukkit.getCurrentTick())%20==0){
            int seconds=(startAt-Bukkit.getCurrentTick())/20;
            for(Player player:new Player[]{bot(),Bukkit.getPlayerExact(opponent)})if(player!=null)
                player.sendTitle("§e"+seconds,"§f准备对战",0,25,0);
        }
        if(preparing&&Bukkit.getCurrentTick()>=startAt){
            for(Player player:new Player[]{bot(),Bukkit.getPlayerExact(opponent)})if(player!=null){
                for(var metadata:player.getMetadata("wavedog-preparation-cage"))if(metadata.getOwningPlugin()==this
                    &&metadata.value() instanceof java.util.List<?> states)for(Object value:states)
                        if(value instanceof org.bukkit.block.BlockState state&&state.getBlock().getType()==Material.GLASS)
                            state.update(true,false);
                player.removeMetadata("wavedog-preparation-cage",this);
                player.sendTitle("§a开始！","",0,20,5);
            }
            preparing=false;active=true;
            send(Map.of("type","start","opponent",opponent));record("start",Map.of("opponent",opponent,"policySha",policySha));
            Player p=Bukkit.getPlayerExact(opponent);if(p!=null)p.sendMessage("§b"+botName+" 对战开始。");
        }
    }
    private ItemStack crossbow(){
        ItemStack item=new ItemStack(Material.CROSSBOW);CrossbowMeta meta=(CrossbowMeta)item.getItemMeta();
        meta.addChargedProjectile(new ItemStack(Material.ARROW));item.setItemMeta(meta);return item;
    }
    private void equipBot(Player p){
        var i=p.getInventory();i.clear();i.setItem(0,new ItemStack(Material.DIAMOND_SWORD));
        i.setItem(1,new ItemStack(Material.BOW));i.setItem(2,new ItemStack(Material.ARROW,5));
        i.setItem(4,crossbow());i.setItem(7,new ItemStack(Material.DIAMOND_AXE));i.setHeldItemSlot(7);
        i.setItemInOffHand(new ItemStack(Material.SHIELD));
        i.setHelmet(new ItemStack(Material.DIAMOND_HELMET));i.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        i.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));i.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.setGameMode(GameMode.SURVIVAL);p.setHealth(20);p.setFoodLevel(20);p.setSaturation(5);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
        p.updateInventory();
    }
    private void equipSword(Player p){
        var i=p.getInventory();i.clear();i.setItem(0,new ItemStack(Material.DIAMOND_SWORD));i.setHeldItemSlot(0);
        i.setHelmet(new ItemStack(Material.DIAMOND_HELMET));i.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        i.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));i.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);p.setSaturation(5);p.setNoDamageTicks(0);p.setFallDistance(0);p.updateInventory();
    }
    private ItemStack[] readKit(JsonArray entries){
        var inventory=new ItemStack[41];
        for(var entry:entries){
            var item=entry.getAsJsonObject();int slot=item.get("slot").getAsInt();
            var stack=Bukkit.getItemFactory().createItemStack(item.get("stack").getAsString());
            stack.setAmount(item.get("count").getAsInt());inventory[slot]=stack;
        }
        return inventory;
    }
    private void equipCrystal(Player p,ItemStack[] kit){
        p.getInventory().setContents(Arrays.stream(kit).map(i->i==null?null:i.clone()).toArray(ItemStack[]::new));
        p.getInventory().setHeldItemSlot(0);p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);p.setSaturation(5);p.setNoDamageTicks(0);p.setFallDistance(0);p.updateInventory();
    }
    private void humanKit(Player p){
        var i=p.getInventory();
        for(Material m:List.of(Material.DIAMOND_SWORD,Material.DIAMOND_AXE,Material.BOW,Material.CROSSBOW,Material.SHIELD))
            if(!i.contains(m)&&i.getItemInOffHand().getType()!=m)i.addItem(new ItemStack(m));
        if(!i.contains(Material.ARROW))i.addItem(new ItemStack(Material.ARROW,5));
        if(i.getItemInOffHand().getType()==Material.AIR){i.removeItem(new ItemStack(Material.SHIELD));i.setItemInOffHand(new ItemStack(Material.SHIELD));}
        if(i.getHelmet()==null||i.getHelmet().getType().isAir())i.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        if(i.getChestplate()==null||i.getChestplate().getType().isAir())i.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        if(i.getLeggings()==null||i.getLeggings().getType().isAir())i.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        if(i.getBoots()==null||i.getBoots().getType().isAir())i.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.setHealth(20);p.setFoodLevel(20);p.setSaturation(5);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
    }
    private Location startLocation(Player p){
        // ARENA_PREPARATION_V2: all commands/buttons use the lower arena.
        World arena=Bukkit.getWorld("world");if(arena==null)return null;
        int first=Math.floorMod(Bukkit.getCurrentTick()/20,8);
        for(int turn=0;turn<8;turn++){
            double angle=(first+turn)*Math.PI/4;
            double x=Math.floor(1014.5+Math.cos(angle)*6)+.5;
            double z=Math.floor(1014.5+Math.sin(angle)*6)+.5;
            Location botAt=new Location(arena,x,221,z),humanAt=new Location(arena,2029-x,221,2029-z);
            boolean clear=true;
            for(Location at:new Location[]{botAt,humanAt}){
                if(!at.clone().add(0,-1,0).getBlock().getType().isSolid()){clear=false;break;}
                for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)for(int dy=0;dy<=3;dy++)
                    if(!at.clone().add(dx,dy,dz).getBlock().getType().isAir())clear=false;
            }
            if(clear){botAt.setYaw((float)Math.toDegrees(Math.atan2(-(humanAt.getX()-x),humanAt.getZ()-z)));return botAt;}
        }
        return null;
    }
    private void finish(String reason,String winner){
        if(!active&&!preparing)return;
        for(Player player:new Player[]{bot(),opponent==null?null:Bukkit.getPlayerExact(opponent)})if(player!=null){
            for(var metadata:player.getMetadata("wavedog-preparation-cage"))if(metadata.getOwningPlugin()==this
                &&metadata.value() instanceof java.util.List<?> states)for(Object value:states)
                    if(value instanceof org.bukkit.block.BlockState state&&state.getBlock().getType()==Material.GLASS)
                        state.update(true,false);
            player.removeMetadata("wavedog-preparation-cage",this);
            player.removeMetadata("wavedog-duel-owner",this);player.resetTitle();
        }
        if(originalInventory!=null){
            Player target=Bukkit.getPlayerExact(opponent);
            if(target!=null){
                target.getInventory().setContents(originalInventory);
                target.getInventory().setHeldItemSlot(originalHeldSlot);
                target.updateInventory();
            }
            originalInventory=null;
        }
        boolean hadFrames=active;active=preparing=false;learning=hadFrames;
        send(Map.of("type","end","reason",reason,"winner",winner==null?"":winner,"hadFrames",hadFrames));
        record("end",Map.of("reason",reason,"winner",winner==null?"":winner));
        var entry=Bukkit.getPluginManager()==null?null:Bukkit.getPluginManager().getPlugin("WaveDogArenaEntry");
        if(entry!=null&&entry.getConfig().isConfigurationSection("duel-return")){
            var config=entry.getConfig();World lobby=Bukkit.getWorld(config.getString("duel-return.world","world"));
            if(lobby!=null){
                Location at=new Location(lobby,config.getDouble("duel-return.x"),config.getDouble("duel-return.y"),
                    config.getDouble("duel-return.z"),(float)config.getDouble("duel-return.yaw"),0);
                for(Player player:new Player[]{bot(),opponent==null?null:Bukkit.getPlayerExact(opponent)})if(player!=null){
                    if(player.isDead())player.setMetadata("wavedog-return-after-duel",new org.bukkit.metadata.FixedMetadataValue(this,at.clone()));
                    else {player.setFallDistance(0);player.teleport(at);}
                }
                record("duel_return",Map.of("world",lobby.getName(),"x",at.getX(),"y",at.getY(),"z",at.getZ()));
            }
        }
        World arena=Bukkit.getWorld("world");int removed=0;
        if(arena!=null)for(Entity entity:arena.getEntities()){
            if(crystalOnly&&entity.getScoreboardTags().contains("wavedog-father-crystal")){entity.remove();continue;}
            if(!(entity instanceof Item)&&!(entity instanceof ExperienceOrb))continue;
            Location l=entity.getLocation();
            if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<219||l.getY()>240)continue;
            entity.remove();removed++;
        }
        record("arena_cleanup",Map.of("phase","end","removed",removed));
        Player p=opponent==null?null:Bukkit.getPlayerExact(opponent);
        if(p!=null)p.sendMessage("§b"+botName+" 本局结束："+(winner==null?reason:"胜者 "+winner)+"。正在保存与汇总。");
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.hasPermission("wavedog.control"))return true;
        String sub=args.length>0?args[0].toLowerCase(Locale.ROOT):"status";
        if(sub.equals("status")){
            sender.sendMessage("§b"+botName+" "+(bot()!=null&&bot().hasMetadata("wavedog-native-player")?"服务端玩家=":"协议玩家=")+(bot()!=null)+"，控制器="+ready+"，对局="+(active?"进行中":preparing?"准备中":"空闲")
                +"，汇总="+learning+"，权重="+policySha.substring(0,Math.min(16,policySha.length())));return true;}
        if(sub.equals("setupcheck")){
            Player subject=args.length==2?Bukkit.getPlayerExact(args[1]):bot();
            if(subject==null){sender.sendMessage("§c玩家未在线。");return true;}
            Location at=startLocation(subject);
            if(at==null){sender.sendMessage("§c竞技场无安全玻璃罩站位。");return true;}
            sender.sendMessage(json.toJson(Map.of("arena","world","bot",List.of(at.getX(),at.getY(),at.getZ()),
                "human",List.of(2029-at.getX(),221.0,2029-at.getZ()),"prepareTicks",200,"glassPerPlayer",33,
                "readOnly",true)));return true;
        }
        if(sub.equals("stop")){
            if(!active&&!preparing&&learning&&match!=null){
                // A disconnect can lose the original end packet. Request the
                // durable client receipt again; never clear learning blindly.
                send(Map.of("type","end","reason","operator-stop-recovery","winner","","hadFrames",true));
            }else finish("operator-stop",null);
            sender.sendMessage("§b已停止 "+botName+" 对战，轨迹保存后开放入口。");return true;}
        if(!sub.equals("duel")||args.length!=2){sender.sendMessage("/"+duelCommand+" duel 玩家名 | stop | status");return true;}
        if(active||preparing||learning){sender.sendMessage("§e请先结束当前对局并等待学习汇总。");return true;}
        Player target=Bukkit.getPlayerExact(args[1]), bot=bot();
        if(bot==null||!ready||System.currentTimeMillis()-heartbeat>5000){sender.sendMessage("§c"+botName+" 控制器或模型尚未就绪。");return true;}
        if(target==null||target==bot||target.isDead()||target.getName().startsWith("NBot")
            ||target.getGameMode()!=GameMode.SURVIVAL||!authenticated(target)||!authenticated(bot)){
            sender.sendMessage("§c目标须为已登录、存活的生存模式真人玩家。");return true;}
        if(target.hasMetadata("wavedog-native-player")||target.hasMetadata("wavedog-duel-owner")
            ||((swordOnly||crystalOnly)&&Bukkit.getOnlinePlayers().stream().anyMatch(p->p.hasMetadata("wavedog-duel-owner")))){
            sender.sendMessage("§e竞技场已占用，或目标是机器人。");return true;}
        Location at=startLocation(target);
        if(at==null){sender.sendMessage("§c附近没有安全站位，请在空旷平地发起对战。");return true;}
        match=UUID.randomUUID().toString();opponent=target.getName();intents.clear();actual=null;
        World arena=Bukkit.getWorld("world");int removed=0;
        if(arena!=null)for(Entity entity:arena.getEntities()){
            if(!(entity instanceof Item)&&!(entity instanceof ExperienceOrb))continue;
            Location l=entity.getLocation();
            if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<219||l.getY()>240)continue;
            entity.remove();removed++;
        }
        record("arena_cleanup",Map.of("phase","prepare","removed",removed));
        Location humanAt=new Location(at.getWorld(),2029-at.getX(),221,2029-at.getZ());
        humanAt.setYaw((float)Math.toDegrees(Math.atan2(-(at.getX()-humanAt.getX()),at.getZ()-humanAt.getZ())));
        if(!swordOnly&&!crystalOnly){equipBot(bot);humanKit(target);}
        // Teleports and glass are referee setup; never combat movement.
        if(!target.teleport(humanAt)||!bot.teleport(at)){
            sender.sendMessage("§c准备传送失败，未开始对战。");return true;
        }
        if(swordOnly||crystalOnly){
            originalInventory=Arrays.stream(target.getInventory().getContents())
                .map(item->item==null?null:item.clone()).toArray(ItemStack[]::new);
            originalHeldSlot=target.getInventory().getHeldItemSlot();
            if(crystalOnly){equipCrystal(bot,crystalBotKit);equipCrystal(target,crystalPlayerKit);}
            else{equipSword(bot);equipSword(target);}
        }
        for(Player player:new Player[]{bot,target}){
            var states=new ArrayList<org.bukkit.block.BlockState>();Location center=player.getLocation();
            for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)for(int dy=0;dy<=3;dy++){
                if(dy<3&&dx==0&&dz==0)continue;
                var block=center.clone().add(dx,dy,dz).getBlock();
                states.add(block.getState());block.setType(Material.GLASS,false);
            }
            player.setMetadata("wavedog-preparation-cage",new org.bukkit.metadata.FixedMetadataValue(this,states));
            player.setMetadata("wavedog-duel-owner",new org.bukkit.metadata.FixedMetadataValue(this,botName));
            player.sendTitle("§e10","§f玻璃罩将在倒计时结束后消失",0,25,0);
        }
        preparedAt=Bukkit.getCurrentTick();startAt=preparedAt+200;preparing=true;
        send(Map.of("type","prepare","opponent",opponent,"startAfterTicks",200));
        sender.sendMessage("§b"+botName+" 将在 10 秒后对战 "+opponent+"。");
        target.sendMessage("§b已安排你对战 "+botName+"，10 秒玻璃罩准备。"+(crystalOnly?"改良自 Theobald's PvP Practice。":swordOnly?"本局使用剑斗 Kit。":"使用 /WaveDog stop 停止。"));
        record("prepare",Map.of("opponent",opponent,"policySha",policySha));return true;
    }
    private boolean participant(Player p){return p.getName().equals(botName)||p.getName().equals(opponent);}
    @EventHandler(priority=EventPriority.HIGHEST) public void preparationDamage(EntityDamageEvent e){
        if(preparing&&e.getEntity() instanceof Player p&&participant(p))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.MONITOR) public void packet(PrePlayerAttackEntityEvent e){
        if(e.getPlayer().getName().equals(botName))actual=null;
        if(!active||!e.getPlayer().getName().equals(botName)||!(e.getAttacked() instanceof Player target)
            ||!target.getName().equals(opponent))return;
        Intent found=intents.values().stream().filter(i->!i.consumed&&i.actualTick<0&&i.target.equals(target.getUniqueId())
            &&Bukkit.getCurrentTick()-i.requested<=2).max(Comparator.comparingLong(i->i.id)).orElse(null);
        if(found==null){record("unclaimed_attack_packet",Map.of("target",target.getName()));return;}
        found.actualTick=Bukkit.getCurrentTick();if(e.willAttack())actual=found;
        send(Map.of("type","attack_packet","attackId",found.id,"kind",found.kind,"willAttack",e.willAttack()));
        record("attack_packet",Map.of("attackId",found.id,"kind",found.kind,"target",target.getName(),"willAttack",e.willAttack()));
    }
    @EventHandler(priority=EventPriority.MONITOR) public void damage(EntityDamageByEntityEvent e){
        if(!active||!(e.getEntity() instanceof Player victim)||!participant(victim))return;
        Player attacker=e.getDamager() instanceof Player p?p:e.getDamager() instanceof Projectile shot&&shot.getShooter() instanceof Player p?p:null;
        if(attacker==null||!participant(attacker)||attacker==victim)return;
        boolean melee=e.getDamager() instanceof Player;
        double shield=e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)?e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING):0;
        if(melee&&!e.isCancelled()&&victim.getName().equals(botName)&&shield<-.001){
            var block=Map.<String,Object>of("type","blocked_melee","attacker",attacker.getName(),"blockId",Bukkit.getCurrentTick(),"shieldDisabled",victim.hasCooldown(Material.SHIELD));
            send(block);record("blocked_melee",block);
        }
        long id=-1;
        if(melee&&attacker.getName().equals(botName)&&actual!=null&&!actual.consumed&&actual.target.equals(victim.getUniqueId())
            &&Bukkit.getCurrentTick()-actual.actualTick<=1){id=actual.id;actual.consumed=true;}
        var row=new LinkedHashMap<String,Object>();row.put("type","damage");row.put("attacker",attacker.getName());row.put("victim",victim.getName());
        row.put("amount",e.getFinalDamage());row.put("cancelled",e.isCancelled());row.put("melee",melee);row.put("attackId",id);
        row.put("nativeCritical",e.isCritical());row.put("shieldModifier",shield);
        send(row);record("damage",row);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void disable(PlayerShieldDisableEvent e){
        if(active&&e.getPlayer().getName().equals(botName)){
            send(Map.of("type","shield_disabled","cooldownTicks",e.getCooldown()));
            record("shield_disabled",Map.of("cooldownTicks",e.getCooldown()));
        }
    }
    @EventHandler(ignoreCancelled=true) public void dropKit(PlayerDropItemEvent e){
        if((swordOnly||crystalOnly)&&(active||preparing)&&participant(e.getPlayer()))e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled=true) public void pickupKit(EntityPickupItemEvent e){
        if(swordOnly&&(active||preparing)&&e.getEntity() instanceof Player p&&participant(p))e.setCancelled(true);
    }
    @EventHandler public void death(PlayerDeathEvent e){
        if(!active||!participant(e.getEntity()))return;
        e.setKeepInventory(true);e.getDrops().clear();e.setKeepLevel(true);e.setDroppedExp(0);
        finish("death",e.getEntity().getName().equals(botName)?opponent:botName);
    }
    @EventHandler public void quit(PlayerQuitEvent e){if((active||preparing)&&participant(e.getPlayer()))finish("disconnect",null);
        if(e.getPlayer().getName().equals(botName))ready=false;}
    @EventHandler(priority=EventPriority.HIGHEST) public void respawn(PlayerRespawnEvent e){
        if(e.getPlayer().getName().equals(botName))ready=false;
        for(var value:e.getPlayer().getMetadata("wavedog-return-after-duel"))
            if(value.getOwningPlugin()==this&&value.value() instanceof Location at)e.setRespawnLocation(at);
        e.getPlayer().removeMetadata("wavedog-return-after-duel",this);
    }
}
