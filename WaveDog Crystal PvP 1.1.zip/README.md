# WaveDog Crystal PvP 1.0

WaveDogFather 是 Paper 1.21.11 上的服务端 水晶 PvP 机器人。根据原版爆炸伤害选择水晶、重生锚和末影珍珠动作。被堵时用对应工具挖掘。套装移除了 le bonk，开场注明改良自 Theobald's PvP Practice。

挖掘按服务器 tick 推进，使用主手工具的原版速度。吃金苹果、拉弓和装弩期间由物品使用独占手部操作。

## 安装

1. 准备 Windows x64、Paper 1.21.11、Java 21、Node.js 和兼容的竞技场地图。
2. 关闭目标服，将 `plugins` 内的 JAR 和配置合并到目标服。同一服务器装两个包时，保留水晶包的 `WaveDogArenaEntry/config.yml`，然后运行 `/wdarena install`。
3. 在项目的 `work/pvp-dual-brain` 运行 `npm ci --omit=dev`。启动 Paper 时在 `-jar` 前加入 `"-Dwavedog.workspace=项目绝对路径"` 和 `"-Dwavedog.node=node.exe绝对路径"`。升级旧服时，清除 Native 插件配置中的旧 `policy-directory` 指向。
4. 现有服务器可以保留自己的身份 JSON。新服使用包内示例身份，按地图调整出生点和返回点。竞技场保护使用配套地图和对应的 `terrain.dat.gz`。
5. 启动后用 `/wdnative status` 检查机器人在线。运行 `/wdarena install-father` 安装入口，或从控制台用 `wavedogfather duel 玩家名` 发起对战。

源码在 `work`。在启动过目标版本 Paper 后，用 `python build.py --server-root "Paper 服务端目录" --java-bin "Java 21 bin 目录"` 重编译。插件 JAR、策略和冻结模型权重均随包提供。

发布包使用当前主服的机器人 JAR。公共控制器和裁判依赖随包带齐，两个包可以在同一服合并。Paper 本体、世界存档、玩家数据、个性化皮肤签名、登录凭据、历史对局和 `node_modules` 由部署环境自行管理。
