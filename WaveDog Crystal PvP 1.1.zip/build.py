"""Recompile the included plugin sources against a Paper 1.21.11 server."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--server-root", type=Path, required=True)
parser.add_argument("--java-bin", type=Path, help="Java 21 bin directory")
args = parser.parse_args()
server = args.server_root.resolve()
java = args.java_bin or server / "runtime/java21/bin"
manifest_file = root / "manifest.json"
manifest = json.loads(manifest_file.read_text(encoding="utf8"))

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()

plugins = root / "plugins"
paper = server / "versions/1.21.11/paper-1.21.11.jar"
if not paper.is_file():
    parser.error(f"Paper 1.21.11 needs to have been started once: {paper}")
libraries = server / "libraries"
api = next((libraries / "io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT").glob("*.jar"), None)
if api is None:
    parser.error("Missing Paper 1.21.11 API in the target server libraries")
classpath = os.pathsep.join(map(str, [paper, api, *sorted(libraries.rglob("*.jar"), reverse=True),
                                      *sorted(plugins.glob("*.jar"))]))
with tempfile.TemporaryDirectory(dir=root) as temporary:
    temporary = Path(temporary)
    compiled = {}
    for jar_name, component in manifest["sources"].items():
        if component not in compiled:
            source = root / "work" / component / "src"
            classes = temporary / component
            classes.mkdir()
            files = sorted(source.rglob("*.java"))
            if not files:
                raise FileNotFoundError(source)
            flags = ["-proc:none", "--release", "21", "-encoding", "UTF-8", "-cp",
                     classpath, "-d", str(classes), *map(str, files)]
            response = temporary / "javac.args"
            response.write_text("\n".join(json.dumps(flag, ensure_ascii=False) for flag in flags), encoding="utf8")
            subprocess.run([str(java / "javac.exe"), "-J-Dfile.encoding=UTF-8", "-J-Duser.language=en", "@" + str(response)], check=True)
            compiled[component] = {p.relative_to(classes).as_posix(): p.read_bytes()
                                   for p in classes.rglob("*.class")}
        jar = plugins / jar_name
        with zipfile.ZipFile(jar) as existing:
            entries = {name: existing.read(name) for name in existing.namelist()}
        entries.update(compiled[component])
        if jar_name == "WaveDogNativeControl.jar":
            policy = json.loads(entries["policy-manifest.json"])
            for module, source in manifest["policySources"].items():
                entries["policy/" + module] = (root / source).read_bytes()
                policy["files"][module] = digest(entries["policy/" + module])
            entries["policy-bootstrap.js"] = (root / "work/wavedog-native/policy-bootstrap.js").read_bytes()
            policy["bootstrapSha256"] = digest(entries["policy-bootstrap.js"])
            policy["sha256"] = digest(json.dumps(policy["files"], sort_keys=True).encode())
            entries["policy-manifest.json"] = json_bytes(policy)
            manifest["loadedPolicySha256"] = policy["sha256"]
        if jar_name == "WaveDogFatherCore.jar":
            entries["crystal-kit.json"] = (root / "work/wavedog-punengbho/crystal-kit.json").read_bytes()
        with zipfile.ZipFile(temporary / jar_name, "w", zipfile.ZIP_DEFLATED) as output:
            for name, raw in sorted(entries.items()):
                output.writestr(name, raw)
    for jar_name in manifest["sources"]:
        (temporary / jar_name).replace(plugins / jar_name)

manifest["files"] = {name: digest((root / name).read_bytes()) for name in manifest["files"]}
manifest["plugins"] = {name: {"sha256": manifest["files"]["plugins/" + name]} for name in manifest["sources"]}
manifest["startupJarSha256"] = manifest["files"]["plugins/WaveDogNativeControl.jar"]
manifest_file.write_bytes(json_bytes(manifest))
print(f"Built {manifest['project']} {manifest['version']}")
