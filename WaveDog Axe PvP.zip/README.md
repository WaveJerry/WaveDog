# WaveDog Axe PvP

主服策略 `f4ea69a2fa6601647a71a8c938e3dbda1d10165fc77bec7cd44a1edad040a674`。包含 WaveDog 和 WaveDogSon 的接入插件、精确策略源码、竞技场配置、弩校准、500 Hz 探测插件和旧 GRU＋GTrXL 剑斗权重。当前 A 是地面短后撤斧控距，B 由短后撤失控的实际入距触发，确认击退脱离或盾破盾反后回 A。

## 恢复

1. 解压到固定目录。使用 Windows x64、Paper 1.21.11、Java 21 和 Node.js。
2. 在解压目录的 `work/pvp-dual-brain` 执行 `npm ci --omit=dev`。
3. 在服务器停止时，把包内 `plugins` 合并到目标服的 `plugins`。配置使用 JAR 内锁定的策略，解压路径无需与制作机相同。
4. 在服务器启动的 `-jar` 前添加 `"-Dwavedog.workspace=解压目录绝对路径" "-Dwavedog.node=node.exe绝对路径"`。
5. 目标服需要原竞技场地图，或在代码和各插件配置中调整竞技场位置。启动后检查 `wdnative status`、`wdneural` 和 `wdprobe status`，再用 `/wavedog duel 玩家名` 或 `/wavedogson duel 玩家名`。

包内保留机器人外观所需的身份属性。地图存档、完整服务端、实战日志、账号和 RCON 凭据以及 Qwen 和 DeepSeek 权重均独立于该备份。已热切换的策略通过配套启动 JAR 恢复。原生控制 JAR 重新压缩，逐条目校验与原启动包的内容相同。Javet 已内置在 JAR 中。若从源码重编译，可从 Maven Central 获取 `com.caoccao.javet` 的 `javet` 和 `javet-v8-windows-x86_64` 4.1.7 依赖，放入 `work/wavedog-native/lib`。
