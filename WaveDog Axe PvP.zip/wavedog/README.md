# WaveDog Axe PvP

Minecraft 盾斧 PvP 机器人当前运行版的 GitHub 源码导出。没有执行回退，没有修改或重启主服务器。

控制器：`66603f8e0aa731dbba0f4f34f1fff0b3270e0c4f10964f9a0c00b426cf8e716c`。
游戏名 WaveDog，内部独立身份 Punengbho。当前实时决策是 **8.6 Java 控制器 + JS 协议适配、运动预测与 500 Hz 本地监测**。Transformer/GRU 模型和训练代码一起保存，但本版不由它的权重控制实时动作。

## 包含

- `work/`：协议客户端、完整控制与发包链、Java 运行桥、神经网络/训练代码、接入插件源码、竞技场入口、数据记录、构建和部署工具、回归测试。
- `artifacts/plugins/`：当前服务器自有接入插件的准确 JAR，包括 PunengbhoProtocolCore、命令与竞技场入口。
- `artifacts/legacy86-classes/`：实际加载的四个 Java 类；`artifacts/reference86/`：准确的 8.6 参考 JAR 和战术文件。
- `artifacts/independent-model/`：当前独立 Transformer/GRU 检查点元数据；参数/优化器二进制仅保存在完整 Git bundle 和原开发目录中，不在此源码 ZIP 中。
- `artifacts/config/`：控制模式和弓弩校准；`docs/`：加载哈希、插件版本锁与依赖要求。
- `SOURCE_MANIFEST.json`：所有上述文件的 SHA256；`tools/verify_snapshot.py`：离线核对工具。

## 恢复和运行边界

这是机器人系统备份，**不是整台服务器一键启动包**。不包含世界、玩家数据库、密码/控制令牌、录像、旧模型、node_modules、Java/Node/Python 本体和 1 GB 的 Qwen GGUF。历史模型原件仍留在开发工作区。

在原部署路径恢复时，把 `work/` 还原到工作区；将四个 Java 类放回 `work/legacy86-reference/classes/local/pvpbot/ai/`；参考文件放回 `outputs/legacy86-hop-neural-20261118/reference/`；检查点放回 `work/wavedog-punengbho/model/`；配置分别放到独立身份目录及其 `runtime/`。将自有插件 JAR 放到服务器 `plugins/`。先让机器人退出，再替换；不要在对局中覆盖。

Node 依赖在 `work/pvp-player-client`、`work/pvp-dual-brain` 分别执行 `npm ci`。Java 21 / Paper / ViaVersion / AuthMe 等第三方环境按 `docs/` 配置。AuthMe 的机器人账号须自行注册/设置，与新建 `work/wavedog-protocol/runtime/auth.json` 的 password 一致；控制令牌由插件启动时重新生成，不从别的服务器复制。

`work/legacy86-reference/launch.json` 是本地配置，按 Java 路径、classes、参考 JAR、Gson JAR 和战术文件重新生成；参考文件的锁定哈希见 `docs/loaded-controller.json`。原构建/部署工具保留原开发机路径；搬到其他路径时须先配置路径和端口。Qwen 仅用于异步复盘，要恢复此服务需另装 `runtime-requirements.json` 标明的模型及 llama-server。

可用 `python tools/verify_snapshot.py` 检查备份。原环境配置恢复后，用 `work/wavedog-punengbho/start-client.py` 启动协议客户端。独立神经服务使用 `start-service.py`，本次冻结的模式仍是 legacy86。对战命令 `/wavedog duel 玩家名`。

## Git 备份

便携单文件：`WaveDog Axe PvP.bundle`。恢复仓库：

```powershell
git clone "WaveDog Axe PvP.bundle" wavedog
cd wavedog
python tools/verify_snapshot.py
```

本地标签 `wavedog-axe-pvp` 固定本次版本。后续修改继续提交到本仓库；用户再次要求备份时，验证新 bundle 后替换同名文件，只保留一份交付文件。没有配置远程仓库或上传。

500 Hz 是本地监测目标，不代表 500 次服务器新观测；没有实战零失误保证。旧脚本和旧文档用于保留研发信息，实际运行版本以本 README 和加载清单为准。

## 本源码 ZIP 与完整 Git 备份

此目录可像之前的源码包一样浏览和上传到 GitHub。保留全套接入/控制源码与小型参考/插件文件，单文件均低于网页上传上限。独立模型的 40 MB 二进制没有放入此 ZIP；如要完整恢复本次机器人快照，使用旁边的 `WaveDog Axe PvP.bundle`，其中已经包含模型。
