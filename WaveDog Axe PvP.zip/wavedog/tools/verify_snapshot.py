from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf8'))
for row in m['files']:
    p=root/row['path']
    if not p.is_file() or p.stat().st_size!=row['bytes']:
        raise SystemExit('Missing/size mismatch: '+row['path'])
    with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
    if digest!=row['sha256']:raise SystemExit('Hash mismatch: '+row['path'])
loaded=json.loads((root/'docs/loaded-controller.json').read_text())
for name,digest in loaded['sourceSha256'].items():
    if hashlib.sha256((root/'work/pvp-player-client'/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Loaded controller mismatch: '+name)
for name,digest in loaded['legacyRuntime']['classSha256'].items():
    if hashlib.sha256((root/'artifacts/legacy86-classes'/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Loaded Java class mismatch: '+name)
model=root/'artifacts/independent-model'
c=json.loads((model/'checkpoint.json').read_text())
if (model/c['binary']).is_file() and hashlib.sha256((model/c['binary']).read_bytes()).hexdigest()!=c['sha256']:
    raise SystemExit('Checkpoint mismatch')
print(json.dumps({'verified':True,'files':len(m['files']),'bytes':sum(r['bytes'] for r in m['files']),
    'controllerCode':loaded['controllerCode'],'classes':len(loaded['legacyRuntime']['classSha256']),
    'currentCheckpointVerified':(model/c['binary']).is_file(),'fullServer':False}))
