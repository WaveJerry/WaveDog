package local.pvpbot.sense;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Isolated interface doubles; does not create a Minecraft server or network connection. */
public final class SenseCheck {
    private static int tick;
    private static World world;
    private static Player observer;
    private static final List<Arrow> arrows=new ArrayList<>();
    private static boolean wall;
    private static final UUID WORLD=UUID.randomUUID(), PLAYER=UUID.randomUUID();

    private static void check(boolean ok,String message) { if(!ok)throw new AssertionError(message); }
    private static Object primitive(Class<?> type) {
        if(!type.isPrimitive())return null;
        if(type==boolean.class)return false;
        if(type==int.class)return 0;
        if(type==long.class)return 0L;
        if(type==double.class)return 0d;
        if(type==float.class)return 0f;
        if(type==short.class)return (short)0;
        if(type==byte.class)return (byte)0;
        if(type==char.class)return (char)0;
        return null;
    }
    private static final class Arrow {
        final UUID uuid=UUID.randomUUID();final int id;final AbstractArrow entity;
        Vector position,velocity;boolean visible=true,self;int reads,locations;
        Arrow(int id,Vector position,Vector velocity) {
            this.id=id;this.position=position;this.velocity=velocity;
            entity=(AbstractArrow)Proxy.newProxyInstance(SenseCheck.class.getClassLoader(),new Class<?>[]{AbstractArrow.class},
                (proxy,method,args)->switch(method.getName()) {
                    case "getUniqueId"->uuid;
                    case "getEntityId"->id;
                    case "getLocation"->{
                        if(!visible)throw new AssertionError("unseen location read");
                        locations++;yield new Location(world,this.position.getX(),this.position.getY(),this.position.getZ());
                    }
                    case "getVelocity"->{
                        if(!visible)throw new AssertionError("unseen velocity read");
                        reads++;yield this.velocity.clone();
                    }
                    case "hasGravity"->true;
                    case "getPierceLevel"->0;
                    case "getShooter"->self?observer:null;
                    case "equals"->proxy==args[0];
                    case "hashCode"->System.identityHashCode(proxy);
                    case "toString"->"ArrowDouble";
                    default->primitive(method.getReturnType());
                });
        }
    }

    private static void setup() {
        Server server=(Server)Proxy.newProxyInstance(SenseCheck.class.getClassLoader(),new Class<?>[]{Server.class},
            (proxy,method,args)->switch(method.getName()) {
                case "isPrimaryThread"->true;
                case "getCurrentTick"->tick;
                case "getLogger"->Logger.getLogger("ArrowSenseCheck");
                case "getName","getVersion","getBukkitVersion"->"ArrowSense isolated check";
                default->primitive(method.getReturnType());
            });
        try {
            var serverField=Bukkit.class.getDeclaredField("server");
            serverField.setAccessible(true);serverField.set(null,server);
        } catch(ReflectiveOperationException error) { throw new AssertionError(error); }
        world=(World)Proxy.newProxyInstance(SenseCheck.class.getClassLoader(),new Class<?>[]{World.class},
            (proxy,method,args)->switch(method.getName()) {
                case "getUID"->WORLD;
                case "getNearbyEntities"->arrows.stream().map(a->a.entity).toList();
                case "isChunkLoaded"->true;
                case "rayTraceBlocks"->{
                    if(!wall)yield null;
                    Location origin=(Location)args[0];Vector direction=((Vector)args[1]).clone().normalize();
                    double distance=(double)args[2];
                    double t=Math.abs(direction.getX())<1e-10?Double.POSITIVE_INFINITY:(1-origin.getX())/direction.getX();
                    yield t>=0 && t<=distance?new RayTraceResult(origin.toVector().add(direction.multiply(t))):null;
                }
                case "equals"->proxy==args[0];
                case "hashCode"->System.identityHashCode(proxy);
                case "toString"->"WorldDouble";
                default->primitive(method.getReturnType());
            });
        observer=(Player)Proxy.newProxyInstance(SenseCheck.class.getClassLoader(),new Class<?>[]{Player.class},
            (proxy,method,args)->switch(method.getName()) {
                case "getUniqueId"->PLAYER;
                case "getWorld"->world;
                case "isOnline"->true;
                case "getLocation"->new Location(world,0,0,0);
                case "getEyeLocation"->new Location(world,0,1.62,0);
                case "getVelocity"->new Vector();
                case "canSee","hasLineOfSight"->arrows.stream().filter(a->a.entity==args[0]).findFirst().orElseThrow().visible;
                case "equals"->proxy==args[0];
                case "hashCode"->System.identityHashCode(proxy);
                case "toString"->"ObserverDouble";
                default->primitive(method.getReturnType());
            });
    }

    public static void main(String[] args) {
        setup();
        DefaultArrowSense sense=new DefaultArrowSense();
        Arrow arrow=new Arrow(1,new Vector(0,1,8),new Vector(0,0,-1));arrows.add(arrow);
        var first=sense.observe(observer);
        check(first.visibleCount()==1 && first.predictedCount()==0,"current visibility counts");
        check(first.arrows().get(0).path().size()==25,"24 predicted ticks plus initial point");
        var step=first.arrows().get(0).path().get(2);
        check(Math.abs(step.z()-6.01)<1e-9 && Math.abs(step.y()-.95)<1e-9,"drag and gravity order");
        sense.observe(observer);check(arrow.reads==1,"same tick cache avoids duplicate reads");
        arrow.visible=false;arrow.position=new Vector(200,100,200);arrow.velocity=new Vector(30,30,30);
        tick=1;var remembered=sense.observe(observer);
        check(remembered.predictedCount()==1 && remembered.arrows().get(0).seenAge()==1,"brief memory is identified");
        check(remembered.arrows().get(0).z()==7 && remembered.arrows().get(0).vz()==-.99,"memory ignores real hidden state");
        check(arrow.reads==1 && arrow.locations==1,"hidden entity position/velocity never reread");
        tick=7;check(sense.observe(observer).arrows().isEmpty(),"memory expires after six ticks");
        System.out.println("PASS current visibility, same-tick cache, physical prediction, no unseen entity refresh, memory expiry");

        arrows.clear();sense.clear();tick=20;
        Arrow behind=new Arrow(2,new Vector(0,1,-5),new Vector(0,0,1));arrows.add(behind);
        check(sense.observe(observer).visibleCount()==1 && behind.reads==1,"360-degree visible rear arrow is sampled without turning");
        arrows.clear();sense.clear();tick++;
        Arrow own=new Arrow(3,new Vector(0,1,2),new Vector(0,0,1));own.self=true;arrows.add(own);
        check(sense.observe(observer).arrows().isEmpty(),"fresh self arrow moving away is ignored");
        own.velocity=new Vector(0,0,-1);tick++;
        check(sense.observe(observer).visibleCount()==1,"returning self arrow remains observable");
        sense.forgetArrow(own.uuid);own.visible=false;tick++;
        check(sense.observe(observer).arrows().isEmpty(),"known hit removes stale memory");
        System.out.println("PASS 360-degree rear sensing, outgoing/returning self arrows, known-hit memory cleanup");

        arrows.clear();sense.clear();tick=40;wall=true;
        Arrow sideways=new Arrow(4,new Vector(0,1,8),new Vector(.5,0,-1));arrows.add(sideways);
        var clipped=sense.observe(observer).arrows().get(0);
        check(clipped.path().size()<25,"static wall truncates trajectory");
        check(Math.abs(clipped.path().getLast().x()-1)<1e-9,"visible collision face reports intersection");
        try { clipped.path().add(new ArrowSenseService.Point(0,0,0));throw new AssertionError("mutable path"); }
        catch(UnsupportedOperationException expected) {}
        wall=false;arrows.clear();sense.clear();tick=50;
        for(int i=0;i<20;i++)arrows.add(new Arrow(100+i,new Vector(i*.1,1,8),new Vector(0,0,-1)));
        var capped=sense.observe(observer);
        check(capped.arrows().size()==12 && capped.visibleCount()+capped.predictedCount()==12,"returned sample cap and counts");
        System.out.println("PASS static geometry clipping, immutable paths, twelve-arrow cap");
    }
}
