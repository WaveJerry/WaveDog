"""Run observer/arrow interface doubles in an isolated JVM, never a server."""
from pathlib import Path
import os
import subprocess

base = Path(__file__).resolve().parent
server = Path(r'D:\Walt Disney\Minecraft-1.21.1-Server')
java = server / 'runtime/java21/bin'
classes = base / 'testclasses'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, sorted((server / 'libraries').rglob('*.jar'))))
arguments = ['-encoding', 'UTF-8', '--release', '21', '-proc:none', '-cp', classpath, '-d', 'testclasses',
             *map(str, sorted((base / 'src').rglob('*.java'))), 'SenseCheck.java']
argfile = base / 'compile-check.args'
argfile.write_text('\n'.join('"' + str(a).replace('\\', '/') + '"' for a in arguments), encoding='utf-8')
subprocess.run([java / 'javac.exe', '@' + argfile.name], check=True, cwd=base)
argfile = base / 'run-check.args'
argfile.write_text('\n'.join('"' + str(a).replace('\\', '/') + '"' for a in
                           ['-Xmx128m', '-cp', 'testclasses' + os.pathsep + classpath, 'local.pvpbot.sense.SenseCheck']), encoding='utf-8')
subprocess.run([java / 'java.exe', '@' + argfile.name], check=True, cwd=base)
