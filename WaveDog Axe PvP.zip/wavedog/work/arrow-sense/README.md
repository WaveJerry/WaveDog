# ArrowSense 1.1.0

Minecraft Java / Paper 1.21.1 的独立只读感知插件。只提供箭的位置样本、速度和弹道预测，不移动玩家，不改箭、伤害、属性、学习模型或网络包，不启动额外进程。

使用同一 Java 21 构建：`E:\python.exe -X utf8 work\arrow-sense\build.py`，产物为本目录 `ArrowSense.jar`。调用插件应在 plugin.yml 声明 `depend: [ArrowSense]` 并编译依赖该 JAR。

```java
import local.pvpbot.sense.ArrowSenseService;
ArrowSenseService sense = Bukkit.getServicesManager().load(ArrowSenseService.class);
ArrowSenseService.Snapshot snapshot = sense.observe(bot); // 仅服务端主线程
```

- 当前样本限观察者 48×32×48 的半径范围，周围360°采样，仍须通过实体可见性和直接方块视线；通过可见性门控后才读取箭的速度、重力、穿透和介质。候选位置只用于可见性判断，落选位置不进入记忆。背后可见箭不再要求先转头，墙后箭不会因此可见。
- 最多返回 12 支，优先预计经过观察者附近的箭，再按逼近距离排序。自身刚射出、离体不满 4 格且远离的箭被过滤；返程箭保留。静止/已插地的可见箭不作为飞行威胁。
- `seenAge=0` 为当前可见；`seenAge=1..6` 仅由最后一次可见样本按重力/阻力外推，置信度随时间下降。不可见时不会查询实体最新位置、速度、生死或其他玩家状态。超过六刻或已不构成合理威胁的记忆不返回。
- `path` 包含当前估计点与最多 24 个未来 tick 点：先位移，后施加 .99 空气阻力 / .6 水中阻力与 .05 重力。未来介质和动态碰撞仍有不确定性，调用方应每刻重观测，不能把预测当作命中保证。
- 轨迹以已加载区块的静态方块碰撞射线截断。可见命中面可返回交点；不可见命中面仅停止预测，不向调用者提供其精确坐标。不会为预测主动加载区块。
- `visibleCount + predictedCount == arrows.size()`；predictedCount 特指短时记忆样本数量。快照和轨迹列表不可修改。
- 已知的非穿透实体命中、方块命中会清除该箭记忆；退出或换世界会清除观察者记忆。每观察者同刻缓存一次快照。

需要放入服务端 plugins 的是此插件和调用插件；本构建脚本仅在工作目录生成文件，不会安装、重启或连接服务器。
