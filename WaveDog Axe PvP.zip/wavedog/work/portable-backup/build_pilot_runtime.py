"""Allow-listed xie01 runtime. Does not remove or alter the live installation."""
from pathlib import Path
import hashlib, json, os, re, shutil, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT/'outputs/xie01'
DEST = ROOT/'outputs/xie01-portable'
HERE = Path(__file__).parent
CAPTURE = SOURCE/'snapshot-models/controller-source'

def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def main():
    if (DEST/'BACKUP_READY.json').exists(): raise RuntimeError('Completed package is immutable')
    DEST.mkdir(exist_ok=True)
    (DEST/'INCOMPLETE').write_text('Compact runtime assembly / validation pending.\n')
    jobs = {}
    def add(src, rel):
        src=Path(src)
        if not src.is_file(): raise FileNotFoundError(src)
        jobs[str(rel).replace('\\','/')]=src
    def tree(src, rel, skip=None):
        src=Path(src)
        for current, dirs, files in os.walk(src):
            dirs[:]=[d for d in dirs if not (Path(current)/d).is_junction()
                     and not (Path(current)/d).is_symlink()
                     and not (skip and skip((Path(current)/d).relative_to(src), True))]
            for name in files:
                p=Path(current)/name;r=p.relative_to(src)
                if p.is_symlink() or (skip and skip(r,False)): continue
                add(p,Path(rel)/r)
    def server_skip(p, directory):
        if p.parts[0] in {'backups','logs'}: return True
        if directory and p.name in {'.paper-remapped','cache','diagnostics','archived-learning','reviews'}: return True
        if directory and (p.name.startswith('models-') or p.name in {'gru'}): return True
        if not directory and (p.name=='session.lock' or p.suffix in {'.log','.jsonl','.csv','.lck'}): return True
        return False
    tree(SOURCE/'server','server',server_skip)
    # Paper's original server cache is required for offline bootstrap.
    tree(SOURCE/'server/cache','server/cache')
    # Pinned running source takes priority over unfinished workspace edits.
    sources={}
    for folder in ['pvp-player-client','pvp-dual-brain','pvp-dual-brain/punengbho']:
        for base in [ROOT/'work'/folder,CAPTURE/folder]:
            if base.exists():
                for p in base.iterdir():
                    if p.is_file() and p.suffix in {'.js','.cjs','.mjs','.json'}:
                        sources[(Path(folder)/p.name).as_posix()]=p
    loaded=json.loads((SOURCE/'snapshot-models/wavedog-punengbho-loaded.json').read_text())
    status=json.loads((ROOT/'work/wavedog-punengbho/runtime/model-status.json').read_text())
    for base,hashes in [('pvp-player-client',loaded['sourceSha256']),
                        ('pvp-dual-brain/punengbho',status['runtimeSourceSha256'])]:
        for name,digest in hashes.items():
            key=Path(os.path.normpath(str(Path(base)/name))).as_posix()
            if sha(sources[key])!=digest: raise RuntimeError('Not the loaded source: '+key)
    pending=['pvp-player-client/protocol-punengbho.js','pvp-dual-brain/punengbho/dual-service.js']
    pending += ['pvp-player-client/'+n for n in loaded['sourceSha256']]
    pending += [Path(os.path.normpath('pvp-dual-brain/punengbho/'+n)).as_posix()
                for n in status['runtimeSourceSha256']]
    visited=set()
    while pending:
        key=pending.pop()
        if key in visited: continue
        visited.add(key);p=sources[key];add(p,'workspace/work/'+key)
        # Covers require(), static imports, Worker/new URL(), and hash lists.
        for value in re.findall(r"['\"]([^'\"\r\n]+)['\"]",p.read_text(encoding='utf8')):
            if not (value.startswith('.') or value.endswith(('.js','.cjs','.mjs'))): continue
            rel=Path(os.path.normpath(str(Path(key).parent/value))).as_posix()
            for candidate in [rel,rel+'.js',rel+'/index.js']:
                if candidate in sources: pending.append(candidate);break
    for folder in ['pvp-player-client','pvp-dual-brain']:
        add(ROOT/'work'/folder/'package.json','workspace/work/'+folder+'/package.json')
        tree(ROOT/'work'/folder/'node_modules','workspace/work/'+folder+'/node_modules')
    tree(ROOT/'work/pvp-player-client/bridge-classes','workspace/work/pvp-player-client/bridge-classes')
    tree(ROOT/'work/pvp-neural-lab/classes','workspace/work/pvp-neural-lab/classes')
    model=SOURCE/'snapshot-models/independent'
    manifest=json.loads((model/'checkpoint.json').read_text())
    if sha(model/manifest['binary'])!=manifest['sha256']: raise RuntimeError('Invalid frozen model')
    for name in ['checkpoint.json',manifest['binary']]:
        add(model/name,'workspace/work/wavedog-punengbho/model/'+name)
    coach=ROOT/'work/wavedog-punengbho/model/coach'
    for name in ['shared-lessons.jsonl','quality-flags.jsonl','player-experience.jsonl','operator-critical-defense.json']:
        if (coach/name).exists(): add(coach/name,'workspace/work/wavedog-punengbho/model/coach/'+name)
    for name in ['auth.json','ranged-calibration.json']:
        p=ROOT/'work/wavedog-punengbho/runtime'/name
        if p.exists():add(p,'workspace/work/wavedog-punengbho/runtime/'+name)
    for name in ['client-control.json','fit-ranged-calibration.py']:
        add(ROOT/'work/wavedog-punengbho'/name,'workspace/work/wavedog-punengbho/'+name)
    qwen=ROOT/'work/pvp-neural-lab/model-runtime'
    for p in qwen.iterdir():
        if p.is_file() and (p.suffix=='.dll' or p.name in {'llama-server.exe','manifest.json',
                'qwen2.5-1.5b-instruct-q4_k_m.gguf','Qwen-LICENSE','LICENSE-LLVM-OpenMP'}):
            add(p,'workspace/work/pvp-neural-lab/model-runtime/'+p.name)
    for name in ['node.exe','LICENSE']:
        if (Path('E:/node')/name).exists():add(Path('E:/node')/name,'runtime/node/'+name)
    for name in ['python.exe','pythonw.exe','python3.dll','python314.dll','vcruntime140.dll','vcruntime140_1.dll','LICENSE.txt']:
        if (Path('E:/')/name).exists():add(Path('E:/')/name,'runtime/python/'+name)
    tree(Path('E:/DLLs'),'runtime/python/DLLs')
    tree(Path('E:/Lib'),'runtime/python/Lib',lambda p,d:any(x in {'test','tests','__pycache__','site-packages',
           'idlelib','tkinter','turtledemo','ensurepip'} for x in p.parts))
    for p in Path('C:/Windows/System32').glob('*.dll'):
        if p.name.startswith(('msvcp140','vcruntime140')) or p.name in {'vccorlib140.dll','concrt140.dll','vcomp140.dll'}:
            add(p,'runtime/system/'+p.name)
    for name,target in [('launch_pilot.py','launch.py'),('verify_pilot.py','verify.py'),
                        ('relocate.py','relocate.py'),('launch.py','portable_common.py')]:add(HERE/name,target)
    rows=[]
    def copy(item):
        rel,src=item;dst=DEST/rel;dst.parent.mkdir(parents=True,exist_ok=True)
        # Capture a fixed prefix of append-only teaching cards.
        size=src.stat().st_size
        with src.open('rb') as incoming,dst.open('wb') as outgoing:
            left=size
            while left:
                block=incoming.read(min(left,4*1024*1024))
                if not block:raise RuntimeError('Source shrank: '+str(src))
                outgoing.write(block);left-=len(block)
        if dst.suffix=='.jsonl':
            data=dst.read_bytes()
            if data and not data.endswith(b'\n'):dst.write_bytes(data[:data.rfind(b'\n')+1])
        return {'path':rel,'bytes':dst.stat().st_size,'sha256':sha(dst)}
    print(json.dumps({'stage':'compact-copy','plannedFiles':len(jobs),'GiB':round(sum(p.stat().st_size for p in jobs.values())/2**30,3)}),flush=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        for i,row in enumerate(pool.map(copy,jobs.items())):
            rows.append(row)
            if i%5000==0:print(json.dumps({'copied':i}),flush=True)
    (DEST/'workspace/outputs').mkdir(exist_ok=True)
    info={'label':'xie01','scope':'server-and-independent-punengbho-runtime',
          'sourceWorkspace':str(ROOT),'sourceServer':'D:/Walt Disney/Minecraft-1.21.1-Server',
          'independentModel':manifest['sha256'],'controlRegime':loaded['controlRegime'],
          'bundled':['server-worlds-and-plugins','Punengbho-mechanics','GRU-GTrXL-weights-and-Adam',
                     'Qwen-1.5B-runtime','learned-coach-cards','ranged-calibration','Java-Node-Python'],
          'excluded':['development-workspace','old-server-backups','experimental-candidates',
                      'old-WaveDog-brain','NBot-processes','Qwen-7B','historical-trajectories'],
          'originalHistoryPreserved':True,'liveServerChanged':False,
          'trainingMode':'preserved current frozen-BC acceptance mode; no claim of active PPO'}
    (DEST/'bundle-info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
    (DEST/'start.cmd').write_bytes(b'@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\n"%~dp0runtime\\python\\python.exe" -B -X utf8 "%~dp0launch.py" %*\r\nif errorlevel 1 pause\r\n')
    (DEST/'README.txt').write_text('xie01：服务器＋独立 WaveDog_Punengbho 运行包\n'
        'Windows x64：整个文件夹复制走，双击 start.cmd。默认端口25566，同端口已有服务则拒绝启动。\n'
        '启动 Minecraft、Qwen 1.5B、独立 Transformer/GRU 服务和 Punengbho 协议玩家。\n'
        '对战：/WaveDog_Punengbho duel 玩家名；停止：/WaveDog_Punengbho stop。\n'
        '控制台输入 stop 安全关闭本包启动的进程。start.cmd --check 校验文件。\n'
        '保存的是当前在服 V26 模型及原机械综合版；未加入尚未验收的修改。\n'
        '模型和 Adam 状态包含；当前仍是冻结 BC 验收配置，不能宣称自动 PPO 已开启。\n'
        '历史模型和逐帧素材留在开发工作区，本包不重复带上。新对局仍会落盘和复盘。\n'
        '未启动旧 WaveDog 和 NBot；旧地图按钮尚待后续更新，当前用上述命令。\n',encoding='utf8')
    for name in ['bundle-info.json','start.cmd','README.txt']:
        p=DEST/name;rows.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
    for row in rows:
        if sha(DEST/row['path'])!=row['sha256']:raise RuntimeError('Copy hash mismatch')
    result={'label':'xie01','files':rows,'fileCount':len(rows),'bytes':sum(r['bytes']for r in rows)}
    (DEST/'manifest.json').write_text(json.dumps(result),encoding='utf8')
    (DEST/'COPY_COMPLETE').write_text('All copied file hashes verified; startup validation pending.\n')
    print(json.dumps({'stage':'copy-complete','path':str(DEST),'GiB':round(result['bytes']/2**30,3)}),flush=True)

if __name__=='__main__':main()
