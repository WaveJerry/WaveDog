"""Verify one portable capture, launch an isolated copy, then retain one ZIP."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ctypes, hashlib, json, os, shutil, subprocess, zipfile

ROOT=Path(__file__).resolve().parents[2]
OUTPUT=(ROOT/'outputs').resolve()
BUNDLE=(OUTPUT/'.盾斧pvp无敌版-build').resolve()
ARCHIVE=OUTPUT/'盾斧pvp无敌版.zip'
PART=OUTPUT/'盾斧pvp无敌版.zip.part'

def remove_capture(path):
    path=Path(path).resolve()
    allowed={'.盾斧pvp无敌版-build','.盾斧pvp无敌版-build-启动核验'}
    if path.parent!=OUTPUT or path.name not in allowed:
        raise RuntimeError('Refusing cleanup outside exact temporary capture: '+str(path))
    info=json.loads((path/'bundle-info.json').read_text(encoding='utf8'))
    if info.get('label')!='盾斧pvp无敌版':raise RuntimeError('Temporary capture identity mismatch')
    shutil.rmtree(path)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reuse-validation',action='store_true')
    args=parser.parse_args()
    # Compression should yield CPU time to the live Minecraft server.
    ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
    if BUNDLE.parent!=OUTPUT or not (BUNDLE/'COPY_COMPLETE').is_file():
        raise RuntimeError('Wait for verified capture completion')
    if PART.exists():raise RuntimeError('Existing incomplete archive; inspect before retrying')
    python=BUNDLE/'runtime/python/python.exe'
    if args.reuse_validation:
        log=(BUNDLE/'validation-launch.log').read_text(encoding='utf8')
        if '"fullManifestVerified": true' not in log or 'ISOLATED_LAUNCH_PASS' not in log:
            raise RuntimeError('No completed verification to reuse')
        installed=json.loads((BUNDLE/'installed-controller.json').read_text(encoding='utf8'))
        for name,digest in installed['sourceSha256'].items():
            source=BUNDLE/'workspace/work/pvp-player-client'/name
            if hashlib.sha256(source.read_bytes()).hexdigest()!=digest:
                raise RuntimeError('Captured source changed since validation: '+name)
    for mode in ([] if args.reuse_validation else ['--check','--test']):
        print(json.dumps({'stage':'portable-validation','mode':mode}),flush=True)
        with (BUNDLE/'validation-launch.log').open('ab') as log:
            subprocess.run([str(python),'-B','-X','utf8',str(BUNDLE/'launch.py'),mode],
                cwd=BUNDLE,stdout=log,stderr=subprocess.STDOUT,check=True,
                creationflags=subprocess.CREATE_NO_WINDOW)
    receipt=json.loads((BUNDLE/'isolated-launch-receipt.json').read_text(encoding='utf8'))
    required=['serverStarted','qwenReady','independentBrainReady','punengbhoProtocolAndModelReady',
              'loadedPunengbhoSourcesVerified','directRuntimeVerified','noOriginalServiceStopped']
    if not all(receipt.get(k) is True for k in required):raise RuntimeError('Portable startup checks incomplete')
    info=json.loads((BUNDLE/'bundle-info.json').read_text(encoding='utf8'))
    if receipt['checkpointSha256']!=info['independentModel']:raise RuntimeError('Wrong loaded portable checkpoint')
    test=Path(receipt['testFolder']).resolve()
    if test!=BUNDLE.with_name(BUNDLE.name+'-启动核验'):raise RuntimeError('Unexpected disposable test path')
    ready={'complete':True,'label':'盾斧pvp无敌版','created':datetime.now(timezone.utc).isoformat(),
           'controllerCode':info['controllerCode'],'entry':'start.cmd','portableLaunchPassed':True,
           'mainServerStopped':False,'liveZeroCriticalsProven':False,'archive':str(ARCHIVE)}
    (BUNDLE/'BACKUP_READY.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2),encoding='utf8')
    (BUNDLE/'INCOMPLETE').unlink()
    (BUNDLE/'COPY_COMPLETE').write_text('Capture hashes and isolated relocated startup passed.\n')
    if test.exists():remove_capture(test)
    files=sorted(p for p in BUNDLE.rglob('*') if p.is_file())
    print(json.dumps({'stage':'compressing','files':len(files)}),flush=True)
    with zipfile.ZipFile(PART,'w',zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as archive:
        for index,p in enumerate(files,1):
            archive.write(p,(Path('盾斧pvp无敌版')/p.relative_to(BUNDLE)).as_posix())
            if index%5000==0:print(json.dumps({'stage':'compressed','files':index}),flush=True)
    print(json.dumps({'stage':'zip-crc-check'}),flush=True)
    with zipfile.ZipFile(PART) as archive:
        bad=archive.testzip()
        if bad:raise RuntimeError('ZIP CRC failure: '+bad)
        if len(archive.infolist())!=len(files):raise RuntimeError('ZIP file count mismatch')
        for n in ['start.cmd','BACKUP_READY.json','server/server.jar','server/world/level.dat',
                  'workspace/work/wavedog-protocol/runtime/auth.json']:
            archive.getinfo('盾斧pvp无敌版/'+n)
    with PART.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    PART.replace(ARCHIVE)
    final={**ready,'bytes':ARCHIVE.stat().st_size,'sha256':digest,'files':len(files),'zipCrcPassed':True}
    # The machine-readable receipt lives with development evidence; only the
    # single ZIP is the user's deliverable. Clean only our verified captures.
    (OUTPUT/'wavedog-performance-20261118/latest-critical/backup-receipt.json').write_text(
        json.dumps(final,ensure_ascii=False,indent=2),encoding='utf8')
    remove_capture(BUNDLE)
    print(json.dumps(final,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
