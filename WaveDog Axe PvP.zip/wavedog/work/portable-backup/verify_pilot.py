from pathlib import Path
import hashlib,json

def verify(root,full=False):
    root=Path(root)
    for name in ['server/server.jar','server/runtime/java21/bin/java.exe','server/world/level.dat',
                 'runtime/node/node.exe','runtime/python/python.exe',
                 'workspace/work/pvp-neural-lab/model-runtime/llama-server.exe',
                 'workspace/work/pvp-neural-lab/model-runtime/qwen2.5-1.5b-instruct-q4_k_m.gguf',
                 'workspace/work/pvp-player-client/node_modules/mineflayer/package.json',
                 'workspace/work/pvp-dual-brain/node_modules/@tensorflow/tfjs/package.json']:
        if not(root/name).is_file():raise FileNotFoundError(name)
    model=root/'workspace/work/wavedog-punengbho/model'
    m=json.loads((model/'checkpoint.json').read_text())
    if Path(m['binary']).name!=m['binary']:raise RuntimeError('Invalid model path')
    with (model/m['binary']).open('rb')as f:
        if hashlib.file_digest(f,'sha256').hexdigest()!=m['sha256']:raise RuntimeError('Model hash mismatch')
    if full:
        manifest=json.loads((root/'manifest.json').read_text())
        for row in manifest['files']:
            original=root/'portable-originals'/row['path']
            p=original if original.exists()else root/row['path']
            with p.open('rb')as f:
                if hashlib.file_digest(f,'sha256').hexdigest()!=row['sha256']:raise RuntimeError('Hash mismatch: '+row['path'])
    return {'requiredFiles':True,'independentModelValid':True,'fullManifestVerified':full}
