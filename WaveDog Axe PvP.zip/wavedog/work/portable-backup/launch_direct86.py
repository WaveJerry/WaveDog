"""Start only the self-contained independent Punengbho stack."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time,urllib.request
from portable_common import occupied,rcon,wait_for,model_status
from relocate_direct86 import relocate
from verify import verify

ROOT=Path(__file__).resolve().parent
PORTS={'mc':25566,'rcon':25576,'qwen':18765,'brain':18766,'independent':18776}
TEST_PORTS={'mc':25666,'rcon':25676,'qwen':18865,'brain':18866,'independent':18876}

def run(root,ports,test=False):
    for key in ['mc','rcon','qwen','independent']:
        if occupied(ports[key]):raise RuntimeError('Port occupied; existing services preserved: '+str(ports[key]))
    relocate(root,ports)
    runtime=root/'runtime';workspace=root/'workspace';node=runtime/'node/node.exe'
    java=root/'server/runtime/java21/bin/java.exe'
    logs=root/'launch-logs';logs.mkdir(exist_ok=True)
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','WAVEDOG_PYTHON':str(runtime/'python/python.exe')}
    env['PATH']=os.pathsep.join([str(runtime/'system'),str(node.parent),str(runtime/'python'),env.get('PATH','')])
    owned=[];streams=[];server=None
    def spawn(label,args,cwd,extra=None):
        out=(logs/(label+'.out.log')).open('ab');err=(logs/(label+'.err.log')).open('ab');streams.extend([out,err])
        p=subprocess.Popen([str(x)for x in args],cwd=cwd,env={**env,**(extra or {})},stdin=subprocess.PIPE,
                           stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        owned.append((label,p));return p
    try:
        server=spawn('server',[java,'-Xms256M','-Xmx'+('1G'if test else'3G'),'-jar','server.jar','--nogui'],root/'server')
        wait_for('Minecraft',lambda:occupied(ports['rcon'])and rcon(root,ports,'list'),server,180)
        rcon(root,ports,'selfplay pause')
        qdir=workspace/'work/pvp-neural-lab/model-runtime'
        qwen=spawn('qwen',[qdir/'llama-server.exe','-m',qdir/'qwen2.5-1.5b-instruct-q4_k_m.gguf',
            '--host','127.0.0.1','--port',ports['qwen'],'-t','3','-tb','3','-c','12288','-np','1',
            '--alias','wavedog-tactics','--no-webui'],qdir)
        local=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        def qready():
            with local.open('http://127.0.0.1:'+str(ports['qwen'])+'/health',timeout=2)as response:return response.status==200
        wait_for('Qwen',qready,qwen)
        checkpoint=workspace/'work/wavedog-punengbho/model/checkpoint.json'
        brain=spawn('independent',[node,workspace/'work/pvp-dual-brain/punengbho/dual-service.js',checkpoint],workspace)
        status=wait_for('Punengbho brain',lambda:model_status(ports['independent']),brain)
        expected=json.loads(checkpoint.read_text())['sha256']
        if status.get('checkpointSha256')!=expected:raise RuntimeError('Loaded different weights')
        pilot=workspace/'work/wavedog-punengbho';(pilot/'runtime').mkdir(exist_ok=True)
        mode=json.loads((pilot/'client-control.json').read_text())['mode']
        client=spawn('punengbho-client',[node,workspace/'work/pvp-player-client/protocol-punengbho.js'],workspace,
                     {'PUNENGBHO_CONTROL_MODE':mode,'PUNENGBHO_HIGH_RATE_MODE':'control'})
        ready=pilot/'runtime/client-ready.json'
        wait_for('Client source receipt',lambda:ready.exists()and json.loads(ready.read_text()).get('pid')==client.pid,client,180)
        receipt=json.loads(ready.read_text())
        for name,digest in receipt['sourceSha256'].items():
            if hashlib.sha256((workspace/'work/pvp-player-client'/name).read_bytes()).hexdigest()!=digest:
                raise RuntimeError('Loaded source mismatch: '+name)
        if receipt['controlRegime']!='original86-single-controller-with-public-threat-prediction':raise RuntimeError('Current direct-8.6 controller missing')
        def pstatus():
            reply=rcon(root,ports,'wavedog status')
            return reply if all(x in reply for x in ['协议玩家=true','模型=true'])else False
        text=wait_for('Punengbho plugin',pstatus,client)
        result={'serverStarted':True,'qwenReady':True,'independentBrainReady':True,
                'punengbhoProtocolAndModelReady':True,'loadedPunengbhoSourcesVerified':True,
                'punengbhoControlRegime':receipt['controlRegime'],'directRuntimeVerified':bool(receipt.get('legacyRuntime')),'checkpointSha256':expected,
                'noOriginalServiceStopped':True,'ports':ports,'punengbho':text,'oldBrainStarted':False}
        (root/'startup-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps(result,ensure_ascii=True),flush=True)
        if test:return result
        print('Ready: /wavedog duel PLAYER. Enter stop to save and exit.',flush=True)
        while server.poll()is None:
            try:line=input('> ')
            except EOFError:time.sleep(1);continue
            if line.strip().lower()=='stop':break
            if line.strip():print(rcon(root,ports,line))
    finally:
        for label,p in reversed(owned):
            if label!='server'and p.poll()is None:subprocess.run(['taskkill.exe','/PID',str(p.pid),'/T','/F'],capture_output=True)
        if server and server.poll()is None:
            try:rcon(root,ports,'stop');server.wait(timeout=45)
            except Exception:
                if server.poll()is None:subprocess.run(['taskkill.exe','/PID',str(server.pid),'/T','/F'],capture_output=True)
        for stream in streams:stream.close()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--test',action='store_true')
    args=parser.parse_args()
    if args.check:print(json.dumps(verify(ROOT,True)));return
    verify(ROOT)
    if args.test:
        test=ROOT.parent/(ROOT.name+'-启动核验')
        if not test.exists():shutil.copytree(ROOT,test,ignore=shutil.ignore_patterns('snapshot','launch-logs','portable-originals'))
        elif json.loads((test/'bundle-info.json').read_text())!=json.loads((ROOT/'bundle-info.json').read_text()):
            raise RuntimeError('Existing test tree belongs to another package')
        result=run(test,TEST_PORTS,True)
        result['testFolder']=str(test)
        (ROOT/'isolated-launch-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        print('ISOLATED_LAUNCH_PASS',flush=True)
    else:run(ROOT,PORTS)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Stopped.')
    except Exception as error:print('START_FAILED: '+str(error),file=sys.stderr);sys.exit(1)
