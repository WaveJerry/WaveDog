"""Capture the installed pilot and a movable server, without the development tree."""
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,os,runpy,shutil,sqlite3,sys

ROOT=Path(__file__).resolve().parents[2]
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
HERE=Path(__file__).parent
DEST=ROOT/'outputs'/('盾斧pvp无敌版-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
jobs={}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p,rel):
    p=Path(p)
    if not p.is_file():raise FileNotFoundError(p)
    jobs[Path(rel).as_posix()]=p
def tree(src,rel,skip=lambda p,d:False):
    src=Path(src)
    if not src.is_dir():raise FileNotFoundError(src)
    for base,ds,fs in os.walk(src):
        base=Path(base)
        ds[:]=[d for d in ds if not (base/d).is_symlink() and not (base/d).is_junction()
               and not skip((base/d).relative_to(src),True)]
        for n in fs:
            p=base/n;r=p.relative_to(src)
            if not p.is_symlink() and not skip(r,False):add(p,Path(rel)/r)
def copy(item):
    rel,src=item;dst=DEST/rel;dst.parent.mkdir(parents=True,exist_ok=True)
    if src.suffix=='.db':
        incoming=sqlite3.connect(src.as_uri()+'?mode=ro',uri=True)
        outgoing=sqlite3.connect(dst)
        try:incoming.backup(outgoing)
        finally:incoming.close();outgoing.close()
    else:
        # A closed prefix is consistent for append-only journals.
        size=src.stat().st_size
        with src.open('rb') as incoming,dst.open('wb') as outgoing:
            left=size
            while left:
                b=incoming.read(min(left,4*1024*1024))
                if not b:raise RuntimeError('Source changed while copying: '+str(src))
                outgoing.write(b);left-=len(b)
        if dst.suffix=='.jsonl':
            b=dst.read_bytes()
            if b and not b.endswith(b'\n'):dst.write_bytes(b[:b.rfind(b'\n')+1])
    return {'path':rel,'bytes':dst.stat().st_size,'sha256':sha(dst)}
def main():
    global DEST
    parser=argparse.ArgumentParser()
    parser.add_argument('--destination',type=Path)
    parser.add_argument('--candidate',default='latest-critical')
    args=parser.parse_args()
    if args.destination:DEST=args.destination.resolve()
    DEST.mkdir();(DEST/'INCOMPLETE').write_text('Copy and relocated startup checks pending.\n')
    print(json.dumps({'stage':'destination','path':str(DEST)},ensure_ascii=False),flush=True)
    ready=json.loads((ROOT/'work/wavedog-punengbho/runtime/client-ready.json').read_text())
    for name,digest in ready['sourceSha256'].items():
        if sha(ROOT/'work/pvp-player-client'/name)!=digest:raise RuntimeError('Installed source differs: '+name)
    # Pin executable bytes immediately, before any subsequent live changes.
    frozen=DEST/'snapshot';frozen.mkdir()
    pinned=[]
    for folder in ['pvp-player-client','pvp-dual-brain','pvp-dual-brain/punengbho']:
        for p in (ROOT/'work'/folder).iterdir():
            if p.is_file() and p.suffix in {'.js','.cjs','.mjs','.json','.py'}:
                rel=Path('workspace/work')/folder/p.name
                dest=frozen/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);pinned.append((dest,rel))
    for p in SERVER.glob('plugins/*.jar'):
        rel=Path('server/plugins')/p.name;dest=frozen/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);pinned.append((dest,rel))
    checkpoint=ROOT/'work/wavedog-punengbho/model/checkpoint.json'
    raw=checkpoint.read_bytes();model=json.loads(raw);binary=checkpoint.parent/model['binary']
    if Path(model['binary']).name!=model['binary'] or sha(binary)!=model['sha256']:raise RuntimeError('Invalid checkpoint')
    for p in [checkpoint,binary]:
        rel=Path('workspace/work/wavedog-punengbho/model')/p.name;dest=frozen/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);pinned.append((dest,rel))
    (DEST/'installed-controller.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2),encoding='utf8')
    command=runpy.run_path(str(ROOT/'work/server_control_1211.py'))['command']
    state=command('wavedog status');saves={};rows=[]
    try:
        saves['off']=command('save-off');saves['flush']=command('save-all flush')
        for name in ['world','world_nether','world_the_end']:
            tree(SERVER/name,Path('server')/name,lambda p,d:p.name=='session.lock')
        with ThreadPoolExecutor(max_workers=3) as pool:rows.extend(pool.map(copy,jobs.items()))
        jobs.clear()
    finally:
        saves['on']=command('save-on');print(json.dumps({'stage':'worlds-saved','savingRestored':True}),flush=True)
    def server_skip(p,d):
        if p.parts[0] in {'world','world_nether','world_the_end','backups','logs'}:return True
        if d and (p.name in {'.paper-remapped','backups','diagnostics','archived-learning','reviews','gru'} or p.name.startswith('models-')):return True
        return not d and (p.name=='session.lock' or p.suffix in {'.log','.jsonl','.csv','.lck','.lock','.tmp','-wal','-shm'} or p.name.endswith(('-wal','-shm')))
    tree(SERVER,'server',server_skip)
    for folder in ['pvp-player-client','pvp-dual-brain']:
        tree(ROOT/'work'/folder/'node_modules',Path('workspace/work')/folder/'node_modules',lambda p,d:p.name=='__pycache__')
    for folder in ['work/legacy86-reference/classes','work/pvp-player-client/bridge-classes','work/pvp-neural-lab/classes']:
        tree(ROOT/folder,Path('workspace')/folder)
    for name in ['launch.json','build.py']:
        add(ROOT/'work/legacy86-reference'/name,Path('workspace/work/legacy86-reference')/name)
    tree(ROOT/'work/legacy86-reference/src','workspace/work/legacy86-reference/src')
    reference=ROOT/'outputs/legacy86-hop-neural-20261118/reference'
    for name in ['PvPArenaAI.jar','test1.nn.tactics-v5.nn']:
        add(reference/name,Path('workspace/outputs/legacy86-hop-neural-20261118/reference')/name)
    coach=ROOT/'work/wavedog-punengbho/model/coach'
    for name in ['shared-lessons.jsonl','quality-flags.jsonl','player-experience.jsonl','operator-critical-defense.json']:
        if (coach/name).is_file():add(coach/name,Path('workspace/work/wavedog-punengbho/model/coach')/name)
    for name in ['client-control.json','start-client.py','start-service.py','fit-ranged-calibration.py']:
        add(ROOT/'work/wavedog-punengbho'/name,Path('workspace/work/wavedog-punengbho')/name)
    for name in ['auth.json','ranged-calibration.json']:
        add(ROOT/'work/wavedog-punengbho/runtime'/name,Path('workspace/work/wavedog-punengbho/runtime')/name)
    add(ROOT/'work/wavedog-protocol/runtime/auth.json','workspace/work/wavedog-protocol/runtime/auth.json')
    # Keep this test session's evidence; do not copy historical replay archives.
    runtime=ROOT/'work/wavedog-punengbho/runtime'
    for m in ['a1535590-0ced-499c-8a21-c5d640647684','b97f3272-4527-49f7-a5be-92783ac21165']:
        for p in runtime.glob(m+'-*'):add(p,Path('evidence')/p.name)
    candidate=ROOT/'outputs/wavedog-performance-20261118'/args.candidate
    for n in ['修复说明.md','manifest.json','install-receipt.json','critical-replay.json','stun-distances.json','offline-performance.json']:
        if (candidate/n).is_file():add(candidate/n,Path('evidence/current-candidate')/n)
    tree(candidate/'checks','evidence/current-candidate/checks')
    q=ROOT/'work/pvp-neural-lab/model-runtime'
    for p in q.iterdir():
        if p.is_file() and (p.suffix=='.dll' or p.name in {'llama-server.exe','manifest.json','qwen2.5-1.5b-instruct-q4_k_m.gguf','Qwen-LICENSE','LICENSE-LLVM-OpenMP'}):
            add(p,Path('workspace/work/pvp-neural-lab/model-runtime')/p.name)
    for name in ['node.exe','LICENSE']:
        if (Path('E:/node')/name).is_file():add(Path('E:/node')/name,Path('runtime/node')/name)
    for name in ['python.exe','pythonw.exe','python3.dll','python314.dll','vcruntime140.dll','vcruntime140_1.dll','LICENSE.txt']:
        if (Path('E:/')/name).is_file():add(Path('E:/')/name,Path('runtime/python')/name)
    tree(Path('E:/DLLs'),'runtime/python/DLLs')
    tree(Path('E:/Lib'),'runtime/python/Lib',lambda p,d:any(x in {'test','tests','__pycache__','site-packages','idlelib','tkinter','turtledemo','ensurepip'} for x in p.parts))
    for p in Path('C:/Windows/System32').glob('*.dll'):
        if p.name.startswith(('msvcp140','vcruntime140')) or p.name in {'vccorlib140.dll','concrt140.dll','vcomp140.dll'}:add(p,Path('runtime/system')/p.name)
    for src,rel in [('launch_direct86.py','launch.py'),('launch.py','portable_common.py'),('relocate.py','relocate.py'),('relocate_direct86.py','relocate_direct86.py'),('verify_direct86.py','verify.py')]:add(HERE/src,rel)
    for p,rel in pinned:add(p,rel)
    print(json.dumps({'stage':'runtime-copy','plannedFiles':len(jobs),'GiB':round(sum(p.stat().st_size for p in jobs.values())/2**30,3)}),flush=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        for i,row in enumerate(pool.map(copy,jobs.items())):
            rows.append(row)
            if i%5000==0:print(json.dumps({'stage':'copied','files':i}),flush=True)
    info={'label':'盾斧pvp无敌版','created':datetime.now().astimezone().isoformat(),'sourceWorkspace':str(ROOT),'sourceServer':str(SERVER),
          'controlRegime':ready['controlRegime'],'controllerCode':ready['controllerCode'],'independentModel':model['sha256'],'worldSave':saves,'liveStatus':state,
          'scope':'server-and-current-independent-Punengbho','oldModelArchivesPreservedAtSource':True,
          'contains':['server-worlds-and-plugins','loaded-Punengbho-sources','original86-runtime-and-teacher','current-GRU-Transformer-checkpoint-and-Adam','Qwen-1.5B','calibration-and-coach-cards','Java-Node-Python'],
          'excluded':['old-server-backups','development-workspace','old-model-archives','old-trajectories','unused-Qwen-7B','NBot-client-processes','old-WaveDog-test-client-process'],
          'neuralWeightsUsedForCurrentControl':False,'zeroSpacingFailuresVerified':False,'candidate':args.candidate}
    (DEST/'bundle-info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
    (DEST/'start.cmd').write_bytes(b'@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\n"%~dp0runtime\\python\\python.exe" -B -X utf8 "%~dp0launch.py" %*\r\nif errorlevel 1 pause\r\n')
    (DEST/'README.txt').write_text('盾斧pvp无敌版：服务器＋当前 WaveDog（原 Punengbho）完整运行包\n'
        'Windows x64：整个文件夹拿走，双击 start.cmd。无需原电脑的 Java / Node / Python 路径。\n'
        '同端口已有服务器时会拒绝启动；默认 Minecraft 25566。关闭原服或换电脑后再正常启动本包。\n'
        'start.cmd --check 校验；start.cmd --test 使用本包独立测试端口启动核验。输入 stop 安全保存关闭。\n'
        '对战：/wavedog duel 玩家名；停止：/wavedog stop。\n'
        '当前为原版8.6单控制器＋最新弓弩同步＋公开运动预测，不声称已经0失误，也不声称当前由神经权重控制。\n'
        '现有独立 Transformer/GRU 权重、优化器和 Qwen 均随包保存；神经权重未被删除。\n'
        '本包包含本轮旧观测暴击预判、低蓄力打断和绕盾打盾修复；回中心与贴脸剑斗保留。\n'
        '不重复携带旧服务器备份、全部开发实验、历史模型及旧录像；原件仍留在原工作区。\n',encoding='utf8')
    for n in ['bundle-info.json','start.cmd','README.txt','installed-controller.json']:
        p=DEST/n;rows.append({'path':n,'bytes':p.stat().st_size,'sha256':sha(p)})
    for row in rows:
        if sha(DEST/row['path'])!=row['sha256']:raise RuntimeError('Copied hash mismatch: '+row['path'])
    manifest={'files':rows,'fileCount':len(rows),'bytes':sum(x['bytes']for x in rows)}
    (DEST/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf8')
    (DEST/'COPY_COMPLETE').write_text('All files SHA256 verified; relocated startup validation pending.\n')
    # The frozen originals are already verified and retained at their final paths.
    if frozen.resolve().parent!=DEST.resolve():raise RuntimeError('Unexpected capture directory')
    shutil.rmtree(frozen)
    print(json.dumps({'stage':'copy-complete','path':str(DEST),'GiB':round(manifest['bytes']/2**30,3),'files':len(rows)},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
