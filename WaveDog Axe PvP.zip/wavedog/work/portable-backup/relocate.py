"""Relocate only executable code/configuration, never learned weights or logs."""
from pathlib import Path
import io,json,re,struct,zipfile

def rewrite_class(data,replacements):
    if data[:4]!=b'\xca\xfe\xba\xbe':return data
    n=struct.unpack_from('>H',data,8)[0];i=1;at=10;out=bytearray(data[:10])
    widths={3:4,4:4,5:8,6:8,7:2,8:2,9:4,10:4,11:4,12:4,15:3,16:2,17:4,18:4,19:2,20:2}
    while i<n:
        tag=data[at];at+=1;out.append(tag)
        if tag==1:
            length=struct.unpack_from('>H',data,at)[0];at+=2;value=data[at:at+length];at+=length
            for old,new in replacements:value=value.replace(old,new)
            if len(value)>65535:raise ValueError('Relocated class string is too long')
            out.extend(struct.pack('>H',len(value)));out.extend(value)
        else:
            width=widths[tag];out.extend(data[at:at+width]);at+=width
            if tag in(5,6):i+=1
        i+=1
    out.extend(data[at:]);return bytes(out)

def relocate(root,ports):
    root=Path(root).resolve();info=json.loads((root/'bundle-info.json').read_text(encoding='utf-8'))
    marker=root/'relocation-state.json';previous=json.loads(marker.read_text())if marker.exists()else{}
    server=(root/'server').as_posix();workspace=(root/'workspace').as_posix()
    mappings={info['sourceWorkspace']:workspace,info['sourceServer']:server,
      previous.get('workspace',''):workspace,previous.get('server',''):server,
      'E:/python.exe':(root/'runtime/python/python.exe').as_posix(),
      'E:/node/node.exe':(root/'runtime/node/node.exe').as_posix()}
    replacements=[]
    for old,new in mappings.items():
        if not old or old==new:continue
        for variant in sorted({old,old.replace('\\','/'),old.replace('/','\\'),old.replace('/','\\\\'),old.replace('\\','\\\\')},key=len,reverse=True):
            replacements.append((variant.encode(),new.encode()))
    old_ports=previous.get('ports',{'mc':25566,'qwen':18765,'brain':18766,'independent':18776})
    for key in['mc','qwen','brain','independent']:
        if old_ports[key]!=ports[key]:replacements.append((str(old_ports[key]).encode(),str(ports[key]).encode()))
    changed=[]
    def write(p,data):
        old=p.read_bytes()
        if old==data:return
        # Keep the original executable for verification/forensics. These are
        # real files, not junctions back to the active installation.
        original=root/'portable-originals'/p.relative_to(root)
        if not original.exists():original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes(old)
        p.write_bytes(data);changed.append(p.relative_to(root).as_posix())
    active=['pvp-player-client','pvp-dual-brain','wavedog-protocol','wavedog-punengbho',
      'pvp-neural-lab','pvp-train-control','wavedog-arena-entry','wavedog-command','pvp-frame-recorder']
    candidates=[]
    for folder in active:
        base=root/'workspace/work'/folder
        if not base.exists():continue
        for p in base.rglob('*'):
            rel=p.relative_to(base)
            if any(x in{'node_modules','backups','new-learning','runtime','model','models','.venv','model-runtime'}for x in rel.parts):continue
            if p.is_file()and p.suffix.lower()in{'.js','.cjs','.mjs','.py','.class','.cmd','.ps1','.properties','.yml'}:candidates.append(p)
    candidates+=list((root/'workspace/work').glob('*.py'))
    plugins=root/'server/plugins'
    candidates+=list((root/'server').glob('*.cmd'))
    candidates+=list(plugins.rglob('*.jar'))
    candidates+=list(plugins.rglob('*.yml'))
    for p in candidates:
        if p.suffix=='.jar':
            src=p.read_bytes();out=io.BytesIO();altered=False
            with zipfile.ZipFile(io.BytesIO(src))as incoming,zipfile.ZipFile(out,'w')as outgoing:
                for entry in incoming.infolist():
                    payload=incoming.read(entry)
                    if entry.filename.endswith('.class'):
                        update=rewrite_class(payload,replacements);altered|=update!=payload;payload=update
                    outgoing.writestr(entry,payload)
            if altered:write(p,out.getvalue())
        elif p.suffix=='.class':write(p,rewrite_class(p.read_bytes(),replacements))
        else:
            data=p.read_bytes()
            for old,new in replacements:data=data.replace(old,new)
            if p.suffix in{'.js','.cjs','.mjs'}:
                data=re.sub(rb"path\.join\(['\"]D:['\"],\s*['\"]Walt Disney['\"],\s*['\"]Minecraft-1\.21\.1-Server['\"]\)",
                  lambda m:json.dumps(server).encode(),data)
                # URL.pathname retains %20 / percent-encoded Chinese. The
                # original helpers happened to live in an ASCII-only folder.
                # Use Node's actual URL decoder for a movable user folder.
                data,n=re.subn(rb"(new URL\([^\r\n]*?\))\.pathname\.replace\([^\r\n]*?,\s*['\"]['\"]\)",
                    rb'portableFileURLToPath(\1)',data)
                if n and b'fileURLToPath as portableFileURLToPath'not in data:
                    data=b"import { fileURLToPath as portableFileURLToPath } from 'node:url'\n"+data
            write(p,data)
    properties=root/'server/server.properties'
    data=properties.read_text(encoding='utf-8')
    for key,value in{'server-port':ports['mc'],'rcon.port':ports['rcon'],'query.port':ports['mc'],'server-ip':''}.items():
        if re.search(r'^'+re.escape(key)+r'=',data,re.M):data=re.sub(r'^'+re.escape(key)+r'=.*$',key+'='+str(value),data,flags=re.M)
        else:data+='\n'+key+'='+str(value)+'\n'
    write(properties,data.encode())
    marker.write_text(json.dumps({'workspace':workspace,'server':server,'ports':ports,'changedFiles':changed},ensure_ascii=False,indent=2),encoding='utf-8')
    return changed
