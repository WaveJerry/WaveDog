"""Finish one new portable bundle only after hash and relocated startup checks."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, os, subprocess

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--recheck-all', action='store_true',
                        help='Repeat the full hash pass already completed by build_bundle')
    parser.add_argument('--reuse-test-tree', type=Path,
                        help='Retry a previously copied disposable test tree after checking its bundle label')
    args = parser.parse_args()
    if not args.label.isascii() or not args.label.replace('-', '').replace('_', '').isalnum():
        raise ValueError('Invalid label')
    bundle = (ROOT/'outputs'/args.label).resolve()
    if bundle.parent != (ROOT/'outputs').resolve():
        raise RuntimeError('Bundle is outside outputs')
    if (bundle/'BACKUP_READY.json').exists():
        raise RuntimeError('Do not modify a completed backup')
    if not (bundle/'COPY_COMPLETE').is_file():
        raise RuntimeError('Wait for the copy and complete hash verification')
    info = json.loads((bundle/'bundle-info.json').read_text(encoding='utf8'))
    if info['label'] != args.label:
        raise RuntimeError('Bundle label mismatch')
    python = bundle/'runtime/python/python.exe'
    test_tree = args.reuse_test_tree.resolve() if args.reuse_test_tree else None
    if test_tree:
        if not test_tree.is_relative_to(Path(os.environ['TEMP']).resolve()) \
                or not test_tree.name.startswith('WaveDog 搬移 xieyi1 '):
            raise RuntimeError('Only a disposable relocated test tree may be reused')
        if json.loads((test_tree/'bundle-info.json').read_text(encoding='utf8'))['label'] != args.label:
            raise RuntimeError('Disposable tree belongs to a different bundle')
    # COPY_COMPLETE is written only after every manifest hash passes. The
    # relocated launch checks required files/model hashes again; a second
    # scan of all 178k files is optional rather than delaying the launch test.
    for mode in (['--check'] if args.recheck_all else []) + ['--test']:
        print(json.dumps({'stage': mode, 'label': args.label}), flush=True)
        argv = [str(python), '-B', '-X', 'utf8', str(bundle/'launch.py'), mode]
        if test_tree and mode == '--test':
            code = '''import json,sys
from pathlib import Path
import launch
tree=Path(sys.argv[1])
result=launch.run(tree,launch.ROOT,launch.TEST_PORTS,True)
result['testFolder']=str(tree)
(launch.ROOT/'isolated-launch-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('ISOLATED_LAUNCH_PASS',flush=True)
'''
            argv = [str(python), '-B', '-X', 'utf8', '-c', code, str(test_tree)]
        completed = subprocess.run(argv, cwd=bundle, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, encoding='utf8', errors='replace', creationflags=subprocess.CREATE_NO_WINDOW)
        with (bundle/'validation-launch.log').open('a', encoding='utf8') as stream:
            stream.write(completed.stdout)
        print(completed.stdout[-12000:], flush=True)
        completed.check_returncode()
    receipt = json.loads((bundle/'isolated-launch-receipt.json').read_text(encoding='utf8'))
    for field in ['serverStarted', 'qwenReady', 'sharedBrainReady', 'independentBrainReady',
                  'waveDogProtocolAndModelReady', 'loadedWaveDogSourcesVerified',
                  'punengbhoProtocolAndModelReady','loadedPunengbhoSourcesVerified','noOriginalServiceStopped']:
        if receipt.get(field) is not True:
            raise RuntimeError('Startup check missing: '+field)
    if receipt['models'] != {'brain': info['mainModel'], 'independent': info['independentModel']}:
        raise RuntimeError('Started model differs from the frozen model')
    manifest = json.loads((bundle/'manifest.json').read_text(encoding='utf8'))
    ready = dict(label=args.label, complete=True, at=datetime.now(timezone.utc).isoformat(),
                 folder=str(bundle), entry='start.cmd', fileCount=manifest['fileCount'], bytes=manifest['bytes'],
                 copyManifestHashesVerified=True, isolatedRelocatedLaunchPassed=True,
                 testedOnDifferentPC=False, models=receipt['models'], mainServerStopped=False)
    temporary = bundle/'BACKUP_READY.updating.json'
    temporary.write_text(json.dumps(ready, ensure_ascii=False, indent=2), encoding='utf8')
    temporary.replace(bundle/'BACKUP_READY.json')
    (bundle/'INCOMPLETE').unlink(missing_ok=True)
    print(json.dumps(ready, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
