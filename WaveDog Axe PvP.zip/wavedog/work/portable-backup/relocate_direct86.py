"""Resolve the reference JVM's JSON paths as well as existing plugin paths."""
from pathlib import Path
import json,os
from relocate import relocate as relocate_common

def relocate(root,ports):
    root=Path(root).resolve();changed=relocate_common(root,ports)
    ref=root/'workspace/work/legacy86-reference';p=ref/'launch.json'
    cfg=json.loads(p.read_text(encoding='utf8'))
    original=root/'portable-originals'/p.relative_to(root)
    if not original.exists():original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes(p.read_bytes())
    teacher=root/'workspace/outputs/legacy86-hop-neural-20261118/reference'
    cfg['java']=str(root/'server/runtime/java21/bin/java.exe')
    cfg['classpath']=os.pathsep.join(map(str,[ref/'classes',teacher/'PvPArenaAI.jar',root/'server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
    cfg['model']=str(teacher/'test1.nn.tactics-v5.nn')
    p.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf8')
    changed.append(p.relative_to(root).as_posix())
    return changed
