"""Bundled Windows entry point. No network downloads or original install needed."""
from pathlib import Path
import argparse,json,os,shutil,socket,struct,subprocess,sys,tempfile,time,urllib.request
from relocate import relocate
from verify import verify

ROOT=Path(__file__).resolve().parent
PORTS={'mc':25566,'rcon':25576,'qwen':18765,'brain':18766,'independent':18776}
TEST_PORTS={'mc':25666,'rcon':25676,'qwen':18865,'brain':18866,'independent':18876}

def occupied(port):
    with socket.socket()as sock:sock.settimeout(.3);return sock.connect_ex(('127.0.0.1',port))==0

def rcon(root,ports,text):
    options=dict(line.split('=',1)for line in(root/'server/server.properties').read_text(encoding='utf-8').splitlines()if'='in line and not line.startswith('#'))
    def exact(sock,n):
        data=b''
        while len(data)<n:
            part=sock.recv(n-len(data))
            if not part:raise EOFError('RCON closed')
            data+=part
        return data
    def send(sock,typ,message):
        data=struct.pack('<ii',99,typ)+message.encode()+b'\0\0';sock.sendall(struct.pack('<i',len(data))+data)
    def read(sock):
        n=struct.unpack('<i',exact(sock,4))[0]
        if not 10<=n<=1048576:raise ValueError('Invalid RCON packet')
        data=exact(sock,n);return struct.unpack('<ii',data[:8]),data[8:-2].decode('utf-8','replace')
    with socket.create_connection(('127.0.0.1',ports['rcon']),timeout=5)as sock:
        send(sock,3,options['rcon.password'])
        for _ in range(4):
            head,_=read(sock)
            if head[1]==2:
                if head[0]==-1:raise PermissionError('RCON authentication failed')
                break
        send(sock,2,text)
        for _ in range(4):
            head,body=read(sock)
            if head[0]==99:return body
    raise TimeoutError('No RCON response')

def wait_for(label,predicate,process=None,timeout=120):
    start=time.monotonic();reported=-1
    while time.monotonic()-start<timeout:
        if process and process.poll()is not None:raise RuntimeError(label+' exited; inspect launch-logs')
        try:
            value=predicate()
            if value:return value
        except(OSError,ValueError,TimeoutError,EOFError):pass
        elapsed=int(time.monotonic()-start)
        if elapsed//10!=reported:reported=elapsed//10;print(label+' ... '+str(elapsed)+'s',flush=True)
        time.sleep(.5)
    raise TimeoutError(label+' readiness timeout')

def model_status(port):
    with socket.create_connection(('127.0.0.1',port),timeout=2)as sock:
        sock.sendall(b'{"command":"model_status","requestId":"portable-check"}\n')
        with sock.makefile('r',encoding='utf-8')as reader:
            for _ in range(12):
                line=reader.readline()
                if not line:return False
                row=json.loads(line)
                if row.get('event')=='model_status':return row if row.get('ready')else False
    return False

def prepare_test(root):
    test=Path(tempfile.mkdtemp(prefix='WaveDog 搬移 xieyi1 ',dir=root.parent))
    # Real independent files, never shared world files or mutable models.
    shutil.copytree(root/'server',test/'server',ignore=shutil.ignore_patterns('backups','logs','*.log','session.lock'))
    for folder in ['pvp-player-client','pvp-dual-brain','wavedog-protocol','wavedog-punengbho']:
        source=root/'workspace/work'/folder
        shutil.copytree(source,test/'workspace/work'/folder,ignore=shutil.ignore_patterns(
            'backups','new-learning','runtime','.venv','model','models','__pycache__'))
    source=root/'workspace/work/pvp-neural-lab'
    shutil.copytree(source/'classes',test/'workspace/work/pvp-neural-lab/classes')
    for folder in ['pvp-8.6-dual-fresh','wavedog-punengbho']:
        src=root/'workspace/work'/folder/'model';dst=test/'workspace/work'/folder/'model';dst.mkdir(parents=True,exist_ok=True)
        m=json.loads((src/'checkpoint.json').read_text())
        for name in ['checkpoint.json',m['binary']]:shutil.copy2(src/name,dst/name)
    history=[
      'pvp-dual-brain/models/history-44kk/recurrent-ppo.json',
      'pvp-player-client/new-learning/backups/before-hybrid-wavedog-20261112-122357/work/pvp-player-client/new-learning/models/recurrent-ppo.json',
      'pvp-player-client/new-learning/backups/before-shield-handover-20261112-162729/recurrent-ppo.json',
      'pvp-player-client/new-learning/backups/before-shared-clones-20261113-170732/models/recurrent-ppo.json']
    for rel in history:
        dst=test/'workspace/work'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'workspace/work'/rel,dst)
    auth=root/'workspace/work/pvp-player-client/.auth-selfplay.json'
    if auth.exists():shutil.copy2(auth,test/'workspace/work/pvp-player-client'/auth.name)
    for folder in['wavedog-protocol','wavedog-punengbho']:
        for name in['auth.json','ranged-calibration.json']:
            src=root/'workspace/work'/folder/'runtime'/name
            if src.exists():dst=test/'workspace/work'/folder/'runtime'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        mode=root/'workspace/work'/folder/'client-control.json'
        if mode.exists():shutil.copy2(mode,test/'workspace/work'/folder/'client-control.json')
    shutil.copy2(root/'bundle-info.json',test/'bundle-info.json')
    return test

def run(root,runtime_root,ports,test=False):
    for port in ports.values():
        if occupied(port):raise RuntimeError('Port '+str(port)+' is occupied. Existing services were preserved.')
    changed=relocate(root,ports)
    # The test tree uses the bundled runtime/model files read-only.
    runtime=runtime_root/'runtime';node=runtime/'node/node.exe'
    java=root/'server/runtime/java21/bin/java.exe';workspace=root/'workspace'
    logs=root/'launch-logs';logs.mkdir(exist_ok=True)
    environment=os.environ.copy();environment['PATH']=os.pathsep.join([
      str(runtime/'system'),str(node.parent),str(runtime/'python'),environment.get('PATH','')])
    environment['PYTHONDONTWRITEBYTECODE']='1';environment['WAVEDOG_FRESH_DUAL']='1'
    owned=[];streams=[]
    def spawn(label,args,cwd,extra_env=None):
        out=(logs/(label+'.out.log')).open('ab');err=(logs/(label+'.err.log')).open('ab');streams.extend([out,err])
        p=subprocess.Popen([str(a)for a in args],cwd=cwd,env={**environment,**(extra_env or {})},stdin=subprocess.PIPE,stdout=out,stderr=err,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));owned.append((label,p));return p
    server=None
    try:
        server=spawn('server',[java,'-Xms256M','-Xmx'+('1G'if test else'3G'),'-jar','server.jar','--nogui'],root/'server')
        wait_for('Minecraft',lambda:occupied(ports['rcon'])and rcon(root,ports,'list'),server)
        # Recreate the recorded paused state before controllers connect.
        rcon(root,ports,'selfplay pause')
        qwen_dir=runtime_root/'workspace/work/pvp-neural-lab/model-runtime'
        manifest=json.loads((qwen_dir/'manifest.json').read_text())
        model=qwen_dir/manifest.get('active_model_path','qwen2.5-1.5b-instruct-q4_k_m.gguf')
        qwen=spawn('qwen',[qwen_dir/'llama-server.exe','-m',model,'--host','127.0.0.1','--port',str(ports['qwen']),
          '-t',str(manifest.get('threads',3)),'-tb',str(manifest.get('batch_threads',3)),
          '-c',str(manifest.get('context_tokens',12288)),'-np','1','--alias','wavedog-tactics','--no-webui'],qwen_dir)
        local=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        def qwen_ready():
            with local.open('http://127.0.0.1:'+str(ports['qwen'])+'/health',timeout=2)as response:return response.status==200
        wait_for('Qwen',qwen_ready,qwen)
        services=[('brain','pvp-dual-brain/dual-service.js','pvp-8.6-dual-fresh/model/checkpoint.json',ports['brain']),
          ('independent','pvp-dual-brain/punengbho/dual-service.js','wavedog-punengbho/model/checkpoint.json',ports['independent'])]
        statuses={}
        for label,entry,checkpoint,port in services:
            proc=spawn(label,[node,workspace/'work'/entry,workspace/'work'/checkpoint],workspace)
            statuses[label]=wait_for(label,lambda port=port:model_status(port),proc)
            expected=json.loads((workspace/'work'/checkpoint).read_text())['sha256']
            if statuses[label].get('checkpointSha256')!=expected:
                raise RuntimeError(label+' loaded a different checkpoint')
        client_processes={}
        for folder,entry in[('wavedog-protocol','protocol-wavedog.js'),('wavedog-punengbho','protocol-punengbho.js')]:
            (workspace/'work'/folder/'runtime').mkdir(parents=True,exist_ok=True)
            mode_file=workspace/'work'/folder/'client-control.json'
            mode=json.loads(mode_file.read_text()).get('mode','pure') if mode_file.exists()else 'pure'
            client=spawn(folder,[node,workspace/'work/pvp-player-client'/entry],workspace,
                         {'PUNENGBHO_CONTROL_MODE':mode} if folder=='wavedog-punengbho' else None)
            client_processes[folder]=client
            (workspace/'work'/folder/'runtime/client-process.json').write_text(json.dumps({'pid':client.pid,'entry':entry}),encoding='utf-8')
        spawn('nbots',[node,workspace/'work/pvp-player-client/selfplay.js','--bots=4'],workspace)
        def bot_ready():
            reply=rcon(root,ports,'wavedog status')
            return reply if '\u534f\u8bae\u73a9\u5bb6=true'in reply and '\u6a21\u578b=true'in reply else False
        wavedog=wait_for('WaveDog',bot_ready,server)
        client_receipt=workspace/'work/wavedog-protocol/runtime/client-ready.json'
        wait_for('WaveDog source receipt',lambda:client_receipt.exists(),server)
        import hashlib
        receipt=json.loads(client_receipt.read_text())
        for filename,sha in receipt.get('sourceSha256',{}).items():
            payload=(workspace/'work/pvp-player-client'/filename).read_bytes()
            if hashlib.sha256(payload).hexdigest()!=sha:raise RuntimeError('Loaded WaveDog source mismatch: '+filename)
        if not receipt.get('sourceSha256'):raise RuntimeError('No loaded WaveDog source hashes')
        pilot_status=wait_for('Punengbho',lambda:rcon(root,ports,'wavedog_punengbho status')
            if all(s in rcon(root,ports,'wavedog_punengbho status') for s in ['协议玩家=true','模型=true'])else False,server)
        pilot_file=workspace/'work/wavedog-punengbho/runtime/client-ready.json'
        wait_for('Punengbho loaded source',lambda:pilot_file.exists()
                 and json.loads(pilot_file.read_text()).get('pid')==client_processes['wavedog-punengbho'].pid,server)
        pilot_receipt=json.loads(pilot_file.read_text())
        pilot_mode_file=workspace/'work/wavedog-punengbho/client-control.json'
        pilot_mode=json.loads(pilot_mode_file.read_text()).get('mode','pure')if pilot_mode_file.exists()else 'pure'
        expected='pilot-mechanical-shield-neural-melee'if pilot_mode=='hybrid'else 'pure-model-all-input'
        if pilot_receipt.get('controlRegime')!=expected:raise RuntimeError('Punengbho composition differs from backup')
        if not pilot_receipt.get('sourceSha256'):raise RuntimeError('No Punengbho source receipt')
        for filename,sha in pilot_receipt['sourceSha256'].items():
            if hashlib.sha256((workspace/'work/pvp-player-client'/filename).read_bytes()).hexdigest()!=sha:
                raise RuntimeError('Loaded Punengbho source mismatch: '+filename)
        result={'serverStarted':True,'qwenReady':True,'sharedBrainReady':True,'independentBrainReady':True,
          'waveDogProtocolAndModelReady':True,'loadedWaveDogSourcesVerified':True,
          'punengbhoProtocolAndModelReady':True,'loadedPunengbhoSourcesVerified':True,
          'punengbhoControlRegime':expected,'punengbho':pilot_status,
          'ports':ports,'models':{k:v.get('checkpointSha256')for k,v in statuses.items()},
          'selfplay':rcon(root,ports,'selfplay status'),'wavedog':wavedog,'relocatedFiles':len(changed),
          'noOriginalServiceStopped':True}
        (root/'startup-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=True),flush=True)
        if test:return result
        print('Server and WaveDog ready. Enter server commands here; stop exits safely. Logs: '+str(logs),flush=True)
        while server.poll()is None:
            try:line=input('> ')
            except EOFError:time.sleep(1);continue
            if line.strip().lower()=='stop':break
            if line.strip():print(rcon(root,ports,line))
    finally:
        for label,process in reversed(owned):
            if label=='server':continue
            if process.poll()is None:
                subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],capture_output=True)
        if server and server.poll()is None:
            try:rcon(root,ports,'stop');server.wait(timeout=45)
            except(Exception,):
                if server.poll()is None:subprocess.run(['taskkill.exe','/PID',str(server.pid),'/T','/F'],capture_output=True)
        for f in streams:f.close()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--test',action='store_true')
    args=parser.parse_args()
    if args.check:print(json.dumps(verify(ROOT,True)));return
    verify(ROOT,False)
    if args.test:
        test=prepare_test(ROOT)
        print(json.dumps({'stage':'isolated-launch','testFolder':str(test)}),flush=True)
        result=run(test,ROOT,TEST_PORTS,True)
        result['testFolder']=str(test)
        (ROOT/'isolated-launch-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print('ISOLATED_LAUNCH_PASS',flush=True)
    else:run(ROOT,ROOT,PORTS)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Stopped.')
    except Exception as error:print('START_FAILED: '+str(error),file=sys.stderr);sys.exit(1)
