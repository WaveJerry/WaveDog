from pathlib import Path
import hashlib,json

def sha(p):
    with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify(root,full=False):
    root=Path(root)
    for n in ['server/server.jar','server/runtime/java21/bin/java.exe','server/world/level.dat',
              'runtime/node/node.exe','runtime/python/python.exe',
              'workspace/work/pvp-neural-lab/model-runtime/llama-server.exe',
              'workspace/work/pvp-neural-lab/model-runtime/qwen2.5-1.5b-instruct-q4_k_m.gguf',
              'workspace/work/pvp-player-client/node_modules/mineflayer/package.json',
              'workspace/work/pvp-dual-brain/node_modules/@tensorflow/tfjs/package.json',
              'workspace/work/legacy86-reference/classes/local/pvpbot/ai/Legacy86Runtime.class']:
        if not(root/n).is_file():raise FileNotFoundError(n)
    model=root/'workspace/work/wavedog-punengbho/model';m=json.loads((model/'checkpoint.json').read_text())
    if Path(m['binary']).name!=m['binary'] or sha(model/m['binary'])!=m['sha256']:raise RuntimeError('Model mismatch')
    cfg=json.loads((root/'workspace/work/legacy86-reference/launch.json').read_text())
    ref=root/'workspace/outputs/legacy86-hop-neural-20261118/reference'
    if sha(ref/'PvPArenaAI.jar')!=cfg['originalJarSha256'] or sha(ref/'test1.nn.tactics-v5.nn')!=cfg['modelSha256']:
        raise RuntimeError('Frozen 8.6 teacher mismatch')
    if full:
        for row in json.loads((root/'manifest.json').read_text(encoding='utf8'))['files']:
            old=root/'portable-originals'/row['path'];p=old if old.is_file() else root/row['path']
            if sha(p)!=row['sha256']:raise RuntimeError('Hash mismatch: '+row['path'])
    return {'requiredFiles':True,'independentModelValid':True,'original86TeacherValid':True,'fullManifestVerified':full}
