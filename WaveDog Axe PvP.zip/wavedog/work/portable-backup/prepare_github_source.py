"""Export a reviewable source snapshot without private server or model files."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / 'outputs/盾斧pvp无敌版.zip'
DEST = ROOT / 'outputs/wavedog-github'
OUTPUT = ROOT / 'outputs/wavedog-github-source.zip'
PREFIXES = (
    'workspace/work/pvp-player-client/',
    'workspace/work/pvp-dual-brain/',
    'workspace/work/legacy86-reference/',
    'workspace/work/wavedog-punengbho/',
)
SECRET_KEY = re.compile(r'password|passwd|token|secret|api.?key', re.I)
LITERAL_SECRET = re.compile(
    r'''(?i)(?:password|passwd|rconpass|rcon_pass|accessToken|clientToken|api_key|apiKey|authorization|secret)\s*[=:]\s*['"][^'"]{4,}['"]'''
    r'|(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]+'
    r'|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY'
    r'|https?://[^\s/@:]+:[^\s/@]+@')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def credentials(obj):
    found = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            if SECRET_KEY.search(key) and isinstance(value, str) and len(value) >= 8:
                found.add(value)
            found.update(credentials(value))
    elif isinstance(obj, list):
        for value in obj:
            found.update(credentials(value))
    return found


def main():
    if DEST.exists() or OUTPUT.exists():
        raise RuntimeError('Source export already exists; preserve it for review.')
    files = {}
    secrets = set()
    with zipfile.ZipFile(ARCHIVE) as source:
        info = json.loads(source.read('盾斧pvp无敌版/bundle-info.json'))
        for entry in source.infolist():
            rel = PurePosixPath(entry.filename)
            if rel.name.endswith('.json') and ('auth' in rel.name.lower()):
                try:
                    secrets.update(credentials(json.loads(source.read(entry))))
                except (ValueError, UnicodeError):
                    pass
            if rel.name.endswith('token.txt'):
                value = source.read(entry).decode('utf8').strip()
                if len(value) >= 8:
                    secrets.add(value)
            if rel.name == 'server.properties':
                for line in source.read(entry).decode('utf8').splitlines():
                    if '=' in line:
                        key, value = line.split('=', 1)
                        if SECRET_KEY.search(key) and len(value.strip()) >= 8:
                            secrets.add(value.strip())
        for entry in source.infolist():
            rel = PurePosixPath(*PurePosixPath(entry.filename).parts[1:])
            if not str(rel).startswith(PREFIXES):
                continue
            if any(p in {'node_modules', 'runtime', 'model', 'classes', '__pycache__'} for p in rel.parts):
                continue
            if rel.suffix not in {'.js', '.cjs', '.mjs', '.py', '.java'} and rel.name not in {'package.json', 'package-lock.json'}:
                continue
            files[str(PurePosixPath(*rel.parts[1:]))] = source.read(entry)
        fixture = source.read('盾斧pvp无敌版/evidence/current-candidate/checks/fixtures/critical-20261119.json').decode('utf8')
        fixture = fixture.replace('WaveJerry', 'fixture-player-a')
        fixture = re.sub(r'\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b',
                         '00000000-0000-4000-8000-000000000001', fixture)
        files['work/pvp-player-client/fixtures/critical-20261119.json'] = fixture.encode('utf8')

    files['README.md'] = ('''# wavedog 我的世界pvp机器人

WaveDog 的 Minecraft 盾斧 PVP 实验项目：协议玩家、战斗观测与预测、8.6 控制器适配，以及 Transformer/GRU 训练和评估工具。

## 这份快照

本仓库导出自已校验的「盾斧pvp无敌版」运行备份，控制器版本为 `CONTROLLER`。它与该备份版本对应，不包含之后的落地交接修复。

本版本实战执行的是 **8.6 Java 控制逻辑 + JS 协议适配和公开威胁预测**；保存了神经模型相关源码，当前执行路径没有改成 Transformer 权重决策。500 Hz 是本地监测目标，不代表服务器每秒有 500 次新状态，也没有实战零失误保证。

## 目录

- `work/pvp-player-client/`：协议玩家、运动监测、威胁预测、发包节流、执行与回归测试。
- `work/legacy86-reference/src/`：原版 8.6 Java 运行桥接源码。
- `work/pvp-dual-brain/`：Transformer/GRU 模型、训练、评估与复盘工具。
- `work/wavedog-punengbho/`：独立模型身份的服务启动辅助脚本；游戏名为 WaveDog。
- `docs/DISTRIBUTION.md`：源码、模型和可启动运行包的发布方法。
- `SOURCE_MANIFEST.json`：所选源码的 SHA256 清单。

## 开发和运行

Node 依赖由两份 `package-lock.json` 固定版本，可分别在 `work/pvp-player-client` 和 `work/pvp-dual-brain` 执行 `npm ci` 安装。

这是一份源码与训练工具快照，**不是解压即可开服的包**。从源码运行还需要相应插件、8.6 参考 JAR、模型、服务器和本地配置；Java 桥接源码不等于所有服务器插件的完整源码。历史启动/部署脚本含原开发机路径，使用前需配置，不能直接当成通用安装器运行。

需要直接开服时使用单独发布的运行包，解压执行 `start.cmd`。完整私人备份还包含服务器凭据与玩家数据，不能直接作为公开 Release；公开运行包须使用新的空白配置与自行取得的依赖。

## Git 管理范围

只跟踪源码、依赖锁文件、文档和匿名化测试观测。模型权重、优化器、Java/Node/Python 运行环境、`node_modules`、服务器世界、对局录像、日志和真实认证信息不进入 Git 历史。

未在这次导出中新增开源许可证；第三方组件遵循各自许可证。
'''.replace('CONTROLLER', info['controllerCode'])).encode('utf8')

    files['.gitignore'] = b'''# Dependencies and generated artifacts
**/node_modules/
**/__pycache__/
*.py[cod]
*.class
*.jar
*.dll
*.exe
*.pdb
*.gguf
*.bin
*.safetensors
*.onnx
*.pt
*.pth
*.zip
*.7z
*.tar*
*.log
*.jsonl
*.db*
**/classes/
**/bridge-classes/
**/runtime/
**/model/
**/models/
**/model-runtime/
**/launch.json
**/client-control.json
/server/
/runtime/
/outputs/
/backups/
/logs/
/releases/
# Local authentication and server secrets
.env
.env.*
!.env.example
**/*auth*.json
**/*token*.txt
**/server.properties
*.key
*.pem
*.pfx
*.keystore
'''
    files['.gitattributes'] = b'* text=auto\n*.js text eol=lf\n*.mjs text eol=lf\n*.py text eol=lf\n*.java text eol=lf\n*.md text eol=lf\n*.cmd text eol=crlf\n'
    files['docs/DISTRIBUTION.md'] = '''# GitHub 发布安排

仓库 slug 建议 `wavedog`，README 标题和仓库简介为「wavedog 我的世界pvp机器人」。

## GitHub 限制

- 网页上传仓库单文件上限 25 MiB。
- 普通 Git 超过 50 MiB 警告，超过 100 MiB 拒绝。
- 官方建议仓库最好小于 1 GB，强烈建议小于 5 GB。
- Release 的每个附件须小于 2 GiB；与 Git 文件限制不同。
- Git LFS 能管理大文件，但有存储、下载流量及套餐限制，删除普通 Git 文件也不会自动清掉历史里的大文件。

来源（2026-11-19 核对）：
- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
- https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases

## 当前备份

当前私人备份 ZIP 为 1,832,754,688 字节，约 1.71 GiB，低于 Release 单附件上限。它含真实认证配置、控制令牌和服务器数据，留作私人完整备份，不直接公开上传。

其中 Qwen GGUF 原文件约 1.04 GiB，ZIP 后仍约 1.02 GiB；它已经量化，重新压缩不能保证明显缩小。服务器 JAR 等也已压缩。

## 推荐布局

1. Git 仓库只提交本目录源码；不提交完整备份 ZIP。
2. 模型和可启动运行包单独作为 Release 附件，或从其原始来源下载；有不同版本时标明对应控制器与 SHA256。
3. 若制作更小运行包：依赖通过安装器按锁文件安装，公开第三方模型按固定版本下载；自有模型单独下载。这会把「离线、双击即开」改为「首次启动联网安装」，不是等效删减。
4. 世界、个人对局数据、密码与控制令牌不进入公开发布包；新环境生成独立配置。

## 上传

可以在 GitHub 网页新建 `wavedog`，解压源码 ZIP 后把其中的文件上传到仓库根目录（不是上传 ZIP 本身）。本工具只生成本地可审阅材料，没有创建远程仓库或上传任何数据。

若使用 Git，在本目录设置你的远程仓库后再提交和推送。完整备份 ZIP 始终位于本目录之外，不会被 `.gitignore` 配置失误顺带提交。
'''.encode('utf8')

    hits = []
    for name, data in files.items():
        text = data.decode('utf-8-sig')
        if LITERAL_SECRET.search(text) or any(value in text for value in secrets):
            hits.append(name)
    if hits:
        raise RuntimeError('Potential embedded credentials; review files: ' + ', '.join(hits))
    rows = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())]
    manifest = {
        'title': 'wavedog 我的世界pvp机器人',
        'suggestedRepositoryName': 'wavedog',
        'controllerCode': info['controllerCode'],
        'source': 'verified-private-backup-source-snapshot',
        'standaloneServer': False,
        'privateServerDataIncluded': False,
        'authenticationFilesIncluded': False,
        'credentialLiteralScanPassed': True,
        'testFixtureIdentifiersAnonymized': True,
        'files': rows,
    }
    files['SOURCE_MANIFEST.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf8')
    for name, data in files.items():
        target = DEST.joinpath(*PurePosixPath(name).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    with zipfile.ZipFile(OUTPUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(files.items()):
            output.writestr('wavedog/' + name, data)
    with zipfile.ZipFile(OUTPUT) as output:
        if output.testzip() is not None:
            raise RuntimeError('Source ZIP failed CRC validation')
    print(json.dumps({'directory': str(DEST), 'zip': str(OUTPUT), 'files': len(files),
                      'sourceBytes': sum(map(len, files.values())), 'zipBytes': OUTPUT.stat().st_size,
                      'maxFileBytes': max(map(len, files.values())),
                      'controllerCode': info['controllerCode'], 'zipCrcPassed': True,
                      'credentialLiteralScanPassed': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
