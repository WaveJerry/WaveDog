"""Full portable bundle. Read live sources; mutate only the new destination."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,hashlib,json,os,runpy,shutil,sqlite3,sys,time,threading
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parents[2]
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
OPTIONS=argparse.ArgumentParser()
OPTIONS.add_argument('--label',default='xieyi1')
OPTIONS.add_argument('--resume',action='store_true')
OPTIONS.add_argument('--workers',type=int,default=2)
OPTIONS.add_argument('--loaded-pilot-source',type=Path,
    help='Hash-verified source of the running pilot, when unpublished work differs')
ARGS=OPTIONS.parse_args()
if not ARGS.label.isascii() or not ARGS.label.replace('-','').replace('_','').isalnum():raise ValueError('Invalid backup label')
if not 1<=ARGS.workers<=8:raise ValueError('Invalid copy concurrency')
LABEL=ARGS.label
DEST=ROOT/'outputs'/LABEL
MODEL=ROOT/'work/pvp-8.6-dual-fresh/model'
records=[];copied=0;total=0
RECORD_LOCK=threading.Lock()
RESUME=ARGS.resume

def digest(p):
    with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

def record(p,source=None):
    global copied,total
    n=p.stat().st_size;sha=digest(p)
    with RECORD_LOCK:
        copied+=1;total+=n
        records.append({'path':p.relative_to(DEST).as_posix(),'bytes':n,'sha256':sha})
        if copied%2000==0:print(json.dumps({'stage':'copy','files':copied,'GiB':round(total/2**30,3)}),flush=True)

def copy_file(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if RESUME and dst.is_file() and src.suffix!='.db':
        # Keep already copied complete prefixes; static files must still match
        # their source. A file interrupted mid-copy is overwritten safely.
        if dst.stat().st_size==src.stat().st_size and digest(dst)==digest(src):record(dst);return
        if src.suffix in{'.jsonl','.log'} and dst.stat().st_size:
            with dst.open('rb')as saved,src.open('rb')as live:
                remaining=dst.stat().st_size;equal=True
                while remaining:
                    block=saved.read(min(1024*1024,remaining))
                    if not block or live.read(len(block))!=block:equal=False;break
                    remaining-=len(block)
            if equal and not remaining:record(dst);return
    if src.suffix=='.db':
        try:
            with closing(sqlite3.connect(src.as_uri()+'?mode=ro',uri=True))as incoming,closing(sqlite3.connect(dst))as outgoing:
                incoming.backup(outgoing)
            record(dst);return
        except sqlite3.DatabaseError:
            if dst.exists():dst.unlink()
    # Capture a fixed-length prefix even when the live logger appends to it.
    with src.open('rb')as incoming,dst.open('wb')as outgoing:
        remaining=src.stat().st_size
        while remaining:
            block=incoming.read(min(4*1024*1024,remaining))
            if not block:raise RuntimeError('Source shrank while copying: '+str(src))
            outgoing.write(block);remaining-=len(block)
    if src.suffix=='.jsonl' and dst.stat().st_size:
        with dst.open('r+b')as f:
            end=f.seek(0,2);f.seek(end-1)
            if f.read(1)!=b'\n':
                cursor=end
                while cursor:
                    start=max(0,cursor-65536);f.seek(start);block=f.read(cursor-start);i=block.rfind(b'\n')
                    if i>=0:f.truncate(start+i+1);break
                    cursor=start
                else:f.truncate(0)
    record(dst)

def tree(src,dst,exclude=()):
    excluded={p.resolve()for p in exclude}
    tasks=[]
    for current,dirs,files in os.walk(src):
        base=Path(current)
        dirs[:]=sorted(d for d in dirs if d not in {'.git','.agents','.codex'}
            and (base/d).resolve()not in excluded and not(base/d).is_junction()and not(base/d).is_symlink())
        for name in sorted(files):
            p=base/name
            if p.resolve()in excluded or name=='session.lock' or name.endswith(('.tmp','.lock')):continue
            if p.is_symlink():raise RuntimeError('Unresolved file symlink: '+str(p))
            tasks.append((p,dst/p.relative_to(src)))
    with ThreadPoolExecutor(max_workers=ARGS.workers)as pool:
        for result in pool.map(lambda pair:copy_file(*pair),tasks):pass

def freeze_pair(src):
    for attempt in range(20):
        raw=(src/'checkpoint.json').read_bytes();manifest=json.loads(raw)
        name=manifest['binary']
        if Path(name).name!=name:raise RuntimeError('Unexpected weight path')
        try:binary=(src/name).read_bytes()
        except FileNotFoundError:time.sleep(.1);continue
        if hashlib.sha256(binary).hexdigest()!=manifest['sha256']:raise RuntimeError('Weight hash mismatch')
        return raw,binary,manifest
    raise RuntimeError('Could not capture published weights')

def main():
    if DEST.exists() and not(RESUME and (DEST/'INCOMPLETE').exists()):raise RuntimeError('Do not overwrite '+LABEL)
    DEST.mkdir(parents=True,exist_ok=RESUME)
    (DEST/'INCOMPLETE').write_text('Backup is being assembled. Do not move yet.\n')
    command=runpy.run_path(str(ROOT/'work/server_control_1211.py'))['command']
    state={'wavedog':command('wavedog status'),'punengbho':command('wavedog_punengbho status'),
           'selfplay':command('selfplay status')}
    capture=DEST/'snapshot-models'
    def captured_pair(name,source):
        target=capture/name
        if (target/'checkpoint.json').exists():return freeze_pair(target)
        pair=freeze_pair(source);target.mkdir(parents=True,exist_ok=True)
        (target/'checkpoint.json').write_bytes(pair[0]);(target/pair[2]['binary']).write_bytes(pair[1])
        return pair
    primary=captured_pair('main',MODEL)
    independent=captured_pair('independent',ROOT/'work/wavedog-punengbho/model')
    # Pin source now so offline work during the copy cannot change this bundle.
    source_capture=capture/'controller-source'
    if not source_capture.exists():
        for folder in ['pvp-player-client','pvp-dual-brain']:
            destination=source_capture/folder;destination.mkdir(parents=True)
            for file in (ROOT/'work'/folder).glob('*.js'):shutil.copy2(file,destination/file.name)
        pilot_code=ROOT/'work/pvp-dual-brain/punengbho'
        for file in pilot_code.iterdir():
            if file.is_file() and file.suffix in {'.js','.cjs','.json','.py'}:
                dest=source_capture/'pvp-dual-brain/punengbho'/file.name
                dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest)
        # Pin the code actually loaded in BOTH clients, not unpublished edits.
        pinned={}
        for folder in ['wavedog-protocol','wavedog-punengbho']:
            ready=json.loads((ROOT/'work'/folder/'runtime/client-ready.json').read_text())
            for name,expected in ready['sourceSha256'].items():
                if name in pinned and pinned[name]!=expected:raise RuntimeError('Loaded shared-source conflict: '+name)
                sources=[ROOT/'work/pvp-player-client'/name]
                if ARGS.loaded_pilot_source:sources.append(ARGS.loaded_pilot_source/name)
                payload=None
                for src in sources:
                    if not src.is_file():continue
                    raw=src.read_bytes()
                    for candidate in [raw,raw.replace(b'\r\n',b'\n')]:
                        if hashlib.sha256(candidate).hexdigest()==expected:payload=candidate;break
                    if payload is not None:break
                if payload is None:raise RuntimeError('Cannot preserve loaded source: '+folder+'/'+name)
                (source_capture/'pvp-player-client'/name).write_bytes(payload);pinned[name]=expected
            (capture/(folder+'-loaded.json')).write_text(json.dumps(ready),encoding='utf8')
        if ARGS.loaded_pilot_source:
            src=ARGS.loaded_pilot_source/'start-client.py'
            if not src.exists():raise RuntimeError('Matching pilot launcher required')
            dest=source_capture/'wavedog-punengbho/start-client.py';dest.parent.mkdir(parents=True)
            shutil.copy2(src,dest)
    print(json.dumps({'stage':'captured','path':str(DEST),'model':primary[2]['sha256']}),flush=True)
    saves={}
    if RESUME and all((DEST/'server'/folder/'level.dat').exists()for folder in ['world','world_nether','world_the_end']):
        saves['resumedPreviouslyFlushedWorldCopy']=True
        for folder in ['world','world_nether','world_the_end']:
            for p in (DEST/'server'/folder).rglob('*'):
                if p.is_file():record(p)
    else:
        try:
            saves['off']=command('save-off');saves['flush']=command('save-all flush')
            for folder in ['world','world_nether','world_the_end']:
                tree(SERVER/folder,DEST/'server'/folder)
        finally:
            saves['on']=command('save-on')
            print(json.dumps({'stage':'worlds-saved','savingRestored':True}),flush=True)
    tree(SERVER,DEST/'server',exclude=[SERVER/n for n in ['world','world_nether','world_the_end']])
    # Keep history/model archives; omit complete portable copies of the same
    # tree, otherwise each backup recursively doubles all previous bundles.
    previous_bundles=[p for p in (ROOT/'outputs').iterdir()if p.is_dir()
        and(p/'bundle-info.json').is_file()and(p/'start.cmd').is_file()]
    tree(ROOT,DEST/'workspace',exclude=[DEST,*previous_bundles])
    for source in source_capture.rglob('*'):
        if not source.is_file():continue
        p=DEST/'workspace/work'/source.relative_to(source_capture)
        shutil.copy2(source,p)
        record_key=p.relative_to(DEST).as_posix()
        records[:]=[r for r in records if r['path']!=record_key]
        record(p)
    for source,pair in [(MODEL,primary),(ROOT/'work/wavedog-punengbho/model',independent)]:
        raw,binary,manifest=pair;target=DEST/'workspace'/source.relative_to(ROOT)
        for name,data in [('checkpoint.json',raw),(manifest['binary'],binary)]:
            p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            record_key=p.relative_to(DEST).as_posix()
            records[:]=[r for r in records if r['path']!=record_key]
            record(p)
    tree(Path('E:/node'),DEST/'runtime/node')
    python=DEST/'runtime/python';python.mkdir(parents=True,exist_ok=True)
    for name in ['python.exe','pythonw.exe','python3.dll','python314.dll','vcruntime140.dll','vcruntime140_1.dll','LICENSE.txt']:
        src=Path('E:/')/name
        if src.exists():copy_file(src,python/name)
    for name in ['Lib','DLLs','Scripts']:
        if(Path('E:/')/name).exists():tree(Path('E:/')/name,python/name)
    for name in ['msvcp140.dll','msvcp140_1.dll','msvcp140_2.dll','msvcp140_atomic_wait.dll',
      'msvcp140_codecvt_ids.dll','vcruntime140.dll','vcruntime140_1.dll','vccorlib140.dll','concrt140.dll','vcomp140.dll']:
        source=Path('C:/Windows/System32')/name
        if source.exists():copy_file(source,DEST/'runtime/system'/name)
    for p in capture.rglob('*'):
        if p.is_file():record(p)
    # launcher resolves itself; no original drive letters are required.
    for name in ['launch.py','relocate.py','verify.py']:
        copy_file(Path(__file__).parent/name,DEST/name)
    (DEST/'start.cmd').write_bytes(b'@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\n"%~dp0runtime\\python\\python.exe" -B -X utf8 "%~dp0launch.py" %*\r\nif errorlevel 1 pause\r\n')
    record(DEST/'start.cmd')
    (DEST/'README.txt').write_text('xieyi1 完整备份\n\n整个文件夹可搬走。双击根目录 start.cmd 启动服务器、Qwen、共享主脑、WaveDog 及独立 Punengbho。Java / Node / Python 与模型、世界和训练记录均包含。\n已存在同端口服务时拒绝启动，不连接原主服。\nstart.cmd --check 仅校验；start.cmd --test 使用隔离端口试启动并在检查结束后关闭测试服务。\n八角笼训练启动状态保留；当前快照为暂停训练。\n模型权重及 Adam 是一致发布点；在线日志是复制当时的完整前缀，在线进行中的内存状态不伪装成已结算对局。\n',encoding='utf-8')
    readme=DEST/'README.txt'
    readme.write_text(readme.read_text(encoding='utf8').replace('xieyi1',LABEL),encoding='utf8')
    record(readme)
    (DEST/'bundle-info.json').write_text(json.dumps({'label':LABEL,'created':datetime.now().astimezone().isoformat(),
      'sourceWorkspace':str(ROOT),'sourceServer':str(SERVER),'mainModel':primary[2]['sha256'],
      'independentModel':independent[2]['sha256'],'liveStatus':state,'worldSave':saves,
      'bundled':['full-server','full-workspace','java','node','python','node_modules','qwen-weights',
        'transformer-gru-ppo-adam','mechanical-controller','trajectories','reviews','historical-checkpoints'],
      'copyConsistency':'Flushed worlds; atomic model pairs; per-file fixed prefixes; SQLite online backups.',
      'omitted':['session.lock','temporary lock files','managed .git/.agents/.codex metadata','directory junctions','previous self-contained portable bundles'],
      'frozenBeforeFurtherSwordChanges':True},ensure_ascii=False,indent=2),encoding='utf-8')
    record(DEST/'bundle-info.json')
    print(json.dumps({'stage':'verifying','files':len(records),'GiB':round(sum(r['bytes']for r in records)/2**30,3)}),flush=True)
    for i,row in enumerate(records):
        p=DEST/row['path']
        if p.stat().st_size!=row['bytes']or digest(p)!=row['sha256']:raise RuntimeError('Backup verification failed: '+row['path'])
        if i%10000==0:print(json.dumps({'stage':'verified-files','count':i}),flush=True)
    manifest={'label':LABEL,'files':records,'fileCount':len(records),'bytes':sum(r['bytes']for r in records)}
    (DEST/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8')
    (DEST/'COPY_COMPLETE').write_text('Copied and SHA256 verified. Isolated launch validation pending.\n')
    print(json.dumps({'stage':'copy-complete','path':str(DEST),'fileCount':len(records),'bytes':manifest['bytes']}),flush=True)

if __name__=='__main__':main()
