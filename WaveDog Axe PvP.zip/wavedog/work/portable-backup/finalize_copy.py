"""Refresh portable helpers and runtime DLLs after the copy verifier finishes."""
from pathlib import Path
import hashlib, json, shutil

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT/'outputs/xieyi1'
if not (DEST/'COPY_COMPLETE').is_file():
    raise RuntimeError('Wait for the original complete copy and hash verification')
manifest = json.loads((DEST/'manifest.json').read_text(encoding='utf-8'))
records = {row['path']: row for row in manifest['files']}
changed = []
for name in ['launch.py', 'relocate.py', 'verify.py']:
    shutil.copy2(Path(__file__).parent/name, DEST/name)
    changed.append(DEST/name)
for name in ['msvcp140.dll', 'msvcp140_1.dll', 'msvcp140_2.dll', 'msvcp140_atomic_wait.dll',
             'msvcp140_codecvt_ids.dll', 'vcruntime140.dll', 'vcruntime140_1.dll',
             'vccorlib140.dll', 'concrt140.dll', 'vcomp140.dll']:
    source = Path('C:/Windows/System32')/name
    target = DEST/'runtime/system'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    changed.append(target)
for path in changed:
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    key = path.relative_to(DEST).as_posix()
    records[key] = {'path': key, 'bytes': path.stat().st_size, 'sha256': sha}
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha
manifest.update(files=list(records.values()), fileCount=len(records),
                bytes=sum(row['bytes'] for row in records.values()))
(DEST/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False), encoding='utf-8')
(DEST/'helper-refresh-receipt.json').write_text(json.dumps({
    'originalCopyAllHashesVerified': True, 'updatedFilesRehashedAndVerified': len(changed),
    'fileCount': manifest['fileCount'], 'bytes': manifest['bytes']}, indent=2), encoding='utf-8')
print(json.dumps({'refreshed': len(changed), 'fileCount': manifest['fileCount'],
                 'GiB': round(manifest['bytes']/2**30, 3)}))
