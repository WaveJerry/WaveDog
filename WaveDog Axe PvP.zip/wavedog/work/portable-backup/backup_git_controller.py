"""Capture the loaded robot in Git, without a server/world/runtime duplicate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
LABEL = 'WaveDog Axe PvP'
DEST = ROOT / 'outputs' / LABEL
ARTIFACT = ROOT / 'outputs' / (LABEL + '.bundle')
GROUPS = [
    'pvp-player-client', 'pvp-dual-brain', 'legacy86-reference',
    'wavedog-punengbho', 'wavedog-protocol', 'wavedog-command',
    'wavedog-arena-entry', 'pvp-frame-recorder', 'pvp-neural-lab',
    'pvp-train-control', 'hot-update-java', 'arrow-sense',
]
SUBDIRS = {'src', 'bridge-src', 'duel-gate-src', 'qwen-dialogue-src',
           'selfplay-src', 'fixtures', 'tests', 'punengbho'}
SKIP = {'node_modules', 'backups', 'new-learning', 'runtime', 'model',
        'models', 'classes', '__pycache__', '.venv', 'model-runtime', '.git'}
SUFFIXES = {'.js', '.cjs', '.mjs', '.py', '.java', '.md', '.yml'}
SECRET_KEY = re.compile(r'password|passwd|token|secret|api.?key', re.I)
LITERAL_SECRET = re.compile(
    r'''(?i)(?<![.\w])(?:password|passwd|rconpass|rcon_pass|accessToken|clientToken|api_key|apiKey|authorization|secret)\s*[=:]\s*['"][^'"]{4,}['"]'''
    r'|(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]+'
    r'|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY'
    r'|https?://[^\s/@:]+:[^\s/@]+@')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def secret_values(obj):
    out = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            if SECRET_KEY.search(key) and isinstance(value, str) and len(value) >= 8:
                out.add(value)
            out.update(secret_values(value))
    elif isinstance(obj, list):
        for value in obj:
            out.update(secret_values(value))
    return out


def main():
    if DEST.exists() or ARTIFACT.exists():
        raise RuntimeError('Existing snapshot preserved; review before updating its Git history')
    ready = json.loads((ROOT / 'work/wavedog-punengbho/runtime/client-ready.json').read_text())
    for name, digest in ready['sourceSha256'].items():
        if sha(ROOT / 'work/pvp-player-client' / name) != digest:
            raise RuntimeError('Loaded source differs from disk: ' + name)
    for name, digest in ready['legacyRuntime']['classSha256'].items():
        if sha(ROOT / 'work/legacy86-reference/classes/local/pvpbot/ai' / name) != digest:
            raise RuntimeError('Loaded Java class differs from disk: ' + name)

    secrets = set()
    for group in ['wavedog-punengbho', 'wavedog-protocol', 'pvp-player-client']:
        base = ROOT / 'work' / group
        for folder in [base, base / 'runtime']:
            for p in folder.glob('*auth*.json'):
                secrets.update(secret_values(json.loads(p.read_text(encoding='utf-8-sig'))))
    for p in SERVER.glob('plugins/*/*token*.txt'):
        value = p.read_text(encoding='utf8').strip()
        if len(value) >= 8:
            secrets.add(value)
    for line in (SERVER / 'server.properties').read_text(encoding='utf8').splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            if SECRET_KEY.search(key) and len(value) >= 8:
                secrets.add(value)

    files = {}
    for group in GROUPS:
        base = ROOT / 'work' / group
        selected = [p for p in base.iterdir() if p.is_file()]
        for child in base.iterdir():
            if child.is_dir() and child.name in SUBDIRS:
                for folder, dirs, names in os.walk(child):
                    dirs[:] = [name for name in dirs if name not in SKIP]
                    selected.extend(Path(folder) / name for name in names)
        for p in selected:
            rel = p.relative_to(base)
            if not p.is_file() or any(part in SKIP for part in rel.parts):
                continue
            if p.name == 'llama-server-docs.md':
                continue  # Upstream manual with example API keys, not our code.
            if len(rel.parts) > 1 and rel.parts[0] not in SUBDIRS:
                continue
            if p.suffix not in SUFFIXES and not (
                p.name in {'package.json', 'package-lock.json'}
                or 'fixtures' in rel.parts and p.suffix == '.json'
            ):
                continue
            files[p.relative_to(ROOT).as_posix()] = p.read_bytes()

    # Keep deployment/verification utilities as sources, never old output trees.
    for p in (ROOT / 'work/portable-backup').glob('*.py'):
        files[p.relative_to(ROOT).as_posix()] = p.read_bytes()

    for name in ready['legacyRuntime']['classSha256']:
        files['artifacts/legacy86-classes/' + name] = (
            ROOT / 'work/legacy86-reference/classes/local/pvpbot/ai' / name).read_bytes()
    ref = ROOT / 'outputs/legacy86-hop-neural-20261118/reference'
    for name, expected in [
        ('PvPArenaAI.jar', ready['legacyRuntime']['jarSha256']),
        ('test1.nn.tactics-v5.nn', ready['legacyRuntime']['tacticsSha256']),
    ]:
        if sha(ref / name) != expected:
            raise RuntimeError('Reference file changed: ' + name)
        files['artifacts/reference86/' + name] = (ref / name).read_bytes()

    modeldir = ROOT / 'work/wavedog-punengbho/model'
    modelraw = (modeldir / 'checkpoint.json').read_bytes()
    model = json.loads(modelraw)
    if Path(model['binary']).name != model['binary'] or sha(modeldir / model['binary']) != model['sha256']:
        raise RuntimeError('Invalid current checkpoint')
    files['artifacts/independent-model/checkpoint.json'] = modelraw
    files['artifacts/independent-model/' + model['binary']] = (modeldir / model['binary']).read_bytes()

    pluginrows = []
    for p in sorted(SERVER.glob('plugins/*.jar')):
        own = p.name.startswith(('WaveDog', 'Punengbho', 'PvPFrame', 'ArrowSense'))
        pluginrows.append({'name': p.name, 'bytes': p.stat().st_size,
                           'sha256': sha(p), 'included': own})
        if own:
            files['artifacts/plugins/' + p.name] = p.read_bytes()
    for name in ['ranged-calibration.json']:
        files['artifacts/config/' + name] = (
            ROOT / 'work/wavedog-punengbho/runtime' / name).read_bytes()
    mode = json.loads((ROOT / 'work/wavedog-punengbho/client-control.json').read_text())
    mode.pop('candidate', None)
    files['artifacts/config/client-control.json'] = json.dumps(mode, indent=2).encode()
    loaded = {key: ready[key] for key in ['protocol', 'playerName', 'modelIdentity',
        'controllerCode', 'sourceSha256', 'controlRegime', 'highRateMode']}
    loaded['legacyRuntime'] = {key: value for key, value in ready['legacyRuntime'].items() if key != 'pid'}
    files['docs/loaded-controller.json'] = json.dumps(loaded, indent=2).encode()
    files['docs/plugins-lock.json'] = json.dumps(pluginrows, indent=2).encode()
    files['docs/runtime-requirements.json'] = json.dumps({
        'sourceWorkspace': str(ROOT), 'sourceServer': str(SERVER),
        'serverVersion': 'Paper 1.21.11', 'protocolVersion': '1.21.1',
        'mode': mode, 'nodeVersion': subprocess.check_output(
            ['E:/node/node.exe', '--version'], text=True).strip(),
        'java': 'Java 21', 'python': 'Python 3.14 (deployment helpers)',
        'dependencyLocks': ['work/pvp-player-client/package-lock.json', 'work/pvp-dual-brain/package-lock.json'],
        'ports': {'minecraft': 25566, 'rcon': 25576, 'qwen': 18765, 'brain': 18776},
        'qwenModel': {'name': 'Qwen2.5-1.5B-Instruct-Q4_K_M',
            'included': False, 'usedForRealtimeActions': False,
            'path': 'work/pvp-neural-lab/model-runtime/qwen2.5-1.5b-instruct-q4_k_m.gguf'},
        'credentialsIncluded': False, 'fullServerIncluded': False,
    }, ensure_ascii=False, indent=2).encode('utf8')
    files['.gitignore'] = b'''**/node_modules/\n**/__pycache__/\n**/.venv/\n**/runtime/\n**/model/\n**/models/\n**/classes/\n**/bridge-classes/\n**/model-runtime/\n**/launch.json\n**/client-control.json\n!artifacts/config/client-control.json\n**/*auth*.json\n**/*token*.txt\n.env\n.env.*\n*.log\n*.zip\n*.bundle\n*.gguf\n/server/\n/outputs/\n/backups/\n'''
    # The locked source hashes describe actual loaded bytes, including CRLF.
    files['.gitattributes'] = b'* -text\n*.bin binary\n*.jar binary\n*.class binary\n*.nn binary\n'
    files['README.md'] = f'''# {LABEL}

Minecraft 盾斧 PvP 机器人当前运行版的 Git 快照。没有执行回退，没有修改或重启主服务器。

控制器：`{ready['controllerCode']}`。
游戏名 WaveDog，内部独立身份 Punengbho。当前实时决策是 **8.6 Java 控制器 + JS 协议适配、运动预测与 500 Hz 本地监测**。Transformer/GRU 模型和训练代码一起保存，但本版不由它的权重控制实时动作。

## 包含

- `work/`：协议客户端、完整控制与发包链、Java 运行桥、神经网络/训练代码、接入插件源码、竞技场入口、数据记录、构建和部署工具、回归测试。
- `artifacts/plugins/`：当前服务器自有接入插件的准确 JAR，包括 PunengbhoProtocolCore、命令与竞技场入口。
- `artifacts/legacy86-classes/`：实际加载的四个 Java 类；`artifacts/reference86/`：准确的 8.6 参考 JAR 和战术文件。
- `artifacts/independent-model/`：当前独立 Transformer/GRU 检查点及参数/优化器二进制，只有当前一份。
- `artifacts/config/`：控制模式和弓弩校准；`docs/`：加载哈希、插件版本锁与依赖要求。
- `SOURCE_MANIFEST.json`：所有上述文件的 SHA256；`tools/verify_snapshot.py`：离线核对工具。

## 恢复和运行边界

这是机器人系统备份，**不是整台服务器一键启动包**。不包含世界、玩家数据库、密码/控制令牌、录像、旧模型、node_modules、Java/Node/Python 本体和 1 GB 的 Qwen GGUF。历史模型原件仍留在开发工作区。

在原部署路径恢复时，把 `work/` 还原到工作区；将四个 Java 类放回 `work/legacy86-reference/classes/local/pvpbot/ai/`；参考文件放回 `outputs/legacy86-hop-neural-20261118/reference/`；检查点放回 `work/wavedog-punengbho/model/`；配置分别放到独立身份目录及其 `runtime/`。将自有插件 JAR 放到服务器 `plugins/`。先让机器人退出，再替换；不要在对局中覆盖。

Node 依赖在 `work/pvp-player-client`、`work/pvp-dual-brain` 分别执行 `npm ci`。Java 21 / Paper / ViaVersion / AuthMe 等第三方环境按 `docs/` 配置。AuthMe 的机器人账号须自行注册/设置，与新建 `work/wavedog-protocol/runtime/auth.json` 的 password 一致；控制令牌由插件启动时重新生成，不从别的服务器复制。

`work/legacy86-reference/launch.json` 是本地配置，按 Java 路径、classes、参考 JAR、Gson JAR 和战术文件重新生成；参考文件的锁定哈希见 `docs/loaded-controller.json`。原构建/部署工具保留原开发机路径；搬到其他路径时须先配置路径和端口。Qwen 仅用于异步复盘，要恢复此服务需另装 `runtime-requirements.json` 标明的模型及 llama-server。

可用 `python tools/verify_snapshot.py` 检查备份。原环境配置恢复后，用 `work/wavedog-punengbho/start-client.py` 启动协议客户端。独立神经服务使用 `start-service.py`，本次冻结的模式仍是 legacy86。对战命令 `/wavedog duel 玩家名`。

## Git 备份

便携单文件：`WaveDog Axe PvP.bundle`。恢复仓库：

```powershell
git clone "WaveDog Axe PvP.bundle" wavedog
cd wavedog
python tools/verify_snapshot.py
```

本地标签 `wavedog-axe-pvp` 固定本次版本。后续修改继续提交到本仓库；用户再次要求备份时，验证新 bundle 后替换同名文件，只保留一份交付文件。没有配置远程仓库或上传。

500 Hz 是本地监测目标，不代表 500 次服务器新观测；没有实战零失误保证。旧脚本和旧文档用于保留研发信息，实际运行版本以本 README 和加载清单为准。
'''.encode('utf8')
    files['tools/verify_snapshot.py'] = b'''from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf8'))
for row in m['files']:
    p=root/row['path']
    if not p.is_file() or p.stat().st_size!=row['bytes']:
        raise SystemExit('Missing/size mismatch: '+row['path'])
    with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
    if digest!=row['sha256']:raise SystemExit('Hash mismatch: '+row['path'])
loaded=json.loads((root/'docs/loaded-controller.json').read_text())
for name,digest in loaded['sourceSha256'].items():
    if hashlib.sha256((root/'work/pvp-player-client'/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Loaded controller mismatch: '+name)
for name,digest in loaded['legacyRuntime']['classSha256'].items():
    if hashlib.sha256((root/'artifacts/legacy86-classes'/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Loaded Java class mismatch: '+name)
model=root/'artifacts/independent-model'
c=json.loads((model/'checkpoint.json').read_text())
if hashlib.sha256((model/c['binary']).read_bytes()).hexdigest()!=c['sha256']:
    raise SystemExit('Checkpoint mismatch')
print(json.dumps({'verified':True,'files':len(m['files']),'bytes':sum(r['bytes'] for r in m['files']),
    'controllerCode':loaded['controllerCode'],'classes':len(loaded['legacyRuntime']['classSha256']),
    'currentCheckpointVerified':True,'fullServer':False}))
'''

    hits = []
    for name, data in files.items():
        if len(data) >= 100 * 2**20:
            raise RuntimeError('Git single file too large: ' + name)
        if Path(name).suffix in {'.jar', '.bin', '.class', '.nn'}:
            continue
        text = data.decode('utf-8-sig')
        if LITERAL_SECRET.search(text) or any(value in text for value in secrets):
            hits.append(name)
    if hits:
        raise RuntimeError('Review potential credential literals in: ' + ', '.join(hits))
    rows = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())]
    manifest = {'title': LABEL, 'created': datetime.now(timezone.utc).isoformat(),
        'controllerCode': ready['controllerCode'], 'files': rows,
        'loadedSourcesVerified': len(ready['sourceSha256']),
        'loadedJavaClassesVerified': len(ready['legacyRuntime']['classSha256']),
        'credentialScanPassed': True, 'serverAndWorldIncluded': False,
        'currentCheckpoint': model['sha256'], 'mainServerModified': False}
    files['SOURCE_MANIFEST.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf8')
    DEST.mkdir()
    for name, data in files.items():
        p = DEST / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    # Git identity is local to the new archive; no global user configuration.
    def git(*args):
        return subprocess.check_output(['git', '-C', str(DEST), *args], text=True, encoding='utf8', stderr=subprocess.STDOUT).strip()
    git('init', '-b', 'main')
    git('config', 'user.name', 'WaveDog Snapshot')
    git('config', 'user.email', 'snapshot@wavedog.local')
    git('config', 'core.autocrlf', 'false')
    git('config', 'core.quotePath', 'false')
    git('add', '--all')
    tracked = set(git('ls-files').splitlines())
    if tracked != set(files):
        raise RuntimeError('Git tracking mismatch: ' + repr(sorted(set(files) - tracked)))
    subprocess.run(['E:/python.exe', '-B', '-X', 'utf8', str(DEST/'tools/verify_snapshot.py')], check=True)
    git('commit', '-m', 'Snapshot current WaveDog Axe PvP controller and integration')
    git('tag', '-a', 'wavedog-axe-pvp', '-m', 'Current installed controller ' + ready['controllerCode'])
    temporary = ARTIFACT.with_suffix('.bundle.part')
    git('bundle', 'create', str(temporary), '--all')
    git('bundle', 'verify', str(temporary))
    git('fsck', '--full')
    if git('status', '--porcelain'):
        raise RuntimeError('Snapshot working tree is not clean')
    temporary.replace(ARTIFACT)
    receipt = {'label': LABEL, 'repository': str(DEST), 'bundle': str(ARTIFACT),
        'bytes': ARTIFACT.stat().st_size, 'sha256': sha(ARTIFACT),
        'gitCommit': git('rev-parse', 'HEAD'), 'tag': 'wavedog-axe-pvp',
        'controllerCode': ready['controllerCode'], 'files': len(files),
        'credentialScanPassed': True, 'gitBundleVerified': True,
        'serverModified': False, 'rollbackPerformed': False}
    (ROOT/'outputs/wavedog-performance-20261118/close-center-20261119/git-backup-receipt.json').write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(receipt, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
