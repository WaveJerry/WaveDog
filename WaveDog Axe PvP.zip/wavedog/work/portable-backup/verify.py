from pathlib import Path
import hashlib,json,sys,zipfile,subprocess

def verify(root,full=False):
    root=Path(root);failures=[]
    for rel in ['server/server.jar','server/runtime/java21/bin/java.exe','server/world/level.dat',
      'runtime/node/node.exe','runtime/python/python.exe','workspace/work/pvp-neural-lab/model-runtime/llama-server.exe',
      'workspace/work/pvp-neural-lab/model-runtime/qwen2.5-1.5b-instruct-q4_k_m.gguf',
      'workspace/work/pvp-player-client/node_modules/mineflayer/package.json',
      'workspace/work/pvp-dual-brain/node_modules/@tensorflow/tfjs/package.json']:
        if not(root/rel).is_file():failures.append('Missing '+rel)
    for name in ['pvp-8.6-dual-fresh','wavedog-punengbho']:
        model=root/'workspace/work'/name/'model';m=json.loads((model/'checkpoint.json').read_text())
        if Path(m['binary']).name!=m['binary']:failures.append('Invalid model binary path');continue
        with(model/m['binary']).open('rb')as f:
            if hashlib.file_digest(f,'sha256').hexdigest()!=m['sha256']:failures.append('Model weight/Adam hash mismatch: '+name)
    if full:
        manifest=json.loads((root/'manifest.json').read_text())
        for row in manifest['files']:
            p=root/row['path'];original=root/'portable-originals'/row['path']
            check=original if original.exists()else p
            with check.open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
            if sha!=row['sha256']:failures.append('Changed file: '+row['path'])
    if failures:raise RuntimeError('\n'.join(failures[:30]))
    return {'requiredFiles':True,'bothModelPairsValid':True,'fullManifestVerified':full}

if __name__=='__main__':print(json.dumps(verify(Path(__file__).resolve().parent,'--full'in sys.argv)))
