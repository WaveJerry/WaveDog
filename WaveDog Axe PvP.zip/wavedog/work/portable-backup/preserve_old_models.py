"""Keep changed/missing historical checkpoints before retiring whole bundles.

Only creates files. Never deletes a bundle, live model, or trajectory.
"""
from pathlib import Path
import argparse, hashlib, json, shutil

ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--replacement',required=True);p.add_argument('--old',nargs='+',required=True)
a=p.parse_args();new=ROOT/'outputs'/a.replacement
ready=json.loads((new/'BACKUP_READY.json').read_text(encoding='utf8'))
if not ready.get('complete'):raise RuntimeError('Replacement is not validated')
new_rows={r['path']:r for r in json.loads((new/'manifest.json').read_text(encoding='utf8'))['files']}
def digest(path):
    with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
for label in a.old:
    if Path(label).name!=label or label==a.replacement:raise RuntimeError('Invalid old bundle')
    old=ROOT/'outputs'/label
    info=json.loads((old/'bundle-info.json').read_text(encoding='utf8'))
    if info['label']!=label:raise RuntimeError('Old bundle identity mismatch')
    rows={r['path']:r for r in json.loads((old/'manifest.json').read_text(encoding='utf8'))['files']}
    dest=ROOT/'backups'/('retained-models-from-'+label)
    copied=[];verified=0;retained_existing=[];seen=set();missing_references=[]
    def retain(rel):
        if rel in seen:return
        seen.add(rel)
        source=old/rel;target=dest/rel
        if not source.resolve().is_relative_to(old.resolve()):raise RuntimeError('Invalid archive path')
        original=old/'portable-originals'/rel
        if original.exists():source=original
        expected=rows.get(rel,{}).get('sha256')
        live=ROOT/rel.removeprefix('workspace/') if rel.startswith('workspace/') else None
        if live and live.is_file() and expected:
            expected_size=rows[rel]['bytes']
            if live.stat().st_size==expected_size and digest(live)==expected:
                retained_existing.append({'path':rel,'retainedAt':str(live),'sha256':expected});return
            if live.suffix in {'.jsonl','.log','.csv'} and live.stat().st_size>=expected_size:
                h=hashlib.sha256();remaining=expected_size
                with live.open('rb')as stream:
                    while remaining:
                        block=stream.read(min(remaining,4*1024*1024))
                        if not block:break
                        h.update(block);remaining-=len(block)
                if remaining==0 and h.hexdigest()==expected:
                    retained_existing.append({'path':rel,'retainedAt':str(live),'sha256OfPrefix':expected,
                                             'prefixBytes':expected_size});return
        if expected and digest(source)!=expected:raise RuntimeError('Changed old source '+rel)
        if target.exists():
            if digest(target)!=digest(source):raise RuntimeError('Preserved file conflict '+rel)
        else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
        if digest(target)!=digest(source):raise RuntimeError('Preservation copy failed '+rel)
        copied.append({'path':rel,'bytes':target.stat().st_size,'sha256':digest(target)})
    for rel,row in rows.items():
        file=Path(rel);parts=set(file.parts)
        checkpoint=file.name=='checkpoint.json' or file.name.startswith('checkpoint-') and file.suffix in {'.bin','.json'}
        weight=file.suffix.lower() in {'.pt','.pth','.safetensors','.onnx','.gguf','.npz'} or \
            file.suffix=='.bin' and any('model' in part or 'checkpoint' in part for part in parts)
        recurrent=file.name.startswith('recurrent-ppo') and file.suffix in {'.json','.gz'}
        model_json=bool(parts&{'model','models','snapshot-models'}) and file.suffix=='.json' and 'rollouts'not in parts
        trajectory=(file.suffix in {'.jsonl','.jsonl.gz'} and any(x in str(file).lower()
            for x in ['frame','rollout','bouts','coach','review','experience'])) or file.name.endswith('-report.json')
        if not(checkpoint or weight or recurrent or model_json or trajectory):continue
        if rel in new_rows and row['sha256']==new_rows[rel]['sha256']:
            verified+=1;continue
        retain(rel)
        if file.suffix=='.json':
            source=old/'portable-originals'/rel
            if not source.exists():source=old/rel
            try:m=json.loads(source.read_text(encoding='utf8'))
            except (ValueError,UnicodeError):continue
            if isinstance(m,dict) and isinstance(m.get('binary'),str):
                if Path(m['binary']).name!=m['binary']:raise RuntimeError('Unsafe checkpoint binary')
                binary=(file.parent/m['binary']).as_posix()
                if (old/binary).is_file():retain(binary)
                else:missing_references.append({'manifest':rel,'binary':binary,
                    'expectedSha256':m.get('sha256'),'missingBeforeCleanup':True})
    dest.mkdir(parents=True,exist_ok=True)
    receipt={'sourceBundle':str(old),'replacement':str(new),'identicalModelsInReplacement':verified,
             'copiedFiles':copied,'bytesCopied':sum(r['bytes']for r in {r['path']:r for r in copied}.values()),
             'retainedExisting':retained_existing,'preexistingMissingReferences':missing_references,
             'modelsPreserved':True,'oldBundleDeleted':False}
    (dest/'PRESERVED.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'old':label,'retained':str(dest),'copiedFiles':len(copied),'bytes':receipt['bytesCopied']}),flush=True)
