"""Focused native sword-critical demonstrations plus explicit operator switch preferences."""
from pathlib import Path
from collections import Counter
import gzip,json
import prepare_expert_repair as base

OUT=base.ROOT/'outputs/learning-repair-20261116'
evidence=json.loads((OUT/'sword-critical-evidence.json').read_text(encoding='utf-8'))
critical={}
for e in evidence['examples']:critical.setdefault(e['source'],{})[e['decisionTick']]=e
original_extract=base.extract

def focused_extract(rows):
    labels,proof,metrics=original_extract(rows)
    source=rows[0]['id']+'.jsonl.gz';known=critical.get(source,{})
    by_tick={r['tick']:r for r in rows if r['type']=='frame'}
    # Keep native successful sword attacks. jifeng's earlier recorder lacks
    # native critical flags; retain sword hits without calling them critical.
    for t,heads in labels.items():
        if heads.get('4')==2:
            own=by_tick[t]['self']
            if own['main']['type']!='DIAMOND_SWORD' or rows[0]['fighter']!='jifengoqk'and t not in known:
                heads.pop('4')
            elif t in known:proof.setdefault(t,[]).append('native-confirmed-sword-critical')
    # A native critical damage receipt is authoritative evidence of a real
    # attack. Requiring the PREVIOUS tick's aim cone discarded five of the six
    # verified wasplan sword criticals: the legitimate player turned and hit
    # between recorder samples. Keep the causal previous observation, require
    # its visible in-reach target and confirmed sword, never invent look keys.
    for t in known:
        frame=by_tick.get(t)
        if not frame:continue
        own=frame['self']
        target=next((p for p in frame['visiblePlayers']if p['name']==rows[0]['opponent']),None)
        if target and own['main']['type']=='DIAMOND_SWORD' and not own['using'] \
                and not own['shielding'] and not target['shield'] and base.compare.reach(own,target)<=3:
            labels.setdefault(t,{})['4']=2
            labels[t]['5']=1
            proof.setdefault(t,[]).append('native-confirmed-sword-critical-no-prelook-assumption')
    preceding_frame=None
    for r in rows:
        if r['type']=='frame':preceding_frame=r
        if r['type']=='action-event'and r['event']=='jump':
            # The recorder emits a grounded frame, then the native jump event
            # in the SAME tick, then an airborne frame on the next tick. The
            # previous tick can still be falling, so t-1 loses repeated jumps.
            # Use only a snapshot preceding the event in journal order; never
            # borrow the next grounded frame as a fictitious earlier input.
            f=preceding_frame;t=f['tick'] if f else -1
            if f and f['self']['ground']and f['self']['main']['type']=='DIAMOND_SWORD' \
                    and 0<=r['tick']-t<=1 and any(t<k<=t+16 for k in known):
                labels.setdefault(t,{})['2']=1
                proof.setdefault(t,[]).extend(['native-jump-leading-to-confirmed-sword-critical',
                    'native-jump-event-after-grounded-snapshot'])
    return labels,proof,metrics

def main():
    base.DEST=OUT/'sword-combo-data';base.extract=focused_extract
    selection={
      'wasplan':[
        '1794728886146-409475-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz',
        '1794728886146-408352-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz',
        '1794728886146-405802-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz'],
      'jifengoqk':[
        '1794720829881-18423-482e97f5-57f4-31bd-a1cf-904812ae89b5.jsonl.gz',
        '1794720829881-45212-482e97f5-57f4-31bd-a1cf-904812ae89b5.jsonl.gz',
        '1794720829881-11871-482e97f5-57f4-31bd-a1cf-904812ae89b5.jsonl.gz'],
      'YarmWino':[
        '1794728886146-415229-6027b660-6005-37f0-b4da-0e7dce500f09.jsonl.gz',
        '1794728886146-448435-6027b660-6005-37f0-b4da-0e7dce500f09.jsonl.gz',
        '1794728886146-359032-6027b660-6005-37f0-b4da-0e7dce500f09.jsonl.gz']}
    base.main(selection)
    path=base.DEST/'dataset.json';dataset=json.loads(path.read_text(encoding='utf-8'))
    operator=[];counts=Counter()
    for trace in dataset['trajectories']:
        with gzip.open(base.SERVER/'plugins/PvPFrameRecorder/bouts'/trace['source'],'rt',encoding='utf-8')as f:rows=[json.loads(l)for l in f]
        frames={r['tick']:r for r in rows if r['type']=='frame'}
        dealt={r['tick']for r in rows if r['type']=='damage'and r['attacker']==trace['fighter']
               and r['victim']==trace['opponent']and not r['cancelled']and r['damage']>0 and r['cause']=='ENTITY_ATTACK'}
        taught=[]
        for frame in trace['frames']:
            t=frame['tick'];f=frames[t];s=f['self'];target=next((p for p in f['visiblePlayers']if p['name']==trace['opponent']),None)
            labels={};proof=[]
            if target and not s['using']and not s['shielding']and base.compare.reach(s,target)<=3:
                if s['main']['type']=='DIAMOND_SWORD'and target['shield']:
                    labels['5']=0;proof.append('operator-preference-quick-axe-switch-against-public-effective-shield');counts['swordToAxe']+=1
                elif s['main']['type']=='DIAMOND_AXE'and not target['shield']and (t in dealt or t-1 in dealt):
                    labels['5']=1;proof.append('operator-preference-sword-followup-after-native-axe-hit');counts['axeToSword']+=1
            if t in critical.get(trace['source'],{}) and not s['ground']:
                labels['1']=0;proof.append('operator-stop-sprint-before-native-confirmed-critical');counts['releaseSprint']+=1
            taught.append({**frame,'labels':labels,'labelEvidence':proof,'supervisionWeight':.5})
        operator.append({**trace,'source':trace['source']+'.operator','sourceKind':'operator-guidance','frames':taught})
    dataset['trajectories']+=operator
    dataset['primaryGoal']='sword critical chains; axe opener then sword; quick axe against effective shield then continue the same combo when possible'
    dataset['operatorPreferences']=dict(counts)
    dataset['notClaimed']='Recorded held events do not prove an intentional quick-switch, a shield break, or uninterrupted combo. Operator preference labels are separate, never PPO.'
    (base.DEST/'focused-dataset.json').write_text(json.dumps(dataset,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'focusedDataset':str(base.DEST/'focused-dataset.json'),'preferences':counts,'frames':sum(len(t['frames'])for t in dataset['trajectories'])}))

if __name__=='__main__':main()
