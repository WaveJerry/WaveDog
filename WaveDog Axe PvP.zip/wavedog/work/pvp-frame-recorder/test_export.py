import importlib.util
from pathlib import Path

spec=importlib.util.spec_from_file_location('export_dataset',Path(__file__).with_name('export_dataset.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
own=dict(x=0,y=0,z=0,eyeY=1.62,vx=0,vy=0,vz=0,ground=True,health=20,food=20,charge=1,
    shieldAvailable=False,shielding=False,using=False,useTicks=0,yaw=0,pitch=0,
    main={'type':'DIAMOND_SWORD'},off={'type':'AIR'})
seen=dict(name='B',x=0,y=0,z=3,yaw=180,shield=False,using=False,main={'type':'DIAMOND_AXE'},
    health=1,charge=1,hiddenInventory=['SECRET'])
rows=[dict(type='start',fighter='A',opponent='B',id='test'),
    dict(type='frame',tick=1,self=own,visiblePlayers=[seen],arrows=[],terrain=[{'type':'STONE'}]),
    dict(type='action-event',tick=1,event='jump'),
    dict(type='damage',tick=1,cancelled=False,attacker='A',victim='B',cause='ENTITY_ATTACK',damage=3),
    dict(type='frame',tick=2,self=own,visiblePlayers=[],arrows=[]),
    dict(type='terminal',tick=3,dead='B'),dict(type='end',tick=3)]
result=module.convert(rows)
assert not result['ppoEligible'] and not result['onPolicy']
assert result['frames'][0]['actionLabels']=={'jump':True,'attack':True}
assert not result['frames'][1]['publicRequest']['seen']['visible']
assert result['frames'][1]['terrainTokens']==[{'type':'STONE'}]
assert all(k not in result['frames'][0]['publicRequest']['seen'] for k in ['health','charge','hiddenInventory'])
assert result['frames'][1]['actionLabels']=={},'unknown actions cannot become false no-ops'
assert result['terminal']['dead']=='B'
print('RECORDER_EXPORT_PASS: full chronological public inputs, terrain carry, native-only labels, no on-policy contamination')
