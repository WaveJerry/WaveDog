"""Audit shield-cooldown windows from paired public journals, not inferred inputs.

Both perspectives are used only for offline outcome analysis. Opponent cooldown,
health and inventory from the other perspective must never enter policy inputs.
"""
from collections import Counter
from pathlib import Path
import gzip, json, statistics
import prepare_expert_repair as base

DEST = base.ROOT / 'outputs/sword-learning-next-20261116'
SOURCE = base.SERVER / 'plugins/PvPFrameRecorder/bouts'


def load(path):
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        return [json.loads(line) for line in stream]


def analyze(rows, source):
    header = rows[0]
    frames = [r for r in rows if r['type'] == 'frame']
    damage = [r for r in rows if r['type'] == 'damage' and not r['cancelled']
              and {r['attacker'], r['victim']} == {header['fighter'], header['opponent']}]
    windows = []
    for i in range(1, len(frames)):
        start = frames[i]
        if not frames[i-1]['self']['shieldAvailable'] or start['self']['shieldAvailable']:
            continue
        # Native own shield cooldown transition proves disabled shield. An
        # enemy lowering the shield alone cannot prove a break.
        episode = []
        for frame in frames[i:]:
            if frame['self']['shieldAvailable'] or frame['tick'] - start['tick'] >= 100:
                break
            episode.append(frame)
        if not episode:
            continue
        distances = []
        weapon = Counter()
        switches = []
        previous_weapon = frames[i-1]['self']['main']['type']
        for frame in episode:
            own = frame['self']
            other = next((p for p in frame['visiblePlayers'] if p['name'] == header['opponent']), None)
            if other:
                distances.append((frame['tick'], base.compare.reach(own, other)))
            weapon[own['main']['type']] += 1
            if own['main']['type'] != previous_weapon:
                switches.append({'tick': frame['tick'], 'item': own['main']['type'],
                                 'chargeAfterSwitch': own['charge']})
            previous_weapon = own['main']['type']
        end = episode[-1]['tick']
        events = [r for r in damage if start['tick'] <= r['tick'] <= end]
        dealt = sum(r['damage'] for r in events if r['attacker'] == header['fighter'])
        taken = sum(r['damage'] for r in events if r['victim'] == header['fighter'])
        inside = sum(distance <= 3 for _, distance in distances)
        windows.append({
            'source': source, 'fighter': header['fighter'], 'opponent': header['opponent'],
            'disabledShieldFirstFrame': start['tick'], 'endTick': end,
            'frames': len(episode), 'visibleFrames': len(distances), 'inReachFrames': inside,
            'contactFraction': inside / len(distances) if distances else None,
            'firstOutOfReachTick': next((tick for tick, distance in distances if distance > 3), None),
            'weaponFrames': dict(weapon), 'weaponChanges': switches,
            'damageDealt': dealt, 'damageTaken': taken, 'netDamage': dealt-taken,
            'nativeCombatEvents': events,
            'breakBoundaryEvents': [r for r in damage if start['tick']-1 <= r['tick'] <= start['tick']],
            'evidence': 'native own shield cooldown transition; journal frames; native damage events',
            'notProven': 'movement keys, deliberate rush intent, or a counterfactual winning response'
        })
    return windows


def main():
    catalog = json.loads((base.ROOT/'outputs/learning-repair-20261116/usable-experts.json').read_text())
    selected = [r for r in catalog if not r['dropped'] and 100 <= r['frames'] <= 1200]
    seen = set()
    windows = []
    for item in selected:
        if item['opponent'] != 'WaveDog':
            continue
        prefix = '-'.join(item['file'].split('-')[:2])+'-'
        for path in SOURCE.glob(prefix+'*.jsonl.gz'):
            if path.name in seen:
                continue
            seen.add(path.name)
            rows = load(path)
            if rows[0]['fighter'] != 'WaveDog' or rows[0]['opponent'] != item['fighter']:
                continue
            end = rows[-1]
            if end['type'] != 'end' or end.get('droppedGlobal', 0):
                continue
            windows.extend(analyze(rows, path.name))
    report = {
        'schema': 'shield-rush-outcome-audit-v1', 'analyzedWindows': len(windows),
        'nativeShieldDisableEvidence': True, 'counterfactualResponsesVerified': False,
        'onlineOpponentPrivateStateUsed': False,
        'summary': {player: {
            'windows': len(group := [w for w in windows if w['opponent'] == player]),
            'netDamage': round(sum(w['netDamage'] for w in group), 4),
            'contactFrames': sum(w['inReachFrames'] for w in group),
            'visibleFrames': sum(w['visibleFrames'] for w in group),
            'axeFrames': sum(w['weaponFrames'].get('DIAMOND_AXE', 0) for w in group),
            'swordFrames': sum(w['weaponFrames'].get('DIAMOND_SWORD', 0) for w in group)
        } for player in base.PLAYERS},
        'windows': sorted(windows, key=lambda w: w['netDamage'])
    }
    DEST.mkdir(parents=True, exist_ok=True)
    (DEST/'shield-rush-analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'windows'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
