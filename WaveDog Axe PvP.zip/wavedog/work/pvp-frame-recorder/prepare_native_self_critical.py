"""Self-imitation of executed, native-confirmed criticals; never fabricated PPO."""
from pathlib import Path
from collections import Counter
import gzip, hashlib, json

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'outputs/sword-learning-next-20261116'
destination = BASE/'contact-curriculum-self-critical-v1/live-context.json'
if destination.exists():
    raise RuntimeError('Do not overwrite used evidence')
source = BASE/'contact-curriculum-cadence-v2/live-context.json'
dataset = json.loads(source.read_text(encoding='utf8'))
audit = []
for name, split in [('live-o-axe-contact', 'train'), ('live-o-combo-shield', 'validation'),
                    ('live-o-sword-contact', 'train')]:
    folder = BASE/name
    result = json.loads((folder/'result.json').read_text(encoding='utf8'))
    if not result['validAcceptanceTrial']:
        raise RuntimeError('Invalid server trial')
    journal = next(folder.glob('*-frames.jsonl'))
    frames = [json.loads(line) for line in journal.read_text(encoding='utf8').splitlines()]
    packets = {frame['attackId']: frame for frame in frames if frame.get('attackPacket')}
    targets = {}
    for event in result['nativeSwordCriticals']:
        attack = packets[event['attackId']]
        assert event['nativeCritical'] and not event['cancelled'] and event['amount'] > 0
        assert attack['attackItemName'] == 'diamond_sword' and attack['owners']['attack'] == 'neural'
        assert attack['attackId'] == event['attackId'] and attack['tick'] == event['attackTick']
        # Supervise the decision that actually emitted the packet, not a later
        # frame that has already observed damage. Native outcomes are labels.
        targets[attack['command']['decidedTick']] = event
    rollout_files = list((folder/'rollouts').glob('*.json.gz'))
    assert len(rollout_files) == 1
    payload = rollout_files[0].read_bytes()
    rollout = json.loads(gzip.decompress(payload))
    output = []
    counts = Counter()
    used = set()
    for frame in rollout['episode']:
        x = frame['observation']
        event = targets.get(frame['decidedTick'])
        labels, evidence, weight = {}, [], 1
        if event:
            assert frame['executedHeads'][4] and frame['actions'][4] == 2
            labels = {'4': 2}
            evidence = ['executed-decision-to-matching-native-positive-sword-critical']
            # Outcome-weighted self-imitation is explicitly separate from the
            # uniformly weighted human per-tick cadence and from PPO updates.
            weight = min(4, event['amount'])
            used.add(frame['decidedTick'])
        elif frame['executedHeads'][4] and frame['actions'][4] == 0 and x[1] < .4 \
                and x[31] > .5 and x[97] <= 0 and not x[7] and not x[8] \
                and frame['actions'][5] == (1 if x[12] < .25 else 0):
            labels, evidence = {'4': 0}, ['actual-executed-low-charge-wait-retention']
        output.append({**frame, 'tick': frame['decidedTick'], 'labels': labels,
                       'attackWeaponAction': frame['actions'][5],
                       'labelEvidence': evidence, 'supervisionWeight': weight})
        counts.update(str(v) for v in labels.values())
    assert used == set(targets), 'Every native critical must map to an executed recurrent decision'
    dataset['trajectories'].append(dict(source=name+'-executed-rollout', sourceKind='executed-bot-retention',
        sourceSha256=hashlib.sha256(payload).hexdigest(), policySha256=result['sourceSha256'],
        matchId=result['matchId'], split=split, fighter='WaveDog', opponent='WaveDogSon', frames=output,
        nativeEvidence=str(folder/'result.json'), successfulActionSelfImitation=True))
    audit.append(dict(trial=name, split=split, matchId=result['matchId'], labels=counts,
                      criticalDecisionTicks=sorted(used), rolloutSha256=hashlib.sha256(payload).hexdigest()))
dataset['selfImitationPurpose'] = 'Outcome-weighted native-positive sword criticals, complete causal states; human cadence unchanged'
dataset['parentDatasetSha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
destination.parent.mkdir(parents=True)
destination.write_text(json.dumps(dataset, separators=(',', ':')), encoding='utf8')
destination.with_name('audit.json').write_text(json.dumps(audit, indent=2), encoding='utf8')
print(json.dumps({'dataset': str(destination), 'audit': audit, 'fabricatedPPO': False}))
