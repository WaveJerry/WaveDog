"""Verify cadence labels against ordered native events, not guessed keys."""
from pathlib import Path
import gzip, json, sys
from collections import Counter
from prepare_attack_cadence import RECORDER, reach

base = Path(__file__).resolve().parents[2] / 'outputs/sword-learning-next-20261116'
source = json.loads((base/'contact-curriculum-continuity/live-context.json').read_text(encoding='utf8'))
result = json.loads((base/'contact-curriculum-cadence-v2/live-context.json').read_text(encoding='utf8'))
counts = Counter()
assert len(source['trajectories']) == len(result['trajectories'])
for before, after in zip(source['trajectories'], result['trajectories']):
    assert (before['source'], before['split']) == (after['source'], after['split'])
    assert len(before['frames']) == len(after['frames'])
    original = {f['tick']: f for f in before['frames']}
    intervals = {}
    if after.get('sourceKind', 'native-human-events') == 'native-human-events':
        with gzip.open(RECORDER/after['source'], 'rt', encoding='utf8') as stream:
            previous, events = None, []
            for line in stream:
                row = json.loads(line)
                if row['type'] != 'frame':
                    events.append(row)
                    continue
                if previous and row['tick'] == previous['tick'] + 1:
                    intervals[previous['tick']] = (previous, events)
                previous, events = row, []
    for frame in after['frames']:
        old = original[frame['tick']]
        # Future frames may verify a label, never change its causal input.
        for key in ['observation', 'context', 'publicRequest', 'publicHealthFeatures']:
            assert frame.get(key) == old.get(key), key
        assert set(frame['labels']) <= {'4'}
        if '4' not in frame['labels']:
            continue
        assert frame['supervisionWeight'] == 1
        counts[after['split']+':'+str(frame['labels']['4'])] += 1
        if '4' in old['labels']:
            assert frame['labels']['4'] == old['labels']['4']
            continue
        native, events = intervals[frame['tick']]
        assert frame['labels']['4'] == 0
        assert not any(e['type'] == 'action-event' or e['type'] == 'damage'
                       and e.get('attacker') == after['fighter'] for e in events)
        target = next(p for p in native['visiblePlayers'] if p['name'] == after['opponent'])
        own = native['self']
        assert not own['shielding'] and not own['using'] and not target['shield']
        assert own['main']['type'] in ['DIAMOND_SWORD', 'DIAMOND_AXE']
        assert reach(own, target) <= 4.5
assert counts == {'train:0': 1256, 'train:2': 91, 'validation:0': 651, 'validation:2': 38}
print(json.dumps({'result': 'ATTACK_CADENCE_PASS', 'labels': counts,
                  'causalInputsUnchanged': True, 'nativeQuietIntervalsVerified': True,
                  'weaponKeepWeightNotReused': True}))
