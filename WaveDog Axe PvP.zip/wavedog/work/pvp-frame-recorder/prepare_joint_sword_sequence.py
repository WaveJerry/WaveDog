"""Jointly teach verified jump/weapon events and full attack cadence.

Keep complete causal bouts and their original split. Unknown movement keys
remain unknown; human records are imitation data, never PPO rollouts.
"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import gzip, hashlib, json

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/sword-learning-next-20261116'
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
DEST=BASE/'joint-expert-sequences-v1'

def align_critical_evidence(raw,hits):
    aligned=[]
    for hit in hits:
        previous=None;matches=[]
        for row in raw:
            if row['type']=='frame':previous=row
            if row['type']=='damage'and row['tick']==hit['recorderTick'] \
                    and row.get('attacker')==hit['fighter']and row.get('victim')==hit['opponent'] \
                    and not row.get('cancelled')and abs(row.get('damage',0)-hit['damage'])<1e-5:
                assert previous is not None
                matches.append(previous['tick'])
        assert len(matches)==1,'Ambiguous original damage/observation alignment'
        aligned.append({**hit,'legacyDecisionTick':hit['decisionTick'],
            'decisionTick':matches[0],'alignment':'last recorder snapshot preceding native damage in journal order'})
    return aligned

def main():
    if DEST.exists():raise RuntimeError('Preserve existing dataset')
    original=json.loads((BASE/'contact-curriculum/live-context.json').read_text(encoding='utf8'))
    cadence=json.loads((BASE/'contact-curriculum-critical-paths-v1/live-context.json').read_text(encoding='utf8'))
    timing={t['source']:t for t in cadence['trajectories']}
    result=deepcopy(original); result['trajectories']=[]
    counts=Counter()
    for source in original['trajectories']:
        if source.get('fighter')not in ['wasplan','jifengoqk','YarmWino']:continue
        trace=deepcopy(source); other=timing[trace['source']]
        assert trace['split']==other['split']and trace['matchId']==other['matchId']
        assert len(trace['frames'])==len(other['frames'])
        for frame,teacher in zip(trace['frames'],other['frames']):
            for key in ['tick','observation','publicRequest','legalMasks','context']:
                assert frame.get(key)==teacher.get(key),f'Changed causal input: {key}'
            frame['labels']={h:a for h,a in frame['labels'].items()if h in ['2','5']}
            proof=list(frame['labelEvidence'])
            if '4'in teacher['labels']:
                frame['labels']['4']=teacher['labels']['4']
                proof.extend(teacher['labelEvidence'])
            frame['labelEvidence']=sorted(set(proof))
            if 'attackWeaponAction'in teacher:frame['attackWeaponAction']=teacher['attackWeaponAction']
            for h in frame['labels']:counts[f'{trace["split"]}:head{h}']+=1
        result['trajectories'].append(trace)
    result.update(learningPurpose='joint native jump, weapon selection and complete attack cadence within ordered expert bouts',
        unknownMovementKeysNotFabricated=True,ppoEligible=False,
        originalHumanTrainValidationSplitPreserved=True)
    DEST.mkdir(parents=True)
    (DEST/'live-context.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf8')

    evidence=json.loads((ROOT/'outputs/learning-repair-20261116/sword-critical-evidence.json').read_text())
    source='1794728886146-409475-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz'
    hits=sorted([e for e in evidence['examples']if e['source']==source],key=lambda e:e['decisionTick'])
    assert len(hits)==6 and all(e['nativeCritical']and e['damage']>0 for e in hits)
    file=SERVER/'plugins/PvPFrameRecorder/bouts'/source
    assert hashlib.sha256(file.read_bytes()).hexdigest()==hits[0]['sourceSha256']
    with gzip.open(file,'rt',encoding='utf8')as stream:raw=[json.loads(line)for line in stream]
    assert raw[-1]['type']=='end'and raw[-1].get('droppedGlobal')==0
    hits=align_critical_evidence(raw,hits)
    teacher=next(t for t in result['trajectories']if t['source']==source)
    first,last=hits[0]['decisionTick']-16,hits[-1]['decisionTick']+4
    frames=[f for f in teacher['frames']if first<=f['tick']<=last]
    by_tick={f['tick']:f for f in frames}
    assert all(by_tick[h['decisionTick']]['labels'].get('4')==2 for h in hits)
    clip={'fighter':'wasplan','opponent':teacher['opponent'],'source':source,
        'sourceSha256':hits[0]['sourceSha256'],'nativeCriticalEvidence':hits,
        'tickGaps':[b['decisionTick']-a['decisionTick']for a,b in zip(hits,hits[1:])],
        'positiveDamage':sum(e['damage']for e in hits),
        'knownNativeEvents':[r for r in raw if first<=r['tick']<=last and r['type']=='action-event'],
        'frames':frames,'sourceIsTrainingDemonstration':teacher['split']=='train',
        'notClaimed':['exact unrecorded movement key presses','model has reproduced this chain','guaranteed success against a changing opponent']}
    (DEST/'wasplan-six-crit-reference.json').write_text(json.dumps(clip,ensure_ascii=False,indent=2),encoding='utf8')
    receipt={'counts':dict(counts),'wholeBouts':len(result['trajectories']),
        'sourceInputsUnchanged':True,'humanKeyboardNotInvented':True,
        'wasplanReferenceTickGaps':clip['tickGaps'],'wasplanReferenceDamage':clip['positiveDamage'],
        'mechanicalCombatCodeModified':False,'installed':False}
    (DEST/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(receipt,ensure_ascii=False))

if __name__=='__main__':main()
