"""Compare both human matchups using all recorded ticks, with causal evidence."""
from collections import Counter, defaultdict
from datetime import datetime
import gzip
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[2]
COACH = ROOT / 'work/pvp-8.6-dual-fresh/model/coach'
SOURCE = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts')
DEST = COACH / 'priority-reviews/wavejerry-jifengoqk-20261115'


def reach(own, target):
    return math.sqrt(max(0, abs(target['x']-own['x'])-.3)**2
                     + max(0, abs(target['z']-own['z'])-.3)**2
                     + max(0, target['y']-own['eyeY'], own['eyeY']-target['y']-1.8)**2)


def aimed(own, target):
    yaw, pitch = math.radians(own['yaw']), math.radians(own['pitch'])
    direction = (-math.sin(yaw)*math.cos(pitch), -math.sin(pitch), math.cos(yaw)*math.cos(pitch))
    low, high = 0., 3.
    for origin, delta, lo, hi in zip((own['x'], own['eyeY'], own['z']), direction,
                                    (target['x']-.3, target['y'], target['z']-.3),
                                    (target['x']+.3, target['y']+1.8, target['z']+.3)):
        if abs(delta) < 1e-9:
            if not lo <= origin <= hi:
                return False
            continue
        a, b = sorted(((lo-origin)/delta, (hi-origin)/delta))
        low, high = max(low, a), min(high, b)
        if high < low:
            return False
    return high >= low


def summarize(rows, file):
    start = rows[0]
    fighter, opponent = start['fighter'], start['opponent']
    frames = {r['tick']: r for r in rows if r['type'] == 'frame'}
    ticks = sorted(frames)
    swings = {r['tick'] for r in rows if r['type'] == 'action-event' and r['event'] == 'swing'}
    events = [r for r in rows if r['type'] == 'damage' and not r['cancelled']
              and {r['attacker'], r['victim']} == {fighter, opponent}]

    def before(tick):
        return next((frames[t] for t in (tick-1, tick-2) if t in frames), None)

    def describe(event):
        frame = before(event['tick'])
        out = dict(event)
        if not frame:
            return out
        own = frame['self']
        target = next((p for p in frame['visiblePlayers'] if p['name'] == opponent), None)
        out.update(preTick=frame['tick'], ownHP=own['health'], ownWeapon=own['main']['type'],
                   ownCharge=round(own['charge'], 3), ownGround=own['ground'],
                   ownVy=round(own['vy'], 3), ownSprint=own['sprint'], ownUsing=own['using'],
                   ownShieldAvailable=own['shieldAvailable'], ownShielding=own['shielding'])
        if target:
            out.update(reach=round(reach(own, target), 3), aimed=aimed(own, target),
                       opponentWeapon=target['main']['type'], opponentShielding=target['shield'])
            previous = frames.get(frame['tick']-1)
            other = next((p for p in previous['visiblePlayers'] if p['name'] == opponent), None) if previous else None
            if other:
                out['opponentObservedVy'] = round(target['y']-other['y'], 3)
        return out

    dealt = [describe(r) for r in events if r['damage'] > 0 and r['attacker'] == fighter]
    taken = [describe(r) for r in events if r['damage'] > 0 and r['victim'] == fighter]
    melee = [r for r in dealt if r['cause'] == 'ENTITY_ATTACK']
    incoming = [r for r in taken if r['cause'] == 'ENTITY_ATTACK']
    counters = Counter()
    waited = []
    run = []
    for tick in ticks:
        frame = frames[tick]
        own = frame['self']
        target = next((p for p in frame['visiblePlayers'] if p['name'] == opponent), None)
        if target:
            in_range = reach(own, target) <= 3
            free = not own['shieldAvailable'] and not own['using'] and not own['shielding']
            counters['unshieldedVisibleFrames'] += not own['shieldAvailable']
            counters['unshieldedUsingFrames'] += not own['shieldAvailable'] and own['using']
            counters['unshieldedSwordFrames'] += not own['shieldAvailable'] and own['main']['type'].endswith('_SWORD')
            counters['sneakFrames'] += own['sneak']
            counters['sprintFrames'] += own['sprint']
            ready = free and in_range and aimed(own, target) and own['charge'] >= .85 and not target['shield']
            counters['freeAimedChargedFrames'] += ready
            waiting = ready and tick not in swings and tick+1 not in swings
        else:
            waiting = False
        if waiting:
            if run and tick != run[-1]+1:
                waited.append(run)
                run = []
            run.append(tick)
        elif run:
            waited.append(run)
            run = []
    if run:
        waited.append(run)
    combos = []
    chain = []
    for hit in incoming:
        interrupted = chain and any(chain[-1]['tick'] < own['tick'] <= hit['tick'] for own in melee)
        if chain and (hit['tick']-chain[-1]['tick'] > 18 or interrupted):
            if len(chain) >= 2:
                combos.append(chain)
            chain = []
        chain.append(hit)
    if len(chain) >= 2:
        combos.append(chain)
    last_tick = ticks[-1]
    combat_items = {'DIAMOND_AXE', 'DIAMOND_SWORD', 'BOW', 'CROSSBOW'}
    armed_frames = sum(frame['self']['main']['type'] in combat_items
                       or frame['self']['off']['type'] == 'SHIELD' for frame in frames.values())
    return {'id': start['id'], 'file': file.name, 'fighter': fighter, 'opponent': opponent,
            'startTick': ticks[0], 'endTick': last_tick, 'frames': len(frames),
            'startAt': frames[ticks[0]]['at'], 'endAt': frames[last_tick]['at'],
            'terminal': next((r for r in rows if r['type'] == 'terminal'), None),
            'nativeDealt': round(sum(r['damage'] for r in dealt), 3),
            'nativeTaken': round(sum(r['damage'] for r in taken), 3),
            'meleeHits': len(melee), 'swings': len(swings), 'meleeDealt': round(sum(r['damage'] for r in melee), 3),
            'swordHits': sum(r.get('ownWeapon', '').endswith('_SWORD') for r in melee),
            'preHitChargeMedian': statistics.median([r['ownCharge'] for r in melee if 'ownCharge' in r]) if melee else None,
            'ownFallingMeleeHits': sum(not r.get('ownGround', True) and r.get('ownVy', 0) < -.08 for r in melee),
            'incomingMeleeHits': len(incoming), 'unansweredComboChains': combos,
            'waitRunsAtLeast4Ticks': [r for r in waited if len(r) >= 4],
            'counters': dict(counters), 'dealtEvents': dealt, 'takenEvents': taken,
            'quality': {'combatEquipmentFrames': armed_frames,
                        'unarmedThroughout': armed_frames == 0,
                        'swingTelemetryReliable': fighter != 'WaveDog',
                        'waitingMetric': 'potential observation window only; fake-player swing events are incomplete'
                          if fighter == 'WaveDog' else 'no native swing signal in a charged/aimed window'}}


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    bouts = []
    for file in SOURCE.glob('*.jsonl.gz'):
        try:
            with gzip.open(file, 'rt', encoding='utf-8') as stream:
                rows = [json.loads(line) for line in stream]
        except (EOFError, OSError):
            continue
        if not rows or rows[-1]['type'] != 'end' or not any(r['type'] == 'frame' for r in rows):
            continue
        pair = {rows[0]['fighter'], rows[0]['opponent']}
        if pair not in ({'jifengoqk', 'WaveJerry'}, {'jifengoqk', 'WaveDog'}):
            continue
        bouts.append(summarize(rows, file))
    bouts.sort(key=lambda r: (r['startAt'], r['fighter']))
    # Exclude a whole paired segment if either view was never equipped. Keep
    # the raw evidence and reason rather than learning from naked respawn kills.
    def pair_key(bout):
        return (bout['id'].split('-')[0], bout['startTick'], tuple(sorted((bout['fighter'], bout['opponent']))))
    unarmed = {pair_key(bout) for bout in bouts if bout['quality']['unarmedThroughout']}
    groups = defaultdict(list)
    for bout in bouts:
        bout['quality']['excludedFromTechniqueComparison'] = pair_key(bout) in unarmed
        if not bout['quality']['excludedFromTechniqueComparison']:
            groups[bout['fighter'] + '_vs_' + bout['opponent']].append(bout)
    summary = {}
    for key, group in groups.items():
        charges = [r['ownCharge'] for b in group for r in b['dealtEvents']
                   if r['cause'] == 'ENTITY_ATTACK' and 'ownCharge' in r]
        summary[key] = {'views': len(group), 'frames': sum(b['frames'] for b in group),
                        'deathEnds': sum(bool(b['terminal']) for b in group),
                        'ownDeaths': sum((b['terminal'] or {}).get('dead') == b['fighter'] for b in group),
                        'meleeHits': sum(b['meleeHits'] for b in group),
                        'swordHits': sum(b['swordHits'] for b in group),
                        'fallingMeleeHitsNotConfirmedCriticals': sum(b['ownFallingMeleeHits'] for b in group),
                        'swings': sum(b['swings'] for b in group) if group[0]['fighter'] != 'WaveDog' else None,
                        'preHitChargeMedian': statistics.median(charges) if charges else None,
                        'netDamage': round(sum(b['nativeDealt']-b['nativeTaken'] for b in group), 3),
                        'unansweredComboChains': sum(len(b['unansweredComboChains']) for b in group),
                        'potentialChargedAimedRunsAtLeast4Ticks': sum(len(b['waitRunsAtLeast4Ticks']) for b in group),
                        'counters': dict(sum((Counter(b['counters']) for b in group), Counter()))}
    result = {'at': datetime.now().astimezone().isoformat(), 'summary': summary, 'bouts': bouts,
              'limits': ['damage labels are outcomes, never hidden online observations',
                         'pre-hit charge uses strictly earlier tick, not packet-time charge',
                         'falling motion alone does not establish a native critical',
                         'an observation opportunity is not proof of an executable winning counterfactual',
                         'views may be exchange fragments, not full matches; use deathEnds separately']}
    (DEST / 'comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'summary': summary,
                      'excludedUnarmedViews': sum(b['quality']['excludedFromTechniqueComparison'] for b in bouts),
                      'report': str(DEST / 'comparison.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
