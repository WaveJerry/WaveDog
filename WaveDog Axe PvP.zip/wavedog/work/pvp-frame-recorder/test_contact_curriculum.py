"""Causal import regression on the actual expert six-critical sequence."""
from copy import deepcopy
import gzip, json
import prepare_contact_curriculum as curriculum

source = '1794728886146-409475-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz'
with gzip.open(curriculum.base.SERVER/'plugins/PvPFrameRecorder/bouts'/source, 'rt', encoding='utf-8') as stream:
    rows = [json.loads(line) for line in stream]
labels, proof, metrics = curriculum.extract(rows)
criticals = [409546, 409558, 409572, 409584, 409596, 409609]
jumps = [409538, 409551, 409563, 409575, 409587, 409600]
assert all(labels[t].get('4') == 2 and labels[t].get('5') == 1 for t in criticals)
assert all(labels[t].get('2') == 1 for t in jumps)
frames = {r['tick']: r for r in rows if r['type'] == 'frame'}
for t, heads in labels.items():
    if heads.get('4') != 0:
        continue
    own = frames[t]['self']
    other = next(p for p in frames[t]['visiblePlayers'] if p['name'] == 'WaveDog')
    assert curriculum.base.compare.reach(own, other) > 3 or own['charge'] < .4, 'do not teach charged in-range inactivity'
for t in criticals:
    frame_index = next(i for i, r in enumerate(rows) if r['type'] == 'frame' and r['tick'] == t)
    event_index = next(i for i, r in enumerate(rows) if r['type'] == 'damage' and r['tick'] == t and r['attacker'] == 'wasplan')
    assert frame_index < event_index, 'same-tick snapshot must precede its native action result'
changed = deepcopy(rows)
event_index = next(i for i, r in enumerate(changed) if r['type'] == 'damage' and r['tick'] == criticals[0] and r['attacker'] == 'wasplan')
changed.insert(event_index, {'type': 'action-event', 'tick': criticals[0], 'event': 'held', 'data': {'slot': 0}})
ambiguous, _, _ = curriculum.extract(changed)
assert ambiguous.get(criticals[0], {}).get('4') != 2, 'an intervening switch makes weapon identity uncertain'
assert metrics['confirmedSwordCriticals'] == 6
print(json.dumps({'result': 'CONTACT_CURRICULUM_PASS', 'orderedNativeCriticals': 6,
    'groundedNativeJumps': 6, 'ambiguousWeaponRejected': True, 'chargedInReachWaitingNotTaught': True}))
