"""Export public human demonstrations; these are NOT on-policy PPO rollouts."""
import argparse
import gzip
import json
from pathlib import Path

def convert(rows):
    start=next(row for row in rows if row['type']=='start')
    fighter,opponent=start['fighter'],start['opponent']
    events={}
    for row in rows:
        if row['type'] in ('action-event','damage','terminal'):
            events.setdefault(row['tick'],[]).append(row)
    frames=[]; terrain=[]
    previous=None
    for row in rows:
        if row['type']!='frame':continue
        own=row['self']; terrain=row.get('terrain',terrain)
        visible=next((p for p in row.get('visiblePlayers',[]) if p['name']==opponent),None)
        seen={'visible':visible is not None,'arrows':row.get('arrows',[])}
        if visible:
            seen.update({k:visible[k] for k in ('x','y','z','yaw','shield','using')})
            seen.update(held=visible['main']['type'],swing=visible.get('swingTick',-1))
        self_state={k:own[k] for k in ('x','y','z','eyeY','vx','vy','vz','ground',
            'health','food','charge','shieldAvailable','shielding','using','useTicks')}
        self_state.update(held=0 if own['main']['type'].endswith('_SWORD') else 7,
            crossbowLoaded=bool(own['off'].get('loaded') or own['main'].get('loaded')),
            arrows=own.get('arrows',0),hasBow=own.get('hasBow',False),hasCrossbow=own.get('hasCrossbow',False))
        labels={}; evidence=[]
        for event in events.get(row['tick'],[]):
            if event['type']=='action-event' and event['event']=='jump':
                labels['jump']=True;evidence.append('native-jump-event')
            if event['type']=='damage' and not event['cancelled'] \
                    and event['attacker']==fighter and event['cause']=='ENTITY_ATTACK':
                labels['attack']=True;evidence.append('native-melee-hit; not a packet timestamp')
        frames.append({'tick':row['tick'],'publicRequest':{'fighter':fighter,'opponent':opponent,
            'matchId':start['id'],'tick':row['tick'],'yaw':own['yaw'],'pitch':own['pitch'],
            'self':self_state,'seen':seen},'terrainTokens':terrain,
            'actionLabels':labels,'labelEvidence':evidence,
            'unknownActionHeads':['move','sprint-intent','sneak-intent','weapon-intent','look-intent'],
            'nativeEvents':events.get(row['tick'],[])})
        previous=row
    return {'schema':'wavedog-human-demonstration-v1','sourceMatch':start['id'],
        'fighter':fighter,'opponent':opponent,'onPolicy':False,'ppoEligible':False,
        'purpose':'offline imitation/evaluation; encode publicRequest through PUBLIC-OBS-98; mask unknown action heads; terrain tokens retained for encoder extension',
        'frames':frames,'terminal':next((r for r in rows if r['type']=='terminal'),None)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('input');parser.add_argument('output')
    args=parser.parse_args();destination=Path(args.output);destination.mkdir(parents=True,exist_ok=True)
    files=0;frames=0
    for source in sorted(Path(args.input).glob('*.jsonl.gz')):
        try:
            with gzip.open(source,'rt',encoding='utf-8') as stream:rows=[json.loads(line) for line in stream]
        except (EOFError,OSError):continue # Still-open gzip files wait for their terminal close.
        if not rows or rows[-1]['type']!='end':continue
        result=convert(rows)
        with gzip.open(destination/(source.stem+'.dataset.json.gz'),'wt',encoding='utf-8') as stream:json.dump(result,stream)
        files+=1;frames+=len(result['frames'])
    print(json.dumps({'episodes':files,'publicFrames':frames,'output':str(destination),'ppoEligible':False}))

if __name__=='__main__':main()
