"""Package recorder binaries and source without changing the running server."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SERVER_JAR = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder.jar')
INSTALL = '''# PvP 数据收集插件备份

适用：Paper 1.21.1，Java 21。插件权限 `pvprecord.admin` 默认给予 OP。

## 文件

- `server-disk/plugins/PvPFrameRecorder.jar`：打包时主服 plugins 目录里的原始 JAR，完整保留。
- `latest-build/plugins/PvPFrameRecorder.jar`：工作区最新编译的 JAR，与当前源码一并备份。
- `source/`：当前 Java 源码、原始构建脚本、导出工具、导出验证及说明。
- `build_standalone.py`：可在另一台机器使用的独立构建脚本，不包含服务器热更新操作。
- `manifest.json`：逐文件 SHA-256、时间与版本信息。

两个 JAR 的哈希不同，不能混称同一版本。主服磁盘版本和内存热更新版本可能不同，本包不推断内存版本。

## 安装和记录

选择一个 JAR，放进目标服务器的 `plugins` 目录后正常启动服务器；不要同时安装两份同名插件。
可优先试用 latest-build，若要精确恢复本次主服磁盘文件则使用 server-disk。
本次打包没有改动、重启或重新加载主服务器。

插件自动采集真人参与的 PvP，无需改变原有对战指令。

- `/pvprecord status`：查看帧数、活动轨迹、写入队列和丢帧。
- `/pvprecord watch 玩家名`：延长该玩家的交战记录。
- 原始记录：`plugins/PvPFrameRecorder/bouts/*.jsonl.gz`。
- 导出：`python source/export_dataset.py 输入目录 输出目录`。

逐 tick 保存公开观测、自身状态、可见玩家、箭矢、动作事件、伤害和死亡；周围可见地形每 10 tick 保存一次，含交战前 40 tick。
无法通过 Bukkit 得知的移动按键保持未知；对手隐藏血量、背包和蓄力不作为在线观测。
人类演示供离线模仿和复盘，不作为当前策略的 on-policy PPO 轨迹。

此包保存插件与工具，实际对战轨迹继续保存在原服务器数据目录。

## 独立构建

`python build_standalone.py --server "目标服务器目录" --java "JDK21的bin目录"`

目标目录需已有 Paper 1.21.1 服务端及 libraries；编译产物为 `build/PvPFrameRecorder.jar`。
'''

STANDALONE = '''from pathlib import Path
import argparse, os, subprocess, zipfile
p = argparse.ArgumentParser()
p.add_argument('--server', required=True)
p.add_argument('--java', required=True, help='JDK 21 bin directory')
a = p.parse_args()
base = Path(__file__).resolve().parent
server = Path(a.server)
build = base / 'build'
classes = build / 'classes'
classes.mkdir(parents=True, exist_ok=True)
jars = [server / 'versions/1.21.1/paper-1.21.1.jar', *sorted((server / 'libraries').rglob('*.jar'))]
args = ['-proc:none', '-encoding', 'UTF-8', '--release', '21', '-cp', os.pathsep.join(map(str, jars)), '-d', str(classes), *map(str, (base / 'source/src').rglob('*.java'))]
javac = Path(a.java) / ('javac.exe' if os.name == 'nt' else 'javac')
argfile = build / 'compile.args'
argfile.write_text('\\n'.join('"' + s.replace('\\\\', '\\\\\\\\').replace('"', '\\\\"') + '"' for s in args), encoding='utf-8')
subprocess.run([str(javac), '@' + str(argfile)], check=True)
with zipfile.ZipFile(build / 'PvPFrameRecorder.jar', 'w', zipfile.ZIP_DEFLATED) as z:
    for file in sorted(classes.rglob('*.class')):
        z.write(file, file.relative_to(classes).as_posix())
    z.writestr('plugin.yml', (base / 'source/plugin.yml').read_bytes())
print(build / 'PvPFrameRecorder.jar')
'''


def main():
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    destination = ROOT / 'outputs' / ('PvPFrameRecorder-backup-' + stamp + '.zip')
    destination.parent.mkdir(parents=True, exist_ok=True)
    contents = {'使用说明.md': INSTALL.encode('utf-8'),
                'build_standalone.py': STANDALONE.encode('utf-8')}
    for label, source in [('server-disk', SERVER_JAR), ('latest-build', BASE / 'PvPFrameRecorder.jar')]:
        data = source.read_bytes()
        with zipfile.ZipFile(source) as archive:
            if archive.testzip() is not None:
                raise ValueError('Invalid JAR: ' + str(source))
            descriptor = archive.read('plugin.yml')
        contents[label + '/plugins/PvPFrameRecorder.jar'] = data
        if label == 'latest-build':
            contents['source/plugin.yml'] = descriptor
    for source in sorted((BASE / 'src').rglob('*.java')):
        contents['source/' + source.relative_to(BASE).as_posix()] = source.read_bytes()
    for name in ['build.py', 'export_dataset.py', 'test_export.py', 'README.md',
                 'analyze_opponent.py', 'compare_human_bouts.py', 'watch_opponent.py']:
        contents['source/' + name] = (BASE / name).read_bytes()
    # Validate the portable builder's generated Python before distributing it.
    compile(STANDALONE, 'build_standalone.py', 'exec')
    manifest = {'createdAt': datetime.now().astimezone().isoformat(),
                'serverUnchanged': True, 'includesRecordedTrajectories': False,
                'serverDiskJarSource': str(SERVER_JAR),
                'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                          for name, data in contents.items()]}
    contents['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED) as archive:
        for name, data in contents.items():
            archive.writestr(name, data)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError('Backup ZIP CRC failed')
        for name, data in contents.items():
            if archive.read(name) != data:
                raise ValueError('Backup content verification failed: ' + name)
    print(json.dumps({'path': str(destination), 'bytes': destination.stat().st_size,
                      'entries': len(contents), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                      'verified': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
