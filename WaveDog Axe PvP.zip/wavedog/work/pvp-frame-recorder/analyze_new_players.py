"""Full ordered public evidence, with retreat outcomes rather than invented keys."""
from pathlib import Path
from collections import Counter
from datetime import datetime
import gzip, hashlib, importlib.util, json, math

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts')
DEST=ROOT/'work/wavedog-protocol/runtime/orbit-and-entry/human-study'
spec=importlib.util.spec_from_file_location('compare',Path(__file__).with_name('compare_human_bouts.py'))
compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
NAMES={'YarmWino','wasplan'}

def main():
    DEST.mkdir(parents=True,exist_ok=True)
    details=[]; review=[]; groups=Counter()
    for file in sorted(SOURCE.glob('*.jsonl.gz')):
        try:
            with gzip.open(file,'rt',encoding='utf8')as stream:
                first=json.loads(stream.readline())
                if not ({first.get('fighter'),first.get('opponent')}&NAMES):continue
                rows=[first,*[json.loads(l)for l in stream]]
        except (EOFError,OSError):continue
        if rows[-1]['type']!='end':continue
        own,opp=first['fighter'],first['opponent']
        if own not in NAMES|{'WaveDog','WaveJerry'} or opp not in NAMES|{'WaveDog','WaveJerry'}:continue
        summary=compare.summarize(rows,file)
        frames=[r for r in rows if r['type']=='frame']
        targets={r['tick']:next((p for p in r['visiblePlayers']if p['name']==opp),None)for r in frames}
        exchanges=[r for r in rows if r['type']=='damage'and not r['cancelled']and r['damage']>0
            and {r['attacker'],r['victim']}=={own,opp}]
        retreat=[];pressure=0
        for prev,cur in zip(frames,frames[1:]):
            a,b=targets[prev['tick']],targets[cur['tick']]
            if a is None or b is None or cur['tick']-prev['tick']!=1:continue
            s=prev['self'];u=cur['self'];dx=a['x']-s['x'];dz=a['z']-s['z'];dist=math.hypot(dx,dz)
            if dist<.1:continue
            closing=((b['x']-a['x'])*dx+(b['z']-a['z'])*dz)/dist
            away=-((u['x']-s['x'])*dx+(u['z']-s['z'])*dz)/dist
            threat=compare.reach(s,a)<3.7 and closing<-.035 and (s['shielding']or a['shield'])
            if not threat:continue
            pressure+=1
            if away<.035:continue
            if retreat and cur['tick']-retreat[-1]['lastTick']<=3:
                retreat[-1]['lastTick']=cur['tick'];retreat[-1]['awayDistance']+=away;continue
            retreat.append({'firstTick':cur['tick'],'lastTick':cur['tick'],'ownHP':u['health'],
                'ownShield':u['shielding'],'ownShieldAvailable':u['shieldAvailable'],'opponentShield':b['shield'],
                'reach':compare.reach(u,b),'awayDistance':away,'initialCharge':u['charge']})
        for e in retreat:
            relevant=[r for r in exchanges if e['firstTick']<=r['tick']<=e['lastTick']+20]
            e['next20TicksDealt']=round(sum(r['damage']for r in relevant if r['attacker']==own),4)
            e['next20TicksTaken']=round(sum(r['damage']for r in relevant if r['victim']==own),4)
            e['awayDistance']=round(e['awayDistance'],4)
        summary.update(sourceSha256=hashlib.sha256(file.read_bytes()).hexdigest(),
            shieldRushObservationFrames=pressure,observedRetreats=retreat,
            actionKeysKnown=False,fullOrderedFrames=len(frames))
        details.append(summary);groups[f'{own}_vs_{opp}']+=len(frames)
        if {own,opp}==NAMES and summary['quality']['combatEquipmentFrames']>0:
            events={}
            for r in rows:
                if r['type']in ['damage','action-event','terminal']:events.setdefault(r['tick'],[]).append(r)
            ordered=[];terrain=[]
            for f in frames:
                terrain=f.get('terrain',terrain)
                ordered.append({'tick':f['tick'],'self':f['self'],'visibleOpponent':targets[f['tick']],
                    'arrows':f['arrows'],'visibleTerrain':terrain,'nativeEvents':events.get(f['tick'],[])})
            review.append({'matchId':first['id'],'fighter':own,'opponent':opp,'source':file.name,
                'sourceSha256':summary['sourceSha256'],'onPolicy':False,'ppoEligible':False,'actionKeysKnown':False,
                'summary':{k:summary[k]for k in ['nativeDealt','nativeTaken','shieldRushObservationFrames','observedRetreats']},
                'frames':ordered})
    result={'at':datetime.now().astimezone().isoformat(),'views':len(details),'frameCounts':dict(groups),
        'fullOrderedFrames':sum(d['fullOrderedFrames']for d in details),'bouts':details,
        'limits':['Retreat is observed displacement, not a known backwards key.',
            'Outcome in next 20 ticks does not establish a successful counterfactual.',
            'Falling motion is not proof of a native critical.',
            'Only the fighter own state and publicly visible opponent/environment are policy inputs.']}
    (DEST/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    (DEST/'human-duels-for-qwen.json').write_text(json.dumps(review,ensure_ascii=False),encoding='utf8')
    print(json.dumps({'views':len(details),'frames':result['fullOrderedFrames'],'byPair':dict(groups),
        'humanVsHumanViews':len(review),'shieldRushObservationFrames':sum(d['shieldRushObservationFrames']for d in details),
        'observedRetreats':sum(len(d['observedRetreats'])for d in details),'output':str(DEST)},ensure_ascii=False))

if __name__=='__main__':main()
