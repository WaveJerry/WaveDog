"""A per-frame desired-weapon policy needs demonstrations of KEEP as well as SWITCH.

The next recorded held item plus a complete no-held-event interval supplies
the desired weapon label. It does not fabricate human keyboard intent.
"""
from pathlib import Path
from collections import Counter
import gzip,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/sword-learning-next-20261116'
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
destination=BASE/'contact-curriculum-continuity/live-context.json'
if destination.exists():raise RuntimeError('Refuse to replace previously used data')
dataset=json.loads((BASE/'contact-curriculum-retained/live-context.json').read_text(encoding='utf-8'))
counts=Counter()
for trace in dataset['trajectories']:
    if trace.get('sourceKind')=='executed-bot-retention':continue
    with gzip.open(SERVER/'plugins/PvPFrameRecorder/bouts'/trace['source'],'rt',encoding='utf-8')as stream:
        rows=[json.loads(line)for line in stream]
    changed={r['tick']for r in rows if r['type']=='action-event'and r['event']=='held'}
    for frame,nxt in zip(trace['frames'],trace['frames'][1:]):
        s=frame['publicRequest']['self'];ns=nxt['publicRequest']['self'];seen=frame['publicRequest']['seen']
        if '5'in frame['labels']or nxt['tick']!=frame['tick']+1 or not seen.get('visible')or seen.get('shield')\
                or s['held']not in [0,7]or ns['held']!=s['held']or s['using']or s['shielding']\
                or frame['observation'][97]>.9 or frame['tick']in changed or nxt['tick']in changed:continue
        empty=not frame['labels']
        frame['labels']['5']=int(s['held']==0)
        frame['labelEvidence'].append('native-same-next-held-item-with-complete-no-switch-events')
        if empty:frame['supervisionWeight']*=.15
        counts[f'{trace["split"]}:{s["held"]}']+=1
dataset['desiredWeaponContinuityAudit']=dict(counts)
dataset['learningPurpose']+='; dense desired-weapon KEEP evidence during real charge cycles, with sparse SWITCH events retained at original weight'
destination.parent.mkdir(parents=True)
destination.write_text(json.dumps(dataset,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'dataset':str(destination),'addedNativeKeepLabels':dict(counts)}))
