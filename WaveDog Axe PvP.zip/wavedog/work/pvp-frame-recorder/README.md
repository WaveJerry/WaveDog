# 玩家 PvP 逐帧记录

主服安装 `PvPFrameRecorder.jar` 后自动记录真人参与的交战。原对战指令不变。

- `/pvprecord status` 查看活动轨迹、帧数、队列和丢帧。
- `/pvprecord watch 玩家名` 延长指定玩家的交战记录。
- 每 tick 保存自身状态、公开可见玩家、箭矢；每 10 tick 保存周围 36 条射线可见的墙、地面、低顶表面。保留交战前 40 tick。
- 原生跳跃、挥手、切槽、使用尝试、伤害和死亡按同一 tick 编号。伤害结果单列为结果标签，不作为隐藏对手观测。
- 不控制玩家，不修改物理、攻击距离或装备，不读取对手背包、血量、蓄力或输入。Bukkit 无法得知的移动按键标为未知。

输出 `plugins/PvPFrameRecorder/bouts/*.jsonl.gz`，完整轨迹在结束后关闭压缩流。

转换：`python work/pvp-frame-recorder/export_dataset.py 输入目录 输出目录`。

转换后的 `publicRequest` 对齐现有 PUBLIC-OBS-98 观测入口；地形 token 单独保留。只对有原生证据的动作标注，不伪造移动意图。这些旧人类数据用于离线模仿或评估，不能混作当前策略的 on-policy PPO 轨迹。新增地形 token 尚需后续扩展在线编码器，不能声称现有98维网络已经消费全部环境 token。
