"""Check generated KEEP labels against native event journals and original labels."""
from pathlib import Path
import gzip,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/sword-learning-next-20261116'
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
old=json.loads((BASE/'contact-curriculum-retained/live-context.json').read_text(encoding='utf-8'))
new=json.loads((BASE/'contact-curriculum-continuity/live-context.json').read_text(encoding='utf-8'))
added=0
for a,b in zip(old['trajectories'],new['trajectories'],strict=True):
    assert a['source']==b['source']and a['split']==b['split']
    changes=set()
    if b.get('sourceKind')!='executed-bot-retention':
        with gzip.open(SERVER/'plugins/PvPFrameRecorder/bouts'/b['source'],'rt',encoding='utf-8')as stream:
            rows=[json.loads(line)for line in stream]
        changes={r['tick']for r in rows if r['type']=='action-event'and r['event']=='held'}
    for i,(left,right)in enumerate(zip(a['frames'],b['frames'],strict=True)):
        assert left['observation']==right['observation'],'labels must not alter causal inputs'
        assert all(right['labels'][head]==action for head,action in left['labels'].items()),'native SWITCH/attack/jump labels must remain intact'
        if '5'in left['labels']or '5'not in right['labels']:continue
        own=right['publicRequest']['self'];nxt=b['frames'][i+1]
        assert right['tick']not in changes and nxt['tick']not in changes
        assert nxt['tick']==right['tick']+1 and nxt['publicRequest']['self']['held']==own['held']
        assert not right['publicRequest']['seen'].get('shield')
        assert right['labels']['5']==int(own['held']==0)
        added+=1
assert added==1847
print(json.dumps({'result':'NATIVE_WEAPON_CONTINUITY_PASS','addedKeepLabels':added,
    'originalSwitchAndCriticalLabelsPreserved':True,'causalObservationsUnchanged':True}))
