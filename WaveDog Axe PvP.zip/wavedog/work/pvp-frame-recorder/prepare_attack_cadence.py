"""Keep real between-hit quiet phases; do not invent keys or PPO samples."""
from pathlib import Path
from collections import Counter
import argparse, gzip, hashlib, json, math

ROOT = Path(__file__).resolve().parents[2]
RECORDER = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts')


def reach(own, target):
    return math.hypot(max(0, abs(own['x']-target['x'])-.3),
                      max(0, target['y']-own['eyeY'], own['eyeY']-target['y']-1.8),
                      max(0, abs(own['z']-target['z'])-.3))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    if args.destination.exists():
        raise RuntimeError('Do not overwrite a used curriculum')
    raw = args.source.read_bytes()
    dataset = json.loads(raw)
    counts = Counter()
    buckets = Counter()
    previous_weights = Counter()
    for trace in dataset['trajectories']:
        for frame in trace['frames']:
            frame['attackWeaponAction'] = frame['labels'].get('5', 1 if frame['observation'][12] < .25 else 0)
            frame['labels'] = {k:v for k,v in frame['labels'].items() if k == '4'}
        if trace.get('sourceKind', 'native-human-events') != 'native-human-events':
            continue
        if Path(trace['source']).name != trace['source']:
            raise RuntimeError('Unexpected native source path')
        source = RECORDER/trace['source']
        payload = source.read_bytes()
        if hashlib.sha256(payload).hexdigest() != trace['sourceSha256']:
            raise RuntimeError('Native source changed')
        rows = [json.loads(x) for x in gzip.decompress(payload).decode('utf8').splitlines()]
        if rows[-1].get('droppedGlobal') != 0:
            raise RuntimeError('Quiet labels require complete event capture')
        frames = {f['tick']: f for f in trace['frames']}
        previous = None
        interval = []
        for row in rows:
            if row['type'] != 'frame':
                interval.append(row)
                continue
            if previous and row['tick'] == previous['tick']+1:
                tick = previous['tick']
                target = next((p for p in previous['visiblePlayers'] if p['name'] == trace['opponent']), None)
                own = previous['self']
                # An observed attack, switch, item use or hand event disqualifies
                # quiet supervision. Both the input frame and full event order
                # are retained; the next frame is used only to verify the label.
                hand_event = any(e['type'] == 'action-event' or e['type'] == 'damage'
                                 and e.get('attacker') == trace['fighter'] for e in interval)
                frame = frames.get(tick)
                if frame and '4' not in frame['labels'] and not hand_event and target \
                        and not target['shield'] and not own['using'] and not own['shielding'] \
                        and own['main']['type'] in ['DIAMOND_SWORD', 'DIAMOND_AXE'] \
                        and reach(own, target) <= 4.5:
                    frame['labels']['4'] = 0
                    frame.setdefault('labelEvidence', []).append('complete-native-quiet-ordered-interval-to-next-frame')
                    phase = 'ground' if own['ground'] else 'rising' if own['vy'] >= 0 else 'falling'
                    buckets[trace['split']+':'+phase+':'+('charging' if own['charge'] < .85 else 'charged')] += 1
            previous = row
            interval = []
        for frame in trace['frames']:
            if '4' in frame['labels']:
                # KEEP-only frames were downweighted by the weapon curriculum.
                # These are now equally verified native attack/no-attack labels;
                # reusing that weight would inflate the per-tick attack rate.
                previous_weights[str(frame.get('supervisionWeight', 1))] += 1
                frame['supervisionWeight'] = 1
                counts[trace['split']+':'+str(frame['labels']['4'])] += 1
    dataset['sourceDatasetSha256'] = hashlib.sha256(raw).hexdigest()
    dataset['trainingPurpose'] = 'Full causal sequences and observed quiet attack intervals; empirical per-frame attack frequency'
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    args.destination.write_text(json.dumps(dataset, separators=(',', ':')), encoding='utf8')
    audit = dict(sourceSha256=dataset['sourceDatasetSha256'], labels=counts,
                 addedQuietBuckets=buckets, wholeMatchSplitsPreserved=True,
                 replacedWeaponCurriculumWeights=previous_weights,
                 allNativeAttackLabelWeights=1,
                 realActionsNotPPO=True, fabricatedKeys=False)
    args.destination.with_name('audit.json').write_text(json.dumps(audit, indent=2), encoding='utf8')
    print(json.dumps(audit), flush=True)


if __name__ == '__main__':
    main()
