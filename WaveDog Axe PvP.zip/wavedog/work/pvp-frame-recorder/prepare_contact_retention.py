"""Keep grounded sprint/no-jump evidence while adapting jump and weapon heads.

Actual executed bot inputs are labeled as retention, never human imitation or
PPO. No guessed sprint keys are added to the native human traces.
"""
from pathlib import Path
import gzip,json
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/sword-learning-next-20261116'
source=BASE/'contact-curriculum-balanced/live-context.json'
destination=BASE/'contact-curriculum-retained/live-context.json'
if destination.exists():raise RuntimeError('Refuse to replace used training data')
data=json.loads(source.read_text(encoding='utf-8'))
data['trajectories']=[t for t in data['trajectories']if t.get('sourceKind')!='operator-guidance']
for seq,split in [(3814,'train'),(3815,'validation')]:
    file=ROOT/f'work/pvp-8.6-dual-fresh/model/rollouts/rollout-{seq:012}.json.gz'
    row=json.loads(gzip.decompress(file.read_bytes()))
    frames=[]
    for i,frame in enumerate(row['episode']):
        x=frame['observation'];labels={}
        if i%2==0 and x[2]>.5 and x[31]>.5 and x[97]>.12 and x[7]<.5 and x[8]<.5:
            for head,action in [(1,1),(2,0)]:
                if frame['executedHeads'][head]and frame['actions'][head]==action:labels[str(head)]=action
        frames.append({**frame,'tick':frame['decidedTick'],'labels':labels,
            'labelEvidence':['actual-executed-grounded-approach-retention']if labels else [],'supervisionWeight':1})
    data['trajectories'].append(dict(source=file.name,sourceKind='executed-bot-retention',
        sourceSha256=row['episode'][0]['checkpointSha256'],matchId=f'retention-{seq}',split=split,frames=frames))
data['operatorPreferences']='Sprint release is already guaranteed by the tested falling-hit executor. Do not turn it into general stop-sprinting labels.'
data['learningPurpose']='Native sword/axe choices and native jumps; preserve actual grounded approach; selective probability fusion only for jump and weapon.'
destination.parent.mkdir(parents=True)
destination.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'dataset':str(destination),'traces':len(data['trajectories']),
    'frames':sum(len(t['frames'])for t in data['trajectories'])}))
