"""Build causal expert demonstrations; keep complete bouts and native evidence."""
from collections import Counter
import gzip, hashlib, importlib.util, json, math, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
DEST = ROOT / 'outputs/learning-repair-20261116/expert-data'
def module(name, file):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(file))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
export = module('export_data', 'export_dataset.py')
compare = module('compare_data', 'compare_human_bouts.py')
PLAYERS = ['wasplan', 'jifengoqk', 'YarmWino']
WIDTHS = [9, 2, 2, 2, 5, 5, 13, 7, 2]

def condition(x, req, terrain, episode_tick):
    """Match live relative-yaw, local-floor and cardinal-clearance channels."""
    x = list(x); own = req['self']
    x[17] = max(0, min(1, episode_tick / 2400))
    if x[31] > .5:
        x[14], x[15] = math.sin(math.pi*x[78]), math.cos(math.pi*x[78])
    floors = [b for b in terrain if b.get('solid') and b.get('face') == 'UP'
              and b.get('dy', 0) <= 0]
    if own['ground']: x[16] = 0
    elif floors:
        # Recorder rays are measured from the public eye position.
        nearest = min(floors, key=lambda b: math.hypot(b['dx'], b['dz']))
        floor_y = own['eyeY'] + nearest['dy']
        x[16] = max(-1, min(1, (own['y']-floor_y)/4))
    else: x[16] = max(0, min(1, x[16]))
    # Only use recorded ray-visible solid surfaces; no invented arena bounds.
    for i, (dx, dz) in enumerate([(-1,0), (1,0), (0,-1), (0,1)]):
        walls = [abs(b['dx'] if dx else b['dz']) for b in terrain
                 if b.get('solid') and b.get('face') != 'UP' and abs(b.get('dy',0)) < 1.8
                 and (b['dx']*dx + b['dz']*dz) > 0
                 and abs(b['dz'] if dx else b['dx']) < .6]
        x[56+i] = min([1] + [v/8 for v in walls])
    return x

def extract(rows):
    start = rows[0]; own, enemy = start['fighter'], start['opponent']
    frames = {r['tick']:r for r in rows if r['type']=='frame'}
    labels = {}; evidence = {}; metrics = Counter()
    events = {}
    for event in rows:
        if event['type'] == 'action-event': events.setdefault(event['tick'], []).append(event)
    def eligible(frame, unshielded_enemy=False):
        if not frame:return None
        s = frame['self']; target = next((p for p in frame['visiblePlayers'] if p['name']==enemy),None)
        if s['using'] or s['shielding'] or s['main']['type'] not in ('DIAMOND_AXE','DIAMOND_SWORD'):
            return None
        if target is None or unshielded_enemy and target['shield']:return None
        return target
    for event in rows:
        t = event['tick']; before = frames.get(t-1)
        target = eligible(before)
        if not target:continue
        s = before['self']
        if event['type']=='damage' and not event['cancelled'] and event['damage']>0 \
                and event['cause']=='ENTITY_ATTACK' and event['attacker']==own and event['victim']==enemy \
                and not target['shield'] and compare.reach(s,target)<=3 and compare.aimed(s,target):
            labels.setdefault(t-1,{})['4']=2
            # The observed native hit proves the currently used weapon. This
            # labels retaining it, not a hypothetical rapid-switch exploit.
            labels[t-1]['5']=int(s['main']['type']=='DIAMOND_SWORD')
            evidence.setdefault(t-1,[]).append('native-hit-prior-legal-aim-and-confirmed-weapon')
            metrics['hits']+=1
            metrics['swordHits' if s['main']['type']=='DIAMOND_SWORD' else 'axeHits']+=1
            metrics['groundHits' if s['ground'] else 'fallingHits' if s['vy']<0 else 'risingHits']+=1
            metrics['edgeHits']+=compare.reach(s,target)>=2.75
        if event['type']=='action-event' and event['event']=='held':
            after = next((frames[k]for k in (t,t+1,t+2)if k in frames
                          and frames[k]['self']['selectedSlot']==event['data']['slot']),None)
            if after and after['self']['main']['type']in ('DIAMOND_AXE','DIAMOND_SWORD') \
                    and after['self']['main']['type']!=s['main']['type']:
                labels.setdefault(t-1,{})['5']=int(after['self']['main']['type']=='DIAMOND_SWORD')
                evidence.setdefault(t-1,[]).append('native-held-with-confirmed-item')
                metrics['switches']+=1
    # The recorder has complete swing events (droppedGlobal=0). Select a
    # balanced, deterministic set of real no-swing melee frames, not fabricated
    # keyboard intent. Preserve both out-of-range restraint and real waiting.
    negatives = []
    for t, f in sorted(frames.items()):
        target = eligible(f,True)
        if target and t+1 in frames and '4' not in labels.get(t,{}) and not events.get(t+1):
            distance = compare.reach(f['self'],target)
            if distance<=4.5 and compare.aimed(f['self'],target) or 3<distance<=4.5:
                negatives.append(t)
    limit = metrics['hits']
    if limit and negatives:
        selected = sorted(set(negatives[min(len(negatives)-1,int(i*len(negatives)/limit))]for i in range(limit)))
        for t in selected:
            labels.setdefault(t,{})['4']=0
            evidence.setdefault(t,[]).append('complete-native-events-no-swing-next-tick')
        metrics['noAttackLabels']=len(selected)
    return labels, evidence, dict(metrics)

def main(selection=None, per_player=3, validation_slots=(2,)):
    DEST.mkdir(parents=True,exist_ok=True)
    catalog=json.loads((ROOT/'outputs/learning-repair-20261116/usable-experts.json').read_text())
    sources=[];seen=set()
    for player in PLAYERS:
        ranked=sorted((r for r in catalog if r['fighter']==player and not r['dropped'] and 100<=r['frames']<=900),
                      key=lambda r:(r['swordHits']+r['hits'],r['armed']/r['frames']),reverse=True)
        if selection:
            ranked=sorted((r for r in ranked if r['file']in selection[player]),
                          key=lambda r:selection[player].index(r['file']))
        count=0
        for item in ranked:
            # Do not put the other perspective of a validation encounter in train.
            encounter='-'.join(item['file'].split('-')[:2])+':'+':'.join(sorted([item['fighter'],item['opponent']]))
            if encounter in seen:continue
            with gzip.open(SERVER/'plugins/PvPFrameRecorder/bouts'/item['file'],'rt',encoding='utf-8')as f:
                rows=[json.loads(line)for line in f]
            labels,evidence,metrics=extract(rows)
            if metrics.get('hits',0)<(1 if selection else 4):continue
            split='validation'if count in validation_slots else'train'
            sources.append((item,rows,labels,evidence,metrics,split));seen.add(encounter);count+=1
            if count==per_player:break
        if count<per_player:raise RuntimeError('Insufficient causal expert evidence for '+player)
    client=ROOT/'work/pvp-player-client'
    cp=';'.join(map(str,[client/'bridge-classes',ROOT/'work/pvp-neural-lab/classes',SERVER/'versions/1.21.1/paper-1.21.1.jar',SERVER/'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
    bridge=subprocess.Popen([str(SERVER/'runtime/java21/bin/java.exe'),'-cp',cp,'local.wavedog.lab.ProtocolPlayerBridge',str(DEST/'encoder-cache'),'--observe-only'],
        stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
    def send(row):
        bridge.stdin.write(json.dumps(row)+'\n');bridge.stdin.flush()
        while True:
            line=bridge.stdout.readline()
            if not line:raise RuntimeError('Encoder exited')
            response=json.loads(line)
            if response.get('event')=='error':raise RuntimeError(str(response))
            if response.get('event')=='reset'or response.get('model')=='DUAL-OBS':return response
    if json.loads(bridge.stdout.readline()).get('architecture')!='PUBLIC-OBS-98':raise RuntimeError('Wrong encoder')
    trajectories=[];summary=[]
    try:
        for item,rows,labels,evidence,metrics,split in sources:
            start=rows[0];send({'command':'reset','fighter':start['fighter'],'opponent':start['opponent'],'learning':False})
            encoded=[];converted=export.convert(rows);first=converted['frames'][0]['tick']
            for record in converted['frames']:
                req={**record['publicRequest'],'command':'act','requestId':len(encoded)+1,'focus':'FREE','style':'AGGRESSIVE'}
                swing=req['seen'].get('swing',-1);req['observedOpponentSwingAge']=req['tick']-swing if swing>=0 else-1
                response=send(req)
                masks=[[True]*n for n in WIDTHS];masks[4]=[True,False,True,False,False];masks[5]=[True,True,False,False,False]
                if not req['self']['ground']:masks[2][1]=False
                encoded.append({'tick':req['tick'],'observation':condition(response['observation'],req,record['terrainTokens'],req['tick']-first),
                    'labels':labels.get(req['tick'],{}),'labelEvidence':evidence.get(req['tick'],[]),'legalMasks':masks,
                    'publicRequest':req})
            trace={'source':item['file'],'matchId':start['id'],'sourceSha256':hashlib.sha256((SERVER/'plugins/PvPFrameRecorder/bouts'/item['file']).read_bytes()).hexdigest(),
                   'fighter':start['fighter'],'opponent':start['opponent'],'split':split,'frames':encoded}
            trajectories.append(trace);summary.append({**item,'split':split,'metrics':metrics})
            print(json.dumps({'encoded':item['file'],'split':split,'frames':len(encoded),'metrics':metrics}),flush=True)
    finally:
        bridge.stdin.write('{"command":"close"}\n');bridge.stdin.flush();bridge.wait(timeout=10)
    payload={'schema':'public-human-imitation-v1','ppoEligible':False,'trajectories':trajectories,
             'priorityPlayers':PLAYERS,'bouts':summary,'observationConditioning':'live relative yaw, episode time, public local terrain',
             'unknownHeadsNotSupervised':['movement-keys','sprint-intent','jump-intent','sneak-intent','offhand','look'],
             'evidenceBoundary':'No guessed movement keys. No damage labels from AIR equipment. Full bout holdout. Native positive and balanced no-swing labels.'}
    (DEST/'dataset.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
    (DEST/'selection.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'dataset':str(DEST/'dataset.json'),'bouts':len(trajectories),'frames':sum(len(t['frames'])for t in trajectories)}))

if __name__=='__main__':main()
