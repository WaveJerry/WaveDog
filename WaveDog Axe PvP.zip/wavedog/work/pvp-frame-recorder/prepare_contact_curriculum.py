"""Broader expert sword/axe sequences with causal phase and domain audits.

No mandatory axe-to-sword rule. Only native hits, verified held changes and
native jumps receive human labels. Unknown keyboard inputs remain unknown.
"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import gzip, json, sys
import prepare_expert_repair as base
import prepare_sword_curriculum as focused

DEST = base.ROOT/'outputs/sword-learning-next-20261116/contact-curriculum'
original_extract = base.extract


def extract(rows):
    labels, proof, metrics = original_extract(rows)
    header = rows[0]
    own, enemy = header['fighter'], header['opponent']
    frames = {r['tick']: r for r in rows if r['type'] == 'frame'}
    known = focused.critical.get(header['id']+'.jsonl.gz', {})
    # Replace the old attack subset. Native successful turn-and-hits need no
    # already-aligned crosshair on the previous tick. Require a legal visible
    # target and an unambiguous weapon, not guessed aim or guessed key presses.
    for heads in labels.values():
        heads.pop('4', None)
    hits = Counter()
    hit_ticks = set()
    previous = None
    interval_events = []
    for event in rows:
        if event['type'] == 'frame':
            previous = event
            interval_events = []
            continue
        if event['type'] == 'action-event':
            interval_events.append(event)
        if event['type'] != 'damage' or event['cancelled'] or event['damage'] <= 0 \
                or event['cause'] != 'ENTITY_ATTACK' or event['attacker'] != own or event['victim'] != enemy:
            continue
        # Use the last observation strictly preceding the event in journal
        # order. It can share the event tick without observing its outcome.
        frame = previous
        if not frame or not 0 <= event['tick']-frame['tick'] <= 1:
            continue
        s = frame['self']
        target = next((p for p in frame['visiblePlayers'] if p['name'] == enemy), None)
        if not target or s['using'] or s['shielding'] or target['shield'] \
                or s['main']['type'] not in ('DIAMOND_AXE', 'DIAMOND_SWORD') \
                or base.compare.reach(s, target) > 3:
            continue
        if any(e['event'] == 'held' for e in interval_events):
            continue  # An intratick switch makes the prior weapon uncertain.
        t = frame['tick']
        labels.setdefault(t, {}).update({'4': 2, '5': int(s['main']['type'] == 'DIAMOND_SWORD')})
        proof.setdefault(t, []).append('native-hit-ordered-prior-visible-reach-confirmed-weapon')
        hit_ticks.add(t)
        hits['hits'] += 1
        hits['swordHits' if s['main']['type'] == 'DIAMOND_SWORD' else 'axeHits'] += 1
        hits['edgeHits'] += base.compare.reach(s, target) >= 2.75
        hits['groundHits' if s['ground'] else 'fallingHits' if s['vy'] < 0 else 'risingHits'] += 1
        hits['ownShieldDisabledHits'] += not s['shieldAvailable']
        hits['ownShieldAvailableHits'] += s['shieldAvailable']
        if event['tick']-1 in known and s['main']['type'] == 'DIAMOND_SWORD':
            proof[t].append('native-confirmed-sword-critical')
            hits['confirmedSwordCriticals'] += 1
    # A balanced quiet sample teaches restraint outside reach / while charging,
    # without importing the harmful "full-charge in-range waiting" pattern.
    events_by_tick = Counter(r['tick'] for r in rows if r['type'] == 'action-event')
    quiet = []
    for t, frame in sorted(frames.items()):
        s = frame['self']
        target = next((p for p in frame['visiblePlayers'] if p['name'] == enemy), None)
        if t not in hit_ticks and t+1 in frames and not events_by_tick[t] and not events_by_tick[t+1] \
                and target and not target['shield'] and not s['using'] and not s['shielding'] \
                and s['main']['type'] in ('DIAMOND_AXE', 'DIAMOND_SWORD'):
            distance = base.compare.reach(s, target)
            if 3 < distance <= 4.5 or distance <= 3 and s['charge'] < .4:
                quiet.append(t)
    limit = max(1, hits['hits']//2)
    chosen = sorted(set(quiet[min(len(quiet)-1, int(i*len(quiet)/limit))]
                        for i in range(limit))) if quiet and hits['hits'] else []
    for t in chosen:
        labels.setdefault(t, {})['4'] = 0
        proof.setdefault(t, []).append('complete-native-events-quiet-outside-reach-or-low-charge')
    # Jump supervision follows recorder order, including land-and-jump in the
    # same tick. The later verified critical supplies a label, never an input.
    previous = None
    for event in rows:
        if event['type'] == 'frame':
            previous = event
        elif event['type'] == 'action-event' and event['event'] == 'jump':
            f = previous
            if f and f['self']['ground'] and f['self']['main']['type'] == 'DIAMOND_SWORD' \
                    and 0 <= event['tick']-f['tick'] <= 1 and any(f['tick'] < k <= f['tick']+16 for k in known):
                labels.setdefault(f['tick'], {})['2'] = 1
                proof.setdefault(f['tick'], []).extend([
                    'native-jump-leading-to-confirmed-sword-critical',
                    'native-jump-event-after-grounded-snapshot'])
                hits['nativeCriticalLeadingJumps'] += 1
    counts = {key: hits[key] for key in ('hits', 'swordHits', 'axeHits', 'edgeHits',
        'groundHits', 'fallingHits', 'risingHits', 'ownShieldDisabledHits',
        'ownShieldAvailableHits', 'confirmedSwordCriticals', 'nativeCriticalLeadingJumps')}
    return labels, proof, {**metrics, **counts, 'noAttackLabels': len(chosen)}


def main():
    global DEST
    if len(sys.argv) > 1:
        DEST = Path(sys.argv[1]).resolve()
        if DEST.exists():
            raise RuntimeError('Do not overwrite a previously used curriculum')
    catalog = json.loads((base.ROOT/'outputs/learning-repair-20261116/usable-experts.json').read_text())
    selection = {}
    # All six-hit sword chains are eligible, while entire other encounters,
    # including both possible observer views, are held out from gradients.
    for player in base.PLAYERS:
        pool = [r for r in catalog if r['fighter'] == player and not r['dropped'] and 100 <= r['frames'] <= 900]
        pool.sort(key=lambda r: (len(focused.critical.get(r['file'], {})), r['swordHits'], r['hits']), reverse=True)
        selection[player] = [r['file'] for r in pool[:6]]
    base.DEST = DEST
    base.extract = extract
    base.main(selection, per_player=6, validation_slots=(4, 5))
    path = DEST/'dataset.json'
    dataset = json.loads(path.read_text(encoding='utf-8'))
    audits = Counter()
    for trace in dataset['trajectories']:
        raw = focused.base.SERVER/'plugins/PvPFrameRecorder/bouts'/trace['source']
        with gzip.open(raw, 'rt', encoding='utf-8') as stream:
            rows = [json.loads(line) for line in stream]
        by_tick = {r['tick']: r for r in rows if r['type'] == 'frame'}
        previous_contacts = []
        for frame in trace['frames']:
            f = by_tick[frame['tick']]
            s = f['self']
            target = next((p for p in f['visiblePlayers'] if p['name'] == trace['opponent']), None)
            distance = base.compare.reach(s, target) if target else None
            previous_contacts = [(tick, d) for tick, d in previous_contacts if tick >= frame['tick']-6]
            sustained = distance is not None and distance <= 2.3 and sum(d <= 2.3 for _, d in previous_contacts) >= 3
            frame['analysisPhase'] = 'sustained-contact' if sustained else 'boundary-contact' \
                if distance is not None and 2.6 <= distance <= 3 else 'disengaged' \
                if distance is not None and distance > 3 else 'other'
            # Keep actual shield availability. Nonblocking is not equivalent
            # to a broken shield. Audit this domain gap rather than falsifying
            # the observation to make every expert look unshielded.
            frame['supervisionWeight'] = 1 if not s['shieldAvailable'] else .5
            frame['ownShieldActuallyDisabled'] = not s['shieldAvailable']
            if target:
                previous_contacts.append((frame['tick'], distance))
            for head in frame['labels']:
                audits[f'{trace["split"]}:{frame["analysisPhase"]}:head{head}'] += 1
            if frame['labels'].get('4') == 2:
                audits[f'{trace["split"]}:ownShieldDisabled:{not s["shieldAvailable"]}'] += 1
    dataset['learningPurpose'] = 'distinct boundary exchanges and sustained sword contact; native sword critical jumps; actual weapon switches'
    dataset['noMandatoryAxeToSwordRule'] = True
    # Explicitly separate the operator's stop-sprint instruction from native
    # key evidence. A native critical proves its server result, not which
    # unrecorded client input produced it. Preserve the complete causal trace.
    guided = []
    for trace in dataset['trajectories']:
        if not any('native-confirmed-sword-critical' in f['labelEvidence'] for f in trace['frames']):
            continue
        taught = deepcopy(trace)
        taught['source'] += '.release-sprint-operator'
        taught['sourceKind'] = 'operator-guidance'
        for f in taught['frames']:
            critical = 'native-confirmed-sword-critical' in f['labelEvidence']
            f['labels'] = {'1': 0} if critical and not f['publicRequest']['self']['ground'] else {}
            f['labelEvidence'] = ['operator-stop-sprint-before-native-confirmed-critical'] if f['labels'] else []
            f['supervisionWeight'] *= .5
        if any(f['labels'] for f in taught['frames']):
            guided.append(taught)
    dataset['trajectories'] += guided
    dataset['operatorPreferences'] = 'Only stop sprint before native-confirmed airborne sword criticals; no forced weapon sequence.'
    dataset['phaseAndShieldDomainAudit'] = dict(audits)
    path.write_text(json.dumps(dataset, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({'audit': dict(audits), 'dataset': str(path)}))


if __name__ == '__main__':
    main()
