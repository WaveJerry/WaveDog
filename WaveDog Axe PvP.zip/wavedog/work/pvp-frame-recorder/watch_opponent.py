"""Continuously preserve all named-opponent evidence and export complete demonstrations."""
from datetime import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[2]
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
COACH=ROOT/'work/pvp-8.6-dual-fresh/model/coach'
DEST=COACH/'priority-reviews/jifengoqk-20261115'
DATASET=ROOT/'work/pvp-8.6-dual-fresh/model/demonstrations'
spec=importlib.util.spec_from_file_location('export_dataset',Path(__file__).with_name('export_dataset.py'))
export=importlib.util.module_from_spec(spec);spec.loader.exec_module(export)

def append(path,row):
    with path.open('a',encoding='utf-8') as stream:stream.write(json.dumps(row,ensure_ascii=False)+'\n')

def analyze(rows):
    frames=[r for r in rows if r['type']=='frame']
    own=rows[0]['fighter'];opponent=rows[0]['opponent']
    damage=[r for r in rows if r['type']=='damage' and not r['cancelled']]
    received=sum(r['damage'] for r in damage if r['victim']==own)
    dealt=sum(r['damage'] for r in damage if r['attacker']==own)
    events=[r for r in rows if r['type']=='action-event']
    return {'fighter':own,'opponent':opponent,'frames':len(frames),
        'observedJumpEvents':sum(r['event']=='jump' for r in events),
        'observedWeaponChanges':sum(r['event']=='held' for r in events),
        'nativeDealt':round(dealt,4),'nativeReceived':round(received,4),
        'ownSwordFrames':sum(r['self']['main']['type'].endswith('_SWORD') for r in frames),
        'ownShieldEffectiveFrames':sum(bool(r['self']['shielding']) for r in frames),
        'ownShieldCooldownFrames':sum(not r['self']['shieldAvailable'] for r in frames),
        'terrainFrames':sum('terrain' in r for r in frames),
        'terminal':next((r for r in rows if r['type']=='terminal'),None)}

def run_once():
    DEST.mkdir(parents=True,exist_ok=True);DATASET.mkdir(parents=True,exist_ok=True)
    index=DEST/'continuous-index.json'
    state=json.loads(index.read_text(encoding='utf-8')) if index.exists() else {'nativeReviews':{},'recordedBouts':{}}
    for source in (SERVER/'plugins/PvPArenaAI/reviews').glob('*jifengoqk*.md'):
        if source.name in state['nativeReviews']:continue
        target=DEST/'native-reviews'/source.name;target.parent.mkdir(exist_ok=True)
        data=source.read_bytes();target.write_bytes(data)
        state['nativeReviews'][source.name]={'sha256':hashlib.sha256(data).hexdigest(),'source':str(source)}
    new=[]
    for source in (SERVER/'plugins/PvPFrameRecorder/bouts').glob('*.jsonl.gz'):
        if source.name in state['recordedBouts']:continue
        try:
            with gzip.open(source,'rt',encoding='utf-8') as stream:rows=[json.loads(line) for line in stream]
        except (EOFError,OSError):continue
        if not rows or rows[-1]['type']!='end' or 'jifengoqk' not in (rows[0]['fighter'],rows[0]['opponent']):continue
        target=DEST/'recorded-bouts'/source.name;target.parent.mkdir(exist_ok=True);shutil.copy2(source,target)
        dataset=export.convert(rows)
        with gzip.open(DATASET/(source.stem+'.dataset.json.gz'),'wt',encoding='utf-8') as stream:json.dump(dataset,stream)
        facts=analyze(rows);facts.update(file=source.name,sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            at=datetime.now().astimezone().isoformat(),ppoEligible=False)
        append(DEST/'measured-bouts.jsonl',facts)
        state['recordedBouts'][source.name]=facts;new.append(facts)
    state['updatedAt']=datetime.now().astimezone().isoformat()
    temp=index.with_suffix('.tmp');temp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(index)
    if new:
        # Feed measured notes to the existing live Qwen reader, without an extra
        # model process or re-labeling demonstrations as PPO experience.
        facts={'at':state['updatedAt'],'source':'jifengoqk-measured-unshielded-study',
            'text':'疾风实测对局归档新增'+str(len(new))+'份视角。'+json.dumps(new[-2:],ensure_ascii=False)
                +'。只借鉴无盾起手、剑连击、退距和可实现的反制；固定盾牌打法不作为模仿目标。按连续轨迹分析，不把按跳当成功jump reset。'}
        for path in [COACH/'player-experience.jsonl',ROOT/'work/pvp-dual-brain/work/pvp-player-client/new-learning/selfplay/player-experience.jsonl']:
            path.parent.mkdir(parents=True,exist_ok=True);append(path,facts)
    result={'at':state['updatedAt'],'nativeReviewsPreserved':len(state['nativeReviews']),
        'recordedViewsPreserved':len(state['recordedBouts']),'newViews':len(new)}
    print(json.dumps(result),flush=True)
    return result

if __name__=='__main__':
    while True:
        try:run_once()
        except Exception as error:print(json.dumps({'error':str(error)}),flush=True)
        if '--once' in sys.argv:break
        time.sleep(10)
