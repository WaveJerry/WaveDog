"""Join recorder self views to native critical outcomes, never infer from falling alone."""
from pathlib import Path
from datetime import datetime
from bisect import bisect_left
from collections import Counter, defaultdict
import gzip, hashlib, json

ROOT=Path(__file__).resolve().parents[2]
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
OUT=ROOT/'outputs/learning-repair-20261116'
PLAYERS=['jifengoqk','wasplan','YarmWino']

def main():
    native_path=SERVER/'plugins/WaveDogProtocolCore/native-events.jsonl'
    native=[json.loads(l)for l in native_path.read_text(encoding='utf-8').splitlines()if l.strip()]
    by_pair=defaultdict(list)
    for i,e in enumerate(native):
        if e['type']=='damage' and e.get('melee') and not e.get('cancelled') and e.get('amount',0)>0:
            by_pair[(e['attacker'],e['victim'])].append((datetime.fromisoformat(e['at']).timestamp()*1000,i,e))
    for values in by_pair.values():values.sort()
    catalog=json.loads((OUT/'usable-experts.json').read_text(encoding='utf-8'))
    examples=[];switches=[];used=set()
    for item in catalog:
        p=SERVER/'plugins/PvPFrameRecorder/bouts'/item['file']
        with gzip.open(p,'rt',encoding='utf-8')as f:rows=[json.loads(l)for l in f]
        frames={r['tick']:r for r in rows if r['type']=='frame'}
        values=by_pair.get((item['fighter'],item['opponent']),[]);times=[v[0]for v in values]
        for e in rows:
            t=e['tick'];before=frames.get(t-1);near=frames.get(t)or before
            if e['type']=='action-event'and e['event']=='held'and before:
                after=next((frames[k]for k in (t,t+1,t+2)if k in frames and frames[k]['self']['selectedSlot']==e['data']['slot']),None)
                if after and before['self']['main']['type']in ('DIAMOND_AXE','DIAMOND_SWORD')and after['self']['main']['type']in ('DIAMOND_AXE','DIAMOND_SWORD') \
                        and before['self']['main']['type']!=after['self']['main']['type']:
                    target=next((p for p in before['visiblePlayers']if p['name']==item['opponent']),None)
                    switches.append({'source':item['file'],'fighter':item['fighter'],'tick':t,
                        'from':before['self']['main']['type'],'to':after['self']['main']['type'],
                        'publicTargetShield':target.get('shield')if target else None,
                        'nativeHeldConfirmed':True,'shieldBreakConfirmed':False})
            if e['type']!='damage'or e['attacker']!=item['fighter']or e['victim']!=item['opponent'] \
                    or e['cancelled']or e['damage']<=0 or e['cause']!='ENTITY_ATTACK'or not near or not before:continue
            if before['self']['main']['type']!='DIAMOND_SWORD':continue
            at=near['at'];lo=bisect_left(times,at-150);hi=bisect_left(times,at+151)
            candidates=[v for v in values[lo:hi]if abs(v[2]['amount']-e['damage'])<.0001 and v[1]not in used]
            if len(candidates)!=1:continue
            stamp,index,match=candidates[0];used.add(index)
            if not match.get('nativeCritical'):continue
            examples.append({'source':item['file'],'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                'fighter':item['fighter'],'opponent':item['opponent'],'recorderTick':t,'decisionTick':t-1,
                'nativeMatchId':match['matchId'],'nativeServerTick':match['serverTick'],
                'nativeAt':match['at'],'nativeCritical':True,'damage':match['amount'],
                'joinTimeDeltaMs':round(stamp-at,3),'ownChargeBefore':before['self']['charge'],
                'ownGroundBefore':before['self']['ground'],'ownSprintBefore':before['self']['sprint']})
    chains=[]
    for player in PLAYERS:
        groups=defaultdict(list)
        for e in examples:
            if e['fighter']==player:groups[e['source']].append(e)
        for source,events in groups.items():
            run=[]
            for e in sorted(events,key=lambda r:r['recorderTick']):
                between = run and any(run[-1]['nativeServerTick'] < other['serverTick'] < e['nativeServerTick']
                    for _,_,other in by_pair[(e['fighter'],e['opponent'])]
                    if other['matchId']==e['nativeMatchId'])
                if run and (e['recorderTick']-run[-1]['recorderTick']>26 or between):
                    if len(run)>=2:chains.append({'source':source,'fighter':player,'hits':run})
                    run=[]
                run.append(e)
            if len(run)>=2:chains.append({'source':source,'fighter':player,'hits':run})
    result={'schema':'native-sword-critical-evidence-v1','nativeSourceSha256':hashlib.sha256(native_path.read_bytes()).hexdigest(),
        'priorityPlayers':PLAYERS,'examples':examples,'criticalSequences':chains,'weaponSwitches':switches,
        'boundary':'Native critical bit joined by same attacker/victim/damage and unique time match within 150ms. Switch evidence does not prove intentional quick-switch, shield break or uninterrupted combo. Missing outcomes remain unknown.',
        'counts':{'criticalHits':dict(Counter(e['fighter']for e in examples)),
                  'sequences':dict(Counter(e['fighter']for e in chains)),
                  'weaponSwitches':dict(Counter(e['fighter']for e in switches))}}
    (OUT/'sword-critical-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result['counts']))

if __name__=='__main__':main()
