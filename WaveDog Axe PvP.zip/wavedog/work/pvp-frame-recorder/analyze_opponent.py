"""Measured chronological critique of the current opponent's recorded bouts."""
from collections import Counter
from datetime import datetime
import gzip
import json
import math
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[2]
COACH=ROOT/'work/pvp-8.6-dual-fresh/model/coach'
DEST=COACH/'priority-reviews/jifengoqk-20261115'

def reach(frame,target):
    own=frame['self'];eye=own['eyeY']
    return math.sqrt(max(0,abs(target['x']-own['x'])-.3)**2
        +max(0,abs(target['z']-own['z'])-.3)**2
        +max(0,target['y']-eye,eye-target['y']-1.8)**2)

def analyze(file):
    with gzip.open(file,'rt',encoding='utf-8') as stream:rows=[json.loads(l) for l in stream]
    start=rows[0];frames={r['tick']:r for r in rows if r['type']=='frame'}
    ticks=sorted(frames)
    def at(tick):
        prior=[t for t in ticks if t<=tick and tick-t<=2]
        return frames[max(prior)] if prior else None
    hits=[];losses=[];weapons=Counter();jumps=[]
    for frame in frames.values():weapons[frame['self']['main']['type']]+=1
    for row in rows:
        if row['type']=='action-event' and row['event']=='jump':jumps.append(row['tick'])
        if row['type']!='damage' or row['cancelled'] or row['damage']<=0:continue
        frame=at(row['tick'])
        if not frame:continue
        target=next((p for p in frame['visiblePlayers'] if p['name']==start['opponent']),None)
        if not target:continue
        previous=at(row['tick']-2)
        self=frame['self']
        observedFalling=self['ground'] is False and self['vy']<-.08
        out={'tick':row['tick'],'amount':row['damage'],'cause':row['cause'],
            'ownWeapon':self['main']['type'],'opponentWeapon':target['main']['type'],
            'ownChargeObservedAtDamage':self['charge'],'ownReach':round(reach(frame,target),3),
            'ownGround':self['ground'],'ownVy':round(self['vy'],3),'ownSprint':self['sprint'],
            'ownShieldCooldown':not self['shieldAvailable'],
            'ownFallingPose':observedFalling,'nativeCriticalConfirmed':'unknown-in-recorder-v1'}
        if previous:
            ptarget=next((p for p in previous['visiblePlayers'] if p['name']==start['opponent']),None)
            if ptarget:
                out['opponentObservedDyPerTick']=round((target['y']-ptarget['y'])/(row['tick']-previous['tick']),3)
        if row['attacker']==start['fighter']:hits.append(out)
        if row['victim']==start['fighter']:losses.append(out)
    # Close sword exchange evidence, including the fighter's weapon before each
    # received hit. This does not assert that a hypothetical swap would have won.
    closeSword=[r for r in losses if r['cause']=='ENTITY_ATTACK'
        and r['opponentWeapon'].endswith('_SWORD') and r['ownReach']<2.4 and r['ownShieldCooldown']]
    badTrades=[]
    for hit in hits:
        incoming=[r for r in losses if 0<=r['tick']-hit['tick']<=6]
        total=sum(r['amount'] for r in incoming)
        if total>hit['amount']:
            badTrades.append({'ownHit':hit,'incoming':incoming,'net':round(hit['amount']-total,4)})
    # Observed native hit intervals; zero/cancelled hits are excluded.
    intervals=[b['tick']-a['tick'] for a,b in zip(hits,hits[1:]) if b['cause']=='ENTITY_ATTACK' and a['cause']=='ENTITY_ATTACK']
    return {'id':start['id'],'file':file.name,'fighter':start['fighter'],'opponent':start['opponent'],
        'tickStart':min(ticks),'tickEnd':max(ticks),'frames':len(frames),
        'weapons':dict(weapons),'nativeDealt':round(sum(r['amount'] for r in hits),4),
        'nativeReceived':round(sum(r['amount'] for r in losses),4),'jumps':len(jumps),
        'swordMeleeHits':sum(r['cause']=='ENTITY_ATTACK' and r['ownWeapon'].endswith('_SWORD') for r in hits),
        'axeMeleeHits':sum(r['cause']=='ENTITY_ATTACK' and r['ownWeapon'].endswith('_AXE') for r in hits),
        'medianMeleeHitIntervalTicks':statistics.median(intervals) if intervals else None,
        'closeSwordPressure':closeSword,'badImmediateTrades':badTrades,
        'hits':hits,'received':losses,'terminal':next((r for r in rows if r['type']=='terminal'),None)}

def main():
    records=[]
    for file in sorted((DEST/'recorded-bouts').glob('*.gz')):
        try:records.append(analyze(file))
        except (OSError,EOFError,ValueError,KeyError):continue
    wave=[r for r in records if r['fighter']=='WaveDog']
    human=[r for r in records if r['fighter']=='jifengoqk']
    pressure=[(r,p) for r in wave for p in r['closeSwordPressure']]
    axePressure=[(r,p) for r,p in pressure if p['ownWeapon'].endswith('_AXE')]
    bad=[(r,b) for r in wave for b in r['badImmediateTrades']]
    summary={'at':datetime.now().astimezone().isoformat(),'views':len(records),
        'wavedogViews':len(wave),'humanViews':len(human),
        'wavedogCloseSwordHitsTakenWhileShieldCooling':len(pressure),
        'ofThoseHoldingAxe':len(axePressure),
        'wavedogImmediateLosingTradeWindows':len(bad),
        'humanSwordMeleeHits':sum(r['swordMeleeHits'] for r in human),
        'humanAxeMeleeHits':sum(r['axeMeleeHits'] for r in human),
        'humanObservedNativeJumps':sum(r['jumps'] for r in human),
        'examples':[{'id':r['id'],**p} for r,p in axePressure[:6]],
        'badTradeExamples':[{'id':r['id'],**b} for r,b in bad[:4]],
        'limits':['damage-tick charge may already be reset; not a pre-swing charge measurement',
                  'falling pose is not native-critical confirmation',
                  'alternative action outcomes are counterfactual, not demonstrated wins',
                  'recorded views cover recorder-enabled period; older native reviews stored separately']}
    (DEST/'codex-chronological-analysis.json').write_text(json.dumps({'summary':summary,'bouts':records},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
