"""Regression on the actual six-hit chain, including land-and-jump ordering."""
import gzip,json
import prepare_sword_curriculum as curriculum

source='1794728886146-409475-939b384d-bb00-3d00-812d-5b808bc82d34.jsonl.gz'
with gzip.open(curriculum.base.SERVER/'plugins/PvPFrameRecorder/bouts'/source,'rt',encoding='utf-8')as f:
    rows=[json.loads(line)for line in f]
labels,proof,_=curriculum.focused_extract(rows)
critical_ticks=[409545,409557,409571,409583,409595,409608]
jump_ticks=[409538,409551,409563,409575,409587,409600]
frames={r['tick']:r for r in rows if r['type']=='frame'}
assert all(labels[t].get('4')==2 and labels[t].get('5')==1 for t in critical_ticks)
assert all(labels[t].get('2')==1 and frames[t]['self']['ground'] for t in jump_ticks)
for t in jump_ticks:
    fi=next(i for i,r in enumerate(rows)if r['type']=='frame'and r['tick']==t)
    ji=next(i for i,r in enumerate(rows)if r['type']=='action-event'and r['event']=='jump'and r['tick']==t)
    assert fi<ji,'supervised observation must precede its native jump'
assert all(labels.get(t-1,{}).get('2')!=1 for t in jump_ticks[1:]),'airborne prior frame is not a legal grounded jump'
print(json.dumps({'result':'NATIVE_SWORD_CHAIN_LABEL_PASS','criticalAttackLabels':critical_ticks,
    'groundedJumpLabels':jump_ticks,'futureGroundNotUsed':True}))
