"""Causal human demonstrations: known weapon changes and legal native hits only."""
from collections import Counter
import hashlib
from datetime import datetime
import gzip, importlib.util, json, math
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
DEST = ROOT / 'work/pvp-dual-brain/runtime/pvp-technique-20261115/imitation'
spec = importlib.util.spec_from_file_location('export', Path(__file__).with_name('export_dataset.py'))
export = importlib.util.module_from_spec(spec); spec.loader.exec_module(export)
spec = importlib.util.spec_from_file_location('compare', Path(__file__).with_name('compare_human_bouts.py'))
compare = importlib.util.module_from_spec(spec); spec.loader.exec_module(compare)


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    client = ROOT / 'work/pvp-player-client'
    cp = ';'.join(map(str, [client / 'bridge-classes', ROOT / 'work/pvp-neural-lab/classes',
         SERVER / 'versions/1.21.1/paper-1.21.1.jar',
         SERVER / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
    bridge = subprocess.Popen([str(SERVER / 'runtime/java21/bin/java.exe'), '-cp', cp,
        'local.wavedog.lab.ProtocolPlayerBridge', str(DEST / 'encoder-cache'), '--observe-only'],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
    def send(row):
        bridge.stdin.write(json.dumps(row) + '\n'); bridge.stdin.flush()
        while True:
            line = bridge.stdout.readline()
            if not line: raise RuntimeError('Observation encoder exited')
            response = json.loads(line)
            if response.get('event') == 'error': raise RuntimeError(str(response))
            if response.get('event') == 'reset' or response.get('model') == 'DUAL-OBS': return response
    if json.loads(bridge.stdout.readline()).get('architecture') != 'PUBLIC-OBS-98':
        raise RuntimeError('Wrong public observation encoder')
    windows = []; counts = Counter(); bouts = []; trajectories = []
    cutoff = datetime.fromisoformat('2026-11-15T05:48:00+00:00').timestamp() * 1000
    try:
        for file in sorted((SERVER / 'plugins/PvPFrameRecorder/bouts').glob('*.jsonl.gz')):
            try:
                with gzip.open(file, 'rt', encoding='utf-8') as stream: rows = [json.loads(line) for line in stream]
            except (EOFError, OSError): continue
            if not rows or rows[-1]['type'] != 'end': continue
            start = rows[0]; own, opponent = start['fighter'], start['opponent']
            if own not in ('jifengoqk', 'WaveJerry') or opponent not in ('jifengoqk', 'WaveJerry', 'WaveDog'): continue
            frames = {r['tick']: r for r in rows if r['type'] == 'frame'}
            if not frames: continue
            if opponent == 'WaveDog' and max(r['at'] for r in frames.values()) > cutoff: continue
            # Only the two explicitly requested human matches are in this pass.
            if opponent != 'WaveDog' and start['tick'] not in (20870, 23128): continue
            converted = export.convert(rows)
            send({'command': 'reset', 'fighter': own, 'opponent': opponent, 'learning': False})
            encoded = []; by_tick = {}; labels = {}
            def eligible(frame):
                if not frame: return False
                s = frame['self']
                target = next((p for p in frame['visiblePlayers'] if p['name'] == opponent), None)
                return (not s['shieldAvailable'] and not s['using'] and not s['shielding']
                        and s['main']['type'] in ('DIAMOND_AXE', 'DIAMOND_SWORD')
                        and target is not None and not target['shield'] and compare.reach(s, target) <= 3)
            for event in rows:
                t = event['tick']; before = frames.get(t-1)
                if not eligible(before): continue
                if event['type'] == 'action-event' and event['event'] == 'held':
                    after = next((frames[k] for k in (t, t+1, t+2) if k in frames
                        and frames[k]['self']['selectedSlot'] == event['data']['slot']), None)
                    if after and after['self']['main']['type'] in ('DIAMOND_AXE', 'DIAMOND_SWORD'):
                        old_item, new_item = before['self']['main']['type'], after['self']['main']['type']
                        if old_item != new_item:
                            labels.setdefault(t-1, {})['5'] = 1 if new_item.endswith('_SWORD') else 0
                            counts['nativeWeaponChanges'] += 1
                if event['type'] == 'damage' and not event['cancelled'] and event['damage'] > 0 \
                        and event['cause'] == 'ENTITY_ATTACK' and event['attacker'] == own and event['victim'] == opponent:
                    target = next(p for p in before['visiblePlayers'] if p['name'] == opponent)
                    if compare.aimed(before['self'], target):
                        labels.setdefault(t-1, {})['4'] = 2
                        counts['legalAimedNativeHits'] += 1
            if not labels: continue
            for record in converted['frames']:
                req = {**record['publicRequest'], 'command': 'act', 'requestId': len(encoded)+1,
                       'focus': 'FREE', 'style': 'MIXED'}
                swing = req['seen'].get('swing', -1)
                req['observedOpponentSwingAge'] = req['tick']-swing if swing >= 0 else -1
                response = send(req)
                frame = {'observation': response['observation'], 'tick': req['tick'],
                         'labels': labels.get(req['tick'], {})}
                by_tick[req['tick']] = len(encoded); encoded.append(frame)
            held_out = opponent != 'WaveDog' and start['tick'] == 23128
            trajectories.append({'source': file.name, 'matchId': start['id'],
                'sourceSha256': hashlib.sha256(file.read_bytes()).hexdigest(),
                'fighter': own, 'opponent': opponent,
                'split': 'validation' if held_out else 'train', 'frames': encoded})
            for tick, heads in labels.items():
                if tick not in by_tick: continue
                end = by_tick[tick]
                part = [{**f, 'labels': {}} for f in encoded[max(0, end-15):end+1]]
                part[-1]['labels'] = heads
                windows.append({'source': file.name, 'matchId': start['id'],
                                'split': 'validation' if held_out else 'train', 'frames': part})
            bouts.append({'file': file.name, 'fighter': own, 'opponent': opponent,
                          'encodedFrames': len(encoded), 'labelTicks': len(labels), 'heldOut': held_out})
        payload = {'schema': 'public-human-imitation-v1', 'ppoEligible': False,
            'unknownHeadsNotSupervised': ['move', 'sprint-intent', 'jump-intent', 'sneak-intent', 'offhand', 'look'],
            'labels': 'native held-slot event with confirmed own item; native hit with prior legal aimed observation',
            'wholeBoutEncodedFrames': sum(b['encodedFrames'] for b in bouts),
            'windowSize': 16, 'bouts': bouts, 'counts': dict(counts), 'windows': windows,
            'trajectories': trajectories,
            'recurrentReplay': 'Every recorded frame in order; reset only at bout boundary. Sparse labels only.'}
        if not any(w['split'] == 'train' for w in windows) or not any(w['split'] == 'validation' for w in windows):
            raise RuntimeError('Need disjoint full-bout training and validation evidence')
        path = DEST / 'dataset.json'
        path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        print(json.dumps({'dataset': str(path), 'counts': dict(counts), 'bouts': len(bouts),
                          'windows': dict(Counter(w['split'] for w in windows)),
                          'encodedFrames': payload['wholeBoutEncodedFrames']}, ensure_ascii=False))
    finally:
        bridge.stdin.write('{"command":"close"}\n'); bridge.stdin.flush()
        bridge.wait(timeout=10)


if __name__ == '__main__': main()
