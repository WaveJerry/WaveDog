"""Self-imitation of executed waits and attacks that led to native sword crits.

All inputs stay causal; only labels use subsequent referee outcomes. Whole
held-out bouts remain outside gradient updates. These are not PPO samples.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path


def add_trace(folder, split):
    result = json.loads((folder / 'result.json').read_text(encoding='utf8'))
    assert result['validAcceptanceTrial']
    journal = next(folder.glob('*-frames.jsonl'))
    frames = [json.loads(line) for line in journal.read_text(encoding='utf8').splitlines()]
    packets = {f['attackId']: f for f in frames if f.get('attackPacket')}
    rollout_file, = (folder / 'rollouts').glob('*.json.gz')
    payload = rollout_file.read_bytes()
    episode = json.loads(gzip.decompress(payload))['episode']
    indices = {f['decidedTick']: i for i, f in enumerate(episode)}
    labels = {}
    for event in result['nativeSwordCriticals']:
        attack = packets[event['attackId']]
        assert event['amount'] > 0 and not event['cancelled'] and event['nativeCritical']
        assert attack['owners']['attack'] == 'neural' and attack['attackItemName'] == 'diamond_sword'
        decision = attack['command']['decidedTick']
        index = indices[decision]
        frame = episode[index]
        assert frame['executedHeads'][4] and frame['actions'][4] == 2
        labels[index] = (2, min(4, event['amount']), 'executed-matching-native-positive-sword-critical')
        # Retain the ACTUAL waits immediately preceding this successful hit.
        # Stop at a switch or another attack. Charge .4-.9 matters too: those
        # premature clicks can destroy a critical just as zero-charge clicks do.
        for j in range(index - 1, -1, -1):
            prior = episode[j]
            x = prior['observation']
            if decision - prior['decidedTick'] > 13 or prior['actions'][4] != 0 \
                    or prior['actions'][5] != 1 or x[12] >= .25:
                break
            if prior['executedHeads'][4] and x[31] > .5 and x[97] <= 0 \
                    and not x[7] and not x[8]:
                labels[j] = (0, 1, 'actual-executed-wait-before-native-positive-sword-critical')
    output, counts = [], Counter()
    for i, frame in enumerate(episode):
        value = labels.get(i)
        output.append({**frame, 'tick': frame['decidedTick'],
            'labels': {'4': value[0]} if value else {},
            'labelEvidence': [value[2]] if value else [],
            'supervisionWeight': value[1] if value else 1,
            'attackWeaponAction': frame['actions'][5]})
        if value:
            counts[str(value[0])] += 1
    trace = dict(source=folder.name+'-executed-critical-path', sourceKind='executed-bot-retention',
        sourceSha256=hashlib.sha256(payload).hexdigest(), policySha256=result['sourceSha256'],
        matchId=result['matchId'], split=split, fighter='WaveDog', opponent='WaveDogSon',
        frames=output, nativeEvidence=str(folder / 'result.json'))
    return trace, dict(trial=folder.name, split=split, labels=counts,
        criticalDecisionTicks=[episode[i]['decidedTick'] for i, v in labels.items() if v[0] == 2],
        rolloutSha256=trace['sourceSha256'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('base', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    assert not args.destination.exists(), 'Never overwrite used evidence'
    source = args.base / 'contact-curriculum-cadence-v2/live-context.json'
    dataset = json.loads(source.read_text(encoding='utf8'))
    audits = []
    for name, split in [('live-o-axe-contact', 'train'), ('live-o-sword-contact', 'train'),
                        ('live-p-sword-contact', 'train'), ('live-p-axe-contact', 'train'),
                        ('live-o-combo-shield', 'validation')]:
        trace, audit = add_trace(args.base / name, split)
        dataset['trajectories'].append(trace)
        audits.append(audit)
    dataset['parentDatasetSha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    dataset['selfImitationPurpose'] = 'Native successful sword critical paths, actual executed decisions only'
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    args.destination.write_text(json.dumps(dataset, separators=(',', ':')), encoding='utf8')
    args.destination.with_name('audit.json').write_text(json.dumps(audits, indent=2), encoding='utf8')
    print(json.dumps(audits))
