from pathlib import Path
import hashlib,importlib.util,json,os,secrets,shutil,socket,subprocess,time

b=Path(__file__).resolve().parent
s=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
p=b/'isolated-server';p.mkdir(exist_ok=True);(p/'plugins').mkdir(exist_ok=True)
port=25589;rcon_port=25590
for local in (port,rcon_port):
    with socket.socket() as sock:
        if sock.connect_ex(('127.0.0.1',local))==0:raise SystemExit('Isolated port in use; existing process preserved')
for name in ('CommandAPI.jar','ArrowSense.jar','fakeplayer.jar','PvPArenaAI.jar','AuthMe.jar'):
    shutil.copy2(s/'plugins'/name,p/'plugins'/name)
shutil.copy2(b/'WaveDogPracticeLab.jar',p/'plugins/WaveDogPracticeLab.jar')
config=p/'plugins/WaveDogPracticeLab/config.yml';config.parent.mkdir(exist_ok=True);config.write_text((b/'config.yml').read_text(encoding='utf-8').replace('active-arenas: 30','active-arenas: 8'),encoding='utf-8')
shutil.copy2(b/'coach-research-notes.txt',config.parent/'coach-research-notes.txt')
(p/'plugins/WaveDogPracticeLab/status.json').unlink(missing_ok=True)
for folder in ('home','tmp'):(p/folder).mkdir(exist_ok=True)
secret=secrets.token_urlsafe(24)
(p/'eula.txt').write_text('eula=true\n',encoding='ascii')
(p/'server.properties').write_text(f'server-ip=127.0.0.1\nserver-port={port}\nonline-mode=false\nenable-rcon=true\nrcon.port={rcon_port}\nrcon.password={secret}\nmax-players=65\nspawn-protection=0\nview-distance=3\nsimulation-distance=3\nlevel-type=minecraft:flat\ngenerate-structures=false\nspawn-monsters=false\nspawn-animals=false\nspawn-npcs=false\nallow-nether=false\n',encoding='ascii')
runtime_cp=os.pathsep.join(map(str,[s/'versions/1.21.1/paper-1.21.1.jar',*sorted((s/'libraries').rglob('*.jar'))]))
args=['-Xms512M','-Xmx3G','-Duser.home='+str(p/'home'),'-Djava.io.tmpdir='+str(p/'tmp'),'-cp',runtime_cp,'org.bukkit.craftbukkit.Main','--nogui']
(b/'probe.args').write_text('\n'.join('"'+x.replace('\\','\\\\').replace('"','\\"')+'"' for x in args),encoding='utf-8')
spec=importlib.util.spec_from_file_location('rcon','D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py');rcon=importlib.util.module_from_spec(spec);spec.loader.exec_module(rcon)
rcon.PROPERTIES={'rcon.port':str(rcon_port),'rcon.password':secret}
start=time.monotonic();result={'status':'STARTING','main_server_modified':False,'candidate_sha256':hashlib.sha256((b/'WaveDogPracticeLab.jar').read_bytes()).hexdigest()}
out=(p/'console.log').open('wb')
proc=subprocess.Popen([str(s/'runtime/java21/bin/java.exe'),'@'+str(b/'probe.args')],cwd=p,stdout=out,stderr=subprocess.STDOUT,stdin=subprocess.PIPE)
print(json.dumps({'isolated_pid':proc.pid,'port':port,'purpose':'30-cell construction, native input and complete-duel smoke test; not strength/training'},ensure_ascii=False),flush=True)
previous=None
try:
    while time.monotonic()-start<360:
        if proc.poll() is not None:raise RuntimeError('Isolated process stopped early')
        log=(p/'console.log').read_text(encoding='utf-8',errors='replace')
        if 'Laboratory paused after an error' in log:raise RuntimeError(log[log.rfind('Laboratory paused after an error'):][-5000:])
        path=p/'plugins/WaveDogPracticeLab/status.json'
        if path.exists():
            try:data=json.loads(path.read_text(encoding='utf-8'))
            except json.JSONDecodeError:time.sleep(1);continue
            state=(data.get('built'),data.get('active'),data.get('complete_rounds'),round(data.get('mspt',0),1),data.get('neural',{}).get('gradient_updates',0),data.get('llm',{}).get('applied_advice',0))
            if state!=previous:print(json.dumps({'elapsed_seconds':round(time.monotonic()-start,1),'built':state[0],'active':state[1],'complete_rounds':state[2],'mspt':state[3],'neural_updates':state[4],'llm_advice_applied':state[5],'stall_events':data.get('stall_penalty_events',0)},ensure_ascii=False),flush=True);previous=state
            if data.get('failed'):raise RuntimeError('Plugin status failed')
            if data.get('built') and data.get('active',0)>=4 and data.get('complete_rounds',0)>=6 and data.get('neural',{}).get('gradient_updates',0)>=3 and data.get('llm',{}).get('successful_inferences',0)>=2 and data.get('llm',{}).get('applied_advice',0)>=2 and data.get('stall_penalty_events',0)>=1 and data.get('llm',{}).get('shared_review_batches',0)>=1 and time.monotonic()-start>150:
                result.update(status='PASS',snapshot=data);break
        time.sleep(2)
    else:result.update(status='INCOMPLETE',reason='Fixture observations not all satisfied in technical observation window')
except Exception as e:
    result.update(status='FAIL',error=str(e));print(str(e),flush=True)
finally:
    if proc.poll() is None:
        try:rcon.command('pvplab pause');rcon.command('save-all flush');rcon.command('stop')
        except Exception:proc.stdin.write(b'stop\n');proc.stdin.flush()
        proc.wait(timeout=60)
    out.close();result['elapsed_seconds']=time.monotonic()-start;result['normal_exit_code']=proc.returncode
    (b/'probe-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
if result['status']!='PASS':raise SystemExit(1)
