"""Exercise the Arc Vulkan backend on an isolated loopback port."""
from pathlib import Path
import json
import subprocess
import time
import urllib.request

runtime = Path(__file__).resolve().parent / "model-runtime"
executable = runtime / "vulkan/llama-server.exe"
model = runtime / "qwen2.5-1.5b-instruct-q4_k_m.gguf"
log = runtime / "vulkan-test.log"
client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
with log.open("ab") as output:
    process = subprocess.Popen([str(executable), "-m", str(model), "--host", "127.0.0.1",
        "--port", "18766", "-t", "3", "-tb", "3", "-c", "2048", "-np", "1",
        "-ngl", "99", "--alias", "wavedog-tactics-test", "--no-webui"],
        cwd=executable.parent, stdin=subprocess.DEVNULL, stdout=output,
        stderr=subprocess.STDOUT, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
try:
    for _ in range(90):
        if process.poll() is not None:
            raise SystemExit(f"Vulkan server exited {process.returncode}; inspect {log}")
        try:
            with client.open("http://127.0.0.1:18766/health", timeout=2) as response:
                if response.status == 200:
                    break
        except Exception:
            pass
        time.sleep(1)
    else:
        raise SystemExit(f"Vulkan server startup timed out; inspect {log}")
    body = {"model": "wavedog-tactics-test", "max_tokens": 80, "temperature": 0,
        "messages": [{"role": "user", "content": "盾牌成功挡住斧击后，为什么不能把空挥当作命中？用一句话回答。"}]}
    start = time.monotonic()
    request = urllib.request.Request("http://127.0.0.1:18766/v1/chat/completions",
        data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with client.open(request, timeout=120) as response:
        result = json.load(response)
    print(json.dumps({"latencySeconds": round(time.monotonic()-start, 2),
        "reply": result["choices"][0]["message"]["content"],
        "usage": result.get("usage")}, ensure_ascii=False))
finally:
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
