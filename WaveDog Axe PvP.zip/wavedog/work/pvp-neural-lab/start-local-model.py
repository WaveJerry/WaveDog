from pathlib import Path
import json,subprocess,socket,time,urllib.request
b=Path(__file__).resolve().parent;r=b/'model-runtime'
local=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def healthy():
    try:
        with local.open('http://127.0.0.1:18765/health',timeout=2) as response:return response.status==200
    except Exception:return False
if healthy():print('LOCAL_MODEL_READY: existing loopback service');raise SystemExit(0)
manifest=json.loads((r/'manifest.json').read_text(encoding='utf-8'))
exe=r/'llama-server.exe'
model=r/manifest.get('active_model_path','qwen2.5-1.5b-instruct-q4_k_m.gguf')
if not model.is_file():raise SystemExit('Model missing: run setup-local-model.py first')
sock=socket.socket();occupied=sock.connect_ex(('127.0.0.1',18765))==0;sock.close()
if occupied:raise SystemExit('Port18765 belongs to another/unready service; preserved it')
out=(r/'server.log').open('ab')
proc=subprocess.Popen([str(exe),'-m',str(model),'--host','127.0.0.1','--port','18765',
                       '-t',str(manifest.get('threads',3)),'-tb',str(manifest.get('batch_threads',3)),
                       '-c',str(manifest.get('context_tokens',12288)),'-np','1',
                       '--alias','wavedog-tactics','--no-webui'],cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));out.close()
for _ in range(90):
    if proc.poll() is not None:raise SystemExit('Local model process exited; inspect model-runtime/server.log')
    if healthy():
        manifest['pid']=proc.pid;(r/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('LOCAL_MODEL_READY pid='+str(proc.pid));break
    time.sleep(1)
else:raise SystemExit('Local model readiness timed out; process preserved for diagnosis')
