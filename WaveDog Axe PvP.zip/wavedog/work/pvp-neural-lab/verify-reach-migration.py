"""Verify exact 96/97-input GRU64 plus Adam migration to reach-margin input."""
from pathlib import Path
import os
import subprocess

base = Path(__file__).resolve().parent
server = Path("D:/Walt Disney/Minecraft-1.21.1-Server")
tests = base / "test-classes"
tests.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, [base / "classes",
    server / "versions/1.21.1/paper-1.21.1.jar",
    *sorted((server / "libraries").rglob("*.jar"))]))
source = base / "tests/local/wavedog/lab/RecurrentCueMigrationCheck.java"
arrow_source = base / "tests/local/wavedog/lab/ArrowDodgePredictionCheck.java"
javac = server / "runtime/java21/bin/javac.exe"
java = server / "runtime/java21/bin/java.exe"
subprocess.run([str(javac), "-proc:none", "-encoding", "UTF-8", "--release", "21",
    "-cp", classpath, "-d", str(tests), str(source), str(arrow_source)], check=True)
subprocess.run([str(java), "-cp", str(tests) + os.pathsep + classpath,
    "local.wavedog.lab.RecurrentCueMigrationCheck"], check=True, timeout=100)
subprocess.run([str(java), "-cp", str(tests) + os.pathsep + classpath,
    "local.wavedog.lab.ArrowDodgePredictionCheck"], check=True, timeout=100)
