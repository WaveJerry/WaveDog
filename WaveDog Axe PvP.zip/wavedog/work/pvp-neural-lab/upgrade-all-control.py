from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'src/local/wavedog/lab/DuelPolicy.java';s=p.read_text(encoding='utf-8')
s=s.replace('boolean flightLook,String skill,String reason) {}','boolean flightLook,String skill,String reason,boolean sneak) {}')
s=s.replace('slot,use,release,flight,skill,reason);','slot,use,release,flight,skill,reason,false);')
p.write_text(s,encoding='utf-8')
p=b/'src/local/wavedog/lab/LivePracticeLab.java';s=p.read_text(encoding='utf-8')
s=s.replace('NeuralFootwork.Actor neural;','CombatLearner.Actor neural;')
s=s.replace('NeuralFootwork neural;TacticalModel tactics;','CombatLearner neural;TacticalModel tactics;')
s=s.replace('neural=new NeuralFootwork(','neural=new CombatLearner(')
old='''                int group=(l.cell.id()+l.round+(f==l.a?0:1))%4;f.arm=new String[]{"SCRIPT","NEURAL","LLM","HYBRID"}[group];
                f.neural=neural!=null&&(group==1||group==3)?neural.actor(81239L*l.round+f.name.hashCode()):null;
                f.tactical=tactics!=null&&(group==2||group==3)?tactics.agent():null;f.policy.tactics=f.tactical;'''
new='''                f.arm="ALL_INPUT_RL_QWEN";
                f.neural=neural!=null?neural.actor(81239L*l.round+f.name.hashCode(),(f==l.a)==(l.round%2==1)):null;
                f.tactical=tactics!=null?tactics.agent(f.name):null;f.policy.tactics=f.tactical;'''
assert old in s,'group anchor missing';s=s.replace(old,new)
old='''        var action=f.policy.decide(tick,tick+f.delay(),self);
        if(f.neural!=null)action=f.neural.apply(tick,self,f.policy.seen,l.cell,f.policy.actingStyle,action);f.inputs.add(action);'''
new='''        f.policy.actingStyle=f.tactical==null?f.policy.style:f.tactical.update(tick,self,f.policy.seen,l.cell,f.policy.style);
        var action=f.neural!=null?f.neural.act(tick,tick+f.delay(),self,f.policy.seen,l.cell,f.policy.actingStyle,p.getYaw(),p.getPitch()):f.policy.decide(tick,tick+f.delay(),self);
        f.inputs.add(action);'''
assert old in s,'decision anchor missing';s=s.replace(old,new)
s=s.replace('p.setRotation(a.yaw(),a.pitch());','p.setRotation(a.yaw(),a.pitch());p.setSneaking(a.sneak());')
s=s.replace('if(a.flightLook()){p.setRotation(priorYaw,priorPitch);p.setSprinting(priorSprint);}','if(a.flightLook()){p.setRotation(priorYaw,priorPitch);ClientMovementInput.apply(p,bridge,a.forward(),a.side(),priorSprint);}')
s=s.replace('四组对照：脚本、神经走位、LLM战术、神经+LLM；模型效果待实测','全员动作强化学习+共享Qwen指导；每组轮换一方更新；尚在初始化与训练')
s=s.replace('four-arm ablation: scripts, episodic neural footwork, asynchronous local LLM tactics, hybrid; no visual/audio','all-input learned policy and shared Qwen coach; one learner per pair, alternating by bout; learned API observation encoding, no image/audio')
s=s.replace('§e四组对照：脚本/神经走位/LLM战术/混合。原生格斗独立执行；尚无画面声音输入。','§e全员动作强化学习+共享Qwen；每组轮换一方学习，赛后交流。还不是画面声音感知。')
s=s.replace('record(judge,"round_end",row);recent.add(row);','row.put("loser_hits",loser.hits);row.put("loser_crits",loser.crits);row.put("nominal_rtt_ms",winner.delayMs);row.put("learner",l.a.neural!=null&&l.a.neural.learning?l.a.name:l.b.name);record(judge,"round_end",row);if(tactics!=null)tactics.completedBout(row);recent.add(row);')
s=s.replace('data.put("neural_training",neural!=null);','data.put("all_agents_learned_controls",true);data.put("target_pairs",desired);data.put("max_players",Bukkit.getMaxPlayers());data.put("neural_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.neural!=null).count());data.put("llm_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.tactical!=null).count());data.put("neural_training",neural!=null);')
# Damage is a training reward recorded after adjudication; it is never an observation for actions.
anchor='''            for(var f:List.of(l.a,l.b))if(e.getDamager().equals(f.player)&&e.getFinalDamage()>0)'''
addition='''            Object source=e.getDamager() instanceof org.bukkit.entity.Projectile arrow?arrow.getShooter():e.getDamager();
            for(var f:List.of(l.a,l.b))if(f.neural!=null)f.neural.outcomeFeedback(source==f.player?e.getFinalDamage():0,e.getEntity()==f.player?e.getFinalDamage():0);
'''
assert anchor in s;s=s.replace(anchor,addition+anchor)
p.write_text(s,encoding='utf-8')
p=b/'src/local/wavedog/lab/TacticalModel.java';s=p.read_text(encoding='utf-8')
s=s.replace('final AtomicLong succeeded=', 'final SharedCoachMemory memory;\n    final AtomicLong succeeded=')
s=s.replace('journal=dir.resolve("llm-tactics.jsonl");','journal=dir.resolve("llm-tactics.jsonl");memory=new SharedCoachMemory(dir);')
s=s.replace('new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(8)','new ThreadPoolExecutor(2,2,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64)')
s=s.replace('Agent agent(){return new Agent();}','Agent agent(){return agent("test-agent");}\n    Agent agent(String name){memory.registered.add(name);return new Agent(name);}')
s=s.replace('volatile DuelPolicy.Style advice;', 'final String name;Agent(String name){this.name=name;var prior=memory.advice.get(name);if(prior!=null)try{advice=DuelPolicy.Style.valueOf(prior.get("style").getAsString());reason=prior.get("reason").getAsString();}catch(Exception ignored){}}\n        volatile DuelPolicy.Style advice;')
s=s.replace('if(!active)return;var result=infer(payload);','var request=new LinkedHashMap<String,Object>(payload);request.put("coach_research_notes",memory.notes);request.put("shared_completed_bout_lessons",memory.lessonSnapshot());request.put("agent",name);var result=infer(request);memory.remember(name,result);')
s=s.replace('void close(){active=false;version++;}','void close(){active=false;version++;}')
s=s.replace('Strategies: DEFENSIVE','Axes and swords are melee weapons, not ranged. All styles train every input. Some requests are completed post-bout reviews: summarize a cautious testable lesson, not a universal style ranking. Strategies: DEFENSIVE')
s=s.replace('Files.writeString(journal,JSON.toJson(', 'synchronized(memory){Files.writeString(journal,JSON.toJson(')
s=s.replace('StandardOpenOption.APPEND);return result;', 'StandardOpenOption.APPEND);}return result;')
old='''    Map<String,Object> status(){return Map.of("enabled",true,"provider","local Qwen2.5-1.5B-Instruct Q4_K_M","successful_inferences",succeeded.get(),"applied_advice",applied.get(),"failed_requests",failed.get(),"queued",worker.getQueue().size(),"last_error",lastError,"stall_feedbacks",stallFeedbacks.get());}'''
new='''    void completedBout(Map<String,Object> report)throws Exception{memory.completed(report);if(memory.reviewPending||memory.reports.size()<6)return;var batch=memory.takeBatch();try{worker.execute(()->{try{var lesson=infer(Map.of("mode","completed_post_bout_review","completed_bouts",batch,"instruction","Choose a style worth testing next and make reason a cautious evidence-based lesson. Do not invent criticals or trajectories.","coach_research_notes",memory.notes));memory.addLesson(lesson);}catch(Exception e){failed.incrementAndGet();lastError=e.toString();}finally{memory.reviewPending=false;}});}catch(RejectedExecutionException e){memory.restoreBatch(batch);}}
    Map<String,Object> status(){var out=new LinkedHashMap<String,Object>();out.put("enabled",true);out.put("provider","shared local Qwen2.5-1.5B-Instruct Q4_K_M");out.put("successful_inferences",succeeded.get());out.put("applied_advice",applied.get());out.put("failed_requests",failed.get());out.put("queued",worker.getQueue().size());out.put("last_error",lastError);out.put("stall_feedbacks",stallFeedbacks.get());out.putAll(memory.status());return out;}'''
assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=b/'plugin.yml';p.write_text(p.read_text(encoding='utf-8').replace('version: 0.2.1','version: 0.3.0'),encoding='utf-8')
p=b/'install-and-start.py';s=p.read_text(encoding='utf-8');anchor='for rel,sha in unchanged.items():'
assert anchor in s;s=s.replace(anchor,"shutil.copy2(b/'coach-research-notes.txt',config.parent/'coach-research-notes.txt')\n"+anchor)
s=s.replace("s/'plugins/WaveDogPracticeLab/models/footwork.json',","s/'plugins/WaveDogPracticeLab/models/footwork.json',s/'plugins/WaveDogPracticeLab/models/combat-policy.json',s/'plugins/WaveDogPracticeLab/shared-learning.json',")
p.write_text(s,encoding='utf-8')
p=b/'probe.py';s=p.read_text(encoding='utf-8').replace('while time.monotonic()-start<210:','while time.monotonic()-start<360:')
s=s.replace("(p/'plugins/WaveDogPracticeLab/status.json').unlink(missing_ok=True)","shutil.copy2(b/'coach-research-notes.txt',config.parent/'coach-research-notes.txt')\n(p/'plugins/WaveDogPracticeLab/status.json').unlink(missing_ok=True)")
s=s.replace("and data.get('stall_penalty_events',0)>=1 and time.monotonic()-start>150:","and data.get('stall_penalty_events',0)>=1 and data.get('llm',{}).get('shared_review_batches',0)>=1 and time.monotonic()-start>150:")
p.write_text(s,encoding='utf-8')
print('ALL_INPUT_RL_PRIVATE_ACTORS_SHARED_QWEN_WIRED')
