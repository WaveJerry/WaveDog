"""Download and verify official Qwen2.5 7B GGUF shards without touching the live model."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import math
import shutil
import socket
import threading
import time
import urllib.request

base = Path(__file__).resolve().parent / "model-runtime"
target = base / "qwen2.5-7b"
target.mkdir(exist_ok=True)
model_id = "Qwen/Qwen2.5-7B-Instruct-GGUF"
prefix = "qwen2.5-7b-instruct-q4_k_m-"
sock = socket.socket()
proxy = sock.connect_ex(("127.0.0.1", 10808)) == 0
sock.close()
opener = urllib.request.build_opener(urllib.request.ProxyHandler(
    {"http": "http://127.0.0.1:10808", "https": "http://127.0.0.1:10808"} if proxy else {}))

def open_url(url, headers=None):
    return opener.open(urllib.request.Request(url, headers=headers or {}), timeout=90)

with open_url(f"https://huggingface.co/api/models/{model_id}/tree/main") as response:
    listing = json.load(response)
shards = sorted((row for row in listing if row.get("path", "").startswith(prefix)),
                key=lambda row: row["path"])
if len(shards) != 2:
    raise SystemExit(f"Expected two official GGUF shards, found {len(shards)}")

manifest = []
for row in shards:
    name = row["path"]
    expected = row["lfs"]["oid"]
    size = row["size"]
    destination = target / name
    partial = target / (name + ".partial")
    parallel = target / (name + ".parallel")
    state_file = target / (name + ".parallel.json")
    if not destination.exists() or destination.stat().st_size != size:
        chunk_size = 64 * 1024 * 1024
        chunks = math.ceil(size / chunk_size)
        if parallel.exists() and state_file.exists():
            completed = set(json.loads(state_file.read_text(encoding="utf-8"))["completed"])
        else:
            completed = set()
            with parallel.open("wb") as output:
                if partial.exists():
                    prefix = min(partial.stat().st_size // chunk_size, chunks) * chunk_size
                    with partial.open("rb") as source:
                        shutil.copyfileobj(source, output, 1024 * 1024)
                    completed.update(range(prefix // chunk_size))
                output.truncate(size)
            state_file.write_text(json.dumps({"completed": sorted(completed)}), encoding="utf-8")
        lock = threading.Lock()
        url = f"https://huggingface.co/{model_id}/resolve/main/{name}"
        def fetch_chunk(index):
            start = index * chunk_size
            end = min(size, start + chunk_size) - 1
            for attempt in range(16):
                try:
                    headers = {"User-Agent": "WaveDog-local-Qwen-upgrade",
                               "Range": f"bytes={start}-{end}"}
                    with open_url(url, headers) as response:
                        content_range = response.headers.get("Content-Range", "")
                        if response.status != 206 or not content_range.startswith(f"bytes {start}-{end}/"):
                            raise OSError(f"Unexpected range response {response.status} {content_range}")
                        received = 0
                        with parallel.open("r+b") as output:
                            output.seek(start)
                            while received < end - start + 1:
                                block = response.read(min(1024 * 1024, end - start + 1 - received))
                                if not block:
                                    raise OSError("Unexpected end of range")
                                output.write(block)
                                received += len(block)
                    with lock:
                        completed.add(index)
                        temporary = state_file.with_suffix(".json.tmp")
                        temporary.write_text(json.dumps({"completed": sorted(completed)}), encoding="utf-8")
                        temporary.replace(state_file)
                        if len(completed) % 8 == 0 or len(completed) == chunks:
                            print(json.dumps({"shard": name, "chunks": len(completed),
                                              "totalChunks": chunks}), flush=True)
                    return
                except (TimeoutError, OSError) as error:
                    if attempt == 15:
                        raise
                    time.sleep(min(10, attempt + 1))
        with ThreadPoolExecutor(max_workers=6) as pool:
            for future in as_completed([pool.submit(fetch_chunk, index)
                                        for index in range(chunks) if index not in completed]):
                future.result()
        with parallel.open("rb") as source:
            actual = hashlib.file_digest(source, "sha256").hexdigest()
        if actual != expected:
            raise SystemExit(f"Official SHA256 mismatch: {name}")
        parallel.replace(destination)
        state_file.unlink(missing_ok=True)
        partial.unlink(missing_ok=True)
    with destination.open("rb") as source:
        actual = hashlib.file_digest(source, "sha256").hexdigest()
    if actual != expected:
        raise SystemExit(f"Official SHA256 mismatch: {name}")
    manifest.append({"file": name, "bytes": size, "sha256": actual})
    print(json.dumps({"verified": name, "bytes": size}), flush=True)
(target / "manifest.json").write_text(json.dumps({"model": model_id, "shards": manifest}, indent=2), encoding="utf-8")
print(json.dumps({"ready": str(target / shards[0]["path"]), "totalBytes": sum(x["bytes"] for x in manifest)}))
