from pathlib import Path
import hashlib,importlib.util,json,os,shutil,socket,subprocess,time,sys

b=Path(__file__).resolve().parent;s=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
candidate=b/'WaveDogPracticeLab.jar';digest=hashlib.sha256(candidate.read_bytes()).hexdigest()
seed=b/'recurrent-seed/recurrent-ppo.json'
if not seed.exists():raise SystemExit('FAILED: validated recurrent policy seed missing; main preserved')
supervised='--main-supervised-test' in sys.argv
if supervised:
    tests=json.loads((b/'all-control-test-result.json').read_text(encoding='utf-8'))
    if tests.get('status')!='PASS' or tests.get('candidate_sha256')!=digest or tests.get('recurrent_seed_sha256')!=hashlib.sha256(seed.read_bytes()).hexdigest():raise SystemExit('FAILED: This candidate and recurrent seed have not passed model checks')
else:
    probe=json.loads((b/'probe-result.json').read_text(encoding='utf-8'))
    if probe.get('status')!='PASS' or probe.get('candidate_sha256')!=digest:raise SystemExit('FAILED: This exact candidate has not passed the isolated native test')
with socket.socket() as sock:
    if sock.connect_ex(('127.0.0.1',25566))==0:raise SystemExit('FAILED: Main server already running; preserved it. Stop normally before installing')
stamp=time.strftime('%Y%m%d-%H%M%S');backup=b/'main-backups'/stamp;backup.mkdir(parents=True)
destination=s/'plugins/WaveDogPracticeLab.jar'
lab_data=s/'plugins/WaveDogPracticeLab'
training_files=[lab_data/'models/footwork.json',lab_data/'models/combat-policy.json',lab_data/'models/recurrent-ppo.json',lab_data/'shared-learning.json',lab_data/'completed-learning-reports.jsonl',lab_data/'coach-lessons.jsonl']
training_hashes={str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in training_files if p.exists()}
for p in [s/'server.properties',destination,lab_data/'config.yml',*training_files,lab_data/'coach-experience-library.json',lab_data/'coach-research-notes.txt',lab_data/'coach-briefing-core.txt',lab_data/'coach-reference-20261111.md',lab_data/'qwen-conversations.jsonl',lab_data/'llm-tactics.jsonl',lab_data/'每轮对战.txt',s/'world/level.dat',s/'world/level.dat_old',*[s/'world'/folder/f'r.2.{z}.mca' for folder in ('region','entities','poi') for z in (1,2)]]:
    if p.exists():
        out=backup/p.relative_to(s);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
unchanged={str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [s/'plugins/PvPArenaAI.jar',s/'plugins/fakeplayer.jar',*list((s/'plugins/PvPArenaAI').glob('*.yml'))] if p.is_file()}
properties=s/'server.properties';lines=properties.read_text(encoding='utf-8').splitlines();seen=False
for i,line in enumerate(lines):
    if line.startswith('max-players='):lines[i]='max-players=65';seen=True
if not seen:lines.append('max-players=65')
properties.write_text('\n'.join(lines)+'\n',encoding='utf-8')
shutil.copy2(candidate,destination)
config=s/'plugins/WaveDogPracticeLab/config.yml';config.parent.mkdir(parents=True,exist_ok=True)
if not config.exists():shutil.copy2(b/'config.yml',config)
else:
    cfg=config.read_text(encoding='utf-8');cfg=cfg.replace('active-arenas: 18','active-arenas: 30').replace('physics-audit: false','physics-audit: true');cfg+='\nphysics-audit: true\n' if 'physics-audit:' not in cfg else '';config.write_text(cfg,encoding='utf-8')
if not (config.parent/'coach-research-notes.txt').exists():shutil.copy2(b/'coach-research-notes.txt',config.parent/'coach-research-notes.txt')
shutil.copy2(b/'coach-briefing-core.txt',config.parent/'coach-briefing-core.txt')
shutil.copy2(b/'coach-reference-20261111.md',config.parent/'coach-reference-20261111.md')
seed_cards=json.loads((b/'coach-experience-library.json').read_text(encoding='utf-8'))
library=config.parent/'coach-experience-library.json'
if library.exists():
    current=json.loads(library.read_text(encoding='utf-8'))
    ids={card['id'] for card in current['cards']}
    for card in seed_cards['cards']:
        if card['id'] not in ids:current['cards'].append(card);ids.add(card['id'])
    library.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
else:shutil.copy2(b/'coach-experience-library.json',library)
model=config.parent/'models/recurrent-ppo.json';model.parent.mkdir(exist_ok=True)
if not model.exists():shutil.copy2(seed,model)
for rel,sha in unchanged.items():
    if hashlib.sha256((s/rel).read_bytes()).hexdigest()!=sha:raise SystemExit('FAILED: Existing AI asset unexpectedly changed: '+rel)
for rel,sha in training_hashes.items():
    if hashlib.sha256((s/rel).read_bytes()).hexdigest()!=sha:raise SystemExit('FAILED: Training data unexpectedly changed: '+rel)
logs=b/'main-console';logs.mkdir(exist_ok=True);log=logs/(stamp+'.log');out=log.open('wb')
# Keep the server working directory and existing proxy choices; route new home/temp data to D.
runtime=b/'main-runtime';runtime.mkdir(exist_ok=True);(runtime/'home').mkdir(exist_ok=True);(runtime/'tmp').mkdir(exist_ok=True)
args=[str(s/'runtime/java21/bin/java.exe'),'-Xms512M','-Xmx3G','-Duser.home='+str(runtime/'home'),'-Djava.io.tmpdir='+str(runtime/'tmp'),'-Dhttp.proxyHost=127.0.0.1','-Dhttp.proxyPort=10808','-Dhttps.proxyHost=127.0.0.1','-Dhttps.proxyPort=10808','-jar',str(s/'server.jar'),'--nogui']
proc=subprocess.Popen(args,cwd=s,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));out.close()
receipt={'pid':proc.pid,'candidate_sha256':digest,'backup':str(backup),'console':str(log),'server':str(s),'max_players':65,'arena_count':30,'target_parallel_pairs':30,'supervised_main_test':supervised,'main_ai_assets_preserved':unchanged,'training_data_preserved':training_hashes,'experience_cards':len(json.loads(library.read_text(encoding='utf-8'))['cards'])}
(b/'main-install.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False),flush=True)
spec=importlib.util.spec_from_file_location('rcon','D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py');rcon=importlib.util.module_from_spec(spec);spec.loader.exec_module(rcon)
for attempt in range(90):
    if proc.poll() is not None:raise SystemExit('FAILED: Main process exited; inspect '+str(log))
    try:
        response=rcon.command('list')
        if response:
            print('MAIN_SERVER_READY: 127.0.0.1:25566; max players 65; arena construction/activation follows',flush=True)
            print(rcon.command('pvplab status'),flush=True)
            break
    except (OSError,TimeoutError,ConnectionError):pass
    time.sleep(2)
else:raise SystemExit('FAILED: Main readiness timeout; process preserved for diagnosis')
print('DONE: use /pvplab watch 1; /pvplab status; /pvplab pause',flush=True)
