"""Evaluate the current saved policy without writing to the checkpoint."""
from pathlib import Path
import os
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
checkpoint = base.parent / 'pvp-player-client/new-learning/models'
classes = base / 'test-classes'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, [base / 'classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    *sorted((server / 'libraries').rglob('*.jar'))]))
source = base / 'tests/local/wavedog/lab/JumpPolicyProbe.java'
subprocess.run([str(server / 'runtime/java21/bin/javac.exe'), '-proc:none',
    '-encoding', 'UTF-8', '--release', '21', '-cp', classpath,
    '-d', str(classes), str(source)], check=True)
subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp',
    str(classes) + os.pathsep + classpath,
    'local.wavedog.lab.JumpPolicyProbe', str(checkpoint)], check=True)
