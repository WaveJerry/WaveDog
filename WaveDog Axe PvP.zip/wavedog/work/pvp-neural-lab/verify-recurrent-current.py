"""Run current GRU/PPO tests in a fresh output directory without old seed assumptions."""
from pathlib import Path
import os
import subprocess
import time

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
tests = base / 'test-classes'
tests.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, [base / 'classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    *sorted((server / 'libraries').rglob('*.jar'))]))
javac = server / 'runtime/java21/bin/javac.exe'
java = server / 'runtime/java21/bin/java.exe'
source = base / 'tests/local/wavedog/lab/RecurrentPpoTests.java'
subprocess.run([str(javac), '-proc:none', '-encoding', 'UTF-8', '--release', '21',
    '-cp', classpath, '-d', str(tests), str(source)], check=True)
output = base / 'test-model-output' / ('control-chain-' + str(int(time.time())))
subprocess.run([str(java), '-cp', str(tests) + os.pathsep + classpath,
    'local.wavedog.lab.RecurrentPpoTests', 'test', str(output)], check=True,
    timeout=100)
print('GRU_TEST_OUTPUT=' + str(output))
