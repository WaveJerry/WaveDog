from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'src/local/wavedog/lab/LivePracticeLab.java';s=p.read_text(encoding='utf-8')
s=s.replace('final ArenaLayout.Cell cell;final Fighter a,b;int round,prepareStage;', 'final ArenaLayout.Cell cell;final Fighter a,b;StallPenaltyClock stall;int round,prepareStage;')
s=s.replace('World world;long tick,', 'long stallEvents;\n    World world;long tick,')
s=s.replace('l.preparing=false;l.fighting=true;l.started=tick;', 'l.preparing=false;l.fighting=true;l.started=tick;l.stall=new StallPenaltyClock(System.nanoTime());')
needle='observe(l.a,l.b);observe(l.b,l.a);decide(l,l.a);decide(l,l.b);'
assert needle in s
s=s.replace(needle,'int due=l.stall.poll(System.nanoTime());for(int n=0;n<due;n++)penalizeStall(l);\n            '+needle)
needle='    void observe(Fighter f,Fighter target)throws Exception{'
addition='''    void penalizeStall(Lane l)throws Exception{
        stallEvents++;
        for(var f:List.of(l.a,l.b)){
            if(f.neural!=null)f.neural.penalizeStall();
            if(f.tactical!=null)f.tactical.penalizeStall();
            record(inputs,"reward_feedback",Map.of("fighter",f.name,"reward",-StallPenaltyClock.PENALTY,"reason","stall_120_seconds","penalty_count",l.stall.count));
        }
        record(judge,"stall_penalty",Map.of("arena",l.cell.id()+1,"round",l.round,"seconds",l.stall.seconds(System.nanoTime()),"penalty_count",l.stall.count,"reward_each",-StallPenaltyClock.PENALTY,"a",l.a.name,"b",l.b.name));
        text.write("僵持惩罚／场地 "+(l.cell.id()+1)+"／本场第 "+l.round+" 局：已持续 "+String.format(Locale.ROOT,"%.1f",l.stall.seconds(System.nanoTime()))+" 秒，双方各扣 "+StallPenaltyClock.PENALTY+" 训练奖励（第 "+l.stall.count+" 次）；比赛继续，不扣游戏血量。\\n");
    }
'''
assert needle in s;s=s.replace(needle,addition+needle)
s=s.replace('row.put("winner_arm",winner.arm);', 'row.put("stall_penalties",l.stall.count);row.put("stall_reward_each",l.stall.totalReward());row.put("winner_arm",winner.arm);')
s=s.replace('data.put("neural_training",neural!=null);','data.put("stall_penalty_events",stallEvents);data.put("stall_penalty_seconds",120);data.put("stall_reward_each",-StallPenaltyClock.PENALTY);data.put("neural_training",neural!=null);')
s=s.replace('sender.sendMessage("Neural: "+', 'sender.sendMessage("Stall penalty: 120 seconds, reward=-0.25 each, events="+stallEvents);sender.sendMessage("Neural: "+')
p.write_text(s,encoding='utf-8')
p=b/'src/local/wavedog/lab/NeuralFootwork.java';s=p.read_text(encoding='utf-8').replace('final List<Sample> episode=new ArrayList<>();','final ArrayDeque<Sample> episode=new ArrayDeque<>();').replace('if(episode.size()<512)episode.add(new Sample(x,mask,action,self.health()));','if(episode.size()>=512)episode.removeFirst();episode.addLast(new Sample(x,mask,action,self.health()));');p.write_text(s,encoding='utf-8')
p=b/'plugin.yml';p.write_text(p.read_text(encoding='utf-8').replace('version: 0.2.0','version: 0.2.1'),encoding='utf-8')
p=b/'tests/local/wavedog/lab/NeuralLabTests.java';s=p.read_text(encoding='utf-8');needle='        var llm=new TacticalModel(folder,'
add='''        var clock=new StallPenaltyClock(5000);check(clock.poll(5000+119_999_999_999L)==0,"penalty before120seconds");check(clock.poll(5000+120_000_000_000L)==1,"no penalty at120seconds");check(clock.poll(5000+120_000_000_001L)==0,"duplicate penalty");check(clock.poll(5000+240_000_000_000L)==1,"no repeated120second penalty");check(clock.totalReward()==-.5,"wrong accumulated punishment");
        var punished=new NeuralFootwork(folder.resolve("penalty-test"));var punishedActor=punished.actor(7);double[] start=punished.state.w.clone();punished.state.baseline=-10;
        boolean[] all=new boolean[NeuralFootwork.A];Arrays.fill(all,true);double before=NeuralFootwork.probabilities(start,features,all)[0];
        for(int i=0;i<10;i++)punishedActor.episode.add(new NeuralFootwork.Sample(features,all,0,20));punishedActor.penalizeStall();punished.close();
        double after=NeuralFootwork.probabilities(punished.state.w,features,all)[0];check(after<before,"negative baseline turned punishment into reward");check(punished.state.episodes==0&&punished.state.penaltyUpdates==1,"stall fabricated a completed episode");check(punishedActor.episode.isEmpty(),"penalty samples reused twice");
'''
assert needle in s;s=s.replace(needle,add+needle);p.write_text(s,encoding='utf-8')
p=b/'probe.py';s=p.read_text(encoding='utf-8').replace("and time.monotonic()-start>85:","and data.get('stall_penalty_events',0)>=1 and time.monotonic()-start>150:");s=s.replace("'llm_advice_applied':state[5]","'llm_advice_applied':state[5],'stall_events':data.get('stall_penalty_events',0)");p.write_text(s,encoding='utf-8')
print('STALL_PENALTY_WIRED')
