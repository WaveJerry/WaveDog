package local.wavedog.lab;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;

final class ArenaLayout {
    static final int COLUMNS=6, ROWS=5, COUNT=30, STEP=32, X=1042, Z=944, FLOOR=220;
    record Cell(int id,int minX,int minZ) {
        int maxX(){return minX+STEP;} int maxZ(){return minZ+STEP;}
        double cx(){return minX+16.5;} double cz(){return minZ+16.5;}
        boolean contains(double x,double y,double z){return x>minX&&x<maxX()+1&&z>minZ&&z<maxZ()+1&&y>=FLOOR+.9&&y<FLOOR+8;}
        Location start(World world,boolean a){return new Location(world,cx(),FLOOR+1,cz()+(a?-3:3),a?0:180,0);}
        Location watch(World world){return new Location(world,cx(),FLOOR+12,cz()-7,0,55);}
        double margin(double x,double z){return Math.min(Math.min(x-minX-1,maxX()-x),Math.min(z-minZ-1,maxZ()-z));}
    }
    static List<Cell> cells(){var list=new ArrayList<Cell>();for(int r=0;r<ROWS;r++)for(int c=0;c<COLUMNS;c++)list.add(new Cell(r*COLUMNS+c,X+c*STEP,Z+r*STEP));return List.copyOf(list);}
    static boolean inside(double x,double y,double z){return x>=X&&x<=X+COLUMNS*STEP&&z>=Z&&z<=Z+ROWS*STEP&&y>=FLOOR-1&&y<=FLOOR+9;}
}
