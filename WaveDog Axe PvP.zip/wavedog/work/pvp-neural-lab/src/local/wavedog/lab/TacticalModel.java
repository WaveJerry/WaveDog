package local.wavedog.lab;

import com.google.gson.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.Supplier;

/** Async local LLM receives only the owning controller's delayed public observations. */
final class TacticalModel implements AutoCloseable {
    static final Gson JSON=new Gson();
    final ThreadPoolExecutor worker;final HttpClient client;final URI endpoint;final Path journal;
    final SharedCoachMemory memory;final ExperienceLibrary experiences;volatile Supplier<Map<String,Object>> trainingProgress=Map::of;
    final CoachRequestGate liveRequestGate=new CoachRequestGate(TimeUnit.SECONDS.toNanos(15),TimeUnit.MINUTES.toNanos(20));
    final AtomicLong succeeded=new AtomicLong(),failed=new AtomicLong(),applied=new AtomicLong(),stallFeedbacks=new AtomicLong();volatile String lastError="";
    static final String PROMPT="You coach Minecraft Java 1.21.1 PvP. Use only own state and delayed visible opponent history; never hidden health, keys, recharge or future moves. Six styles rotate across bouts; the assigned style stays fixed during each bout. An occasional curriculum bout compares AGGRESSIVE with DEFENSIVE shield-counter/escape. In completed reviews, style=AGGRESSIVE or DEFENSIVE chooses which side learns next and focus chooses its topic; other styles still rotate. Use measured swing and whiff rates to identify wasted attacks, and low-charge counts to consider charge discipline; do not infer causes from these totals alone. Every attack swing, including a miss, resets own charge; prefer high charge for ordinary damage while retaining necessary light hits. Experience cards and completed-bout lessons are testable hypotheses, not action rules. Focus labels condition a separate GRU combat policy; text does not update its weights or your weights. That policy selects all game inputs. For completed reviews, compress the previous short lesson and new evidence into a concise reusable phrase; keep only supported observations, not a causal style ranking. Return style, focus and a reason in at most12words. You issue no direct game inputs.";
    record CurriculumPlan(boolean aggressiveLearns,ExperienceLibrary.Focus focus,String reason){}
    CurriculumPlan curriculumPlan(){var lessons=memory.lessonSnapshot();if(lessons.isEmpty())return new CurriculumPlan(true,ExperienceLibrary.Focus.OPPONENT,"initial aggressive versus shield-counter escape comparison");var last=lessons.getLast();try{return new CurriculumPlan(!"DEFENSIVE".equals(last.get("style").getAsString()),ExperienceLibrary.Focus.valueOf(last.get("focus").getAsString()),last.get("reason").getAsString());}catch(Exception ignored){return new CurriculumPlan(true,ExperienceLibrary.Focus.OPPONENT,"invalid prior lesson; balanced default");}}
    static final class CoachRequestGate {
        final long globalInterval,agentInterval;Long nextGlobal;final Map<String,Long> nextAgent=new HashMap<>();
        CoachRequestGate(long globalInterval,long agentInterval){this.globalInterval=globalInterval;this.agentInterval=agentInterval;}
        synchronized boolean allow(String name,long now){Long own=nextAgent.get(name);if((nextGlobal!=null&&now-nextGlobal<0)||(own!=null&&now-own<0))return false;nextGlobal=now+globalInterval;nextAgent.put(name,now+agentInterval);return true;}
    }
    TacticalModel(Path dir,String endpoint)throws Exception{
        this.endpoint=URI.create(endpoint);if(!List.of("127.0.0.1","localhost").contains(this.endpoint.getHost()))throw new IllegalArgumentException("Local-only LLM endpoint required");
        journal=dir.resolve("llm-tactics.jsonl");memory=new SharedCoachMemory(dir);experiences=new ExperienceLibrary(dir);if(Files.exists(journal))try(var lines=Files.lines(journal)){succeeded.set(lines.count());}
        worker=new ThreadPoolExecutor(2,2,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),r->{var t=new Thread(r,"WaveDog-local-LLM");t.setDaemon(true);return t;},new ThreadPoolExecutor.AbortPolicy());
        client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).proxy(new ProxySelector(){public List<Proxy> select(URI u){return List.of(Proxy.NO_PROXY);}public void connectFailed(URI u,SocketAddress a,java.io.IOException e){}}).build();
    }
    Agent agent(){return agent("test-agent");}
    Agent agent(String name){memory.registered.add(name);return new Agent(name);}
    final class Agent {
        final String name;Agent(String name){this.name=name;var prior=memory.advice.get(name);if(prior!=null)try{advice=DuelPolicy.Style.valueOf(prior.get("style").getAsString());reason=prior.get("reason").getAsString();if(prior.has("focus"))focus=ExperienceLibrary.Focus.valueOf(prior.get("focus").getAsString());}catch(Exception ignored){}}
        volatile DuelPolicy.Style advice;volatile ExperienceLibrary.Focus focus=ExperienceLibrary.Focus.FREE;volatile String reason="";volatile boolean active=true;volatile long version;volatile boolean pending;long next;int stallWarnings;final ArrayDeque<Map<String,Object>> history=new ArrayDeque<>();
        DuelPolicy.Style update(long tick,DuelPolicy.Self self,DuelPolicy.Seen seen,ArenaLayout.Cell cell,DuelPolicy.Style fallback){
            if(!active||seen==null||!seen.visible())return advice==null?fallback:advice;
            if(tick%10==0){history.addLast(publicFrame(tick,self,seen,cell));while(history.size()>2)history.removeFirst();}
            if(tick>=next&&!pending&&!memory.inflight.contains(name)&&liveRequestGate.allow(name,System.nanoTime())&&memory.inflight.add(name)){next=tick+400;pending=true;long requestVersion=version;var payload=Map.of("baseline",fallback.name(),"observed_history",List.copyOf(history.isEmpty()?List.of(publicFrame(tick,self,seen,cell)):history),"own_training_feedback",Map.of("stall_penalty_count",stallWarnings,"stall_reward_total",-StallPenaltyClock.PENALTY*stallWarnings,"instruction",stallWarnings>0?"The bout exceeded another120seconds and both agents were penalized. Reconsider an ineffective stalling tactic and seek a legal combat opening; preserve immediate defence.":"No stalling penalty in this bout."));
                try{worker.execute(()->{try{var request=new LinkedHashMap<String,Object>(payload);request.put("coach_research_notes",memory.notes);request.put("shared_completed_bout_lessons",memory.lessonSnapshot());request.put("agent",name);var result=infer(request);memory.remember(name,result);if(active&&version==requestVersion){advice=DuelPolicy.Style.valueOf(result.get("style").getAsString());focus=ExperienceLibrary.Focus.valueOf(result.get("focus").getAsString());reason=result.has("reason")?result.get("reason").getAsString():"";applied.incrementAndGet();}}catch(Exception e){failed.incrementAndGet();lastError=e.toString();}finally{pending=false;memory.inflight.remove(name);}});}catch(RejectedExecutionException e){pending=false;memory.inflight.remove(name);next=tick+40;}
            }return advice==null?fallback:advice;
        }
        void penalizeStall(){stallWarnings++;stallFeedbacks.incrementAndGet();version++;next=0;advice=null;focus=ExperienceLibrary.Focus.FREE;}
        void close(){active=false;version++;}
    }
    static Map<String,Object> publicFrame(long tick,DuelPolicy.Self s,DuelPolicy.Seen o,ArenaLayout.Cell c){
        return Map.of("own",Map.of("health",s.health(),"charge",s.charge(),"shield_usable",s.shieldAvailable(),"arrows",s.arrows(),"loaded_crossbow",s.crossbowLoaded(),"wall_room",c.margin(s.x(),s.z())),"visible_opponent",Map.of("range_estimate",DuelPolicy.distance(s.x(),s.eyeY(),s.z(),o.x(),o.y(),o.z()),"shield_animation",o.shield(),"held",o.held(),"using",o.using(),"relative_height",o.y()-s.y(),"observed_swing_sequence",o.swing(),"age_ticks",Math.max(0,tick-o.captured())));
    }
    JsonObject infer(Object payload)throws Exception{
        if(payload instanceof Map<?,?> original){var compact=new LinkedHashMap<String,Object>();original.forEach((k,v)->compact.put(k.toString(),v));if(compact.get("coach_research_notes") instanceof String notes)compact.put("coach_research_notes",notes.substring(0,Math.min(320,notes.length())));if(compact.get("shared_completed_bout_lessons") instanceof List<?> lessons)compact.put("shared_completed_bout_lessons",lessons.isEmpty()?List.of():List.of(lessons.getLast()));if(compact.get("completed_bouts") instanceof List<?> bouts){var rows=new ArrayList<Object>();for(var value:bouts){var row=new LinkedHashMap<String,Object>();if(value instanceof Map<?,?> bout)for(String key:List.of("style_winner","style_loser","remaining_health","ticks","winner_hits","winner_crits","winner_swings","winner_whiffs","loser_hits","loser_crits","loser_swings","loser_whiffs","nominal_rtt_ms","stall_penalties"))if(bout.containsKey(key))row.put(key,bout.get(key));rows.add(row);}compact.put("completed_bouts",rows);}compact.put("retrieved_experience_hypotheses",experiences.retrieve());compact.put("cumulative_training",cumulativeTraining());payload=compact;}
        boolean review=payload instanceof Map<?,?> m&&"completed_post_bout_review".equals(m.get("mode"));
        var styles=review?List.of("AGGRESSIVE","DEFENSIVE"):Arrays.stream(DuelPolicy.Style.values()).map(Enum::name).toList();
        var schema=Map.of("type","object","properties",Map.of("style",Map.of("type","string","enum",styles),"focus",Map.of("type","string","enum",Arrays.stream(ExperienceLibrary.Focus.values()).map(Enum::name).toList()),"reason",Map.of("type","string","maxLength",80)),"required",List.of("style","focus","reason"),"additionalProperties",false);
        var body=Map.of("model","wavedog-tactics","messages",List.of(Map.of("role","system","content",PROMPT),Map.of("role","user","content",JSON.toJson(payload))),"temperature",.4,"max_tokens",96,"response_format",Map.of("type","json_object","schema",schema));
        long start=System.nanoTime();var req=HttpRequest.newBuilder(endpoint).timeout(Duration.ofSeconds(35)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(JSON.toJson(body))).build();
        var response=client.send(req,HttpResponse.BodyHandlers.ofString());if(response.statusCode()!=200)throw new IllegalStateException("Local LLM HTTP "+response.statusCode());
        var root=JsonParser.parseString(response.body()).getAsJsonObject();String content=root.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
        var result=JsonParser.parseString(content).getAsJsonObject();DuelPolicy.Style.valueOf(result.get("style").getAsString());if(review&&!styles.contains(result.get("style").getAsString()))throw new IllegalArgumentException("Invalid curriculum learner side");ExperienceLibrary.Focus.valueOf(result.get("focus").getAsString());experiences.acknowledge(payload);succeeded.incrementAndGet();
        synchronized(memory){Files.writeString(journal,JSON.toJson(Map.of("at",java.time.Instant.now().toString(),"public_input",payload,"output",result,"latency_ms",(System.nanoTime()-start)/1e6))+System.lineSeparator(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}return result;
    }
    static long metric(Map<String,Object> row,String key){Object value=row.get(key);return value instanceof Number n?n.longValue():0;}
    static Map<String,Object> reviewSignals(List<Map<String,Object>> batch){
        long swings=0,whiffs=0,hits=0,criticals=0,ticks=0,measured=0;
        for(var row:batch){long attempts=metric(row,"winner_swings")+metric(row,"loser_swings");if(attempts>0){measured++;swings+=attempts;whiffs+=metric(row,"winner_whiffs")+metric(row,"loser_whiffs");}hits+=metric(row,"winner_hits")+metric(row,"loser_hits");criticals+=metric(row,"winner_crits")+metric(row,"loser_crits");ticks+=metric(row,"ticks");}
        return Map.of("measured_bouts",measured,"swing_attempts",swings,"whiffs",whiffs,"whiff_rate",swings==0?0:Math.round(1000.0*whiffs/swings)/1000.0,"hits",hits,"critical_hits",criticals,"mean_ticks",batch.isEmpty()?0:Math.round((double)ticks/batch.size()));
    }
    void completedBout(Map<String,Object> report)throws Exception{memory.completed(report);if(memory.reviewPending||memory.reports.size()<6)return;var batch=memory.takeBatch();try{worker.execute(()->{try{var lesson=infer(Map.of("mode","completed_post_bout_review","completed_bouts",batch,"review_signals",reviewSignals(batch),"shared_completed_bout_lessons",memory.lessonSnapshot(),"instruction","Choose AGGRESSIVE or DEFENSIVE as the next targeted learner side, and a focus based on measured weakness. High whiff rate suggests testing distance and timing; high low-charge count suggests testing charge discipline. Compress the prior short lesson with new evidence into one cautious reason. Preserve supported attack interval, whiff and spacing insights when relevant. Do not invent criticals or trajectories.","coach_research_notes",memory.notes));memory.addLesson(lesson);}catch(Exception e){try{memory.restoreUnfinishedReview();}catch(Exception restore){e.addSuppressed(restore);}failed.incrementAndGet();lastError=e.toString();}finally{memory.reviewPending=false;}});}catch(RejectedExecutionException e){memory.restoreBatch(batch);}}
    Map<String,Object> cumulativeTraining(){var out=new LinkedHashMap<String,Object>();out.put("completed_history",memory.cumulativeSummary());var live=trainingProgress.get();var ppo=new LinkedHashMap<String,Object>();for(String key:List.of("gradient_updates","trained_episodes","training_samples","stall_penalty_updates","attack_attempts","whiff_attempts","low_charge_attempts","last_approx_kl","last_clip_fraction"))if(live.containsKey(key))ppo.put(key,live.get(key));out.put("recurrent_ppo_checkpoint",ppo);return out;}
    Map<String,Object> status(){var out=new LinkedHashMap<String,Object>();out.put("enabled",true);out.put("provider","shared local Qwen2.5-1.5B-Instruct Q4_K_M");out.put("successful_inferences",succeeded.get());out.put("applied_advice",applied.get());out.put("failed_requests",failed.get());out.put("queued",worker.getQueue().size());out.put("last_error",lastError);out.put("stall_feedbacks",stallFeedbacks.get());out.putAll(memory.status());out.putAll(experiences.status());return out;}
    public void close(){worker.shutdownNow();}
}
