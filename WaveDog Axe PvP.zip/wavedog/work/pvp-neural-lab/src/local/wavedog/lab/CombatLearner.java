package local.wavedog.lab;

import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Learned observation encoder and every available combat input; no live tactical rule override. */
final class CombatLearner implements AutoCloseable {
    static final int F=96,H=48;
    // movement, sprint, jump, sneak, hand intent, hotbar, yaw delta, pitch delta, turn-back restoration
    static final int[] WIDTH={9,2,2,2,5,5,13,7,2},OFF=new int[WIDTH.length];
    static final float[] TURN={-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180},PITCH={-30,-10,-3,0,3,10,30};
    static final int[] SLOT={7,0,1,4,-1};
    static final float[] FW={0,1,-1,0,0,1,1,-1,-1},SIDE={0,0,0,-1,1,-1,1,-1,1};
    static final int O,N;static {int n=0;for(int i=0;i<WIDTH.length;i++){OFF[i]=n;n+=WIDTH[i];}O=n;N=H*(F+1)+O*(H+1);}
    static final Gson JSON=new Gson();
    static final class State {int format=1;long updates,episodes,penaltyUpdates,samples,bootstrapExamples,bootstrapRevision;double baseline;double[] w=new double[N],m=new double[N],v=new double[N];}
    static final class Sample {final double[] x;final int[] action;double feedback;Sample(double[] x,int[] a){this.x=x;action=a;}}
    final Path checkpoint;final ExecutorService trainer;volatile State state;volatile String error="";
    final AtomicLong decisions=new AtomicLong();final AtomicInteger pending=new AtomicInteger();
    CombatLearner(Path folder)throws Exception{
        Files.createDirectories(folder);checkpoint=folder.resolve("combat-policy.json");
        if(Files.exists(checkpoint)){state=JSON.fromJson(Files.readString(checkpoint),State.class);if(state.bootstrapRevision<2){Files.copy(checkpoint,checkpoint.resolveSibling("combat-policy.incompatible-observation-v1-"+System.currentTimeMillis()+".json"));initializeWeights();bootstrap();save();}else validate(state);}else{initializeWeights();bootstrap();save();}
        trainer=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"WaveDog-all-input-RL");t.setDaemon(true);return t;});
    }
    void initializeWeights(){state=new State();Random r=new Random(991183);for(int i=0;i<N;i++)state.w[i]=r.nextGaussian()*.055;}
    static void validate(State s){if(s==null||s.format!=1||s.w.length!=N||s.m.length!=N||s.v.length!=N)throw new IllegalArgumentException("Combat model shape mismatch");for(double v:s.w)if(!Double.isFinite(v))throw new IllegalArgumentException("Nonfinite combat weights");}
    Actor actor(long seed,boolean learning){return new Actor(state.w.clone(),seed,learning);}
    final class Actor {
        final double[] weights;final Random random;final boolean learning;final ArrayList<Sample> episode=new ArrayList<>();final ArrayDeque<Sample> recent=new ArrayDeque<>();
        final double[] previous=new double[12];long sampled,lastObserved=-1;double ox,oy,oz;long previousSwing;ExperienceLibrary.Focus focus=ExperienceLibrary.Focus.FREE;
        Actor(double[] w,long seed,boolean learning){weights=w;random=new Random(seed);this.learning=learning;}
        DuelPolicy.Input act(long tick,long due,DuelPolicy.Self self,DuelPolicy.Seen seen,ArenaLayout.Cell cell,DuelPolicy.Style style,float yaw,float pitch){
            double[] x=features(self,seen,cell,style,yaw,pitch,tick,previous);conditionOnFocus(x,focus);double[] p=probabilities(weights,x);int[] action=new int[WIDTH.length];
            for(int head=0;head<WIDTH.length;head++){double draw=random.nextDouble();int chosen=WIDTH[head]-1;for(int a=0;a<WIDTH[head];a++){draw-=p[OFF[head]+a];if(draw<=0){chosen=a;break;}}action[head]=chosen;}
            if(learning){Sample sample=new Sample(x,action.clone());recent.addLast(sample);while(recent.size()>12)recent.removeFirst();sampled++;if(episode.size()<2048)episode.add(sample);else{long index=random.nextLong(sampled);if(index<2048)episode.set((int)index,sample);}}
            if(seen!=null&&seen.visible()&&seen.captured()!=lastObserved){System.arraycopy(x,18,previous,0,12);lastObserved=seen.captured();}
            decisions.incrementAndGet();return decode(tick,due,self,yaw,pitch,action);
        }
        void outcomeFeedback(double dealt,double received){if(!learning||recent.isEmpty())return;double value=(dealt-received)/20;for(var sample:recent)sample.feedback+=value/recent.size();}
        void finish(boolean win,double health){submit((win?1:-1)+health/40,true);}
        void penalizeStall(){submit(-StallPenaltyClock.PENALTY,false);}
        void submit(double reward,boolean terminal){if(!learning||episode.isEmpty())return;List<Sample> batch=new ArrayList<>(episode);Collections.shuffle(batch,random);if(batch.size()>256)batch=new ArrayList<>(batch.subList(0,256));final List<Sample> samples=List.copyOf(batch);episode.clear();recent.clear();sampled=0;if(pending.incrementAndGet()>64){pending.decrementAndGet();return;}trainer.execute(()->{try{train(weights,samples,reward,terminal);}catch(Exception e){error=e.toString();}finally{pending.decrementAndGet();}});}
    }
    /** Context only: no attack, movement, reward or safety decision is selected by a label. */
    static void conditionOnFocus(double[] x,ExperienceLibrary.Focus focus){Arrays.fill(x,80,F,0);if(focus!=null&&focus!=ExperienceLibrary.Focus.FREE)x[80+focus.ordinal()]=1;}
    static DuelPolicy.Input decode(long tick,long due,DuelPolicy.Self s,float yaw,float pitch,int[] a){
        int slot=SLOT[a[5]]<0?s.held():SLOT[a[5]],hand=a[4];boolean guard=hand==1,attack=hand==2,use=hand==3,release=hand==4;
        // Keep/continue use is a learned hand choice too; no trajectory or attack rule supersedes this output.
        String skill=hand==0?"RL_HOLD":(slot==1?"BOW":slot==4?"CROSSBOW":guard?"RL_SHIELD":"RL_INPUT");
        return new DuelPolicy.Input(tick,due,yaw+TURN[a[6]],Math.max(-90,Math.min(90,pitch+PITCH[a[7]])),FW[a[0]],SIDE[a[0]],a[1]==1,a[2]==1,guard,attack,slot,use,release,a[8]==1&&attack,skill,"all-input learned policy",a[3]==1);
    }
    /** Raw normalized public observations, not hand-written threat/critical classifications. */
    static double[] features(DuelPolicy.Self s,DuelPolicy.Seen o,ArenaLayout.Cell c,DuelPolicy.Style style,float yaw,float pitch,long tick,double[] previous){
        double[] x=new double[F];double r=Math.toRadians(yaw),sin=Math.sin(r),cos=Math.cos(r);
        x[0]=s.health()/20;x[1]=s.charge();x[2]=s.ground()?1:0;x[3]=s.vx()*cos+s.vz()*sin;x[4]=s.vy();x[5]=-s.vx()*sin+s.vz()*cos;x[6]=s.shieldAvailable()?1:0;x[7]=s.shielding()?1:0;x[8]=s.using()?1:0;x[9]=s.useTicks()/25.0;x[10]=s.arrows()/5.0;x[11]=s.crossbowLoaded()?1:0;x[12]=s.held()/8.0;x[13]=pitch/90;x[14]=sin;x[15]=cos;x[16]=(s.y()-ArenaLayout.FLOOR)/4;x[17]=Math.min(1,tick/2400.0);
        if(o!=null&&o.visible()){
            double dx=o.x()-s.x(),dz=o.z()-s.z();x[18]=Math.tanh((dx*cos+dz*sin)/6);x[19]=Math.tanh((o.y()-s.y())/3);x[20]=Math.tanh((-dx*sin+dz*cos)/6);x[21]=Math.sin(Math.toRadians(o.yaw()-yaw));x[22]=Math.cos(Math.toRadians(o.yaw()-yaw));x[23]=o.shield()?1:0;x[24]=o.using()?1:0;x[25]=Math.min(1,(tick-o.captured())/10.0);x[26]=o.held().contains("SWORD")?1:0;x[27]=o.held().contains("AXE")?1:0;x[28]=o.held().equals("BOW")?1:0;x[29]=o.held().contains("CROSSBOW")?1:0;x[30]=(o.swing()%4)/3.0;x[31]=1;x[78]=wrap(DuelPolicy.yaw(dx,dz)-yaw)/180.0;x[79]=(DuelPolicy.pitch(dx,o.y()+1-s.eyeY(),dz)-pitch)/90.0;
        }
        if(o!=null){int i=0;for(var a:o.arrows()){if(i>=4)break;int z=32+6*i++;double ax=a.x()-s.x(),az=a.z()-s.z();x[z]=Math.tanh((ax*cos+az*sin)/12);x[z+1]=Math.tanh((a.y()-s.y())/6);x[z+2]=Math.tanh((-ax*sin+az*cos)/12);x[z+3]=(a.vx()*cos+a.vz()*sin)/4;x[z+4]=a.vy()/4;x[z+5]=(-a.vx()*sin+a.vz()*cos)/4;}}
        x[56]=Math.min(1,(s.x()-c.minX())/8);x[57]=Math.min(1,(c.maxX()-s.x())/8);x[58]=Math.min(1,(s.z()-c.minZ())/8);x[59]=Math.min(1,(c.maxZ()-s.z())/8);
        for(int i=0;i<12;i++)x[60+i]=previous[i];x[72+style.ordinal()]=1;
        for(int i=0;i<F;i++)x[i]=Double.isFinite(x[i])?Math.max(-3,Math.min(3,x[i])):0;return x;
    }
    static double[] hidden(double[] w,double[] x){double[] h=new double[H];for(int j=0;j<H;j++){int off=j*(F+1);double z=w[off+F];for(int k=0;k<F;k++)z+=w[off+k]*x[k];h[j]=Math.tanh(z);}return h;}
    static double[] probabilities(double[] w,double[] x){return probabilities(w,hidden(w,x),true);}
    static double[] probabilities(double[] w,double[] h,boolean isHidden){double[] p=new double[O];for(int head=0;head<WIDTH.length;head++){double max=-1e30,total=0;for(int a=0;a<WIDTH[head];a++){int at=OFF[head]+a,off=H*(F+1)+at*(H+1);double z=w[off+H];for(int j=0;j<H;j++)z+=w[off+j]*h[j];p[at]=2*z;max=Math.max(max,2*z);}for(int a=0;a<WIDTH[head];a++){int at=OFF[head]+a;p[at]=Math.exp(p[at]-max);total+=p[at];}for(int a=0;a<WIDTH[head];a++)p[OFF[head]+a]/=total;}return p;}
    static void gradient(double[] w,Sample sample,double advantage,double[] g){double[] h=hidden(w,sample.x),p=probabilities(w,h,true),dh=new double[H];for(int head=0;head<WIDTH.length;head++)for(int a=0;a<WIDTH[head];a++){int at=OFF[head]+a,off=H*(F+1)+at*(H+1);double d=2*((a==sample.action[head]?1:0)-p[at])*advantage;g[off+H]+=d;for(int j=0;j<H;j++){g[off+j]+=d*h[j];dh[j]+=d*w[off+j];}}for(int j=0;j<H;j++){double d=dh[j]*(1-h[j]*h[j]);int off=j*(F+1);g[off+F]+=d;for(int k=0;k<F;k++)g[off+k]+=d*sample.x[k];}}
    void train(double[] actor,List<Sample> samples,double reward,boolean terminal)throws Exception{
        State old=state,s=copy(old);double advantage=terminal?Math.max(-2,Math.min(2,reward-s.baseline)):Math.min(0,reward);if(terminal)s.baseline=.98*s.baseline+.02*reward;double[] g=new double[N];
        for(var sample:samples)gradient(actor,sample,(advantage+sample.feedback)/samples.size(),g);double norm=0;for(double d:g)norm+=d*d;double scale=norm>1?1/Math.sqrt(norm):1;s.updates++;double b1=1-Math.pow(.9,s.updates),b2=1-Math.pow(.999,s.updates);
        for(int i=0;i<N;i++){double d=g[i]*scale;s.m[i]=.9*s.m[i]+.1*d;s.v[i]=.999*s.v[i]+.001*d*d;s.w[i]+=.0003*(s.m[i]/b1)/(Math.sqrt(s.v[i]/b2)+1e-8);}
        s.samples+=samples.size();if(terminal)s.episodes++;else s.penaltyUpdates++;validate(s);state=s;save();
    }
    static State copy(State o){State s=new State();s.w=o.w.clone();s.m=o.m.clone();s.v=o.v.clone();s.updates=o.updates;s.episodes=o.episodes;s.penaltyUpdates=o.penaltyUpdates;s.samples=o.samples;s.bootstrapExamples=o.bootstrapExamples;s.bootstrapRevision=o.bootstrapRevision;s.baseline=o.baseline;return s;}
    static int nearest(float value,float[] values){int best=0;for(int i=1;i<values.length;i++)if(Math.abs(values[i]-value)<Math.abs(values[best]-value))best=i;return best;}
    static float wrap(float a){while(a>180)a-=360;while(a< -180)a+=360;return a;}
    static int[] teacher(DuelPolicy.Input b,DuelPolicy.Self s,float yaw,float pitch){int move=0;double best=1e9;for(int i=0;i<FW.length;i++){double d=Math.pow(FW[i]-b.forward(),2)+Math.pow(SIDE[i]-b.side(),2);if(d<best){move=i;best=d;}}int slot=4;for(int i=0;i<4;i++)if(SLOT[i]==b.slot())slot=i;return new int[]{move,b.sprint()?1:0,b.jump()?1:0,0,b.attack()?2:b.shield()?1:b.release()?4:b.use()?3:0,slot,nearest(wrap(b.yaw()-yaw),TURN),nearest(b.pitch()-pitch,PITCH),b.flightLook()?1:0};}
    /** Offline imitation initialization only. These rules are NOT executed by the live learner. */
    void bootstrap(){Random random=new Random(881125);var cell=ArenaLayout.cells().getFirst();var examples=new ArrayList<Sample>();
        for(int i=0;i<10000;i++){var style=DuelPolicy.Style.values()[i%6];float yaw=(float)(random.nextDouble()*360),pitch=(float)(random.nextDouble()*180-90);double bearing=Math.toRadians(yaw+90+random.nextDouble()*160-80),range=random.nextBoolean()?.6+random.nextDouble()*3:3+random.nextDouble()*9;boolean ground=random.nextDouble()<.75;double vy=ground?0:random.nextDouble()*.8-.4;double y=ArenaLayout.FLOOR+1+(ground?0:random.nextDouble()*1.2);int held=SLOT[random.nextInt(4)];
            var s=new DuelPolicy.Self(cell.cx(),y,cell.cz(),y+1.62,0,vy,0,ground,!ground&&vy<0,random.nextDouble()<.6?.98f:(float)random.nextDouble(),5+random.nextDouble()*15,random.nextBoolean(),false,5,random.nextBoolean(),random.nextBoolean(),random.nextInt(30),held);
            var o=new DuelPolicy.Seen(i,i,random.nextDouble()>.2,cell.cx()+Math.cos(bearing)*range,ArenaLayout.FLOOR+1+(random.nextDouble()<.2?1:0),cell.cz()+Math.sin(bearing)*range,(float)random.nextInt(360),random.nextBoolean(),new String[]{"DIAMOND_AXE","DIAMOND_SWORD","BOW","CROSSBOW"}[random.nextInt(4)],random.nextBoolean(),i%3,List.of());
            var teacher=new DuelPolicy(style,random.nextLong(),cell);teacher.seen=o;var b=teacher.decide(i,i,s);examples.add(new Sample(features(s,o,cell,style,yaw,pitch,i,new double[12]),teacher(b,s,yaw,pitch)));
        }
        for(int epoch=0;epoch<12;epoch++){Collections.shuffle(examples,random);for(var sample:examples){double[] g=new double[N];gradient(state.w,sample,1,g);for(int j=0;j<N;j++)state.w[j]+=.0015*g[j];}}state.bootstrapExamples=examples.size();state.bootstrapRevision=2;
    }
    void save()throws Exception{Path temp=checkpoint.resolveSibling("combat-policy.json.tmp");Files.writeString(temp,JSON.toJson(state));Files.move(temp,checkpoint,StandardCopyOption.REPLACE_EXISTING);}
    Map<String,Object> status(){State s=state;return Map.of("enabled",true,"architecture","96 public/history inputs ->48 learned tanh ->9 categorical action heads; REINFORCE+Adam","decisions",decisions.get(),"gradient_updates",s.updates,"trained_episodes",s.episodes,"stall_penalty_updates",s.penaltyUpdates,"training_samples",s.samples,"bootstrap_examples_not_matches",s.bootstrapExamples,"pending",pending.get(),"last_error",error);}
    public void close(){trainer.shutdown();try{trainer.awaitTermination(20,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
