package local.wavedog.lab;

import java.util.List;
import java.util.Random;

/** Independent knowledge-seeded controller. Not an LLM and not a neural policy. */
final class DuelPolicy {
    enum Style { DEFENSIVE, AGGRESSIVE, FLANK, GROUND_COMBO, RANGED, MIXED }
    record Arrow(long tick,double x,double y,double z,double vx,double vy,double vz) {}
    record Seen(long captured,long available,boolean visible,double x,double y,double z,float yaw,
                boolean shield,String held,boolean using,long swing,List<Arrow> arrows) {}
    record Self(double x,double y,double z,double eyeY,double vx,double vy,double vz,
                boolean ground,boolean critical,float charge,double health,boolean shieldAvailable,
                boolean shielding,int arrows,boolean crossbowLoaded,boolean using,int useTicks,int held) {}
    record Input(long decided,long due,float yaw,float pitch,float forward,float side,boolean sprint,
                 boolean jump,boolean shield,boolean attack,int slot,boolean use,boolean release,
                 boolean flightLook,String skill,String reason,boolean sneak) {}
    final Style style;Style actingStyle;TacticalModel.Agent tactics;final Random random;final ArenaLayout.Cell cell;
    Seen seen;long nextSide,lastJump=-100,orbitUntil,escapeUntil,lastSwing=-1,lastAttack=-100,lastObserved=-1;
    double oldX,oldY,oldZ,vx,vy,vz,previousHealth=20;float side=1,escapeYaw;boolean wantJump,previousShield=true;
    DuelPolicy(Style style,long seed,ArenaLayout.Cell cell){this.style=style;this.actingStyle=style;random=new Random(seed);this.cell=cell;}
    Input decide(long tick,long due,Self s){
        actingStyle=tactics==null?style:tactics.update(tick,s,seen,cell,style);
        boolean hurt=s.health()<previousHealth-.01;previousHealth=s.health();
        boolean shieldJustBroke=previousShield&&!s.shieldAvailable();previousShield=s.shieldAvailable();
        if(seen==null||!seen.visible()||tick-seen.captured()>18)
            return out(tick,due,escapeUntil>tick?escapeYaw:(float)((tick*18)%360),0,escapeUntil>tick?1:0,0,
                escapeUntil>tick,false,s.shieldAvailable(),false,7,false,false,false,"SEARCH","target not currently observed");
        if(lastObserved!=seen.captured()){
            if(lastObserved>=0){double dt=Math.max(1,seen.captured()-lastObserved);vx=(seen.x()-oldX)/dt;vy=(seen.y()-oldY)/dt;vz=(seen.z()-oldZ)/dt;}
            oldX=seen.x();oldY=seen.y();oldZ=seen.z();lastObserved=seen.captured();
        }
        double age=Math.min(4,Math.max(0,tick-seen.captured()));
        double tx=seen.x()+vx*age,tz=seen.z()+vz*age,ty=seen.y()+vy*age;
        double dx=tx-s.x(),dz=tz-s.z(),dist=Math.hypot(dx,dz);
        double range=distance(s.x(),s.eyeY(),s.z(),tx,ty,tz);
        float aim=yaw(dx,dz),pitch=pitch(dx,ty+1-s.eyeY(),dz);
        boolean rising=vy>.06,falling=vy<-.08,air=ty>ArenaLayout.FLOOR+1.15;
        boolean in=range<=2.97,near=range<=3.35;
        boolean swing=seen.swing()!=lastSwing;lastSwing=seen.swing();
        boolean facing=dotYaw(seen.yaw(),s.x()-tx,s.z()-tz)>.1;
        boolean guarded=seen.shield()&&facing; // conservative visual estimate, not target native blocking state
        if(tick>=nextSide){side=random.nextBoolean()?1:-1;nextSide=tick+5+random.nextInt(12);}

        // One final action owner: projectile defence is resolved before learned/style footwork.
        Arrow danger=null;double eta=99;
        for(var a:seen.arrows())for(int k=1;k<=12;k++){
            double ageArrow=Math.max(0,tick-a.tick()),t=ageArrow+k;
            double scale=(1-Math.pow(.99,t))/.01;
            double ax=a.x()+a.vx()*scale,az=a.z()+a.vz()*scale;
            double ay=a.y()+a.vy()*scale-.05*(t-scale)/.01;
            if(Math.abs(ax-(s.x()+s.vx()*k))<.55&&Math.abs(az-(s.z()+s.vz()*k))<.55
                &&ay>s.y()-.15&&ay<s.y()+1.95&&k<eta){danger=a;eta=k;}
        }
        if(danger!=null){
            if(s.shieldAvailable())return out(tick,due,yaw(danger.x()-s.x(),danger.z()-s.z()),0,0,0,false,false,true,false,7,false,false,false,"ARROW_GUARD","observed trajectory intersects body; shield has priority");
            double len=Math.max(.01,Math.hypot(danger.vx(),danger.vz()));double ex=-danger.vz()/len,ez=danger.vx()/len;
            if(cell.margin(s.x()+ex*3,s.z()+ez*3)<cell.margin(s.x()-ex*3,s.z()-ez*3)){ex=-ex;ez=-ez;}
            boolean j=s.ground()&&eta<=7&&tick-lastJump>8;if(j)lastJump=tick;
            return out(tick,due,yaw(ex,ez),0,1,0,true,j,false,false,7,false,false,false,"ARROW_DODGE","no usable shield; perpendicular sprint path away from nearby wall");
        }

        if(shieldJustBroke){escapeYaw=away(s,tx,tz);escapeUntil=tick+16;wantJump=true;}
        // Shield-counter escape uses ordinary inputs, one jump, and no repeated head turns out of range.
        if(!s.shieldAvailable()&&escapeUntil>tick){
            boolean finalHit=in&&range>2.55&&!guarded;
            boolean criticalHit=in&&s.critical()&&s.charge()>.9&&!guarded;
            boolean strike=criticalHit||finalHit||(hurt&&in&&!guarded);
            if(range>3.03||(!s.ground()&&s.y()<ArenaLayout.FLOOR+.8))escapeUntil=tick;
            if(strike){lastAttack=tick;if(finalHit)escapeUntil=tick;}
            boolean jump=wantJump&&s.ground();wantJump=false;if(jump)lastJump=tick;
            return out(tick,due,strike?aim:escapeYaw,strike?pitch:0,1,0,!criticalHit,jump,false,strike,0,false,false,strike,"ESCAPE",criticalHit?"native own critical opportunity":"single sprint jump; final legal boundary hit only");
        }

        // Delayed public swing/position observations, never pre-attack or pre-jump hooks.
        boolean reply=(hurt||swing)&&in&&!guarded;
        if(s.shieldAvailable()){
            if(air&&near)return out(tick,due,aim,pitch,.3f,side*.15f,false,false,true,false,7,false,false,false,"GUARD_AIR","visible airborne close opponent; maintain shield");
            boolean behind=dotYaw(seen.yaw(),s.x()-tx,s.z()-tz)<-.2;
            boolean optional=(actingStyle==Style.AGGRESSIVE||actingStyle==Style.GROUND_COMBO||actingStyle==Style.MIXED)&&s.charge()>.93;
            boolean ordinaryShieldBreak=guarded&&s.charge()>.94&&tick-lastAttack>26&&(actingStyle==Style.AGGRESSIVE||actingStyle==Style.GROUND_COMBO);
            if(in&&(ordinaryShieldBreak||!guarded&&((reply&&s.charge()>.2)||s.charge()>.94&&(behind||optional||tick-lastAttack>30)))){
                lastAttack=tick;
                return out(tick,due,aim,pitch,1,0,true,false,false,true,7,false,false,false,"AXE_COUNTER",reply?"reply to observed contact/animation":"charged axe through observed opening");
            }
            if(actingStyle==Style.FLANK&&!air&&range<1.8&&tick>orbitUntil&&s.charge()>.85&&random.nextDouble()<.10)orbitUntil=tick+4;
            if(orbitUntil>tick&&!air){
                if(reply||behind){orbitUntil=tick;return out(tick,due,aim,pitch,1,side*.2f,true,false,false,in&&!guarded,7,false,false,false,"FLANK_REPLY","back opening or received hit; abort exposed orbit");}
                float tangent=aim+side*105;
                return out(tick,due,tangent,0,1,0,true,false,false,false,7,false,false,false,"FLANK","short sprint around observed grounded target");
            }
            if(range<4.2||actingStyle==Style.DEFENSIVE||seen.held().contains("BOW")&&range<6)
                return out(tick,due,aim,pitch,range>1.5?.9f:0,side*(actingStyle==Style.FLANK?.5f:.16f),false,false,true,false,7,false,false,false,"SHIELD_PRESSURE","approach under shield; wait for an opening");
        }

        if(!s.shieldAvailable()&&near&&air&&falling&&!in){
            escapeYaw=away(s,tx,tz);return out(tick,due,escapeYaw,0,1,0,true,false,false,false,7,false,false,false,"CRITICAL_AVOID","visible descending threat; leave projected approach lane");
        }
        if(!s.shieldAvailable()&&in&&!guarded&&(reply||s.charge()>.92)){
            lastAttack=tick;escapeYaw=away(s,tx,tz);escapeUntil=tick+14;wantJump=true;
            int slot=seen.held().endsWith("SWORD")?0:7;
            return out(tick,due,aim,pitch,1,0,!s.critical(),false,false,true,slot,false,false,false,"TRADE_EXIT","legal close reply; begin native knockback then one sprint-jump exit");
        }
        if(range>4.2&&(s.arrows()>0||s.crossbowLoaded())&&(actingStyle==Style.RANGED||actingStyle==Style.MIXED||seen.using()&&seen.held().contains("BOW"))){
            int slot=actingStyle==Style.RANGED?4:1;
            double flight=dist/3,px=dx+vx*Math.min(8,flight),pz=dz+vz*Math.min(8,flight);
            float shotPitch=pitch(px,ty+1-s.eyeY()+.025*flight*flight,pz);
            if(s.held()!=slot)return out(tick,due,aim,shotPitch,0,side*.3f,false,false,false,false,slot,false,false,false,"RANGED_SELECT","ranged choice yields immediately to close combat/trajectory defence");
            if(slot==4)return out(tick,due,yaw(px,pz),shotPitch,0,side*.25f,false,false,false,false,4,!s.using(),false,false,s.crossbowLoaded()?"CROSSBOW_FIRE":"CROSSBOW_LOAD","keep native use uninterrupted until own charged item confirms completion");
            boolean release=s.using()&&s.useTicks()>=18;
            return out(tick,due,yaw(px,pz),shotPitch,0,side*.3f,false,false,false,false,1,!s.using(),release,false,"BOW","ordinary draw/release; lead based only on published positions");
        }
        boolean jump=!s.shieldAvailable()&&s.ground()&&near&&rising&&tick-lastJump>9;
        if(jump)lastJump=tick;
        double target=actingStyle==Style.AGGRESSIVE?2.5:3.15;
        float forward=range>target&&s.charge()>.88?1:0;
        if(cell.margin(s.x(),s.z())<4){aim=yaw(cell.cx()-s.x(),cell.cz()-s.z());forward=1;}
        return out(tick,due,aim,pitch,forward,side*.5f,forward>0,jump,s.shieldAvailable(),false,7,false,false,false,"SPACE_RESET","recharge/ground footwork; prefer room away from walls");
    }
    float away(Self s,double tx,double tz){
        double dx=s.x()-tx,dz=s.z()-tz,len=Math.max(.01,Math.hypot(dx,dz));dx/=len;dz/=len;
        double best=-1e9,bx=dx,bz=dz;
        for(int degrees:new int[]{0,35,-35,70,-70,110,-110}){double a=Math.toRadians(degrees),x=dx*Math.cos(a)-dz*Math.sin(a),z=dx*Math.sin(a)+dz*Math.cos(a);
            double score=cell.margin(s.x()+x*4,s.z()+z*4)*2+(x*dx+z*dz)*3;
            if(score>best){best=score;bx=x;bz=z;}}
        return yaw(bx,bz);
    }
    static Input out(long t,long due,float yaw,float pitch,float f,float side,boolean sprint,boolean jump,boolean shield,boolean hit,int slot,boolean use,boolean release,boolean flight,String skill,String reason){return new Input(t,due,yaw,pitch,f,side,sprint,jump,shield,hit,slot,use,release,flight,skill,reason,false);}
    static double distance(double x,double eye,double z,double tx,double ty,double tz){double dx=Math.max(Math.abs(tx-x)-.3,0),dz=Math.max(Math.abs(tz-z)-.3,0),dy=Math.max(Math.max(ty-eye,eye-ty-1.8),0);return Math.sqrt(dx*dx+dy*dy+dz*dz);}
    static float yaw(double x,double z){return (float)Math.toDegrees(Math.atan2(-x,z));}
    static float pitch(double x,double y,double z){return (float)-Math.toDegrees(Math.atan2(y,Math.max(.01,Math.hypot(x,z))));}
    static double dotYaw(float yaw,double dx,double dz){double len=Math.max(.001,Math.hypot(dx,dz)),a=Math.toRadians(yaw);return (-Math.sin(a)*dx+Math.cos(a)*dz)/len;}
}
