package local.wavedog.lab;

import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.util.Vector;

/** Native mechanics fixture. Inputs pass through the production executor; never trains an actor. */
final class NativeCombatProbe {
    interface Task { void run() throws Exception; }
    record Step(int delay,Task task){}
    final LivePracticeLab lab;final LivePracticeLab.Lane lane;final Task completion;
    final ArrayDeque<Step> steps=new ArrayDeque<>();final List<Map<String,Object>> results=new ArrayList<>();
    final List<Map<String,Object>> shots=new ArrayList<>();int age;double damage,lastDamage,fullDamage,ordinaryKb,shortSpeed;float charge;boolean done;
    NativeCombatProbe(LivePracticeLab lab,LivePracticeLab.Lane lane,Task completion)throws Exception{
        this.lab=lab;this.lane=lane;this.completion=completion;pose(2.3);equip(7);
        add(30,()->{charge=a().getCooledAttackStrength(0);hit(7,false);fullDamage=lastDamage;mark("axe_full_charge",charge>.99&&lastDamage>0,Map.of("charge",charge,"damage",lastDamage));});
        add(1,()->{charge=a().getCooledAttackStrength(0);hit(7,false);mark("axe_one_tick_recharge",charge<.15&&lastDamage<fullDamage,Map.of("charge",charge,"damage",lastDamage,"full_damage",fullDamage));});
        add(27,()->{charge=a().getCooledAttackStrength(0);mark("axe_recovered",charge>.99,Map.of("charge",charge));pose(12);hit(7,false);double after=a().getCooledAttackStrength(0);mark("axe_whiff_resets_charge",charge>.99&&lastDamage==0&&after<.15,Map.of("before",charge,"after",after,"damage",lastDamage));pose(2.3);equip(0);});
        add(2,()->{charge=a().getCooledAttackStrength(0);mark("sword_switch_resets_charge",charge<.35,Map.of("charge",charge));});
        add(14,()->{charge=a().getCooledAttackStrength(0);pose(2.3);hit(0,false);mark("sword_full_charge",charge>.99&&lastDamage>0,Map.of("charge",charge,"damage",lastDamage));});
        add(1,()->{charge=a().getCooledAttackStrength(0);mark("sword_one_tick_recharge",charge<.25,Map.of("charge",charge));});
        add(2,()->{pose(2.3);b().setCooldown(Material.SHIELD,0);send(lane.b,7,true,false,false,false,false);});
        add(3,()->{var p=b();lane.b.inputs.addLast(new DuelPolicy.Input(lab.tick,lab.tick,p.getYaw(),0,0,0,false,false,false,false,7,false,false,false,"RL_HOLD","all-input learned policy",false));lab.execute(lane,lane.b,lane.a);});
        add(5,()->{boolean blocking=b().isBlocking();mark("learned_hold_preserves_effective_shield",blocking&&b().getHandRaisedTime()>=7,Map.of("blocking",blocking,"use_ticks",b().getHandRaisedTime()));hit(0,false);mark("sword_vs_effective_shield",blocking&&lastDamage==0&&b().getCooldown(Material.SHIELD)==0,Map.of("blocking",blocking,"damage",lastDamage,"shield_cooldown",b().getCooldown(Material.SHIELD),"horizontal_knockback",horizontal(b())));equip(7);});
        add(2,()->{mark("effective_shield_blocks_sword_knockback",horizontal(b())<.01,Map.of("horizontal_velocity_after_packet",horizontal(b())));pose(2.3);send(lane.b,7,true,false,false,false,false);});
        add(30,()->{boolean blocking=b().isBlocking();charge=a().getCooledAttackStrength(0);hit(7,false);mark("axe_disables_effective_shield",blocking&&charge>.99&&b().getCooldown(Material.SHIELD)>0,Map.of("blocking_before",blocking,"charge",charge,"damage",lastDamage,"shield_cooldown",b().getCooldown(Material.SHIELD),"horizontal_knockback",horizontal(b())));});
        add(2,()->{mark("effective_shield_blocks_axe_knockback",horizontal(b())<.01,Map.of("horizontal_velocity_after_packet",horizontal(b())));pose(2.3);});
        add(30,()->{b().setCooldown(Material.SHIELD,0);hit(0,false);mark("unshielded_hit_before_hurt_window",lastDamage>0,Map.of("damage",lastDamage,"hurt_ticks",b().getNoDamageTicks()));});
        add(1,()->{b().teleport(new Location(lab.world,lane.cell.cx(),ArenaLayout.FLOOR+1,lane.cell.cz()+2.3,180,0));b().setVelocity(new Vector());send(lane.b,7,true,false,false,false,false);});
        add(7,()->{boolean blocking=b().isBlocking();int hurt=b().getNoDamageTicks();charge=a().getCooledAttackStrength(0);hit(7,false);mark("axe_disables_shield_during_hurt_invulnerability",blocking&&hurt>0&&b().getCooldown(Material.SHIELD)>0,Map.of("blocking_before",blocking,"hurt_ticks_before",hurt,"charge",charge,"shield_cooldown",b().getCooldown(Material.SHIELD),"damage",lastDamage));pose(2.3);});
        add(30,()->{b().setCooldown(Material.SHIELD,0);b().setRotation(0,0);send(lane.b,7,true,false,false,false,false);});
        add(7,()->{boolean blocking=b().isBlocking();hit(7,false);mark("back_facing_shield_does_not_disable",blocking&&lastDamage>0&&b().getCooldown(Material.SHIELD)==0,Map.of("blocking_animation",blocking,"damage",lastDamage,"shield_cooldown",b().getCooldown(Material.SHIELD)));});
        add(2,()->pose(2.3));
        add(30,()->{hit(7,false);damage=lastDamage;});
        add(2,()->{ordinaryKb=horizontal(b());mark("ordinary_melee_knockback",damage>0&&ordinaryKb>0,Map.of("damage",damage,"horizontal_velocity_after_packet",ordinaryKb));pose(2.3);});
        add(30,()->{hit(7,true);damage=lastDamage;});
        add(2,()->{double kb=horizontal(b());mark("sprint_axe_knockback",damage>0&&kb>ordinaryKb+.1,Map.of("damage",damage,"horizontal_velocity_after_packet",kb,"ordinary_horizontal_velocity",ordinaryKb));pose(12);equip(1);});
        add(3,()->send(lane.a,1,false,false,true,false,false));
        add(8,()->{int before=shots.size(),ticks=a().getHandRaisedTime();send(lane.a,1,false,false,false,true,false);shortSpeed=shots.size()>before?((Number)shots.getLast().get("speed")).doubleValue():0;mark("short_bow_draw",shots.size()==before+1&&shortSpeed>0&&shortSpeed<2.9,Map.of("draw_ticks",ticks,"speed",shortSpeed,"shots",shots.size()-before));});
        add(3,()->send(lane.a,1,false,false,true,false,false));
        add(21,()->{int before=shots.size(),ticks=a().getHandRaisedTime();send(lane.a,1,false,false,false,true,false);double speed=shots.size()>before?((Number)shots.getLast().get("speed")).doubleValue():0;mark("full_bow_draw",ticks>=20&&shots.size()==before+1&&speed>2.9&&speed>shortSpeed,Map.of("draw_ticks",ticks,"speed",speed,"shots",shots.size()-before));equip(4);});
        add(3,()->send(lane.a,4,false,false,true,false,false));
        add(10,()->{send(lane.a,4,false,false,false,true,false);mark("interrupted_crossbow_not_loaded",!loaded()&&arrows()==3,Map.of("loaded",loaded(),"arrows",arrows()));});
        add(3,()->send(lane.a,4,false,false,true,false,false));
        add(27,()->{int ticks=a().getHandRaisedTime();if(a().hasActiveItem())send(lane.a,4,false,false,false,true,false);mark("full_crossbow_load",loaded()&&arrows()==2,Map.of("loaded",loaded(),"arrows",arrows(),"draw_ticks",ticks));});
        add(2,()->{int before=shots.size();send(lane.a,4,false,false,true,false,false);double speed=shots.size()>before?((Number)shots.getLast().get("speed")).doubleValue():0;mark("charged_crossbow_fires_once",shots.size()==before+1&&!loaded()&&speed>3,Map.of("loaded_after",loaded(),"shots",shots.size()-before,"speed",speed,"arrows",arrows()));});
        add(2,this::finish);
    }
    Player a(){return lane.a.player;}Player b(){return lane.b.player;}
    void add(int delay,Task t){steps.addLast(new Step(delay,t));}
    void step()throws Exception{if(done||steps.isEmpty())return;if(++age<steps.peekFirst().delay())return;age=0;steps.removeFirst().task().run();}
    void equip(int slot)throws Exception{send(lane.a,slot,false,false,false,false,false);}
    void pose(double distance)throws Exception{
        for(var f:List.of(lane.a,lane.b)){var p=f.player;f.inputs.clear();if(p.hasActiveItem())lab.release.invoke(null,p);p.setSneaking(false);p.setSprinting(false);lab.bridge.fromPlayer(p).setZza(0);lab.bridge.fromPlayer(p).setXxa(0);p.setHealth(20);p.setFoodLevel(20);p.setNoDamageTicks(0);}
        a().teleport(new Location(lab.world,lane.cell.cx(),ArenaLayout.FLOOR+1,lane.cell.cz(),0,0));b().teleport(new Location(lab.world,lane.cell.cx(),ArenaLayout.FLOOR+1,lane.cell.cz()+distance,180,0));a().setVelocity(new Vector());b().setVelocity(new Vector());
    }
    void send(LivePracticeLab.Fighter f,int slot,boolean shield,boolean attack,boolean use,boolean release,boolean sprint)throws Exception{
        var p=f.player;var input=new DuelPolicy.Input(lab.tick,lab.tick,p.getYaw(),0,sprint?1:0,0,sprint,false,shield,attack,slot,use,release,false,slot==1?"BOW":slot==4?"CROSSBOW":"NATIVE_AUDIT","native mechanics fixture",false);
        f.inputs.addLast(input);lab.execute(lane,f,f==lane.a?lane.b:lane.a);
    }
    void hit(int slot,boolean sprint)throws Exception{lastDamage=0;send(lane.a,slot,false,true,false,false,sprint);}
    static double horizontal(Player p){return Math.hypot(p.getVelocity().getX(),p.getVelocity().getZ());}
    boolean loaded(){var item=a().getInventory().getItem(4);return item!=null&&item.getItemMeta() instanceof CrossbowMeta m&&m.hasChargedProjectiles();}
    int arrows(){int n=0;for(var i:a().getInventory().getContents())if(i!=null&&i.getType()==Material.ARROW)n+=i.getAmount();return n;}
    void damage(EntityDamageByEntityEvent e){if(e.getDamager()==a()&&e.getEntity()==b())lastDamage=e.isCancelled()?0:e.getFinalDamage();}
    void shot(EntityShootBowEvent e){if(e.getEntity()==a())shots.add(Map.of("weapon",e.getBow()==null?"UNKNOWN":e.getBow().getType().name(),"force",e.getForce(),"speed",e.getProjectile().getVelocity().length()));}
    void mark(String name,boolean pass,Map<String,Object> values){var row=new LinkedHashMap<String,Object>(values);row.put("case",name);row.put("pass",pass);results.add(row);lab.getLogger().info("NATIVE_COMBAT "+name+" "+(pass?"PASS":"FAIL")+" "+LivePracticeLab.JSON.toJson(values));}
    void finish()throws Exception{
        done=true;boolean pass=results.stream().allMatch(r->Boolean.TRUE.equals(r.get("pass")));var report=Map.of("status",pass?"PASS":"FAIL","cases",results,"shots",shots,"executor","same LivePracticeLab.execute as training; original WaveDog native shield/release and native Player.attack", "human_remote_client_comparison",false);
        Files.writeString(lab.getDataFolder().toPath().resolve("native-combat-probe.json"),LivePracticeLab.JSON.toJson(report));lab.record(lab.judge,"native_combat_fixture_end",report);
        if(!pass){lab.running=false;throw new IllegalStateException("Native combat mechanics audit failed; training remains stopped");}completion.run();
    }
}
