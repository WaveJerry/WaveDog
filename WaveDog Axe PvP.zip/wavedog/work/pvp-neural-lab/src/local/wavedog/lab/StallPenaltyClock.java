package local.wavedog.lab;

/** Public elapsed match time; monotonic wall clock, no damage or hidden opponent state. */
final class StallPenaltyClock {
    static final long INTERVAL_NANOS=120_000_000_000L;
    static final double PENALTY=.25;
    final long started;int count;
    StallPenaltyClock(long started){this.started=started;}
    int poll(long now){int reached=(int)Math.max(0,(now-started)/INTERVAL_NANOS);int due=Math.max(0,reached-count);count+=due;return due;}
    double seconds(long now){return Math.max(0,(now-started)/1_000_000_000.0);}
    double totalReward(){return -PENALTY*count;}
}
