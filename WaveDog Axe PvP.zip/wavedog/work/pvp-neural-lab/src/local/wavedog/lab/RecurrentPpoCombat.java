package local.wavedog.lab;

import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Recurrent actor/critic with joint-action PPO clipping and truncated sequence backpropagation. */
final class RecurrentPpoCombat implements AutoCloseable {
    static final int F=CombatLearner.F+2,H=64,STRIDE=F+H+1,GATE=H*STRIDE;
    static final int POLICY=3*GATE,VALUE=POLICY+CombatLearner.O*(H+1),N=VALUE+H+1;
    static final int OLD_F=CombatLearner.F,OLD_STRIDE=OLD_F+H+1;
    static final int OLD_GATE=H*OLD_STRIDE,OLD_POLICY=3*OLD_GATE;
    static final int OLD_N=OLD_POLICY+CombatLearner.O*(H+1)+H+1;
    static final int CUE_F=CombatLearner.F+1,CUE_STRIDE=CUE_F+H+1;
    static final int CUE_GATE=H*CUE_STRIDE,CUE_POLICY=3*CUE_GATE;
    static final int CUE_N=CUE_POLICY+CombatLearner.O*(H+1)+H+1;
    // Preserve the GRU64 checkpoint shape while covering multi-second tactics.
    static final int SEQUENCE=64,EPOCHS=4,SEQUENCES=4;
    static final double GAMMA=.997,LAMBDA=.99,CLIP=.2,ENTROPY=.0001,LR=.00015;
    static final Gson JSON=new Gson();
    static final class State {
        int format=1;long updates,episodes,penaltyUpdates,samples,optimizerSteps,bootstrapExamples;
        double[] w=new double[N],m=new double[N],v=new double[N];double lastKl,lastClipFraction,lastValueLoss;
    }
    static final class Frame {
        final double[] x,previous,z=new double[H],r=new double[H],n=new double[H],h=new double[H],p=new double[CombatLearner.O],baseP=new double[CombatLearner.O];
        final double[] mixture=new double[CombatLearner.WIDTH.length];double value;
        Frame(double[] x,double[] previous){this.x=x;this.previous=previous;}
    }
    static final class Sample {
        final long tick;final double[] x,previous;final int[] action;final double logp,value;final double[] oldHeadLogp;final int publicHurtEvidence;
        final boolean[] executedHeads;double reward,advantage,target;
        Sample(long tick,Frame f,int[] action){this(tick,f,action,0);}
        Sample(long tick,Frame f,int[] action,int publicHurtEvidence){this.tick=tick;x=f.x;previous=f.previous;this.action=action.clone();logp=logProbability(f.p,action);value=f.value;this.publicHurtEvidence=publicHurtEvidence;
            oldHeadLogp=new double[action.length];executedHeads=new boolean[action.length];
            for(int head=0;head<action.length;head++)oldHeadLogp[head]=Math.log(Math.max(1e-30,f.p[CombatLearner.OFF[head]+action[head]]));}
        Sample(Sample o){tick=o.tick;x=o.x;previous=o.previous;action=o.action;logp=o.logp;value=o.value;publicHurtEvidence=o.publicHurtEvidence;
            oldHeadLogp=o.oldHeadLogp.clone();executedHeads=o.executedHeads.clone();reward=o.reward;}
        double executedLogp(){double total=0;for(int head=0;head<action.length;head++)if(executedHeads[head])total+=oldHeadLogp[head];return total;}
    }
    final Path checkpoint;final ExecutorService trainer;volatile State state;volatile String error="";
    final AtomicLong decisions=new AtomicLong(),attempts=new AtomicLong(),emptyAttempts=new AtomicLong(),whiffAttempts=new AtomicLong(),lightAttempts=new AtomicLong(),dropped=new AtomicLong();final AtomicInteger pending=new AtomicInteger();
    RecurrentPpoCombat(Path folder)throws Exception {
        Files.createDirectories(folder);checkpoint=folder.resolve("recurrent-ppo.json");
        if(Files.exists(checkpoint)){
            state=JSON.fromJson(Files.readString(checkpoint),State.class);
            if(state!=null&&state.w!=null&&(state.w.length==OLD_N||state.w.length==CUE_N)){
                Files.copy(checkpoint,checkpoint.resolveSibling("recurrent-ppo.before-reach-margin-"+System.currentTimeMillis()+".json"));
                state=migrateInputs(state,state.w.length==OLD_N?OLD_F:CUE_F);save();
            }
            validate(state);
        }else{state=new State();Random random=new Random(991127);for(int i=0;i<VALUE;i++)state.w[i]=random.nextGaussian()*.045;for(int j=0;j<H;j++)state.w[j*STRIDE+F+H]=-.7;save();}
        trainer=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"WaveDog-recurrent-PPO");t.setDaemon(true);return t;});
    }
    static void validate(State s){if(s==null||s.format!=1||s.w.length!=N||s.m.length!=N||s.v.length!=N)throw new IllegalArgumentException("Recurrent PPO checkpoint shape");for(double[] a:List.of(s.w,s.m,s.v))for(double v:a)if(!Double.isFinite(v))throw new IllegalArgumentException("Nonfinite PPO checkpoint");}
    static State migrateInputs(State old,int sourceF){
        int sourceStride=sourceF+H+1,sourcePolicy=3*H*sourceStride;
        int sourceN=sourcePolicy+CombatLearner.O*(H+1)+H+1;
        if(old==null||old.w==null||old.m==null||old.v==null
            ||(sourceF!=OLD_F&&sourceF!=CUE_F)
            ||old.w.length!=sourceN||old.m.length!=sourceN||old.v.length!=sourceN)
            throw new IllegalArgumentException("Unexpected old GRU shape");
        State next=new State();next.format=old.format;next.updates=old.updates;
        next.episodes=old.episodes;next.penaltyUpdates=old.penaltyUpdates;
        next.samples=old.samples;next.optimizerSteps=old.optimizerSteps;
        next.bootstrapExamples=old.bootstrapExamples;next.lastKl=old.lastKl;
        next.lastClipFraction=old.lastClipFraction;next.lastValueLoss=old.lastValueLoss;
        next.w=expandInputs(old.w,sourceF);next.m=expandInputs(old.m,sourceF);
        next.v=expandInputs(old.v,sourceF);validate(next);return next;
    }
    static double[] expandInputs(double[] old,int sourceF){
        double[] expanded=new double[N];
        int sourceStride=sourceF+H+1,sourceGate=H*sourceStride;
        int sourcePolicy=3*sourceGate;
        for(int gate=0;gate<3;gate++)for(int neuron=0;neuron<H;neuron++){
            int from=gate*sourceGate+neuron*sourceStride;
            int to=gate*GATE+neuron*STRIDE;
            System.arraycopy(old,from,expanded,to,sourceF);
            // New input weights start at zero; all prior weights and Adam
            // moments retain their exact values and positions within a gate.
            System.arraycopy(old,from+sourceF,expanded,to+F,H+1);
        }
        System.arraycopy(old,sourcePolicy,expanded,POLICY,old.length-sourcePolicy);
        return expanded;
    }
    Actor actor(long seed,boolean learning){return new Actor(state.w.clone(),seed,learning);}
    final class Actor {
        final double[] weights,history=new double[12];double[] hidden=new double[H];final boolean learning;final Random random;
        final ArrayList<Sample> episode=new ArrayList<>();final ArrayDeque<Sample> recent=new ArrayDeque<>();Sample executing,last;long observed=-1;
        int nativeFeedbackApplied,publicOpponentSwingAge=-1;
        ExperienceLibrary.Focus focus=ExperienceLibrary.Focus.FREE;int publicHurtEvidence;
        Actor(double[] weights,long seed,boolean learning){this.weights=weights;this.learning=learning;random=new Random(seed);}
        DuelPolicy.Input act(long tick,long due,DuelPolicy.Self self,DuelPolicy.Seen seen,ArenaLayout.Cell cell,DuelPolicy.Style style,float yaw,float pitch){
            double[] x=Arrays.copyOf(CombatLearner.features(self,seen,cell,style,yaw,pitch,tick,history),F);
            CombatLearner.conditionOnFocus(x,focus);
            x[OLD_F]=publicOpponentSwingAge>=0&&publicOpponentSwingAge<=10
                ?1.0/(1.0+publicOpponentSwingAge/5.0):0;
            if(seen!=null&&seen.visible()){
                // Public eye-to-player-box margin around the native 3-block
                // reach. Geometry is an estimate; Paper receipts remain truth.
                double dx=Math.max(0,Math.abs(seen.x()-self.x())-.3);
                double dz=Math.max(0,Math.abs(seen.z()-self.z())-.3);
                double dy=Math.max(0,Math.max(seen.y()-self.eyeY(),self.eyeY()-(seen.y()+1.8)));
                x[CUE_F]=Math.tanh((Math.sqrt(dx*dx+dy*dy+dz*dz)-3.0)/.75);
            }
            Frame frame=forward(weights,x,hidden,publicHurtEvidence);hidden=frame.h.clone();int[] a=new int[CombatLearner.WIDTH.length];
            for(int head=0;head<a.length;head++){
                if(!learning){int best=0;for(int k=1;k<CombatLearner.WIDTH[head];k++)if(frame.p[CombatLearner.OFF[head]+k]>frame.p[CombatLearner.OFF[head]+best])best=k;a[head]=best;}
                else{double draw=random.nextDouble();a[head]=CombatLearner.WIDTH[head]-1;for(int k=0;k<CombatLearner.WIDTH[head];k++)if((draw-=frame.p[CombatLearner.OFF[head]+k])<=0){a[head]=k;break;}}
            }
            if(learning){last=new Sample(tick,frame,a,publicHurtEvidence);episode.add(last);recent.addLast(last);while(recent.size()>256)recent.removeFirst();if(episode.size()>=4096)submit(0,false);}
            if(seen!=null&&seen.visible()&&seen.captured()!=observed){System.arraycopy(x,18,history,0,12);observed=seen.captured();}decisions.incrementAndGet();return CombatLearner.decode(tick,due,self,yaw,pitch,a);
        }
        Sample sample(long decided){
            for(var it=recent.descendingIterator();it.hasNext();){var s=it.next();if(s.tick==decided)return s;}
            // Native bout receipts arrive after death. Keep earlier decisions
            // attributable across the entire episode, not only its last 256 frames.
            for(int i=episode.size()-1;i>=0;i--)if(episode.get(i).tick==decided)return episode.get(i);
            return null;
        }
        void executed(long decided,Set<Integer> ignoredHeads){if(!learning)return;var s=sample(decided);if(s==null)return;
            for(int head=0;head<s.executedHeads.length;head++)s.executedHeads[head]=!ignoredHeads.contains(head);}
        void beginInput(long decided){executing=learning?sample(decided):null;}
        void endInput(){executing=null;}
        void outcomeFeedback(double dealt,double received){if(!learning)return;var s=executing!=null?executing:last;if(s!=null)s.reward+=(dealt-received)/20;}
        boolean nativeStepFeedback(long tick,double reward){
            if(!learning||!Double.isFinite(reward)||Math.abs(reward)>1)return false;
            for(int i=episode.size()-1;i>=0;i--)if(episode.get(i).tick==tick){
                episode.get(i).reward+=reward;nativeFeedbackApplied++;return true;
            }
            return false;
        }
        void attackOutcome(long decided,double charge,boolean effective,boolean brokeShield){attackOutcome(decided,charge,effective,brokeShield,false);}
        void attackOutcome(long decided,double charge,boolean effective,boolean brokeShield,boolean whiff){attempts.incrementAndGet();if(charge<.5)lightAttempts.incrementAndGet();if(!effective&&!brokeShield)emptyAttempts.incrementAndGet();if(whiff)whiffAttempts.incrementAndGet();if(!learning)return;var s=sample(decided);if(s!=null)s.reward+=brokeShield?.02:effective?0:whiff?-.006:-.003;}
        void finish(boolean win,double health){submit((win?1:-1)+(win?health/40:0),true);}
        void penalizeStall(){submit(-StallPenaltyClock.PENALTY,false);}
        void submit(double terminalReward,boolean terminal){
            if(!learning||episode.isEmpty())return;
            if(terminal){
                double shared=.4*terminalReward/episode.size();
                for(var sample:episode)sample.reward+=shared;
                episode.getLast().reward+=.6*terminalReward;
            }else episode.getLast().reward+=terminalReward;
            var copy=new ArrayList<Sample>();for(var s:episode)copy.add(new Sample(s));double bootstrap=terminal?0:episode.getLast().value;episode.clear();recent.clear();last=executing=null;
            if(pending.incrementAndGet()>16){pending.decrementAndGet();dropped.incrementAndGet();return;}
            trainer.execute(()->{try{train(copy,bootstrap,terminal,random.nextLong());}catch(Exception e){error=e.toString();}finally{pending.decrementAndGet();}});
        }
    }
    static double sigmoid(double x){if(x>=0){double e=Math.exp(-x);return 1/(1+e);}double e=Math.exp(x);return e/(1+e);}
    /** A small charge preference is part of the policy distribution, not an input veto. */
    static double explorationPrior(double[] x,int head,int action){
        // During an ESCAPE research bout, sample a short withdrawal after a
        // real swing at the melee boundary. The network still selects every
        // input and PPO learns from native success or punishment.
        // x[18]/x[20] are orthogonal rotated position components, not a
        // universal forward/lateral pair. Their radius is bearing invariant;
        // x[78] is the public observed yaw error used to align input actions.
        double range=Math.hypot(x[18],x[20]);
        boolean aligned=Math.abs(x[78])<.25;
        boolean edge=x[31]>.5&&range>.40&&range<.58&&aligned;
        // Only the ESCAPE research focus broadens sampling after an actual
        // local swing. PPO still selects and credits the movement head.
        boolean retreatStudy=x[31]>.5&&x[86]>.5&&x[1]<.42&&x[7]<.5&&x[8]<.5
            &&range>.02&&range<.58&&aligned;
        if(head==0&&retreatStudy){
            if(action==2)return edge?.9:1.4;
            if(action==7||action==8)return edge?.3:.2;
        }
        if(head==1&&action==1&&retreatStudy)return .6;
        if(head==2&&action==1&&retreatStudy&&x[2]>.5)return .75;
        // A public swing opens a counter window; it never proves a shield block.
        boolean observedCloseSwing=x[OLD_F]>.45&&x[31]>.5&&x[86]>.5
            &&x[7]>.5&&x[1]>.8&&range<.58;
        if(observedCloseSwing&&head==4&&action==2)return .8;
        // Purposeful normal criticals can start inside or outside reach.
        // The sampled approach is aligned to the visible target; the eventual
        // hit still needs a real descending native critical receipt.
        boolean jumpEntry=x[31]>.5&&x[84]>.5&&x[2]>.5&&x[1]>.85
            &&range>.1&&range<.85&&Math.abs(x[78])<.2&&x[23]<.5;
        boolean longEntry=x[CUE_F]>.1;
        if(jumpEntry&&head==0&&action==1)return longEntry?.8:.2;
        if(jumpEntry&&head==1&&action==1)return longEntry?.7:.15;
        if(jumpEntry&&head==2&&action==1)return longEntry?1.05:.3;
        // After takeoff the goal remains an actual landing/hit window. Public
        // reach margin guides sampling throughout flight, not only at jump.
        boolean criticalFlight=x[31]>.5&&x[84]>.5&&x[2]<.5&&x[1]>.7
            &&aligned&&x[23]<.5&&x[7]<.5;
        if(criticalFlight&&head==0&&action==1&&x[CUE_F]>.08&&x[CUE_F]<.9)
            return .45;
        if(criticalFlight&&head==0&&action==0&&x[CUE_F]<-.45)
            return .3;
        // A separate edge study samples native sprint attacks while grounded.
        // The actual hit and sprint state are checked by the Paper receipt.
        boolean sprintEdge=x[31]>.5&&x[85]>.5&&x[2]>.5&&x[1]>.75
            &&x[CUE_F]>-.2&&x[CUE_F]<.55&&aligned&&x[7]<.5&&x[8]<.5&&x[23]<.5;
        if(sprintEdge&&head==0&&action==1)return .2;
        if(sprintEdge&&head==1&&action==1)return .45;
        if(sprintEdge&&head==4&&action==2)return .3;
        // On ordinary entry, a ready first hit near the public reach edge is
        // usually valuable. Rising flight is excluded because it can be a
        // deliberate falling-critical setup.
        boolean earlyEntryHit=x[31]>.5&&aligned&&x[1]>.85&&x[23]<.5
            &&x[7]<.5&&x[8]<.5&&x[CUE_F]>-.55&&x[CUE_F]<.12
            &&(x[2]>.5||x[4]<-.08);
        if(earlyEntryHit&&head==4&&action==2)return .45;
        // A defender can sample shield or a ready first hit when the publicly
        // seen opponent falls toward reach. No hidden jump key is read.
        boolean fallingEntry=x[31]>.5&&x[2]>.5&&x[19]>.05&&x[61]>x[19]
            &&range>.1&&range<.58&&aligned;
        if(fallingEntry&&head==4&&action==1&&x[82]>.5&&x[6]>.5&&x[7]<.5)return .4;
        if(fallingEntry&&head==4&&action==2&&x[85]>.5&&x[1]>.75&&x[23]<.5)return .35;
        boolean swordTempo=x[31]>.5&&x[89]>.5&&x[1]>.7&&x[23]<.5
            &&range>.02&&range<.48&&Math.abs(x[78])<.3;
        // The retained checkpoint assigned sword about 0.5% probability even
        // here. Research bouts need actual sword samples before PPO can compare
        // native damage; the model still samples and owns the hotbar decision.
        if(swordTempo&&head==5&&action==1)return 5.5;
        // Arrow trajectories are public entity position/velocity observations.
        // Predict gravity and drag relative to current player motion, then
        // sample the side that leaves the collision corridor quickest.
        int dodgeSide=predictedArrowDodgeSide(x);
        if(dodgeSide!=0&&head==0&&action==dodgeSide)return x[92]>.5?1.2:.7;
        if(dodgeSide!=0&&head==1&&action==1&&x[7]<.5)return .35;
        if(dodgeSide!=0&&head==2&&action==1&&x[2]>.5)return x[92]>.5?.5:.25;
        if(head==4&&action==1&&edge&&x[82]>.5&&x[6]>.5&&x[7]<.5&&x[1]<.42)
            return .4;
        if(head==4&&action==2){
            if(x[1]>=.85)return .25;
            if(x[23]<.5&&x[0]>.3)return -5.5;
        }
        return 0;
    }
    static double unTanh(double v){
        v=Math.max(-.98,Math.min(.98,v));
        return .5*Math.log((1+v)/(1-v));
    }
    static int predictedArrowDodgeSide(double[] x){
        if(x[31]<.5)return 0;
        for(int i=0;i<4;i++){
            int z=32+6*i;
            double px=unTanh(x[z])*12,py=unTanh(x[z+1])*6,pz=unTanh(x[z+2])*12;
            double vx=x[z+3]*4,vy=x[z+4]*4,vz=x[z+5]*4;
            if(vx*vx+vy*vy+vz*vz<.01||Math.hypot(px,pz)>12)continue;
            for(int tick=1;tick<=12;tick++){
                double dx=vx-x[3],dy=vy-x[4],dz=vz-x[5];
                double segment=Math.max(1e-9,dx*dx+dz*dz);
                double alpha=Math.max(0,Math.min(1,-(px*dx+pz*dz)/segment));
                double closestX=px+dx*alpha,closestY=py+dy*alpha;
                double closestZ=pz+dz*alpha;
                px+=dx;py+=dy;pz+=dz;
                vx*=.99;vy=(vy-.05)*.99;vz*=.99;
                if(closestY<-.2||closestY>2.0)continue;
                if(Math.abs(closestX)<1.0&&Math.abs(closestZ)<1.0)
                    return closestZ>0?3:4;
            }
        }
        return 0;
    }
    static int rangedTarget(double[] x,int head){
        if(head==0){
            if(x[0]>=.3||x[31]<.5||Math.max(Math.abs(x[18]),Math.abs(x[20]))>.6)return -1;
            if(Math.min(Math.min(x[56],x[57]),Math.min(x[58],x[59]))<.15)return -1;
            return x[20]>.15?7:x[20]<-.15?8:2;
        }
        // A charged crossbow can fire promptly after a safe melee exit;
        // loading an empty one still needs the wider separation window.
        double rangedBoundary=x[91]>.5&&x[11]>.5?.54:.62;
        if(x[31]<.5||Math.max(Math.abs(x[18]),Math.abs(x[20]))<rangedBoundary)return -1;
        boolean bow=x[90]>.5,crossbow=x[91]>.5;
        boolean opening=x[17]<.042&&x[0]>.5;
        if(!bow&&!crossbow&&!opening)return -1;
        if(x[10]<=0&&!(crossbow&&x[11]>.5))return -1;
        if(!bow&&!crossbow)crossbow=true;
        if(head==5)return bow?2:3;
        if(head!=4)return -1;
        boolean using=x[8]>.5,held=bow?Math.abs(x[12]-.125)<.03:Math.abs(x[12]-.5)<.03;
        if(bow&&using&&held&&x[9]>=.28)return 4;
        return 3;
    }
    static double rangedMix(double[] x,int head){
        if(head==0)return rangedTarget(x,head)<0?0:.30;
        if(head!=4&&head!=5)return 0;
        int target=rangedTarget(x,head);
        if(target<0)return 0;
        boolean using=x[8]>.5,focusedHeld=x[90]>.5?Math.abs(x[12]-.125)<.03:Math.abs(x[12]-.5)<.03;
        if(using&&focusedHeld)return .85;
        if(x[90]<.5&&x[91]<.5)return head==5?.20:.24;
        return head==5?.45:.55;
    }
    static Frame forward(double[] w,double[] x,double[] previous){
        return forward(w,x,previous,0);
    }
    static double finisherBias(double[] x,int publicHurtEvidence,int head,int action){
        if(head!=4||action!=2||publicHurtEvidence<7||x[31]<.5||x[1]<.55)return 0;
        return Math.max(Math.abs(x[18]),Math.abs(x[20]))<.48?2.3:0;
    }
    static Frame forward(double[] w,double[] x,double[] previous,int publicHurtEvidence){
        Frame f=new Frame(x,previous);
        for(int j=0;j<H;j++){double z=w[j*STRIDE+F+H],r=w[GATE+j*STRIDE+F+H];for(int k=0;k<F;k++){z+=w[j*STRIDE+k]*x[k];r+=w[GATE+j*STRIDE+k]*x[k];}for(int k=0;k<H;k++){z+=w[j*STRIDE+F+k]*previous[k];r+=w[GATE+j*STRIDE+F+k]*previous[k];}f.z[j]=sigmoid(z);f.r[j]=sigmoid(r);}
        for(int j=0;j<H;j++){int off=2*GATE+j*STRIDE;double n=w[off+F+H];for(int k=0;k<F;k++)n+=w[off+k]*x[k];for(int k=0;k<H;k++)n+=w[off+F+k]*f.r[k]*previous[k];f.n[j]=Math.tanh(n);f.h[j]=(1-f.z[j])*f.n[j]+f.z[j]*previous[j];}
        for(int head=0;head<CombatLearner.WIDTH.length;head++){double max=-Double.MAX_VALUE,total=0;for(int a=0;a<CombatLearner.WIDTH[head];a++){int at=CombatLearner.OFF[head]+a,off=POLICY+at*(H+1);double v=w[off+H]+explorationPrior(x,head,a)+finisherBias(x,publicHurtEvidence,head,a);for(int j=0;j<H;j++)v+=w[off+j]*f.h[j];f.p[at]=v;max=Math.max(max,v);}for(int a=0;a<CombatLearner.WIDTH[head];a++){int at=CombatLearner.OFF[head]+a;f.p[at]=Math.exp(f.p[at]-max);total+=f.p[at];}int target=rangedTarget(x,head);double mix=rangedMix(x,head);f.mixture[head]=mix;
            for(int a=0;a<CombatLearner.WIDTH[head];a++){int at=CombatLearner.OFF[head]+a;f.baseP[at]=f.p[at]/total;f.p[at]=(1-mix)*f.baseP[at]+(a==target?mix:0);}}
        f.value=w[VALUE+H];for(int j=0;j<H;j++)f.value+=w[VALUE+j]*f.h[j];return f;
    }
    static double logProbability(double[] p,int[] action){double v=0;for(int h=0;h<action.length;h++)v+=Math.log(Math.max(1e-30,p[CombatLearner.OFF[h]+action[h]]));return v;}
    static double logProbability(double[] p,int[] action,boolean[] executedHeads){double v=0;for(int h=0;h<action.length;h++)if(executedHeads[h])v+=Math.log(Math.max(1e-30,p[CombatLearner.OFF[h]+action[h]]));return v;}
    /** Ascending gradient, with an incoming recurrent gradient from the following time step. */
    static double[] backward(double[] w,Frame f,double[] logits,double valueGradient,double[] carry,double[] g){
        double[] dh=carry.clone(),dp=new double[H],dn=new double[H],dz=new double[H],dr=new double[H],drp=new double[H];
        for(int a=0;a<logits.length;a++){int off=POLICY+a*(H+1);g[off+H]+=logits[a];for(int j=0;j<H;j++){g[off+j]+=logits[a]*f.h[j];dh[j]+=logits[a]*w[off+j];}}
        g[VALUE+H]+=valueGradient;for(int j=0;j<H;j++){g[VALUE+j]+=valueGradient*f.h[j];dh[j]+=valueGradient*w[VALUE+j];dn[j]=dh[j]*(1-f.z[j])*(1-f.n[j]*f.n[j]);dz[j]=dh[j]*(f.previous[j]-f.n[j])*f.z[j]*(1-f.z[j]);dp[j]=dh[j]*f.z[j];}
        for(int j=0;j<H;j++){int off=2*GATE+j*STRIDE;g[off+F+H]+=dn[j];for(int k=0;k<F;k++)g[off+k]+=dn[j]*f.x[k];for(int k=0;k<H;k++){g[off+F+k]+=dn[j]*f.r[k]*f.previous[k];drp[k]+=w[off+F+k]*dn[j];}}
        for(int k=0;k<H;k++){dr[k]=drp[k]*f.previous[k]*f.r[k]*(1-f.r[k]);dp[k]+=drp[k]*f.r[k];}
        for(int j=0;j<H;j++)for(int gate=0;gate<2;gate++){double d=gate==0?dz[j]:dr[j];int off=gate*GATE+j*STRIDE;g[off+F+H]+=d;for(int k=0;k<F;k++)g[off+k]+=d*f.x[k];for(int k=0;k<H;k++){g[off+F+k]+=d*f.previous[k];dp[k]+=w[off+F+k]*d;}}return dp;
    }
    static double clippedPolicyCoefficient(double advantage,double ratio){return (advantage>0&&ratio>1+CLIP)||(advantage<0&&ratio<1-CLIP)?0:advantage*ratio;}
    static void advantages(List<Sample> data,double bootstrap){double next=bootstrap,gae=0;for(int i=data.size()-1;i>=0;i--){var s=data.get(i);double delta=s.reward+GAMMA*next-s.value;gae=delta+GAMMA*LAMBDA*gae;s.advantage=gae;s.target=gae+s.value;next=s.value;}}
    /** Spread the fixed PPO work across the whole bout instead of repeatedly drawing nearby windows. */
    static int sequenceStart(Random random,int samples,int segment,int segments){
        int possible=Math.max(1,samples-SEQUENCE+1);
        int first=(int)((long)segment*possible/segments),end=(int)((long)(segment+1)*possible/segments);
        return first+random.nextInt(Math.max(1,end-first));
    }
    static State copy(State o){State s=new State();s.w=o.w.clone();s.m=o.m.clone();s.v=o.v.clone();s.updates=o.updates;s.episodes=o.episodes;s.penaltyUpdates=o.penaltyUpdates;s.samples=o.samples;s.optimizerSteps=o.optimizerSteps;s.bootstrapExamples=o.bootstrapExamples;s.lastKl=o.lastKl;s.lastClipFraction=o.lastClipFraction;s.lastValueLoss=o.lastValueLoss;return s;}
    static void adam(State s,double[] g,double rate){double norm=0;for(double v:g)norm+=v*v;double scale=norm>.25?.5/Math.sqrt(norm):1;s.optimizerSteps++;double b1=1-Math.pow(.9,s.optimizerSteps),b2=1-Math.pow(.999,s.optimizerSteps);for(int i=0;i<N;i++){double d=g[i]*scale;s.m[i]=.9*s.m[i]+.1*d;s.v[i]=.999*s.v[i]+.001*d*d;s.w[i]+=rate*(s.m[i]/b1)/(Math.sqrt(s.v[i]/b2)+1e-8);}}
    void train(List<Sample> data,double bootstrap,boolean terminal,long seed)throws Exception{
        advantages(data,bootstrap);double mean=0,square=0;for(var sample:data){mean+=sample.advantage;square+=sample.advantage*sample.advantage;}mean/=data.size();double sd=Math.sqrt(Math.max(1e-6,square/data.size()-mean*mean));State s=copy(state);Random random=new Random(seed);int trained=0;
        int sequences=Math.min(SEQUENCES,Math.max(1,(data.size()+SEQUENCE-1)/SEQUENCE));
        for(int epoch=0;epoch<EPOCHS;epoch++){
            double[] g=new double[N];double kl=0,clipped=0,valueLoss=0;int total=0;
            for(int segment=0;segment<sequences;segment++){
                int start=sequenceStart(random,data.size(),segment,sequences),length=Math.min(SEQUENCE,data.size()-start);Frame[] frames=new Frame[length];double[] h=data.get(start).previous;
                for(int j=0;j<length;j++){frames[j]=forward(s.w,data.get(start+j).x,h,data.get(start+j).publicHurtEvidence);h=frames[j].h;}double[] carry=new double[H];
                for(int j=length-1;j>=0;j--){Sample sample=data.get(start+j);Frame f=frames[j];double logRatio=Math.max(-20,Math.min(20,logProbability(f.p,sample.action,sample.executedHeads)-sample.executedLogp())),ratio=Math.exp(logRatio);double advantage=Math.max(-5,Math.min(5,(sample.advantage-mean)/sd));double coeff=clippedPolicyCoefficient(advantage,ratio);double[] logits=new double[CombatLearner.O];
                    for(int head=0;head<sample.action.length;head++){if(!sample.executedHeads[head])continue;double sum=0,mix=f.mixture[head];for(int a=0;a<CombatLearner.WIDTH[head];a++){int at=CombatLearner.OFF[head]+a;if(mix==0)sum+=f.p[at]*Math.log(Math.max(1e-30,f.p[at]));}
                        int chosen=CombatLearner.OFF[head]+sample.action[head];double factor=(1-mix)*f.baseP[chosen]/Math.max(1e-30,f.p[chosen]);
                        for(int a=0;a<CombatLearner.WIDTH[head];a++){int at=CombatLearner.OFF[head]+a;logits[at]=coeff*factor*((a==sample.action[head]?1:0)-f.baseP[at])+(mix==0?ENTROPY*f.p[at]*(sum-Math.log(Math.max(1e-30,f.p[at]))):0);}}
                    double residual=Math.max(-5,Math.min(5,sample.target-f.value));carry=backward(s.w,f,logits,.5*residual,carry,g);kl+=(ratio-1)-logRatio;clipped+=ratio>1+CLIP||ratio<1-CLIP?1:0;valueLoss+=Math.pow(sample.target-f.value,2);total++;
                }
            }
            for(int i=0;i<N;i++)g[i]/=total;s.lastKl=kl/total;s.lastClipFraction=clipped/total;s.lastValueLoss=valueLoss/total;if(epoch>0&&s.lastKl>.08)break;adam(s,g,LR);s.updates++;trained+=total;
        }
        s.samples+=trained;if(terminal)s.episodes++;else s.penaltyUpdates++;validate(s);state=s;save();
    }
    /** Offline transfer from the actual old policy; no scripted decision in live inference. */
    void warmStart(double[] teacher,int count,int epochs)throws Exception{
        State s=copy(state);Random random=new Random(731998);var examples=new ArrayList<double[]>();var targets=new ArrayList<double[]>();var cell=ArenaLayout.cells().getFirst();
        for(int i=0;i<count;i++){float yaw=(float)(random.nextDouble()*360),pitch=(float)(random.nextDouble()*180-90);double bearing=Math.toRadians(yaw+90+random.nextDouble()*160-80),range=.5+random.nextDouble()*10;boolean ground=random.nextDouble()<.7;double y=221+(ground?0:random.nextDouble()*1.2);int held=CombatLearner.SLOT[random.nextInt(4)];var self=new DuelPolicy.Self(cell.cx(),y,cell.cz(),y+1.62,random.nextGaussian()*.1,ground?0:random.nextDouble()*.8-.4,random.nextGaussian()*.1,ground,false,(float)random.nextDouble(),5+random.nextDouble()*15,random.nextBoolean(),false,random.nextInt(6),random.nextBoolean(),random.nextBoolean(),random.nextInt(30),held);var seen=new DuelPolicy.Seen(i,i,random.nextDouble()>.2,cell.cx()+Math.cos(bearing)*range,221+(random.nextDouble()<.2?1:0),cell.cz()+Math.sin(bearing)*range,(float)random.nextInt(360),random.nextBoolean(),new String[]{"DIAMOND_AXE","DIAMOND_SWORD","BOW","CROSSBOW"}[random.nextInt(4)],random.nextBoolean(),i%3,List.of());double[] x=CombatLearner.features(self,seen,cell,DuelPolicy.Style.values()[i%6],yaw,pitch,i,new double[12]);examples.add(x);targets.add(CombatLearner.probabilities(teacher,x));}
        int[] order=new int[count];for(int i=0;i<count;i++)order[i]=i;
        for(int epoch=0;epoch<epochs;epoch++){for(int i=count-1;i>0;i--){int j=random.nextInt(i+1),v=order[i];order[i]=order[j];order[j]=v;}for(int first=0;first<count;first+=32){double[] g=new double[N];int end=Math.min(first+32,count);for(int i=first;i<end;i++){int at=order[i];double[] previous=new double[H];for(int j=0;j<H;j++)previous[j]=random.nextGaussian()*.15;Frame f=forward(s.w,examples.get(at),previous);double[] logits=new double[CombatLearner.O];for(int a=0;a<logits.length;a++)logits[a]=targets.get(at)[a]-f.p[a];backward(s.w,f,logits,0,new double[H],g);}for(int j=0;j<N;j++)g[j]/=end-first;adam(s,g,.001);}}
        s.bootstrapExamples=count;validate(s);state=s;save();
    }
    void save()throws Exception{Path tmp=checkpoint.resolveSibling("recurrent-ppo.json.tmp");Files.writeString(tmp,JSON.toJson(state));Files.move(tmp,checkpoint,StandardCopyOption.REPLACE_EXISTING);}
    Map<String,Object> status(){State s=state;var result=new LinkedHashMap<String,Object>();result.put("enabled",true);result.put("architecture",F+" public/history inputs ->GRU64 memory ->9 policy heads + value critic; recurrent PPO, sequence BPTT64");result.put("parameters",N);result.put("decisions",decisions.get());result.put("gradient_updates",s.updates);result.put("trained_episodes",s.episodes);result.put("training_samples",s.samples);result.put("stall_penalty_updates",s.penaltyUpdates);result.put("bootstrap_examples_not_matches",s.bootstrapExamples);result.put("pending",pending.get());result.put("dropped_rollouts",dropped.get());result.put("last_approx_kl",s.lastKl);result.put("last_clip_fraction",s.lastClipFraction);result.put("last_value_loss",s.lastValueLoss);result.put("attack_attempts",attempts.get());result.put("ineffective_attack_attempts",emptyAttempts.get());result.put("whiff_attempts",whiffAttempts.get());result.put("low_charge_attempts",lightAttempts.get());result.put("last_error",error);return result;}
    public void close(){trainer.shutdown();try{if(!trainer.awaitTermination(30,TimeUnit.SECONDS))error="Pending training did not flush within30seconds";}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
