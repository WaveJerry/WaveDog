package local.wavedog.lab;

import java.util.*;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageModifier;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.util.Vector;

/** Client-physics bridge, not a combat policy. Never chooses a target, swing or defence. */
final class NativeMeleeInput implements Listener {
    static final class Attempt { final Vector before;boolean blocked,positiveDamage,velocityPacket,shieldFacingBefore,shieldFallback;double damage;Attempt(Player p){before=p.getVelocity();} }
    final Map<UUID,Attempt> active=new HashMap<>();
    long restoredShieldFrames;
    static boolean restoreShieldMotion(boolean blocked,boolean positiveDamage,boolean velocityPacket){return blocked&&!positiveDamage&&!velocityPacket;}
    Attempt attack(Player own,Player target){
        var attempt=new Attempt(target);active.put(target.getUniqueId(),attempt);
        var attacker=((CraftPlayer)own).getHandle();var defender=((CraftPlayer)target).getHandle();
        boolean axe=attacker.canDisableShield();
        attempt.shieldFacingBefore=axe&&defender.isDamageSourceBlocked(defender.damageSources().playerAttack(attacker));
        try{
            own.attack(target);
            // Some legal axe strikes meet a front-facing active shield but leave its
            // cooldown unset, including after a recent hit or same-tick weapon switch.
            // Use Paper's native disable entry point only in that observed gap; it
            // still fires the cancellable event and applies the native cooldown.
            if(attempt.shieldFacingBefore&&!target.hasCooldown(Material.SHIELD)){
                defender.disableShield(attacker);attempt.shieldFallback=true;
            }
        }finally{
            active.remove(target.getUniqueId());
            if(restoreShieldMotion(attempt.blocked,attempt.positiveDamage,attempt.velocityPacket)){
                // LivingEntity.blockedByShield changes server-only delta movement even when
                // hurt returns false. No velocity packet is sent to an ordinary client then.
                // Fakeplayer integrates this server state, so preserve the client's pre-hit
                // motion in this one fully-blocked/no-packet case. Do not send a new packet,
                // invent an impulse, change damage or override a real PlayerVelocityEvent.
                var v=attempt.before;((CraftPlayer)target).getHandle().setDeltaMovement(v.getX(),v.getY(),v.getZ());restoredShieldFrames++;
            }
        }return attempt;
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void damage(EntityDamageByEntityEvent e){var attempt=active.get(e.getEntity().getUniqueId());if(attempt==null)return;attempt.damage+=e.getFinalDamage();attempt.positiveDamage|=e.getFinalDamage()>0;attempt.blocked|=e.isApplicable(DamageModifier.BLOCKING)&&e.getDamage(DamageModifier.BLOCKING)<0;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void velocity(PlayerVelocityEvent e){var attempt=active.get(e.getPlayer().getUniqueId());if(attempt!=null)attempt.velocityPacket=true;}
}
