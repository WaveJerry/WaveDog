package local.wavedog.lab;

import com.google.gson.Gson;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Small actual neural policy. Frozen actor per bout, asynchronous episodic REINFORCE updates. */
final class NeuralFootwork implements AutoCloseable {
    static final int F=32,H=24,A=8,N=H*(F+1)+A*(H+1);
    static final Gson JSON=new Gson();
    static final class State {int format=1;long episodes,updates,samples,penaltyUpdates;double[] w=new double[N],m=new double[N],v=new double[N];double baseline;}
    record Sample(double[] x,boolean[] mask,int action,double ownHealth){}
    final Path checkpoint;final ExecutorService trainer;volatile State state;volatile String error="";
    final AtomicLong decisions=new AtomicLong(),trained=new AtomicLong();final AtomicInteger pending=new AtomicInteger();
    NeuralFootwork(Path folder)throws Exception{
        Files.createDirectories(folder);checkpoint=folder.resolve("footwork.json");
        if(Files.exists(checkpoint)){state=JSON.fromJson(Files.readString(checkpoint),State.class);validate(state);}else{state=new State();var r=new Random(413994);for(int i=0;i<N;i++)state.w[i]=r.nextGaussian()*.065;state.w[H*(F+1)+H]=2.2;}
        trainer=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"WaveDog-neural-trainer");t.setDaemon(true);return t;});
    }
    static void validate(State s){if(s==null||s.format!=1||s.w.length!=N||s.m.length!=N||s.v.length!=N)throw new IllegalArgumentException("Neural checkpoint shape mismatch");for(double d:s.w)if(!Double.isFinite(d))throw new IllegalArgumentException("Non-finite neural weights");}
    Actor actor(long seed){return new Actor(state.w.clone(),seed);}
    final class Actor {
        final double[] weights;final Random random;final ArrayDeque<Sample> episode=new ArrayDeque<>();long next;int action;
        Actor(double[] weights,long seed){this.weights=weights;random=new Random(seed);}
        DuelPolicy.Input apply(long tick,DuelPolicy.Self self,DuelPolicy.Seen seen,ArenaLayout.Cell cell,DuelPolicy.Style style,DuelPolicy.Input base){
            if((!base.skill().equals("SPACE_RESET")&&!base.skill().equals("SHIELD_PRESSURE"))||!self.ground()||seen==null||!seen.visible()||tick-seen.captured()>8)return base;
            double range=DuelPolicy.distance(self.x(),self.eyeY(),self.z(),seen.x(),seen.y(),seen.z());
            // Learned motion cannot displace committed melee, escape, projectiles or active airborne defence.
            if(base.attack()||base.jump()||range<2.2)return base;
            if(tick>=next){next=tick+4;double[] x=features(self,seen,cell,style,tick);boolean[] mask=mask(self,cell,base);double[] p=probabilities(weights,x,mask);double roll=random.nextDouble();action=0;for(int i=0;i<A;i++){roll-=p[i];if(roll<=0){action=i;break;}}
                if(episode.size()>=512)episode.removeFirst();episode.addLast(new Sample(x,mask,action,self.health()));decisions.incrementAndGet();}
            boolean[] legal=mask(self,cell,base);if(!legal[action])action=0;
            float f=forward(action,base),side=side(action,base);boolean sprint=!base.shield()&&f>0;
            return DuelPolicy.out(base.decided(),base.due(),base.yaw(),base.pitch(),f,side,sprint,base.jump(),base.shield(),base.attack(),base.slot(),base.use(),base.release(),base.flightLook(),base.skill(),base.reason()+"; neural footwork="+action);
        }
        void finish(boolean win,double ownHealth){submit((win?1:-1)+ownHealth/40.0,true);}
        void penalizeStall(){submit(-StallPenaltyClock.PENALTY,false);}
        void submit(double reward,boolean terminal){if(episode.isEmpty())return;var samples=List.copyOf(episode);if(pending.incrementAndGet()>64){pending.decrementAndGet();return;}episode.clear();trainer.execute(()->{try{train(weights,samples,reward,terminal);}catch(Exception e){error=e.toString();}finally{pending.decrementAndGet();}});}
    }
    static float forward(int a,DuelPolicy.Input b){return switch(a){case 0->b.forward();case 3,5,6->1;case 4->-1;default->0;};}
    static float side(int a,DuelPolicy.Input b){return switch(a){case 0->b.side();case 1,5->1;case 2,6->-1;default->0;};}
    static boolean[] mask(DuelPolicy.Self s,ArenaLayout.Cell c,DuelPolicy.Input b){boolean[] mask=new boolean[A];mask[0]=true;double rad=Math.toRadians(b.yaw());for(int a=1;a<A;a++){double f=forward(a,b),q=side(a,b),dx=-Math.sin(rad)*f+Math.cos(rad)*q,dz=Math.cos(rad)*f+Math.sin(rad)*q;mask[a]=c.margin(s.x()+dx*1.5,s.z()+dz*1.5)>.65;}return mask;}
    static double[] features(DuelPolicy.Self s,DuelPolicy.Seen o,ArenaLayout.Cell c,DuelPolicy.Style style,long tick){
        double[] x=new double[F];double dx=o.x()-s.x(),dz=o.z()-s.z(),dist=Math.hypot(dx,dz);
        x[0]=Math.min(2,dist/6);x[1]=s.charge();x[2]=s.health()/20;x[3]=s.shieldAvailable()?1:0;x[4]=s.shielding()?1:0;x[5]=s.vx();x[6]=s.vy();x[7]=s.vz();x[8]=s.ground()?1:0;
        x[9]=Math.max(-1,Math.min(1,(o.y()-s.y())/3));x[10]=o.shield()?1:0;x[11]=o.using()?1:0;x[12]=s.arrows()/5.0;x[13]=s.crossbowLoaded()?1:0;x[14]=Math.min(1,(tick-o.captured())/8.0);
        x[15]=Math.min(1,(s.x()-c.minX())/8);x[16]=Math.min(1,(c.maxX()-s.x())/8);x[17]=Math.min(1,(s.z()-c.minZ())/8);x[18]=Math.min(1,(c.maxZ()-s.z())/8);
        x[19]=Math.sin(Math.toRadians(o.yaw()));x[20]=Math.cos(Math.toRadians(o.yaw()));x[21]=Math.min(1,o.arrows().size()/3.0);x[22]=s.critical()?1:0;x[23]=Math.min(1,s.useTicks()/25.0);
        x[24+style.ordinal()]=1;x[30]=o.held().contains("SWORD")?1:0;x[31]=o.held().contains("BOW")?1:0;return x;
    }
    static double[] hidden(double[] w,double[] x){double[] h=new double[H];for(int j=0;j<H;j++){double z=w[j*(F+1)+F];for(int k=0;k<F;k++)z+=w[j*(F+1)+k]*x[k];h[j]=Math.tanh(z);}return h;}
    static double[] probabilities(double[] w,double[] x,boolean[] mask){double[] h=hidden(w,x),p=new double[A];double max=-1e30,sum=0;for(int a=0;a<A;a++){double z=w[H*(F+1)+a*(H+1)+H];for(int j=0;j<H;j++)z+=w[H*(F+1)+a*(H+1)+j]*h[j];p[a]=mask[a]?z:-1e30;max=Math.max(max,p[a]);}for(int a=0;a<A;a++){p[a]=mask[a]?Math.exp(p[a]-max):0;sum+=p[a];}for(int a=0;a<A;a++)p[a]/=sum;return p;}
    void train(double[] actor,List<Sample> samples,double reward,boolean terminal)throws Exception{
        State old=state,s=new State();s.w=old.w.clone();s.m=old.m.clone();s.v=old.v.clone();s.baseline=old.baseline;s.episodes=old.episodes;s.updates=old.updates;s.samples=old.samples;s.penaltyUpdates=old.penaltyUpdates;
        // A punishment must stay negative even when the terminal baseline is strongly negative.
        double advantage=terminal?Math.max(-2,Math.min(2,reward-s.baseline)):Math.min(0,reward);if(terminal)s.baseline=.98*s.baseline+.02*reward;double[] g=new double[N];
        for(Sample sample:samples){double[] h=hidden(actor,sample.x()),p=probabilities(actor,sample.x(),sample.mask()),dh=new double[H];
            for(int a=0;a<A;a++){double d=(a==sample.action()?1:0)-p[a];d*=advantage/samples.size();int off=H*(F+1)+a*(H+1);g[off+H]+=d;for(int j=0;j<H;j++){g[off+j]+=d*h[j];dh[j]+=d*actor[off+j];}}
            for(int j=0;j<H;j++){double d=dh[j]*(1-h[j]*h[j]);int off=j*(F+1);g[off+F]+=d;for(int k=0;k<F;k++)g[off+k]+=d*sample.x()[k];}}
        double norm=0;for(double d:g)norm+=d*d;double scale=norm>1?1/Math.sqrt(norm):1;s.updates++;
        double beta1=1-Math.pow(.9,s.updates),beta2=1-Math.pow(.999,s.updates);for(int i=0;i<N;i++){double d=g[i]*scale;s.m[i]=.9*s.m[i]+.1*d;s.v[i]=.999*s.v[i]+.001*d*d;s.w[i]+=.0003*(s.m[i]/beta1)/(Math.sqrt(s.v[i]/beta2)+1e-8);}
        if(terminal)s.episodes++;else s.penaltyUpdates++;s.samples+=samples.size();validate(s);state=s;trained.incrementAndGet();save();
    }
    void save()throws Exception{Path tmp=checkpoint.resolveSibling("footwork.json.tmp");Files.writeString(tmp,JSON.toJson(state));try{Files.move(tmp,checkpoint,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,checkpoint,StandardCopyOption.REPLACE_EXISTING);}}
    Map<String,Object> status(){State s=state;return Map.of("enabled",true,"decisions",decisions.get(),"trained_episodes",s.episodes,"gradient_updates",s.updates,"training_samples",s.samples,"pending",pending.get(),"last_error",error,"stall_penalty_updates",s.penaltyUpdates,"architecture","32-24tanh-8softmax episodic REINFORCE+Adam");}
    public void close(){trainer.shutdown();try{trainer.awaitTermination(10,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
