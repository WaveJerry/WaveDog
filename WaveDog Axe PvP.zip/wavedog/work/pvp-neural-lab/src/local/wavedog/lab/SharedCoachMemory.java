package local.wavedog.lab;
import com.google.gson.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Shared research and completed-bout communication. Never contains a live opponent-private state. */
final class SharedCoachMemory {
    final Path file,reportsFile,lessonsFile;final String notes;
    final Set<String> registered=ConcurrentHashMap.newKeySet(),inflight=ConcurrentHashMap.newKeySet();final Map<String,JsonObject> advice=new ConcurrentHashMap<>();
    final ArrayDeque<JsonObject> lessons=new ArrayDeque<>();final ArrayDeque<Map<String,Object>> reports=new ArrayDeque<>();final List<Map<String,Object>> reviewInFlight=new ArrayList<>();
    final Map<String,Long> styleWins=new TreeMap<>();long winnerHits,loserHits,winnerCrits,loserCrits,stallPenalties,measuredSwingBouts,swings,whiffs;
    final AtomicLong reportCount=new AtomicLong(),reviewCount=new AtomicLong();volatile boolean reviewPending;
    SharedCoachMemory(Path dir)throws Exception{
        Files.createDirectories(dir);file=dir.resolve("shared-learning.json");reportsFile=dir.resolve("completed-learning-reports.jsonl");lessonsFile=dir.resolve("coach-lessons.jsonl");
        var core=dir.resolve("coach-briefing-core.txt");var p=dir.resolve("coach-research-notes.txt");String head=Files.exists(core)?Files.readString(core,StandardCharsets.UTF_8):"All six styles learn; compare actual completed bouts fairly.";String tail=Files.exists(p)?Files.readString(p,StandardCharsets.UTF_8):"";String text=head+"\n"+tail;notes=text.substring(0,Math.min(950,text.length()));
        JsonObject root=null;if(Files.exists(file)){root=JsonParser.parseString(Files.readString(file,StandardCharsets.UTF_8)).getAsJsonObject();if(root.has("lessons"))for(var item:root.getAsJsonArray("lessons"))lessons.addLast(item.getAsJsonObject());if(root.has("advice"))for(var e:root.getAsJsonObject("advice").entrySet())advice.put(e.getKey(),e.getValue().getAsJsonObject());if(root.has("pending_reports"))for(var item:root.getAsJsonArray("pending_reports"))reports.addLast(TacticalModel.JSON.fromJson(item,Map.class));if(root.has("review_inflight"))for(var item:root.getAsJsonArray("review_inflight"))reviewInFlight.add(TacticalModel.JSON.fromJson(item,Map.class));if(root.has("review_count"))reviewCount.set(root.get("review_count").getAsLong());}while(lessons.size()>4)lessons.removeFirst();
        var recent=new ArrayDeque<Map<String,Object>>();if(Files.exists(reportsFile))try(var lines=Files.lines(reportsFile,StandardCharsets.UTF_8)){lines.forEach(line->{try{var report=TacticalModel.JSON.fromJson(line,Map.class);accumulate(report);recent.addLast(report);while(recent.size()>24)recent.removeFirst();}catch(Exception ignored){}});}
        if(root==null||!root.has("pending_reports"))reports.addAll(recent);if(!reviewInFlight.isEmpty()){for(int i=reviewInFlight.size()-1;i>=0;i--)reports.addFirst(reviewInFlight.get(i));reviewInFlight.clear();}
        if(root==null||!root.has("review_count"))backfillLessons(dir.resolve("llm-tactics.jsonl"));
    }
    void backfillLessons(Path journal)throws Exception{
        if(Files.exists(lessonsFile)){try(var lines=Files.lines(lessonsFile,StandardCharsets.UTF_8)){reviewCount.set(lines.count());}return;}
        if(!Files.exists(journal))return;
        try(var lines=Files.lines(journal,StandardCharsets.UTF_8)){lines.forEach(line->{try{var row=JsonParser.parseString(line).getAsJsonObject();var input=row.getAsJsonObject("public_input");if(input!=null&&input.has("mode")&&"completed_post_bout_review".equals(input.get("mode").getAsString())&&row.has("output")){reviewCount.incrementAndGet();Files.writeString(lessonsFile,row.get("output").toString()+System.lineSeparator(),StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);}}catch(Exception ignored){}});}
    }
    synchronized void accumulate(Map<String,Object> report){reportCount.incrementAndGet();winnerHits+=number(report,"winner_hits");loserHits+=number(report,"loser_hits");winnerCrits+=number(report,"winner_crits");loserCrits+=number(report,"loser_crits");stallPenalties+=number(report,"stall_penalties");if(report.containsKey("winner_swings")&&report.containsKey("loser_swings")){measuredSwingBouts++;swings+=number(report,"winner_swings")+number(report,"loser_swings");whiffs+=number(report,"winner_whiffs")+number(report,"loser_whiffs");}if(report.get("style_winner") instanceof String style)styleWins.merge(style,1L,Long::sum);}
    static long number(Map<String,Object> report,String key){return report.get(key) instanceof Number n?n.longValue():0;}
    synchronized void save()throws Exception{Path temp=file.resolveSibling("shared-learning.json.tmp");var state=new LinkedHashMap<String,Object>();state.put("lessons",lessons);state.put("advice",new TreeMap<>(advice));state.put("pending_reports",reports);state.put("review_inflight",reviewInFlight);state.put("review_count",reviewCount.get());state.put("completed_bout_count",reportCount.get());state.put("method","durable post-bout contextual memory and recurrent PPO checkpoint; no Qwen weight fine-tuning");Files.writeString(temp,TacticalModel.JSON.toJson(state),StandardCharsets.UTF_8);Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
    synchronized List<JsonObject> lessonSnapshot(){return lessons.stream().map(JsonObject::deepCopy).toList();}
    synchronized void remember(String name,JsonObject value)throws Exception{advice.put(name,value.deepCopy());save();}
    synchronized void completed(Map<String,Object> report)throws Exception{var copy=Map.copyOf(report);Files.writeString(reportsFile,TacticalModel.JSON.toJson(copy)+System.lineSeparator(),StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);accumulate(copy);reports.addLast(copy);while(reports.size()>24)reports.removeFirst();save();}
    synchronized List<Map<String,Object>> takeBatch()throws Exception{reviewPending=true;var result=new ArrayList<Map<String,Object>>();for(int i=0;i<6;i++)result.add(reports.removeFirst());reviewInFlight.clear();reviewInFlight.addAll(result);save();return List.copyOf(result);}
    synchronized void restoreBatch(List<Map<String,Object>> batch)throws Exception{for(int i=batch.size()-1;i>=0;i--)reports.addFirst(batch.get(i));while(reports.size()>24)reports.removeLast();reviewInFlight.clear();reviewPending=false;save();}
    synchronized void restoreUnfinishedReview()throws Exception{if(!reviewInFlight.isEmpty())restoreBatch(List.copyOf(reviewInFlight));}
    synchronized void addLesson(JsonObject result)throws Exception{lessons.addLast(result.deepCopy());while(lessons.size()>4)lessons.removeFirst();reviewCount.incrementAndGet();reviewInFlight.clear();save();Files.writeString(lessonsFile,result.toString()+System.lineSeparator(),StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
    synchronized Map<String,Object> cumulativeSummary(){var out=new LinkedHashMap<String,Object>();out.put("completed_bouts_all_sessions",reportCount.get());out.put("review_batches_all_sessions",reviewCount.get());out.put("winner_hits_total",winnerHits);out.put("loser_hits_total",loserHits);out.put("winner_crits_total",winnerCrits);out.put("loser_crits_total",loserCrits);out.put("stall_penalties_total",stallPenalties);out.put("style_wins_uncontrolled",new TreeMap<>(styleWins));out.put("pending_reviews",reports.size()+reviewInFlight.size());out.put("swing_metrics_covered_bouts",measuredSwingBouts);out.put("swing_attempts_covered_bouts",swings);out.put("whiffs_covered_bouts",whiffs);return out;}
    synchronized Map<String,Object> status(){var out=new LinkedHashMap<String,Object>();out.put("registered_names",new TreeSet<>(registered));out.put("coached_unique_names",advice.size());out.put("shared_review_batches",reviewCount.get());out.put("shared_lessons",lessons.size());out.put("completed_bout_reports",reportCount.get());out.put("pending_review_reports",reports.size()+reviewInFlight.size());out.put("coach_notes_loaded",!notes.isBlank());out.put("learning_method","RL weights plus durable Qwen contextual memory; no Qwen fine-tuning");return out;}
}
