package local.wavedog.lab;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Readable experience retrieval and goal labels. No routine here selects a game input. */
final class ExperienceLibrary {
    enum Focus {FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT}
    final Path file;long modified=-1;List<JsonObject> cards=List.of(),retrievalOrder=List.of();final AtomicLong requests=new AtomicLong();final Set<String> retrieved=new HashSet<>(),delivered=new HashSet<>();
    ExperienceLibrary(Path directory)throws Exception{file=directory.resolve("coach-experience-library.json");refresh();}
    synchronized void refresh()throws Exception{if(!Files.exists(file))return;long m=Files.getLastModifiedTime(file).toMillis();if(m==modified)return;var root=JsonParser.parseString(Files.readString(file)).getAsJsonObject();var next=new ArrayList<JsonObject>();for(var item:root.getAsJsonArray("cards")){var card=item.getAsJsonObject();Focus.valueOf(card.get("focus").getAsString());next.add(card.deepCopy());}cards=List.copyOf(next);var priority=new ArrayList<JsonObject>();for(var card:next)if(prioritized(card))priority.add(card);for(var card:next)if(!prioritized(card))priority.add(card);retrievalOrder=List.copyOf(priority);modified=m;}
    static boolean prioritized(JsonObject card){String id=card.get("id").getAsString();return id.startsWith("brief-20261111-")||id.startsWith("perception-goal-")||id.startsWith("game-");}
    synchronized List<Map<String,String>> retrieve()throws Exception{refresh();long index=requests.getAndIncrement();var result=new ArrayList<Map<String,String>>();for(int i=0;i<2&&!retrievalOrder.isEmpty();i++){var c=retrievalOrder.get((int)((index*2+i)%retrievalOrder.size()));String text=c.get("summary").getAsString();result.add(Map.of("id",c.get("id").getAsString(),"focus",c.get("focus").getAsString(),"experience_hypothesis",text.substring(0,Math.min(90,text.length()))));retrieved.add(c.get("id").getAsString());}return result;}
    synchronized void acknowledge(Object payload){if(payload instanceof Map<?,?> map&&map.get("retrieved_experience_hypotheses") instanceof List<?> list)for(Object value:list)if(value instanceof Map<?,?> card&&card.get("id") instanceof String id)delivered.add(id);}
    synchronized String save(String summary,String author)throws Exception{
        summary=summary.strip();if(summary.length()<4||summary.length()>240||summary.chars().anyMatch(c->Character.isISOControl(c)))throw new IllegalArgumentException("经验需为4至240字的单行文字");
        refresh();Files.createDirectories(file.getParent());
        JsonObject root=Files.exists(file)?JsonParser.parseString(Files.readString(file,StandardCharsets.UTF_8)).getAsJsonObject():new JsonObject();
        JsonArray array=root.has("cards")?root.getAsJsonArray("cards"):new JsonArray();
        String id="game-"+UUID.randomUUID();JsonObject card=new JsonObject();card.addProperty("id",id);card.addProperty("focus",Focus.FREE.name());card.addProperty("summary",summary);card.addProperty("source","game-command");card.addProperty("author",author);card.addProperty("created_at",java.time.Instant.now().toString());array.add(card);root.add("cards",array);
        Path temp=Files.createTempFile(file.getParent(),"experience-",".tmp");
        try{Files.writeString(temp,new GsonBuilder().setPrettyPrinting().create().toJson(root),StandardCharsets.UTF_8);Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(temp);}
        modified=-1;refresh();return id;
    }
    synchronized List<String> chatContext()throws Exception{refresh();var out=new ArrayList<String>();for(int i=Math.max(0,cards.size()-4);i<cards.size();i++)out.add(cards.get(i).get("summary").getAsString());return out;}
    synchronized Map<String,Object> status(){return Map.of("experience_cards",cards.size(),"experience_cards_retrieved",retrieved.size(),"experience_cards_delivered",delivered.size(),"experience_requests",requests.get(),"transfer","coach focus conditions RL observations; native actions remain learned; labels alone do not teach a skill or update weights");}
}
