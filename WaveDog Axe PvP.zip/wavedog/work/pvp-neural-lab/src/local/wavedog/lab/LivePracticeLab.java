package local.wavedog.lab;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.github.hello09x.fakeplayer.api.spi.*;
import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.manager.FakeplayerList;
import fr.xephi.authme.api.v3.AuthMeApi;
import java.io.*;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;
import org.bukkit.*;
import org.bukkit.block.TileState;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/** A separately owned, observable main-server laboratory. Existing WaveDog is not its policy. */
public final class LivePracticeLab extends JavaPlugin implements Listener {
    static final Gson JSON=new GsonBuilder().serializeNulls().create();
    final class Fighter {
        final String name;final Random channel;int delayMs;
        final ArrayDeque<DuelPolicy.Seen> perceptions=new ArrayDeque<>();
        final ArrayDeque<DuelPolicy.Input> inputs=new ArrayDeque<>();
        RecurrentPpoCombat.Actor neural;TacticalModel.Agent tactical;String arm="SCRIPT";Player player;DuelPolicy policy;long swing;int hits,crits,whiffs,joinAttempts;double damage;String lastSkill="";boolean authQueued;
        Fighter(String name,int delayMs,long seed){this.name=name;this.delayMs=delayMs;channel=new Random(seed);}
        int delay(){return (Math.max(0,delayMs/2+(delayMs==0?0:channel.nextInt(21)-10))+49)/50;}
    }
    final class Lane {
        final ArenaLayout.Cell cell;final Fighter a,b;StallPenaltyClock stall;int round,prepareStage;long ready,started;boolean active,fighting,preparing,broken;
        Lane(ArenaLayout.Cell cell){this.cell=cell;int ms=new int[]{0,50,100,150,200}[cell.id()%5];a=new Fighter(String.format("WLab%02dA",cell.id()+1),ms,1001+cell.id());b=new Fighter(String.format("WLab%02dB",cell.id()+1),ms,4001+cell.id());}
    }
    final List<Lane> lanes=new ArrayList<>();final Map<UUID,Map<String,Object>> spectators=new HashMap<>();
    final Map<String,Integer> wins=new LinkedHashMap<>(),losses=new LinkedHashMap<>();
    final List<Map<String,Object>> recent=new ArrayList<>();
    RecurrentPpoCombat neural;TacticalModel tactics;QwenChat qwenChat;final NativeMeleeInput meleeInput=new NativeMeleeInput();
    NMSBridge bridge;FakeplayerList fakeRecords;AuthMeApi auth;Object ai;Method shieldUse,release;
    final ArrayDeque<Fighter> authenticationQueue=new ArrayDeque<>();
    long stallEvents;NativeFairnessProbe physics;
    World world;long tick,lastRamp,lastFlush,rounds,nextAuthentication;int desired=30,columns,nextLane;boolean built,building,running=true,pausing,failed;
    BufferedWriter judge,inputs,text,original;Path runDirectory;String runId;long buildStarted;
    @Override public void onEnable(){
        saveDefaultConfig();Bukkit.getPluginManager().registerEvents(this,this);Bukkit.getPluginManager().registerEvents(meleeInput,this);
        Objects.requireNonNull(getCommand("pvplab")).setExecutor(this);
        Objects.requireNonNull(getCommand("qwen")).setExecutor(this);
        try{qwenChat=new QwenChat(getDataFolder().toPath(),getConfig().getString("llm-endpoint","http://127.0.0.1:18765/v1/chat/completions"));}catch(Exception e){getLogger().log(java.util.logging.Level.SEVERE,"Player Qwen chat unavailable",e);}
        Bukkit.getScheduler().runTaskLater(this,()->safe(this::initialize),40);
    }
    interface Task{void run()throws Exception;}
    void safe(Task task){try{task.run();}catch(Throwable e){failed=true;running=false;getLogger().log(java.util.logging.Level.SEVERE,"Laboratory paused after an error",e);writeQuiet(text,"ERROR: "+e);try{writeStatus();}catch(Exception ignored){}}}
    void initialize()throws Exception{
        ai=Bukkit.getPluginManager().getPlugin("PvPArenaAI");
        var field=ai.getClass().getDeclaredField("bridge");field.setAccessible(true);bridge=(NMSBridge)field.get(ai);
        fakeRecords=Main.getInjector().getInstance(FakeplayerList.class);
        if(Bukkit.getPluginManager().isPluginEnabled("AuthMe"))auth=AuthMeApi.getInstance();
        var cl=ai.getClass().getClassLoader();
        shieldUse=Class.forName("local.pvpbot.ai.NativeOffhandUse",true,cl).getDeclaredMethod("use",Player.class);shieldUse.setAccessible(true);
        release=Class.forName("local.pvpbot.ai.VanillaUseRelease",true,cl).getDeclaredMethod("release",Object.class);release.setAccessible(true);
        world=Bukkit.getWorld(getConfig().getString("world","world"));if(world==null)throw new IllegalStateException("Configured arena world absent");
        for(var cell:ArenaLayout.cells())lanes.add(new Lane(cell));
        if(getConfig().getBoolean("neural-enabled",true)){var folder=getDataFolder().toPath().resolve("models");if(!Files.exists(folder.resolve("recurrent-ppo.json")))throw new IllegalStateException("Validated recurrent seed is not installed; no random live replacement");neural=new RecurrentPpoCombat(folder);}
        if(getConfig().getBoolean("llm-enabled",true))tactics=new TacticalModel(getDataFolder().toPath(),getConfig().getString("llm-endpoint","http://127.0.0.1:18765/v1/chat/completions"));if(tactics!=null&&neural!=null)tactics.trainingProgress=neural::status;
        runId=java.time.LocalDateTime.now().toString().replace(':','-');runDirectory=getDataFolder().toPath().resolve("sessions").resolve(runId);Files.createDirectories(runDirectory);
        judge=gzip(runDirectory.resolve("judge.jsonl.gz"));inputs=gzip(runDirectory.resolve("observations-inputs.jsonl.gz"));
        text=Files.newBufferedWriter(getDataFolder().toPath().resolve("每轮对战.txt"),StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
        text.write("\n新会话 "+runId+"；原服钻石完整套装；全员动作强化学习+共享Qwen指导；每组轮换一方更新；尚在初始化与训练；尚无画面声音输入。\n");
        Files.writeString(runDirectory.resolve("environment.json"),JSON.toJson(Map.of("world",world.getName(),"version",Bukkit.getVersion(),"cells",ArenaLayout.cells(),"floor",ArenaLayout.FLOOR,"kit",ReferenceDuelKit.DESCRIPTION,"natural_regeneration",world.getGameRuleValue(GameRule.NATURAL_REGENERATION),"policy","all-input learned policy and shared Qwen coach; one learner per pair, alternating by bout; learned API observation encoding, no image/audio","observation","delayed API approximation of visible client information; not image/audio validation")),StandardCharsets.UTF_8);
        built=getConfig().getBoolean("built",false);running=getConfig().getBoolean("auto-start",true);desired=Math.min(30,Math.max(0,getConfig().getInt("active-arenas",30)));
        if(!built)beginBuild();
        Bukkit.getScheduler().runTaskTimer(this,()->safe(this::step),1,1);
        getLogger().info("LIVE_LAB_READY; /pvplab status, /pvplab watch 1, /pvplab pause");
    }
    static BufferedWriter gzip(Path p)throws IOException{return new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(p)),StandardCharsets.UTF_8));}
    void record(BufferedWriter out,String type,Object data)throws IOException{out.write(JSON.toJson(Map.of("tick",tick,"type",type,"data",data)));out.newLine();}
    void beginBuild()throws Exception{
        if(building||built)return;building=true;columns=0;buildStarted=System.nanoTime();original=gzip(runDirectory.resolve("original-blocks.jsonl.gz"));
        getLogger().info("Building 30 cells east of old arena; old arena ends at x=1038, new area starts x=1042");
    }
    void buildStep()throws Exception{
        long deadline=System.nanoTime()+4_000_000;int width=ArenaLayout.COLUMNS*32+1,depth=ArenaLayout.ROWS*32+1;
        for(int done=0;columns<width*depth&&done<48&&System.nanoTime()<deadline;done++,columns++){
            int x=ArenaLayout.X+columns%width,z=ArenaLayout.Z+columns/width;
            boolean edge=(x-ArenaLayout.X)%32==0||(z-ArenaLayout.Z)%32==0;
            for(int y=219;y<=228;y++){
                Material m=y==219?Material.BEDROCK:y==220?(((x+z)%16==0)?Material.SEA_LANTERN:Material.SMOOTH_SANDSTONE):
                    y==228?Material.GLASS:edge?(y==221||y==227?Material.POLISHED_DEEPSLATE:Material.GLASS):Material.AIR;
                var block=world.getBlockAt(x,y,z);if(block.getType()==m)continue;
                if(block.getState() instanceof TileState)throw new IllegalStateException("Existing tile entity in new construction area; preserved it at "+x+","+y+","+z);
                original.write(JSON.toJson(Map.of("x",x,"y",y,"z",z,"before",block.getBlockData().getAsString())));original.newLine();block.setType(m,false);
            }
        }
        if(columns==width*depth){original.close();original=null;building=false;built=true;getConfig().set("built",true);saveConfig();getLogger().info("ARENA_GRID_COMPLETE 30 cells; /pvplab watch 1");Bukkit.broadcastMessage("§a30场对练区已建好。OP可用 /pvplab watch 1 旁观，/pvplab status 查看。");}
    }
    boolean internal(Player p){return p!=null&&fakeRecords!=null&&fakeRecords.getAll().stream().anyMatch(f->f.getPlayer()==p);}
    boolean reserved(String n){return n.matches("WLab(0[1-9]|[12][0-9]|30)[AB]");}
    @EventHandler(priority=EventPriority.HIGHEST)public void prelogin(AsyncPlayerPreLoginEvent e){
        if(!reserved(e.getName()))return;boolean registered=false;
        try{java.util.concurrent.Callable<Boolean> check=()->fakeRecords!=null&&fakeRecords.getAll().stream().anyMatch(f->f.getName().equals(e.getName())&&f.getUUID().equals(e.getUniqueId()));registered=Bukkit.isPrimaryThread()?check.call():Bukkit.getScheduler().callSyncMethod(this,check).get(5,java.util.concurrent.TimeUnit.SECONDS);}catch(Exception ignored){}
        if(registered)e.allow();else e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,"Reserved laboratory identity");
    }
    @EventHandler(priority=EventPriority.HIGHEST)public void login(PlayerLoginEvent e){if(reserved(e.getPlayer().getName())){if(internal(e.getPlayer())&&Bukkit.getOnlinePlayers().size()<Bukkit.getMaxPlayers())e.allow();else if(!internal(e.getPlayer()))e.disallow(PlayerLoginEvent.Result.KICK_OTHER,"Reserved laboratory fakeplayer identity");}}
    void authenticate(Fighter f){
        if(!internal(f.player))throw new IllegalStateException("Internal fakeplayer identity not verified: "+f.name);
        if(auth!=null&&!auth.isAuthenticated(f.player)&&!f.authQueued){f.authQueued=true;authenticationQueue.add(f);}
    }
    void prepare(Lane l)throws Exception{
        l.preparing=true;l.prepareStage=0;l.ready=tick+50;
        for(var f:List.of(l.a,l.b)){f.player=Bukkit.getPlayerExact(f.name);if(f.player==null)Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"fp spawn "+f.name);}
    }
    void prepareStep(Lane l)throws Exception{
        if(tick<l.ready)return;
        if(l.prepareStage==0){
            for(var f:List.of(l.a,l.b)){f.player=Bukkit.getPlayerExact(f.name);if(f.player==null){if(++f.joinAttempts>40){l.preparing=false;l.broken=true;record(judge,"round_incomplete",Map.of("arena",l.cell.id()+1,"reason","fakeplayer failed to join"));return;}l.ready=tick+10;return;}authenticate(f);}
            l.prepareStage=1;l.ready=tick+15;return;
        }
        if(l.prepareStage==1){
            if(auth!=null&&(!auth.isAuthenticated(l.a.player)||!auth.isAuthenticated(l.b.player))){l.ready=tick+10;return;}
            // Between rounds only: arrows left by the previous bout must not alter the new five-arrow kit.
            for(var entity:world.getNearbyEntities(new Location(world,l.cell.cx(),224,l.cell.cz()),16,9,16))if(entity instanceof AbstractArrow||entity instanceof Item)entity.remove();
            l.round++;
            for(var f:List.of(l.a,l.b)){
                var p=f.player;if(p.isDead()){bridge.fromPlayer(p).respawn();l.ready=tick+10;return;}
                if(p.hasActiveItem())release.invoke(null,p);p.setSprinting(false);bridge.fromPlayer(p).setZza(0);bridge.fromPlayer(p).setXxa(0);
                p.setGameMode(GameMode.SURVIVAL);p.getActivePotionEffects().forEach(e->p.removePotionEffect(e.getType()));
                p.setHealth(20);p.setFoodLevel(20);p.setSaturation(5);p.setFireTicks(0);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
                ReferenceDuelKit.equip(p);p.teleport(l.cell.start(world,f==l.a));p.setVelocity(new Vector()); // fixture only, before combat
                int first=l.cell.id()/5,second=l.cell.id()%5;if(second>=first)second++;
                int arm=((f==l.a)^(l.round%2==0)?first:second)+l.round-1;arm%=DuelPolicy.Style.values().length;
                f.policy=new DuelPolicy(DuelPolicy.Style.values()[arm],1000003L*l.round+f.name.hashCode(),l.cell);
                f.arm="ALL_INPUT_RL_QWEN";
                f.neural=neural!=null?neural.actor(81239L*l.round+f.name.hashCode(),(f==l.a)==(l.round%2==1)):null;
                f.tactical=tactics!=null?tactics.agent(f.name):null;f.policy.tactics=f.tactical;
                f.inputs.clear();f.perceptions.clear();f.hits=f.crits=f.whiffs=0;f.damage=0;f.swing=0;
            }
            // The shared Qwen review chooses the learner side and focus for one
            // occasional aggressive-vs-defensive lesson. Each bot keeps its own GRU state.
            if(neural!=null&&tactics!=null&&curriculumBout(l.round,l.cell.id())){
                var plan=tactics.curriculumPlan();
                l.a.policy=new DuelPolicy(DuelPolicy.Style.AGGRESSIVE,1000003L*l.round+l.a.name.hashCode(),l.cell);
                l.b.policy=new DuelPolicy(DuelPolicy.Style.DEFENSIVE,1000003L*l.round+l.b.name.hashCode(),l.cell);
                l.a.policy.tactics=l.a.tactical;l.b.policy.tactics=l.b.tactical;
                l.a.neural=neural.actor(81239L*l.round+l.a.name.hashCode(),plan.aggressiveLearns());
                l.b.neural=neural.actor(81239L*l.round+l.b.name.hashCode(),!plan.aggressiveLearns());
                (plan.aggressiveLearns()?l.a:l.b).tactical.focus=plan.focus();
                l.a.delayMs=l.a.channel.nextInt(5)*50;l.b.delayMs=l.b.channel.nextInt(5)*50;
                l.a.arm="QWEN_CURRICULUM_AGGRESSIVE_GRU";l.b.arm="QWEN_CURRICULUM_DEFENSIVE_GRU";
            }
            // Sparse WaveDog-pattern sparring: the aggressive GRU learns against a
            // shield-counter/escape script using only the same delayed public view.
            if(neural!=null&&l.cell.id()!=0&&referenceBout(l.round,l.a.policy.style,l.b.policy.style)){
                Fighter teacher=l.a.policy.style==DuelPolicy.Style.DEFENSIVE?l.a:l.b;
                Fighter learner=teacher==l.a?l.b:l.a;
                teacher.neural=null;teacher.arm="WAVEDOG_PATTERN_SHIELD_ESCAPE";
                if(teacher.tactical!=null)teacher.tactical.close();
                teacher.tactical=null;teacher.policy.tactics=null;
                learner.neural=neural.actor(81239L*l.round+learner.name.hashCode(),true);
                learner.arm="AGGRESSIVE_GRU_VS_WAVEDOG_PATTERN";
            }
            l.prepareStage=2;l.ready=tick+70;return;
        }
        for(var f:List.of(l.a,l.b)){if(!l.cell.contains(f.player.getX(),f.player.getY(),f.player.getZ()))throw new IllegalStateException("Fixture outside cell: "+f.name);ReferenceDuelKit.verify(f.player);}
        l.preparing=false;l.fighting=true;l.started=tick;l.stall=new StallPenaltyClock(System.nanoTime());
        record(judge,physics!=null&&physics.owns(l)?"physics_fixture_start":"round_start",Map.ofEntries(Map.entry("arena",l.cell.id()+1),Map.entry("round",l.round),Map.entry("a",l.a.name),Map.entry("b",l.b.name),Map.entry("style_a",l.a.policy.style.name()),Map.entry("style_b",l.b.policy.style.name()),Map.entry("arm_a",l.a.arm),Map.entry("arm_b",l.b.arm),Map.entry("nominal_rtt_ms_a",l.a.delayMs),Map.entry("nominal_rtt_ms_b",l.b.delayMs),Map.entry("kit",ReferenceDuelKit.DESCRIPTION)));
        for(var f:List.of(l.a,l.b)){var contents=new ArrayList<Object>();for(var item:f.player.getInventory().getContents())contents.add(item==null?null:Base64.getEncoder().encodeToString(item.serializeAsBytes()));record(judge,"starting_inventory",Map.of("fighter",f.name,"slots_native_base64",contents));}
    }
    void step()throws Exception{
        tick++;if(failed)return;if(building){buildStep();return;}if(!built)return;
        if(physics==null&&getConfig().getBoolean("physics-audit",false))physics=new NativeFairnessProbe(this);
        if(tick>=nextAuthentication&&!authenticationQueue.isEmpty()){
            var f=authenticationQueue.removeFirst();f.authQueued=false;nextAuthentication=tick+5;
            if(f.player!=null&&f.player.isOnline()&&internal(f.player)&&auth!=null&&!auth.isAuthenticated(f.player)){
                if(!auth.isRegistered(f.name)&&!auth.registerPlayer(f.name,UUID.randomUUID().toString().replace("-","").substring(0,24)))throw new IllegalStateException("Internal bot registration failed: "+f.name);
                auth.forceLogin(f.player);
            }
        }
        double mspt=Bukkit.getServer().getAverageTickTime();
        if(tick%100==0){record(judge,"load",Map.of("mspt",mspt,"active",lanes.stream().filter(l->l.active).count(),"fighting",lanes.stream().filter(l->l.fighting).count()));
            if(getDataFolder().getUsableSpace()<8L*1024*1024*1024){running=false;getLogger().warning("Less than 8GiB free on record drive; no new rounds will start");}}
        int outsiders=(int)Bukkit.getOnlinePlayers().stream().filter(p->!reserved(p.getName())).count();
        int capacity=physics!=null&&!physics.done?0:Math.min(desired,Math.max(0,(Bukkit.getMaxPlayers()-Math.max(5,outsiders))/2));
        if(running&&mspt<35&&tick-lastRamp>=40&&lanes.stream().filter(l->l.active).count()<capacity){lastRamp=tick;for(int attempt=0;attempt<30;attempt++){var l=lanes.get(nextLane++%30);if(!l.active&&!l.broken){l.active=true;prepare(l);break;}}}
        for(var l:lanes){
            if(l.preparing){prepareStep(l);continue;}
            if(physics!=null&&physics.owns(l)){physics.step();continue;}
            if(l.active&&!l.fighting&&running&&mspt<40&&tick>=l.ready){prepare(l);continue;}
            if(!l.fighting)continue;
            if(l.a.player==null||l.b.player==null||!l.a.player.isOnline()||!l.b.player.isOnline()){l.broken=true;l.fighting=false;record(judge,"round_incomplete",Map.of("arena",l.cell.id()+1,"reason","unexpected disconnect"));continue;}
            int due=l.stall.poll(System.nanoTime());for(int n=0;n<due;n++)penalizeStall(l);
            observe(l.a,l.b);observe(l.b,l.a);decide(l,l.a);decide(l,l.b);
            if((tick&1)==0){execute(l,l.a,l.b);execute(l,l.b,l.a);}else{execute(l,l.b,l.a);execute(l,l.a,l.b);}
            frame(l);
        }
        if(tick-lastFlush>=20){lastFlush=tick;judge.flush();inputs.flush();text.flush();writeStatus();}
    }
    void penalizeStall(Lane l)throws Exception{
        stallEvents++;
        for(var f:List.of(l.a,l.b)){
            if(f.neural!=null)f.neural.penalizeStall();
            if(f.tactical!=null)f.tactical.penalizeStall();
            record(inputs,"reward_feedback",Map.of("fighter",f.name,"reward",-StallPenaltyClock.PENALTY,"reason","stall_120_seconds","penalty_count",l.stall.count));
        }
        record(judge,"stall_penalty",Map.of("arena",l.cell.id()+1,"round",l.round,"seconds",l.stall.seconds(System.nanoTime()),"penalty_count",l.stall.count,"reward_each",-StallPenaltyClock.PENALTY,"a",l.a.name,"b",l.b.name));
        text.write("僵持惩罚／场地 "+(l.cell.id()+1)+"／本场第 "+l.round+" 局：已持续 "+String.format(Locale.ROOT,"%.1f",l.stall.seconds(System.nanoTime()))+" 秒，双方各扣 "+StallPenaltyClock.PENALTY+" 训练奖励（第 "+l.stall.count+" 次）；比赛继续，不扣游戏血量。\n");
    }
    void observe(Fighter f,Fighter target)throws Exception{
        var p=f.player;var t=target.player;var delta=t.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector());
        boolean visible=p.hasLineOfSight(t)&&(delta.lengthSquared()<.001||p.getLocation().getDirection().dot(delta.normalize())>=.5);
        List<DuelPolicy.Arrow> arrows=new ArrayList<>();
        for(var entity:p.getNearbyEntities(32,24,32))if(entity instanceof AbstractArrow a&&!a.isInBlock()&&!a.isOnGround()&&p.hasLineOfSight(a)){
            var d=a.getLocation().toVector().subtract(p.getEyeLocation().toVector());if(d.lengthSquared()>.01&&p.getLocation().getDirection().dot(d.normalize())<.5)continue;
            var v=a.getVelocity();arrows.add(new DuelPolicy.Arrow(tick,a.getX(),a.getY(),a.getZ(),v.getX(),v.getY(),v.getZ()));if(arrows.size()==12)break;
        }
        var packet=new DuelPolicy.Seen(tick,tick+f.delay(),visible,visible?t.getX():0,visible?t.getY():0,visible?t.getZ():0,visible?t.getYaw():0,
            visible&&t.hasActiveItem()&&t.getActiveItem().getType()==Material.SHIELD,visible?t.getInventory().getItemInMainHand().getType().name():"UNKNOWN",visible&&t.hasActiveItem(),visible?target.swing:0,List.copyOf(arrows));
        f.perceptions.add(packet);while(!f.perceptions.isEmpty()&&f.perceptions.peekFirst().available()<=tick)f.policy.seen=f.perceptions.removeFirst();
        record(inputs,"observation",Map.of("fighter",f.name,"captured",packet,"published",f.policy.seen==null?"NONE":f.policy.seen));
    }
    void decide(Lane l,Fighter f)throws Exception{
        var p=f.player;var v=p.getVelocity();var held=p.getInventory().getItemInMainHand();
        int arrows=0;for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.ARROW)arrows+=item.getAmount();
        var ownCrossbow=p.getInventory().getItem(4);
        boolean loaded=ownCrossbow!=null&&ownCrossbow.getItemMeta() instanceof CrossbowMeta meta&&meta.hasChargedProjectiles();
        boolean crit=p.getFallDistance()>0&&!p.isOnGround()&&!p.isInWater()&&!p.isClimbing()&&!p.isInsideVehicle()&&!p.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);
        var self=new DuelPolicy.Self(p.getX(),p.getY(),p.getZ(),p.getEyeLocation().getY(),v.getX(),v.getY(),v.getZ(),p.isOnGround(),crit,p.getCooledAttackStrength(0),p.getHealth(),!p.hasCooldown(Material.SHIELD),p.isBlocking(),arrows,loaded,p.hasActiveItem(),p.getHandRaisedTime(),p.getInventory().getHeldItemSlot());
        if(f.tactical!=null)f.tactical.update(tick,self,f.policy.seen,l.cell,f.policy.style);
        f.policy.actingStyle=f.policy.style; // balanced six-style cohort remains assigned for this bout
        if(f.neural!=null)f.neural.focus=f.tactical==null?ExperienceLibrary.Focus.FREE:f.tactical.focus;
        var action=f.neural!=null?f.neural.act(tick,tick+f.delay(),self,f.policy.seen,l.cell,f.policy.actingStyle,p.getYaw(),p.getPitch()):f.policy.decide(tick,tick+f.delay(),self);
        f.inputs.add(action);
        record(inputs,"decision",Map.of("fighter",f.name,"self",self,"input",action,"style",f.policy.actingStyle.name(),"arm",f.arm,"llm_advice",f.tactical!=null&&f.tactical.advice!=null?f.tactical.advice.name():"NONE","training_focus",f.neural==null?"NONE":f.neural.focus.name()));
    }
    void execute(Lane l,Fighter f,Fighter enemy)throws Exception{
        while(l.fighting&&!f.inputs.isEmpty()&&f.inputs.peekFirst().due()<=tick){
            var a=f.inputs.removeFirst();var p=f.player;if(p.isDead()||enemy.player.isDead())return;
            if(f.neural!=null)f.neural.beginInput(a.decided());
            float priorYaw=p.getYaw(),priorPitch=p.getPitch();boolean priorSprint=p.isSprinting();
            boolean change=p.getInventory().getHeldItemSlot()!=a.slot();
            if(change&&p.hasActiveItem())release.invoke(null,p);if(change)p.getInventory().setHeldItemSlot(a.slot());
            p.setRotation(a.yaw(),a.pitch());p.setSneaking(a.sneak());
            boolean drawing=a.skill().equals("BOW")||a.skill().startsWith("CROSSBOW");
            boolean continuing=a.skill().equals("RL_HOLD");
            if(a.shield()&&!p.hasCooldown(Material.SHIELD)){if(p.hasActiveItem()&&p.getActiveItem().getType()!=Material.SHIELD)release.invoke(null,p);if(!p.hasActiveItem())shieldUse.invoke(null,p);}
            else if(p.hasActiveItem()&&!drawing&&!continuing)release.invoke(null,p);
            if(a.release()&&p.hasActiveItem())release.invoke(null,p);
            if(a.use()&&!p.hasActiveItem())bridge.createAction(p,ActionType.USE,ActionSetting.once()).tick();
            if(a.attack()&&p.hasActiveItem())release.invoke(null,p);
            ClientMovementInput.apply(p,bridge,a.forward(),a.side(),a.sprint());
            if(a.jump()&&p.isOnGround())bridge.createAction(p,ActionType.JUMP,ActionSetting.once()).tick();
            if(a.attack()){
                double charge=p.getCooledAttackStrength(0);int shieldBefore=enemy.player.getCooldown(Material.SHIELD),hurtBefore=enemy.player.getNoDamageTicks();String weapon=p.getInventory().getItemInMainHand().getType().name();NativeMeleeInput.Attempt receipt=null;
                if(p.hasActiveItem())release.invoke(null,p);p.swingMainHand();f.swing++;
                // The fresh geometry below is engine adjudication, never published to the policy.
                double reach=distance(p.getEyeLocation().toVector(),enemy.player.getBoundingBox());
                boolean legalTarget=ClientMovementInput.canAttack(p,enemy.player);
                try{if(legalTarget)receipt=meleeInput.attack(p,enemy.player);else{f.whiffs++;record(judge,"engine_reject",Map.of("fighter",f.name,"actual_reach",reach,"reason","swing_whiff"));}}
                finally{((org.bukkit.craftbukkit.entity.CraftPlayer)p).getHandle().resetAttackStrengthTicker();}
                boolean brokeShield=shieldBefore==0&&enemy.player.getCooldown(Material.SHIELD)>0,effective=receipt!=null&&(receipt.positiveDamage||receipt.velocityPacket);
                if(f.neural!=null)f.neural.attackOutcome(a.decided(),charge,effective,brokeShield,!legalTarget);
                var outcome=new LinkedHashMap<String,Object>();outcome.put("fighter",f.name);outcome.put("decided",a.decided());outcome.put("weapon",weapon);outcome.put("charge_before",charge);outcome.put("charge_after",p.getCooledAttackStrength(0));outcome.put("reach",reach);outcome.put("whiff",!legalTarget);outcome.put("effective",effective);outcome.put("shield_disabled",brokeShield);outcome.put("damage",receipt==null?0:receipt.damage);outcome.put("target_hurt_ticks_before",hurtBefore);outcome.put("shield_facing_before",receipt!=null&&receipt.shieldFacingBefore);outcome.put("native_shield_blocked",receipt!=null&&receipt.blocked);outcome.put("shield_hurt_fallback",receipt!=null&&receipt.shieldFallback);record(judge,"native_attack_outcome",outcome);
            }
            if(a.flightLook()){p.setRotation(priorYaw,priorPitch);ClientMovementInput.apply(p,bridge,a.forward(),a.side(),priorSprint);}
            f.lastSkill=a.skill();record(inputs,"executed_input",Map.of("fighter",f.name,"input",a));
            if(f.neural!=null)f.neural.endInput();
        }
    }
    static double distance(Vector e,org.bukkit.util.BoundingBox b){double x=Math.max(Math.max(b.getMinX()-e.getX(),e.getX()-b.getMaxX()),0),y=Math.max(Math.max(b.getMinY()-e.getY(),e.getY()-b.getMaxY()),0),z=Math.max(Math.max(b.getMinZ()-e.getZ(),e.getZ()-b.getMaxZ()),0);return Math.sqrt(x*x+y*y+z*z);}
    void frame(Lane l)throws Exception{
        var entities=new ArrayList<Object>();
        for(var f:List.of(l.a,l.b)){var p=f.player;var row=new LinkedHashMap<String,Object>();row.put("name",f.name);row.put("uuid",p.getUniqueId());row.put("xyz",List.of(p.getX(),p.getY(),p.getZ()));row.put("velocity",List.of(p.getVelocity().getX(),p.getVelocity().getY(),p.getVelocity().getZ()));row.put("yaw",p.getYaw());row.put("pitch",p.getPitch());row.put("health",p.getHealth());row.put("charge",p.getCooledAttackStrength(0));row.put("ground",p.isOnGround());row.put("fall",p.getFallDistance());row.put("shield",p.isBlocking());row.put("shield_cd",p.getCooldown(Material.SHIELD));row.put("held",p.getInventory().getItemInMainHand().getType().name());row.put("use_ticks",p.getHandRaisedTime());row.put("skill",f.lastSkill);entities.add(row);}
        for(var e:world.getNearbyEntities(new Location(world,l.cell.cx(),223,l.cell.cz()),16,7,16))if(e instanceof AbstractArrow a){var v=a.getVelocity();entities.add(Map.of("type",a.getType().name(),"uuid",a.getUniqueId(),"xyz",List.of(a.getX(),a.getY(),a.getZ()),"velocity",List.of(v.getX(),v.getY(),v.getZ())));}
        record(judge,"frame",Map.of("arena",l.cell.id()+1,"round",l.round,"entities",entities));
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void damage(EntityDamageByEntityEvent e){
        if(physics!=null&&!physics.done){if(physics.combat!=null)physics.combat.damage(e);return;}
        for(var l:lanes)if(l.fighting&&(e.getEntity().equals(l.a.player)||e.getEntity().equals(l.b.player)))safe(()->{
            Object source=e.getDamager() instanceof org.bukkit.entity.Projectile arrow?arrow.getShooter():e.getDamager();
            record(judge,"damage",Map.of("arena",l.cell.id()+1,"round",l.round,"attacker",e.getDamager().getUniqueId(),"source",source instanceof Entity owner?owner.getUniqueId().toString():"UNKNOWN","target",e.getEntity().getUniqueId(),"raw",e.getDamage(),"final",e.getFinalDamage(),"critical",e.isCritical()));
            for(var f:List.of(l.a,l.b))if(f.neural!=null)f.neural.outcomeFeedback(source==f.player?e.getFinalDamage():0,e.getEntity()==f.player?e.getFinalDamage():0);
            for(var f:List.of(l.a,l.b))if(source==f.player&&e.getFinalDamage()>0){f.hits++;f.damage+=e.getFinalDamage();if(e.isCritical())f.crits++;}
        });
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void shoot(EntityShootBowEvent e){if(physics!=null&&physics.combat!=null&&!physics.done)physics.combat.shot(e);}
    @EventHandler(priority=EventPriority.MONITOR)public void death(PlayerDeathEvent e){
        for(var l:lanes)if(l.fighting&&(e.getEntity().equals(l.a.player)||e.getEntity().equals(l.b.player))){
            l.fighting=false;rounds++;e.getDrops().clear();e.setKeepInventory(true);e.setShouldDropExperience(false);
            var winner=e.getEntity().equals(l.a.player)?l.b:l.a;var loser=winner==l.a?l.b:l.a;
            for(var f:List.of(l.a,l.b)){if(f.neural!=null)f.neural.finish(f==winner,f.player.getHealth());if(f.tactical!=null)f.tactical.close();}
            for(var f:List.of(l.a,l.b)){bridge.fromPlayer(f.player).setZza(0);bridge.fromPlayer(f.player).setXxa(0);try{if(f.player.hasActiveItem())release.invoke(null,f.player);}catch(Exception ignored){}}
            wins.merge(winner.policy.style.name(),1,Integer::sum);losses.merge(loser.policy.style.name(),1,Integer::sum);
            safe(()->{var row=new LinkedHashMap<String,Object>();row.put("arena",l.cell.id()+1);row.put("round",l.round);row.put("winner",winner.name);row.put("loser",loser.name);row.put("style_winner",winner.policy.style.name());row.put("style_loser",loser.policy.style.name());row.put("stall_penalties",l.stall.count);row.put("stall_reward_each",l.stall.totalReward());row.put("winner_arm",winner.arm);row.put("loser_arm",loser.arm);row.put("remaining_health",winner.player.getHealth());row.put("ticks",tick-l.started);row.put("winner_hits",winner.hits);row.put("winner_crits",winner.crits);row.put("winner_swings",winner.swing);row.put("winner_whiffs",winner.whiffs);row.put("loser_hits",loser.hits);row.put("loser_crits",loser.crits);row.put("loser_swings",loser.swing);row.put("loser_whiffs",loser.whiffs);row.put("nominal_rtt_ms",winner.delayMs);row.put("learner",l.a.neural!=null&&l.a.neural.learning?l.a.name:l.b.name);record(judge,"round_end",row);if(tactics!=null)tactics.completedBout(row);recent.add(row);while(recent.size()>10)recent.removeFirst();
                text.write("["+winner.arm+" vs "+loser.arm+"] 第 "+rounds+" 局／场地 "+(l.cell.id()+1)+"："+winner.name+"（"+styleChinese(winner.policy.style)+"）胜 "+loser.name+"（"+styleChinese(loser.policy.style)+"），剩 "+String.format(Locale.ROOT,"%.2f 点血／%.2f 心",winner.player.getHealth(),winner.player.getHealth()/2)+"；用时 "+String.format(Locale.ROOT,"%.2f 秒",(tick-l.started)/20.0)+"；胜者造成伤害 "+winner.hits+" 次，真实暴击 "+winner.crits+" 次。"+(winner.player.getHealth()<5?"残血险胜，双方互换较多。":"需结合轨迹与招式时序分析优势。")+"\n");});
            l.ready=tick+60;
            if(desired<30)Bukkit.getScheduler().runTaskLater(this,()->{if(l.fighting)return;for(var f:List.of(l.a,l.b))if(f.player!=null&&f.player.isOnline()&&internal(f.player))Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"fp kill "+f.name);l.active=false;},2);
            break;
        }
    }
    void writeStatus()throws Exception{
        var data=new LinkedHashMap<String,Object>();data.put("run",runId);data.put("built",built);data.put("building",building);data.put("build_columns",columns);data.put("running",running);data.put("failed",failed);data.put("active",lanes.stream().filter(l->l.active).count());data.put("fighting",lanes.stream().filter(l->l.fighting).count());data.put("complete_rounds",rounds);data.put("mspt",Bukkit.getServer().getAverageTickTime());data.put("recent",recent);data.put("style_wins_uncontrolled",wins);data.put("style_losses_uncontrolled",losses);data.put("stall_penalty_events",stallEvents);data.put("stall_penalty_seconds",120);data.put("stall_reward_each",-StallPenaltyClock.PENALTY);data.put("all_agents_learned_controls",true);data.put("target_pairs",desired);data.put("max_players",Bukkit.getMaxPlayers());data.put("neural_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.neural!=null).count());data.put("llm_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.tactical!=null).count());data.put("neural_training",neural!=null);data.put("llm_agent",tactics!=null&&tactics.succeeded.get()>0);data.put("neural",neural==null?Map.of("enabled",false):neural.status());data.put("llm",tactics==null?Map.of("enabled",false):tactics.status());data.put("client_visual_audio",false);
        data.put("wavedog_pattern_reference_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.arm.equals("WAVEDOG_PATTERN_SHIELD_ESCAPE")).count());
        data.put("qwen_curriculum_participants",lanes.stream().filter(l->l.active).flatMap(l->List.of(l.a,l.b).stream()).filter(f->f.arm.startsWith("QWEN_CURRICULUM_")).count());
        data.put("all_agents_learned_controls",data.get("wavedog_pattern_reference_participants").equals(0L));
        Files.writeString(getDataFolder().toPath().resolve("status.json"),JSON.toJson(data),StandardCharsets.UTF_8);
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(command.getName().equalsIgnoreCase("qwen"))return qwenCommand(sender,args);
        if(!sender.hasPermission("wavedog.lab.admin")){sender.sendMessage("§c需要OP权限。");return true;}
        if(args.length==0){sender.sendMessage("/pvplab status | watch <1-30> | leave | start [1-30] | pause | build");return true;}
        safe(()->{switch(args[0].toLowerCase(Locale.ROOT)){
            case "status"->{sender.sendMessage("§a对练区：建成="+built+"；施工="+building+"；新局="+running+"；在打="+lanes.stream().filter(l->l.fighting).count()+"；完整局="+rounds+"；MSPT="+String.format(Locale.ROOT,"%.2f",Bukkit.getServer().getAverageTickTime()));sender.sendMessage("§e全员动作强化学习+共享Qwen；每组轮换一方学习，赛后交流。还不是画面声音感知。");}
            case "models"->{sender.sendMessage("Stall penalty: 120 seconds, reward=-0.25 each, events="+stallEvents);sender.sendMessage("Neural: "+(neural==null?"disabled":JSON.toJson(neural.status())));sender.sendMessage("LLM: "+(tactics==null?"disabled":JSON.toJson(tactics.status())));}
            case "watch"->{if(!(sender instanceof Player p))throw new IllegalArgumentException("玩家执行旁观指令");int id=args.length>1?Integer.parseInt(args[1]):1;if(id<1||id>30)throw new IllegalArgumentException("场地编号1至30");spectators.putIfAbsent(p.getUniqueId(),Map.of("world",p.getWorld().getName(),"x",p.getX(),"y",p.getY(),"z",p.getZ(),"yaw",p.getYaw(),"pitch",p.getPitch(),"mode",p.getGameMode().name()));p.setGameMode(GameMode.SPECTATOR);p.teleport(ArenaLayout.cells().get(id-1).watch(world));p.sendMessage("§a旁观场地 "+id+"。/pvplab watch 2 换场，/pvplab leave 返回。");}
            case "leave"->{if(sender instanceof Player p){var old=spectators.remove(p.getUniqueId());if(old!=null){p.teleport(new Location(Bukkit.getWorld((String)old.get("world")),((Number)old.get("x")).doubleValue(),((Number)old.get("y")).doubleValue(),((Number)old.get("z")).doubleValue(),((Number)old.get("yaw")).floatValue(),((Number)old.get("pitch")).floatValue()));p.setGameMode(GameMode.valueOf((String)old.get("mode")));}}}
            case "pause"->{running=false;sender.sendMessage("§e停止开新局；已开始的局继续打完。");}
            case "start"->{desired=args.length>1?Math.max(1,Math.min(30,Integer.parseInt(args[1]))):30;running=true;failed=false;sender.sendMessage("§a目标 "+desired+" 场，并遵守总人数上限，保留至少5个原服玩家名额；超负载暂缓开新局。");}
            case "build"->beginBuild();
            default->sender.sendMessage("未知子命令，用 /pvplab 查看。");
        }});return true;
    }
    boolean qwenCommand(CommandSender sender,String[] args){
        if(!(sender instanceof Player player)||reserved(player.getName())){sender.sendMessage("§c请由真实玩家在游戏内使用 /qwen。");return true;}
        if(qwenChat==null){sender.sendMessage("§c本地 Qwen 对话服务未就绪。");return true;}
        if(args.length==0){sender.sendMessage("§e/qwen <问题> 对话；OP 使用 /qwen save <经验> 保存可检验经验。");return true;}
        if(args[0].equalsIgnoreCase("save")||args[0].equals("记住")){
            if(!sender.hasPermission("wavedog.lab.admin")){sender.sendMessage("§c保存全服经验需要OP权限。");return true;}
            try{String id=qwenChat.saveExperience(String.join(" ",Arrays.copyOfRange(args,1,args.length)),player.getUniqueId().toString());sender.sendMessage("§a经验已保存到 Qwen 教练经验库（"+id+"）。文字会作为待验证假设进入后续上下文，不会直接改动模型权重。");}catch(Exception e){sender.sendMessage("§c保存失败："+e.getMessage());}
            return true;
        }
        try{qwenChat.ask(player.getUniqueId(),String.join(" ",args)).whenComplete((answer,error)->{
            if(!isEnabled())return;Bukkit.getScheduler().runTask(this,()->{if(!player.isOnline())return;if(error!=null){player.sendMessage("§cQwen 回答失败："+error.getCause().getMessage());return;}String clean=answer.replace('§',' ').replace('\n',' ');for(int i=0;i<clean.length();i+=160)player.sendMessage("§bQwen：§f"+clean.substring(i,Math.min(i+160,clean.length())));});
        });sender.sendMessage("§7Qwen 正在本机生成回答…");}catch(Exception e){sender.sendMessage("§c"+e.getMessage());}
        return true;
    }
    static boolean curriculumBout(int round,int cellId){return cellId==0&&round>0&&round%5==1;}
    static boolean referenceBout(int round,DuelPolicy.Style a,DuelPolicy.Style b){return round>0&&round%10==1&&((a==DuelPolicy.Style.AGGRESSIVE&&b==DuelPolicy.Style.DEFENSIVE)||(b==DuelPolicy.Style.AGGRESSIVE&&a==DuelPolicy.Style.DEFENSIVE));}
    static String styleChinese(DuelPolicy.Style s){return switch(s){case DEFENSIVE->"盾反防守";case AGGRESSIVE->"主动进攻";case FLANK->"短促侧绕";case GROUND_COMBO->"地面连招";case RANGED->"远程机会";case MIXED->"混合节奏";};}
    static void writeQuiet(BufferedWriter w,String line){try{if(w!=null){w.write(line);w.newLine();w.flush();}}catch(Exception ignored){}}
    @Override public void onDisable(){running=false;if(qwenChat!=null)qwenChat.close();if(tactics!=null)tactics.close();if(neural!=null)neural.close();for(var l:lanes){if(l.fighting){l.fighting=false;try{record(judge,"round_incomplete",Map.of("arena",l.cell.id()+1,"reason","server shutdown"));}catch(Exception ignored){}}for(var f:List.of(l.a,l.b))if(f.player!=null&&internal(f.player))try{if(f.tactical!=null)f.tactical.close();bridge.fromPlayer(f.player).setZza(0);bridge.fromPlayer(f.player).setXxa(0);if(f.player.hasActiveItem())release.invoke(null,f.player);Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"fp kill "+f.name);}catch(Exception ignored){}}for(var w:Arrays.asList(judge,inputs,text,original))if(w!=null)try{w.close();}catch(Exception ignored){}}
}
