package local.wavedog.lab;

import io.github.hello09x.fakeplayer.api.spi.NMSBridge;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

/** Client-side input gates missing from ServerPlayer.doTick; native physics does the rest. */
final class ClientMovementInput {
    record Resolved(float forward,float side,boolean sprint){}
    static Resolved resolve(float forward,float side,boolean requestSprint,boolean using,boolean sneak,int food){
        forward=Math.max(-1,Math.min(1,Float.isFinite(forward)?forward:0));side=Math.max(-1,Math.min(1,Float.isFinite(side)?side:0));
        // LivingEntity.aiStep already applies 0.98 and native travel normalizes diagonal input.
        float scale=(using?.2f:1f)*(sneak?.3f:1f);
        return new Resolved(forward*scale,side*scale,requestSprint&&forward>=.8f&&!using&&!sneak&&food>6);
    }
    static Resolved apply(Player p,NMSBridge bridge,float forward,float side,boolean sprint){
        var input=resolve(forward,side,sprint,p.hasActiveItem(),p.isSneaking(),p.getFoodLevel());
        p.setSprinting(input.sprint());bridge.fromPlayer(p).setZza(input.forward());bridge.fromPlayer(p).setXxa(input.side());return input;
    }
    static double reach(Player p){var value=p.getAttribute(Attribute.PLAYER_ENTITY_INTERACTION_RANGE);return Math.min(3,value==null?3:value.getValue());}
    static boolean canAttack(Player p,Player target){
        double reach=reach(p);return p.hasLineOfSight(target)&&LivePracticeLab.distance(p.getEyeLocation().toVector(),target.getBoundingBox())<=reach
            &&target.getBoundingBox().rayTrace(p.getEyeLocation().toVector(),p.getEyeLocation().getDirection(),reach)!=null;
    }
}
