package local.wavedog.lab;

import com.google.gson.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Player conversation with the local Qwen endpoint; independent of the combat coach queue. */
final class QwenChat implements AutoCloseable {
    static final Gson JSON=new Gson();
    static final String SYSTEM="你是 Minecraft 服务器内的本地 Qwen 对话助手。用简洁中文回答。经验卡是待检验的打法假设，不是已证实结论。你不能直接修改战斗网络权重或代替玩家操作，也不是 Codex 聊天。不要声称已保存经验，只有玩家明确使用 /qwen save 并得到保存回执才算保存。";
    final URI endpoint;final HttpClient client;final ThreadPoolExecutor worker;final Path directory,transcript;final ExperienceLibrary experiences;
    final Map<UUID,ArrayDeque<Map<String,String>>> history=new HashMap<>();
    final Set<UUID> pending=ConcurrentHashMap.newKeySet();
    final Map<UUID,Long> lastRequest=new ConcurrentHashMap<>();
    QwenChat(Path directory,String address)throws Exception{
        endpoint=URI.create(address);if(!"http".equals(endpoint.getScheme())||!List.of("127.0.0.1","localhost").contains(endpoint.getHost()))throw new IllegalArgumentException("Local HTTP Qwen endpoint required");
        Files.createDirectories(directory);this.directory=directory;transcript=directory.resolve("qwen-conversations.jsonl");experiences=new ExperienceLibrary(directory);
        client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).proxy(new ProxySelector(){public List<Proxy> select(URI u){return List.of(Proxy.NO_PROXY);}public void connectFailed(URI u,SocketAddress a,java.io.IOException e){}}).build();
        worker=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(12),r->{var t=new Thread(r,"WaveDog-player-Qwen");t.setDaemon(true);return t;},new ThreadPoolExecutor.AbortPolicy());
        loadHistory();
    }
    void loadHistory()throws Exception{
        if(!Files.exists(transcript))return;
        try(var lines=Files.lines(transcript,StandardCharsets.UTF_8)){lines.forEach(line->{try{var row=JsonParser.parseString(line).getAsJsonObject();var id=UUID.fromString(row.get("player").getAsString());String role=row.get("role").getAsString();if(!role.equals("user")&&!role.equals("assistant"))return;remember(id,role,row.get("content").getAsString());}catch(Exception ignored){}});}
    }
    void remember(UUID id,String role,String content){var turns=history.computeIfAbsent(id,k->new ArrayDeque<>());turns.addLast(Map.of("role",role,"content",content));while(turns.size()>6)turns.removeFirst();}
    CompletableFuture<String> ask(UUID id,String text){
        text=text.strip();if(text.isEmpty()||text.length()>300||text.chars().anyMatch(c->Character.isISOControl(c)))throw new IllegalArgumentException("问题需为1至300字的单行文字");
        long now=System.nanoTime();Long last=lastRequest.get(id);if(last!=null&&now-last<TimeUnit.SECONDS.toNanos(4))throw new IllegalStateException("请稍等4秒再提问");
        if(!pending.add(id))throw new IllegalStateException("上一条问题还在回答中");
        lastRequest.put(id,now);final String question=text;
        try{return CompletableFuture.supplyAsync(()->{try{return infer(id,question);}catch(Exception e){throw new CompletionException(e);}finally{pending.remove(id);}},worker);}catch(RejectedExecutionException e){pending.remove(id);throw new IllegalStateException("Qwen 忙碌，请稍后再试",e);}
    }
    String infer(UUID id,String question)throws Exception{
        var messages=new ArrayList<Map<String,String>>();messages.add(Map.of("role","system","content",SYSTEM+"\n长期原则："+core()+"\n累计训练："+JSON.toJson(trainingProgress())+"\n经验库最新条目："+JSON.toJson(experiences.chatContext())));
        var recent=new ArrayList<>(history.getOrDefault(id,new ArrayDeque<>()));for(int i=Math.max(0,recent.size()-4);i<recent.size();i++)messages.add(recent.get(i));messages.add(Map.of("role","user","content",question));
        var body=Map.of("model","wavedog-chat","messages",messages,"temperature",0.5,"max_tokens",180,"stream",false);
        var request=HttpRequest.newBuilder(endpoint).timeout(Duration.ofSeconds(40)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(JSON.toJson(body),StandardCharsets.UTF_8)).build();
        var response=client.send(request,HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));if(response.statusCode()!=200)throw new IllegalStateException("本地 Qwen HTTP "+response.statusCode());
        String answer=JsonParser.parseString(response.body()).getAsJsonObject().getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString().strip();
        if(answer.isEmpty())throw new IllegalStateException("本地 Qwen 返回空内容");if(answer.length()>500)answer=answer.substring(0,500);
        append(id,"user",question);append(id,"assistant",answer);remember(id,"user",question);remember(id,"assistant",answer);return answer;
    }
    void append(UUID id,String role,String content)throws Exception{Files.writeString(transcript,JSON.toJson(Map.of("at",java.time.Instant.now().toString(),"player",id.toString(),"role",role,"content",content))+System.lineSeparator(),StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
    String core()throws Exception{var file=directory.resolve("coach-briefing-core.txt");if(!Files.exists(file))return "盾斧打法是待验证假设；战斗网络从真实对局学习。";String value=Files.readString(file,StandardCharsets.UTF_8);return value.substring(0,Math.min(320,value.length()));}
    Map<String,Object> trainingProgress()throws Exception{var file=directory.resolve("status.json");if(!Files.exists(file))return Map.of();try{var status=JsonParser.parseString(Files.readString(file,StandardCharsets.UTF_8)).getAsJsonObject();var out=new LinkedHashMap<String,Object>();for(var pair:List.of(Map.entry("neural","gradient_updates"),Map.entry("neural","trained_episodes"),Map.entry("neural","training_samples"),Map.entry("llm","completed_bout_reports"),Map.entry("llm","shared_review_batches"))){var section=status.getAsJsonObject(pair.getKey());if(section!=null&&section.has(pair.getValue()))out.put(pair.getValue(),section.get(pair.getValue()).getAsLong());}return out;}catch(Exception e){return Map.of();}}
    String saveExperience(String text,String author)throws Exception{return experiences.save(text,author);}
    public void close(){worker.shutdownNow();}
}
