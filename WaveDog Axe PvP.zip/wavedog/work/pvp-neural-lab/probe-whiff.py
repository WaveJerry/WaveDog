"""Isolated Paper smoke test for the exact candidate JAR and native whiff cooldown."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import secrets
import shutil
import socket
import subprocess
import time

base = Path(__file__).resolve().parent
main = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
test = base / 'isolated-server'
port, rcon_port = 25589, 25590
for value in (port, rcon_port):
    with socket.socket() as sock:
        if sock.connect_ex(('127.0.0.1', value)) == 0:
            raise SystemExit(f'Isolated port {value} already in use')
plugins = test / 'plugins'
plugins.mkdir(parents=True, exist_ok=True)
for name in ('CommandAPI.jar', 'ArrowSense.jar', 'fakeplayer.jar', 'PvPArenaAI.jar', 'AuthMe.jar'):
    shutil.copy2(main / 'plugins' / name, plugins / name)
candidate = base / 'WaveDogPracticeLab.jar'
shutil.copy2(candidate, plugins / candidate.name)
data = plugins / 'WaveDogPracticeLab'
data.mkdir(exist_ok=True)
old_config = data / 'config.yml'
built = old_config.exists() and 'built: true' in old_config.read_text(encoding='utf-8')
config = (base / 'config.yml').read_text(encoding='utf-8')
config = config.replace('active-arenas: 30', 'active-arenas: 6')
config = config.replace('built: false', f'built: {str(built).lower()}')
old_config.write_text(config, encoding='utf-8')
model = data / 'models' / 'recurrent-ppo.json'
model.parent.mkdir(exist_ok=True)
if not model.exists():
    shutil.copy2(base / 'recurrent-seed' / 'recurrent-ppo.json', model)
initial_updates = json.loads(model.read_text(encoding='utf-8')).get('updates', 0)
old_status = data / 'status.json'
initial_run = json.loads(old_status.read_text(encoding='utf-8')).get('run') if old_status.exists() else None
for name in ('coach-research-notes.txt', 'coach-briefing-core.txt'):
    shutil.copy2(base / name, data / name)
shutil.copy2(base / 'coach-experience-library.json', data / 'coach-experience-library.json')
for name in ('home', 'tmp'):
    (test / name).mkdir(exist_ok=True)
secret = secrets.token_urlsafe(24)
(test / 'eula.txt').write_text('eula=true\n', encoding='ascii')
(test / 'server.properties').write_text(
    f'server-ip=127.0.0.1\nserver-port={port}\nonline-mode=false\n'
    f'enable-rcon=true\nrcon.port={rcon_port}\nrcon.password={secret}\n'
    'max-players=65\nspawn-protection=0\nview-distance=3\n'
    'simulation-distance=3\nlevel-type=minecraft:flat\n'
    'generate-structures=false\nspawn-monsters=false\nspawn-animals=false\n'
    'spawn-npcs=false\nallow-nether=false\n', encoding='ascii')
runtime_cp = os.pathsep.join(map(str, [main / 'versions/1.21.1/paper-1.21.1.jar',
                                     *sorted((main / 'libraries').rglob('*.jar'))]))
args = [str(main / 'runtime/java21/bin/java.exe'), '-Xms512M', '-Xmx3G',
        '-Duser.home=' + str(test / 'home'), '-Djava.io.tmpdir=' + str(test / 'tmp'),
        '-cp', runtime_cp, 'org.bukkit.craftbukkit.Main', '--nogui']
spec = importlib.util.spec_from_file_location('rcon',
    'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
rcon.PROPERTIES = {'rcon.port': str(rcon_port), 'rcon.password': secret}
stamp = time.time()
receipt = {'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
           'main_server_modified': False, 'status': 'STARTING'}
log = (test / 'whiff-console.log').open('wb')
proc = subprocess.Popen(args, cwd=test, stdin=subprocess.PIPE,
                        stdout=log, stderr=subprocess.STDOUT)
print(f'ISOLATED_WHIFF_PID={proc.pid}', flush=True)
try:
    while time.time() - stamp < 240:
        if proc.poll() is not None:
            raise RuntimeError('Isolated Paper exited early')
        native = data / 'native-combat-probe.json'
        status = data / 'status.json'
        if native.exists() and native.stat().st_mtime >= stamp:
            result = json.loads(native.read_text(encoding='utf-8'))
            case = next((c for c in result['cases'] if c['case'] == 'axe_whiff_resets_charge'), None)
            if result['status'] != 'PASS' or case is None or not case['pass']:
                raise RuntimeError('Native combat or whiff reset probe failed: ' + json.dumps(case))
            if status.exists():
                current = json.loads(status.read_text(encoding='utf-8'))
                recent = current.get('recent', [])
                curriculum_bout = any('QWEN_CURRICULUM_' in str(row.get('winner_arm', ''))
                                      or 'QWEN_CURRICULUM_' in str(row.get('loser_arm', ''))
                                      for row in recent)
                reference_bout = any('WAVEDOG_PATTERN_SHIELD_ESCAPE' in str(row.get('winner_arm', ''))
                                     or 'WAVEDOG_PATTERN_SHIELD_ESCAPE' in str(row.get('loser_arm', ''))
                                     for row in recent)
                if (current.get('run') != initial_run and current.get('built') and not current.get('failed') and
                    current.get('complete_rounds', 0) >= 1 and
                    current.get('neural', {}).get('gradient_updates', 0) > initial_updates and
                    curriculum_bout and reference_bout):
                    receipt.update(status='PASS', whiff_case=case,
                                   completed_rounds=current['complete_rounds'],
                                   gradient_updates=current['neural']['gradient_updates'],
                                   baseline_updates=initial_updates,
                                   curriculum_bout_completed=curriculum_bout,
                                   wavedog_reference_bout_completed=reference_bout)
                    break
        time.sleep(2)
    else:
        receipt.update(status='INCOMPLETE', reason='Native audit or complete bout timed out')
except Exception as exc:
    receipt.update(status='FAIL', error=repr(exc))
finally:
    if proc.poll() is None:
        try:
            rcon.command('pvplab pause')
            rcon.command('save-all flush')
            rcon.command('stop')
        except Exception:
            proc.stdin.write(b'stop\n')
            proc.stdin.flush()
        proc.wait(timeout=60)
    log.close()
    receipt['normal_exit_code'] = proc.returncode
    receipt['elapsed_seconds'] = round(time.time() - stamp, 1)
    (base / 'whiff-probe-result.json').write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
if receipt['status'] != 'PASS':
    raise SystemExit(1)
