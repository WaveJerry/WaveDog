from pathlib import Path
import hashlib,json,os,socket,subprocess,time,urllib.request,zipfile

b=Path(__file__).resolve().parent;r=b/'model-runtime';r.mkdir(exist_ok=True)
s=socket.socket();proxy=s.connect_ex(('127.0.0.1',10808))==0;s.close()
opener=urllib.request.build_opener(urllib.request.ProxyHandler({'http':'http://127.0.0.1:10808','https':'http://127.0.0.1:10808'} if proxy else {}))
def fetch(url):return opener.open(urllib.request.Request(url,headers={'User-Agent':'WaveDog-local-model-setup'}),timeout=120)
def download(url,path,expected=None):
    if path.exists() and (not expected or hashlib.sha256(path.read_bytes()).hexdigest()==expected):return
    part=path.with_suffix(path.suffix+'.partial');last=0
    for attempt in range(4):
        try:
            with fetch(url) as response,part.open('wb') as out:
                total=int(response.headers.get('Content-Length',0));count=0
                while chunk:=response.read(1024*1024):
                    out.write(chunk);count+=len(chunk)
                    if time.monotonic()-last>15:print(json.dumps({'download':path.name,'bytes':count,'total':total}),flush=True);last=time.monotonic()
            sha=hashlib.sha256(part.read_bytes()).hexdigest()
            if expected and sha!=expected:raise RuntimeError('Official hash mismatch '+path.name)
            part.replace(path);return
        except Exception as e:
            print('Download attempt '+str(attempt+1)+': '+str(e),flush=True)
            if attempt==3:raise
releases=json.load(fetch('https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=5'))
asset=next(a for release in releases for a in release['assets'] if a['name'].endswith('bin-win-cpu-x64.zip'))
sha=asset.get('digest','').removeprefix('sha256:')
archive=r/asset['name'];download(asset['browser_download_url'],archive,sha or None)
with zipfile.ZipFile(archive) as z:
    for member in z.infolist():
        target=(r/member.filename).resolve()
        if not target.is_relative_to(r.resolve()):raise RuntimeError('Archive path escapes runtime')
    z.extractall(r)
model='qwen2.5-1.5b-instruct-q4_k_m.gguf';url='https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/'+model
details=json.load(fetch('https://huggingface.co/api/models/Qwen/Qwen2.5-1.5B-Instruct-GGUF/tree/main'))
file=next(x for x in details if x.get('path')==model);model_sha=file.get('lfs',{}).get('oid')
download(url,r/model,model_sha)
for name in ('LICENSE','README.md'):
    (r/('Qwen-'+name)).write_bytes(fetch('https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/raw/main/'+name).read())
exe=next(r.rglob('llama-server.exe'));log=r/'server.log'
sock=socket.socket();already=sock.connect_ex(('127.0.0.1',18765))==0;sock.close()
if not already:
    out=log.open('ab');proc=subprocess.Popen([str(exe),'-m',str(r/model),'--host','127.0.0.1','--port','18765','-t','3','-tb','3','-c','2048','-np','2','--alias','wavedog-tactics','--no-webui'],cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));out.close();pid=proc.pid
else:pid=None
local=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(90):
    try:
        with local.open('http://127.0.0.1:18765/health',timeout=2) as response:
            if response.status==200:break
    except Exception:time.sleep(1)
else:raise SystemExit('Local model server not ready; inspect '+str(log))
manifest={'model':'Qwen2.5-1.5B-Instruct Q4_K_M','model_sha256':hashlib.sha256((r/model).read_bytes()).hexdigest(),'runtime_asset':asset,'endpoint':'http://127.0.0.1:18765/v1/chat/completions','pid':pid,'source':url,'api_cost':0,'bind':'loopback only'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(manifest),flush=True)
