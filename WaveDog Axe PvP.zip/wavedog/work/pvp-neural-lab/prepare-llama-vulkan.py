"""Install the matching official llama.cpp Vulkan build beside the CPU fallback."""
from pathlib import Path
import hashlib
import json
import urllib.request
import zipfile

base = Path(__file__).resolve().parent / "model-runtime"
folder = base / "vulkan"
folder.mkdir(exist_ok=True)
name = "llama-b12246-bin-win-vulkan-x64.zip"
expected = "ca8cfe89b00fd447ac3b816d095871bc9b6ca9835fd96e06238a9ff5d1640639"
archive = folder / name
if not archive.exists():
    with urllib.request.urlopen(
        f"https://github.com/ggml-org/llama.cpp/releases/download/b12246/{name}", timeout=90
    ) as response, archive.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)
with archive.open("rb") as source:
    actual = hashlib.file_digest(source, "sha256").hexdigest()
if actual != expected:
    raise SystemExit("Vulkan runtime SHA256 mismatch")
with zipfile.ZipFile(archive) as source:
    for item in source.infolist():
        path = (folder / item.filename).resolve()
        if not path.is_relative_to(folder.resolve()):
            raise SystemExit("Unsafe runtime archive path")
    source.extractall(folder)
print(json.dumps({"runtime": str(folder / "llama-server.exe"), "sha256": actual}))
