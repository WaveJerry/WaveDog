"""Create an offline GRU seed from a preserved snapshot; no running server is changed."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time

b=Path(__file__).resolve().parent;s=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
seed=b/'recurrent-seed';seed.mkdir(exist_ok=True)
legacy=s/'plugins/WaveDogPracticeLab/models/combat-policy.json';snapshot=seed/'legacy-source.json'
shutil.copy2(legacy,snapshot)
cp=os.pathsep.join(map(str,[b/'classes',s/'versions/1.21.1/paper-1.21.1.jar',*sorted((s/'libraries').rglob('*.jar'))]))
tests=b/'test-classes';tests.mkdir(exist_ok=True)
subprocess.run([str(s/'runtime/java21/bin/javac.exe'),'-proc:none','-encoding','UTF-8','--release','21','-cp',cp,'-d',str(tests),str(b/'tests/local/wavedog/lab/RecurrentPpoTests.java')],check=True)
start=time.monotonic()
subprocess.run([str(s/'runtime/java21/bin/java.exe'),'-cp',str(tests)+os.pathsep+cp,'local.wavedog.lab.RecurrentPpoTests','prepare',str(seed),str(snapshot)],check=True,timeout=240)
manifest={'recurrent_seed_sha256':hashlib.sha256((seed/'recurrent-ppo.json').read_bytes()).hexdigest(),'teacher_snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'source':'actual preserved legacy combat policy','synthetic_examples_not_matches':6000,'distillation_epochs':8,'seconds':time.monotonic()-start,'main_modified':False}
(seed/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False),flush=True)
