"""Read native combat events without changing training records or checkpoints."""
from collections import Counter, defaultdict
from pathlib import Path
import gzip
import json
import math
import sys

path = Path(sys.argv[1])
participants = {}
previous = {}
pending = defaultdict(list)
damage_events = {}
totals = Counter()
fighters = defaultdict(Counter)
examples = []
zero_examples = []

with gzip.open(path, 'rt', encoding='utf-8') as source:
    for line in source:
        event = json.loads(line)
        kind, tick, data = event['type'], event['tick'], event['data']
        if kind in ('round_start', 'physics_fixture_start'):
            participants[data['arena']] = (data['a'], data['b'], data['round'])
        elif kind == 'damage':
            damage_events[(tick, data['arena'], data['source'])] = data
        elif kind == 'native_attack_outcome':
            # The frame event follows both fighters' executions in this tick.
            arena = int(data['fighter'][4:6])
            owner = previous.get(arena, {}).get(data['fighter'], {})
            hit = damage_events.get((tick, arena, owner.get('uuid')))
            data['damage_event'] = hit if hit and hit['attacker'] == hit['source'] else None
            pending[(tick, arena)].append(data)
        elif kind == 'frame':
            arena = data['arena']
            current = {row['name']: row for row in data['entities'] if 'name' in row}
            prior = previous.get(arena, {})
            names = participants.get(arena)
            for attack in pending.pop((tick, arena), []):
                fighter = attack['fighter']
                if not names or fighter not in names[:2]:
                    continue
                opponent = names[1] if fighter == names[0] else names[0]
                attacker_now = current.get(fighter, {})
                target_before = prior.get(opponent, {})
                if not attacker_now or not target_before:
                    continue
                weapon = attacker_now.get('held', 'UNKNOWN')
                shield = bool(target_before.get('shield')) and target_before.get('shield_cd') == 0
                if not shield:
                    continue
                label = ('axe' if weapon.endswith('_AXE') else 'other') + ('_whiff' if attack['whiff'] else '_in_range')
                totals[label] += 1
                fighters[fighter][label] += 1
                if attack['shield_disabled']:
                    totals[label + '_broke'] += 1
                    fighters[fighter][label + '_broke'] += 1
                if label == 'axe_in_range' and not attack['shield_disabled']:
                    target_pos = target_before['xyz']
                    attacker_pos = attacker_now['xyz']
                    yaw = math.radians(target_before['yaw'])
                    facing = (-math.sin(yaw) * (attacker_pos[0] - target_pos[0]) +
                              math.cos(yaw) * (attacker_pos[2] - target_pos[2]))
                    key = 'no_break_' + ('damage_event_zero' if attack['damage_event'] and attack['damage_event']['final'] == 0 else 'damage_event_positive' if attack['damage_event'] else 'no_damage_event')
                    totals[key] += 1
                    totals[key + ('_facing_front' if facing > .1 else '_facing_side_or_back')] += 1
                    if key == 'no_break_damage_event_zero' and len(zero_examples) < 20:
                        zero_examples.append({'tick': tick, 'arena': arena, 'round': names[2],
                                              'fighter': fighter, 'weapon': weapon,
                                              'charge': attack['charge_before'], 'reach': attack['reach'],
                                              'damage_event': attack['damage_event'],
                                              'facing_dot_unnormalized': facing,
                                              'target_shield_before': target_before['shield'],
                                              'target_shield_after': current.get(opponent, {}).get('shield')})
                    if len(examples) < 12:
                        examples.append({'tick': tick, 'arena': arena, 'round': names[2], 'fighter': fighter,
                                         'weapon': weapon, 'charge': attack['charge_before'],
                                         'reach': attack['reach'], 'effective': attack['effective'],
                                         'damage_event': attack['damage_event'], 'facing_dot_unnormalized': facing,
                                         'prior_shield': target_before['shield'],
                                         'current_shield': current.get(opponent, {}).get('shield'),
                                         'shield_cd': current.get(opponent, {}).get('shield_cd')})
            previous[arena] = current

print(json.dumps({'source': str(path), 'totals': totals,
                  'fighters_with_axe_in_range': {k: dict(v) for k, v in fighters.items() if v['axe_in_range']},
                  'axe_no_break_examples': examples,
                  'zero_damage_no_break_examples': zero_examples}, ensure_ascii=False, indent=2))
