"""Run real model/HTTP checks and bind the result to the exact candidate JAR."""
from pathlib import Path
import hashlib,json,re,subprocess,sys

base=Path(__file__).resolve().parent
result=subprocess.run([sys.executable,'-B','-X','utf8',str(base/'test-models.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf-8',errors='replace')
(base/'all-control-tests.log').write_text(result.stdout,encoding='utf-8')
print(result.stdout,flush=True)
match=re.search(r'NEURAL_MODEL_TESTS_PASS checks=(\d+)',result.stdout)
ppo=re.search(r'RECURRENT_PPO_TESTS_PASS checks=(\d+)',result.stdout)
if result.returncode or not match or not ppo:
    raise SystemExit('FAILED: model checks incomplete; main server preserved')
proof={'status':'PASS','candidate_sha256':hashlib.sha256((base/'WaveDogPracticeLab.jar').read_bytes()).hexdigest(),'checks':int(match.group(1))+int(ppo.group(1)),'recurrent_ppo_checks':int(ppo.group(1)),'recurrent_seed_sha256':hashlib.sha256((base/'recurrent-seed/recurrent-ppo.json').read_bytes()).hexdigest(),'actual_local_llm_and_compact_post_bout_review':True,'experience_retrieval_and_context_gradient':True}
(base/'all-control-test-result.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False),flush=True)
