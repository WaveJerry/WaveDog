from pathlib import Path
import ctypes,hashlib,importlib.util,json,socket,subprocess,time,urllib.request
b=Path(__file__).resolve().parent
candidate=b/'WaveDogPracticeLab.jar'
proof=json.loads((b/'all-control-test-result.json').read_text(encoding='utf-8'))
if proof.get('status')!='PASS' or proof.get('candidate_sha256')!=hashlib.sha256(candidate.read_bytes()).hexdigest():raise SystemExit('FAILED: exact model check missing')
whiff=json.loads((b/'whiff-probe-result.json').read_text(encoding='utf-8'))
if whiff.get('status')!='PASS' or whiff.get('candidate_sha256')!=proof['candidate_sha256'] or whiff.get('whiff_case',{}).get('pass') is not True or whiff.get('curriculum_bout_completed') is not True or whiff.get('wavedog_reference_bout_completed') is not True or whiff.get('normal_exit_code')!=0:raise SystemExit('FAILED: exact isolated combat and curriculum proof missing; main preserved')
if proof.get('recurrent_seed_sha256')!=hashlib.sha256((b/'recurrent-seed/recurrent-ppo.json').read_bytes()).hexdigest():raise SystemExit('FAILED: exact recurrent seed check missing; main preserved')
core=(b/'coach-briefing-core.txt').read_text(encoding='utf-8').strip()
if len(core)>320 or '后撤盾反逃逸' not in core or '空挥' not in core or '高蓄力' not in core or '0.625秒' not in core:raise SystemExit('FAILED: full coach core will not fit the Qwen prompt; main preserved')
cards=json.loads((b/'coach-experience-library.json').read_text(encoding='utf-8'))['cards']
if len(cards)<66 or not all(any(c.get('id')==name for c in cards) for name in ('brief-20261111-aggressive-vs-shield-escape','brief-20261111-attack-interval','brief-20261111-native-axe-shield-break','brief-20261111-wavedog-reference','brief-20261111-qwen-curriculum','brief-20261111-ranged-opening')):raise SystemExit('FAILED: latest coach experience cards missing; main preserved')
with urllib.request.urlopen('http://127.0.0.1:18765/health',timeout=5) as response:
    if response.status!=200:raise SystemExit('FAILED: local model not ready; main preserved')
spec=importlib.util.spec_from_file_location('rcon','D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py');rcon=importlib.util.module_from_spec(spec);spec.loader.exec_module(rcon)
old=json.loads((b/'main-install.json').read_text(encoding='utf-8'));pid=int(old['pid'])
status=Path(old['server'])/'plugins/WaveDogPracticeLab/status.json'
if status.exists():(b/'before-all-control-main-status.json').write_bytes(status.read_bytes())
print('SAVING_MAIN_AND_STOPPING_OLD_LAB',flush=True)
print(rcon.command('pvplab pause'),flush=True)
deadline=time.monotonic()+180
while time.monotonic()<deadline:
    if status.exists():
        try:
            current=json.loads(status.read_text(encoding='utf-8'))
            if current.get('fighting')==0:
                print('ACTIVE_BOUTS_COMPLETED rounds='+str(current.get('complete_rounds')),flush=True)
                break
        except (OSError,ValueError):pass
    time.sleep(2)
else:print('ACTIVE_BOUT_WAIT_TIMEOUT: unfinished bouts will be logged incomplete',flush=True)
print(rcon.command('save-all flush'),flush=True)
try:rcon.command('stop')
except (OSError,TimeoutError,ConnectionError):pass
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.restype=ctypes.c_void_p;kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
handle=kernel.OpenProcess(0x100000,False,pid)
if handle:
    code=kernel.WaitForSingleObject(handle,60000);kernel.CloseHandle(handle)
    if code!=0:raise SystemExit('FAILED: old main has not exited; no forced kill or replacement')
time.sleep(2)
subprocess.run(['E:/python.exe','-B','-X','utf8',str(b/'install-and-start.py'),'--main-supervised-test'],check=True)
