from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent
p=b/'src/local/wavedog/lab/LivePracticeLab.java';s=p.read_text(encoding='utf-8')
s=s.replace('long stallEvents;','long stallEvents;NativeFairnessProbe physics;')
s=s.replace('tick++;if(building){buildStep();return;}if(!built)return;','tick++;if(building){buildStep();return;}if(!built)return;\n        if(physics==null&&getConfig().getBoolean("physics-audit",false))physics=new NativeFairnessProbe(this);')
s=s.replace('if(l.preparing){prepareStep(l);continue;}','if(l.preparing){prepareStep(l);continue;}\n            if(physics!=null&&physics.owns(l)){physics.step();continue;}')
s=s.replace('record(judge,"round_start",Map.of(', 'record(judge,physics!=null&&physics.owns(l)?"physics_fixture_start":"round_start",Map.of(')
p.write_text(s,encoding='utf-8')
p=b/'config.yml';s=p.read_text(encoding='utf-8');s+='\nphysics-audit: true\n';p.write_text(s,encoding='utf-8')
p=b/'install-and-start.py';s=p.read_text(encoding='utf-8');s=s.replace('import hashlib,importlib.util,json,os,shutil,socket,subprocess,time','import hashlib,importlib.util,json,os,shutil,socket,subprocess,time,sys')
old="probe=json.loads((b/'probe-result.json').read_text(encoding='utf-8'))\nif probe.get('status')!='PASS' or probe.get('candidate_sha256')!=digest:raise SystemExit('FAILED: This exact candidate has not passed the isolated native test')"
new="""supervised='--main-supervised-test' in sys.argv
if supervised:
    tests=json.loads((b/'all-control-test-result.json').read_text(encoding='utf-8'))
    if tests.get('status')!='PASS' or tests.get('candidate_sha256')!=digest:raise SystemExit('FAILED: This candidate has not passed all-action model tests')
else:
    probe=json.loads((b/'probe-result.json').read_text(encoding='utf-8'))
    if probe.get('status')!='PASS' or probe.get('candidate_sha256')!=digest:raise SystemExit('FAILED: This exact candidate has not passed the isolated native test')"""
assert old in s;s=s.replace(old,new)
s=s.replace("cfg=cfg.replace('active-arenas: 18','active-arenas: 30');config.write_text(cfg,encoding='utf-8')","cfg=cfg.replace('active-arenas: 18','active-arenas: 30');cfg+='\\nphysics-audit: true\\n' if 'physics-audit:' not in cfg else '';config.write_text(cfg,encoding='utf-8')")
s=s.replace("'target_parallel_pairs':30,","'target_parallel_pairs':30,'supervised_main_test':supervised,")
p.write_text(s,encoding='utf-8')
print('SUPERVISED_MAIN_AUDIT_ENABLED')
