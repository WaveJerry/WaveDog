"""Stop the main practice server before resetting explicitly invalidated training."""
import importlib.util
import json
import socket
import time
from pathlib import Path

base = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rcon', 'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)

def listening():
    with socket.socket() as connection:
        connection.settimeout(1)
        return connection.connect_ex(('127.0.0.1', 25566)) == 0

receipt = {'at': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'server': 'D:/Walt Disney/Minecraft-1.21.1-Server'}
if listening():
    receipt['pause'] = rcon.command('pvplab pause')
    receipt['save'] = rcon.command('save-all flush')
    try:
        receipt['stop'] = rcon.command('stop')
    except (OSError, TimeoutError, ConnectionError):
        receipt['stop'] = 'connection closed during stop'
    for _ in range(60):
        if not listening():
            break
        time.sleep(1)
    else:
        raise SystemExit('Main game port still listening; training files must not be reset')
receipt['main_stopped'] = not listening()
(base / 'invalid-practice-stop.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
