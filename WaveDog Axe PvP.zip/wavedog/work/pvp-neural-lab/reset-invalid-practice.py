"""User-authorized reset of invalid WLab practice and contextual Qwen memory.

Only the named WaveDogPracticeLab runtime, its matching workspace outputs, and
WLab01A..WLab30B identities are removed. Human players and the main world stay.
"""
from pathlib import Path
import json
import re
import shutil
import socket
import sqlite3
import sys

workspace = Path('D:/CodexWorkspace/ban/work/pvp-neural-lab').resolve()
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server').resolve()
lab = (server / 'plugins/WaveDogPracticeLab').resolve()
jar = (server / 'plugins/WaveDogPracticeLab.jar').resolve()
assert lab == server / 'plugins/WaveDogPracticeLab'
assert jar == server / 'plugins/WaveDogPracticeLab.jar'
assert workspace == Path(__file__).resolve().parent
with socket.socket() as connection:
    if connection.connect_ex(('127.0.0.1', 25566)) == 0:
        raise SystemExit('Main server is running; refused to reset practice')

cache = server / 'usercache.json'
entries = json.loads(cache.read_text(encoding='utf-8'))
pattern = re.compile(r'WLab(?:0[1-9]|[12][0-9]|30)[AB]$')
bots = {entry['uuid'] for entry in entries if pattern.fullmatch(entry['name'])}
if len(bots) != 60:
    raise SystemExit(f'Expected 60 WLab identities, found {len(bots)}; refused broad cleanup')
player_files = []
for uuid in bots:
    for relative in (f'world/playerdata/{uuid}.dat', f'world/playerdata/{uuid}.dat_old',
                     f'world/stats/{uuid}.json', f'world/advancements/{uuid}.json'):
        item = (server / relative).resolve()
        assert item.is_relative_to(server / 'world')
        if item.exists():
            player_files.append(item)
workspace_dirs = [workspace / name for name in ('main-backups', 'main-console', 'source-backups',
                  'isolated-server', 'test-model-output', 'recurrent-seed')]
workspace_files = [workspace / name for name in ('main-install.json', 'main-model-verification.json',
                   'probe-result.json', 'whiff-probe-result.json', 'qwen-briefing-receipt.json',
                   'before-all-control-main-status.json', 'all-control-test-result.json',
                   'all-control-tests.log', 'research-notes.jsonl', 'shield-audit-1055.json',
                   'shield-audit-1100.json', 'coach-experience-library.json',
                   'coach-research-notes.txt', 'coach-briefing-core.txt', 'probe.args')]
for item in workspace_dirs + workspace_files:
    assert item.resolve().is_relative_to(workspace)

database = server / 'plugins/AuthMe/authme.db'
with sqlite3.connect(f'file:{database.as_posix()}?mode=ro', uri=True) as connection:
    auth_count = connection.execute("SELECT count(*) FROM authme WHERE realname GLOB 'WLab[0-9][0-9][AB]'").fetchone()[0]
if auth_count != 60:
    raise SystemExit(f'Expected 60 WLab AuthMe accounts, found {auth_count}; refused database cleanup')

report = {'main_server_stopped': True, 'invalid_bot_ids': len(bots),
          'invalid_bot_world_files': len(player_files), 'invalid_bot_auth_accounts': auth_count,
          'lab_runtime': str(lab), 'lab_jar': str(jar),
          'workspace_directories': [str(p) for p in workspace_dirs if p.exists()],
          'workspace_files': [str(p) for p in workspace_files if p.exists()],
          'human_accounts_preserved': ['WaveJerry', 'WaveDog', 'WaveDog2', 'jifengoqk']}
if '--execute' not in sys.argv:
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0)

if lab.exists():
    shutil.rmtree(lab)
jar.unlink(missing_ok=True)
for item in player_files:
    item.unlink()
cache.write_text(json.dumps([entry for entry in entries if entry['uuid'] not in bots], ensure_ascii=False), encoding='utf-8')
with sqlite3.connect(database) as connection:
    result = connection.execute("DELETE FROM authme WHERE realname GLOB 'WLab[0-9][0-9][AB]'")
    if result.rowcount != 60:
        raise RuntimeError(f'Unexpected AuthMe deletion count {result.rowcount}')
for item in workspace_dirs:
    if item.exists():
        shutil.rmtree(item)
for item in workspace_files:
    item.unlink(missing_ok=True)
report['status'] = 'DELETED'
(workspace / 'invalid-practice-reset.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
