"""Run model checks against a dedicated local Qwen slot, away from the live coach queue."""
from pathlib import Path
import os
import socket
import subprocess
import sys
import time
import urllib.request

base = Path(__file__).resolve().parent
port = 18766
with socket.socket() as check:
    if check.connect_ex(('127.0.0.1', port)) == 0:
        raise SystemExit('Test Qwen port already occupied')

runtime = base / 'model-runtime'
log = (runtime / 'test-server.log').open('ab')
process = subprocess.Popen([
    str(runtime / 'llama-server.exe'), '-m',
    str(runtime / 'qwen2.5-1.5b-instruct-q4_k_m.gguf'),
    '--host', '127.0.0.1', '--port', str(port), '-t', '4', '-tb', '4',
    '-c', '4096', '-np', '1', '--alias', 'wavedog-tactics', '--no-webui',
], cwd=runtime, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
log.close()

try:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(90):
        if process.poll() is not None:
            raise RuntimeError('Isolated Qwen exited before readiness')
        try:
            with opener.open(f'http://127.0.0.1:{port}/health', timeout=2) as response:
                if response.status == 200:
                    break
        except Exception:
            time.sleep(1)
    else:
        raise RuntimeError('Isolated Qwen readiness timed out')
    env = os.environ.copy()
    env['WAVEDOG_TEST_LLM_ENDPOINT'] = f'http://127.0.0.1:{port}/v1/chat/completions'
    subprocess.run([sys.executable, '-B', '-X', 'utf8',
                    str(base / 'validate-learning-models.py')],
                   env=env, check=True)
finally:
    if process.poll() is None:
        process.terminate()
        process.wait(timeout=30)
