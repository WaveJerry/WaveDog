"""Isolated Paper player-mechanics audit. No GRU, Qwen coach, or practice bouts run."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import secrets
import shutil
import socket
import subprocess
import time

base = Path(__file__).resolve().parent
main = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
test = base / 'player-baseline-server'
port, rcon_port = 25589, 25590
for value in (port, rcon_port):
    with socket.socket() as connection:
        if connection.connect_ex(('127.0.0.1', value)) == 0:
            raise SystemExit(f'Isolated port {value} already in use')
plugins = test / 'plugins'
plugins.mkdir(parents=True, exist_ok=True)
for name in ('CommandAPI.jar', 'ArrowSense.jar', 'fakeplayer.jar', 'PvPArenaAI.jar', 'AuthMe.jar'):
    shutil.copy2(main / 'plugins' / name, plugins / name)
candidate = base / 'WaveDogPracticeLab.jar'
shutil.copy2(candidate, plugins / candidate.name)
data = plugins / 'WaveDogPracticeLab'
data.mkdir(exist_ok=True)
old_config = data / 'config.yml'
built = old_config.exists() and 'built: true' in old_config.read_text(encoding='utf-8')
config = (base / 'config.yml').read_text(encoding='utf-8')
config = config.replace('auto-start: true', 'auto-start: false').replace('active-arenas: 30', 'active-arenas: 0')
config = config.replace('neural-enabled: true', 'neural-enabled: false').replace('llm-enabled: true', 'llm-enabled: false')
config = config.replace('built: false', f'built: {str(built).lower()}')
old_config.write_text(config, encoding='utf-8')
for name in ('home', 'tmp'):
    (test / name).mkdir(exist_ok=True)
secret = secrets.token_urlsafe(24)
(test / 'eula.txt').write_text('eula=true\n', encoding='ascii')
(test / 'server.properties').write_text(
    f'server-ip=127.0.0.1\nserver-port={port}\nonline-mode=false\n'
    f'enable-rcon=true\nrcon.port={rcon_port}\nrcon.password={secret}\n'
    'max-players=65\nspawn-protection=0\nview-distance=3\n'
    'simulation-distance=3\nlevel-type=minecraft:flat\n'
    'generate-structures=false\nspawn-monsters=false\nspawn-animals=false\n'
    'spawn-npcs=false\nallow-nether=false\n', encoding='ascii')
runtime_cp = os.pathsep.join(map(str, [main / 'versions/1.21.1/paper-1.21.1.jar',
                                     *sorted((main / 'libraries').rglob('*.jar'))]))
args = [str(main / 'runtime/java21/bin/java.exe'), '-Xms512M', '-Xmx3G',
        '-Duser.home=' + str(test / 'home'), '-Djava.io.tmpdir=' + str(test / 'tmp'),
        '-cp', runtime_cp, 'org.bukkit.craftbukkit.Main', '--nogui']
spec = importlib.util.spec_from_file_location('rcon', 'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
rcon.PROPERTIES = {'rcon.port': str(rcon_port), 'rcon.password': secret}
stamp = time.time()
receipt = {'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
           'main_server_modified': False, 'training_enabled': False, 'status': 'STARTING'}
log = (test / 'player-baseline-console.log').open('wb')
process = subprocess.Popen(args, cwd=test, stdin=subprocess.PIPE, stdout=log, stderr=subprocess.STDOUT)
print(f'PLAYER_BASELINE_PID={process.pid}', flush=True)
try:
    while time.time() - stamp < 300:
        if process.poll() is not None:
            raise RuntimeError('Isolated Paper exited early')
        movement_file = data / 'native-fairness-probe.json'
        combat_file = data / 'native-combat-probe.json'
        if movement_file.exists() and combat_file.exists() and combat_file.stat().st_mtime >= stamp:
            movement = json.loads(movement_file.read_text(encoding='utf-8'))
            combat = json.loads(combat_file.read_text(encoding='utf-8'))
            cases = {case['case']: case for case in combat['cases']}
            required = ('axe_disables_effective_shield',
                        'axe_disables_shield_during_hurt_invulnerability',
                        'back_facing_shield_does_not_disable', 'axe_whiff_resets_charge')
            if movement['status'] != 'PASS' or combat['status'] != 'PASS' or not all(cases.get(k, {}).get('pass') for k in required):
                raise RuntimeError('Native player baseline failed; inspect isolated probe files')
            receipt.update(status='PASS', movement=movement, combat_cases=cases,
                           completed_practice_rounds=0)
            break
        time.sleep(2)
    else:
        receipt.update(status='INCOMPLETE', reason='Native player baseline timed out')
except Exception as exc:
    receipt.update(status='FAIL', error=repr(exc))
finally:
    if process.poll() is None:
        try:
            rcon.command('save-all flush')
            rcon.command('stop')
        except Exception:
            process.stdin.write(b'stop\n')
            process.stdin.flush()
        process.wait(timeout=60)
    log.close()
    receipt['normal_exit_code'] = process.returncode
    receipt['elapsed_seconds'] = round(time.time() - stamp, 1)
    (base / 'player-baseline-result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ('movement', 'combat_cases')}, ensure_ascii=False), flush=True)
if receipt['status'] != 'PASS':
    raise SystemExit(1)
