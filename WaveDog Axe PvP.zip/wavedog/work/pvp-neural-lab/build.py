from pathlib import Path
import hashlib,json,os,subprocess,zipfile

base=Path(__file__).resolve().parent
server=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classes=base/'classes';classes.mkdir(exist_ok=True)
sources=sorted((base/'src').rglob('*.java'))+[base.parent/'pvp-lab/ReferenceDuelKit.java']
cp=os.pathsep.join(map(str,[server/'versions/1.21.1/paper-1.21.1.jar',*sorted((server/'libraries').rglob('*.jar')),server/'plugins/fakeplayer.jar',server/'plugins/AuthMe.jar']))
args=['-proc:none','-encoding','UTF-8','--release','21','-cp',cp,'-d',str(classes),*map(str,sources)]
argfile=base/'compile.args'
argfile.write_text('\n'.join('"'+a.replace('\\','\\\\').replace('"','\\"')+'"' for a in args),encoding='utf-8')
subprocess.run([str(server/'runtime/java21/bin/javac.exe'),'@'+str(argfile)],check=True)
out=base/'WaveDogPracticeLab.jar'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(classes.rglob('*.class')):z.write(p,p.relative_to(classes).as_posix())
    for name in ('plugin.yml','config.yml'):z.write(base/name,name)
report={'jar':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':{str(p.relative_to(base) if p.is_relative_to(base) else p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'main_server_modified':False,'llm_enabled':True,'neural_training':True,'visual_audio_input':False}
(base/'build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
