"""Send the user's concise research cards to the already-running local Qwen and record receipts.

The durable source of future coach context is the installed core note and experience
library. This HTTP acknowledgement alone does not change model weights or memory.
"""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone
from urllib.request import Request, urlopen

base = Path(__file__).resolve().parent
cards_file = base / 'coach-experience-library.json'
source_file = base / 'coach-reference-20261111.md'
cards = [c for c in json.loads(cards_file.read_text(encoding='utf-8'))['cards']
         if c['id'].startswith('brief-20261111-')]
if len(cards) != 18:
    raise SystemExit('Expected exactly 18 research briefing cards')
core = (base / 'coach-briefing-core.txt').read_text(encoding='utf-8').strip()
receipt = {'at': datetime.now(timezone.utc).isoformat(),
           'source_sha256': hashlib.sha256(source_file.read_bytes()).hexdigest(),
           'cards_sha256': hashlib.sha256(cards_file.read_bytes()).hexdigest(),
           'groups': []}
for offset in range(0, len(cards), 5):
    group = cards[offset:offset + 5]
    content = core + '\n本批经验卡：\n' + '\n'.join(
        f"{c['id']} [{c['focus']}] {c['summary']}" for c in group)
    body = {'model': 'wavedog-chat', 'messages': [
        {'role': 'system', 'content': '你是本地 Minecraft PvP 研究教练。以下是用户经验假设与历史修订。简短确认收到，勿声称已微调权重或已证明打法最强。'},
        {'role': 'user', 'content': content + '\n请指出本批的两个重点和一项仍需实战验证的点。'}],
        'temperature': 0.2, 'max_tokens': 140, 'stream': False}
    request = Request('http://127.0.0.1:18765/v1/chat/completions',
                      data=json.dumps(body, ensure_ascii=False).encode('utf-8'),
                      headers={'Content-Type': 'application/json'})
    try:
        with urlopen(request, timeout=75) as response:
            if response.status != 200:
                raise RuntimeError(f'HTTP {response.status}')
            result = json.loads(response.read().decode('utf-8'))
        answer = result['choices'][0]['message']['content'].strip()
        if not answer:
            raise RuntimeError('empty Qwen response')
        receipt['groups'].append({'ids': [c['id'] for c in group],
                                  'response': answer, 'delivered': True})
        print(f'QWEN_BRIEFING_DELIVERED group={offset // 5 + 1} cards={len(group)}', flush=True)
    except Exception as exc:
        receipt['groups'].append({'ids': [c['id'] for c in group],
                                  'delivered': False, 'error': repr(exc)})
        print(f'QWEN_BRIEFING_FAILED group={offset // 5 + 1} error={exc}', flush=True)
receipt['status'] = 'PASS' if all(g['delivered'] for g in receipt['groups']) else 'INCOMPLETE'
(base / 'qwen-briefing-receipt.json').write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': receipt['status'],
                  'groups_delivered': sum(g['delivered'] for g in receipt['groups']),
                  'cards_delivered': sum(len(g['ids']) for g in receipt['groups'] if g['delivered'])},
                 ensure_ascii=False), flush=True)
if receipt['status'] != 'PASS':
    raise SystemExit(1)
