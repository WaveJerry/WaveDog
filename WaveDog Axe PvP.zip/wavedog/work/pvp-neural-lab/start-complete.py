from pathlib import Path
import socket,subprocess,sys
b=Path(__file__).resolve().parent;s=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
subprocess.run([sys.executable,'-B','-X','utf8',str(b/'start-local-model.py')],check=True)
sock=socket.socket();running=sock.connect_ex(('127.0.0.1',25566))==0;sock.close()
if running:print('SERVER_ALREADY_RUNNING: preserved. Use /pvplab models to inspect live model status.')
else:
    subprocess.Popen(['cmd.exe','/d','/c',str(s/'start-server.cmd')],cwd=s,creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
    print('STARTED: main server and local model. Keep the server console open.')
