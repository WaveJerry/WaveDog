from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'src/local/wavedog/lab/LivePracticeLab.java';s=p.read_text(encoding='utf-8')
old='p.setRotation(a.yaw(),a.pitch());p.setSprinting(a.sprint());bridge.fromPlayer(p).setZza(a.forward());bridge.fromPlayer(p).setXxa(a.side());'
assert old in s;s=s.replace(old,'p.setRotation(a.yaw(),a.pitch());')
needle='if(a.jump()&&p.isOnGround())bridge.createAction(p,ActionType.JUMP,ActionSetting.once()).tick();'
assert needle in s;s=s.replace(needle,'if(a.attack()&&p.hasActiveItem())release.invoke(null,p);\n            ClientMovementInput.apply(p,bridge,a.forward(),a.side(),a.sprint());\n            '+needle)
s=s.replace('boolean aimed=enemy.player.getBoundingBox().rayTrace(p.getEyeLocation().toVector(),p.getEyeLocation().getDirection(),3)!=null;\n                if(reach<=3&&aimed&&p.hasLineOfSight(enemy.player))p.attack(enemy.player);', 'if(ClientMovementInput.canAttack(p,enemy.player))p.attack(enemy.player);')
s=s.replace('priorSprint=p.isSprinting();','priorSprint=p.isSprinting();')
# At least five slots are held for real/original players; open all30 arenas by default.
s=s.replace('int desired=18,','int desired=30,').replace('getInt("active-arenas",18)','getInt("active-arenas",30)').replace('Math.max(4,outsiders)','Math.max(5,outsiders)').replace(')):18;running=true', ')):30;running=true').replace('至少4个原服玩家名额','至少5个原服玩家名额')
p.write_text(s,encoding='utf-8')
p=b/'config.yml';p.write_text(p.read_text(encoding='utf-8').replace('active-arenas: 18','active-arenas: 30'),encoding='utf-8')
p=b/'install-and-start.py';s=p.read_text(encoding='utf-8').replace("'max-players=40'","'max-players=65'").replace("'max_players':40","'max_players':65").replace("'target_parallel_pairs':18","'target_parallel_pairs':30").replace('max players 40','max players 65').replace("cfg=cfg.replace('active-arenas: 30','active-arenas: 18')","cfg=cfg.replace('active-arenas: 18','active-arenas: 30')")
# Preserve the learned network and optimizer before replacing the laboratory jar.
s=s.replace("s/'plugins/WaveDogPracticeLab/config.yml',", "s/'plugins/WaveDogPracticeLab/config.yml',s/'plugins/WaveDogPracticeLab/models/footwork.json',")
p.write_text(s,encoding='utf-8')
p=b/'probe.py';s=p.read_text(encoding='utf-8').replace('max-players=40','max-players=65').replace(".replace('active-arenas: 18','active-arenas: 8')",".replace('active-arenas: 30','active-arenas: 8')");p.write_text(s,encoding='utf-8')
p=b/'tests/local/wavedog/lab/NeuralLabTests.java';s=p.read_text(encoding='utf-8');needle='        var llm=new TacticalModel(folder,'
addition='''        check(ClientMovementInput.resolve(1,0,false,false,false,20).forward()==1,"walk input");
        check(ClientMovementInput.resolve(1,0,true,false,false,20).sprint(),"normal sprint denied");
        var guard=ClientMovementInput.resolve(1,0,true,true,false,20);check(Math.abs(guard.forward()-.2)<1e-6&&!guard.sprint(),"shield sprint exploit");
        var crouch=ClientMovementInput.resolve(1,0,true,false,true,20);check(Math.abs(crouch.forward()-.3)<1e-6&&!crouch.sprint(),"crouch sprint exploit");
        var both=ClientMovementInput.resolve(1,0,true,true,true,20);check(Math.abs(both.forward()-.06)<1e-6&&!both.sprint(),"shield+crouch speed mismatch");
        check(!ClientMovementInput.resolve(-1,0,true,false,false,20).sprint(),"backward sprint");
        check(!ClientMovementInput.resolve(1,0,true,false,false,6).sprint(),"hungry sprint");
        check(ClientMovementInput.resolve(4,3,true,false,false,20).forward()==1,"unbounded input");
'''
assert needle in s;s=s.replace(needle,addition+needle);p.write_text(s,encoding='utf-8')
print('FAIR_INPUT_AND65_SLOTS_WIRED')
