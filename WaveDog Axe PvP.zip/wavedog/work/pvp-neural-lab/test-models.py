from pathlib import Path
import os,subprocess,time
b=Path(__file__).resolve().parent;s=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
cp=os.pathsep.join(map(str,[b/'classes',s/'versions/1.21.1/paper-1.21.1.jar',*sorted((s/'libraries').rglob('*.jar'))]))
tests=b/'test-classes';tests.mkdir(exist_ok=True)
subprocess.run([str(s/'runtime/java21/bin/javac.exe'),'-encoding','UTF-8','--release','21','-cp',cp,'-d',str(tests),str(b/'tests/local/wavedog/lab/NeuralLabTests.java')],check=True)
subprocess.run([str(s/'runtime/java21/bin/java.exe'),'-cp',str(tests)+os.pathsep+cp,'local.wavedog.lab.NeuralLabTests',str(b/'test-model-output'/str(int(time.time()))),str(b/'coach-experience-library.json')],check=True,timeout=100)
subprocess.run([str(s/'runtime/java21/bin/javac.exe'),'-proc:none','-encoding','UTF-8','--release','21','-cp',cp,'-d',str(tests),str(b/'tests/local/wavedog/lab/RecurrentPpoTests.java')],check=True)
subprocess.run([str(s/'runtime/java21/bin/java.exe'),'-cp',str(tests)+os.pathsep+cp,'local.wavedog.lab.RecurrentPpoTests','test',str(b/'test-model-output'/('ppo-'+str(int(time.time())))),str(b/'recurrent-seed')],check=True,timeout=100)
