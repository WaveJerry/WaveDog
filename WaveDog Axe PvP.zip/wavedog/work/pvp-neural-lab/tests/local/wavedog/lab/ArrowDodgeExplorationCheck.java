package local.wavedog.lab;

/** Lateral jump research requires an approaching public projectile. */
public final class ArrowDodgeExplorationCheck {
    static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args){
        double[] x=new double[RecurrentPpoCombat.F];
        x[31]=1;x[92]=1;x[2]=1;
        x[32]=Math.tanh(5./12);x[33]=Math.tanh(1.3/6.);x[35]=-1./4;
        check(RecurrentPpoCombat.explorationPrior(x,0,3)>0,"left sidestep sampled");
        check(RecurrentPpoCombat.explorationPrior(x,0,4)>0,"right sidestep sampled");
        check(RecurrentPpoCombat.explorationPrior(x,2,1)>0,"side jump sampled");
        x[35]=1./4;
        check(RecurrentPpoCombat.explorationPrior(x,2,1)==0,"outgoing arrow is not incoming threat");
        x[35]=-1./4;x[92]=0;
        check(RecurrentPpoCombat.explorationPrior(x,2,1)==0,"other focuses retain policy");
        System.out.println("ARROW_DODGE_EXPLORATION_PASS public incoming projectile only");
    }
}
