package local.wavedog.lab;

/** Public projectile trajectory must distinguish collision from a safe pass. */
public final class ArrowDodgePredictionCheck {
    static void check(boolean yes,String message){if(!yes)throw new AssertionError(message);}
    public static void main(String[] args){
        double[] x=new double[RecurrentPpoCombat.F];x[31]=1;x[2]=1;
        x[32]=Math.tanh(3.0/12);x[33]=Math.tanh(1.0/6);
        x[34]=Math.tanh(.3/12);x[35]=-.25;
        check(RecurrentPpoCombat.predictedArrowDodgeSide(x)==3,"left dodge not predicted");
        x[34]=Math.tanh(-.3/12);
        check(RecurrentPpoCombat.predictedArrowDodgeSide(x)==4,"right dodge not predicted");
        x[34]=Math.tanh(4.0/12);
        check(RecurrentPpoCombat.predictedArrowDodgeSide(x)==0,"safe lateral pass marked dangerous");
        x[34]=0;x[33]=Math.tanh(5.0/6);
        check(RecurrentPpoCombat.predictedArrowDodgeSide(x)==0,"high arrow marked dangerous");
        System.out.println("ARROW_DODGE_PREDICTION_PASS public 3D trajectory and side choice");
    }
}
