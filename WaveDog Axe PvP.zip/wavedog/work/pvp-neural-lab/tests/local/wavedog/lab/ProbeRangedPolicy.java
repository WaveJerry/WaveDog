package local.wavedog.lab;
import java.nio.file.Path;
import java.util.*;

public final class ProbeRangedPolicy {
    public static void main(String[] args)throws Exception{
        try(var model=new RecurrentPpoCombat(Path.of(args[0]))){
            var cell=ArenaLayout.cells().getFirst();
            for(var focus:List.of(ExperienceLibrary.Focus.BOW,ExperienceLibrary.Focus.CROSSBOW)){
                var self=new DuelPolicy.Self(cell.cx(),221,cell.cz()-12,222.62,0,0,0,true,false,1,20,true,false,5,false,false,0,7);
                var seen=new DuelPolicy.Seen(1,1,true,cell.cx(),221,cell.cz()+12,180,false,"DIAMOND_AXE",false,0,List.of());
                double[] x=CombatLearner.features(self,seen,cell,DuelPolicy.Style.RANGED,0,0,1,new double[12]);
                CombatLearner.conditionOnFocus(x,focus);
                var frame=RecurrentPpoCombat.forward(model.state.w,x,new double[RecurrentPpoCombat.H]);
                int slot=focus==ExperienceLibrary.Focus.BOW?2:3;
                System.out.printf(Locale.ROOT,"%s far=%.3f slot=%.8f use=%.8f joint=%.10f attack=%.8f%n",
                    focus,Math.max(Math.abs(x[18]),Math.abs(x[20])),frame.p[CombatLearner.OFF[5]+slot],
                    frame.p[CombatLearner.OFF[4]+3],frame.p[CombatLearner.OFF[5]+slot]*frame.p[CombatLearner.OFF[4]+3],
                    frame.p[CombatLearner.OFF[4]+2]);
            }
            for(float charge:new float[]{.3f,.55f,.7f,.85f,1f}){
                var self=new DuelPolicy.Self(cell.cx(),221,cell.cz(),222.62,0,0,0,true,false,charge,20,true,false,5,false,false,0,7);
                var seen=new DuelPolicy.Seen(1,1,true,cell.cx(),221,cell.cz()+2,180,false,"DIAMOND_AXE",false,0,List.of());
                double[] x=CombatLearner.features(self,seen,cell,DuelPolicy.Style.AGGRESSIVE,0,0,1,new double[12]);
                var frame=RecurrentPpoCombat.forward(model.state.w,x,new double[RecurrentPpoCombat.H]);
                System.out.printf(Locale.ROOT,"MELEE charge=%.2f attack=%.5f hold=%.5f%n",charge,
                    frame.p[CombatLearner.OFF[4]+2],frame.p[CombatLearner.OFF[4]]);
            }
        }
    }
}
