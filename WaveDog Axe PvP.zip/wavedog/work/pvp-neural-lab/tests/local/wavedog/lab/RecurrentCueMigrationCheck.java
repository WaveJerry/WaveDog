package local.wavedog.lab;

import java.nio.file.*;
import java.util.*;

/** Verify exact preservation of every old GRU64 and Adam parameter. */
public final class RecurrentCueMigrationCheck {
    static void check(boolean yes,String message){if(!yes)throw new AssertionError(message);}
    static void checkArray(double[] old,double[] newer,int sourceF){
        int sourceStride=sourceF+RecurrentPpoCombat.H+1;
        int sourceGate=RecurrentPpoCombat.H*sourceStride;
        int sourcePolicy=3*sourceGate;
        for(int gate=0;gate<3;gate++)for(int neuron=0;neuron<RecurrentPpoCombat.H;neuron++){
            int from=gate*sourceGate+neuron*sourceStride;
            int to=gate*RecurrentPpoCombat.GATE+neuron*RecurrentPpoCombat.STRIDE;
            for(int k=0;k<sourceF;k++)
                check(old[from+k]==newer[to+k],"old public feature changed");
            for(int k=sourceF;k<RecurrentPpoCombat.F;k++)
                check(newer[to+k]==0,"new input not neutral");
            for(int k=0;k<=RecurrentPpoCombat.H;k++)
                check(old[from+sourceF+k]
                    ==newer[to+RecurrentPpoCombat.F+k],"hidden or bias changed");
        }
        for(int k=0;k<old.length-sourcePolicy;k++)
            check(old[sourcePolicy+k]
                ==newer[RecurrentPpoCombat.POLICY+k],"policy or critic changed");
    }
    static void checkMigration(int sourceF)throws Exception {
        Path folder=Files.createTempDirectory("gru-input-migration-check-");
        var old=new RecurrentPpoCombat.State();
        int sourceN=3*RecurrentPpoCombat.H*(sourceF+RecurrentPpoCombat.H+1)
            +CombatLearner.O*(RecurrentPpoCombat.H+1)+RecurrentPpoCombat.H+1;
        old.w=new double[sourceN];old.m=old.w.clone();old.v=old.w.clone();
        for(int i=0;i<old.w.length;i++){
            old.w[i]=i*.001;old.m[i]=i*.002;old.v[i]=i*.003;
        }
        old.updates=12345;old.episodes=678;old.samples=99999;old.optimizerSteps=888;
        Files.writeString(folder.resolve("recurrent-ppo.json"),RecurrentPpoCombat.JSON.toJson(old));
        try(var model=new RecurrentPpoCombat(folder)){
            var newer=model.state;
            check(newer.updates==old.updates&&newer.episodes==old.episodes
                &&newer.samples==old.samples&&newer.optimizerSteps==old.optimizerSteps,
                "training counters changed");
            checkArray(old.w,newer.w,sourceF);checkArray(old.m,newer.m,sourceF);
            checkArray(old.v,newer.v,sourceF);
            check(Files.list(folder).anyMatch(p->p.getFileName().toString()
                .startsWith("recurrent-ppo.before-reach-margin-")),"old file not backed up");
        }
    }
    public static void main(String[] args)throws Exception {
        checkMigration(RecurrentPpoCombat.OLD_F);
        checkMigration(RecurrentPpoCombat.CUE_F);
        System.out.println("RECURRENT_CUE_MIGRATION_PASS 96/97 inputs, weights and Adam retained");
    }
}
