package local.wavedog.lab;

import java.nio.file.Path;

/** Read-only diagnostic of the shared checkpoint's conditional hotbar odds. */
public final class ResearchPolicyProbe {
    public static void main(String[] args)throws Exception {
        try(var model=new RecurrentPpoCombat(Path.of(args[0]))){
            double[] x=new double[RecurrentPpoCombat.F];
            x[0]=1;x[1]=.95;x[2]=1;x[6]=1;x[12]=7./8;
            x[18]=.3;x[31]=1;x[89]=1;
            var f=RecurrentPpoCombat.forward(model.state.w,x,new double[RecurrentPpoCombat.H]);
            System.out.printf("updates=%d sword=%.6f axe=%.6f swordPrior=%.2f%n",
                model.state.updates,f.p[CombatLearner.OFF[5]+1],
                f.p[CombatLearner.OFF[5]],RecurrentPpoCombat.explorationPrior(x,5,1));
        }
    }
}
