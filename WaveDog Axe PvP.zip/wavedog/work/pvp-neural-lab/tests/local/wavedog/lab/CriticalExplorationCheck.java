package local.wavedog.lab;

/** Research priors broaden sampled actions only under public tactical conditions. */
public final class CriticalExplorationCheck {
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        double[] x=new double[RecurrentPpoCombat.F];
        x[31]=1;x[84]=1;x[2]=1;x[1]=.95;x[18]=.6;
        check(RecurrentPpoCombat.explorationPrior(x,2,1)>0,"jump-in sampling");
        check(RecurrentPpoCombat.explorationPrior(x,1,1)>0,
            "entry jump includes forward sprint sampling");
        x[23]=1;check(RecurrentPpoCombat.explorationPrior(x,2,1)==0,"do not jump blindly into shield");
        x[23]=0;x[84]=0;check(RecurrentPpoCombat.explorationPrior(x,2,1)==0,"no general jump override");
        x[84]=1;x[18]=0;x[20]=.6;
        check(RecurrentPpoCombat.explorationPrior(x,2,1)>0,
            "jump-in sampling is bearing invariant");
        x[20]=.3;
        check(RecurrentPpoCombat.explorationPrior(x,2,1)>0,
            "ordinary close-range critical also receives research sampling");
        x[84]=0;x[20]=0;
        x[18]=.4;x[19]=.2;x[61]=.3;x[82]=1;x[6]=1;
        check(RecurrentPpoCombat.explorationPrior(x,4,1)>0,"shield against falling threat");
        x[82]=0;x[85]=1;check(RecurrentPpoCombat.explorationPrior(x,4,2)>0,"first hit against falling threat");
        double fallingPrior=RecurrentPpoCombat.explorationPrior(x,4,2);
        x[61]=.1;check(RecurrentPpoCombat.explorationPrior(x,4,2)<fallingPrior,
            "falling threat should add to ordinary attack sampling");
        x=new double[RecurrentPpoCombat.F];x[31]=1;x[89]=1;x[1]=.95;x[18]=.3;
        check(RecurrentPpoCombat.explorationPrior(x,5,1)>0,
            "unshielded COMBO focus samples sword slot");
        x[23]=1;check(RecurrentPpoCombat.explorationPrior(x,5,1)==0,
            "shielded target should not trigger sword tempo exploration");
        x[23]=0;x[18]=0;x[20]=.3;
        check(RecurrentPpoCombat.explorationPrior(x,5,1)>0,
            "sword sampling is independent of world-axis orientation");
        System.out.println("CRITICAL_EXPLORATION_PASS conditional probability only");
    }
}
