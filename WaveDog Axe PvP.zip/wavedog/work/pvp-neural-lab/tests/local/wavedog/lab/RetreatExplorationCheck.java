package local.wavedog.lab;

/** The research prior changes odds only in a visible, post-swing ESCAPE state. */
public final class RetreatExplorationCheck {
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        double[] x=new double[RecurrentPpoCombat.F];x[31]=1;x[86]=1;x[18]=.12;x[1]=.2;
        check(RecurrentPpoCombat.explorationPrior(x,0,2)>0,"close retreat sampling");
        check(RecurrentPpoCombat.explorationPrior(x,1,1)>0,"sprint sampling");
        x[1]=.9;check(RecurrentPpoCombat.explorationPrior(x,0,2)==0,"no pre-swing retreat");
        x[1]=.2;x[86]=0;check(RecurrentPpoCombat.explorationPrior(x,0,2)==0,"no broad style override");
        x[86]=1;x[8]=1;check(RecurrentPpoCombat.explorationPrior(x,0,2)==0,"using shield retains native slowdown");
        x[8]=0;x[18]=0;x[20]=.12;
        check(RecurrentPpoCombat.explorationPrior(x,0,2)>0,
            "retreat sampling is independent of world-axis orientation");
        x[78]=.5;check(RecurrentPpoCombat.explorationPrior(x,0,2)==0,
            "back input is not sampled while facing far away from opponent");
        System.out.println("RETREAT_EXPLORATION_PASS conditional probability only");
    }
}
