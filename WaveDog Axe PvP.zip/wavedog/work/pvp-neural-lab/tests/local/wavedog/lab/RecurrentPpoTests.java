package local.wavedog.lab;
import java.nio.file.*;
import java.util.*;

public final class RecurrentPpoTests {
    static int checks;
    static void check(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    static int[] action={1,1,1,0,2,0,7,2,1};
    static double objective(double[] w,double[] x,double[] next,double[] previous){var a=RecurrentPpoCombat.forward(w,x,previous);var b=RecurrentPpoCombat.forward(w,next,a.h);return .7*RecurrentPpoCombat.logProbability(b.p,action)+.2*b.value;}
    public static void main(String[] args)throws Exception{
        Path folder=Path.of(args[1]);Files.createDirectories(folder);
        if(args[0].equals("prepare")){
            var source=CombatLearner.JSON.fromJson(Files.readString(Path.of(args[2])),CombatLearner.State.class);CombatLearner.validate(source);
            long start=System.nanoTime();try(var network=new RecurrentPpoCombat(folder)){network.warmStart(source.w,6000,8);System.out.println("RECURRENT_SEED_PREPARED parameters="+RecurrentPpoCombat.N+" examples="+network.state.bootstrapExamples+" seconds="+(System.nanoTime()-start)/1e9);}return;
        }
        var network=new RecurrentPpoCombat(folder);Random random=new Random(22116);double[] w=network.state.w.clone(),x=new double[RecurrentPpoCombat.F],next=new double[x.length],previous=new double[RecurrentPpoCombat.H];
        for(int i=0;i<x.length;i++){x[i]=random.nextGaussian()*.4;next[i]=random.nextGaussian()*.3;}for(int i=0;i<previous.length;i++)previous[i]=random.nextGaussian()*.2;
        for(int i=RecurrentPpoCombat.VALUE;i<w.length;i++)w[i]=random.nextGaussian()*.04;
        var a=RecurrentPpoCombat.forward(w,x,previous);var b=RecurrentPpoCombat.forward(w,next,a.h);double[] logits=new double[CombatLearner.O];
        double[] ranged=x.clone();Arrays.fill(ranged,80,96,0);ranged[31]=1;ranged[18]=.9;ranged[10]=1;ranged[90]=1;
        var plain=RecurrentPpoCombat.forward(w,ranged,previous);
        ranged[90]=0;ranged[91]=1;
        var cross=RecurrentPpoCombat.forward(w,ranged,previous);
        check(RecurrentPpoCombat.rangedMix(ranged,5)>.4&&RecurrentPpoCombat.rangedMix(ranged,4)>.5,"crossbow exploration missing");
        double previousCharge=ranged[11];ranged[18]=.56;ranged[11]=1;
        check(RecurrentPpoCombat.rangedTarget(ranged,4)<0,"old close policy gained ranged override");
        ranged[11]=0;check(RecurrentPpoCombat.rangedTarget(ranged,4)<0,"empty crossbow treated as instant shot");
        ranged[18]=.9;ranged[11]=previousCharge;
        double[] spacing=new double[RecurrentPpoCombat.F];spacing[31]=1;spacing[18]=.45;spacing[1]=.2;spacing[86]=1;
        check(RecurrentPpoCombat.explorationPrior(spacing,0,2)==0,"old close policy gained forced exit");
        check(RecurrentPpoCombat.explorationPrior(spacing,4,1)<0,"unavailable shield was encouraged");
        spacing[6]=1;spacing[31]=1;spacing[18]=.35;spacing[1]=.4;
        check(RecurrentPpoCombat.explorationPrior(spacing,4,1)>0,"nearby threat did not reopen shield exploration");
        spacing[8]=1;spacing[7]=0;
        check(RecurrentPpoCombat.explorationPrior(spacing,4,1)>9,"shield request was released before the native 0.25 second activation");
        spacing[8]=0;spacing[2]=0;
        check(RecurrentPpoCombat.explorationPrior(spacing,2,1)<-9,"airborne jump request stayed saturated");
        check(cross.p[CombatLearner.OFF[5]+3]>0&&cross.p[CombatLearner.OFF[5]+3]<1,"ranged prior forced one action");
        check(cross.p[CombatLearner.OFF[5]+3]>.44&&cross.p[CombatLearner.OFF[4]+3]>.54,"ranged action still unreachable");
        int useAt=CombatLearner.OFF[4]+3;double[] mixedLogits=new double[CombatLearner.O],mixedGrad=new double[w.length];
        double mixedFactor=(1-cross.mixture[4])*cross.baseP[useAt]/cross.p[useAt];
        for(int k=0;k<CombatLearner.WIDTH[4];k++){int at=CombatLearner.OFF[4]+k;
            mixedLogits[at]=mixedFactor*((k==3?1:0)-cross.baseP[at]);}
        RecurrentPpoCombat.backward(w,cross,mixedLogits,0,new double[RecurrentPpoCombat.H],mixedGrad);
        int mixedIndex=RecurrentPpoCombat.POLICY+useAt*(RecurrentPpoCombat.H+1)+RecurrentPpoCombat.H;
        double oldMixed=w[mixedIndex],mixedEps=1e-5;
        w[mixedIndex]=oldMixed+mixedEps;double mixedPlus=Math.log(RecurrentPpoCombat.forward(w,ranged,previous).p[useAt]);
        w[mixedIndex]=oldMixed-mixedEps;double mixedMinus=Math.log(RecurrentPpoCombat.forward(w,ranged,previous).p[useAt]);
        w[mixedIndex]=oldMixed;check(Math.abs((mixedPlus-mixedMinus)/(2*mixedEps)-mixedGrad[mixedIndex])<1e-5,"ranged mixture PPO gradient wrong");
        ranged[91]=0;check(RecurrentPpoCombat.rangedMix(ranged,5)==0,"ranged prior escaped its curriculum focus");
        ranged[0]=1;ranged[17]=.01;check(RecurrentPpoCombat.rangedMix(ranged,5)>.1&&RecurrentPpoCombat.rangedMix(ranged,5)<.5,"opening ranged choice was forced or unavailable");
        ranged[17]=.05;check(RecurrentPpoCombat.rangedMix(ranged,5)==0,"opening ranged exploration persisted beyond five seconds");
        ranged[0]=.2;ranged[18]=.3;ranged[20]=0;
        for(int edge=56;edge<60;edge++)ranged[edge]=.5;
        check(RecurrentPpoCombat.rangedTarget(ranged,0)==2&&RecurrentPpoCombat.rangedMix(ranged,0)==.30,"low-health retreat choice missing");
        ranged[56]=0;check(RecurrentPpoCombat.rangedMix(ranged,0)==0,"retreat exploration ignored arena edge");
        double[] finishInput=ranged.clone();finishInput[31]=1;finishInput[18]=.3;finishInput[20]=0;finishInput[1]=.7;
        var noFinish=RecurrentPpoCombat.forward(w,finishInput,previous,0);
        var likelyFinish=RecurrentPpoCombat.forward(w,finishInput,previous,7);
        check(likelyFinish.p[CombatLearner.OFF[4]+2]>noFinish.p[CombatLearner.OFF[4]+2],"public hurt evidence failed to raise early finish chance");
        check(RecurrentPpoCombat.finisherBias(finishInput,6,4,2)==0,"finisher used too little visible evidence");
        finishInput[31]=0;check(RecurrentPpoCombat.finisherBias(finishInput,7,4,2)==0,"finisher used invisible target");
        for(int h=0;h<action.length;h++)for(int k=0;k<CombatLearner.WIDTH[h];k++){int at=CombatLearner.OFF[h]+k;logits[at]=.7*((k==action[h]?1:0)-b.p[at]);}
        double[] grad=new double[w.length];double[] carry=RecurrentPpoCombat.backward(w,b,logits,.2,new double[RecurrentPpoCombat.H],grad);RecurrentPpoCombat.backward(w,a,new double[CombatLearner.O],0,carry,grad);
        for(int index:new int[]{0,31,96,120,160,2000,RecurrentPpoCombat.GATE,RecurrentPpoCombat.GATE+96,RecurrentPpoCombat.GATE+160,2*RecurrentPpoCombat.GATE,2*RecurrentPpoCombat.GATE+97,2*RecurrentPpoCombat.GATE+160,RecurrentPpoCombat.POLICY,RecurrentPpoCombat.POLICY+100,RecurrentPpoCombat.VALUE,RecurrentPpoCombat.VALUE+64}){
            double value=w[index],eps=1e-5;w[index]=value+eps;double plus=objective(w,x,next,previous);w[index]=value-eps;double minus=objective(w,x,next,previous);w[index]=value;double numerical=(plus-minus)/(2*eps);check(Math.abs(numerical-grad[index])<1e-5,"GRU/BPTT gradient wrong at"+index+" actual="+grad[index]+" numerical="+numerical);
        }
        for(int h=0;h<action.length;h++){double total=0;for(int k=0;k<CombatLearner.WIDTH[h];k++)total+=b.p[CombatLearner.OFF[h]+k];check(Math.abs(total-1)<1e-10,"recurrent policy head not normalized");}
        check(RecurrentPpoCombat.clippedPolicyCoefficient(1,1.3)==0,"positive PPO advantage escaped clipping");check(RecurrentPpoCombat.clippedPolicyCoefficient(-1,.7)==0,"negative PPO advantage escaped clipping");check(RecurrentPpoCombat.clippedPolicyCoefficient(1,.9)==.9,"allowed PPO update wrongly blocked");
        int possible=240-RecurrentPpoCombat.SEQUENCE+1;for(int segment=0;segment<8;segment++){int start=RecurrentPpoCombat.sequenceStart(random,240,segment,8);check(start>=segment*possible/8&&start<(segment+1)*possible/8,"PPO sampled outside its trajectory stratum");}
        check(RecurrentPpoCombat.sequenceStart(random,1,0,1)==0,"short rollout sampling skipped its only frame");
        var first=new RecurrentPpoCombat.Sample(1,a,action);var second=new RecurrentPpoCombat.Sample(2,b,action);first.reward=.1;second.reward=1;var trajectory=new ArrayList<RecurrentPpoCombat.Sample>(List.of(first,second));RecurrentPpoCombat.advantages(trajectory,0);check(Math.abs(second.target-1)<1e-9,"terminal value bootstrapped after death");check(Double.isFinite(first.target),"GAE nonfinite");
        check(!Arrays.equals(RecurrentPpoCombat.forward(w,next,new double[RecurrentPpoCombat.H]).h,b.h),"GRU forgot all previous state");
        var cell=ArenaLayout.cells().getFirst();var self=new DuelPolicy.Self(cell.cx(),221,cell.cz(),222.62,0,0,0,true,false,.1f,20,true,false,5,false,false,0,7);var seen=new DuelPolicy.Seen(1,1,true,cell.cx(),221,cell.cz()+4,180,false,"DIAMOND_AXE",false,0,List.of());
        var learner=network.actor(121,true);var frozen=network.actor(122,false);double[] before=network.state.w.clone();
        for(int t=0;t<100;t++){learner.act(t,t,self,seen,cell,DuelPolicy.Style.MIXED,0,0);frozen.act(t,t,self,seen,cell,DuelPolicy.Style.MIXED,0,0);if(t%10==0)learner.outcomeFeedback(.5,.1);}
        var last=learner.episode.getLast();
        check(!last.executedHeads[4],"unacknowledged input was treated as executed");
        learner.executed(99,Set.of(4,6,7));
        check(last.executedHeads[0]&&!last.executedHeads[4]&&!last.executedHeads[6]&&!last.executedHeads[7],"PPO head masking ignored the real client input");
        check(Double.isFinite(last.executedLogp())&&Math.abs(last.executedLogp()-last.logp)>1e-6,"ignored heads remained in PPO likelihood");
        double reward=last.reward;learner.attackOutcome(99,.1,true,false);check(last.reward==reward,"successful light hit forbidden");learner.attackOutcome(99,1,false,false);check(Math.abs(last.reward-(reward-.003))<1e-10,"ineffective full-charge swing not measured");learner.attackOutcome(99,.1,false,true);check(Math.abs(last.reward-(reward+.017))<1e-10,"real shield disable not credited");learner.attackOutcome(99,1,false,false,true);check(Math.abs(last.reward-(reward+.011))<1e-10&&network.whiffAttempts.get()==1,"whiff feedback or counting missing");
        learner.beginInput(98);learner.outcomeFeedback(1,0);check(learner.executing==learner.sample(98),"delayed input credited to wrong decision");learner.endInput();check(frozen.episode.isEmpty(),"frozen opponent accumulated training rollouts");
        learner.finish(true,8);network.close();check(network.state.updates>0&&network.state.episodes==1,"PPO did not train a completed bout");check(!Arrays.equals(before,network.state.w),"PPO weights unchanged");check(Arrays.equals(before,learner.weights),"ongoing actor's frozen policy changed");check(network.state.lastKl>=0&&Double.isFinite(network.state.lastValueLoss),"invalid PPO diagnostics");
        try(var reloaded=new RecurrentPpoCombat(folder)){check(reloaded.state.episodes==1,"recurrent checkpoint did not resume");}
        if(args.length>2){try(var seed=new RecurrentPpoCombat(Path.of(args[2]))){
            check(seed.state.bootstrapExamples==6000,"warm start mistaken for actual matches");
            for(float pitch:new float[]{-80,-30,0,30,80}){double[] h=new double[RecurrentPpoCombat.H];float yaw=0,p=pitch;for(int t=0;t<60;t++){double[] features=CombatLearner.features(self,seen,cell,DuelPolicy.Style.GROUND_COMBO,yaw,p,t,new double[12]);var frame=RecurrentPpoCombat.forward(seed.state.w,features,h);h=frame.h;int[] chosen=new int[CombatLearner.WIDTH.length];for(int head=0;head<chosen.length;head++)for(int k=1;k<CombatLearner.WIDTH[head];k++)if(frame.p[CombatLearner.OFF[head]+k]>frame.p[CombatLearner.OFF[head]+chosen[head]])chosen[head]=k;var input=CombatLearner.decode(t,t,self,yaw,p,chosen);yaw=input.yaw();p=input.pitch();}System.out.println("RECURRENT_CLOSED_LOOP_LOOK start="+pitch+" end="+p+" yaw="+yaw);check(Math.abs(p-8.81)<35&&Math.abs(CombatLearner.wrap(yaw))<35,"warm recurrent policy looks away from opponent");}
            double[] h=new double[RecurrentPpoCombat.H];long begin=System.nanoTime();for(int i=0;i<3000;i++)h=RecurrentPpoCombat.forward(seed.state.w,x,h).h;double ms=(System.nanoTime()-begin)/1e6;System.out.println("RECURRENT_CPU_BENCH frames=3000 elapsed_ms="+ms+" cpu_ms_per_60bots_second="+(ms/3000*1200));check(ms/3000*1200<500,"60-bot recurrent inference exceeds half a CPU second per server second");
        }}
        System.out.println("RECURRENT_PPO_TESTS_PASS checks="+checks+" parameters="+RecurrentPpoCombat.N);
    }
}
