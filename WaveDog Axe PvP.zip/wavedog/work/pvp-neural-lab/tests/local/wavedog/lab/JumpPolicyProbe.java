package local.wavedog.lab;
import java.nio.file.Path;

/** Read-only diagnostic for the deployed GRU jump and shield action heads. */
public final class JumpPolicyProbe {
    public static void main(String[] args) throws Exception {
        try (var network = new RecurrentPpoCombat(Path.of(args[0]))) {
            var cell = ArenaLayout.cells().getFirst();
            for (double distance : new double[]{1.8, 2.6, 3.1, 5.0}) {
                for (boolean ground : new boolean[]{true, false}) {
                    double[] hidden = new double[RecurrentPpoCombat.H];
                    double jump = 0, shield = 0;
                    for (int tick = 0; tick < 80; tick++) {
                        var self = new DuelPolicy.Self(cell.cx(), 221, cell.cz(), 222.62,
                            0, ground ? 0 : -.2, 0, ground, !ground, .9f, 14,
                            true, false, 0, false, false, 0, 7);
                        var seen = new DuelPolicy.Seen(tick, tick, true, cell.cx(),
                            221, cell.cz() + distance, 180, false,
                            "DIAMOND_AXE", false, tick, java.util.List.of());
                        var x = CombatLearner.features(self, seen, cell,
                            DuelPolicy.Style.AGGRESSIVE, 0, 0, tick, new double[12]);
                        var frame = RecurrentPpoCombat.forward(network.state.w, x, hidden);
                        hidden = frame.h;
                        if (tick >= 20) {
                            jump += frame.p[CombatLearner.OFF[2] + 1];
                            shield += frame.p[CombatLearner.OFF[4] + 1];
                        }
                    }
                    System.out.printf("distance=%.1f ground=%s jump_p=%.5f shield_p=%.8f%n",
                        distance, ground, jump / 60, shield / 60);
                }
            }
            for(int useTicks:new int[]{1,3,5,8,18}){
                var self=new DuelPolicy.Self(cell.cx(),221,cell.cz(),222.62,
                    0,0,0,true,false,.5f,14,true,useTicks>=5,0,false,true,useTicks,7);
                var seen=new DuelPolicy.Seen(1,1,true,cell.cx(),221,cell.cz()+2.6,
                    180,false,"DIAMOND_AXE",false,1,java.util.List.of());
                var x=CombatLearner.features(self,seen,cell,DuelPolicy.Style.AGGRESSIVE,
                    0,0,1,new double[12]);
                var f=RecurrentPpoCombat.forward(network.state.w,x,new double[RecurrentPpoCombat.H]);
                System.out.printf("shield_use_ticks=%d shield_p=%.6f%n",useTicks,
                    f.p[CombatLearner.OFF[4]+1]);
            }
        }
    }
}
