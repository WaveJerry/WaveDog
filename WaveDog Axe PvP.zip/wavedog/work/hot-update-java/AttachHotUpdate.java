import com.sun.tools.attach.VirtualMachine;

public final class AttachHotUpdate {
    public static void main(String[] arguments) throws Exception {
        var vm = VirtualMachine.attach(arguments[0]);
        try { vm.loadAgent(arguments[1], arguments[2]); }
        finally { vm.detach(); }
    }
}
