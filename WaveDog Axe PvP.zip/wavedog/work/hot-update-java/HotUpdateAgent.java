import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.security.MessageDigest;
import java.util.HexFormat;

/** Redefines one explicitly named, already-loaded class without plugin reload. */
public final class HotUpdateAgent {
    public static void agentmain(String argument, Instrumentation instrumentation) throws Exception {
        var options = new Properties();
        try (var reader = Files.newBufferedReader(Path.of(argument))) { options.load(reader); }
        String name = options.getProperty("class");
        Class<?> selected = null;
        for (Class<?> candidate : instrumentation.getAllLoadedClasses()) {
            if (!candidate.getName().equals(name)) continue;
            if (selected != null) throw new IllegalStateException("Ambiguous loaded class " + name);
            selected = candidate;
        }
        if (selected == null || !instrumentation.isRedefineClassesSupported()
                || !instrumentation.isModifiableClass(selected))
            throw new IllegalStateException("Class cannot be redefined: " + name);
        byte[] bytes = Files.readAllBytes(Path.of(options.getProperty("bytes")));
        instrumentation.redefineClasses(new ClassDefinition(selected, bytes));
        String sha = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        Files.writeString(Path.of(options.getProperty("receipt")),
            "{\"pid\":" + ProcessHandle.current().pid() + ",\"class\":\"" + name
            + "\",\"sha256\":\"" + sha + "\",\"redefined\":true,\"serverRestarted\":false}\n");
        String install = options.getProperty("installPlugin");
        if (install != null) {
            ClassLoader loader = selected.getClassLoader();
            Class<?> bukkit = Class.forName("org.bukkit.Bukkit", true, loader);
            Class<?> pluginClass = Class.forName("org.bukkit.plugin.Plugin", true, loader);
            Object manager = bukkit.getMethod("getPluginManager").invoke(null);
            Object owner = manager.getClass().getMethod("getPlugin", String.class).invoke(manager, "PvPArenaAI");
            Object scheduler = bukkit.getMethod("getScheduler").invoke(null);
            Runnable load = () -> {
                try {
                    Object plugin = manager.getClass().getMethod("loadPlugin", java.io.File.class)
                        .invoke(manager, new java.io.File(install));
                    manager.getClass().getMethod("enablePlugin", pluginClass).invoke(manager, plugin);
                    boolean enabled = (boolean)pluginClass.getMethod("isEnabled").invoke(plugin);
                    Files.writeString(Path.of(options.getProperty("installReceipt")),
                        "{\"plugin\":\"PvPFrameRecorder\",\"enabled\":" + enabled
                        + ",\"serverRestarted\":false}\n");
                } catch (Throwable error) {
                    try { Files.writeString(Path.of(options.getProperty("installReceipt")),
                        "{\"enabled\":false,\"error\":\"" + error.toString().replace("\"", "'") + "\"}\n"); }
                    catch (Exception ignored) { error.printStackTrace(); }
                }
            };
            scheduler.getClass().getMethod("runTask", pluginClass, Runnable.class)
                .invoke(scheduler, owner, load);
        }
    }
}
