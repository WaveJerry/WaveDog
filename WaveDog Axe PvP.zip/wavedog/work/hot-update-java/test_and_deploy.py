"""Test Java class redefinition in a disposable JVM; then apply one verified main-server class."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
SERVER=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
JAVA=SERVER/'runtime/java21/bin'
FRESH=ROOT/'work/pvp-8.6-dual-fresh/source/core/work/counter-escape-ground'

def attach(pid, options):
    subprocess.run([str(JAVA/'java.exe'),'--add-modules','jdk.attach','-cp',str(BASE/'classes'),
        'AttachHotUpdate',str(pid),str(BASE/'HotUpdateAgent.jar'),str(options)],check=True,timeout=30)

def properties(file,values):
    file.write_text('\n'.join(k+'='+str(v).replace('\\','/') for k,v in values.items())+'\n',encoding='utf-8')

def test():
    directory=BASE/'probe';directory.mkdir(exist_ok=True)
    initial=directory/'initial';initial.mkdir(exist_ok=True)
    changed=directory/'changed';changed.mkdir(exist_ok=True)
    source=directory/'RedefineProbe.java'
    source.write_text('public class RedefineProbe { static int value(){return 1;} public static void main(String[] a)throws Exception{for(;;){System.out.println(value());Thread.sleep(50);}}}',encoding='utf-8')
    subprocess.run([str(JAVA/'javac.exe'),'-d',str(initial),str(source)],check=True)
    log=directory/'output.log'
    with log.open('wb') as out:
        process=subprocess.Popen([str(JAVA/'java.exe'),'-cp',str(initial),'RedefineProbe'],stdout=out,stderr=out,creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        source.write_text(source.read_text().replace('return 1','return 2'))
        subprocess.run([str(JAVA/'javac.exe'),'-d',str(changed),str(source)],check=True)
        options=directory/'options.properties'
        properties(options,{'class':'RedefineProbe','bytes':changed/'RedefineProbe.class','receipt':directory/'receipt.json'})
        attach(process.pid,options)
        time.sleep(.3)
        assert '2' in log.read_text().splitlines(),'redefined method not observed'
        assert json.loads((directory/'receipt.json').read_text())['redefined']
        print('JAVA_HOT_REDEFINE_PASS: same running test PID and changed method output',flush=True)
    finally:process.terminate();process.wait(timeout=10)

def deploy():
    target=SERVER/'plugins/PvPArenaAI.jar'
    candidate=FRESH/'PvPArenaAI.jar'
    with zipfile.ZipFile(target) as old,zipfile.ZipFile(candidate) as new:
        different=[n for n in new.namelist() if n not in old.namelist() or new.read(n)!=old.read(n)]
        assert different==['local/pvpbot/ai/OffhandRangedSupport.class'],different
        original=old.read(different[0]);replacement=new.read(different[0])
    raw=subprocess.check_output(['powershell.exe','-NoProfile','-Command',
        'Get-CimInstance Win32_Process | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress'],text=True,encoding='utf-8',errors='replace')
    matches=[]
    for row in json.loads(raw):
        text=(row.get('CommandLine') or '').replace('\\','/').lower()
        if row.get('Name','').lower()=='java.exe' and '/minecraft-1.21.1-server/' in text \
                and 'protocolplayerbridge' not in text:
            matches.append(row['ProcessId'])
    assert len(matches)==1, 'Cannot unambiguously resolve main JVM'
    runtime=ROOT/'work/pvp-dual-brain/runtime/critical-defense-20261115'
    runtime.mkdir(exist_ok=True)
    bytefile=runtime/'OffhandRangedSupport.class';bytefile.write_bytes(replacement)
    (runtime/'OffhandRangedSupport.before.class').write_bytes(original)
    options=runtime/'mechanical-hot-update.properties'
    receipt=runtime/'mechanical-live-receipt.json'
    plugin=SERVER/'plugins/PvPFrameRecorder.jar'
    if plugin.exists():raise RuntimeError('Recorder already installed; refusing overwrite')
    shutil.copy2(ROOT/'work/pvp-frame-recorder/PvPFrameRecorder.jar',plugin)
    properties(options,{'class':'local.pvpbot.ai.OffhandRangedSupport','bytes':bytefile,'receipt':receipt,
        'installPlugin':plugin,'installReceipt':runtime/'recorder-install-receipt.json'})
    attach(matches[0],options)
    result=json.loads(receipt.read_text())
    assert result['pid']==matches[0] and result['sha256']==hashlib.sha256(replacement).hexdigest()
    # Persist only the verified single-class change for the next natural restart.
    shutil.copy2(candidate,target)
    for _ in range(40):
        install=runtime/'recorder-install-receipt.json'
        if install.exists():break
        time.sleep(.1)
    installed=json.loads(install.read_text())
    print(json.dumps({'mechanical':result,'recorder':installed,
        'deployedJarSha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False,indent=2),flush=True)
    if not installed.get('enabled'):raise RuntimeError('Recorder did not enable')

if __name__=='__main__':
    test()
    if '--deploy' in sys.argv:deploy()
