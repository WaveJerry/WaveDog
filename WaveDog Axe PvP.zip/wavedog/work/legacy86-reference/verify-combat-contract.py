"""Check the user's distinguishing cases by executing the original bytecode.

These are synthetic input fixtures, not human bouts or training achievements.
"""
from pathlib import Path
import hashlib, json, subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
cfg = json.loads((BASE/'launch.json').read_text(encoding='utf-8'))
view = dict(tick=100, distance=3.29995, visible=True, targetBlocking=False, targetAxe=True,
    targetFacing=True, ownShieldAvailable=False, ownShieldJustDisabled=False,
    targetShieldJustDropped=False, targetAttackedRecently=False, ownAttackReady=True,
    ownWounded=False, nearWall=False, targetNearWall=False, hasArrows=True,
    targetDrawingRanged=False, targetHoldingRanged=False, targetMotion='APPROACH',
    targetInReach=True, ownAttackCharge=1, bowDrawTicks=0, rangedUseTicks=0,
    ownCrossbowCharged=False, ownOffhand='SHIELD')
senses = dict(ownReachDistance=2.99995, targetReachDistance=2.99995, estimatedReach=2.99995,
    estimatedTargetReach=2.99995, meleeRayDistance=2.99995, estimateAge=0,
    ownWeapon=0, weaponInputReady=True, onGround=True, targetMotionFresh=True,
    targetFacingDot=1, targetAttackAge=1000, damageAge=1000, blockedMeleeAge=1000,
    ownKnockbackAge=1000, targetLandAge=1000, lastBlockTick=-1000, lastMeleeTick=-1000,
    targetShieldDisabled=True, escapeViable=True, escapeJumpEligible=True,
    wallEscapeAvailable=True, opportunity='ENTRY', enteredReach=True)
cases = []

def case(name, v, s, expect):
    cases.append(dict(name=name, view={**view, **v}, senses={**senses, **s}, expect=expect))

for reach in (2.9999, 2.99995, 3.0):
    case('ground-edge-'+str(reach), {}, dict(ownReachDistance=reach, targetReachDistance=reach),
        dict(attack=True, jump=False, sprint=True, shield=False))
case('outside-is-not-an-attack', {}, dict(ownReachDistance=3.000001, targetReachDistance=3.000001,
    opportunity='NONE', enteredReach=False), dict(attack=False))
for vy in (.3, -.2):
    case('usable-shield-vs-air-'+str(vy), dict(ownShieldAvailable=True),
        dict(targetAirborne=True, targetY=vy, targetCritEta=5, targetCritThreat=True,
             targetCriticalPossible=True, opportunity='RISE_INTERRUPT' if vy>0 else 'NONE'),
        dict(shield=True, attack=False, jump=False))
case('unshielded-rising-interrupt', {}, dict(targetAirborne=True, targetY=.3,
    targetCritEta=5, targetCritThreat=True, opportunity='RISE_INTERRUPT'),
    dict(attack=True, jump=False, shield=False))
case('unshielded-descent-with-safe-route', {}, dict(targetAirborne=True, targetY=-.2,
    targetCritEta=0, targetCritThreat=True, opportunity='NONE',
    jumpSpace=dict(threat=True, move=2, clearance=3.4, x=0, z=-1, sprint=True, jump=False)),
    dict(attack=False, jump=False, shield=False))
case('unshielded-no-safe-route-last-reply', {}, dict(targetAirborne=True, targetY=-.2,
    targetCritEta=0, targetCritThreat=True, opportunity='ENTRY',
    jumpSpace=dict(threat=True, move=2, clearance=2.5, x=0, z=-1, sprint=True, jump=False)),
    dict(attack=True, jump=False, shield=False))
rows = []
for c in cases:
    rows.extend([dict(command='reset', seed=123), dict(command='step', view=c['view'], senses=c['senses'])])
p = subprocess.run([cfg['java'], '-cp', cfg['classpath'], cfg['class'], cfg['model']],
    input='\n'.join(map(json.dumps, rows))+'\n', capture_output=True, text=True,
    encoding='utf-8', check=True)
results = [json.loads(s) for s in p.stdout.splitlines()]
assert len(results) == len(rows), p.stderr
for i, c in enumerate(cases):
    result = results[2*i+1]
    assert result['ok'], result
    c['originalResult'] = result['result']
    for k, value in c['expect'].items():
        assert c['originalResult']['decision'][k] == value, (c['name'], k, c['originalResult'])
report = dict(originalJarSha256=cfg['originalJarSha256'], originalClassBytesUnchanged=True,
    syntheticFixtures=True, actualMinecraftBouts=False, modelTrained=False,
    passed=True, cases=cases)
target = ROOT/'outputs/legacy86-hop-neural-20261118/original-combat-contract.json'
target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(passed=True, cases=len(cases), report=str(target))))
