package local.pvpbot.ai;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;

/** Protocol host for the unchanged 8.6 decision classes. All observations and
 * execution receipts are supplied by the normal player client. No Bukkit/NMS
 * movement, damage or entity access is used. Supplementary spacing lives in JS.
 */
public final class Legacy86Runtime {
    static final Gson JSON=Legacy86Reference.JSON;
    static final Map<Long,Attempt> pending=new HashMap<>();
    static final Field PHASE, NEXT_ORBIT;
    static {try {PHASE=InitialCombatController.class.getDeclaredField("phase");PHASE.setAccessible(true);
            NEXT_ORBIT=InitialCombatController.class.getDeclaredField("nextOrbit");NEXT_ORBIT.setAccessible(true);}
        catch(Exception e){throw new ExceptionInInitializerError(e);}}
    record Attempt(long tick,Object phase,double before,boolean counter){}
    static double dealt;
    static void closeContact(InitialCombatController c,JsonObject r)throws Exception {
        Field hop=InitialCombatController.class.getDeclaredField("counterHop");hop.setAccessible(true);
        ((CounterEscapeHop)hop.get(c)).blocked();
        for(String name:new String[]{"counterFlight","escapeObserved","hopFinishPending","hopCriticalAtExit"}) {
            Field f=InitialCombatController.class.getDeclaredField(name);f.setAccessible(true);f.setBoolean(c,false);
        }
        Field exit=InitialCombatController.class.getDeclaredField("exitControl");exit.setAccessible(true);exit.setBoolean(c,true);
        Field observed=InitialCombatController.class.getDeclaredField("observedCounterAxe");observed.setAccessible(true);
        long counter=(long)Legacy86Reference.num(r.getAsJsonObject("senses"),"counterAxeHitTick",-1000);
        observed.setLong(c,Math.max(observed.getLong(c),counter));
        swordMode(c);
    }
    static void swordMode(InitialCombatController c)throws Exception {
        // Explicit user-requested modification to 8.6's post-hop weapon role.
        // Do not merely change the output slot: the original contact tests
        // must agree on the active primary melee weapon after the hop.
        for(String name:new String[]{"escapeSwordHeld","axeSwitchPending","axeSwitchRecovery",
                "landingTradePending","restartTradeHop","tradeRestore","tradeShieldHold","tradeBlocked"}){
            Field f=InitialCombatController.class.getDeclaredField(name);f.setAccessible(true);f.setBoolean(c,false);
        }
        for(String name:new String[]{"activeTrade","tradePlanAfterHit","exchangeHeading"}){
            Field f=InitialCombatController.class.getDeclaredField(name);f.setAccessible(true);f.set(c,null);
        }
        Field melee=InitialCombatController.class.getDeclaredField("currentMelee");melee.setAccessible(true);melee.set(c,Weapon.SWORD);
    }
    static Object command(JsonObject r) throws Exception {
        String command=Legacy86Reference.str(r,"command","");
        var c=Legacy86Reference.controller;
        switch(command){
            case "preview": {
                long physical=r.getAsJsonObject("view").get("tick").getAsLong();
                if(physical!=Legacy86Reference.lastTick)throw new IllegalArgumentException("Preview requires current committed physical tick");
                var saved=Legacy86Reference.controller;long tick=Legacy86Reference.lastTick;
                Legacy86Reference.controller=Legacy86Snapshot.controller();Legacy86Reference.lastTick=physical-1;
                try {return command(withCommand(r,"frame"));}
                finally {Legacy86Reference.controller=saved;Legacy86Reference.lastTick=tick;}
            }
            case "reset":
                Legacy86Reference.reset((long)Legacy86Reference.num(r,"seed",123));pending.clear();dealt=0;
                return Map.of("reset",true);
            case "callback":
                Legacy86Reference.invoke(c,r.get("method").getAsString(),r.getAsJsonArray("args"));
                return Map.of("ok",true);
            case "attempt": {
                long id=r.get("id").getAsLong(),tick=r.get("tick").getAsLong();
                if(!pending.isEmpty())throw new IllegalStateException("Unresolved previous native attack");
                c.beforeMelee(dealt);c.attackSubmitted();
                Object phase=r.has("phase")?Legacy86Reference.decode(r.get("phase"),PHASE.getType()):PHASE.get(c);
                pending.put(id,new Attempt(tick,phase,dealt,Legacy86Reference.bool(r,"counter",false)));
                return Map.of("accepted",true);
            }
            case "outcome": {
                long id=r.get("id").getAsLong();Attempt a=pending.remove(id);
                if(a==null)return Map.of("ignored",true);
                double damage=Legacy86Reference.num(r,"damage",0);boolean critical=Legacy86Reference.bool(r,"critical",false);
                Object current=PHASE.get(c);PHASE.set(c,a.phase());
                try {
                    c.nativeMeleeOutcome(damage>0,critical);dealt+=Math.max(0,damage);
                    c.meleeAttemptFinished(a.tick(),dealt,false);
                    if(damage>0)c.confirmedPressureDamage(a.tick(),dealt);
                    if(damage>0&&a.counter())c.confirmedCounterHop(a.tick());
                } finally {PHASE.set(c,current);}
                return Map.of("accepted",true,"damage",damage);
            }
            case "frame": {
                double orbitMinimum=Legacy86Reference.num(r,"orbitMinimumHealth",5);
                if(!Double.isFinite(orbitMinimum)||orbitMinimum<0||orbitMinimum>20)
                    throw new IllegalArgumentException("Invalid orbit minimum health");
                double health=Legacy86Reference.num(r.getAsJsonObject("senses"),"health",Double.NaN);
                boolean orbitHealthBlocked=Double.isFinite(health)&&health<orbitMinimum;
                if(orbitHealthBlocked) {
                    // Cancel both an active burst and the next optional start,
                    // before ORIGINAL decision selection. Do not fake geometry,
                    // wound opportunities or shielding to suppress an output.
                    c.finishOrbit();
                    long tick=r.getAsJsonObject("view").get("tick").getAsLong();
                    NEXT_ORBIT.setLong(c,Math.max(NEXT_ORBIT.getLong(c),tick+1));
                }
                boolean closeContact=Legacy86Reference.bool(r,"closeContact",false);
                if(closeContact)closeContact(c,r);
                else if(Legacy86Reference.bool(r,"swordMode",false))swordMode(c);
                // Restore the original probabilistic short-approach input.
                // Preview reaches this code only on its isolated Java snapshot.
                var advance=r.has("shortAdvance")&&!r.get("shortAdvance").isJsonNull()
                    ? r.getAsJsonObject("shortAdvance") : null;
                boolean available=advance!=null&&Legacy86Reference.bool(advance,"available",false);
                c.shortAdvanceAvailable(available);
                // At real contact the outside-only forecast intentionally ends.
                // Do not erase the timing of the already selected approach;
                // the original controller still needs it to finish that hit.
                if(available)c.shortAdvanceTiming((int)Legacy86Reference.num(advance,"contactTicks",-1),
                    (int)Legacy86Reference.num(advance,"shieldDelay",-1));
                c.targetLoadingCrossbow(Legacy86Reference.bool(r,"targetLoading",false));
                var out=new LinkedHashMap<String,Object>(Legacy86Reference.step(r));
                out.put("keepEscapeSword",c.keepEscapeSword());out.put("counterHopActive",c.counterHopActive());
                out.put("pressureRecovering",c.pressureRecovering());out.put("hasPendingAttack",!pending.isEmpty());
                out.put("comboStrike",c.comboStrike());out.put("contactReply",c.contactReply());
                out.put("proactiveStrike",c.proactiveStrike());out.put("shieldPressure",c.shieldPressure());
                out.put("closeRechargeReply",c.closeRechargeReply());out.put("wallDamageReply",c.wallDamageReply());
                out.put("drawRequired",c.requiredDrawTicks());
                out.put("shortAdvanceAvailable",available);
                out.put("closeContact",closeContact);
                out.put("hasPendingAttack",!pending.isEmpty());
                out.put("orbitHealthGate",Map.of("minimumHealth",orbitMinimum,
                    "health",health,"blocked",orbitHealthBlocked));
                return out;
            }
            default:throw new IllegalArgumentException("Unknown command: "+command);
        }
    }
    static JsonObject withCommand(JsonObject row,String command){var next=row.deepCopy();next.addProperty("command",command);return next;}
    public static void main(String[] args)throws Exception {
        Legacy86Reference.tacticalModel=Path.of(args[0]);Legacy86Reference.reset(123);
        try(var input=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8))){
            for(String line;(line=input.readLine())!=null;){
                JsonObject r=null;
                try {r=JsonParser.parseString(line).getAsJsonObject();Object result=command(r);
                    System.out.println(JSON.toJson(Map.of("id",r.get("requestId"),"ok",true,"result",result)));
                }catch(Throwable e){
                    while(e instanceof InvocationTargetException&&e.getCause()!=null)e=e.getCause();
                    System.out.println(JSON.toJson(Map.of("id",r!=null&&r.has("requestId")?r.get("requestId"):new JsonPrimitive(-1),
                        "ok",false,"error",e.toString())));
                }
            }
        }
    }
}
