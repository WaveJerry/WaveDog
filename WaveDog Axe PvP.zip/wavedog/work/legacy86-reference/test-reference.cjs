'use strict'
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict')
const {spawnSync}=require('node:child_process')
const {createCounterEscapeHop}=require('../pvp-player-client/protocol-counter-escape-hop')
const brain=require('../pvp-player-client/protocol-pilot-mechanical-brain')
const launch=JSON.parse(fs.readFileSync(path.join(__dirname,'launch.json')))
function oracle(rows){
 const p=spawnSync(launch.java,['-cp',launch.classpath,launch.class,launch.model],{
  input:rows.map(JSON.stringify).join('\n')+'\n',encoding:'utf8',maxBuffer:32*1024*1024,windowsHide:true})
 assert.equal(p.status,0,p.stderr)
 const out=p.stdout.trim().split(/\r?\n/).map(JSON.parse)
 assert.equal(out.length,rows.length)
 for(const x of out)assert(x.ok,x.error)
 return out.map(x=>x.result)
}
function status(hop){return {active:hop.active(),airborne:hop.wasAirborne(),allowsJump:hop.allowsJump(),
 exitAccepted:hop.exitAccepted(),critical:[false,true].flatMap(ready=>[NaN,-.4,-.001,0,.4].map(v=>hop.criticalAvailable(ready,v)))}}
const hop=createCounterEscapeHop(),commands=[],expected=[]
let random=123456789,tick=0
function rand(){random=(Math.imul(random,1664525)+1013904223)>>>0;return random/4294967296}
for(let i=0;i<12000;i++){
 const methods=['reset','arm','observe','jumpSubmitted','criticalSubmitted','acceptExit','blocked']
 const method=methods[Math.floor(rand()*methods.length)]
 tick+=Math.floor(rand()*4)
 const args=method==='arm'||method==='jumpSubmitted'?[tick]:method==='observe'?[tick,rand()<.5]:[]
 hop[method](...args);commands.push({command:'hop-call',method,args});expected.push(status(hop))
}
const actual=oracle(commands)
for(let i=0;i<actual.length;i++)assert.deepEqual(actual[i],expected[i],'original Java hop parity at operation '+i)
const report={originalJarSha256:launch.originalJarSha256,originalClassesRecompiled:false,
 originalHopDifferentialOperations:actual.length,hopDifferentialPassed:true,
 supersededHybridBoundaryTestsArchived:true,mainServerTouched:false,
 fullMechanicalConversionEquivalent:false,neuralBehaviorEquivalent:false}
fs.writeFileSync(path.resolve(__dirname,'../../outputs/legacy86-hop-neural-20261118/reference-checks.json'),JSON.stringify(report,null,2))
console.log(JSON.stringify(report))
