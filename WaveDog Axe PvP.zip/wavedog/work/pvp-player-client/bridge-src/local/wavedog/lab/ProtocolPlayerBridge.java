package local.wavedog.lab;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Drives a real network client using the existing GRU64 policy, without a fake player. */
public final class ProtocolPlayerBridge {
    static final Gson JSON = new Gson();
    static final class ObservationState {
        final double[] history=new double[12],anchorHistory=new double[12];long observed=-1;
    }
    static double number(JsonObject o, String key, double fallback) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsDouble() : fallback;
    }
    static boolean bool(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsBoolean();
    }
    static String string(JsonObject o, String key, String fallback) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : fallback;
    }
    static Map<String,Object> input(DuelPolicy.Input a, long requestId, long decidedTick, String focus, String opponent, String fighter) {
        var out = new LinkedHashMap<String,Object>();
        out.put("requestId", requestId);out.put("decidedTick", decidedTick);out.put("yaw", a.yaw());out.put("pitch", a.pitch());
        out.put("forward", a.forward());out.put("side", a.side());out.put("sprint", a.sprint());
        out.put("jump", a.jump());out.put("sneak", a.sneak());out.put("shield", a.shield());
        out.put("attack", a.attack());out.put("slot", a.slot());out.put("use", a.use());
        out.put("release", a.release());out.put("focus", focus);out.put("model", "GRU64-PPO");
        out.put("opponent", opponent);out.put("fighter", fighter);
        return out;
    }
    public static void main(String[] args) throws Exception {
        if(args.length != 1 && (args.length != 2 || !args[1].equals("--observe-only")))
            throw new IllegalArgumentException("checkpoint directory [--observe-only] required");
        boolean observeOnly=args.length==2;
        Path folder = Path.of(args[0]);Files.createDirectories(folder);
        try(var model = new RecurrentPpoCombat(folder);
            var reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
            if(!observeOnly&&model.state.updates==0&&model.state.bootstrapExamples==0)
                NativeClientWarmStart.apply(model);
            var actors = new HashMap<String,RecurrentPpoCombat.Actor>();
            var observations = new HashMap<String,ObservationState>();
            var opponents = new HashMap<String,String>();
            var cell = ArenaLayout.cells().getFirst();
            System.out.println(JSON.toJson(Map.of("event", "ready", "checkpoint", model.checkpoint.toString(),
                "architecture", observeOnly?"PUBLIC-OBS-98":"GRU64-PPO", "learning", false,
                "nativeClientBootstrapExamples", model.state.bootstrapExamples)));
            for(String line; (line = reader.readLine()) != null;) {
                try {
                    JsonObject req = JsonParser.parseString(line).getAsJsonObject();
                    String command = string(req, "command", "act");
                    String fighter = string(req, "fighter", "WPlayer01");
                    if(command.equals("close")) break;
                    if(command.equals("reset")) {
                        boolean learning=!observeOnly&&bool(req,"learning");
                        String opponent=string(req,"opponent","");
                        if(opponent.isBlank()&&learning)throw new IllegalArgumentException("Learning actor needs named opponent");
                        actors.put(fighter,model.actor(System.nanoTime() ^ fighter.hashCode(), learning));
                        observations.put(fighter,new ObservationState());
                        opponents.put(fighter,opponent);
                        System.out.println(JSON.toJson(Map.of("event","reset","learning",learning,
                            "gradient_updates",model.state.updates,"trained_episodes",model.state.episodes,
                            "fighter",fighter,"opponent",opponent)));
                        continue;
                    }
                    if(command.equals("feedback")) {
                        var actor=actors.get(fighter);
                        if(actor==null)throw new IllegalStateException("Fighter actor not reset: "+fighter);
                        actor.outcomeFeedback(number(req,"dealt",0),number(req,"received",0));
                        System.out.println(JSON.toJson(Map.of("event","feedback_recorded","fighter",fighter)));continue;
                    }
                    if(command.equals("native_step")) {
                        var actor=actors.get(fighter);
                        if(actor==null)throw new IllegalStateException("Fighter actor not reset: "+fighter);
                        actor.nativeStepFeedback((long)number(req,"decidedTick",-1),
                            number(req,"reward",0));
                        continue;
                    }
                    if(command.equals("executed")) {
                        var actor=actors.get(fighter);
                        if(actor==null)throw new IllegalStateException("Fighter actor not reset: "+fighter);
                        var ignored=new HashSet<Integer>();
                        if(req.has("ignoredHeads"))for(var item:req.getAsJsonArray("ignoredHeads")) {
                            int head=item.getAsInt();
                            if(head<0||head>=CombatLearner.WIDTH.length)throw new IllegalArgumentException("Invalid action head");
                            ignored.add(head);
                        }
                        actor.executed((long)number(req,"decidedTick",-1),ignored);
                        continue;
                    }
                    if(command.equals("finish")||command.equals("partial")) {
                        var actor=actors.get(fighter);
                        if(actor==null)throw new IllegalStateException("Fighter actor not reset: "+fighter);
                        long before=model.state.updates;
                        boolean partial=command.equals("partial");
                        if(partial)actor.submit(0,false);
                        else actor.finish(bool(req,"win"),number(req,"health",0));
                        long deadline=System.nanoTime()+java.util.concurrent.TimeUnit.SECONDS.toNanos(25);
                        while(model.pending.get()>0&&System.nanoTime()<deadline)Thread.sleep(20);
                        if(model.pending.get()>0||model.state.updates<=before||!model.error.isEmpty())
                            throw new IllegalStateException("PPO update not saved: "+model.error);
                        var receipt=new LinkedHashMap<String,Object>();receipt.put("event",partial?"trained_partial":"trained");
                        receipt.put("round",(int)number(req,"round",0));receipt.put("gradient_updates_before",before);
                        receipt.put("gradient_updates_after",model.state.updates);
                        receipt.put("trained_episodes",model.state.episodes);
                        receipt.put("training_samples",model.state.samples);
                        receipt.put("native_feedback_applied",actor.nativeFeedbackApplied);
                        receipt.put("checkpoint",model.checkpoint.toString());
                        receipt.put("fighter",fighter);
                        System.out.println(JSON.toJson(receipt));
                        actors.put(fighter,model.actor(System.nanoTime(),false));continue;
                    }
                    if(!command.equals("act")) throw new IllegalArgumentException("Unknown command");
                    var actor=actors.get(fighter);
                    if(actor==null)throw new IllegalStateException("Fighter actor not reset: "+fighter);
                    String requestedOpponent=string(req,"opponent","");
                    if(requestedOpponent.isBlank()||!requestedOpponent.equals(opponents.get(fighter)))
                        throw new IllegalArgumentException("Opponent identity missing or changed during bout");
                    JsonObject s=req.getAsJsonObject("self"),o=req.getAsJsonObject("seen");
                    long tick=(long)number(req,"tick",0),id=(long)number(req,"requestId",0);
                    var self=new DuelPolicy.Self(number(s,"x",0),number(s,"y",221),number(s,"z",0),
                        number(s,"eyeY",222.62),number(s,"vx",0),number(s,"vy",0),number(s,"vz",0),
                        bool(s,"ground"),bool(s,"critical"),(float)number(s,"charge",1),number(s,"health",20),
                        bool(s,"shieldAvailable"),bool(s,"shielding"),(int)number(s,"arrows",0),
                        bool(s,"crossbowLoaded"),bool(s,"using"),(int)number(s,"useTicks",0),(int)number(s,"held",7));
                    var visibleArrows=new ArrayList<DuelPolicy.Arrow>();
                    if(o!=null&&o.has("arrows")&&o.get("arrows").isJsonArray())
                        for(var item:o.getAsJsonArray("arrows")){
                            if(visibleArrows.size()>=4)break;
                            if(!item.isJsonObject())continue;
                            var arrow=item.getAsJsonObject();
                            visibleArrows.add(new DuelPolicy.Arrow(tick,
                                number(arrow,"x",0),number(arrow,"y",0),number(arrow,"z",0),
                                number(arrow,"vx",0),number(arrow,"vy",0),number(arrow,"vz",0)));
                        }
                    DuelPolicy.Seen seen = o==null?null:new DuelPolicy.Seen(tick,tick,bool(o,"visible"),
                        number(o,"x",0),number(o,"y",221),number(o,"z",0),(float)number(o,"yaw",0),
                        bool(o,"shield"),string(o,"held","UNKNOWN"),bool(o,"using"),
                        (long)number(o,"swing",0),visibleArrows);
                    String focus=string(req,"focus","FREE");
                    actor.focus=ExperienceLibrary.Focus.valueOf(focus);
                    actor.publicHurtEvidence=Math.min(20,Math.max(0,(int)number(req,"observedOpponentHurts",0)));
                    actor.publicOpponentSwingAge=Math.min(20,Math.max(-1,
                        (int)number(req,"observedOpponentSwingAge",-1)));
                    var activeCell=ArenaLayout.cells().stream().filter(c->c.contains(self.x(),self.y(),self.z())).findFirst().orElse(cell);
                    var style=DuelPolicy.Style.valueOf(string(req,"style","AGGRESSIVE"));
                    if(observeOnly) {
                        var context=observations.get(fighter);
                        if(context==null)throw new IllegalStateException("Observation context not reset: "+fighter);
                        float yaw=(float)number(req,"yaw",0),pitch=(float)number(req,"pitch",0);
                        boolean refinement=bool(req,"observationRefinement");
                        if(refinement&&tick!=context.observed)
                            throw new IllegalArgumentException("Refinement changed physical anchor");
                        if(!refinement&&tick!=context.observed)
                            System.arraycopy(context.history,0,context.anchorHistory,0,12);
                        double[] x=Arrays.copyOf(CombatLearner.features(self,seen,activeCell,style,
                            yaw,pitch,tick,refinement?context.anchorHistory:context.history),RecurrentPpoCombat.F);
                        CombatLearner.conditionOnFocus(x,ExperienceLibrary.Focus.valueOf(focus));
                        int swingAge=Math.min(20,Math.max(-1,
                            (int)number(req,"observedOpponentSwingAge",-1)));
                        x[CombatLearner.F]=swingAge>=0&&swingAge<=10
                            ?1.0/(1.0+swingAge/5.0):0;
                        if(seen!=null&&seen.visible()){
                            double dx=Math.max(0,Math.abs(seen.x()-self.x())-.3);
                            double dz=Math.max(0,Math.abs(seen.z()-self.z())-.3);
                            double dy=Math.max(0,Math.max(seen.y()-self.eyeY(),
                                self.eyeY()-(seen.y()+1.8)));
                            x[CombatLearner.F+1]=Math.tanh((Math.sqrt(dx*dx+dy*dy+dz*dz)-3.0)/.75);
                        }
                        if(!refinement&&seen!=null&&seen.visible()&&seen.captured()!=context.observed){
                            System.arraycopy(x,18,context.history,0,12);
                            context.observed=seen.captured();
                        }
                        System.out.println(JSON.toJson(Map.of("model","DUAL-OBS",
                            "fighter",fighter,"opponent",requestedOpponent,
                            "requestId",id,"decidedTick",tick,"observation",x)));
                        continue;
                    }
                    var result=actor.act(tick,tick,self,seen,activeCell,style,
                        (float)number(req,"yaw",0),(float)number(req,"pitch",0));
                    var reply=input(result,id,tick,focus,requestedOpponent,fighter);
                    reply.put("observedArrows",visibleArrows.size());
                    System.out.println(JSON.toJson(reply));
                } catch(Exception e) {
                    System.out.println(JSON.toJson(Map.of("event","error","message",e.toString())));
                }
            }
        }
    }
}
