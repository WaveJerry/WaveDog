package local.wavedog.lab;

import java.util.*;

/** Initial action examples based on validated 1.21.1 protocol-player controls. */
final class NativeClientWarmStart {
    record Example(double[] x, int[] action) {}
    static final int EXAMPLES = 2400, EPOCHS = 32, BATCH = 24;

    static void apply(RecurrentPpoCombat model) throws Exception {
        if (model.state.bootstrapExamples > 0) return;
        var random = new Random(2026111102L);
        var cell = ArenaLayout.cells().getFirst();
        var examples = new ArrayList<Example>();
        for (int i=0; i<EXAMPLES; i++) {
            double yaw = random.nextDouble()*360-180;
            double bearing = switch((i/4)%4) {
                case 0 -> -Math.toRadians(yaw)+(random.nextDouble()-.5)*.12;
                case 1 -> -Math.toRadians(yaw)+(random.nextBoolean()?1:-1)*(.22+random.nextDouble()*.65);
                case 2 -> -Math.toRadians(yaw)+(random.nextBoolean()?1:-1)*(1.1+random.nextDouble()*1.6);
                default -> random.nextDouble()*Math.PI*2;
            };
            double range = switch(i%4) {
                case 0,1 -> 1.5+random.nextDouble()*1.0;
                default -> 3.8+random.nextDouble()*5.5;
            };
            double x = 1058.5+random.nextDouble()*2-1, z = 960.5+random.nextDouble()*2-1;
            double tx = x+Math.sin(bearing)*range, tz = z+Math.cos(bearing)*range;
            float charge = switch(i%4) {
                case 0,2 -> .95f + random.nextFloat()*.05f;
                default -> .1f + random.nextFloat()*.5f;
            };
            boolean opponentShield = random.nextBoolean();
            var self = new DuelPolicy.Self(x,221,z,222.62,0,0,0,true,false,charge,
                10+random.nextDouble()*10,true,false,5,false,false,0,7);
            var seen = new DuelPolicy.Seen(i,i,true,tx,221,tz,0,opponentShield,
                random.nextBoolean()?"DIAMOND_AXE":"DIAMOND_SWORD",opponentShield,0,List.of());
            double[] feature = CombatLearner.features(self,seen,cell,DuelPolicy.Style.AGGRESSIVE,(float)yaw,0,i,new double[12]);
            double delta = CombatLearner.wrap(DuelPolicy.yaw(tx-x,tz-z)-(float)yaw);
            int turn = CombatLearner.nearest((float)delta,CombatLearner.TURN);
            boolean inRange = range <= 2.8, full = charge >= .9;
            int hand = inRange && full ? 2 : inRange && charge < .72 ? 1 : 0;
            // Early actions reserve one second for an ordinary full-charge axe hit.
            int[] action = {range>2.45?1:0,range>3.2?1:0,0,0,hand,0,turn,3,0};
            examples.add(new Example(feature,action));
        }
        var state = RecurrentPpoCombat.copy(model.state);
        for (int epoch=0; epoch<EPOCHS; epoch++) {
            Collections.shuffle(examples,random);
            for(int first=0; first<examples.size(); first+=BATCH) {
                int end=Math.min(examples.size(),first+BATCH);double[] gradient=new double[RecurrentPpoCombat.N];
                for(int i=first;i<end;i++) {
                    var example=examples.get(i);
                    var frame=RecurrentPpoCombat.forward(state.w,example.x,new double[RecurrentPpoCombat.H]);
                    double[] logits=new double[CombatLearner.O];
                    for(int head=0;head<example.action.length;head++)
                        for(int choice=0;choice<CombatLearner.WIDTH[head];choice++) {
                            int at=CombatLearner.OFF[head]+choice;
                            double priority=head==6?4.0:head==0||head==1||head==4?2.0:1.0;
                            logits[at]=priority*((choice==example.action[head]?1:0)-frame.p[at]);
                        }
                    RecurrentPpoCombat.backward(state.w,frame,logits,0,new double[RecurrentPpoCombat.H],gradient);
                }
                for(int i=0;i<gradient.length;i++)gradient[i]/=end-first;
                RecurrentPpoCombat.adam(state,gradient,.0015);
            }
        }
        state.bootstrapExamples=EXAMPLES;
        RecurrentPpoCombat.validate(state);model.state=state;model.save();
    }
}
