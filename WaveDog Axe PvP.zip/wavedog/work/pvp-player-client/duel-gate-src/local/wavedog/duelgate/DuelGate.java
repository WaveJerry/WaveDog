package local.wavedog.duelgate;

import com.google.gson.Gson;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/** Two player-approved human bouts with a real protocol bot, scoped to arena one. */
public final class DuelGate extends JavaPlugin implements Listener, CommandExecutor {
    private static final Gson JSON = new Gson();
    private static final String BOT = "WPlayer01", TITLE = "§8WaveDog PvP 第";
    private String token;
    private int pendingRound, activeRound;
    private String pendingHuman, activeHuman;
    private Path journal;
    private Path readiness = Path.of("D:/CodexWorkspace/ban/work/pvp-player-client/new-learning/human-trial-ready.json");

    @Override public void onEnable() {
        try {
            Files.createDirectories(getDataFolder().toPath());
            token = UUID.randomUUID().toString();
            Files.writeString(getDataFolder().toPath().resolve("duel-token.txt"), token);
            journal = getDataFolder().toPath().resolve("duel-events.jsonl");
        } catch (Exception e) { throw new IllegalStateException("Duel gate could not initialize", e); }
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("duelgate")).setExecutor(this);
    }
    private void record(String type, Map<String,Object> values) {
        try {
            Map<String,Object> row = new LinkedHashMap<>();
            row.put("at", Instant.now().toString()); row.put("tick", Bukkit.getCurrentTick()); row.put("type", type); row.putAll(values);
            Files.writeString(journal, JSON.toJson(row) + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) { getLogger().warning("Duel journal write failed: " + e); }
    }
    private boolean inArena(Location l) {
        return l.getWorld() != null && l.getWorld().getName().equals("world")
            && l.getX() >= 1042 && l.getX() <= 1074 && l.getY() >= 220 && l.getY() <= 228
            && l.getZ() >= 944 && l.getZ() <= 976;
    }
    private int clearDrops() {
        World world = Bukkit.getWorld("world"); if (world == null) return 0;
        int removed = 0;
        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof Item) && !(entity instanceof ExperienceOrb)) continue;
            if (!inArena(entity.getLocation())) continue;
            entity.remove(); removed++;
        }
        record("arena_cleanup", Map.of("removed", removed));
        return removed;
    }
    private void equipBot(Player bot) {
        var inventory = bot.getInventory(); inventory.clear();
        inventory.setItem(0, new ItemStack(Material.DIAMOND_SWORD));
        inventory.setItem(1, new ItemStack(Material.BOW));
        inventory.setItem(2, new ItemStack(Material.ARROW, 5));
        inventory.setItem(4, new ItemStack(Material.CROSSBOW));
        inventory.setItem(7, new ItemStack(Material.DIAMOND_AXE));
        inventory.setHeldItemSlot(7);
        inventory.setItemInOffHand(new ItemStack(Material.SHIELD));
        inventory.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        inventory.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        inventory.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        inventory.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        bot.setHealth(20); bot.setFoodLevel(20); bot.setSaturation(5);
        bot.setNoDamageTicks(0); bot.setCooldown(Material.SHIELD, 0);
        bot.setSprinting(false); bot.setSneaking(false);
    }
    private void ensureHumanKit(Player human) {
        var inventory = human.getInventory();
        for (Material type : List.of(Material.DIAMOND_SWORD, Material.DIAMOND_AXE,
                Material.BOW, Material.CROSSBOW)) {
            if (!inventory.contains(type)) inventory.addItem(new ItemStack(type));
        }
        int arrows = inventory.all(Material.ARROW).values().stream().mapToInt(ItemStack::getAmount).sum();
        if (arrows < 5) inventory.addItem(new ItemStack(Material.ARROW, 5 - arrows));
        if (inventory.getItemInOffHand().getType() == Material.AIR)
            inventory.setItemInOffHand(new ItemStack(Material.SHIELD));
        else if (inventory.getItemInOffHand().getType() != Material.SHIELD && !inventory.contains(Material.SHIELD))
            inventory.addItem(new ItemStack(Material.SHIELD));
        if (inventory.getHelmet() == null) inventory.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        if (inventory.getChestplate() == null) inventory.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        if (inventory.getLeggings() == null) inventory.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        if (inventory.getBoots() == null) inventory.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
    }
    private boolean prepare(Player human) {
        Player bot = Bukkit.getPlayerExact(BOT);
        if (bot == null) { human.sendMessage("§c协议玩家还没有上线。"); return false; }
        World world = Bukkit.getWorld("world"); if (world == null) return false;
        if (!inArena(human.getLocation())) human.teleport(new Location(world, 1062.5, 221, 960.5, 90, 0));
        clearDrops(); equipBot(bot); ensureHumanKit(human);
        human.setHealth(20); human.setFoodLevel(20); human.setSaturation(5);
        human.setNoDamageTicks(0); human.setCooldown(Material.SHIELD, 0);
        double dx = 1058.5-human.getX(), dz = 960.5-human.getZ();
        double length = Math.max(0.01, Math.hypot(dx, dz));
        double x = human.getX()+dx/length*3.2, z = human.getZ()+dz/length*3.2;
        bot.teleport(new Location(world, x, 221, z, 0, 0)); bot.setVelocity(new Vector());
        return true;
    }
    private static ItemStack button(Material type, String title) {
        ItemStack item = new ItemStack(type); ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(title); item.setItemMeta(meta); return item;
    }
    private void invite(Player human, int round) {
        if (activeRound != 0) return;
        if (!Files.isRegularFile(readiness)) { human.sendMessage("§cGRU/Qwen 控制器尚未就绪，稍后再打开对话框。"); return; }
        try { if (System.currentTimeMillis()-Files.getLastModifiedTime(readiness).toMillis()>5000) { human.sendMessage("§cGRU/Qwen 就绪状态已过期。"); return; } }
        catch(Exception e) { human.sendMessage("§c无法核验 GRU/Qwen 状态。"); return; }
        pendingRound = round; pendingHuman = human.getName();
        Inventory menu = Bukkit.createInventory(null, 9, TITLE + round + "局");
        menu.setItem(3, button(Material.LIME_WOOL, "§a同意开始第"+round+"局"));
        menu.setItem(5, button(Material.BARRIER, "§c稍后再打"));
        human.openInventory(menu);
        human.sendMessage("§e检查装备后点绿色羊毛。每局单独确认，bot 使用 GRU 与本地 Qwen 教练。");
        record("invite", Map.of("round", round, "human", human.getName()));
    }
    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().startsWith(TITLE)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player human) || !human.getName().equals(pendingHuman) || pendingRound == 0) return;
        if (event.getRawSlot() == 5) {
            pendingRound = 0; pendingHuman = null; human.closeInventory(); human.sendMessage("§e已取消开局。"); return;
        }
        if (event.getRawSlot() != 3) return;
        try { if (!Files.isRegularFile(readiness) || System.currentTimeMillis()-Files.getLastModifiedTime(readiness).toMillis()>5000) { human.sendMessage("§cGRU/Qwen 已离线，无法开局。"); return; } }
        catch(Exception e) { human.sendMessage("§c无法核验 GRU/Qwen 状态。"); return; }
        int round = pendingRound;
        if (!prepare(human)) return;
        pendingRound = 0; pendingHuman = null; activeRound = round; activeHuman = human.getName(); human.closeInventory();
        Bukkit.getPlayerExact(BOT).sendMessage("WDUEL_START:"+round+":"+activeHuman+":"+token);
        human.sendMessage("§a第"+round+"局开始！");
        record("consent", Map.of("round", round, "human", activeHuman));
        Bukkit.getScheduler().runTaskLater(this, () -> { if (activeRound == round) abort("time_limit"); }, 20L*120);
    }
    private void abort(String reason) {
        if (activeRound == 0) return;
        int round = activeRound; String opponent = activeHuman;
        activeRound = 0; pendingRound = 0; activeHuman = pendingHuman = null;
        Player bot = Bukkit.getPlayerExact(BOT), human = opponent == null ? null : Bukkit.getPlayerExact(opponent);
        if (bot != null) bot.sendMessage("WDUEL_END:"+round+":ABORT:"+token);
        if (human != null) human.sendMessage("§e第"+round+"局已暂停（"+reason+"）。检查记录后再发下一局按钮。");
        clearDrops(); record("abort", Map.of("round", round, "reason", reason));
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        if (activeRound != 0 && (event.getPlayer().getName().equals(activeHuman) || event.getPlayer().getName().equals(BOT))) abort("disconnect");
        if (event.getPlayer().getName().equals(pendingHuman)) { pendingRound = 0; pendingHuman = null; }
    }
    @EventHandler(priority=EventPriority.MONITOR) public void onDamage(EntityDamageByEntityEvent event) {
        if (activeRound == 0 || !(event.getDamager() instanceof Player attacker) || !(event.getEntity() instanceof Player target)) return;
        if (!Set.of(activeHuman, BOT).contains(attacker.getName()) || !Set.of(activeHuman, BOT).contains(target.getName()) || attacker == target) return;
        record("damage", Map.of("round", activeRound, "attacker", attacker.getName(), "target", target.getName(),
            "final", event.getFinalDamage(), "cancelled", event.isCancelled(), "weapon", attacker.getInventory().getItemInMainHand().getType().name()));
    }
    @EventHandler public void onDeath(PlayerDeathEvent event) {
        if (activeRound == 0 || !Set.of(activeHuman, BOT).contains(event.getEntity().getName())) return;
        Player victim = event.getEntity(); int round = activeRound; activeRound = 0;
        String opponent = activeHuman; activeHuman = null;
        String winner = victim.getName().equals(opponent) ? BOT : opponent;
        if (victim.getName().equals(opponent)) {
            event.setKeepInventory(true); event.getDrops().clear();
            event.setKeepLevel(true); event.setDroppedExp(0);
        }
        record("death", Map.of("round", round, "winner", winner, "loser", victim.getName()));
        Player bot = Bukkit.getPlayerExact(BOT);
        if (bot != null) bot.sendMessage("WDUEL_END:"+round+":"+winner+":"+token);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            clearDrops();
            Player human = Bukkit.getPlayerExact(opponent);
            if (human == null) return;
            human.sendMessage("§e第"+round+"局结束，胜者："+winner);
            human.sendMessage("§e本局记录已保存；检查后再发下一局按钮。");
        }, 20);
    }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("cleanup")) {
            sender.sendMessage("Removed " + clearDrops() + " arena drops"); return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("abort")) {
            abort("operator"); sender.sendMessage("Active round stopped"); return true;
        }
        if ((args.length == 2 || args.length == 3) && args[0].equalsIgnoreCase("invite")) {
            if (activeRound != 0) { sender.sendMessage("Duel in progress"); return true; }
            String playerName = args.length == 3 ? args[1] : sender instanceof Player player ? player.getName() : null;
            if (playerName == null) { sender.sendMessage("Use /duelgate invite <player> <round> from console"); return true; }
            int round; try { round = Integer.parseInt(args[args.length-1]); } catch (NumberFormatException e) { round = 0; }
            if (round < 1 || round > 20) { sender.sendMessage("Use round 1..20"); return true; }
            Player human = Bukkit.getPlayerExact(playerName), bot = Bukkit.getPlayerExact(BOT);
            if (human == null || bot == null) { sender.sendMessage("Human or bot is offline"); return true; }
            invite(human, round); sender.sendMessage("Dialog opened for round " + round); return true;
        }
        sender.sendMessage("Usage: /duelgate invite [player] 1..20 | cleanup | abort"); return true;
    }
}
