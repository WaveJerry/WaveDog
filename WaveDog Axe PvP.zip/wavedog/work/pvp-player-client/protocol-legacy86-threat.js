'use strict'

// Public-observation prediction. The disk at each future tick encloses all
// horizontal steering inputs within the stated acceleration bound. It is not
// one guessed trajectory, nor access to an opponent's private keys/cooldown.
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n))
const gap=(v,a,b)=>Math.max(0,a-v,v-b)
const valid=p=>p&&['x','y','z','vx','vy','vz'].every(k=>Number.isFinite(p[k]))
// Public map landmarks. These select a centre preference, never collision
// bounds: walls and walkability still come from loaded block shapes.
function arenaCenter(self){
  if(self.y<219||self.y>232)return null
  if(self.x>=990&&self.x<=1039&&self.z>=990&&self.z<=1039)return {x:1014.5,z:1014.5,name:'main-arena'}
  if(Math.hypot(self.x-1122.5,self.z-960.5)<=24)return {x:1122.5,z:960.5,name:'arena-3'}
  return null
}
function centerGain(frame,end){
  const c=frame.arenaCenter||arenaCenter(frame.self)
  return c?clamp(Math.hypot(frame.self.x-c.x,frame.self.z-c.z)-Math.hypot(end.x-c.x,end.z-c.z),-2,2):0
}
function eyeBoxReach(own,target){
  const half=target.half??.3,height=target.height??1.8,eye=own.y+(own.eyeHeight??1.62)
  return Math.hypot(Math.max(0,Math.abs(own.x-target.x)-half),
    Math.max(0,target.y-eye,eye-target.y-height),Math.max(0,Math.abs(own.z-target.z)-half))
}
function airborneEnvelope(target,{floorY=-64,steering=.026,positionError=.04,velocityError=.035,horizon=40}={}){
  if(!valid(target)||target.grounded===true)return []
  let {x,y,z,vx,vy,vz}=target,radius=positionError,rv=velocityError
  const result=[]
  for(let t=0;t<=horizon;t++){
    // Vertical uncertainty is retained up to the latest possible landing.
    const yError=positionError+velocityError*(1-Math.pow(.98,t))/.02
    if(t>0&&y+yError<=floorY+1e-6&&vy<=0)break
    result.push({tick:t,x,y,z,vy,radius,yMin:Math.max(floorY,y-yError),yMax:y+yError,
      criticalPossible:vy-velocityError*Math.pow(.98,t)<0})
    x+=vx;z+=vz;y+=vy;vx*=.91;vz*=.91;vy=(vy-.08)*.98
    radius+=rv+steering;rv=(rv+steering)*.91
  }
  return result
}
function clearance(own,e){
  // Enemy eye to our physical box. Radius is a superset of possible enemy
  // positions; subtract it before evaluating horizontal reach.
  const h=Math.max(0,Math.hypot(Math.max(0,Math.abs(e.x-own.x)-.3),
    Math.max(0,Math.abs(e.z-own.z)-.3))-e.radius)
  const vertical=Math.max(0,own.y-(e.yMax+1.62),(e.yMin+1.62)-(own.y+1.8))
  return Math.hypot(h,vertical)
}
function exposureTicks(frame){
  if(!frame.selfPositionHistory?.length)return 0
  const latency=frame.latency||{}
  // Our outgoing movement can still be queued, and an opponent's view and
  // attack have their own public round-trip delay. Neither sees our newest
  // local physics point instantaneously. This is a stated bounded model.
  return clamp(Math.ceil(((latency.oneWayMs??25)+(latency.serverQueueMs??50)
    +(latency.opponentRttMs??50))/50),0,8)
}
function exposedClearance(frame,points,e,lagTicks=exposureTicks(frame)){
  let distance=clearance(points[e.tick],e)
  const tick=frame.observation.tick
  for(let lag=1;lag<=lagTicks;lag++){
    const index=e.tick-lag
    let own=points[Math.max(0,index)]
    if(index<0){
      const history=frame.selfPositionHistory
      for(let i=history.length-1;i>=0;i--)if(history[i].tick<=tick+index){own=history[i];break}
    }
    distance=Math.min(distance,clearance(own,e))
  }
  return distance
}
function ageEnvelope(envelope,ageTicks){
  // Entity positions are packet samples, not a fresh simulation state on
  // every 2ms poll. Align the whole possible flight with NOW, including its
  // critical phase; enlarging only the position radius leaves a stale rising
  // velocity incorrectly promising several more safe ticks.
  if(!envelope.length)return []
  const lo=Math.min(envelope.length-1,Math.floor(ageTicks)),hi=Math.min(envelope.length-1,Math.ceil(ageTicks)),result=[]
  for(let tick=0;tick+lo<envelope.length;tick++){
    const samples=envelope.slice(tick+lo,tick+hi+1),base=samples[0]
    result.push({...base,tick,
      radius:Math.max(...samples.map(e=>e.radius+Math.hypot(e.x-base.x,e.z-base.z))),
      yMin:Math.min(...samples.map(e=>e.yMin)),yMax:Math.max(...samples.map(e=>e.yMax)),
      criticalPossible:samples.some(e=>e.criticalPossible)})
  }
  return result
}
function directions(self,target){
  const a=Math.atan2(target.z-self.z,target.x-self.x)
  return [{x:0,z:0},...Array.from({length:16},(_,i)=>({x:Math.cos(a+i*Math.PI/8),z:Math.sin(a+i*Math.PI/8)}))]
}
// Refine only the two angular crossings of a short ground intercept. This
// adds a few directions instead of multiplying every collision route by a
// dense angular grid. These points are forecasts, never attack permission.
function contactHeadings(frame){
  const s=frame.self,t=frame.seen,o=frame.observation,v=frame.targetVelocity
  if(!o.targetGrounded||s.charge<.9||o.reach<=3||o.reach>6)return []
  const age=clamp((frame.latency?.observationAgeMs??0)/50,0,2),result=[]
  const baseAngle=Math.atan2(t.z-s.z,t.x-s.x),acceleration=(s.ground?.098:.0196)*1.3
  const drag=s.ground?.546:.91
  for(let ticks=1;ticks<=4;ticks++){
    let vx=s.vx,vz=s.vz,vy=s.ground?0:s.vy,baseX=s.x,baseY=s.y,baseZ=s.z,gain=0,increment=0
    for(let step=0;step<ticks;step++){
      baseX+=vx;baseZ+=vz;baseY+=vy;vx*=drag;vz*=drag
      if(!s.ground)vy=(vy-.08)*.98
      increment+=acceleration;gain+=increment;increment*=drag
    }
    if(Number.isFinite(frame.publicTerrain?.groundY))baseY=Math.max(baseY,frame.publicTerrain.groundY)
    const target={...t,x:t.x+v.x*(age+ticks),z:t.z+v.z*(age+ticks)}
    const distance=angle=>eyeBoxReach({...s,x:baseX+gain*Math.cos(angle),y:baseY,z:baseZ+gain*Math.sin(angle)},target)-2.95
    let left=baseAngle,fl=distance(left),count=0
    for(let i=1;i<=16;i++){
      const right=baseAngle+i*Math.PI/8,fr=distance(right)
      if(fl*fr<0||Math.abs(fl)<1e-9){
        let lo=left,hi=right,flo=fl
        for(let iteration=0;iteration<12;iteration++){
          const mid=(lo+hi)/2,fm=distance(mid)
          if(flo*fm<=0)hi=mid;else{lo=mid;flo=fm}
        }
        const angle=(lo+hi)/2
        result.push({x:Math.cos(angle),z:Math.sin(angle)})
        if(++count>=2)break
      }
      left=right;fl=fr
    }
  }
  return result
}
function route(self,heading,steps,probe,{delayTicks=0,previousHeading={x:0,z:0},jump=false}={}){
  let p={...self},vx=self.vx,vz=self.vz,vy=self.ground?0:self.vy,grounded=self.ground
  const points=[{...p}],sprint=Math.hypot(heading.x,heading.z)>.5
  let margin=Infinity
  for(let t=1;t<=steps;t++){
    const input=t<=delayTicks?previousHeading:heading
    const wasGrounded=grounded
    if(jump&&t===delayTicks+1&&grounded){
      vy=Math.fround(.42)
      if(sprint){vx+=input.x*.2;vz+=input.z*.2}
      grounded=false
    }
    const acceleration=(wasGrounded?.098:.0196)*(sprint?1.3:1)
    vx+=input.x*acceleration;vz+=input.z*acceleration
    const next={x:p.x+vx,y:p.y+vy,z:p.z+vz}
    const evidence=probe(next,p)
    if(!evidence||evidence.clear!==true||evidence.supported!==true)return null
    if(Number.isFinite(evidence.floorY)&&next.y<=evidence.floorY&&vy<=0){
      next.y=evidence.floorY;vy=0;grounded=true
    }
    margin=Math.min(margin,evidence.margin??0)
    points.push(next);p=next;vx*=wasGrounded?.546:.91;vz*=wasGrounded?.546:.91
    if(!grounded)vy=(vy-.08)*.98
  }
  return {heading,sprint,points,margin,...(jump?{jump:true}:{})}
}
function routesFor(frame,steps,probe,timing={}){
  const s=frame.self,t=frame.seen
  // Cache only deterministic candidate motion against this frozen public
  // collision snapshot. Every cycle still rebuilds the enemy envelope and
  // rechecks every critical-time clearance and selection score.
  const key=[s.x,s.y,s.z,s.vx,s.vy,s.vz,s.ground,t.x,t.y,t.z,steps,timing.delayTicks||0,
    timing.previousHeading?.x||0,timing.previousHeading?.z||0,Boolean(timing.refineContact),
    timing.refineContact?frame.publicTerrain?.groundY??'unknown':0,
    timing.refineContact?frame.targetVelocity.x:0,timing.refineContact?frame.targetVelocity.z:0,
    timing.refineContact?frame.latency?.observationAgeMs||0:0,Boolean(timing.allowJump)].join(',')
  const cache=frame.routeCache
  if(cache?.has(key))return cache.get(key)
  const headings=directions(s,t),previous=frame.previousHeading
  if(timing.refineContact)headings.push(...contactHeadings(frame))
  // Preserve an actually executed heading, not only a target-relative angular
  // grid that rotates whenever the opponent moves across us.
  if(previous&&Math.hypot(previous.x,previous.z)>.5){
    const n=Math.hypot(previous.x,previous.z);headings.push({x:previous.x/n,z:previous.z/n})
  }
  const center=frame.arenaCenter||arenaCenter(s)
  if(center){const dx=center.x-s.x,dz=center.z-s.z,n=Math.hypot(dx,dz);if(n>.1)headings.push({x:dx/n,z:dz/n})}
  const routes=headings.map(h=>route(s,h,steps,probe,timing)).filter(Boolean)
  if(timing.allowJump&&s.ground&&s.jumpAvailable===true)
    routes.push(...headings.filter(h=>Math.hypot(h.x,h.z)>.5)
      .map(h=>route(s,h,steps,probe,{...timing,jump:true})).filter(Boolean))
  if(cache){if(cache.size>=64)cache.clear();cache.set(key,routes)}
  return routes
}
function planLandingReposition(frame,probe,envelope,crit,chosen,timing,positionLagTicks){
  const s=frame.self,o=frame.observation,v=frame.targetVelocity,last=envelope.at(-1),floor=frame.targetFloorY
  // A failed dodge can have an unavoidable minimum at an OLD exposed body
  // position shared by every route. Continuing to maximise that minimum can
  // keep fleeing through the landing and the opponent's next jump. Prepare
  // contact AFTER this flight without worsening ANY remaining critical-time
  // clearance of the best existing escape. This is navigation, not safety or
  // attack permission; a newly observed jump is evaluated normally again.
  if(!chosen||!last||chosen.clearance>3.05||!crit.length||s.shieldAvailable||s.charge<.9||s.using
      ||o.reach<=3||o.reach>5||o.targetShieldRaised||o.targetShieldFacing||o.arrowThreat||v.y>=0
      ||!Number.isFinite(floor)||last.tick>4||last.yMax>floor+.3)return null
  const horizon=last.tick+5,baseline=crit.map(e=>exposedClearance(frame,chosen.points,e,positionLagTicks))
  let best=null
  for(const candidate of routesFor(frame,horizon,probe,{...timing,allowJump:false})){
    const clearances=crit.map(e=>exposedClearance(frame,candidate.points,e,positionLagTicks))
    if(clearances.some((d,i)=>d+1e-7<baseline[i]))continue
    // An old already-exposed body can dominate BOTH minima. That must not
    // hide a newly unsafe local position while turning back for contact.
    if(crit.some(e=>clearance(candidate.points[e.tick],e)+1e-7
      <Math.min(3.05,clearance(chosen.points[e.tick],e))))continue
    // Do not turn into a still-descending opponent to obtain the later goal.
    if(envelope.some(e=>eyeBoxReach(candidate.points[e.tick],{...frame.seen,
      x:e.x,y:Math.max(floor,e.y),z:e.z})<=3))continue
    for(let tick=last.tick+1;tick<=horizon;tick++){
      const dt=tick-last.tick,target={...frame.seen,x:last.x+v.x*dt,y:floor,z:last.z+v.z*dt}
      const distance=eyeBoxReach(candidate.points[tick],target)
      if(distance>3)continue
      if(distance>=2.90){
        const score=100-Math.abs(distance-2.95)*20-tick*.1
          +Math.min(candidate.margin,2)*.4+centerGain(frame,candidate.points[tick])*.2
        if(!best||score>best.score)best={heading:candidate.heading,sprint:candidate.sprint,
          margin:candidate.margin,clearance:Math.min(...clearances),
          localClearance:Math.min(...crit.map(e=>clearance(candidate.points[e.tick],e))),safe:false,
          firstContactTick:tick,firstContactReach:distance,criticalEndsAt:last.tick,
          criticalRiskNotIncreased:true,score,reason:'post-flight-contact-without-increased-critical-exposure'}
      }
      // Score the first predicted contact, never a later return from deep range.
      break
    }
  }
  return best
}
function planAirThreat(frame,probe){
  const o=frame.observation,s=frame.self,t=frame.seen,v=frame.targetVelocity
  // A hit on a grounded opponent also admits a legal same-tick jump reset.
  // This is a possible branch, never a claim to know whether space was held.
  const resetPossible=frame.allowJumpResetForecast!==false&&o.targetGrounded&&frame.targetRecentHitTicks<=2
  if(!o.visible||!o.targetAirborne&&!resetPossible||!valid({...t,vx:v.x,vy:v.y,vz:v.z}))
    return {valid:false,threat:false,reason:'no-public-airborne-target'}
  const latency=frame.latency||{},observationAgeMs=latency.observationAgeMs??0
  const budgetMs=(latency.oneWayMs??25)+(latency.serverQueueMs??50)+(latency.decisionMs??4)
  const attackDelayTicks=Math.ceil(budgetMs/50)
  // Network queue time affects when a strike can interrupt, not when our
  // local movement keys take effect. Do not freeze obsolete keys for it.
  const delayTicks=clamp(Math.ceil((latency.localControlDelayMs??0)/50),0,1)
  const observationAgeTicks=resetPossible?0:clamp((observationAgeMs+(latency.oneWayMs??25))/50,0,4)
  const envelope=ageEnvelope(airborneEnvelope({...t,vx:v.x,vy:resetPossible?.42:v.y,vz:v.z,grounded:false},
    {floorY:frame.targetFloorY??-64,positionError:frame.motionUncertainty??.04}),observationAgeTicks)
  const crit=envelope.filter(e=>e.criticalPossible),steps=envelope.length-1
  const ascentTicks=crit[0]?.tick??16
  const risingTail=!resetPossible&&v.y>0&&ascentTicks<=attackDelayTicks+1
  const timing={delayTicks,previousHeading:frame.previousHeading||{x:0,z:0},
    allowJump:s.jumpAvailable===true&&!s.shieldAvailable&&!s.using}
  const positionLagTicks=exposureTicks(frame)
  let candidates=routesFor(frame,steps,probe,timing).map(c=>({...c}))
  for(const c of candidates){
    c.localClearance=crit.length?Math.min(...crit.map(e=>clearance(c.points[e.tick],e))):Infinity
    c.clearance=crit.length?Math.min(...crit.map(e=>exposedClearance(frame,c.points,e,positionLagTicks))):Infinity
    c.nearClearance=crit.length?Math.min(...crit.slice(0,3).map(e=>exposedClearance(frame,c.points,e,positionLagTicks))):Infinity
    // Prefer sufficient clearance, then open space; do not flee indefinitely.
    const end=c.points.at(-1)
    const previous=frame.previousHeading||{x:0,z:0},continuity=(c.heading.x*previous.x+c.heading.z*previous.z)*.35
    c.score=(c.clearance>3.05?100:0)+Math.min(c.clearance,3.1)*10+Math.min(c.nearClearance,3.1)*5
      +Math.min(c.localClearance,3.2)*2+Math.min(c.margin,3)*.3+centerGain(frame,end)*1.2+continuity
  }
  // An extra evasion jump spends grounded control through the landing/handoff.
  // Merely improving a shared UNSAFE historical minimum is not evidence it
  // escapes the descending strike. Keep those routes on the ground unless the
  // complete bounded critical window, including sent positions, is safe.
  // The original confirmed counter-hop is a separate single-jump transaction.
  candidates=candidates.filter(c=>!c.jump||crit.length>0&&c.clearance>3.05)
  candidates.sort((a,b)=>b.score-a.score)
  const stationary=candidates.find(c=>c.heading.x===0&&c.heading.z===0)
  const stationaryClearance=stationary&&crit.length
    ?Math.min(...crit.map(e=>exposedClearance(frame,stationary.points,e,positionLagTicks))):0
  const threat=crit.length>0&&stationaryClearance<=3.05
  const chosen=candidates[0]||null
  // A low-charge sword tap does not provide sprint knockback. It must not
  // replace the escape route with a forward chase of a jump-reset opponent.
  const liveInterrupt=!resetPossible&&!risingTail&&v.y>0&&o.reach<=3&&!o.targetShieldFacing&&s.charge>.9
  let landingRecovery=null
  // A remote player can land and immediately jump between position packets.
  // Do not require a sampled onGround=true merely to PLAN the turn back.
  // The projected ground state is navigation-only: every remaining falling
  // envelope must stay clear, and the executor still uses the live box.
  const floor=frame.targetFloorY
  if(!s.shieldAvailable&&s.ground&&s.charge>=.9&&!s.using&&!resetPossible&&v.y<0
      &&Number.isFinite(floor)&&t.y>=floor-.02&&t.y<=floor+.25&&steps<=4
      &&!o.targetShieldRaised&&!o.targetShieldFacing&&!o.arrowThreat){
    const grounded={...frame,seen:{...t,y:floor},targetVelocity:{...v,y:0},
      observation:{...o,targetGrounded:true,targetAirborne:false}}
    const approach=planSpacing(grounded,probe)
    if(approach?.firstContactTick!==null&&approach?.firstContactTick!==undefined){
      const checked=route(s,approach.heading,Math.max(1,steps),probe,timing)
      if(checked&&crit.every(e=>exposedClearance(frame,checked.points,e,positionLagTicks)>3.05))
        landingRecovery={...approach,clearance:crit.length?Math.min(...crit.map(e=>exposedClearance(frame,checked.points,e,positionLagTicks))):Infinity,
          safe:true,reason:'checked-near-floor-intercept'}
    }
  }
  const landingReposition=!landingRecovery&&threat&&!liveInterrupt
    ?planLandingReposition(frame,probe,envelope,crit,chosen,timing,positionLagTicks):null
  const action=frame.self.shieldAvailable&&threat?'guard':liveInterrupt?'interrupt'
    :landingRecovery?'landing-recovery'
    :landingReposition?'landing-reposition'
    :threat?(chosen?.clearance>3.05?'dodge':'no-guaranteed-route'):'spacing'
  return {valid:true,threat,action,stationaryClearance,criticalTicks:crit.map(e=>e.tick),
    envelope,landingRecovery,landingReposition,route:landingRecovery||landingReposition|| (chosen?{heading:chosen.heading,sprint:chosen.sprint,jump:chosen.jump===true,clearance:chosen.clearance,
      margin:chosen.margin,localClearance:chosen.localClearance,safe:chosen.clearance>3.05}:null),
    candidateCount:candidates.length,jumpResetPossible:resetPossible,risingTail,
    timing:{budgetMs,delayTicks,attackDelayTicks,ascentTicks,observationAgeMs,observationAgeTicks,positionLagTicks},
    bound:{steering:.026,velocityError:.035,horizon:40},
    provenance:'public-position-velocity-bounded-air-envelope-v1'}
}
// Score in the same eye-to-box geometry used by the strike executor. An
// axis-aligned centre-distance target is not an exact reach target diagonally.
function planSpacing(frame,probe){
  const s=frame.self,t=frame.seen,o=frame.observation
  if(!o.visible)return null
  const dx=t.x-s.x,dz=t.z-s.z,d=Math.hypot(dx,dz),v=frame.targetVelocity
  if(d<1e-6)return null
  const closing=((s.vx-v.x)*dx+(s.vz-v.z)*dz)/d
  const latency=frame.latency||{},ageTicks=clamp((latency.observationAgeMs??0)/50,0,2)
  // Client keys apply at the next local physics step. Network/attack queue
  // time must not make the route hold obsolete keys for two extra steps.
  const delayTicks=clamp(Math.ceil((latency.localControlDelayMs??0)/50),0,1)
  const horizon=4,candidates=routesFor(frame,horizon,probe,
    {delayTicks,previousHeading:frame.previousHeading||{x:0,z:0},refineContact:!delayTicks}).map(c=>({...c}))
  // Travel back to centre never suspends contact planning just because our
  // body is finishing a knockback arc. Routes already use airborne physics;
  // actual strike legality/critical timing remains with the live executor.
  const edgeReady=o.targetGrounded&&s.charge>=.9&&!o.targetShieldRaised&&!o.targetShieldFacing&&!s.using
  const targetApproach=-(v.x*dx+v.z*dz)/d
  // Equal-speed flight has almost zero relative closing speed. Using that
  // alone made a ready fighter keep running from a pursuer instead of turn
  // into a legal first-contact route. Evaluate the checked turn itself.
  for(const c of candidates){
    const distances=c.points.slice(1).map((point,i)=>eyeBoxReach(point,
      {...t,x:t.x+v.x*(ageTicks+i+1),z:t.z+v.z*(ageTicks+i+1)}))
    const contactIndex=o.reach>3?distances.findIndex(distance=>distance<=3):-1
    c.firstContactTick=contactIndex<0?null:contactIndex+1
    c.firstContactReach=contactIndex<0?null:distances[contactIndex]
    c.closest=Math.min(...distances)
    c.minimumReach=c.closest
  }
  // A route can already cross the boundary before the old 4.5-block/2-tick
  // trigger. Score those actual route forecasts now, before approach momentum
  // makes every later choice plunge deeply inside the requested band.
  const contactSoon=candidates.some(c=>c.firstContactTick!==null)
  const pursuit=edgeReady&&targetApproach>.06&&(o.reach<=4.5||contactSoon)
  const contactRelevant=pursuit||contactSoon||o.reach-Math.max(0,closing)*horizon<=3.3
  for(const c of candidates){
    const end=c.points.at(-1),closest=c.closest,contactIndex=c.firstContactTick===null?-1:c.firstContactTick-1
    const previous=frame.previousHeading||{x:0,z:0}
    const continuity=(c.heading.x*previous.x+c.heading.z*previous.z)*.15
    // Score the FIRST engagement. The old endpoint-only score could select
    // a route that plunged inside 2.6 before returning to 3 much later.
    let contactScore=0
    if(edgeReady&&contactRelevant&&o.reach>3){
      contactScore=contactIndex<0?-Math.abs(closest-3)*4
        :c.firstContactReach>=2.90?100-Math.abs(c.firstContactReach-2.95)*20-c.firstContactTick*.1
        :pursuit?20-Math.abs(c.firstContactReach-2.95)*60-c.firstContactTick*.1
        :-20-(2.90-c.firstContactReach)*100
    }
    c.score=contactScore+Math.min(c.margin,2)*.4+centerGain(frame,end)*1.2+continuity
    // Centre is a positional preference, never permission to run through an
    // opponent while unable to stop them. The first contact forecast above
    // keeps precedence; during recharge/shield standoff preserve room and
    // approach centre tangentially instead of buying it with a free hit.
    if(!edgeReady){
      const floor=Math.min(o.reach,3.15)
      c.score-=Math.max(0,floor-c.minimumReach)*30
    }else if(o.reach<=3){
      c.score-=Math.max(0,Math.min(o.reach,2.90)-c.minimumReach)*30
    }
    if(c.margin<.6)c.score-=20
    c.imminent=edgeReady&&o.reach>3&&o.reach<=3.6&&(c.firstContactTick<=2&&c.firstContactTick!==null||closest<3.1)
  }
  candidates.sort((a,b)=>b.score-a.score)
  const c=candidates[0]
  return c?{heading:c.heading,sprint:c.sprint,margin:c.margin,targetReachBand:[2.90,3],
    center:frame.arenaCenter||arenaCenter(s),closing,firstContactTick:c.firstContactTick,
    firstContactReach:c.firstContactReach,imminent:c.imminent,
    minimumReach:c.minimumReach,
    objective:c.firstContactTick!==null&&edgeReady&&contactRelevant?(pursuit?'intercept-pursuit':'first-contact'):'arena-center',
    targetApproach,
    localDelayTicks:delayTicks,opponentAgeTicks:ageTicks}:null
}
// Supply the ORIGINAL optional short-advance branch with a real checked route.
// This does not authorize an attack: only the live execution geometry can do
// that. A route whose first physical contact skips the requested band is not
// advertised as an available precision approach.
function planShortAdvance(frame,probe){
  const o=frame.observation,s=frame.self,t=frame.seen,v=frame.targetVelocity
  if(!o.visible||!s.ground||!o.targetGrounded||o.targetAirborne||s.shieldAvailable
      ||s.charge<.999||o.reach<=3||o.reach>3.3||o.targetShieldRaised
      ||o.targetShieldFacing||o.arrowThreat||s.using)return null
  const latency=frame.latency||{}
  if((latency.observationAgeMs??0)>100)return null
  const delayTicks=Math.ceil(((latency.oneWayMs??25)+(latency.serverQueueMs??50)
    +(latency.decisionMs??4))/50)
  if(delayTicks>=3)return null
  const timing={delayTicks,previousHeading:frame.previousHeading||{x:0,z:0}}
  const candidates=routesFor(frame,3,probe,timing)
  let best=null
  for(const candidate of candidates){
    const dx=t.x-s.x,dz=t.z-s.z
    if(candidate.heading.x*dx+candidate.heading.z*dz<=Math.hypot(dx,dz)*.25||candidate.margin<.6)continue
    let previous=o.reach
    for(let tick=1;tick<candidate.points.length;tick++){
      const target={...t,x:t.x+v.x*tick,z:t.z+v.z*tick}
      const distance=eyeBoxReach(candidate.points[tick],target)
      if(distance<=3){
        if(previous>3&&tick>delayTicks&&distance>=2.90){
          const point=candidate.points[tick],prev=frame.previousHeading||{x:0,z:0}
          const score=-Math.abs(distance-2.97)*10+centerGain(frame,point)*.25
            +(candidate.heading.x*prev.x+candidate.heading.z*prev.z)*.15
          if(!best||score>best.score)best={available:true,contactTicks:tick,shieldDelay:5,
            heading:candidate.heading,sprint:candidate.sprint,predictedReach:distance,
            margin:candidate.margin,delayTicks,score,
            provenance:'public-short-advance-forecast-not-attack-permission'}
        }
        break
      }
      previous=distance
    }
  }
  return best
}
function createThreatClock({now=()=>performance.now(),evaluate=planAirThreat,hz=500}={}){
  let at=-Infinity,cached=null,key=null,recomputations=0
  return {
    reset(){at=-Infinity;cached=null;key=null;recomputations=0},
    update(frame,probe,matchId){
      const time=now(),phase=frame.observation.targetAirborne?'air'
        :frame.observation.targetGrounded&&frame.targetRecentHitTicks<=2?'possible-jump-reset':'ground'
      if(matchId!==key){this.reset();key=matchId}
      // Full bounded threat/route evaluation, not a repeated cached verdict.
      if(hz>=500||time-at>=1000/hz||cached?.phase!==phase){cached={...evaluate(frame,probe),phase,atMs:time};at=time;recomputations++}
      return cached
    },get recomputations(){return recomputations}
  }
}
module.exports={airborneEnvelope,ageEnvelope,clearance,planAirThreat,planSpacing,planShortAdvance,createThreatClock,route,arenaCenter,eyeBoxReach}
