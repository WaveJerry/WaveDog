'use strict'
// A 500Hz analysis clock is not a 500Hz packet clock. Navigation updates are
// coalesced; urgent combat/use transitions can bypass the navigation deadline.
function createOutputGate({intervalMs=50,maxPacketsPerSecond=240,transactionReserve=24}={}){
  let last=null,nextAt=-Infinity,lastSpacingTick=null,lastDefenseTick=null
  const counts={applied:0,coalesced:0,urgent:0,packetBudgetWait:0}
  return {
    reset(){last=null;nextAt=-Infinity;lastSpacingTick=null;lastDefenseTick=null;for(const k of Object.keys(counts))counts[k]=0},
    permit(c,now,{physical=false,outboundPackets=0}={}){
      // Reserve a whole synchronous attack/use transaction. Never drop a
      // random half of an attack, inventory confirmation or teleport ACK.
      if(outboundPackets+transactionReserve>maxPacketsPerSecond){
        counts.coalesced++;counts.packetBudgetWait++;return false
      }
      const rangedChanged=c.ranged!==last?.ranged||c.rangedId!==last?.rangedId
      const spacingUrgent=c.spacingUrgent&&Number.isSafeInteger(c.decidedTick)&&lastSpacingTick!==c.decidedTick
      const oldHeading=last?.worldHeading,newHeading=c.worldHeading
      const defenseChanged=!last?.airDodgeUrgent||Boolean(newHeading&&(!oldHeading
        ||newHeading.x*oldHeading.x+newHeading.z*oldHeading.z<.95))
      const defenseUrgent=c.airDodgeUrgent&&defenseChanged&&Number.isSafeInteger(c.decidedTick)
        &&lastDefenseTick!==c.decidedTick
      const urgent=Boolean(c.attack||c.doubleAttack||c.shield&&!last?.shield||c.landingHandoff&&!last?.landingHandoff
        ||c.jump&&!last?.jump||c.rangedRelease||c.ranged&&rangedChanged
        ||c.precisionApproach&&!last?.precisionApproach||spacingUrgent||defenseUrgent
        ||last&&c.slot!==last.slot)
      if(!urgent&&now<nextAt){counts.coalesced++;return false}
      last={...c};nextAt=now+intervalMs;counts.applied++;if(urgent)counts.urgent++
      if(spacingUrgent)lastSpacingTick=c.decidedTick
      if(defenseUrgent)lastDefenseTick=c.decidedTick
      return true
    },get counts(){return {...counts}}
  }
}
module.exports={createOutputGate}
