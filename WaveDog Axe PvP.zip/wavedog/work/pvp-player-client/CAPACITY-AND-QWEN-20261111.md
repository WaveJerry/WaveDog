# 2026-11-11 主服对练承载与 Qwen 状态

## 当前运行

- 主服：`D:/Walt Disney/Minecraft-1.21.1-Server`，Paper 1.21.1。常驻目标为 18 对、36 名普通离线协议玩家；`/selfplay status` 的 active 会在局间短暂低于 18。
- 开局双方相距 14 格。主服 `plugins/WaveDogSelfPlayGate/bouts.jsonl` 的 `start` 记录含 `opening_distance_blocks:14`。每局前后清理竞技场掉落物。
- 仅 NBot01..60 的玩家视距与模拟距离设为 2；真人玩家继续使用原设置。没有增加 JVM 堆，因为 18 对实测主服平均约 4–5 ms/tick，24 对的卡顿不是已证实的堆不足。
- 每名选手每局有独立 GRU64 actor、对手身份和 Qwen 教练上下文。真实死亡判胜后双方 PPO+Adam 更新同一个 `new-learning/models/recurrent-ppo.json` 检查点。Qwen 权重没有微调。
- 每局原始摘要写入 `new-learning/selfplay/rounds.jsonl`，每名选手上下文写入 `coach-contexts.jsonl`。新局带跨重启唯一 `matchId`；旧局按主服启动时间分段恢复，避免场地局号重置后漏复盘。共享 Qwen 每批最多 32 局复盘，结果写入 `shared-lessons.jsonl`；复盘失败的局保留原始记录供重启补处理。Qwen 当前 `-c 6144 -np 2`，每槽 3072 token。Qwen 原句保留为 `qwenSuggestion`，进入后续教练的共享经验由可观测计数提出待验证实验。
- 玩家 `/qwen <问题>` 只访问本机 Qwen。OP 的 `/qwen save <经验>` 把待验证经验写入 `new-learning/selfplay/player-experience.jsonl`，后续教练、共享复盘和游戏对话会读取。聊天历史在 `player-conversations.jsonl`。已保存“普通输出倾向高蓄力，保留必要轻击”。

## 实测并发

| 同时对数 | 实测结果 |
| --- | --- |
| 6 | 45 局原生死亡结算，无机器人断线，平均约 2.9 ms/tick。 |
| 12 | 49 局原生死亡结算，无机器人断线，平均约 4.2 ms/tick。 |
| 18 | 57 局以上连续完赛、无机器人断线，平均约 4.2–4.5 ms/tick；后续常驻继续增长。 |
| 24 | 约 23 对开战时用户实际感觉卡顿，立即停止；这档未完成局标记为 incomplete，不进训练。 |
| 30 | 未做完整实战压测；24 对已影响真人体验，因此不宣称 30 对可承载。 |

18 对是当前实测可用档位；19–23 对的精确上限未逐一压测。早先 60 名机器人一度登录不代表 30 对稳定实战。

## 验证与限制

- 新 `/qwen` 插件已在主服加载，普通 1.21.1 协议玩家实际得到本地 Qwen 回答；两条聊天记录落盘。当前插件只把有计数依据的共享经验送入游戏对话；JAR SHA256 为 `fe56d6f5effcbf22863f2193fe86945d8a86613bc74509993abdd127b1329a76`。
- `/qwen save` 的临时 OP 测试被自动审批拒绝，因为授予测试机器人完整 OP 权限过宽；没有执行该测试。保存路径已编译、命令已注册，首条用户经验文件存在；游戏内 OP 保存尚待有权限的真人验证。
- 风格和重点是课程输入及 Qwen 的待验证假设，不等于已学会对应招式。当前原始摘要有出刀、空挥与弓弩计数，不足以单独证明真实破盾、暴击或连招质量。
- 无效的旧假玩家练习没有恢复。24 对超载档中断局没有计入 PPO。主服重启前后局号碰撞曾漏掉 Qwen 复盘；原始局和 PPO 更新均保留，已重新入队补处理。早期 Qwen 生成的空泛或错误句子仍保存在原始审计记录，不再选入后续教练和游戏对话。

## 位置与恢复

- 对练控制器：`work/pvp-player-client/selfplay.js`；原生裁判：`selfplay-src/local/wavedog/selfplay/SelfPlayGate.java`；游戏对话：`qwen-dialogue-src/local/wavedog/qwen/QwenDialogue.java`。
- GRU 模型：`work/pvp-player-client/new-learning/models/recurrent-ppo.json`。训练数据与 Qwen 记忆：`work/pvp-player-client/new-learning/selfplay/`。部署前及调整前备份：`new-learning/backups/`。
- 若主服重启，先运行 `python work/pvp-neural-lab/start-local-model.py`，确认主服就绪后在 `work/pvp-player-client` 执行 `node selfplay.js --bots=36`。不要同时运行第二个控制器，避免共享检查点竞争写入。当前后台进程已启动，无需再执行。
