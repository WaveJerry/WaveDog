package local.wavedog.nativecontrol;

import com.mojang.authlib.GameProfile;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import java.net.InetSocketAddress;
import java.util.function.Consumer;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.phys.Vec3;

/** One native player, one native physics step per server tick, no network client. */
final class NativePlayer extends ServerPlayer {
    int lastPhysicsTick=Integer.MIN_VALUE;
    Vec3 queuedMotion;
    static final class HurtContext {
        boolean blocked,positiveDamage,velocity;
    }
    HurtContext hurtContext;long restoredBlockedMotion;
    NativePlayer(MinecraftServer server,ServerLevel level,GameProfile profile){
        super(server,level,profile,new ClientInformation("zh_cn",2,
            net.minecraft.world.entity.player.ChatVisiblity.FULL,true,127,
            net.minecraft.world.entity.HumanoidArm.RIGHT,false,false,net.minecraft.server.level.ParticleStatus.ALL));
    }
    @Override public boolean isClientAuthoritative(){return false;}
    @Override protected boolean isLocalClientAuthoritative(){return false;}
    @Override public boolean hurtServer(ServerLevel level,net.minecraft.world.damagesource.DamageSource source,float damage){
        var previous=hurtContext;var hit=new HurtContext();hurtContext=hit;Vec3 before=getDeltaMovement();
        try{return super.hurtServer(level,source,damage);}
        finally{
            // Fully blocked damage can leave server-only velocity even though
            // vanilla sends no impulse to a human client. Native physics must
            // reproduce that client's unchanged motion, not integrate a ghost hit.
            if(hit.blocked&&!hit.positiveDamage&&!hit.velocity){setDeltaMovement(before);restoredBlockedMotion++;}
            hurtContext=previous;
        }
    }
    void physics(int tick){
        if(tick==lastPhysicsTick)throw new IllegalStateException("Duplicate native player physics tick");
        lastPhysicsTick=tick;
        if(queuedMotion!=null){setDeltaMovement(queuedMotion);queuedMotion=null;}
        setSpeed((float)getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED));
        double x=getX(),y=getY(),z=getZ();
        super.doTick();
        if(isAlive())doCheckFallDamage(getX()-x,getY()-y,getZ()-z,onGround());
    }
    static final class LocalConnection extends net.minecraft.network.Connection {
        Consumer<Packet<?>> sink=packet->{};
        LocalConnection(){super(PacketFlow.SERVERBOUND);channel=new EmbeddedChannel();}
        @Override public java.net.SocketAddress getRemoteAddress(){return new InetSocketAddress("127.0.0.1",0);}
        @Override public boolean isConnected(){return true;}
        @Override public boolean isMemoryConnection(){return true;}
        @Override public void send(Packet<?> packet){sink.accept(packet);}
        @Override public void send(Packet<?> packet,ChannelFutureListener listener){sink.accept(packet);}
        @Override public void send(Packet<?> packet,ChannelFutureListener listener,boolean flush){sink.accept(packet);}
    }
    static final class LocalListener extends ServerGamePacketListenerImpl {
        final NativePlayer nativePlayer;
        LocalListener(MinecraftServer server,LocalConnection connection,NativePlayer player){
            super(server,connection,player,CommonListenerCookie.createInitial(player.getGameProfile(),false));
            nativePlayer=player;connection.sink=this::send;
        }
        @Override public void tick(){} // Owner calls NativePlayer.physics exactly once.
        @Override public boolean hasClientLoaded(){return true;}
        @Override public void send(Packet<?> packet){
            // Vanilla temporarily restores the pre-hit server velocity after
            // sending this packet to a human client. Apply its actual payload
            // once, before native physics, to supply the missing local client.
            if(packet instanceof ClientboundSetEntityMotionPacket motion&&motion.getId()==nativePlayer.getId()){
                nativePlayer.queuedMotion=motion.getMovement();
                if(nativePlayer.hurtContext!=null)nativePlayer.hurtContext.velocity=true;
            }
        }
        @Override public void send(Packet<?> packet,ChannelFutureListener listener){send(packet);}
    }
}
