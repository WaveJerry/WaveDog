package local.wavedog.entry;

import java.lang.reflect.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Switch;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;

/** Self-service entry only. The existing core owns readiness, setup and learning. */
public final class ArenaEntry extends JavaPlugin implements Listener {
    private static final String TAG="wavedog_arena_entry_v1";
    private final Map<UUID,Integer> lastPress=new HashMap<>();
    @Override public void onEnable(){
        getConfig().addDefault("world","world");
        getConfig().addDefault("x",992);getConfig().addDefault("y",227);getConfig().addDefault("z",1032);
        getConfig().options().copyDefaults(true);saveConfig();
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("wdarena")).setExecutor(this);
    }
    private Block entry(){
        World w=Bukkit.getWorld(getConfig().getString("world","world"));
        if(w==null)throw new IllegalStateException("Arena world unavailable");
        return w.getBlockAt(getConfig().getInt("x"),getConfig().getInt("y"),getConfig().getInt("z"));
    }
    private boolean inArena(Player p){
        Location l=p.getLocation();
        return l.getWorld()==entry().getWorld()&&l.getX()>=991&&l.getX()<=1038
            &&l.getZ()>=991&&l.getZ()<=1038&&l.getY()>=220&&l.getY()<=230;
    }
    private void route(Player player,String sub){
        boolean son=sub.endsWith("-son");
        String coreName=son?"wavedogson":"wavedog_punengbho";
        PluginCommand core=Bukkit.getPluginCommand(coreName);
        var plugin=Bukkit.getPluginManager().getPlugin(son?"WaveDogSonCore":"PunengbhoProtocolCore");
        if(core==null||plugin==null||!plugin.isEnabled()||core.getPlugin()!=plugin){
            player.sendMessage("§cWaveDog 核心未就绪，请稍后再试。");return;
        }
        // A narrowly scoped sender forwards all feedback to the actual clicker.
        // It grants no player permission and can only request their own duel.
        CommandSender feedback=(CommandSender)Proxy.newProxyInstance(CommandSender.class.getClassLoader(),
            new Class<?>[]{CommandSender.class},(proxy,method,args)->{
                if(method.getName().equals("hasPermission")&&args!=null&&args.length==1
                    &&args[0] instanceof String permission&&permission.equals("wavedog.control"))return true;
                try{return method.invoke(player,args);}
                catch(InvocationTargetException e){throw e.getCause();}
            });
        core.execute(feedback,coreName,sub.startsWith("duel")?new String[]{"duel",player.getName()}:new String[]{"status"});
    }
    @EventHandler(priority=EventPriority.HIGHEST)
    public void press(PlayerInteractEvent e){
        if(e.getAction()!=Action.RIGHT_CLICK_BLOCK||e.getHand()!=EquipmentSlot.HAND
            ||e.getClickedBlock()==null||!(e.getClickedBlock().equals(entry())||e.getClickedBlock().equals(entry().getRelative(0,0,2))||e.getClickedBlock().equals(entry().getRelative(0,0,-2)))
            ||e.getClickedBlock().getType()!=Material.STONE_BUTTON)return;
        e.setUseInteractedBlock(Event.Result.DENY);e.setUseItemInHand(Event.Result.DENY);
        Player p=e.getPlayer();int now=Bukkit.getCurrentTick();
        if(p.hasMetadata("wavedog-duel-owner")){p.sendMessage("§e当前对局结束并保存后，才可再开局或领取装备。");return;}
        if(now-lastPress.getOrDefault(p.getUniqueId(),-1000)<10)return;
        lastPress.put(p.getUniqueId(),now);
        if(e.getClickedBlock().equals(entry().getRelative(0,0,2))){
            var auth=Bukkit.getPluginManager().getPlugin("AuthMe");
            if(auth!=null)try{
                Class<?> api=Class.forName("fr.xephi.authme.api.v3.AuthMeApi",true,auth.getClass().getClassLoader());
                Object instance=api.getMethod("getInstance").invoke(null);
                if(!(boolean)api.getMethod("isAuthenticated",Player.class).invoke(instance,p)){
                    p.sendMessage("§e请先登录再领取装备。");return;
                }
            }catch(Exception error){p.sendMessage("§c暂时无法确认登录状态。");return;}
            if(p.getGameMode()!=GameMode.SURVIVAL||p.isDead()||p.getName().equals("WaveDog")||p.getName().equals("WaveDogSon")||p.getName().equals("WaveDog_test")||p.getName().startsWith("NBot"))return;
            var core=Bukkit.getPluginManager().getPlugin("PunengbhoProtocolCore");
            if(core==null||!core.isEnabled()){p.sendMessage("§c对局核心未就绪，暂不初始化装备。");return;}
            try{
                Field opponent=core.getClass().getDeclaredField("opponent"),active=core.getClass().getDeclaredField("active"),preparing=core.getClass().getDeclaredField("preparing");
                opponent.setAccessible(true);active.setAccessible(true);preparing.setAccessible(true);
                if(p.getName().equals(opponent.get(core))&&(active.getBoolean(core)||preparing.getBoolean(core))){
                    p.sendMessage("§e正在对局或准备中，结束后再领取 Kit。");return;
                }
            }catch(ReflectiveOperationException error){p.sendMessage("§c无法确认对局状态，暂不初始化装备。");return;}
            for(var value:p.getMetadata("wavedog-last-combat"))if(value.getOwningPlugin()==core&&now-value.asInt()<100){
                p.sendMessage("§e刚刚正在交战，请脱离战斗 5 秒后再初始化 Kit。");return;
            }
            var inventory=p.getInventory();
            inventory.clear();
            inventory.setItem(0,new ItemStack(Material.DIAMOND_SWORD));inventory.setItem(1,new ItemStack(Material.BOW));
            inventory.setItem(2,new ItemStack(Material.ARROW,5));inventory.setItem(7,new ItemStack(Material.DIAMOND_AXE));
            ItemStack crossbow=new ItemStack(Material.CROSSBOW);CrossbowMeta meta=(CrossbowMeta)crossbow.getItemMeta();
            meta.addChargedProjectile(new ItemStack(Material.ARROW));crossbow.setItemMeta(meta);inventory.setItem(4,crossbow);
            inventory.setItemInOffHand(new ItemStack(Material.SHIELD));inventory.setHeldItemSlot(7);
            inventory.setHelmet(new ItemStack(Material.DIAMOND_HELMET));inventory.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
            inventory.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));inventory.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
            for(var effect:p.getActivePotionEffects())p.removePotionEffect(effect.getType());
            p.setAbsorptionAmount(0);p.setHealth(Math.min(20,p.getMaxHealth()));p.setFoodLevel(20);p.setSaturation(5);p.setExhaustion(0);
            p.setFireTicks(0);p.setFallDistance(0);p.setCooldown(Material.SHIELD,0);p.setNoDamageTicks(0);
            p.updateInventory();p.sendMessage("§b盾斧 Kit 已完整初始化：满血、满饥饿、盾冷却恢复，剑斧盾弓弩箭及钻石护甲齐全。");
            getLogger().info("Arena kit button: "+p.getName());return;
        }
        boolean son=e.getClickedBlock().equals(entry().getRelative(0,0,-2));
        getLogger().info("Arena duel button: "+p.getName()+"; bot="+(son?"WaveDogson":"WaveDog")+"; op="+p.isOp());route(p,son?"duel-son":"duel");
    }
    private void panel(World world,double x,double y,double z,String text){
        world.spawn(new Location(world,x,y,z),TextDisplay.class,d->{
            d.addScoreboardTag(TAG);d.setText(text);d.setBillboard(Display.Billboard.CENTER);
            d.setLineWidth(300);d.setShadowed(true);d.setPersistent(true);
        });
    }
    private void install(CommandSender sender){
        Block previous=entry();
        // The initial site was inside vanilla's spawn-protection=16 square,
        // which rejects non-OP interactions before the Bukkit click handler.
        // Keep server protection and move just this button to the arena wall
        // beyond that square. No player permission or protected area changes.
        if(getConfig().getInt("x")==992&&getConfig().getInt("z")==1014){
            getConfig().set("z",1032);saveConfig();
        }
        if(getConfig().getInt("y")==222){getConfig().set("y",227);saveConfig();}
        Block button=entry();World world=button.getWorld();
        if(!button.getType().isAir()&&button.getType()!=Material.STONE_BUTTON){
            sender.sendMessage("§c入口位置已有其他方块，拒绝覆盖。");return;
        }
        if(!button.getRelative(-1,0,0).getType().isSolid()){
            sender.sendMessage("§c入口缺少支撑墙，未放置。");return;
        }
        Block kit=button.getRelative(0,0,2);
        Block son=button.getRelative(0,0,-2);
        if((!son.getType().isAir()&&son.getType()!=Material.STONE_BUTTON)||!son.getRelative(-1,0,0).getType().isSolid()){
            sender.sendMessage("§cWaveDogson 按钮位置被占用或缺少支撑，拒绝覆盖。");return;
        }
        if((!kit.getType().isAir()&&kit.getType()!=Material.STONE_BUTTON)||!kit.getRelative(-1,0,0).getType().isSolid()){
            sender.sendMessage("§cKit按钮位置被占用或缺少支撑，拒绝覆盖。");return;
        }
        Switch data=(Switch)Bukkit.createBlockData(Material.STONE_BUTTON);
        data.setFace(Switch.Face.WALL);data.setFacing(org.bukkit.block.BlockFace.EAST);
        button.setBlockData(data,false);
        kit.setBlockData(data.clone(),false);
        son.setBlockData(data.clone(),false);
        if(!previous.equals(button))for(int dz:new int[]{-2,0,2}){
            Block old=previous.getRelative(0,0,dz);if(old.getType()==Material.STONE_BUTTON)old.setType(Material.AIR,false);
        }
        int removed=0;
        for(TextDisplay d:world.getEntitiesByClass(TextDisplay.class)){
            Location l=d.getLocation();
            if(l.getX()<990||l.getX()>1039||l.getZ()<990||l.getZ()>1039||l.getY()<220||l.getY()>235)continue;
            String text=d.getText();
            if(d.getScoreboardTags().contains(TAG)||d.getScoreboardTags().contains("wavedog_pvp_guide_20261113")
                ||text.contains("/pvpai")||text.contains("/selfplay")||text.contains("/wavedog")||text.contains("/qwen")){
                d.remove();removed++;
            }
        }
        panel(world,993.2,229,1032.5,"§b§l对战 WaveDog\n§f右键：进入下方竞技场对战\n§7盾斧 Kit · 10 秒玻璃罩准备");
        panel(world,993.2,229,1029.5,"§e§l对战 WaveDogSon · UHC\n§f右键：双方初始化 UHC Kit 并入场\n§7记录保存后开放 · 10 秒玻璃罩准备");
        panel(world,993.2,229,1035.5,"§a§l领取盾斧 Kit\n§f右键：清空背包并补齐整套装备\n§7满血满饥饿 · 弩已装填");
        world.save();sender.sendMessage("§b按钮已移到屏障上方：992 227 1030/1032/1034；仅保留三块按钮说明，清除旧说明 "+removed+" 块。");
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        String sub=args.length==1?args[0].toLowerCase(Locale.ROOT):"help";
        if(sub.equals("returnpoint")){
            if(!sender.isOp()&&!(sender instanceof ConsoleCommandSender))return true;
            // Also apply an explicit administrator edit of the pinned point.
            reloadConfig();
            // Pin ONCE. Subsequent /setworldspawn changes must not move the
            // duel lobby; both referees read this shared in-memory config.
            if(!getConfig().isConfigurationSection("duel-return")){
                World world=Bukkit.getWorld(getConfig().getString("world","world"));
                if(world==null){sender.sendMessage("§c竞技场世界未加载。");return true;}
                Location at=world.getSpawnLocation();
                getConfig().set("duel-return.world",world.getName());
                getConfig().set("duel-return.x",at.getBlockX()+.5);
                getConfig().set("duel-return.y",at.getY());
                getConfig().set("duel-return.z",at.getBlockZ()+.5);
                getConfig().set("duel-return.yaw",at.getYaw());getConfig().set("duel-return.pitch",0);
                saveConfig();
            }
            sender.sendMessage("Fixed duel return: "+getConfig().getConfigurationSection("duel-return").getValues(false));
            return true;
        }
        if(sub.equals("install")){
            if(sender.isOp()||sender instanceof ConsoleCommandSender)install(sender);
            else sender.sendMessage("§c仅管理员可安装入口。");return true;
        }
        if(!(sender instanceof Player p)){sender.sendMessage("/wdarena install；玩家可用 /wdarena join | status");return true;}
        if(sub.equals("status")){route(p,"status");return true;}
        if(sub.equals("join")){
            if(!p.hasPermission("wavedog.control")){p.sendMessage("§e对战指令仅限管理员。所有玩家请右键场内西南墙上的开战按钮。");return true;}
            if(!inArena(p)){p.sendMessage("§e请进入主竞技场，或右键场内西墙的开战按钮。");return true;}
            route(p,"duel");return true;
        }
        p.sendMessage("§b右键主竞技场西墙石按钮，或 /wdarena join；/wdarena status 查看状态。");return true;
    }
}
