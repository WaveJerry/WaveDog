# WaveDog 我的世界 PVP 机器人

这是「主场优势版」，包含服务端玩家 WaveDog 和 WaveDogSon、Son 控制逻辑、竞技场插件和冻结的 GRU + GTrXL 剑斗模型。策略 SHA-256 为 `d097d42318817f90a8bddee4388ab1a6629fd2813440ba74148a009037abdeb9`。

- 真人和机器人在对局中统一按服务端眼睛到对手碰撞箱最近点判定近战，最多 3.00 格。
- 手持满蓄力斧头挡下近战且盾未破时，在合法的反击窗口偷一刀并立即重举盾。
- 探测插件的发布配置为 500 Hz 目标。弩、剑斗和移动使用该版原有策略。

## 安装

1. 准备 Windows x64、Paper 1.21.11、Java 21 和 Node.js。
2. 将本仓库解压到固定目录，在 `work/pvp-dual-brain` 运行 `npm ci --omit=dev`。
3. 关闭目标服务器，把仓库 `plugins` 下的插件与配置合并到目标服。身份 JSON 使用示例 UUID 和默认外观，可按目标服配置。
4. 启动 Java 时，在 `-jar` 前添加 `"-Dwavedog.workspace=本仓库绝对路径"` 和 `"-Dwavedog.node=node.exe绝对路径"`。
5. 套用兼容的竞技场地图，或按目标世界调整竞技场位置及配置。启动后在控制台检查 `wdnative status` 和 `wdneural`。对战入口为 `/wavedog duel 玩家名` 和 `/wavedogson duel 玩家名`。

`plugins` 提供编译后的发布插件。可阅读或重编译的 Java、JavaScript 源码位于 `work`。原生 Java 构建使用 Paper 库和 Javet 4.1.7，构建脚本的本地路径需要按机器配置。ZIP 不含 Paper 服务端、世界存档、玩家数据、登录凭据、对局日志或 `node_modules`。
