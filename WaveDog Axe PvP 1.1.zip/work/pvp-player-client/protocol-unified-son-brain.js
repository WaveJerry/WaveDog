'use strict'
// Exactly one combat phase chooses a complete command. Shared helpers only
// propose geometry, trajectories or model actions; none owns an executor.
const {eyeBoxReach,route}=require('./protocol-legacy86-threat')
const {syncRanged,rangedApplied}=require('./protocol-legacy86-ranged')
const {criticalReply}=require('../wavedog-protocol/ground-son-critical.cjs')
const {planBShieldAttack}=require('./protocol-son-shield-script')
const {planArrowDodge}=require('./wavedog-arrow-predictor')
const PHASES=Object.freeze({A:'A',B:'B',SWORD:'SWORD'})
const PUNISHMENT_ENTRY=2.90
const ESCAPE_MARGIN=.04

// Compare the defender's route to the first reachable falling hit. A moment
// inside 2.90 during ascent can still be safe if the route clears in time.
function retreatCriticalWindow(frame,probe,movement,{steering=false}={}){
 const own=frame.self,enemy=frame.seen,o=frame.observation,v=frame.targetVelocity
 const reach=frame.combatGeometry?.opponentBaseRange??3
 const latency=frame.latency?.opponentRttMs??0
 const visibleDelay=Math.min(4,Math.max(1,Math.ceil(latency/100)+1))
 const horizon=12, floor=frame.targetFloorY??own.y
 const displacement=movement?.sprint?route(own,movement.heading,horizon,probe):null
 const points=displacement?.points
 let x=enemy.x,y=enemy.y,z=enemy.z,vx=v.x,vz=v.z
 const airborne=o.targetAirborne&&enemy.y>floor+.015
 const dx=own.x-x,dz=own.z-z,length=Math.max(.001,Math.hypot(dx,dz))
 const toward=(vx*dx+vz*dz)/length
 let vy=airborne?v.y:.42
 if(!airborne&&toward>.08){vx+=.2*dx/length;vz+=.2*dz/length}
 let firstCriticalTick=null,minimumReach=Infinity,futureReach=Infinity
 for(let tick=0;tick<=horizon;tick++){
  if(tick>0&&y<=floor+.015&&vy<=0)break
  if(vy<(steering?.04:-.015)){
   const attacker={...enemy,x,y,z}
   const oldest=Math.max(0,tick-visibleDelay)
   let distance=Infinity
   for(let i=oldest;i<=tick;i++)distance=Math.min(distance,eyeBoxReach(attacker,points?.[i]??own))
   for(const past of frame.combatGeometry?.defenseCandidates??[]){
    if(past.ticksRemaining>=tick)distance=Math.min(distance,eyeBoxReach(attacker,{...own,...past}))
   }
   if(steering)distance-=.035*tick+.013*tick*(tick+1)
   minimumReach=Math.min(minimumReach,distance)
   if(tick>0)futureReach=Math.min(futureReach,distance)
   if(distance<=reach+ESCAPE_MARGIN&&firstCriticalTick===null)firstCriticalTick=tick
  }
  x+=vx;y+=vy;z+=vz
  vx*=.91;vz*=.91;vy=(vy-.08)*.98
 }
 return {firstCriticalTick,minimumReach:Number.isFinite(minimumReach)?minimumReach:null,visibleDelay,
  futureReach:Number.isFinite(futureReach)?futureReach:null,routeClear:Boolean(points),safe:Boolean(points&&firstCriticalTick===null)}
}

function drawBSteal(s,tick){
 if(tick<s.nextBStealTick)return false
 let draw=s.bStealSeed
 s.bStealSeed=(draw+0x9e3779b9)>>>0
 draw=Math.imul(draw^(draw>>>16),0x21f0aaad)
 draw=Math.imul(draw^(draw>>>15),0x735a2d97)
 draw=(draw^(draw>>>15))>>>0
 s.nextBStealTick=tick+8+(draw>>>8)%9
 return draw/0x100000000<1/3
}

function createUnifiedSonBrain({profile,helpers:h}){
 let current=null
 function createState(opponent,fighter='Punengbho'){
  return {opponent,fighter,mode:PHASES.A,decisionVersion:0,nextId:1,pending:new Map(),
   lastAttempt:-1000,lastGroundAttempt:-1000,lastAxeStrikeTick:-1000,lastEnemyAttack:-1000,
   lastBlock:-1000,spentBlock:-1000,lastStunAt:-1000,lastHit:-1000,lastDamage:-1000,
   closeFight:null,punishmentShield:null,engagementAxeDone:false,separatedSince:null,retreating:false,exitRun:null,
   bStealSeed:Math.floor(Math.random()*0x100000000),nextBStealTick:-1000,
   rangedSync:null,previousShield:false,shieldSeenAt:-1000,runJumpRecovery:null}
 }
 function transition(s,mode,tick,reason){
  if(s.mode===mode)return
  s.mode=mode;s.phaseEnteredAt=tick;s.phaseReason=reason
  s.retreating=false
  s.closeFight=mode===PHASES.SWORD?{enteredAt:tick,firstHitDone:false,afterStunAt:null,unified:true,
   axeOpenerDone:Boolean(s.engagementAxeDone),reason}:null
  s.punishmentShield=mode===PHASES.B?{enteredAt:tick,reason:'uncovered-critical-window-after-retreat-entry'}:null
  s.swordExitArmed=null
 }
 function neutral(tick){return {kind:'legacy86-ground',phase:'GROUND_CONTROL',combatMode:'A',slot:7,
  offhand:'shield',shield:false,attack:false,doubleAttack:false,critical:false,jump:false,sneak:false,
  ranged:null,forward:0,side:0,sprint:false,worldHeading:null,keepLook:false,keepTargetLook:true,
  decidedTick:tick,ppoEligible:false,spacingProfile:'axe',rangedShieldOnly:true}}
 function moveCommand(c,move){return {...c,worldHeading:move?.heading||null,sprint:Boolean(move?.sprint),motionRetreat:Boolean(move?.retreat),
  keepTargetLook:!move?.retreat&&move?.reason!=='brake-before-first-contact',forward:0,side:0}}
 function approachBrake(frame,probe,movement){
  if(!movement||movement.retreat||frame.observation.reach<=3||frame.observation.reach>4.5)return movement
  const a=frame.self,t=frame.seen,v=frame.targetVelocity
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const inward=-(v.x*dx+v.z*dz)/n
  if(inward<.08)return movement
  const assess=heading=>{
   const path=route(a,heading,1,probe);if(!path)return null
   const next=eyeBoxReach(path.points[1],{...t,x:t.x+v.x,z:t.z+v.z})
   return {heading,next}
  }
  const forward=assess(movement.heading)
  if(!forward||forward.next>=2.95)return movement
  const options=[{x:-dx/n,z:-dz/n},{x:-dz/n,z:dx/n},{x:dz/n,z:-dx/n}].map(assess).filter(Boolean)
  options.sort((a,b)=>(a.next<2.95)-(b.next<2.95)||Math.abs(a.next-2.98)-Math.abs(b.next-2.98))
  const best=options[0]
  return best&&best.next>forward.next?{...movement,heading:best.heading,sprint:true,retreat:false,reason:'brake-before-first-contact',
   predictedNextReach:best.next,originalPredictedNextReach:forward.next}:movement
 }
 function rangedDefense(frame,probe,base){
  const a=frame.self,o=frame.observation,arrow=o.arrowThreat
  if(arrow){
   const delay=a.shielding?0:Math.max(0,5-(frame.usingKind==='shield'?a.useTicks||0:0))+(o.offhandShieldReady?0:1)
   const freshCrossbow=frame.preserveRangedMovement&&o.loaded&&o.targetShotWeapon==='crossbow'&&o.tick-o.targetShotTick<=3
   const canShield=!arrow.piercing&&a.shieldAvailable&&(a.shielding||arrow.time>=delay)
   const ground=(!canShield||freshCrossbow)?planArrowDodge(frame,probe,base,{allowJump:false}):null
   if(canShield&&(!freshCrossbow||ground?.predictedHits!==0))return {...neutral(o.tick),slot:a.held,
    kind:'legacy86-guard',shield:true,arrowYaw:arrow.shieldYaw??arrow.yaw,keepTargetLook:true,intent:'arrow-shield'}
   const aerial=ground?.predictedHits!==0&&!freshCrossbow&&arrow.time>=2
     ?planArrowDodge(frame,probe,base,{allowJump:'compare'}):null
   const dodge=aerial?.predictedHits===0?aerial:ground
   if(dodge)return {...neutral(o.tick),slot:a.held,worldHeading:dodge.heading,sprint:dodge.sprint,
    jump:Boolean(dodge.jump&&a.ground&&a.vy<=.001),keepLook:false,keepTargetLook:!dodge.sprint,intent:'arrow-dodge'}
  }
  if(o.visible&&o.targetBow&&a.shieldAvailable)return {...neutral(o.tick),slot:a.held,
   kind:'legacy86-guard',shield:true,intent:'ranged-shield'}
  return null
 }
 function criticalFootwork(frame,probe,response,planned){
  const a=frame.self,t=frame.seen,o=frame.observation
  if(!response.threat||response.criticalEta>8||!o.visible||o.otherReach>5.2
      ||!/(?:_AXE|_SWORD)$/.test(t.held||''))return null
  const enemyCharge=t.attackChargeAtHit??t.charge??1
  const enemyAttackSpeed=t.attackSpeed??(/_AXE$/.test(t.held)?1:1.6)
  if(enemyCharge+response.criticalEta*enemyAttackSpeed/20<=.9)return null
  const dx=t.x-a.x,dz=t.z-a.z,distance=Math.hypot(dx,dz)
  if(distance<.001)return null
  const x=dx/distance,z=dz/distance
  const headings=[{x:-x,z:-z},{x:(-x-z)*Math.SQRT1_2,z:(-z+x)*Math.SQRT1_2},
   {x:(-x+z)*Math.SQRT1_2,z:(-z-x)*Math.SQRT1_2},{x:-z,z:x},{x:z,z:-x}]
  const baseline=retreatCriticalWindow(frame,probe,planned,{steering:true})
  if(baseline.firstCriticalTick===null)return null
  let best=null
  for(const heading of headings){
   const movement={heading,sprint:true,retreat:true,reason:'avoid-reachable-critical'}
   const window=retreatCriticalWindow(frame,probe,movement,{steering:true})
   if(!window.routeClear)continue
   const eta=window.firstCriticalTick??Infinity,previous=best?.window.firstCriticalTick??Infinity
   if(!best||eta>previous||eta===previous&&(window.futureReach??Infinity)>(best.window.futureReach??Infinity))
    best={...movement,window}
  }
  return {baseline,escape:best}
 }
 function commitDecision(s,p){
  if(p.baseStateVersion!==s.decisionVersion)return false
  Object.assign(s,p.statePatch);s.decisionVersion++
  if(p.command.attack)p.command.attackId=s.nextId++
  p.committedStateVersion=s.decisionVersion;return true
 }
 function decide(live,frame,probe,tick,{preview=false,isCurrent=null,transactional=false}={}){
  if(current!==live)throw Error('Unified Son bout was not reset')
  if(!preview)for(const [id,p] of live.pending)if(tick-p.tick>=3)live.pending.delete(id)
  const version=live.decisionVersion,s={...live,closeFight:live.closeFight?{...live.closeFight}:null,
   punishmentShield:live.punishmentShield?{...live.punishmentShield}:null,
   rangedSync:live.rangedSync?structuredClone(live.rangedSync):undefined}
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  const charge=a.attackChargeAtHit??a.charge,damageReady=!Number.isFinite(t.noDamageTicks)||t.noDamageTicks<=(t.maxNoDamageTicks??20)/2
  const raised=Boolean(o.targetShieldRaised&&o.targetFacingDot>0),effective=raised&&Boolean(o.targetShieldFacing)
  const enemyReach=Number.isFinite(o.otherReach)?o.otherReach:eyeBoxReach(t,a)
  const entryRisk={threat:false,entered:enemyReach<=PUNISHMENT_ENTRY,current:enemyReach,threshold:PUNISHMENT_ENTRY,
   source:'current-server-opponent-eye-to-self-box'}
  if(o.reach>3.4&&enemyReach>3.4){s.separatedSince??=tick;if(tick-s.separatedSince>=2)s.engagementAxeDone=false}
  else s.separatedSince=null
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz)),closing=((a.vx-v.x)*dx+(a.vz-v.z)*dz)/n
  const nextReach=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},{...t,x:t.x+v.x,z:t.z+v.z})
  const response=criticalReply({enabled:true,self:a,target:{...t,airborne:o.targetAirborne,floorY:frame.targetFloorY??a.y},
   velocity:v,reach:o.reach,charge,shieldReady:a.shieldAvailable,ageMs:frame.latency?.observationAgeMs??0,
   pingMs:frame.latency?.opponentRttMs??0,defenseCandidates:frame.combatGeometry?.defenseCandidates??[],
   incomingRange:frame.combatGeometry?.opponentBaseRange??3})
  let movement=h.axeChargeMotion(frame,probe)
  if(a.held!==7)movement=h.originalSonMotion({...frame,self:{...a,charge:0}},probe)
  movement=approachBrake(frame,probe,movement)
  const recovery=h.sonRecoveryPlan(frame,probe)
  const readyAxe=a.ground&&a.held===7&&charge>.9&&damageReady&&!raised&&o.visible&&o.reach<=3
  const finishingExit=s.exitRun&&tick-s.exitRun.tick<=2
   &&Math.hypot(a.x-s.exitRun.origin.x,a.z-s.exitRun.origin.z)<1e-6
  if(!finishingExit)s.exitRun=null
  else movement={heading:s.exitRun.heading,retreat:true,sprint:true,reason:'finish-exit-step'}
  const critical=s.mode===PHASES.SWORD?null:criticalFootwork(frame,probe,response,s.mode===PHASES.A?movement:null)
  const criticalMove=critical?.escape
  const criticalEta=Math.min(response.criticalEta??Infinity,critical?.baseline.firstCriticalTick??Infinity)
  const shieldWarmup=Math.max(0,5-(frame.usingKind==='shield'?a.useTicks||0:0))+(o.offhandShieldReady?0:1)
  const axeInterrupt=readyAxe&&!live.pending.size&&response.action==='interrupt'&&criticalEta>1
  const covered=Boolean(criticalMove?.window.safe||axeInterrupt)
  const criticalGuard=Boolean(critical&&!covered&&a.shieldAvailable)
  let canControl=Boolean(readyAxe||recovery)
  const enemyClosing=-(v.x*dx+v.z*dz)/n
  const incomingBlade=/(?:_AXE|_SWORD)$/.test(t.held||'')
  if(s.mode===PHASES.A&&s.retreating&&entryRisk.entered&&o.visible&&!finishingExit
      &&incomingBlade&&(response.threat||o.targetGrounded&&enemyClosing>.08)){
   const retreat=movement?.retreat?movement:recovery
   const window=retreatCriticalWindow(frame,probe,retreat)
   const interrupt=readyAxe&&!live.pending.size&&(window.firstCriticalTick??Infinity)>1
   const alternate=!window.safe&&recovery&&recovery!==retreat?retreatCriticalWindow(frame,probe,recovery):null
   const canRetreat=window.safe||alternate?.safe
   if(!interrupt&&canRetreat)movement=window.safe?retreat:recovery
   entryRisk.threat=!interrupt&&!canRetreat
   entryRisk.criticalWindow=alternate?.safe?alternate:window
   entryRisk.canInterrupt=interrupt
   canControl=Boolean(interrupt||canRetreat)
  }
  // Fixture injection uses this public state too; in real play it is created
  // only by the one transition below.
  if(s.punishmentShield&&s.mode!==PHASES.B)transition(s,PHASES.B,tick,'retained-B')
  let brokenB=false
  if(s.mode===PHASES.B){
   if(!a.shieldAvailable){transition(s,PHASES.A,tick,'shield-broken');brokenB=true}
  }
  if(s.mode===PHASES.SWORD&&o.reach>3&&enemyReach>3&&nextReach>3)
   transition(s,PHASES.A,tick,'actual-sword-separation')
  if(s.mode===PHASES.A&&!brokenB){
   if(criticalGuard||entryRisk.threat&&a.shieldAvailable&&(!critical||!covered))
    transition(s,PHASES.B,tick,criticalGuard?'forecast-critical-before-shield-warmup':'retreat-punishment-window')
   else if(o.visible&&o.reach<=2.5&&!canControl&&!covered&&(entryRisk.threat||o.reach<=2.3||closing>.03&&nextReach<=2.5))
    transition(s,PHASES.SWORD,tick,'actual-lost-spacing')
  }
  if(s.mode!==PHASES.SWORD)s.closeFight=null
  if(s.mode!==PHASES.B)s.punishmentShield=null
  let c=neutral(tick),skill='ground-spacing'
  if(s.mode===PHASES.B){
   c={...c,kind:'legacy86-guard',combatMode:'B',shield:true,intent:'B-hold',
    forward:o.visible&&o.distance>.9?1:0};skill='B-punishment-shield'
   if(critical&&!a.shielding){
    if(axeInterrupt&&criticalEta<shieldWarmup){
     c={...moveCommand(c,criticalMove),kind:'legacy86-ground',shield:false,attack:true,
      intent:'B-warmup-interrupt',reblockAfterAttack:true}
     skill=c.intent
    }else{
     c={...c,worldHeading:criticalMove?.heading??null,forward:0,keepTargetLook:true}
     skill='B-warmup-footwork'
    }
   }
   else if(profile().bGuardActions&&!live.pending.size){
    const poke=planBShieldAttack(frame,response,recovery)
    if(poke&&(poke.exitBOnAttack||drawBSteal(s,tick))){c={...c,...poke};skill=poke.intent}
   }
  }else if(s.mode===PHASES.SWORD){
   if(effective&&o.visible&&o.reach<=3&&tick-s.lastStunAt>=10&&!live.pending.size){
    c={...c,kind:'legacy86-stun',attack:true,doubleAttack:true,stunReturnSlot:7}
    skill='stun'
   }else if(!s.closeFight.axeOpenerDone){
    c={...c,kind:'legacy86-close-axe-opener',intent:'axe-before-transformer-sword',
     attack:Boolean(a.held===7&&o.visible&&o.reach<=3&&!live.pending.size)};skill=c.intent
   }else{
    const model=h.legacySwordCommand(s,frame)
    c=model?{...c,...model}:{...moveCommand(c,recovery),kind:'legacy86-close',slot:0,intent:'frozen-model-pending-sword'}
    skill=c.intent
    const exit=h.swordExitCommand(s,frame,probe)
    if(exit&&!live.pending.size){c={...c,...exit};skill=exit.intent}
   }
  }else{
   if(critical&&!axeInterrupt)movement=criticalMove??null
   c=moveCommand(c,movement);skill=movement?.retreat?'short-recovery-run':'ground-spacing'
   if(critical&&!axeInterrupt)skill='axe-critical-footwork'
   if(brokenB){
    const counter=o.visible&&o.reach<=3&&!o.targetShieldFacing&&a.held===7&&charge>=.7&&!live.pending.size
    if(counter)c={...c,kind:'legacy86-counter',attack:true,consumesBlock:s.lastBlock}
    skill=counter?'B-shield-break-counter-to-A':'B-shield-break-to-A'
   }else if(!finishingExit&&!critical&&effective&&o.visible&&o.reach<=3&&tick-s.lastStunAt>=10&&!live.pending.size){
    c={...c,kind:'legacy86-stun',slot:7,attack:true,doubleAttack:true,stunReturnSlot:7};skill='stun'
   }else if((!finishingExit||axeInterrupt)&&readyAxe&&!live.pending.size&&(!critical||axeInterrupt||!covered&&!a.shieldAvailable)){
    c={...c,attack:true,sprint:true,attackRole:o.reach>=2.95?'spacing':'ground-catch',
     impactDirection:{x:dx/n,z:dz/n}};skill='ground-hit'
    if(o.reach>=2.95)c.requestedReachBand=[2.95,3]
   }
  }
  // Ranged defense chooses a complete command and does not mutate the combat
  // mode. Crossbow synchronization can only use an unoccupied A decision.
  const defense=critical||s.mode===PHASES.B&&response.threat?null:rangedDefense(frame,probe,movement)
  const syncOptions={allowBow:false,crossbowShotsOnly:true,reloadAfterSync:true}
  const newShot=o.targetShotWeapon==='crossbow'&&o.loaded&&o.targetShotEvent>(s.rangedSync?.spentShotEvent??0)
   &&tick-o.targetShotTick>=0&&tick-o.targetShotTick<=3
  const canMirror=newShot&&!c.attack&&!critical&&!response.threat&&s.mode!==PHASES.SWORD&&o.reach>3&&enemyReach>3
   &&(!o.arrowThreat||(frame.preserveRangedMovement?defense?.intent==='arrow-dodge'
    :planArrowDodge(frame,probe,null,{stationary:true})?.predictedHits===0))
  const mirror=canMirror?syncRanged(s,frame,c,{...syncOptions,immediateCrossbow:true}):null
  if(mirror){
   const motion=frame.preserveRangedMovement?(defense?.intent==='arrow-dodge'?defense:c)
    :{...neutral(tick),combatMode:s.mode}
   c={...motion,...mirror,jump:false,doubleAttack:false,preserveRangedMovement:Boolean(frame.preserveRangedMovement)}
   skill='sync-fire-crossbow'
  }else if(defense&&!c.attack){
   syncRanged(s,frame,c,{...syncOptions,emergency:true})
   c=s.mode===PHASES.B&&defense.intent==='ranged-shield'?{...defense,combatMode:'B',forward:c.forward}:defense
   skill=defense.intent
  }else if(s.mode===PHASES.A&&!c.attack&&!critical&&!o.arrowThreat&&!movement?.retreat){
   const ranged=syncRanged(s,frame,c,{...syncOptions,emergency:o.reach<=3})
   if(ranged){c={...c,...ranged,doubleAttack:false};skill='sync-'+ranged.ranged}
  }
  if(!o.visible||o.reach>3||live.pending.size)c.attack=c.doubleAttack=false
  if(skill!=='arrow-dodge'&&(o.targetBow||o.targetShotWeapon==='bow'&&tick-o.targetShotTick<=8))c.jump=false
  h.applyJumpOwnership(c,frame,skill,profile())
  const original={axeSpacing:true,shieldScript:false,phase:c.phase,counterHopActive:false,
   hasPendingAttack:live.pending.size>0,sprintKnockback:s.mode!==PHASES.SWORD}
  const patch={...s};delete patch.pending;delete patch.decisionVersion;delete patch.nextId
  const p={mode:'GROUND_SON',phase:s.mode,owners:Object.fromEntries(['movement','sprint','jump','look','sneak','mainhand','attack','shield','offhand'].map(k=>[k,'ground-son'])),
   command:c,original,originalCommand:{...c},commandChanges:{},selectedBranch:'son:'+skill,
   sonArbitration:{skill,decisionOwner:'ground-son',retreatEntryRisk:entryRisk,combatPhase:s.mode,
    warningFootwork:criticalMove?.reason,criticalDefense:critical,
    projectileThreat:o.arrowThreat??null},
   airPlan:{...response,valid:response.threat},closeFight:s.closeFight,groundContact:{controller:'unified-son',axeSpacing:true,
    movement,recovery:null,shortRecovery:recovery,canControl,response,closing,nextReach,
    strictGround:true,requestedReachBand:[2.95,3],phase:s.mode,retreatEntryRisk:entryRisk,
    runJumpRecovery:null,blockReply:s.lastBlock>s.spentBlock&&tick-s.lastBlock<=6},
   statePatch:patch,runtimeMs:0,baseStateVersion:version}
  if(isCurrent&&!isCurrent()||version!==live.decisionVersion)return null
  if(!transactional&&!commitDecision(live,p))return null
  return p
 }
 function applied(s,c,actual,tick){
  if(c.intent==='old-transformer-sword-fallback'||c.intent==='frozen-model-pending-sword')s.swordExitArmed={tick}
  const axe=(actual.attacks||[]).some(x=>x.attempted&&!x.cancelled&&x.held===7)
  if(axe){s.engagementAxeDone=true;s.lastAxeStrikeTick=tick;if(s.closeFight)s.closeFight.axeOpenerDone=true}
  if(actual.attacked){
   s.lastAttempt=tick;if(c.kind==='legacy86-ground')s.lastGroundAttempt=tick
   if(c.kind==='legacy86-stun')s.lastStunAt=tick
   if(s.closeFight&&c.kind==='legacy86-close')s.closeFight.firstHitDone=true
   if(Number.isFinite(c.consumesBlock))s.spentBlock=c.consumesBlock
   for(const hit of actual.attacks||[])s.pending.set(hit.id,{tick})
   const exitHit=(actual.attacks||[]).some(hit=>hit.attempted&&!hit.cancelled&&hit.targetDamage>0
    &&(!c.exitBOnAttack||hit.hitKind==='sprint-knockback'&&hit.outwardMotionConfirmed))
   if(exitHit&&(c.exitBOnAttack||c.intent==='close-exit-hit')){
    transition(s,PHASES.A,tick,'confirmed-exit-attack')
    if(c.exitOrigin&&c.worldHeading)s.exitRun={tick,origin:c.exitOrigin,heading:c.worldHeading}
   }
  }
  if(s.mode===PHASES.A){
   const effectiveAxe=(actual.attacks||[]).some(hit=>hit.attempted&&hit.held===7&&(hit.targetDamage>0||hit.targetShieldCooldown>0))
   s.retreating=Boolean(c.motionRetreat&&actual.sprint&&actual.forward>.5||effectiveAxe||s.exitRun)
  }
 }
 function receipt(s,e,tick){
  if(e.type==='blocked_melee'){s.lastBlock=tick;s.lastEnemyAttack=tick}
  if(e.type==='damage'&&!e.cancelled){
   if(e.victim===s.fighter&&e.amount>0)s.lastDamage=tick
   if(e.attacker===s.opponent&&e.victim===s.fighter&&e.melee)s.lastEnemyAttack=tick
   if(e.attacker===s.fighter&&e.victim===s.opponent&&e.melee){s.pending.delete(e.attackId);if(e.amount>0)s.lastHit=tick}
  }
  if(e.type==='attack_packet'&&e.willAttack===false)s.pending.delete(e.attackId)
 }
 return {ready:Promise.resolve(),runtime:null,createState,reset(s){current=s},decide,applied,receipt,rangedApplied,
  commitDecision,isDecisionCurrent:(s,p)=>s.decisionVersion===p.baseStateVersion,close:async()=>{}}
}
module.exports={createUnifiedSonBrain,retreatCriticalWindow,PHASES}
