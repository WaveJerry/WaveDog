// Public client-visible arrow trajectory and collision estimate.
// Mineflayer retains packet positions; it does not advance remote arrows on
// physics ticks. Keep their observation time and advance the public ballistic
// sample to NOW before predicting another eight ticks into the future.
function advancePublicArrow(sample,atMs,clearPath=()=>true){
  let {x,y,z,vx,vy,vz}=sample
  const observationAgeMs=Math.max(0,atMs-sample.atMs)
  let remaining=Math.min(20,observationAgeMs/50),stopped=false
  while(remaining>1e-9){
    const dt=Math.min(1,remaining),from={x,y,z},to={x:x+vx*dt,y:y+vy*dt,z:z+vz*dt}
    if(!clearPath(from,to)){vx=vy=vz=0;stopped=true;break}
    ;({x,y,z}=to)
    if(dt===1){vx*=.99;vy=vy*.99-.05;vz*=.99}
    remaining-=dt
  }
  return {x,y,z,vx,vy,vz,observationAgeMs,stopped,
    stale:observationAgeMs>1000,source:'public-packet-ballistic-extrapolation'}
}
function observePublicArrow(entity,atMs,{position=true,velocity=false}={}){
  if(!/^(arrow|spectral_arrow)$/.test(entity?.name||''))return
  const previous=entity.publicArrowSample
  const predicted=previous?advancePublicArrow(previous,atMs):null
  const p=position||!predicted?entity.position:predicted
  const v=velocity||!predicted?entity.velocity:{x:predicted.vx,y:predicted.vy,z:predicted.vz}
  entity.publicArrowSample={x:p.x,y:p.y,z:p.z,vx:v?.x||0,vy:v?.y||0,vz:v?.z||0,atMs}
}
function publicArrowSnapshot(entity,atMs,clearPath=()=>true){
  const a=entity.publicArrowSample?advancePublicArrow(entity.publicArrowSample,atMs,clearPath):{
    x:entity.position.x,y:entity.position.y,z:entity.position.z,
    vx:entity.velocity?.x||0,vy:entity.velocity?.y||0,vz:entity.velocity?.z||0,
    observationAgeMs:null,source:'public-entity-packet'}
  return {id:entity.id,...a,shooterId:entity.publicShooterId}
}
function segmentBoxEntry (a, b, center, half, low, high) {
  let enter = 0, leave = 1
  for (const [start, end, min, max] of [
    [a.x-center.x,b.x-center.x,-half,half],
    [a.y-center.y,b.y-center.y,low,high],
    [a.z-center.z,b.z-center.z,-half,half]]) {
    const delta = end-start
    if (Math.abs(delta) < 1e-9) {
      if (start < min || start > max) return null
      continue
    }
    const first = (min-start)/delta, second = (max-start)/delta
    enter = Math.max(enter,Math.min(first,second))
    leave = Math.min(leave,Math.max(first,second))
    if (enter > leave) return null
  }
  return enter
}
function segmentHitsBox (a,b,center,half,low,high) {
  return segmentBoxEntry(a,b,center,half,low,high)!==null
}
function publicArrowThreat (arrows, self, wall, clearPath = () => true) {
  let chosen = null
  const trajectories=[]
  for (const arrow of arrows || []) {
    if(self.entityId!=null&&arrow.shooterId===self.entityId)continue
    if(arrow.stopped||arrow.stale)continue
    let pos = { x: arrow.x, y: arrow.y, z: arrow.z }
    let vx = arrow.vx || 0, vy = arrow.vy || 0, vz = arrow.vz || 0
    // A shield-reflected arrow can slow below .2 blocks/tick and still fall
    // back into the body. Gravity and whole-segment collision remain relevant
    // even for a zero-velocity airborne sample; only stopped/stale is ignored.
    let impact = null
    const segments=[]
    for (let tick=1; tick<=8; tick++) {
      const next = { x: pos.x+vx, y: pos.y+vy, z: pos.z+vz }
      if (!clearPath(pos,next)) break // An observed solid block stops the path.
      segments.push({tick,from:pos,to:next})
      const center = { x: self.x+(self.vx || 0)*Math.min(tick,3)*.7,
        y: self.y+(self.ground?0:self.vy||0)*Math.min(tick,2),
        z: self.z+(self.vz || 0)*Math.min(tick,3)*.7 }
      // 0.3 body half-width + 0.3 native projectile expansion + float margin.
      if(!impact){
        const half=self.half??.3,height=self.height??1.8
        const exact=segmentBoxEntry(pos,next,center,half,0,height)
        const entry=exact??segmentBoxEntry(pos,next,center,half+.32,-.32,height+.32)
        if(entry!==null){
          const dx=pos.x+vx*entry-center.x,dz=pos.z+vz*entry-center.z
          const length=Math.hypot(dx,dz),speed=Math.hypot(vx,vz)
          // Guard toward the impact point. Blend the incoming heading when
          // it can also cover an earlier expanded-box collision.
          const approachDot=speed&&length?-(dx*vx+dz*vz)/(speed*length):0
          const x=dx/length-(approachDot>=0&&speed?vx/speed:0)
          const z=dz/length-(approachDot>=0&&speed?vz/speed:0)
          impact={tick,next,center,shieldYaw:length>1e-6?Math.atan2(-x,-z):null,
            exactContact:exact!==null,approachDot}
        }
      }
      pos = next
      vx *= .99; vy = vy*.99-.05; vz *= .99
    }
    if(segments.length)trajectories.push({id:arrow.id,segments})
    if (!impact) continue
    const leftX = -Math.cos(self.yaw), leftZ = Math.sin(self.yaw)
    const leftRoom = wall(leftX, leftZ), rightRoom = wall(-leftX, -leftZ)
    const displacement = Math.min(1.2,.16*impact.tick*impact.tick)
    const leftMiss = Math.hypot(impact.center.x+leftX*displacement-impact.next.x,
      impact.center.z+leftZ*displacement-impact.next.z)
    const rightMiss = Math.hypot(impact.center.x-leftX*displacement-impact.next.x,
      impact.center.z-leftZ*displacement-impact.next.z)
    const leftSafe = leftRoom >= .9, rightSafe = rightRoom >= .9
    const side = leftSafe && (!rightSafe || leftMiss >= rightMiss) ? -1
      : rightSafe ? 1 : 0
    const jumpRise = [.0,.42,.75,.99,1.16,1.24,1.23,1.14,.97][impact.tick]
    const jump = Boolean(side && self.ground && self.ceilingClear
      && impact.tick >= 2 && impact.next.y < self.y+jumpRise-.12)
    if (!chosen || impact.tick < chosen.time)
      chosen = { id: arrow.id, time: impact.tick, side, jump,
        shieldYaw:impact.shieldYaw,exactContact:impact.exactContact,
        shieldContactDot:impact.approachDot,piercing:(arrow.pierceLevel??0)>0,
        dodgeHeading: { x: -side*leftX, z: -side*leftZ },
        miss: Math.hypot(impact.center.x-impact.next.x,
          impact.center.z-impact.next.z) }
  }
  if(chosen){chosen.trajectories=trajectories;chosen.trajectorySource='public-visible-position-and-velocity'}
  return chosen
}

// A Son skill: test the player's changing position AGAINST each whole arrow
// segment, rather than a side guess at one endpoint. Multiple arrows, momentum,
// headroom and swept body/world collision all use the same observation.
function planArrowDodge(frame,probe,movement,{allowJump=true,stationary=false}={}){
  const a=frame.self,threat=frame.observation.arrowThreat,paths=threat?.trajectories
  if(!paths?.length)return null
  const yaw=a.yaw??frame.observation.targetYaw??0
  let preferred=threat.dodgeHeading||{x:Math.cos(yaw)*(threat.side||1),z:-Math.sin(yaw)*(threat.side||1)}
  const incoming=paths.find(p=>p.id===threat.id)?.segments[0]
  if(incoming){
    const dx=incoming.to.x-incoming.from.x,dz=incoming.to.z-incoming.from.z,n=Math.hypot(dx,dz)
    if(n>.01){
      const sign=(-dz*preferred.x+dx*preferred.z)>=0?1:-1
      preferred={x:-dz/n*sign,z:dx/n*sign}
    }
  }
  const candidates=stationary?[{heading:{x:0,z:0},sprint:false,jump:false}]:[]
  if(!stationary&&movement?.heading&&Math.hypot(movement.heading.x,movement.heading.z)>.5)
    candidates.push({heading:movement.heading,sprint:Boolean(movement.sprint),jump:false,continuingOriginal:true})
  for(const k of stationary?[]:[1,-1]){
    const heading={x:preferred.x*k,z:preferred.z*k}
    if(Math.hypot(heading.x,heading.z)<.5)continue
    candidates.push({heading,sprint:false,jump:false,continuingOriginal:false})
    if(allowJump&&(threat.jump||allowJump==='compare')&&a.ground&&a.jumpAvailable!==false)
      candidates.push({heading,sprint:false,jump:true,continuingOriginal:false})
  }
  let best=null
  for(const candidate of candidates){
    let p={x:a.x,y:a.y,z:a.z},vx=a.vx||0,vy=a.ground?0:a.vy||0,vz=a.vz||0,ground=a.ground
    let firstImpactTick=Infinity,minimumClearance=Infinity,blocked=false
    const hits=new Set()
    for(let t=1;t<=8;t++){
      if(t===1&&candidate.jump)vy=.42
      const acceleration=(ground?.098:.02)*(candidate.sprint?1.3:1)
      vx+=candidate.heading.x*acceleration;vz+=candidate.heading.z*acceleration
      const q={x:p.x+vx,y:p.y+vy,z:p.z+vz},checked=probe(q,p)
      if(!checked?.clear||!checked.supported){blocked=true;break}
      const floor=checked.floorY??(a.ground?a.y:-Infinity)
      if(q.y<floor)q.y=floor
      const landing=q.y<=floor+.001&&vy<=0
      for(const path of paths){
        const seg=path.segments[t-1];if(!seg)continue
        const start={x:seg.from.x-p.x,y:seg.from.y-p.y,z:seg.from.z-p.z}
        const end={x:seg.to.x-q.x,y:seg.to.y-q.y,z:seg.to.z-q.z}
        if(segmentHitsBox(start,end,{x:0,y:0,z:0},.62,-.32,2.12)){
          hits.add(path.id);firstImpactTick=Math.min(firstImpactTick,t)
        }
        // Tie-break only. Actual collision is the swept-box test above.
        const dx=end.x-start.x,dy=end.y-start.y,dz=end.z-start.z,len=dx*dx+dy*dy+dz*dz
        const u=len?Math.max(0,Math.min(1,-(start.x*dx+(start.y-.9)*dy+start.z*dz)/len)):0
        const x=start.x+u*dx,y=start.y+u*dy,z=start.z+u*dz
        minimumClearance=Math.min(minimumClearance,Math.hypot(Math.max(0,Math.abs(x)-.62),
          Math.max(0,-.32-y,y-2.12),Math.max(0,Math.abs(z)-.62)))
      }
      p=q;ground=landing
      const drag=ground?.546:.91;vx*=drag;vz*=drag;vy=landing?0:(vy-.08)*.98
    }
    if(blocked)continue
    const safe=hits.size===0
    if(allowJump==='compare'&&candidate.jump&&!safe)continue
    const score=(safe?1000:Math.min(firstImpactTick,8)*10-hits.size*100)
      +Math.min(minimumClearance,3)+(candidate.continuingOriginal?.2:0)-(candidate.jump?.05:0)
    if(!best||score>best.score)best={...candidate,score,predictedHits:hits.size,
      firstImpactTick:Number.isFinite(firstImpactTick)?firstImpactTick:null,minimumClearance,
      trajectoryCount:paths.length,trajectoryUsed:true,unavoidable:!safe}
  }
  return best
}

module.exports = { publicArrowThreat, segmentHitsBox, planArrowDodge,advancePublicArrow,observePublicArrow,publicArrowSnapshot }
