'use strict'
// The existing shield script is a PURE Son skill. It owns no executor, timer,
// network client or model; Son selects and commits the single final command.
const original=require('./protocol-pilot-mechanical-brain')
const {confirmedRear}=require('./protocol-mechanical-math')
const {eyeBoxReach}=require('./protocol-legacy86-threat')
function createShieldState(opponent,fighter){return original.createState(opponent,fighter)}
function shieldReceipt(s,e,tick){
  if(!s.shieldScriptState)return
  original.receipt(s.shieldScriptState,e,tick)
  if(e.type==='shield_disabled'||e.type==='blocked_melee'&&e.shieldDisabled){
    s.shieldScriptState.mode='NEURAL';s.shieldScriptState.pending=null
    s.shieldScriptState.orbitUntil=0;s.shieldScriptState.orbitAttempt=false
    s.pending.clear()
  }
}
function selectShieldScript(s,frame,movement,response){
  const a=frame.self,o=frame.observation,t=o.tick,st=s.shieldScriptState
  if(!st)return null
  if(!a.shieldAvailable){
    st.mode='NEURAL';st.pending=null;st.orbitUntil=0;st.orbitAttempt=false
    return null
  }
  const dx=frame.seen.x-a.x,dz=frame.seen.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const closing=((a.vx-frame.targetVelocity.x)*dx+(a.vz-frame.targetVelocity.z)*dz)/n
  const o2={...o,self:a,sentPosition:a,target:frame.seen,targetVelocity:frame.targetVelocity,
    selfVelocity:{x:a.vx,y:a.vy,z:a.vz},ground:a.ground,health:a.health,held:a.held,charge:a.attackChargeAtHit??a.charge,
    shieldReady:a.shieldAvailable,shieldEffective:a.shielding,shieldRaised:frame.usingKind==='shield',
    distance:Math.hypot(dx,dz),targetApproachSpeed:closing,
    mutualOutOfReach:o.reach>3&&o.otherReach>3,targetAirborneThreat:response.threat,targetCriticalThreat:response.threat,
    // Current ranged logic is selected once by Son afterwards. Do not revive
    // the retired script's bow mirror or a second crossbow synchronization.
    loaded:false,arrows:0,targetLoading:false,targetBow:false,targetShotEvent:0,arrowThreat:null,
    sideDraw:((Math.floor(t/12)*31)%100)/100,sideDurationDraw:.5,
    openingDraw:((t*37)%100)/100,orbitDraw:((Math.floor(t/8)*17)%100)/100,
    orbitSide:Math.floor(t/8)%2?1:-1}
  if(st.mode==='NEURAL'&&(s.closeFight||s.runJumpRecovery||!original.safeShieldReturn(o2)))return null
  const chosen=original.plan(st,o2,null)
  if(chosen.mode==='NEURAL')return null
  const raw=chosen.command,c={...raw,phase:raw.kind==='counter'?'COUNTER':raw.orbit?'ORBIT_BURST':
    raw.kind==='orbit-reply'||raw.kind==='guard-reply'?'ORBIT_TRADE':raw.kind==='orbit-rear'?'ORBIT_BACK':'GUARD',
    kind:raw.kind==='counter'?'legacy86-counter':'legacy86-guard',shieldScriptKind:raw.kind||'guard',
    decidedTick:t,ppoEligible:false,critical:false,doubleAttack:false,keepLook:false,keepTargetLook:true,
    worldHeading:raw.worldHeading||null,reblockAfterAttack:Boolean(raw.attack),spacingProfile:'axe'}
  // The original script cannot claim a blocked front as a back hit.
  if(c.attack&&o.targetShieldRaised&&o.targetShieldFacing){
    c.attack=false;c.shield=true;c.sprint=false;c.reblockAfterAttack=false;st.pending=null
  }
  return c
}
function shieldApplied(s,c,actual,tick){
  if(!c.shieldScriptKind||!s.shieldScriptState)return
  original.applied(s.shieldScriptState,{...c,kind:c.shieldScriptKind},actual.attacked,tick)
}
// Reuse original GUARD's full-charge exposed/rear window. No orbit planner,
// orbit state or navigation is called by this B-only attack proposal.
function planBShieldAttack(frame,response,escape){
  const a=frame.self,o=frame.observation,t=frame.seen,v=frame.targetVelocity
  const charge=a.attackChargeAtHit??a.charge
  if(!o.visible||o.reach>3||a.held!==7||!a.shieldAvailable||!a.shielding&&frame.usingKind!=='shield'
      ||o.arrowThreat||o.targetBow||Number.isFinite(t.noDamageTicks)&&t.noDamageTicks>(t.maxNoDamageTicks??20)/2)return null
  const exposed=o.targetShieldRaised?confirmedRear(a,a,t,o.targetYaw):!o.targetShieldFacing
  if(!exposed)return null
  const warmup=5+(o.offhandShieldReady?0:1)
  if(response?.threat&&(response.criticalEta??0)<=warmup+1)return null
  const dx=t.x-a.x,dz=t.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const separating=((v.x-a.vx)*dx+(v.z-a.vz)*dz)/n
  const next=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},{...t,x:t.x+v.x,z:t.z+v.z})
  if(escape&&o.reach>=2.95&&next>3&&separating>.03&&charge>.9){
    return {kind:'legacy86-ground',intent:'B-knockback-exit',slot:7,attack:true,doubleAttack:false,
      shield:false,reblockAfterAttack:false,jump:false,critical:false,sprint:true,
      worldHeading:escape.heading,forward:0,side:0,keepTargetLook:false,keepLook:false,
      exitBOnAttack:true,exitOrigin:{x:a.x,z:a.z},combatMode:'A',attackRole:'exit',exitReach:o.reach}
  }
  if(!a.shielding||charge<.999||o.targetShieldRaised)return null
  return {kind:'legacy86-guard-steal',intent:'B-steal-and-reblock',slot:7,attack:true,doubleAttack:false,
    shield:false,reblockAfterAttack:true,jump:false,critical:false,sprint:false,worldHeading:null,
    forward:0,side:0,keepTargetLook:true,keepLook:false,combatMode:'B',
    reblockWarmupTicks:warmup}
}
module.exports={createShieldState,shieldReceipt,selectShieldScript,shieldApplied,planBShieldAttack}
