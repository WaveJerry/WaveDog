# WaveDog Axe PvP 1.1

主服策略 `9530f5209b58d05a869aa8c9e2a187bc5078b72eecdd8d45cdf4ee88798d39be`。包含 WaveDog 和 WaveDogSon 的接入插件、策略源码、竞技场配置、弩校准、500 Hz 探测插件和旧 GRU＋GTrXL 剑斗权重。A 用斧头控距和短后撤，根据对方下落窗口判断打断、避让或提前举盾。B 持盾逼近，在安全入距时按概率偷刀并立即重举盾。

## 恢复

1. 解压到固定目录。使用 Windows x64、Paper 1.21.11、Java 21 和 Node.js。
2. 在解压目录的 `work/pvp-dual-brain` 执行 `npm ci --omit=dev`。
3. 在服务器停止时，把包内 `plugins` 合并到目标服的 `plugins`。配置使用 JAR 内锁定的策略，解压路径无需与制作机相同。
4. 在服务器启动的 `-jar` 前添加 `"-Dwavedog.workspace=解压目录绝对路径" "-Dwavedog.node=node.exe绝对路径"`。
5. 目标服需要原竞技场地图，或在代码和各插件配置中调整竞技场位置。启动后检查 `wdnative status`、`wdneural` 和 `wdprobe status`，再用 `/wavedog duel 玩家名` 或 `/wavedogson duel 玩家名`。

包内保留机器人外观所需的身份属性。使用已有的竞技场地图和 Paper 服务端。原生控制 JAR 内置已核验的策略以及兼容的服务器端执行器，Javet 也已内置。源码重编译依赖 `com.caoccao.javet` 的 `javet` 和 `javet-v8-windows-x86_64` 4.1.7，放入 `work/wavedog-native/lib`。
