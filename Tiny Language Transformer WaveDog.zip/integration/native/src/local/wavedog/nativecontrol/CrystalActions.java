package local.wavedog.nativecontrol;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.*;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Candidate analysis and ordinary player interactions for Father. */
final class CrystalActions {
    private static final int FLOOR=221;
    private static final String TAG="wavedog-father-crystal";
    private static final Map<NativeControl.Actor,Bout> BOUTS=new WeakHashMap<>();
    private static final BlockFace[] SIDES={BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST};
    private static final double[][] TOP_AIMS={{.5,.5},{.12,.12},{.12,.88},{.88,.12},{.88,.88}};

    private static final class Bout {
        final String match;
        int decidedTick=-1,pearlUntil=-1,pearlRetry=-1,landedAt=-1;
        boolean landed,hold,reposition;
        Placement pearlPlacement;
        Block pendingAnchor;
        int pendingUntil;
        Bout(String match){this.match=match;}
    }
    private record Placement(Block base,Block cover,Block second,BlastDamage.Score score){
        Placement(Block base,Block cover,BlastDamage.Score score){this(base,cover,null,score);}
        double value(){return score.value()-(cover==null?0:.15)-(second==null?0:.25);}
    }
    private record Click(Location aim,BlockHitResult hit){}
    private record CrystalHit(EnderCrystal crystal,Location look,BlastDamage.Score score){}
    private record PearlLanding(Location position,int ticks){}
    private record PearlPlan(Location look,PearlLanding landing,Location opponent,Placement placement){}

    private static boolean inside(Location p){
        return p.getWorld().getName().equals("world")&&p.getX()>=992&&p.getX()<1037
            &&p.getZ()>=992&&p.getZ()<1037&&p.getY()>=FLOOR&&p.getY()<225;
    }
    static Map<String,Object> observation(NativeControl.Actor actor){
        var p=actor.player();int totems=0;
        for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.TOTEM_OF_UNDYING)totems+=item.getAmount();
        return Map.of("inArena",inside(p.getLocation()),"anchorReady",anchorReady(actor),"totems",totems);
    }
    private static boolean anchorReady(NativeControl.Actor actor){
        var p=actor.player();return amount(p,5,Material.RESPAWN_ANCHOR)>0&&amount(p,6,Material.GLOWSTONE)>0
            &&!RespawnAnchorBlock.canSetSpawn(actor.handle.level(),position(p.getLocation().getBlock()));
    }
    private static Vector anchorRoute(Player player,Player opponent){
        var at=player.getLocation();var toward=opponent.getLocation().toVector().subtract(at.toVector()).setY(0);
        double distance=toward.length();if(distance>5||distance<.001)return toward;
        toward.multiply(1/distance);
        var center=new Vector(1014.5-at.getX(),0,1014.5-at.getZ());
        var side=toward.clone().rotateAroundY(Math.PI/2);
        if(side.dot(center)<0)side.multiply(-1);
        return toward.multiply(Math.clamp(distance-3.8,-.75,.65)).add(side.multiply(.9)).normalize();
    }

    static void pearlLanded(NativeControl.Actor actor){
        Bout bout=BOUTS.get(actor);
        if(bout!=null&&Objects.equals(bout.match,actor.match)&&bout.pearlUntil>=0){
            bout.landed=true;bout.landedAt=Bukkit.getCurrentTick();bout.pearlUntil=-1;
        }
    }

    static boolean equipTotem(Player player){
        var inventory=player.getInventory();
        if(!inventory.getItemInOffHand().getType().isAir())return false;
        int slot=inventory.first(Material.TOTEM_OF_UNDYING);
        if(slot<0)return false;
        var totem=inventory.getItem(slot);
        inventory.setItem(slot,null);inventory.setItemInOffHand(totem);
        return true;
    }

    private static Vec3 center(Block block,double y){return new Vec3(block.getX()+.5,block.getY()+y,block.getZ()+.5);}
    private static List<Integer> coordinates(Block block){return block==null?List.of():List.of(block.getX(),block.getY(),block.getZ());}
    private static boolean canPlace(Block block){
        if(!inside(block.getLocation())||!block.getType().isAir()||!block.getRelative(BlockFace.DOWN).getType().isSolid())return false;
        return block.getWorld().getNearbyEntities(new org.bukkit.util.BoundingBox(block.getX(),block.getY(),block.getZ(),
            block.getX()+1,block.getY()+1,block.getZ()+1),e->e instanceof LivingEntity||e instanceof EnderCrystal).isEmpty();
    }
    private static double range(Player player){return Objects.requireNonNull(player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE)).getValue();}
    private static Click aimBlock(Player player,Block block,boolean top){
        return aimBlock(player.getEyeLocation(),range(player),block,top,null);
    }
    private static Click aimBlock(Location eye,double range,Block block,boolean top,Block cover){
        if(!top){
            var side=aimBlock(eye,range,block,.5,.5,.5,false,cover);
            if(side!=null)return side;
        }
        for(var offset:TOP_AIMS){
            var click=aimBlock(eye,range,block,offset[0],.999,offset[1],top,cover);
            if(click!=null)return click;
        }
        return null;
    }
    private static Click aimBlock(Location eye,double range,Block block,double x,double y,double z,boolean top,Block cover){
        var spot=block.getLocation().add(x,y,z);
        if(cover!=null&&blocksRay(eye,cover,new Vec3(spot.getX(),spot.getY(),spot.getZ())))return null;
        var aim=eye.clone().setDirection(spot.toVector().subtract(eye.toVector()));
        var hit=eye.getWorld().rayTraceBlocks(eye,aim.getDirection(),range,FluidCollisionMode.NEVER,true);
        if(hit==null||!block.equals(hit.getHitBlock())||top&&hit.getHitBlockFace()!=BlockFace.UP)return null;
        var at=hit.getHitPosition();var face=hit.getHitBlockFace();
        var faceNms=Direction.valueOf(face.name());
        return new Click(aim,new BlockHitResult(new Vec3(at.getX(),at.getY(),at.getZ()),faceNms,position(block),false));
    }
    private static BlockPos position(Block b){return new BlockPos(b.getX(),b.getY(),b.getZ());}
    private static Vec3 eye(Player player){var l=player.getEyeLocation();return new Vec3(l.getX(),l.getY(),l.getZ());}
    private static boolean blocksRay(Location start,Block cover,Vec3 target){
        var cube=BlastDamage.cube(cover);var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        return cube.contains(eye)||cube.clip(eye,target).isPresent();
    }
    private static int amount(Player player,int slot,Material expected){
        var item=player.getInventory().getItem(slot);
        return item!=null&&item.getType()==expected?item.getAmount():0;
    }
    private static int click(NativeControl.Actor actor,int slot,Material material,Block block,boolean top){
        Player player=actor.player();var inv=player.getInventory();int before=amount(player,slot,material);
        if(before==0||player.getGameMode()!=GameMode.SURVIVAL||player.hasCooldown(material))return 0;
        var aim=aimBlock(player,block,top);if(aim==null)return 0;
        int previous=inv.getHeldItemSlot();inv.setHeldItemSlot(slot);player.setRotation(aim.aim().getYaw(),aim.aim().getPitch());
        try{actor.handle.gameMode.useItemOn(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND,aim.hit());}
        finally{inv.setHeldItemSlot(previous);}
        return before-amount(player,slot,material);
    }

    private static Placement select(Player player,Player opponent,boolean anchor){
        return select(player,opponent,anchor,player.getLocation(),opponent.getLocation(),null);
    }
    private static Placement select(Player player,Player opponent,boolean anchor,Location own,Location enemy,Placement planned){
        var origin=planned==null?enemy.getBlock():planned.base();var world=player.getWorld();
        var start=own.clone().add(0,player.getEyeHeight(),0);var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        var projected=player.getBoundingBox().clone().shift(own.toVector().subtract(player.getLocation().toVector()));
        var enemyBox=opponent.getBoundingBox().clone().shift(enemy.toVector().subtract(opponent.getLocation().toVector()));
        double range=range(player),rangeSquared=range*range;Placement best=null,bare=null;
        boolean haveCover=amount(player,1,Material.OBSIDIAN)>0;
        int radius=planned==null?(anchor&&own.equals(player.getLocation())?2:1):0;
        // Elevated opponents can be blasted from a reachable supported base,
        // not only from the arena floor. The existing ray, entity and damage
        // checks still reject impossible or unsafe placements.
        int top=Math.min(223,Math.max(FLOOR,enemy.getBlockY()));
        int covers=amount(player,1,Material.OBSIDIAN);
        for(int y=FLOOR;y<=top;y++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
            var b=world.getBlockAt(origin.getX()+dx,y,origin.getZ()+dz);
            var support=b.getRelative(BlockFace.DOWN);
            boolean readyBase=!anchor&&(b.getType()==Material.OBSIDIAN||b.getType()==Material.BEDROCK);
            if(!inside(b.getLocation())||eye.distanceToSqr(center(b,0))>rangeSquared
                ||(!readyBase&&(!canPlace(b)||projected.overlaps(BoundingBox.of(b))||enemyBox.overlaps(BoundingBox.of(b))
                   ||aimBlock(start,range,support,true,null)==null))){continue;}
            if(!anchor){
                var spawn=b.getRelative(BlockFace.UP);
                var c=BlastDamage.cube(spawn).expandTowards(0,1,0);
                var box=new org.bukkit.util.BoundingBox(c.minX,c.minY,c.minZ,c.maxX,c.maxY,c.maxZ);
                var crystalBox=new AABB(c.minX-.5,c.minY,c.minZ-.5,c.maxX+.5,c.maxY,c.maxZ+.5);
                var exposed=crystalBox.clip(eye,crystalBox.getCenter());
                if(!spawn.getType().isAir()||!world.getNearbyEntities(box).isEmpty()
                    ||(!crystalBox.contains(eye)&&(exposed.isEmpty()||eye.distanceToSqr(exposed.get())>9))
                    ||(readyBase&&aimBlock(start,range,b,false,null)==null)||(!readyBase&&amount(player,1,Material.OBSIDIAN)==0))continue;
                var score=BlastDamage.estimate(player,opponent,center(b,1),false,readyBase?null:b);
                if(score.worthwhile(player)&&(best==null||score.value()>best.score().value()))best=new Placement(b,null,score);
                continue;
            }
            var blast=center(b,.5);
            var uncovered=BlastDamage.estimate(player,opponent,blast,true,null,own,enemy);
            if((planned==null||planned.cover()==null)&&canBlastWithoutCover(player,uncovered)
                &&(bare==null||uncovered.value()>bare.score().value()))bare=new Placement(b,null,uncovered);
            if(!haveCover||planned!=null&&planned.cover()==null)continue;
            var validCovers=new ArrayList<Block>(4);
            for(BlockFace side:SIDES){
                var cover=b.getRelative(side);
                if(planned!=null&&!cover.equals(planned.cover())&&!cover.equals(planned.second()))continue;
                if(!canPlace(cover)||projected.overlaps(BoundingBox.of(cover))||enemyBox.overlaps(BoundingBox.of(cover))
                    ||aimBlock(start,range,cover.getRelative(BlockFace.DOWN),true,null)==null
                    ||aimBlock(start,range,support,true,cover)==null
                    ||blocksRay(start,cover,center(b,.999)))continue;
                var score=BlastDamage.estimate(player,opponent,blast,true,cover,own,enemy);
                var single=new Placement(b,cover,score);
                if(score.self()+.05f<uncovered.self()&&canBlastWithoutCover(player,score)
                    &&(best==null||single.value()>best.value()))best=single;
                if(covers>=2&&score.target()>=1&&score.self()>.08)for(Block previous:validCovers){
                    if(aimBlock(start,range,cover.getRelative(BlockFace.DOWN),true,previous)==null
                        ||aimBlock(start,range,support,true,previous)==null)continue;
                    var combined=BlastDamage.estimate(player,opponent,blast,true,previous,cover,own,enemy);
                    var pair=new Placement(b,previous,cover,combined);
                    if(canBlastWithoutCover(player,combined)&&(best==null||pair.value()>best.value()))best=pair;
                }
                validCovers.add(cover);
            }
        }
        return best!=null&&(bare==null||best.value()>bare.value())?best:bare;
    }

    private static boolean canBlastWithoutCover(Player player,BlastDamage.Score score){
        return score.target()>=1&&score.self()<player.getHealth()+player.getAbsorptionAmount();
    }

    private static boolean finishAnchor(NativeControl.Actor actor,Player opponent,Block anchor,Map<String,Object> receipt){
        Player player=actor.player();
        if(!(anchor.getBlockData() instanceof RespawnAnchor data))return false;
        var score=BlastDamage.estimate(player,opponent,center(anchor,.5),true,null);
        if(!canBlastWithoutCover(player,score))return false;
        if(data.getCharges()==0){
            if(click(actor,6,Material.GLOWSTONE,anchor,false)!=1)return false;
            receipt.put("glowstoneConsumed",1);
        }
        if(!(anchor.getBlockData() instanceof RespawnAnchor charged)||charged.getCharges()!=1)return false;
        score=BlastDamage.estimate(player,opponent,center(anchor,.5),true,null);
        if(!canBlastWithoutCover(player,score))return false;
        receipt.put("anchorDamage",Map.of("self",score.self(),"target",score.target(),"charge",1));
        click(actor,0,Material.NETHERITE_SWORD,anchor,false);
        if(anchor.getType()==Material.RESPAWN_ANCHOR)return false;
        receipt.put("anchorDetonated",true);return true;
    }

    private static CrystalHit scoreCrystal(Player player,Player opponent,EnderCrystal crystal){
        if(crystal.isDead()||NativeControl.reach(player,crystal)>3)return null;
        var at=crystal.getLocation();var score=BlastDamage.estimate(player,opponent,new Vec3(at.getX(),at.getY(),at.getZ()),false,null);
        if(!score.worthwhile(player))return null;
        Location start=player.getEyeLocation(),look=start.clone().setDirection(crystal.getBoundingBox().getCenter().subtract(start.toVector()));
        RayTraceResult ray=player.getWorld().rayTraceEntities(start,look.getDirection(),3,0,
            entity->entity!=player&&entity.isValid()&&(entity instanceof LivingEntity||entity instanceof EnderCrystal));
        if(ray==null||ray.getHitEntity()!=crystal)return null;
        var obstruction=player.getWorld().rayTraceBlocks(start,look.getDirection(),ray.getHitPosition().distance(start.toVector()),FluidCollisionMode.NEVER,true);
        return obstruction==null?new CrystalHit(crystal,look,score):null;
    }
    private static boolean hitCrystal(NativeControl.Actor actor,CrystalHit hit,int tick,Map<String,Object> receipt){
        if(hit==null||actor.lastDispatchTick==tick)return false;
        Player player=actor.player();actor.lastDispatchTick=tick;
        player.setRotation(hit.look().getYaw(),hit.look().getPitch());player.swingMainHand();player.attack(hit.crystal());
        receipt.put("crystalDamage",Map.of("self",hit.score().self(),"target",hit.score().target()));
        if(!hit.crystal().isDead()&&hit.crystal().isValid())return false;
        receipt.put("crystalStruck",true);return true;
    }

    private static PearlLanding predictPearl(NativeControl.Actor actor,Player opponent,Location look){
        var self=actor.player();var level=actor.handle.level();
        Vec3 start=eye(self).subtract(0,.1,0);
        var direction=look.getDirection();var momentum=actor.handle.getDeltaMovement();
        Vec3 speed=new Vec3(direction.getX(),direction.getY(),direction.getZ()).scale(1.5)
            .add(momentum.x,self.isOnGround()?0:momentum.y,momentum.z);
        var enemy=opponent.getBoundingBox();
        var target=new AABB(enemy.getMinX(),enemy.getMinY(),enemy.getMinZ(),enemy.getMaxX(),enemy.getMaxY(),enemy.getMaxZ()).inflate(.35);
        for(int tick=0;tick<12;tick++){
            speed=speed.subtract(0,.03,0);var end=start.add(speed);
            var hit=level.clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,actor.handle));
            if(target.contains(start)||target.clip(start,hit.getLocation()).isPresent())return null;
            if(hit.getType()!=HitResult.Type.MISS){
                var p=hit.getLocation();var landing=new Location(self.getWorld(),start.x,start.y,start.z);
                if(hit.getDirection()!=Direction.UP||p.y<FLOOR-.02||landing.getY()>FLOOR+1.45||!inside(landing)
                    ||!landing.getBlock().isPassable()||!landing.clone().add(0,1,0).getBlock().isPassable())return null;
                return new PearlLanding(landing,tick+1);
            }
            start=end;speed=speed.scale(.99);
        }
        return null;
    }
    private static Location projectOpponent(Player opponent,Vector velocity,int ticks){
        var handle=((CraftPlayer)opponent).getHandle();var at=opponent.getLocation();
        // Limit extrapolation over a pearl's flight. Recheck the accepted pose at impact.
        double horizon=Math.min(ticks,4);
        var travel=new Vec3(velocity.getX()*horizon,opponent.isOnGround()?0:velocity.getY()*horizon,velocity.getZ()*horizon);
        if(travel.lengthSqr()>2.25)travel=travel.normalize().scale(1.5);
        var valid=net.minecraft.world.entity.Entity.collideBoundingBox(handle,travel,handle.getBoundingBox(),handle.level(),List.of());
        var predicted=at.clone().add(valid.x,valid.y,valid.z);
        return inside(predicted)?predicted:at;
    }

    private static PearlPlan planPearl(NativeControl.Actor actor,Player opponent,Vector velocity){
        Player player=actor.player();Location lookFrom=player.getEyeLocation(),self=player.getLocation(),enemy=opponent.getLocation();
        double dx=self.getX()-enemy.getX(),dz=self.getZ()-enemy.getZ(),n=Math.hypot(dx,dz);
        if(n<.01||n>9)return null;
        double ux=dx/n,uz=dz/n;
        var destination=n<4.3?self.clone().add(-uz*2,0,ux*2):enemy.clone().add(ux*3.3,0,uz*3.3);
        PearlPlan best=null;
        for(double lateral:n<4.3?new double[]{0,1.4,-1.4,2.8,-2.8,-4}:new double[]{0,1.4,-1.4,2.8,-2.8}){
            var target=destination.clone().add(-uz*lateral,0,ux*lateral);target.setY(FLOOR+.02);
            if(!inside(target))continue;
            var direction=target.toVector().subtract(lookFrom.toVector());if(direction.lengthSquared()<.5)continue;
            var look=lookFrom.clone().setDirection(direction);var landing=predictPearl(actor,opponent,look);
            if(landing==null)continue;
            var predicted=projectOpponent(opponent,velocity,landing.ticks());
            var placement=select(player,opponent,true,landing.position(),predicted,null);
            if(placement!=null&&predicted.distanceSquared(enemy)>.16
                &&select(player,opponent,true,landing.position(),enemy,placement)==null)continue;
            if(placement!=null&&(best==null||placement.score().value()>best.placement().score().value()))
                best=new PearlPlan(look,landing,predicted,placement);
        }
        return best;
    }
    private static boolean throwPearl(NativeControl.Actor actor,PearlPlan plan){
        Player player=actor.player();
        int before=amount(player,7,Material.ENDER_PEARL);
        if(before==0||player.hasCooldown(Material.ENDER_PEARL))return false;
        var inventory=player.getInventory();int previous=inventory.getHeldItemSlot();
        inventory.setHeldItemSlot(7);player.setRotation(plan.look().getYaw(),plan.look().getPitch());
        try{actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND);}
        finally{inventory.setHeldItemSlot(previous);}
        return amount(player,7,Material.ENDER_PEARL)==before-1;
    }

    static Map<String,Object> execute(NativeControl.Actor actor,Player opponent,Vector velocity,int tick){
        Player player=actor.player();
        if(!inside(player.getLocation())||!inside(opponent.getLocation())||player.getGameMode()!=GameMode.SURVIVAL)return Map.of();
        Bout bout=BOUTS.get(actor);
        if(bout==null||!Objects.equals(bout.match,actor.match)){bout=new Bout(actor.match);BOUTS.put(actor,bout);}
        if(bout.decidedTick==tick){
            if(bout.hold)return Map.of("holdPosition",true);
            if(bout.reposition){var repeat=new LinkedHashMap<String,Object>();reposition(bout,repeat,player,opponent);return repeat;}
            return anchorReady(actor)&&opponent.getY()-player.getY()<=.6?Map.of("anchorPriority",true):Map.of();
        }
        bout.decidedTick=tick;bout.hold=false;bout.reposition=false;
        var receipt=new LinkedHashMap<String,Object>();
        var inventory=player.getInventory();
        var offhand=inventory.getItemInOffHand();
        if(offhand.getType()==Material.GOLDEN_APPLE){
            if(player.hasActiveItem()&&player.getActiveItem().getType()==Material.GOLDEN_APPLE){
                receipt.put("appleEating",true);hold(bout,receipt);return receipt;
            }
            inventory.setItemInOffHand(inventory.getItem(4));inventory.setItem(4,offhand);
            receipt.put("appleFinished",true);
        }
        if(equipTotem(player))receipt.put("totemEquipped",true);
        double distance=player.getLocation().distanceSquared(opponent.getLocation());
        var apples=inventory.getItem(4);
        if(apples!=null&&apples.getType()==Material.GOLDEN_APPLE&&apples.getAmount()>0
            &&player.getAbsorptionAmount()<.5&&player.getFireTicks()<=0&&!player.isInLava()
            &&!player.hasActiveItem()&&!actor.handle.handActionLocked()
            &&(distance>=36||distance>=16&&!player.hasLineOfSight(opponent))){
            var saved=inventory.getItemInOffHand();
            inventory.setItem(4,saved);inventory.setItemInOffHand(apples);
            actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),InteractionHand.OFF_HAND);
            if(player.hasActiveItem()&&player.getActiveItem().getType()==Material.GOLDEN_APPLE){
                receipt.put("appleStarted",true);hold(bout,receipt);return receipt;
            }
            inventory.setItemInOffHand(saved);inventory.setItem(4,apples);
        }
        if(velocity==null)return receipt; // Allow apple upkeep without overriding a non-crystal combat order.
        boolean anchor=anchorReady(actor);
        Placement elevatedPlan=null;
        if(anchor&&opponent.getY()-player.getY()>.6&&amount(player,2,Material.END_CRYSTAL)>0&&distance<=30){
            elevatedPlan=select(player,opponent,false);
            if(elevatedPlan!=null)anchor=false;
        }
        if(anchor)receipt.put("anchorPriority",true);
        if(bout.pendingAnchor!=null){
            if(tick<=bout.pendingUntil&&bout.pendingAnchor.getType()==Material.RESPAWN_ANCHOR){
                if(finishAnchor(actor,opponent,bout.pendingAnchor,receipt)){bout.pendingAnchor=null;bout.landed=false;}
                hold(bout,receipt);return receipt;
            }
            bout.pendingAnchor=null;
        }
        if(tick<=bout.pearlUntil){hold(bout,receipt);return receipt;}
        if(bout.pearlUntil>=0){bout.pearlUntil=-1;bout.pearlPlacement=null;receipt.put("pearlFlightExpired",true);}
        if(bout.landed&&distance>30&&bout.pearlPlacement!=null)clearPearlPlacement(bout,receipt);
        Placement current=anchor&&distance<=30&&!bout.landed?select(player,opponent,true):null;
        if(anchor&&(current==null||current.cover()!=null)&&distance<=81&&!bout.landed&&amount(player,7,Material.ENDER_PEARL)>0){
            if(tick>=bout.pearlRetry&&!player.hasCooldown(Material.ENDER_PEARL)){
                bout.pearlRetry=tick+4;
                var plan=planPearl(actor,opponent,velocity);
                if(plan!=null&&throwPearl(actor,plan)){
                    bout.pearlUntil=tick+plan.landing().ticks()+4;bout.pearlRetry=tick;
                    bout.pearlPlacement=plan.placement();
                    receipt.put("pearlThrown",true);
                    var landing=plan.landing().position();var enemy=plan.opponent();var base=plan.placement().base();var cover=plan.placement().cover();
                    receipt.put("pearlPlan",Map.of("landing",List.of(landing.getX(),landing.getY(),landing.getZ()),
                        "flightTicks",plan.landing().ticks(),"opponent",List.of(enemy.getX(),enemy.getY(),enemy.getZ()),
                        "anchor",coordinates(base),"cover",coordinates(cover),
                        "damage",Map.of("self",plan.placement().score().self(),"target",plan.placement().score().target())));
                    hold(bout,receipt);return receipt;
                }
            }
        }
        if(distance>30){
            if(anchor&&bout.landed)reposition(bout,receipt,player,opponent);
            return receipt;
        }
        if(anchor){
            var remembered=bout.pearlPlacement;
            var plan=bout.landed?select(player,opponent,true):current;
            if(bout.landed&&remembered!=null)receipt.put("pearlPlanReused",plan!=null&&remembered.base().equals(plan.base())
                &&Objects.equals(remembered.cover(),plan.cover())&&Objects.equals(remembered.second(),plan.second()));
            bout.pearlPlacement=null;
            int placed=0;
            if(plan!=null&&plan.cover()!=null){
                if(click(actor,1,Material.OBSIDIAN,plan.cover().getRelative(BlockFace.DOWN),true)==1){
                    placed=1;
                    if(plan.second()!=null&&click(actor,1,Material.OBSIDIAN,plan.second().getRelative(BlockFace.DOWN),true)==1)placed++;
                    receipt.put("obsidianConsumed",placed);receipt.put("basePlaced",true);hold(bout,receipt);
                }else{
                    var score=BlastDamage.estimate(player,opponent,center(plan.base(),.5),true,null);
                    receipt.put("coverPlacementFailed",true);
                    plan=canBlastWithoutCover(player,score)?new Placement(plan.base(),null,score):null;
                }
            }
            if(plan==null){
                if(bout.landed&&remembered!=null)clearPearlPlacement(bout,receipt);
                reposition(bout,receipt,player,opponent);return receipt;
            }
            var base=plan.base();
            if(click(actor,5,Material.RESPAWN_ANCHOR,base.getRelative(BlockFace.DOWN),true)!=1||base.getType()!=Material.RESPAWN_ANCHOR){
                receipt.put("anchorPlacementFailed",true);reposition(bout,receipt,player,opponent);return receipt;
            }
            hold(bout,receipt);
            receipt.put("anchorConsumed",1);
            receipt.put("anchorPlacement",Map.of("anchor",coordinates(base),"cover",coordinates(plan.cover())));
            if(placed>1)receipt.put("secondCover",coordinates(plan.second()));
            bout.pendingAnchor=base;bout.pendingUntil=tick+4;
            if(finishAnchor(actor,opponent,base,receipt)){
                if(bout.landed)receipt.put("pearlLandingToBlastTicks",tick-bout.landedAt);
                bout.pendingAnchor=null;bout.landed=false;
            }
            return receipt;
        }
        CrystalHit best=null;
        for(Entity e:player.getNearbyEntities(3.5,3.5,3.5))if(e instanceof EnderCrystal crystal){
            var hit=scoreCrystal(player,opponent,crystal);
            if(hit!=null&&(best==null||hit.score().value()>best.score().value()))best=hit;
        }
        if(hitCrystal(actor,best,tick,receipt)){hold(bout,receipt);return receipt;}
        if(amount(player,2,Material.END_CRYSTAL)==0)return receipt;
        var plan=elevatedPlan!=null?elevatedPlan:select(player,opponent,false);if(plan==null)return receipt;
        var base=plan.base();
        if(base.getType().isAir()){
            if(click(actor,1,Material.OBSIDIAN,base.getRelative(BlockFace.DOWN),true)!=1)return receipt;
            receipt.put("basePlaced",true);receipt.put("obsidianConsumed",1);
        }
        if(click(actor,2,Material.END_CRYSTAL,base,false)==1){
            var at=base.getLocation().add(.5,1,.5);
            receipt.put("crystalSpawned",true);receipt.put("crystalConsumed",1);hold(bout,receipt);
            for(var entity:player.getWorld().getNearbyEntities(at,.25,.25,.25,e->e instanceof EnderCrystal)){
                entity.addScoreboardTag(TAG);hitCrystal(actor,scoreCrystal(player,opponent,(EnderCrystal)entity),tick,receipt);
            }
        }
        return receipt;
    }

    private static void reposition(Bout bout,Map<String,Object> receipt,Player player,Player opponent){
        bout.reposition=true;var route=anchorRoute(player,opponent);
        receipt.put("repositionForAnchor",true);receipt.put("anchorPriority",true);
        receipt.put("anchorHeading",List.of(route.getX(),route.getZ()));
    }
    private static void clearPearlPlacement(Bout bout,Map<String,Object> receipt){
        bout.pearlPlacement=null;receipt.put("pearlLandingPlanLost",true);
    }
    private static void hold(Bout bout,Map<String,Object> receipt){bout.hold=true;receipt.put("holdPosition",true);}
}
