# Tiny Language Transformer WaveDog

这是 WaveJ 的 Minecraft PvP 专用对话模型。五只 WaveDog 机器人共用一套权重。大厅里只有 WaveDog 回普通聊天，直接发「你好」「怎么开打」「你会什么」即可。对战中由参赛机器人发言。

## 语料怎样进入模型

118 条 PvP 示例和 6 条大厅回复全部拆成可复用词元，再进入逐词训练。中文优先识别「后撤」「连招」「竞技场」等领域词，其余拆成单字。英文缩写、单词、部分词缀和标点各自保留。例如「你这后撤步挺熟」拆成「你｜这｜后撤｜步｜挺｜熟」。新加入的三组调侃及其谐音写法也参与训练。

服务器先根据真实事件确定允许的发言意图，再把战况向量和最近一条玩家消息送给词元生成器。生成器根据此前写出的词元预测下一项，可以在共享词元处接上另一条语料的后半句。对战语料按意图约束，格挡评论要求服务端确认实际格挡。模型输出过长或重复时会跳过本次发言。

普通聊天会自动学习。大厅把识别到的问法拆成词元并存入 `outputs/pvp-perception-language/lobby-chat-learning.json`，之后可识别相近问法。对战中，普通聊天只有与近期已结算事件吻合，才会生成 `online-examples.jsonl` 样本并更新 `online-adapter.json` 的聊天特征权重，玩家仍可用 `/wdnative teach` 明确教一句台词。词表外的新词需要补进下一轮生成模型训练。

## 训练和保存位置

- `work/pvp-dual-brain/perception-language/dialogue.js` 中的 `PHRASES` 保存 PvP 语料和触发条件。
- `work/pvp-dual-brain/perception-language/generation-experiment.js` 中的 `lobby`、`situations`、`teacherExamples()` 提供大厅问法、示例和训练样本。
- 同目录的 `generation-runtime.mjs` 定义分词规则，`live-worker.js` 接受普通聊天，`lobby-learning.js` 和 `online-trainer.js` 按大厅或对局更新在线记录。
- 从项目根目录运行 `node work/pvp-dual-brain/perception-language/generation-experiment.js outputs/pvp-perception-language/token-next 1700`。输出目录下的 `checkpoint.json` 是浮点训练权重，`reply.int8.bin` 是生成器的发布权重，`report.json` 是训练和验证指标。上线模型在 `outputs/pvp-perception-language/reply.int8.bin`，意图模型在同目录的 `checkpoint.json`。

## 解压后验证

需要 Node.js 24。可以只跑量化生成器，也可以装依赖后跑全套对话检查。

```powershell
Get-Content -Encoding utf8 .\validation\sample-input.jsonl |
  node .\work\pvp-dual-brain\perception-language\generation-runtime.mjs .\outputs\pvp-perception-language\reply.int8.bin

npm.cmd --prefix .\work\pvp-dual-brain ci --omit=dev
node .\work\pvp-dual-brain\perception-language\test-token-corpus.js .\outputs\pvp-perception-language\reply.int8.bin
node .\work\pvp-dual-brain\perception-language\test-live-online.js .\outputs\pvp-perception-language\reply.int8.bin
```

量化权重在 `outputs/pvp-perception-language/reply.int8.bin`。验证结果和示例在 `validation`。支持的训练入口为 `generation-experiment.js`，它需要同目录的语言源码及上一步的 Node 依赖。

## 接入已有的 WaveDog 服务器

1. 准备运行正常的 WaveDog 服务器、兼容的竞技场以及 Paper 1.21.11、Java 21 和 Node.js 24。
2. 将 `work`、`outputs` 合并到 WaveDog 项目目录并安装 Node 依赖。备份目标服相应 JAR 后，把 `integration/plugins` 下两个 JAR 放进服务器的 `plugins`。已有同名待更新 JAR 时，先清理该待更新条目，防止启动时覆盖。
3. 在 `plugins/WaveDogNativeControl/config.yml` 设置 `dialogue-enabled: true`。启动命令在 `-jar` 前加 `"-Dwavedog.workspace=项目绝对路径"` 和 `"-Dwavedog.node=node.exe 的绝对路径"`。
4. 启动后确认日志出现 `Local PvP perception speech ready (token dialogue enabled)`。已接入同版 Java 桥接的服务器可以用 `/wdnative restart-speech` 应用 Node 源码和词元权重更新。

包内包含源码、两份模型权重、桥接插件和可直接运行的合成样例。世界存档、其他战斗插件、私人聊天及教学记录由部署环境管理。
