import readline from 'node:readline'
import fs from 'node:fs'
import path from 'node:path'
import {Worker} from 'node:worker_threads'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {DialogueEngine} from './infer.js'
import {INTENTS,canSpeak,persona,pvpFromDual,speak} from './dialogue.js'
import {applyAdapter,baseHash,chatBias,intentName} from './online-adapter.js'
import {createTokenSpeech} from './generation-live.js'
import {openLobbyLearning} from './lobby-learning.js'

await tf.setBackend('cpu');await tf.ready()
const checkpoint=path.resolve(process.argv[2])
const directory=path.dirname(checkpoint),hash=baseHash(checkpoint)
const adapterPath=path.join(directory,'online-adapter.json')
const feedbackPath=path.join(directory,'live-feedback.jsonl')
const examplesPath=path.join(directory,'online-examples.jsonl')
const cursorPath=path.join(directory,'live-feedback.cursor')
const chatPath=path.join(directory,'player-chat.jsonl')
const chatCursorPath=path.join(directory,'player-chat.cursor')
const engine=new DialogueEngine(checkpoint)
const tokenCheckpoint=path.join(directory,'reply.int8.bin')
const tokenSpeech=fs.existsSync(tokenCheckpoint)?createTokenSpeech(tokenCheckpoint,
  openLobbyLearning(path.join(directory,'lobby-chat-learning.json'))):null
let onlineAdapter=fs.existsSync(adapterPath)?JSON.parse(fs.readFileSync(adapterPath,'utf8')):null
if(onlineAdapter)applyAdapter(engine.model,onlineAdapter,hash)
const actors=new Map(),emit=row=>process.stdout.write(JSON.stringify(row)+'\n')
const pendingFeedback=new Map()
const trainer=new Worker(new URL('./online-trainer.js',import.meta.url),
  {workerData:{checkpoint,adapter:adapterPath,examples:examplesPath}})
trainer.on('message',row=>{
  if(row.ready){emit({trainingReady:true,revision:row.revision});return}
  const original=pendingFeedback.get(row.id)
  pendingFeedback.delete(row.id)
  if(row.error){
    if(original)emit({feedbackStatus:true,teacher:original.teacher,message:'教学未生效：'+row.error})
    else emit({error:'Online learning: '+row.error})
    return
  }
  if(row.trained){
    try{applyAdapter(engine.model,row.adapter,hash);onlineAdapter=row.adapter}
    catch(error){emit({error:'Online adapter rejected: '+String(error)});return}
    if(original)emit({feedbackStatus:true,teacher:original.teacher,
      message:`${original.speaker} 已学到这条示范（第 ${row.revision} 次更新）。`})
    else if(row.source==='ordinary-chat')emit({chatLearning:true,mode:'duel',revision:row.revision})
  }
})
trainer.on('error',error=>emit({error:'Online trainer: '+String(error)}))
let cursor=Number(fs.existsSync(cursorPath)?fs.readFileSync(cursorPath,'utf8'):0)||0
let chatCursor=Number(fs.existsSync(chatCursorPath)?fs.readFileSync(chatCursorPath,'utf8'):0)||0
const duelChatCues=[
  ['opener',/^(?:你好|来一把|来打一把|开打吧|准备好了|glhf|good luck)(?:[，,\s]*(?:来一把|来打一把|开打吧))?$/iu],
  ['nice_bow',/^(?:好箭|好弓箭|这箭(?:真准|挺准|漂亮)|nice shot)$/iu],
  ['nice_mace',/^(?:好锤|这锤(?:可以|挺准)|nice mace)$/iu],
  ['nice_crystal',/^(?:好炸|水晶放得漂亮|nice crystal)$/iu],
  ['combo_hype',/^(?:好连招|你这波连得好|被你连上了|nice combo|good combo)$/iu],
  ['shield_respect',/^(?:好盾|盾挡得好|nice block|good block)$/iu]
]
function learnDuelChat(actor){
  const row=actor.pendingChat
  if(!row)return
  const latest=actor.states.at(-1)
  if(latest&&latest.tick-row.tick>60){actor.pendingChat=null;return}
  const state=actor.states.findLast(state=>state.tick>=row.tick-40&&state.tick<=row.tick+10
    &&canSpeak(row.intent,state.events)&&(row.intent!=='shield_respect'||state.shieldBlocked))
  if(!state)return
  actor.pendingChat=null
  actor.lastAutoChatTick=row.tick
  const sample={id:row.id,source:'ordinary-chat',history:state.history,persona:persona(row.speaker),
    label:INTENTS.indexOf(row.intent),chatText:row.text}
  fs.appendFileSync(examplesPath,JSON.stringify(sample)+'\n')
}
function pollChat(){
  if(!fs.existsSync(chatPath))return
  const size=fs.statSync(chatPath).size
  if(size<chatCursor)chatCursor=0
  const length=Math.min(size-chatCursor,1024*1024)
  if(length<=0)return
  const bytes=Buffer.alloc(length),file=fs.openSync(chatPath,'r')
  try{fs.readSync(file,bytes,0,length,chatCursor)}finally{fs.closeSync(file)}
  const last=bytes.lastIndexOf(10)
  if(last<0)return
  for(const line of bytes.subarray(0,last+1).toString('utf8').trimEnd().split('\n')){
    try{
      const row=JSON.parse(line),actor=actors.get(row.speaker)
      if(actor&&actor.matchId===row.matchId&&typeof row.text==='string'
        &&row.text.length<=160&&Number.isFinite(row.tick)){
        actor.lastChat={text:row.text,tick:row.tick,player:row.player}
        const phrase=row.text.trim().replace(/[。！？!?]+$/u,'')
        const intent=duelChatCues.find(([,cue])=>cue.test(phrase))?.[0]
        if(intent&&typeof row.id==='string'&&row.tick-actor.lastAutoChatTick>=60){
          actor.pendingChat={...row,intent}
          learnDuelChat(actor)
        }
      }
    }catch(error){emit({error:'Invalid duel chat record: '+String(error)})}
  }
  chatCursor+=last+1
  fs.writeFileSync(chatCursorPath,String(chatCursor))
}
function pollFeedback(){
  if(!fs.existsSync(feedbackPath))return
  const size=fs.statSync(feedbackPath).size
  if(size<cursor)cursor=0
  const length=Math.min(size-cursor,1024*1024)
  if(length<=0)return
  const bytes=Buffer.alloc(length),file=fs.openSync(feedbackPath,'r')
  try{fs.readSync(file,bytes,0,length,cursor)}finally{fs.closeSync(file)}
  const last=bytes.lastIndexOf(10)
  if(last<0)return
  const rows=bytes.subarray(0,last+1).toString('utf8').trimEnd().split('\n')
  for(const line of rows){
    try{
      const row=JSON.parse(line),actor=actors.get(row.speaker)
      if(!actor||actor.matchId!==row.matchId||!Array.isArray(actor.states))
        throw Error('duel context is no longer available')
      const intent=intentName(row.intent)
      if(!intent)throw Error('unknown intent '+row.intent)
      const phrase=String(row.phrase||'')
      if(intent!=='silence'&&(!phrase||phrase.length>40||/[\r\n\u0000-\u001f]/u.test(phrase)))
        throw Error('phrase must be 1–40 characters on one line')
      const state=[...actor.states].reverse().find(s=>s.tick<=row.tick
        &&row.tick-s.tick<=100&&canSpeak(intent,s.events))
      if(!state)throw Error('no matching verified PvP event in the last five seconds')
      const chatText=actor.lastChat&&row.tick-actor.lastChat.tick>=0
        &&row.tick-actor.lastChat.tick<=160?actor.lastChat.text:''
      const sample={id:row.id,history:state.history,persona:persona(row.speaker),
        label:INTENTS.indexOf(intent),phrase:intent==='silence'?'':phrase,chatText}
      pendingFeedback.set(row.id,{teacher:row.teacher,speaker:row.speaker})
      fs.appendFileSync(examplesPath,JSON.stringify(sample)+'\n')
    }catch(error){
      try{const row=JSON.parse(line);emit({feedbackStatus:true,teacher:row.teacher,
        message:'教学未生效：'+String(error.message||error).slice(0,120)})}
      catch{emit({error:'Invalid teaching record'})}
    }
  }
  cursor+=last+1
  fs.writeFileSync(cursorPath,String(cursor))
}
setInterval(()=>{try{pollFeedback()}catch(error){emit({error:'Teaching input: '+String(error)})}},500).unref()
setInterval(()=>{try{pollChat()}catch(error){emit({error:'Duel chat input: '+String(error)})}},500).unref()
let lastLobbyAt=-Infinity
emit({ready:true,model:'WaveDog-PvP-Perception-v1',tokenSpeech:Boolean(tokenSpeech)})
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
  try{
    const input=JSON.parse(line),{speaker,matchId}=input
    if(input.kind==='lobby'){
      if(!tokenSpeech||speaker!=='WaveDog'||typeof input.playerId!=='string'||
        typeof input.text!=='string'||input.text.length>160)continue
      const text=tokenSpeech.lobby(input.text,Date.now()-lastLobbyAt>=8000)
      if(text){
        lastLobbyAt=Date.now()
        emit({speaker,matchId:'',kind:'lobby',playerId:input.playerId,text})
      }
      continue
    }
    if(!speaker||!matchId||!input.frame)continue
    let actor=actors.get(speaker)
    if(!actor||actor.matchId!==matchId){
      engine.reset(speaker)
      actor={matchId,first:true,greeted:false,previous:null,recentHits:[],lastVector:null,lastPvp:null,
        states:[],lastChat:null,pendingChat:null,lastAutoChatTick:-Infinity}
      actors.set(speaker,actor)
    }
    const f=input.frame
    f.tick=Number(f.observation?.tick)
    if(!Number.isFinite(f.tick))continue
    const damage=(f.nativeEvents||[]).filter(e=>e.type==='damage'&&!e.cancelled&&e.amount>0)
    const shieldBlocked=(f.nativeEvents||[]).some(e=>e.type==='damage'&&!e.cancelled
      &&e.attacker===speaker&&e.melee===true&&e.amount===0&&e.shieldModifier<0)
    if(damage.some(e=>e.attacker===speaker)&&actor.recentHits.at(-1)!==f.tick)
      actor.recentHits.push(f.tick)
    actor.recentHits=actor.recentHits.filter(tick=>f.tick-tick<=30)
    const enemyHit=damage.find(e=>e.victim===speaker&&e.weapon!=='end_crystal')
    const previous=input.kind==='prepare'?null:actor.previous
    const retreat=previous&&f.seen?.visible&&previous.seen?.visible
      &&f.tick-previous.tick>=2&&f.tick-previous.tick<=20
      &&Math.hypot(f.seen.x-previous.seen.x,f.seen.z-previous.seen.z)>.75
      &&f.observation.distance-previous.observation.distance>.7&&!damage.length
    const events=input.kind==='prepare'?{boutStart:true,quiet:true}:input.kind==='end'
      ?{boutEnd:true,won:input.winner===speaker,lost:Boolean(input.winner&&input.winner!==speaker)}
      :{boutStart:actor.first,enemyRetreat:Boolean(retreat),
        enemyCrystalHit:damage.some(e=>e.weapon==='end_crystal'&&e.victim===speaker),
        ownCrystalHit:damage.some(e=>e.weapon==='end_crystal'&&e.attacker===speaker),
        enemyBowHit:Boolean(enemyHit&&!enemyHit.melee
          &&['bow','crossbow'].includes(f.observation.targetShotWeapon)),
        enemyMaceHit:Boolean(enemyHit?.melee&&f.seen.held==='MACE'),
        ownCombo:actor.recentHits.length>=2,ownLowHealth:f.self.health<=6,
        enemyShield:shieldBlocked||Boolean(f.observation.targetShieldRaised)}
    const son=nativeObservation(f,{})
    const pvp=pvpFromDual(f.neuralFallback?.proposal??{})
    actor.lastVector=son;actor.lastPvp=pvp;actor.first=false
    if(input.kind==='prepare')actor.previous=null
    else if(!previous||f.tick-previous.tick>=8)actor.previous=f
    const chatText=actor.lastChat&&f.tick-actor.lastChat.tick>=0
      &&f.tick-actor.lastChat.tick<=160?actor.lastChat.text:''
    const generate=tokenSpeech?(intent,session)=>tokenSpeech.battle({
        intent,history:session.history,events,chat:chatText,shieldBlocked,low:events.ownLowHealth,
        lastText:session.lastText,random:Math.random
      }):()=>null
    const result=engine.decide({speaker,sonVector:son,pvpVector:pvp,events,
      chatBias:chatText?chatBias(onlineAdapter,chatText):null,generate})
    const history=engine.sessions.get(speaker)?.history
    if(history){
      actor.states.push({tick:f.tick,events,history:structuredClone(history),shieldBlocked})
      actor.states=actor.states.filter(state=>f.tick-state.tick<=100)
      learnDuelChat(actor)
    }
    if(input.kind==='prepare'&&!actor.greeted){
      // A new duel gets one opening line even when the small model prefers silence.
      // Use the same phrase selector and session cooldown as model speech.
      const opening=result.said?result.text:speak('opener',events,engine.sessions.get(speaker),
        Date.now(),Math.random,generate)
      if(opening){
        actor.greeted=true
        emit({speaker,matchId,kind:'prepare',intent:'opener',text:opening})
      }
    }else if(result.said)emit({speaker,matchId,kind:input.kind||'frame',intent:result.intent,text:result.text})
  }catch(error){emit({error:String(error).slice(0,300)})}
}
engine.dispose()
