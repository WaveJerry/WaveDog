import {canSpeak, frame, PHRASES} from './dialogue.js'
import {SON_WIDTH, PVP_WIDTH} from './model.js'
import {loadReplyModel, split} from './generation-runtime.mjs'

const lobbyTopics = [
  ['greeting', /^(?:你好|您好|嗨|哈喽|哈啰|在吗|在不在|早上好|晚上好|hello|hi)(?:呀|啊|嘛|吗|哈)?$/iu,
    '你好', ['你好，想练哪种对战？', '我在，随时可以开打。']],
  ['duel', /^(?:怎么|怎样|如何|在哪)(?:对战|开打|开局|开始|匹配|进竞技场)(?:呀|啊|嘛|呢)?$/u,
    '怎么开打', ['去竞技场点我的对战按钮。', '点竞技场里的对战按钮就能开打。']],
  ['capability', /^(?:你会什么|你会啥|你能做什么|你有什么功能|你能干啥|你能做啥|你能干什么)(?:呀|啊|呢)?$/u,
    '你会什么', ['我能陪你练 PvP。', '我可以在竞技场和你对战。']]
]
const clauses = {
  nice_bow: {zh:['这箭挺准','这箭漂亮'], en:['Nice shot','Good arrow']},
  combo_hype: {zh:['这波连上了','这套连得挺顺'], en:['That combo landed','Clean combo']},
  shield_respect: {zh:['这盾举得及时','这下盾防得好'], en:['Good block','Nice shield']}
}
const endings = {
  zh:{steady:['，继续打。','，还能接着打。'],low:['，我得缓一下。','，我得先稳一下。']},
  en:{steady:[', keep going.',', we can keep fighting.'],low:[', I need a breather.',', I need to reset.']}
}
const hasChinese = text => /\p{Script=Han}/u.test(text)

// Each approved sample contributes only local transitions. The next token
// is predicted by the Transformer. A shared token may lead to another
// sample's continuation without making that complete sentence an entry.
export function tokenTransitions(vocabulary, phrases) {
  const edges = new Map()
  for (const phrase of phrases) {
    const ids = split(phrase).map(token => vocabulary.get(token))
    if (!ids.length || ids.some(id => id === undefined)) continue
    let previous = 2
    for (const next of [...ids,3]) {
      if (!edges.has(previous)) edges.set(previous,new Set())
      edges.get(previous).add(next)
      previous = next
    }
  }
  return previous => edges.get(previous) ?? new Set()
}

export function createTokenSpeech(checkpoint,lobbyLearning=null) {
  const model = loadReplyModel(checkpoint)
  function render({intent, history, phrases, chat, prompt, lastText, random, verify = () => true}) {
    const transitions = tokenTransitions(model.vocabulary,phrases)
    for (const [message, sample] of [[chat || prompt,random],[prompt,random],[prompt,null]]) {
      const text = model.generate({history,chat:message,intent},sample,transitions)
      if (text && text.length <= 40 && text !== lastText && verify(text)) return text
    }
    return null
  }
  return {
    lobby(chat,reply=true) {
      const prompt = chat.trim().replace(/^(?:WaveDog)[\s，,:：]+/iu,'').replace(/[\p{P}\s]+/gu,'')
      const recognized = lobbyTopics.find(([, matches]) => matches.test(prompt))
      const remembered = recognized ? null : lobbyLearning?.recognize(prompt)
      const topic = recognized ?? lobbyTopics.find(([key])=>key===remembered)
      if (!topic) return null
      const [key,, canonical, phrases] = topic
      if(recognized)lobbyLearning?.remember(prompt,key)
      if(!reply)return null
      const sonVector = Array(SON_WIDTH).fill(0)
      sonVector[0] = sonVector[2] = sonVector[31] = sonVector[96] = 1
      const observation = frame({sonVector,pvpVector:Array(PVP_WIDTH).fill(0)})
      return render({intent:'lobby_'+key, history:[observation,observation],
        phrases, chat:prompt, prompt:canonical, random:Math.random})
    },
    battle({intent, history, events, chat, shieldBlocked, low, lastText, random}) {
      if (!history.length || !canSpeak(intent,events) || !PHRASES[intent] ||
          intent === 'shield_respect' && !shieldBlocked) return null
      const explicitEnglish = /英文|英语|english/i.test(chat)
      const explicitChinese = /中文|汉语|chinese/i.test(chat)
      const locale = explicitEnglish ? 'en' : 'zh'
      const prompt = locale === 'en' ? '请讲英文' : '请讲中文'
      const states = low ? 'low' : 'steady'
      const corpus = PHRASES[intent]
      const localized = explicitEnglish || explicitChinese
        ? corpus.filter(text=>hasChinese(text)===!explicitEnglish)
        : corpus
      const relevant = clauses[intent]?.[locale] ?? []
      const phrases = [...(localized.length ? localized : corpus)]
      // The held-out pair stays absent here as well. It can be reached
      // through the shared punctuation and subsequent token transitions.
      for (const [first,second] of [[0,0],[0,1],[1,0]])
        if (relevant[first]) phrases.push(relevant[first]+endings[locale][states][second])
      const last = history.at(-1)
      return render({intent, history:[history.at(-2) ?? last,last], phrases,
        chat,prompt,lastText,random,
        verify: text => !/\p{Cc}/u.test(text) && (
          !localized.length || !explicitEnglish && !explicitChinese || hasChinese(text)===!explicitEnglish)
      })
    }
  }
}
