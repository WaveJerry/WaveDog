import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {spawn} from 'node:child_process'
import readline from 'node:readline'
import {openLobbyLearning} from './lobby-learning.js'
import {createTokenSpeech} from './generation-live.js'

const root=path.resolve('outputs/pvp-perception-language')
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-live-online-'))
const checkpoint=path.join(directory,'checkpoint.json')
fs.copyFileSync(path.join(root,'checkpoint.json'),checkpoint)
const tokenPath=process.argv[2]
if(tokenPath)fs.copyFileSync(tokenPath,path.join(directory,'reply.int8.bin'))
const frame={
  self:{x:1000,y:221,z:1000,eyeY:222.62,health:20,charge:1,ground:true,
    vx:0,vy:0,vz:0,shieldAvailable:true,shielding:false,using:false,useTicks:0,
    arrows:8,crossbowLoaded:false,held:0,nativeYaw:-90,nativePitch:0},
  seen:{x:1004,y:221,z:1000,visible:true,using:false,held:'DIAMOND_SWORD',nativeYaw:90,arrows:[]},
  observation:{tick:100,reach:3.7,distance:4,targetShieldRaised:false}
}
const child=spawn(process.execPath,[path.resolve('work/pvp-dual-brain/perception-language/live-worker.js'),checkpoint],
  {stdio:['pipe','pipe','pipe']})
const rows=[],lines=readline.createInterface({input:child.stdout})
lines.on('line',line=>{try{rows.push(JSON.parse(line))}catch{}})
let errors='';child.stderr.on('data',chunk=>{errors+=chunk})
async function until(predicate,limitMs=15000){
  const started=Date.now()
  while(Date.now()-started<limitMs){
    const found=rows.find(predicate)
    if(found)return found
    if(child.exitCode!==null)throw Error('speech worker exited: '+errors)
    await new Promise(resolve=>setTimeout(resolve,100))
  }
  throw Error('speech worker timed out: '+JSON.stringify(rows)+' '+errors)
}
try{
  const ready=await until(row=>row.ready)
  if(tokenPath){
    assert.equal(ready.tokenSpeech,true)
    for(const sample of [
      {speaker:'WaveDogSister',playerId:'wrong-bot',text:'你好'},
      {speaker:'WaveDog',playerId:'irrelevant',text:'今天天气如何'},
      {speaker:'WaveDog',playerId:'tester',text:'怎么开打'},
      {speaker:'WaveDog',playerId:'second',text:'你有什么功能'}
    ]) child.stdin.write(JSON.stringify({kind:'lobby',...sample})+'\n')
    const lobby=await until(row=>row.kind==='lobby')
    assert.equal(lobby.speaker,'WaveDog')
    assert.equal(lobby.playerId,'tester')
    assert.match(lobby.text,/竞技场.*对战按钮/u)
    await new Promise(resolve=>setTimeout(resolve,200))
    assert.equal(rows.filter(row=>row.kind==='lobby').length,1)
    const learned=openLobbyLearning(path.join(directory,'lobby-chat-learning.json'))
    assert.equal(learned.recognize('嗯你有什么功能'),'capability')
    assert.equal(learned.recognize('今天天气如何'),null)
    assert(createTokenSpeech(tokenPath,learned).lobby('嗯你有什么功能'))
  }
  await until(row=>row.trainingReady)
  child.stdin.write(JSON.stringify({speaker:'WaveDogSon',matchId:'test-live-online',
    frame,kind:'prepare'})+'\n')
  if(tokenPath)await until(row=>row.kind==='prepare'&&row.matchId==='test-live-online'&&row.speaker==='WaveDogSon')
  const greeting=await until(row=>row.speaker==='WaveDogSon'&&row.kind==='prepare')
  assert.equal(greeting.intent,'opener')
  assert(greeting.text.length>0)
  child.stdin.write(JSON.stringify({speaker:'WaveDogSon',matchId:'test-live-online',
    frame,kind:'prepare'})+'\n')
  await new Promise(resolve=>setTimeout(resolve,700))
  assert.equal(rows.filter(row=>row.speaker==='WaveDogSon'&&row.kind==='prepare').length,1)
  const chatLog=path.join(directory,'player-chat.jsonl')
  const message={speaker:'WaveDogSon',matchId:'test-live-online',player:'WaveJerry',tick:frame.observation.tick}
  fs.writeFileSync(chatLog,JSON.stringify({...message,id:'not-a-bow-hit',text:'好箭'})+'\n')
  await new Promise(resolve=>setTimeout(resolve,650))
  const adapterFile=path.join(directory,'online-adapter.json')
  assert(!fs.existsSync(adapterFile),'a spoken claim alone must not train an event intent')
  fs.appendFileSync(chatLog,JSON.stringify({...message,id:'plain-chat',text:'你好，来打一把'})+'\n')
  const auto=await until(row=>row.chatLearning&&row.mode==='duel')
  assert.equal(auto.revision,1)
  assert(!fs.existsSync(path.join(directory,'live-feedback.jsonl')))
  const automaticAdapter=JSON.parse(fs.readFileSync(adapterFile,'utf8'))
  assert(automaticAdapter.chatWeights.some(value=>value!==0))
  assert.deepEqual(automaticAdapter.phrases,{})
  const teaching={id:'test-live-1',teacher:'WaveJerry',speaker:'WaveDogSon',
    matchId:'test-live-online',intent:'opener',phrase:'来，认真打一把',
    tick:frame.observation.tick,submittedAt:Date.now()}
  fs.writeFileSync(path.join(directory,'live-feedback.jsonl'),JSON.stringify(teaching)+'\n')
  const result=await until(row=>row.feedbackStatus&&row.teacher==='WaveJerry')
  assert(result.message.includes('已学到'),result.message)
  const adapter=JSON.parse(fs.readFileSync(path.join(directory,'online-adapter.json'),'utf8'))
  assert.equal(adapter.revision,2)
  assert(adapter.chatWeights.some(value=>value!==0))
  console.log(JSON.stringify({pass:true,revision:adapter.revision,
    adapterBytes:fs.statSync(path.join(directory,'online-adapter.json')).size}))
}finally{
  child.kill()
  if(child.exitCode===null)await new Promise(resolve=>child.once('exit',resolve))
  assert(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep))
  assert(path.basename(directory).startsWith('wavedog-live-online-'))
  fs.rmSync(directory,{recursive:true,force:true})
}
