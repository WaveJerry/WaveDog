package local.wavedog.nativecontrol;

import com.google.gson.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.BucketPickup;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Levelled;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/** UHC utility actions, arbitrated before a melee command is executed. */
final class UhcTools {
    private static final BlockFace[] FACES={BlockFace.DOWN,BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST,BlockFace.UP};
    private record Hit(Location look,BlockHitResult ray){}
    private record Segment(Vector from,Vector to){}
    private record Cover(Block block,Block foundation){}
    private record BucketUse(Block target,Material contents,boolean filling){}
    private record RescueWater(Block source,int placedAt){}
    private record WallCross(Vector heading,Vector farEdge){}
    record Route(Vector heading,String action){}
    private static final class Bout {
        final String match;
        int tick=-1;
        String action="";
        Block lava,water,mining,enemyLava;
        final Map<Integer,RescueWater> rescueWater=new LinkedHashMap<>();
        BucketUse bucketUse;
        String bucketAttempt="";
        int lavaAt,miningTick=-1000,miningStarted,wallHopUntil=-1,lastSyncJump=-100;
        int miningToolSlot=-1,miningHotbarSlot,miningReturnSlot;
        int miningHeldSlot;
        BlockState miningBlockState;
        ItemStack miningItem;
        Block refusedBlock;
        int refusedUntil;
        Vector appleEscape;
        Vector wallHop;
        boolean crossingWall;
        Vector wallFarEdge;
        Vector wallWaypoint;
        int wallRouteUntil;
        Vector wallProgressOrigin;
        int wallStillSince,lastWallCheck=-100;
        Route fatherRoute;
        int applesBefore;
        float miningProgress;
        boolean lavaRecovery;
        boolean waitingForWater;
        Bout(String match){this.match=match;}
    }
    private static final Map<NativeControl.Actor,Bout> BOUTS=new WeakHashMap<>();
    private static Bout bout(NativeControl.Actor actor){
        var state=BOUTS.get(actor);
        if(state==null||!Objects.equals(state.match,actor.match)){state=new Bout(actor.match);BOUTS.put(actor,state);}
        return state;
    }

    static boolean craftPlate(Player player){
        var inventory=player.getInventory();var planks=inventory.getItem(13);
        if(planks==null||planks.getType()!=Material.OAK_PLANKS||planks.getAmount()<2)return false;
        var matrix=new ItemStack[9];matrix[0]=new ItemStack(Material.OAK_PLANKS);matrix[1]=matrix[0].clone();
        var craft=Bukkit.craftItemResult(matrix,player.getWorld(),player);var plate=craft.getResult();
        if(plate==null||plate.getType()!=Material.OAK_PRESSURE_PLATE||!craft.getOverflowItems().isEmpty())return false;
        if(inventory.firstEmpty()<0&&planks.getAmount()!=2)return false;
        planks.setAmount(planks.getAmount()-2);inventory.setItem(13,planks.isEmpty()?null:planks);
        inventory.addItem(plate);return true;
    }
    static void waterPlaced(NativeControl.Actor actor,Block water){
        Bout bout=BOUTS.get(actor);
        if(bout!=null&&Objects.equals(bout.match,actor.match))bout.water=water;
    }
    static void enemyLavaPlaced(NativeControl.Actor actor,Block lava){
        Bout bout=BOUTS.get(actor);
        if(bout!=null&&Objects.equals(bout.match,actor.match))bout.enemyLava=lava;
    }
    private static boolean interior(Block b){
        return b.getWorld().getName().equals("world")&&b.getX()>=992&&b.getX()<=1036&&b.getZ()>=992&&b.getZ()<=1036
            &&b.getY()>=221&&b.getY()<225;
    }
    private static Vec3 vec(Vector v){return new Vec3(v.getX(),v.getY(),v.getZ());}
    private static BlockPos pos(Block b){return new BlockPos(b.getX(),b.getY(),b.getZ());}
    private static Vector center(Block b){return b.getLocation().add(.5,.5,.5).toVector();}
    private static double range(Player p){return Objects.requireNonNull(p.getAttribute(Attribute.BLOCK_INTERACTION_RANGE)).getValue();}
    private static boolean has(Player p,int slot,Material m){var item=p.getInventory().getItem(slot);return item!=null&&item.getType()==m;}
    private static boolean source(Block b,Material m){return b!=null&&b.getType()==m&&b.getBlockData() instanceof Levelled l&&l.getLevel()==0;}
    private static Material item(Player p,int slot){
        var stack=p.getInventory().getItem(slot);return stack==null?Material.AIR:stack.getType();
    }
    static Map<String,String> bucketSlots(Player p){
        return Map.of("water",item(p,5).name(),"lava",item(p,6).name(),"spare",item(p,11).name());
    }
    static String bucketAttempt(NativeControl.Actor actor){var state=BOUTS.get(actor);return state==null?"":state.bucketAttempt;}

    private static Hit ray(NativeControl.Actor actor,Vector destination,ClipContext.Fluid fluid){
        var p=actor.player();var eye=p.getEyeLocation();var start=eye.toVector();var direction=destination.clone().subtract(start);
        if(direction.lengthSquared()<1e-6)return null;
        var aim=eye.clone().setDirection(direction);
        var view=Vec3.directionFromRotation(aim.getPitch(),aim.getYaw());
        var from=vec(start);
        var hit=actor.handle.level().clip(new ClipContext(from,from.add(view.scale(range(p))),
            ClipContext.Block.OUTLINE,fluid,actor.handle));
        return hit.getType()==HitResult.Type.MISS?null:new Hit(aim,hit);
    }
    private static Hit placement(NativeControl.Actor actor,Block target,boolean bucket){
        if(!interior(target))return null;
        Vector eye=actor.player().getEyeLocation().toVector(),middle=center(target);
        if(eye.distanceSquared(middle)>Math.pow(range(actor.player())+.9,2))return null;
        for(BlockFace face:FACES){
            Block support=target.getRelative(face);
            if(support.isEmpty()||support.isLiquid())continue;
            var normal=face.getDirection();var aim=middle.clone().add(normal.multiply(.501));
            var hit=ray(actor,aim,ClipContext.Fluid.NONE);
            if(hit==null)continue;
            var block=hit.ray().getBlockPos();var side=hit.ray().getDirection();
            if(block.equals(pos(support))&&block.relative(side).equals(pos(target)))return hit;
            // A liquid-aware item may replace the clicked block itself only
            // when vanilla's block state accepts that liquid.
            if(bucket&&block.equals(pos(target)))return hit;
        }
        return null;
    }
    private static boolean placeBlock(NativeControl.Actor actor,int slot,Material material,Block target){
        if(!has(actor.player(),slot,material)||!target.isEmpty())return false;
        var hit=placement(actor,target,false);if(hit==null)return false;
        use(actor,slot,hit,true);
        return target.getType()==material;
    }
    private static void use(NativeControl.Actor actor,int slot,Hit hit,boolean block){
        var p=actor.player();var inv=p.getInventory();var previous=inv.getItemInOffHand();
        inv.setItemInOffHand(inv.getItem(slot));inv.setItem(slot,null);
        p.setRotation(hit.look().getYaw(),hit.look().getPitch());
        try{
            if(block)actor.handle.gameMode.useItemOn(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),InteractionHand.OFF_HAND,hit.ray());
            else actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),InteractionHand.OFF_HAND);
        }finally{inv.setItem(slot,inv.getItemInOffHand());inv.setItemInOffHand(previous);}
    }
    private static boolean scoop(NativeControl.Actor actor,int slot,Material liquid,Block target){
        var p=actor.player();var bucket=p.getInventory().getItem(slot);
        if(!source(target,liquid)||!interior(target)||bucket==null||bucket.getType()!=Material.BUCKET||bucket.getAmount()!=1)return false;
        Material filled=liquid==Material.LAVA?Material.LAVA_BUCKET:Material.WATER_BUCKET;
        if(slot==5&&filled!=Material.WATER_BUCKET||slot==6&&filled!=Material.LAVA_BUCKET)return false;
        for(double y:new double[]{0,.28,-.28}){
            var hit=ray(actor,center(target).add(new Vector(0,y,0)),ClipContext.Fluid.SOURCE_ONLY);
            if(hit==null||!hit.ray().getBlockPos().equals(pos(target)))continue;
            useBucket(actor,slot,hit,new BucketUse(target,filled,true));
            return !source(target,liquid)&&has(p,slot,filled);
        }
        return false;
    }
    private static boolean pour(NativeControl.Actor actor,Block target){
        return pour(actor,target,6,Material.LAVA_BUCKET);
    }
    private static boolean pour(NativeControl.Actor actor,Block target,int slot,Material bucket){
        if(slot==5&&bucket!=Material.WATER_BUCKET||slot==6&&bucket!=Material.LAVA_BUCKET)return false;
        if(!has(actor.player(),slot,bucket)||!(target.isEmpty()
            ||bucket==Material.LAVA_BUCKET&&(target.getType()==Material.WATER||source(target,Material.LAVA))
            ||bucket==Material.WATER_BUCKET&&source(target,Material.WATER)))return false;
        var hit=placement(actor,target,true);
        if(hit==null){BOUTS.get(actor).bucketAttempt="no visible support";return false;}
        var level=actor.handle.level();var at=hit.ray().getBlockPos();
        // BucketItem uses the adjacent cell unless the clicked support is a
        // liquid container. Reject targets whose actual destination differs.
        if(level.getBlockState(at).getBlock() instanceof net.minecraft.world.level.block.LiquidBlockContainer)return false;
        if(!at.relative(hit.ray().getDirection()).equals(pos(target)))return false;
        boolean replacingWater=bucket==Material.LAVA_BUCKET&&target.getType()==Material.WATER;
        useBucket(actor,slot,hit,new BucketUse(target,bucket,false));
        Material result=target.getType(),liquid=bucket==Material.LAVA_BUCKET?Material.LAVA:Material.WATER;
        BOUTS.get(actor).bucketAttempt="pour "+bucket+" at "+pos(target)+" -> "+result+" / "+item(actor.player(),slot);
        return has(actor.player(),slot,Material.BUCKET)&&(result==liquid
            ||replacingWater&&Set.of(Material.COBBLESTONE,Material.STONE,Material.OBSIDIAN).contains(result));
    }
    private static void useBucket(NativeControl.Actor actor,int slot,Hit hit,BucketUse request){
        var state=BOUTS.get(actor);state.bucketUse=request;
        try{
            var level=actor.handle.level();
            if(net.minecraft.server.MinecraftServer.getServer().isUnderSpawnProtection(level,hit.ray().getBlockPos(),actor.handle))
                useArenaBucket(actor,slot,hit,request);
            else use(actor,slot,hit,false);
        }
        finally{state.bucketUse=null;}
    }
    private static void useArenaBucket(NativeControl.Actor actor,int slot,Hit hit,BucketUse request){
        var p=actor.player();var target=request.target();var level=actor.handle.level();var at=pos(target);
        if(!actor.active||!interior(p.getLocation().getBlock())||!interior(target)||!p.hasMetadata("wavedog-duel-owner")
            ||!level.getWorldBorder().isWithinBounds(at)||!level.getWorldBorder().isWithinBounds(hit.ray().getBlockPos()))return;
        var inv=p.getInventory();var old=inv.getItemInOffHand();inv.setItemInOffHand(inv.getItem(slot));inv.setItem(slot,null);
        try{
            var held=actor.handle.getOffhandItem();if(!(held.getItem() instanceof BucketItem bucket))return;
            p.setRotation(hit.look().getYaw(),hit.look().getPitch());
            if(!request.filling()){
                var ray=hit.ray();
                if(bucket.emptyContents(actor.handle,level,at,ray,ray.getDirection(),ray.getBlockPos(),held,InteractionHand.OFF_HAND))
                    inv.setItemInOffHand(new ItemStack(Material.BUCKET));
                return;
            }
            var block=level.getBlockState(at);
            if(!(block.getBlock() instanceof BucketPickup pickup))return;
            var event=new PlayerBucketFillEvent(p,target,target,BlockFace.valueOf(hit.ray().getDirection().name()),
                Material.BUCKET,new ItemStack(request.contents()),EquipmentSlot.OFF_HAND);
            Bukkit.getPluginManager().callEvent(event);
            if(event.isCancelled()||!acceptsBucket(actor,event))return;
            var filled=pickup.pickupBlock(actor.handle,level,at,block);
            if(filled.isEmpty())return;
            inv.setItemInOffHand(CraftItemStack.asBukkitCopy(filled));
            p.getWorld().playSound(target.getLocation(),request.contents()==Material.LAVA_BUCKET?Sound.ITEM_BUCKET_FILL_LAVA:Sound.ITEM_BUCKET_FILL,1,1);
        }finally{inv.setItem(slot,inv.getItemInOffHand());inv.setItemInOffHand(old);}
    }
    static boolean acceptsBucket(NativeControl.Actor actor,PlayerBucketEvent event){
        var state=BOUTS.get(actor);var request=state==null?null:state.bucketUse;
        if(request==null)return true;
        if(event.getHand()!=EquipmentSlot.OFF_HAND||!event.getBlock().equals(request.target())
            ||(event instanceof PlayerBucketFillEvent)!=request.filling())return false;
        if(!request.filling())return event.getBucket()==request.contents();
        var result=event.getItemStack();
        Material liquid=request.contents()==Material.LAVA_BUCKET?Material.LAVA:Material.WATER;
        return source(event.getBlock(),liquid)&&result!=null&&result.getType()==request.contents()&&result.getAmount()==1;
    }
    static boolean arenaBucketInSpawn(NativeControl.Actor actor,PlayerBucketEmptyEvent event){
        var state=BOUTS.get(actor);
        if(state==null||state.bucketUse==null||!actor.active||!interior(event.getBlock())||!acceptsBucket(actor,event))return false;
        var server=net.minecraft.server.MinecraftServer.getServer();var level=actor.handle.level();
        return server.isUnderSpawnProtection(level,pos(event.getBlockClicked()),actor.handle)
            ||server.isUnderSpawnProtection(level,pos(event.getBlock()),actor.handle);
    }
    private static Vector vector(JsonObject point){return new Vector(point.get("x").getAsDouble(),point.get("y").getAsDouble(),point.get("z").getAsDouble());}
    private static List<Segment> arrowPath(JsonObject order){
        var path=new ArrayList<Segment>();
        for(var row:order.getAsJsonArray("arrow")){
            var step=row.getAsJsonObject();path.add(new Segment(vector(step.getAsJsonObject("from")),vector(step.getAsJsonObject("to"))));
        }
        return path;
    }
    private static Segment aimedLine(Player attacker,Player defender,boolean requireAim){
        var from=attacker.getEyeLocation();var to=defender.getBoundingBox().getCenter();
        if(requireAim){
            var direction=from.getDirection();
            var threat=defender.getBoundingBox().clone().expand(.9,.65,.9).rayTrace(from.toVector(),direction,28);
            return threat==null?null:new Segment(from.toVector(),threat.getHitPosition());
        }
        var delta=to.clone().subtract(from.toVector());
        if(delta.lengthSquared()<.25||delta.lengthSquared()>1024)return null;
        return new Segment(from.toVector(),to);
    }
    private static Cover cover(NativeControl.Actor actor,Player opponent,List<Segment> path,boolean melee,int stock){
        Player self=actor.player();var world=self.getWorld();var eye=self.getEyeLocation().toVector();
        var checked=new HashSet<Block>();Cover best=null;double bestScore=-1;
        for(int i=0;i<path.size();i++){
            var segment=path.get(i);var delta=segment.to().clone().subtract(segment.from());double length=delta.length();
            if(length<.001)continue;
            int steps=(int)Math.ceil(length*4);
            for(int s=0;s<=steps;s++){
                var sample=segment.from().clone().add(delta.clone().multiply((double)s/steps));
                if(eye.distanceSquared(sample)>36)continue;
                Block b=world.getBlockAt(sample.getBlockX(),sample.getBlockY(),sample.getBlockZ());
                if(!checked.add(b)||!interior(b)||!b.isEmpty())continue;
                var box=BoundingBox.of(b);
                if(box.rayTrace(segment.from(),delta,length)==null)continue;
                if(box.overlaps(self.getBoundingBox())||box.overlaps(opponent.getBoundingBox()))continue;
                if(melee){
                    var to=self.getEyeLocation().toVector().subtract(segment.from());
                    if(box.rayTrace(segment.from(),to,to.length())==null)continue;
                }
                Block foundation=null;
                if(placement(actor,b,false)==null){
                    if(stock<2||b.getY()!=222)continue;
                    foundation=b.getRelative(BlockFace.DOWN);var baseBox=BoundingBox.of(foundation);
                    var top=b.getLocation().add(.5,.001,.5).toVector();var aim=top.clone().subtract(eye);
                    if(!foundation.isEmpty()||baseBox.overlaps(self.getBoundingBox())||baseBox.overlaps(opponent.getBoundingBox())
                        ||eye.getY()<=top.getY()||aim.length()>range(self)||placement(actor,foundation,false)==null
                        ||world.rayTraceBlocks(self.getEyeLocation(),aim,aim.length(),FluidCollisionMode.NEVER,false)!=null)continue;
                }
                double score=path.size()-i+(1-(double)s/steps)*.5;
                if(foundation!=null)score-=.15;
                if(score>bestScore){best=new Cover(b,foundation);bestScore=score;}
            }
        }
        return best;
    }
    private static String defend(NativeControl.Actor actor,Player opponent,JsonObject order){
        var p=actor.player();var path=arrowPath(order);var line=aimedLine(opponent,p,true);
        if(path.isEmpty()&&NativeControl.flag(order,"rangedAim")&&line!=null){
            var direction=line.to().clone().subtract(line.from());
            if(p.getWorld().rayTraceBlocks(opponent.getEyeLocation(),direction,direction.length(),FluidCollisionMode.NEVER,true)==null)path.add(line);
        }
        int blocks=has(p,9,Material.COBBLESTONE)?9:10;
        // The existing kit stores the building blocks in the main inventory.
        if(!has(p,blocks,Material.COBBLESTONE))blocks=-1;
        int stock=blocks<0?0:p.getInventory().getItem(blocks).getAmount();
        if(!path.isEmpty()||NativeControl.flag(order,"arrowIncoming"))return blocks>=0&&!path.isEmpty()
            &&placeCover(actor,blocks,cover(actor,opponent,path,false,stock))?"arrow-cover":"arrow-fallback";
        if(NativeControl.flag(order,"rangedAim")&&line!=null&&order.get("rangedFallback") instanceof JsonObject)return "arrow-fallback";
        if(!NativeControl.flag(order,"critical"))return "";
        var melee=aimedLine(opponent,p,false);
        if(blocks>=0&&melee!=null&&placeCover(actor,blocks,cover(actor,opponent,List.of(melee),true,stock)))return "crit-cover";
        double eta=NativeControl.number(order,"criticalEta",Double.POSITIVE_INFINITY);
        int warmUp=p.isBlocking()?0:Math.max(0,5-(p.hasActiveItem()&&p.getActiveItem().getType()==Material.SHIELD?p.getHandRaisedTime():0));
        return !p.hasCooldown(Material.SHIELD)&&p.getInventory().getItemInOffHand().getType()==Material.SHIELD&&eta>=warmUp?"crit-shield":"";
    }
    private static boolean placeCover(NativeControl.Actor actor,int source,Cover cover){
        if(cover==null)return false;
        if(cover.foundation()!=null&&!placeBlock(actor,source,Material.COBBLESTONE,cover.foundation()))return false;
        return placeBlock(actor,source,Material.COBBLESTONE,cover.block());
    }

    private static Block touchingWeb(Player p){
        var box=p.getBoundingBox();var world=p.getWorld();
        for(int x=(int)Math.floor(box.getMinX()+.001);x<box.getMaxX()-.001;x++)
            for(int z=(int)Math.floor(box.getMinZ()+.001);z<box.getMaxZ()-.001;z++)
                for(int y=(int)Math.floor(box.getMinY()+.001);y<box.getMaxY()-.001;y++){
                    Block b=world.getBlockAt(x,y,z);
                    if(interior(b)&&b.getType()==Material.COBWEB)return b;
                }
        return null;
    }
    private static String mineWeb(NativeControl.Actor actor,Bout state,Block web,String action){
        if(web==null||web.equals(state.refusedBlock)&&Bukkit.getCurrentTick()<state.refusedUntil)return "";
        if(state.miningToolSlot>=0)stopMining(actor);
        var inventory=actor.player().getInventory();
        int slot=inventory.first(actor.name.equals("WaveDogFather")?Material.NETHERITE_SWORD:Material.DIAMOND_SWORD);
        if(slot<0||slot>8)return "";
        var hit=ray(actor,center(web),ClipContext.Fluid.NONE);
        // Looking down into the player's own web can start inside its outline.
        if(hit==null||!hit.ray().getBlockPos().equals(pos(web)))return "";
        return mine(actor,state,web,hit,slot,action);
    }
    private static String mine(NativeControl.Actor actor,Bout state,Block block,Hit hit,int slot,String action){
        int tick=Bukkit.getCurrentTick();
        if(actor.handle.handActionLocked())return "";
        if(tick==state.miningTick)return block.equals(state.mining)?action+"-cutting":"";
        var p=actor.player();
        var inv=p.getInventory();
        var at=pos(block);var level=actor.handle.level();var blockState=level.getBlockState(at);
        if(!block.equals(state.mining)||tick!=state.miningTick+1||blockState!=state.miningBlockState
            ||inv.getHeldItemSlot()!=state.miningHeldSlot||!inv.getItemInMainHand().equals(state.miningItem)
            ||slot!=state.miningHeldSlot){
            if(state.miningToolSlot>=0&&slot==state.miningHotbarSlot)slot=state.miningToolSlot;
            stopMining(actor);
            state.mining=block;state.miningBlockState=blockState;state.miningProgress=0;state.miningStarted=tick;
        }
        state.miningTick=tick;
        int held=inv.getHeldItemSlot();
        if(slot>8){
            int hotbar=actor.name.equals("WaveDogFather")?3:4;
            state.miningToolSlot=slot;state.miningHotbarSlot=hotbar;state.miningReturnSlot=held;
            var tool=inv.getItem(slot);inv.setItem(slot,inv.getItem(hotbar));inv.setItem(hotbar,tool);slot=hotbar;
        }
        if(held!=slot){inv.setHeldItemSlot(slot);actor.handle.resetAttackStrengthTicker();actor.lastSwitchTick=tick;}
        p.setRotation(hit.look().getYaw(),hit.look().getPitch());
        if(tick==state.miningStarted){
            state.miningHeldSlot=slot;state.miningItem=inv.getItemInMainHand().clone();
            actor.handle.stopUsingItem();
            // Selecting a hotbar slot changes the inventory immediately, but
            // Efficiency is applied by the equipment update.
            actor.handle.detectEquipmentUpdates();
            p.swingMainHand();
            level.destroyBlockProgress(actor.handle.getId(),at,0);
            return action+"-cutting";
        }
        state.miningProgress+=blockState.getDestroyProgress(actor.handle,level,at);
        if(state.miningProgress<1){
            level.destroyBlockProgress(actor.handle.getId(),at,Math.min(9,(int)(state.miningProgress*10)));
            return action+"-cutting";
        }
        try{
            if(actor.handle.gameMode.destroyBlock(at))return action+"-cut";
            state.refusedBlock=block;state.refusedUntil=tick+30;
            return action+"-blocked";
        }
        finally{stopMining(actor);}
    }

    static void stopMining(NativeControl.Actor actor){
        var state=BOUTS.get(actor);
        if(state==null||state.mining==null)return;
        actor.handle.level().destroyBlockProgress(actor.handle.getId(),pos(state.mining),-1);
        state.mining=null;state.miningItem=null;state.miningBlockState=null;
        if(state.miningToolSlot<0)return;
        var inv=actor.player().getInventory();int storage=state.miningToolSlot,hotbar=state.miningHotbarSlot;
        var tool=inv.getItem(hotbar);inv.setItem(hotbar,inv.getItem(storage));inv.setItem(storage,tool);
        if(inv.getHeldItemSlot()==hotbar)inv.setHeldItemSlot(state.miningReturnSlot);
        state.miningToolSlot=-1;
        actor.handle.detectEquipmentUpdates();
    }

    private static String mineWall(NativeControl.Actor actor,Player opponent,JsonObject order,Bout state,int tick){
        var p=actor.player();
        if(!p.isOnGround()||p.getLocation().distanceSquared(opponent.getLocation())>49
            ||NativeControl.flag(order,"wallHop")||NativeControl.flag(order,"critical")||NativeControl.flag(order,"rangedAim"))return "";
        if(NativeControl.reach(opponent,p)<=3.6&&(!opponent.isOnGround()||opponent.hasLineOfSight(p)))return "";
        Vector toward=opponent.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
        return clearWall(actor,state,tick,toward,aroundWall(actor,opponent,tick),false);
    }

    static Route recoverBlockedMelee(NativeControl.Actor actor,Player opponent,int tick,double allowed){
        var p=actor.player();
        var start=p.getLocation().toVector();
        var toward=opponent.getLocation().toVector().subtract(start).setY(0);
        if(toward.lengthSquared()<.001)toward=p.getLocation().getDirection().setY(0);
        if(toward.lengthSquared()<.001)toward=new Vector(0,0,1);
        var heading=toward.clone().normalize();
        Vector safe=null;
        for(int angle:new int[]{45,-45,90,-90,0,135,-135,180}){
            var candidate=heading.clone().rotateAroundY(Math.toRadians(angle));
            var shift=candidate.clone().multiply(.65);
            if(!wallSegment(p,start,start.clone().add(shift)))continue;
            if(safe==null)safe=candidate;
            if(NativeControl.sonMeleeLook(p.getEyeLocation().add(shift),opponent.getBoundingBox(),allowed)!=null)
                return new Route(candidate,"melee-reposition");
        }
        var around=aroundWall(actor,opponent,tick);
        if(around!=null)return new Route(around,"wall-detour");
        if(p.isOnGround()){
            var mining=clearWall(actor,bout(actor),tick,toward,null,false);
            if(!mining.isEmpty())return new Route(new Vector(),mining);
        }
        return new Route(safe==null?new Vector():safe,safe==null?"melee-blocked":"melee-reposition");
    }

    static Route crystalSelfEscape(NativeControl.Actor actor,Player opponent,int tick){
        var p=actor.player();var state=bout(actor);
        if(state.tick==tick)return state.fatherRoute;
        state.tick=tick;state.fatherRoute=null;
        String web=mineWeb(actor,state,touchingWeb(p),"web");
        if(!web.isEmpty()){
            state.fatherRoute=new Route(new Vector(),web);
            return state.fatherRoute;
        }
        if(p.isOnGround()&&!p.isInWater()&&!p.isInLava()&&CrystalActions.enclosed(p.getLocation())){
            var away=p.getLocation().toVector().subtract(opponent.getLocation().toVector()).setY(0);
            var escape=crystalReposition(p,opponent,true,0);
            if(escape.lengthSquared()>.01){
                state.fatherRoute=new Route(escape,"shelter-escape");return state.fatherRoute;
            }
            var action=clearWall(actor,state,tick,away,null,true);
            if(!action.isEmpty())state.fatherRoute=new Route(new Vector(),action);
        }
        return state.fatherRoute;
    }

    static Route clearCrystalOpening(NativeControl.Actor actor,Player opponent,Set<Block> placed,boolean atShelter){
        var player=actor.player();
        var state=bout(actor);
        if(!player.isOnGround()||!atShelter&&player.getLocation().distanceSquared(opponent.getLocation())<=9)return null;
        int pickaxe=player.getInventory().first(Material.NETHERITE_PICKAXE);
        if(pickaxe<0)return null;
        var target=opponent.getLocation();
        var view=player.getEyeLocation();
        var blockers=new LinkedHashSet<Block>();
        if(state.mining!=null)blockers.add(state.mining);
        for(var spot:List.of(target.clone().add(0,.35,0),target.clone().add(0,1.15,0))){
            var delta=spot.toVector().subtract(view.toVector());
            if(delta.lengthSquared()<.01)continue;
            var ray=player.getWorld().rayTraceBlocks(view,delta,Math.min(delta.length(),range(player)),
                FluidCollisionMode.NEVER,true);
            if(ray!=null&&ray.getHitBlock()!=null)blockers.add(ray.getHitBlock());
        }
        if(atShelter){
            Block feet=target.getBlock();
            for(BlockFace face:new BlockFace[]{BlockFace.NORTH,BlockFace.SOUTH,BlockFace.EAST,BlockFace.WEST}){
                var side=feet.getRelative(face);
                blockers.add(side);
                blockers.add(side.getRelative(BlockFace.UP));
            }
            blockers.add(feet.getRelative(BlockFace.UP,2));
        }
        for(var block:blockers){
            if(!placed.contains(block)||!CrystalActions.arenaDebris(block)
                ||center(block).distanceSquared(target.toVector())>6.25
                ||block.equals(state.refusedBlock)&&Bukkit.getCurrentTick()<state.refusedUntil)continue;
            String action=aimedMine(actor,state,block,pickaxe,"blast-opening");
            if(!action.isEmpty())return new Route(new Vector(),action);
        }
        return null;
    }

    static Route mineShelterFoot(NativeControl.Actor actor,Block block,Set<Block> placed){
        var player=actor.player();
        var state=bout(actor);
        if(!player.isOnGround()||!placed.contains(block)||!CrystalActions.arenaDebris(block)
            ||block.equals(state.refusedBlock)&&Bukkit.getCurrentTick()<state.refusedUntil)return null;
        int pickaxe=player.getInventory().first(Material.NETHERITE_PICKAXE);
        if(pickaxe<0)return null;
        var action=aimedMine(actor,state,block,pickaxe,"shelter-foot");
        return action.isEmpty()?null:new Route(new Vector(),action);
    }

    private static String aimedMine(NativeControl.Actor actor,Bout state,Block block,int slot,String action){
        for(double y:new double[]{.32,0,-.32}){
            var hit=ray(actor,center(block).add(new Vector(0,y,0)),ClipContext.Fluid.NONE);
            if(hit!=null&&hit.ray().getBlockPos().equals(pos(block)))return mine(actor,state,block,hit,slot,action);
        }
        return "";
    }

    private static String clearWall(NativeControl.Actor actor,Bout state,int tick,Vector direction,Vector detour,boolean escape){
        var p=actor.player();var at=p.getLocation().toVector();
        if(direction.lengthSquared()<.01)return "";
        var candidates=new LinkedHashSet<Block>();
        double length=Math.min(direction.length(),range(p));
        var heading=direction.clone().normalize();
        for(double height:new double[]{.45,1.35}){
            var near=p.getLocation().add(0,height,0);
            var obstruction=p.getWorld().rayTraceBlocks(near,heading,length,FluidCollisionMode.NEVER,true);
            if(obstruction!=null&&obstruction.getHitBlock()!=null)candidates.add(obstruction.getHitBlock());
        }
        if(candidates.isEmpty()&&detour==null&&!escape){state.wallProgressOrigin=null;return "";}
        if(state.wallProgressOrigin==null||tick-state.lastWallCheck>3||state.wallProgressOrigin.distanceSquared(at)>.36){
            state.wallProgressOrigin=at;state.wallStillSince=tick;
        }
        state.lastWallCheck=tick;
        boolean stalled=tick-state.wallStillSince>=12;
        if(detour!=null&&!stalled&&state.mining==null)return "";
        boolean crystal=actor.name.equals("WaveDogFather");
        var inventory=p.getInventory();
        int pickaxe=inventory.first(crystal?Material.NETHERITE_PICKAXE:Material.DIAMOND_PICKAXE);
        int sword=inventory.first(crystal?Material.NETHERITE_SWORD:Material.DIAMOND_SWORD);
        if(pickaxe<0&&sword<0)return "";
        var ordered=new LinkedHashSet<Block>();
        if(state.mining!=null&&state.miningTick>=Bukkit.getCurrentTick()-1)ordered.add(state.mining);
        ordered.addAll(candidates);
        if(stalled||escape||detour==null){
            var feet=p.getLocation().getBlock();var nearby=new ArrayList<Block>();
            for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++)for(int dy=0;dy<=1;dy++){
                var block=feet.getRelative(dx,dy,dz);
                if(diggableWall(block,crystal)&&(!escape||center(block).subtract(at).setY(0).dot(heading)>-.2))nearby.add(block);
            }
            nearby.sort(Comparator.comparingDouble(block->center(block).distanceSquared(at)));
            ordered.addAll(nearby);
        }
        for(Block block:ordered){
            if(!diggableWall(block,crystal)||block.equals(state.refusedBlock)&&tick<state.refusedUntil)continue;
            int slot=block.getType()==Material.COBWEB?sword:pickaxe;
            if(slot<0)continue;
            for(double y:new double[]{.32,0,-.32}){
                var hit=ray(actor,center(block).add(new Vector(0,y,0)),ClipContext.Fluid.NONE);
                if(hit!=null&&hit.ray().getBlockPos().equals(pos(block)))return mine(actor,state,block,hit,slot,"wall");
            }
        }
        return "";
    }
    private static boolean diggableWall(Block b,boolean crystal){
        return interior(b)&&(b.getType()==Material.COBWEB||b.getType()==Material.COBBLESTONE
            ||crystal&&Set.of(Material.OBSIDIAN,Material.GLOWSTONE,Material.RESPAWN_ANCHOR).contains(b.getType()));
    }

    static Vector appleEscapeHeading(NativeControl.Actor actor){return bout(actor).appleEscape;}

    private static Vector findAppleEscape(Player p,Player opponent,Vector away){
        var at=p.getLocation();var start=at.toVector();
        if(away.lengthSquared()<.01)return null;
        away=away.clone().normalize();
        Vector best=null;double bestScore=Double.NEGATIVE_INFINITY;
        var enemy=opponent.getLocation().toVector().setY(start.getY());
        for(int i=-4;i<=4;i++){
            var heading=away.clone().rotateAroundY(i*Math.PI/8);
            var end=start.clone().add(heading.clone().multiply(1.1));
            if(!wallSegment(p,start,end))continue;
            double score=end.distance(enemy)-start.distance(enemy)
                +.4*Math.min(2,wallDistance(at.clone().add(heading)));
            if(score>bestScore){best=heading;bestScore=score;}
        }
        return best;
    }

    private static int routeRisk(Player p,BoundingBox box,boolean solid){
        var world=p.getWorld();int risk=0;
        for(int x=(int)Math.floor(box.getMinX()+.001);x<box.getMaxX()-.001;x++)
            for(int z=(int)Math.floor(box.getMinZ()+.001);z<box.getMaxZ()-.001;z++)
                for(int y=(int)Math.floor(box.getMinY()+.001);y<box.getMaxY()-.001;y++){
                    Material m=world.getBlockAt(x,y,z).getType();
                    if(m==Material.LAVA)risk+=16;
                    else if(m==Material.COBWEB)risk+=3;
                    else if(solid&&m.isSolid())risk+=40;
                }
        return risk;
    }
    private static int sweep(Player p,Vector heading,Vector momentum,boolean solid){
        var box=p.getBoundingBox();int cost=0;
        for(int step=1;step<=4;step++){
            var delta=heading.clone().multiply(step*.32).add(momentum.clone().multiply(step==1?.70:1.15));
            cost+=routeRisk(p,box.clone().shift(delta),solid);
        }
        return cost;
    }
    static Route steer(NativeControl.Actor actor,Player opponent,Vector desired){
        var p=actor.player();var state=BOUTS.get(actor);
        if(state==null||!interior(p.getLocation().getBlock()))return null;
        var motion=actor.handle.queuedMotion;
        var momentum=motion==null?p.getVelocity():new Vector(motion.x,0,motion.z);momentum.setY(0);
        int current=routeRisk(p,p.getBoundingBox(),false);
        if(p.getFireTicks()>0){
            var feet=p.getLocation().getBlock();Vector nearest=null;double distance=9;
            for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++){
                var cell=feet.getRelative(dx,0,dz);
                if(cell.getType()!=Material.WATER)continue;
                var toward=center(cell).subtract(p.getLocation().toVector()).setY(0);
                double d=toward.lengthSquared();
                if(d>=distance||sweep(p,d<.16?new Vector():toward.clone().normalize(),momentum,true)!=0)continue;
                nearest=d<.16?new Vector():toward.normalize();distance=d;
            }
            if(nearest!=null)return new Route(nearest,"douse-move");
        }
        boolean recovery=state.lavaRecovery&&state.lava!=null&&p.getLocation().distanceSquared(opponent.getLocation())>16;
        if(recovery){
            var toLava=center(state.lava).subtract(p.getLocation().toVector()).setY(0);
            if(toLava.lengthSquared()>2&&toLava.lengthSquared()<81)desired=toLava;
            else recovery=false;
        }
        if(desired.lengthSquared()<.02&&current==0&&sweep(p,desired,momentum,false)==0)return null;
        var ideal=desired.lengthSquared()>.02?desired.clone().normalize():p.getLocation().toVector().subtract(opponent.getLocation().toVector()).setY(0).normalize();
        if(!Double.isFinite(ideal.getX())||!Double.isFinite(ideal.getZ()))ideal=new Vector(1,0,0);
        if(current==0&&sweep(p,ideal,momentum,false)==0&&!recovery)return null;
        Vector best=new Vector();double bestCost=current==0&&sweep(p,best,momentum,false)==0?3:Double.POSITIVE_INFINITY;
        for(int i=0;i<16;i++){
            var candidate=ideal.clone().rotateAroundY(i*Math.PI/8);
            double cost=sweep(p,candidate,momentum,true)+1-candidate.dot(ideal);
            if(cost<bestCost){best=candidate;bestCost=cost;}
        }
        return new Route(best,recovery?"lava-return":current>0?"hazard-escape":"hazard-avoid");
    }

    private record WallStep(int x,int z,int cost,int estimate,WallStep previous){}
    private static boolean wallSegment(Player player,Vector from,Vector to){
        return walkSegment(player,from,to,true);
    }
    static boolean crystalEscapePath(Player player,Location destination){
        var from=player.getLocation();
        return walkSegment(player,from.toVector(),destination.toVector(),CrystalActions.arenaColumn(from));
    }
    static boolean crystalEscapeLanding(Player player,Location destination){
        return walkSegment(player,destination.toVector(),destination.toVector(),CrystalActions.arenaColumn(player.getLocation()));
    }
    static Route crystalPursuit(Player player,Player opponent){
        var own=player.getLocation();
        var across=opponent.getLocation().toVector().subtract(own.toVector()).setY(0);
        if(across.lengthSquared()<=9)return null;
        var forward=across.normalize();
        for(int turn:new int[]{0,30,-30,60,-60}){
            var heading=forward.clone().rotateAroundY(Math.toRadians(turn));
            var next=own.clone().add(heading.clone().multiply(.8));
            if(crystalEscapePath(player,next))return new Route(heading,"pursuit-blast");
        }
        return null;
    }
    private static boolean walkSegment(Player player,Vector from,Vector to,boolean bounded){
        var at=player.getLocation().toVector();var box=player.getBoundingBox();
        var delta=to.clone().subtract(from);int steps=Math.max(1,(int)Math.ceil(delta.length()/.33));
        for(int i=1;i<=steps;i++){
            var p=from.clone().add(delta.clone().multiply((double)i/steps));
            if(bounded&&(p.getX()<992.33||p.getX()>1036.67||p.getZ()<992.33||p.getZ()>1036.67)
                ||routeRisk(player,box.clone().shift(p.subtract(at)),true)>0)return false;
        }
        return true;
    }
    static Vector crystalReposition(Player player,Player opponent,boolean retreat,int attempt){
        var start=player.getLocation().toVector();
        var target=opponent.getLocation().toVector().setY(start.getY());
        var toward=target.clone().subtract(start);
        if(toward.lengthSquared()<.001)return new Vector();
        var basis=toward.normalize();
        var desired=retreat?basis.clone().multiply(-1)
            :basis.clone().rotateAroundY((attempt%2==0?1:-1)*Math.PI/2).add(basis.clone().multiply(.35)).normalize();
        for(int turn:new int[]{0,30,-30,60,-60,90,-90,120,-120}){
            var heading=desired.clone().rotateAroundY(Math.toRadians(turn));
            if(retreat&&heading.dot(basis)>=-.05)continue;
            if(wallSegment(player,start,start.clone().add(heading.clone().multiply(.85))))return heading;
        }
        return new Vector();
    }
    static Vector aroundWall(NativeControl.Actor actor,Player opponent,int tick){
        var p=actor.player();var state=BOUTS.get(actor);
        if(state==null||!p.isOnGround()||p.getFireTicks()>0||p.isInLava()||p.isInWater())return null;
        var start=p.getLocation().toVector();var target=opponent.getLocation().toVector().setY(start.getY());
        double distance=start.distanceSquared(target);
        if(distance<.8||distance>225||wallSegment(p,start,target)){state.wallWaypoint=null;return null;}
        if(state.wallWaypoint!=null&&tick<=state.wallRouteUntil&&start.distanceSquared(state.wallWaypoint)>.13
            &&wallSegment(p,start,state.wallWaypoint))return state.wallWaypoint.clone().subtract(start).normalize();
        if(state.wallWaypoint==null&&tick<state.wallRouteUntil)return null;
        state.wallWaypoint=null;state.wallRouteUntil=tick+4;
        int sx=start.getBlockX(),sz=start.getBlockZ(),tx=target.getBlockX(),tz=target.getBlockZ();
        var open=new PriorityQueue<WallStep>(Comparator.comparingInt(node->node.cost()+node.estimate()));
        var costs=new HashMap<Long,Integer>();
        open.add(new WallStep(sx,sz,0,wallEstimate(sx,sz,tx,tz),null));
        WallStep last=null;
        for(int visited=0;visited<124&&!open.isEmpty();visited++){
            var node=open.remove();
            var center=node.previous()==null?start:new Vector(node.x()+.5,start.getY(),node.z()+.5);
            if(node.previous()!=null&&center.distanceSquared(target)<16&&wallSegment(p,center,target)){last=node;break;}
            for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
                if(dx==0&&dz==0)continue;
                int x=node.x()+dx,z=node.z()+dz,cost=node.cost()+(dx==0||dz==0?10:14);
                if(x<992||x>1036||z<992||z>1036||Math.abs(x-sx)>15||Math.abs(z-sz)>15)continue;
                long key=(long)x<<32|z;
                if(costs.getOrDefault(key,Integer.MAX_VALUE)<=cost)continue;
                if(!wallSegment(p,center,new Vector(x+.5,start.getY(),z+.5)))continue;
                costs.put(key,cost);open.add(new WallStep(x,z,cost,wallEstimate(x,z,tx,tz),node));
            }
        }
        if(last==null)return null;
        for(var node=last;node.previous()!=null;node=node.previous()){
            var next=new Vector(node.x()+.5,start.getY(),node.z()+.5);
            if(start.distanceSquared(next)>.13&&start.distanceSquared(next)<16&&wallSegment(p,start,next)){
                state.wallWaypoint=next;state.wallRouteUntil=tick+10;return next.clone().subtract(start).normalize();
            }
        }
        return null;
    }
    private static int wallEstimate(int x,int z,int tx,int tz){
        int dx=Math.abs(x-tx),dz=Math.abs(z-tz);return 10*Math.max(dx,dz)+4*Math.min(dx,dz);
    }

    private static boolean syncOverWall(NativeControl.Actor actor,Player target,JsonObject order,Bout state,int tick){
        var p=actor.player();double rise=NativeControl.number(order,"jumpRise",0);
        if(rise<.09||!p.isOnGround()||p.isInWater()||p.isInLava()||p.isBlocking()
            ||tick-state.lastSyncJump<9||p.getLocation().distanceSquared(target.getLocation())>21)return false;
        var from=p.getLocation().add(0,.7,0);var to=target.getLocation().toVector().setY(from.getY());
        var delta=to.subtract(from.toVector());if(delta.lengthSquared()<.35)return false;
        var wall=p.getWorld().rayTraceBlocks(from,delta,delta.length(),FluidCollisionMode.NEVER,true);
        if(wall==null||wall.getHitBlock()==null||!interior(wall.getHitBlock()))return false;
        var b=wall.getHitBlock();
        if(!b.getType().isSolid()||b.getY()>p.getLocation().getBlockY()+1
            ||routeRisk(p,p.getBoundingBox().clone().shift(0,1.23,0),true)!=0)return false;
        state.lastSyncJump=tick;return true;
    }

    private static double wallDistance(Location p){
        return Math.min(Math.min(p.getX()-992,1037-p.getX()),Math.min(p.getZ()-992,1037-p.getZ()));
    }
    private static WallCross jumpAcrossWall(NativeControl.Actor actor,Player opponent){
        var p=actor.player();var at=p.getLocation();
        if(!p.isOnGround()||p.isInWater()||p.isInLava()||p.isBlocking()||p.getFoodLevel()<=6)return null;
        var toward=opponent.getLocation().toVector().subtract(at.toVector()).setY(0);
        double distance=toward.length();if(distance<1.8||distance>8)return null;
        toward.normalize();
        var lip=at.clone().add(0,.45,0);
        var wall=p.getWorld().rayTraceBlocks(lip,toward,1.55,FluidCollisionMode.NEVER,true);
        if(wall==null||wall.getHitBlock()==null)return null;
        var block=wall.getHitBlock();
        if(block.getType()!=Material.COBBLESTONE||!interior(block)||!block.getRelative(BlockFace.UP).isEmpty())return null;

        var level=actor.handle.level();var box=actor.handle.getBoundingBox();
        var motion=actor.handle.queuedMotion==null?actor.handle.getDeltaMovement():actor.handle.queuedMotion;
        var direction=vec(toward);var speed=new Vec3(motion.x,.42,motion.z).add(direction.scale(.2));
        Vec3 displacement=Vec3.ZERO;
        for(int step=0;step<13;step++){
            speed=speed.add(direction.scale(step==0?.127:.026));
            var advance=net.minecraft.world.entity.Entity.collideBoundingBox(actor.handle,speed,box.move(displacement),level,List.of());
            displacement=displacement.add(advance);
            var pose=at.clone().add(displacement.x,displacement.y,displacement.z);
            var moved=p.getBoundingBox().clone().shift(new Vector(displacement.x,displacement.y,displacement.z));
            if(wallDistance(pose)<.31||routeRisk(p,moved,false)>0)return null;
            if(speed.y<0&&advance.y>speed.y+1e-5){
                var beyond=pose.toVector().subtract(wall.getHitPosition()).dot(toward);
                var below=pose.clone().add(0,-.05,0).getBlock();
                if(beyond<=.5||!below.getType().isSolid())return null;
                var farEdge=wall.getHitPosition().add(toward.clone().multiply(1.35));
                if(routeRisk(p,p.getBoundingBox().clone().shift(farEdge.clone().setY(at.getY()).subtract(at.toVector())),false)>0)return null;
                return new WallCross(toward,farEdge);
            }
            if(speed.y>0&&advance.y<speed.y-.05)return null;
            speed=new Vec3(Math.abs(advance.x-speed.x)<1e-5?speed.x*.91:0,(advance.y-.08)*.98,
                Math.abs(advance.z-speed.z)<1e-5?speed.z*.91:0);
        }
        return null;
    }
    private static Vector planWallHop(Player p,Player opponent,JsonObject order){
        double eta=NativeControl.number(order,"criticalEta",0);
        if(!NativeControl.flag(order,"wallHop")||eta<2||eta>6||!p.isOnGround()||p.isInLava()
            ||p.isInWater()||p.isBlocking()||p.getFoodLevel()<=6||NativeControl.flag(order,"rangedAim")||!order.getAsJsonArray("arrow").isEmpty()
            ||Math.min(wallDistance(p.getLocation()),wallDistance(opponent.getLocation()))>1.25)return null;
        var self=p.getLocation();var away=self.toVector().subtract(opponent.getLocation().toVector()).setY(0);
        if(away.lengthSquared()<.09||NativeControl.reach(opponent,p)+eta*.24<3.12)return null;
        away.normalize();var box=p.getBoundingBox();
        Vector best=null;double bestScore=-1;
        for(double angle:new double[]{0,Math.PI/4,-Math.PI/4,Math.PI/2,-Math.PI/2}){
            var heading=away.clone().rotateAroundY(angle);double separation=heading.dot(away);
            if(separation<.5||wallDistance(self.clone().add(heading.clone().multiply(1.2)))<.33)continue;
            boolean clear=true;
            for(int step=1;step<=4;step++){
                var travel=heading.clone().multiply(.3*step).setY(Math.min(1.15,.36*step));
                if(routeRisk(p,box.clone().shift(travel),true)>0){clear=false;break;}
            }
            if(clear&&separation>bestScore){best=heading;bestScore=separation;}
        }
        return best;
    }
    static Vector wallHopHeading(NativeControl.Actor actor){return BOUTS.get(actor).wallHop;}

    private static boolean preparingWater(Player opponent){
        return opponent.getInventory().getItemInMainHand().getType()==Material.WATER_BUCKET
            ||opponent.getInventory().getItemInOffHand().getType()==Material.WATER_BUCKET;
    }
    private static boolean adjacentWater(Block b){
        for(BlockFace face:FACES)if(b.getRelative(face).getType()==Material.WATER)return true;
        return false;
    }
    private static boolean adjacentLava(Block b){
        for(BlockFace face:FACES)if(b.getRelative(face).getType()==Material.LAVA)return true;
        return false;
    }
    private static String recoverLava(NativeControl.Actor actor,Player opponent,Bout state,int tick){
        if(state.lava==null)return "";
        if(!source(state.lava,Material.LAVA)){state.lava=null;state.lavaRecovery=false;return "lava-source-lost";}
        var p=actor.player();var feet=opponent.getLocation().getBlock();
        boolean water=preparingWater(opponent)||state.water!=null&&state.water.getType()==Material.WATER;
        boolean takeBack=water||adjacentWater(state.lava)||!state.lava.equals(feet)&&!state.lava.equals(feet.getRelative(BlockFace.UP))
            ||tick-state.lavaAt>=14||p.isInLava();
        state.lavaRecovery=takeBack;
        if(!takeBack||!scoop(actor,6,Material.LAVA,state.lava))return "";
        state.waitingForWater=water;state.lava=null;state.lavaRecovery=false;return "lava-recovered";
    }

    private static String waterEscape(NativeControl.Actor actor,Bout state,Block web,int tick,boolean recover){
        var p=actor.player();boolean fire=p.getFireTicks()>0;
        for(var it=state.rescueWater.entrySet().iterator();it.hasNext();){
            var entry=it.next();var water=entry.getValue();
            if(!source(water.source(),Material.WATER)){it.remove();continue;}
            if(recover&&!fire&&web==null&&scoop(actor,entry.getKey(),Material.WATER,water.source())){
                it.remove();return "douse-water-recovered";
            }
            if(web!=null&&water.source().equals(web.getRelative(BlockFace.UP))&&tick-water.placedAt()<=8)return "water-clearing-web";
        }
        if((!fire&&web==null)||p.isInWater())return "";
        int slot=has(p,5,Material.WATER_BUCKET)?5:11;
        if(!has(p,slot,Material.WATER_BUCKET))return "";
        Block feet=p.getLocation().getBlock();
        var candidates=new ArrayList<Block>();
        candidates.add(web==null?feet:web.getRelative(BlockFace.UP));
        if(fire){
            candidates.add(feet.getRelative(BlockFace.UP));
            candidates.add(feet.getRelative(BlockFace.DOWN));
            for(BlockFace side:FACES)if(side!=BlockFace.DOWN&&side!=BlockFace.UP)candidates.add(feet.getRelative(side));
            for(BlockFace side:List.of(BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST)){
                var next=feet.getRelative(side,2);
                var destination=center(next).setY(p.getY());
                if(wallSegment(p,p.getLocation().toVector(),destination))candidates.add(next);
            }
        }
        for(Block water:candidates)if(water.isEmpty()&&(!fire||!adjacentLava(water))&&pour(actor,water,slot,Material.WATER_BUCKET)){
            state.rescueWater.put(slot,new RescueWater(water,tick));
            return web==null?"douse-with-water":"water-over-web";
        }
        return "";
    }
    static String douseAfterPhysics(NativeControl.Actor actor,int tick){
        var state=BOUTS.get(actor);
        if(state==null||!interior(actor.player().getLocation().getBlock()))return "";
        if(state.applesBefore>0||actor.handle.handActionLocked())return "";
        stopMining(actor);
        return waterEscape(actor,state,touchingWeb(actor.player()),tick,false);
    }
    private static String takeEnemyLava(NativeControl.Actor actor,Bout state){
        if(!source(state.enemyLava,Material.LAVA)){state.enemyLava=null;return "";}
        int slot=state.lava==null&&has(actor.player(),6,Material.BUCKET)?6:11;
        if(scoop(actor,slot,Material.LAVA,state.enemyLava)){state.enemyLava=null;return "enemy-lava-scooped";}
        if(state.lava==null&&!actor.player().isInLava()&&pour(actor,state.enemyLava))return "enemy-lava-covered";
        return "";
    }
    private static String takeEnemyWater(NativeControl.Actor actor,Player opponent,Bout state){
        var p=actor.player();Block water=state.water;
        if(!source(water,Material.WATER)||ownWater(state,water)){
            Block feet=opponent.getLocation().getBlock(),above=feet.getRelative(BlockFace.UP);
            water=source(feet,Material.WATER)?feet:above;
        }
        if(!source(water,Material.WATER)||ownWater(state,water))return "";
        int slot=!state.rescueWater.containsKey(5)&&has(p,5,Material.BUCKET)?5:11;
        if(!state.rescueWater.containsKey(slot)&&scoop(actor,slot,Material.WATER,water)){
            state.water=water;return "water-scooped";
        }
        if(!state.rescueWater.containsKey(5)&&has(p,5,Material.WATER_BUCKET)&&pour(actor,water,5,Material.WATER_BUCKET)){
            state.water=water;return "enemy-water-covered";
        }
        return "";
    }
    private static boolean ownWater(Bout state,Block block){
        return state.rescueWater.values().stream().anyMatch(water->water.source().equals(block));
    }
    private static String gatherNearbyFluid(NativeControl.Actor actor,Bout state,int tick){
        if(tick%4!=0)return "";
        var p=actor.player();var feet=p.getLocation().getBlock();
        boolean water=!state.rescueWater.containsKey(5)&&has(p,5,Material.BUCKET);
        boolean lava=state.lava==null&&has(p,6,Material.BUCKET);
        boolean spare=!state.rescueWater.containsKey(11)&&has(p,11,Material.BUCKET);
        if(!water&&!lava&&!spare)return "";
        var sources=new ArrayList<Block>();
        for(int dx=-4;dx<=4;dx++)for(int dz=-4;dz<=4;dz++)for(int dy=-1;dy<=2;dy++){
            if(dx*dx+dz*dz>18)continue;
            var b=feet.getRelative(dx,dy,dz);
            if(interior(b)&&((water||spare)&&source(b,Material.WATER)&&!ownWater(state,b)
                ||(lava||spare)&&source(b,Material.LAVA)&&!b.equals(state.lava)))sources.add(b);
        }
        var eye=p.getEyeLocation().toVector();sources.sort(Comparator.comparingDouble(b->center(b).distanceSquared(eye)));
        for(int i=0;i<Math.min(sources.size(),4);i++){
            var b=sources.get(i);boolean isWater=b.getType()==Material.WATER;
            int slot=isWater?(water?5:11):(lava?6:11);
            if(scoop(actor,slot,b.getType(),b))return isWater?"water-swept":"lava-swept";
        }
        return "";
    }

    static boolean eatingApple(Player p){
        return p.hasActiveItem()&&p.getActiveItem().getType()==Material.GOLDEN_APPLE
            &&p.getInventory().getItemInOffHand().getType()==Material.GOLDEN_APPLE;
    }
    private static String startApple(NativeControl.Actor actor,Player opponent,Bout state){
        var p=actor.player();var inv=p.getInventory();
        if(p.getHealth()>10||p.getAbsorptionAmount()>0||!has(p,3,Material.GOLDEN_APPLE))return "";
        if(NativeControl.reach(opponent,p)<(p.getHealth()<=5?2.5:3.2))return "apple-retreat";
        stopMining(actor);
        var apples=inv.getItem(3);state.applesBefore=apples.getAmount();
        inv.setItem(3,inv.getItemInOffHand());inv.setItemInOffHand(apples);
        actor.handle.stopUsingItem();
        actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getOffhandItem(),InteractionHand.OFF_HAND);
        if(eatingApple(p))return "eat-apple";
        restoreApple(actor,state);return "";
    }
    static void end(NativeControl.Actor actor){
        stopMining(actor);
        var state=BOUTS.remove(actor);if(state!=null&&state.applesBefore>0)restoreApple(actor,state);
    }
    private static boolean restoreApple(NativeControl.Actor actor,Bout state){
        var inv=actor.player().getInventory();var left=inv.getItemInOffHand();
        int remaining=left.getType()==Material.GOLDEN_APPLE?left.getAmount():0;
        boolean eaten=remaining<state.applesBefore;
        actor.handle.stopUsingItem();inv.setItemInOffHand(inv.getItem(3));inv.setItem(3,left);state.applesBefore=0;
        return eaten;
    }

    static String decide(NativeControl.Actor actor,Player opponent,JsonObject order,boolean retreating,int tick){
        var p=actor.player();var feet=opponent.getLocation().getBlock();
        if(p.getGameMode()!=GameMode.SURVIVAL||!interior(feet)||!interior(p.getLocation().getBlock()))return "";
        var state=bout(actor);
        if(state.tick==tick)return state.action;
        state.tick=tick;
        state.action="";
        state.bucketAttempt="";
        Block web=touchingWeb(p);
        boolean projectile=NativeControl.flag(order,"arrowIncoming")||!order.getAsJsonArray("arrow").isEmpty();
        boolean danger=p.isInLava()||web!=null||NativeControl.flag(order,"critical")||projectile;
        boolean burning=p.getFireTicks()>0;
        boolean cleanup=!danger&&!burning&&!NativeControl.flag(order,"meleeBusy")&&!NativeControl.flag(order,"rangedAim");
        if(!cleanup)state.lavaRecovery=false;
        if(state.applesBefore>0){
            if(eatingApple(p)){state.action="eat-apple";return state.action;}
            if(restoreApple(actor,state)){state.action="apple-eaten";return state.action;}
        }
        if(burning){
            if(p.isInLava()){
                state.action=recoverLava(actor,opponent,state,tick);
                if(state.action.isEmpty()||state.action.equals("lava-source-lost"))state.action=takeEnemyLava(actor,state);
            }
            if(state.action.isEmpty())state.action=waterEscape(actor,state,web,tick,false);
            if(!state.action.isEmpty())return state.action;
        }
        if(projectile){state.action=defend(actor,opponent,order);return state.action;}
        state.action=waterEscape(actor,state,web,tick,false);
        if(state.action.isEmpty()&&p.isInLava())state.action=takeEnemyLava(actor,state);
        if(state.action.isEmpty())state.action=mineWeb(actor,state,web,"web");
        if(state.crossingWall&&(danger||retreating||NativeControl.flag(order,"meleeBusy")
            ||p.getLocation().toVector().subtract(state.wallFarEdge).setY(0).dot(state.wallHop)>=0)){
            state.crossingWall=false;state.wallHopUntil=-1;
        }
        if(state.action.isEmpty()&&web==null&&tick<=state.wallHopUntil&&!p.isInLava()
            &&(!state.crossingWall||!danger&&!retreating)){
            state.action=state.crossingWall?"wall-cross-travel":"wall-hop-travel";return state.action;
        }
        if(state.action.isEmpty()&&web==null&&syncOverWall(actor,opponent,order,state,tick)){
            state.action="wall-sync-jump";return state.action;
        }
        if(state.action.isEmpty()&&web==null){
            var hop=planWallHop(p,opponent,order);
            if(hop!=null){
                state.wallHop=hop;state.crossingWall=false;state.wallHopUntil=tick+(int)Math.ceil(NativeControl.number(order,"criticalEta",0));
                state.action="wall-hop";return state.action;
            }
        }
        if(state.action.isEmpty())state.action=defend(actor,opponent,order);
        if(state.action.isEmpty()&&!danger){
            state.action=startApple(actor,opponent,state);
            if(state.action.equals("apple-retreat")){
                var away=p.getLocation().toVector().subtract(opponent.getLocation().toVector()).setY(0);
                state.appleEscape=findAppleEscape(p,opponent,away);
                if(state.appleEscape==null){
                    state.action=p.hasLineOfSight(opponent)&&NativeControl.reach(opponent,p)<=3
                        ?"apple-corner-fight":clearWall(actor,state,tick,away,null,true);
                    if(state.action.isEmpty())state.action="apple-corner-fight";
                }
            }
        }
        if(state.action.isEmpty()&&!danger&&!burning&&!retreating&&!NativeControl.flag(order,"meleeBusy")
            &&!NativeControl.flag(order,"rangedAim")&&state.miningTick!=Bukkit.getCurrentTick()-1){
            var across=jumpAcrossWall(actor,opponent);
            if(across!=null){
                state.wallHop=across.heading();state.wallFarEdge=across.farEdge();state.crossingWall=true;state.wallHopUntil=tick+15;
                state.action="wall-cross-jump";return state.action;
            }
        }
        if(state.action.isEmpty()&&!danger&&!burning)state.action=mineWall(actor,opponent,order,state,tick);
        if(state.action.isEmpty()&&cleanup)state.action=waterEscape(actor,state,null,tick,true);
        if(state.action.isEmpty()&&cleanup)state.action=recoverLava(actor,opponent,state,tick);
        if(state.action.isEmpty()&&cleanup)state.action=takeEnemyWater(actor,opponent,state);
        if(state.action.isEmpty()&&cleanup)state.action=takeEnemyLava(actor,state);
        if(state.action.isEmpty()&&cleanup)state.action=gatherNearbyFluid(actor,state,tick);
        if(state.action.isEmpty()&&!p.isInLava())state.action=trap(actor,opponent,feet,state,tick,!danger&&!burning);
        return state.action;
    }
    private static String trap(NativeControl.Actor actor,Player opponent,Block feet,Bout state,int tick,boolean canCut){
        var p=actor.player();
        if(p.getLocation().distanceSquared(opponent.getLocation())>27)return "";
        var above=feet.getRelative(BlockFace.UP);
        var water=state.water;
        if(water==null||!interior(water)||water.getLocation().distanceSquared(opponent.getLocation())>6
            ||water.getType()!=Material.WATER)water=feet.getType()==Material.WATER?feet:above.getType()==Material.WATER?above:null;
        boolean wantsWater=preparingWater(opponent);
        var self=p.getBoundingBox().clone().expand(.18,0,.18);
        if(self.overlaps(BoundingBox.of(feet))||self.overlaps(BoundingBox.of(above)))return "";
        if(water!=null&&has(p,6,Material.LAVA_BUCKET)){
            if(!self.overlaps(BoundingBox.of(water))&&!adjacentWater(water)&&pour(actor,water)){
                state.lava=source(water,Material.LAVA)?water:null;state.lavaAt=tick;state.waitingForWater=false;return "water-replaced";
            }
            return "";
        }
        if(state.water!=null&&state.water.isEmpty()&&interior(state.water)&&state.water.getLocation().distanceSquared(opponent.getLocation())<=6){
            if(!self.overlaps(BoundingBox.of(state.water))&&!adjacentWater(state.water)&&pour(actor,state.water)){
                state.lava=state.water;state.lavaAt=tick;state.water=null;state.waitingForWater=false;return "lava-after-water";
            }
        }
        if(state.waitingForWater&&wantsWater)return "";
        state.waitingForWater=false;
        if(canCut&&feet.getType()==Material.COBWEB&&above.getType()==Material.COBWEB
            &&opponent.getBoundingBox().overlaps(BoundingBox.of(above))){
            return mineWeb(actor,state,above,"upper-web");
        }
        if(!has(p,8,Material.COBWEB)&&feet.isEmpty()&&!adjacentWater(feet)&&pour(actor,feet)){
            state.lava=feet;state.lavaAt=tick;return "lava-at-feet";
        }
        if(feet.getType()!=Material.COBWEB&&placeBlock(actor,8,Material.COBWEB,feet))return "web-feet";
        if(feet.getType()==Material.COBWEB&&!adjacentWater(above)&&pour(actor,above)){state.lava=above;state.lavaAt=tick;return "lava-over-web";}
        return "";
    }
}
