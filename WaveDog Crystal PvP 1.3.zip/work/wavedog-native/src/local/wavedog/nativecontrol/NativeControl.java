package local.wavedog.nativecontrol;

import com.destroystokyo.paper.event.server.ServerTickEndEvent;
import com.google.gson.*;
import com.google.gson.stream.JsonWriter;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPOutputStream;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/** Native player ownership; duel setup and receipts remain with the referees. */
public final class NativeControl extends JavaPlugin implements Listener {
    static final Gson JSON=new GsonBuilder().serializeNulls().create();
    static final Path ROOT=Path.of(System.getProperty("wavedog.workspace","D:/CodexWorkspace/ban"));
    final Map<String,Actor> actors=new LinkedHashMap<>();
    final Map<UUID,Location> positions=new HashMap<>();
    final Map<UUID,Vector> motion=new HashMap<>();
    final ExecutorService writer=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"WaveDog-native-persistence");t.setDaemon(true);return t;});
    NativePolicy policy;PerceptionDialogueBridge dialogue;NativeMechanicsProbe fixture;long decisions,lastNanos,peakNanos;String policySha="";boolean failed;
    final class Actor {
        final String name,channel,coreName,command;final Path runtime,evaluations;
        NativePlayer handle;Plugin core;String token,match,opponent;boolean active,loading;
        int lastDecisionTick=-1,lastAttackTick=-1,lastDispatchTick=-1,lastSwitchTick=-1000,lastSwing=-1000,lastWindTick=-1000,lastAimTick=-1000;
        Map<String,Object> currentAttack;
        boolean executing;final List<Map<String,Object>> deferredReceipts=new ArrayList<>();
        int shotEvent,shotTick=-1000,loadCycle,loadEndedAt=-1000,rangedEvent;
        String shotWeapon="",loadResult;boolean wasLoading,wasBow,refreshQueued;
        JsonObject calibration;
        long attackId,loggedFrames;final List<Map<String,Object>> frames=new ArrayList<>();
        volatile Exception journalFailure;
        Actor(String name,String channel,String coreName,String command,String component){
            this.name=name;this.channel=channel;this.coreName=coreName;this.command=command;
            runtime=ROOT.resolve("work/"+component+"/runtime");
            evaluations=runtime.resolve("../model/evaluations").normalize();
        }
        Player player(){return handle==null?null:handle.getBukkitEntity();}
    }
    @Override public void onEnable(){
        try{
            Files.createDirectories(getDataFolder().toPath());
            String selected=getConfig().getString("policy-directory","");
            try(var in=selected.isBlank()?getResource("policy-manifest.json"):Files.newInputStream(Path.of(selected).resolve("policy-manifest.json"))){policySha=JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(in),StandardCharsets.UTF_8)).getAsJsonObject().get("sha256").getAsString();}
            policy=new NativePolicy(this);
            actors.put("WaveDog",new Actor("WaveDog","punengbho:control","PunengbhoProtocolCore","wavedog","wavedog-punengbho"));
            actors.put("WaveDogSon",new Actor("WaveDogSon","wavedogson:control","WaveDogSonCore","wavedogson","wavedog-son"));
            var brother=Bukkit.getPluginManager().getPlugin("WaveDogBrotherCore");
            if(brother!=null&&brother.isEnabled())actors.put("WaveDogBrother",new Actor("WaveDogBrother","wavedogbrother:control",
                "WaveDogBrotherCore","wavedogbrother","wavedog-brother"));
            var father=Bukkit.getPluginManager().getPlugin("WaveDogFatherCore");
            if(father!=null&&father.isEnabled())actors.put("WaveDogFather",new Actor("WaveDogFather","wavedogfather:control",
                "WaveDogFatherCore","wavedogfather","wavedog-father"));
            var sister=Bukkit.getPluginManager().getPlugin("WaveDogSisterCore");
            if(sister!=null&&sister.isEnabled())actors.put("WaveDogSister",new Actor("WaveDogSister","wavedogsister:control",
                "WaveDogSisterCore","wavedogsister","wavedog-sister"));
            if(getConfig().getBoolean("dialogue-enabled",false))try{dialogue=new PerceptionDialogueBridge(this);}
            catch(Exception error){getLogger().warning("Local perception speech unavailable: "+error);}
            Bukkit.getPluginManager().registerEvents(this,this);
            Objects.requireNonNull(getCommand("wdnative")).setExecutor(this);
            if(getConfig().getBoolean("enabled",false))Bukkit.getScheduler().runTaskLater(this,()->{
                try{for(var a:actors.values())spawn(a);}catch(Exception e){fail(e);}
            },40);
        }catch(Exception e){throw new IllegalStateException("Native backend initialization failed",e);}
    }
    void primary(){if(!Bukkit.isPrimaryThread())throw new IllegalStateException("Native world access outside primary thread");}
    void fail(Throwable error){failed=true;for(var a:actors.values())if(a.handle!=null){a.handle.zza=a.handle.xxa=0;a.handle.setJumping(false);a.handle.setSprinting(false);}
        getLogger().log(java.util.logging.Level.SEVERE,"Native controller stopped after error",error);}
    @Override public void onDisable(){
        for(var a:actors.values())if(a.handle!=null){
            if(Bukkit.getPlayerExact(a.name)==a.player()&&!a.handle.isRemoved())MinecraftServer.getServer().getPlayerList().remove(a.handle);
            a.handle=null;
        }
        if(dialogue!=null)dialogue.close();if(policy!=null)policy.close();writer.shutdown();
        try{writer.awaitTermination(5,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    void capture(Actor a)throws Exception{
        Player p=Bukkit.getPlayerExact(a.name);if(p==null)throw new IllegalStateException(a.name+" must be online to preserve its identity");
        var profile=((CraftPlayer)p).getProfile();var properties=new ArrayList<Map<String,Object>>();
        for(var item:profile.properties().values())properties.add(Map.of("name",item.name(),"value",item.value(),"signature",item.signature()==null?"":item.signature()));
        var at=p.getLocation();var data=new LinkedHashMap<String,Object>();data.put("uuid",p.getUniqueId().toString());data.put("name",a.name);data.put("properties",properties);
        data.put("world",p.getWorld().getName());data.put("x",at.getX());data.put("y",at.getY());data.put("z",at.getZ());data.put("yaw",at.getYaw());data.put("pitch",at.getPitch());
        Files.writeString(getDataFolder().toPath().resolve(a.name+"-identity.json"),JSON.toJson(data));
    }
    void spawn(Actor a)throws Exception{
        primary();if(a.handle!=null){
            if(Bukkit.getPlayerExact(a.name)==a.player()&&!a.handle.isRemoved())return;
            a.handle=null; // A quit/kick already retired this handle; never remove it twice.
        }
        if(Bukkit.getPlayerExact(a.name)!=null)throw new IllegalStateException("Existing player still owns "+a.name);
        var file=getDataFolder().toPath().resolve(a.name+"-identity.json");
        JsonObject identity=JSON.fromJson(Files.readString(file),JsonObject.class);
        var properties=com.google.common.collect.ArrayListMultimap.<String,Property>create();
        for(var item:identity.getAsJsonArray("properties")){
            var p=item.getAsJsonObject();String signature=p.get("signature").getAsString();
            properties.put(p.get("name").getAsString(),new Property(p.get("name").getAsString(),p.get("value").getAsString(),signature.isEmpty()?null:signature));
        }
        var profile=new GameProfile(UUID.fromString(identity.get("uuid").getAsString()),a.name,new com.mojang.authlib.properties.PropertyMap(properties));
        World world=Objects.requireNonNull(Bukkit.getWorld(identity.get("world").getAsString()));
        var server=MinecraftServer.getServer();var level=((CraftWorld)world).getHandle();
        var handle=new NativePlayer(server,level,profile);var connection=new NativePlayer.LocalConnection();
        handle.setPos(identity.get("x").getAsDouble(),identity.get("y").getAsDouble(),identity.get("z").getAsDouble());
        server.getPlayerList().placeNewPlayer(connection,handle,net.minecraft.server.network.CommonListenerCookie.createInitial(profile,false));
        handle.connection=new NativePlayer.LocalListener(server,connection,handle);a.handle=handle;
        Player p=a.player();p.setMetadata("wavedog-native-player",new FixedMetadataValue(this,true));
        // A saved player.dat can contain the previous death. Respawning must
        // restore the native subclass and its live state, rather than loop on it.
        handle.unsetRemoved();handle.deathTime=0;p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        handle.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);handle.queuedMotion=null;p.setFallDistance(0);
        Location pendingReturn=positions.remove(p.getUniqueId());
        p.teleport(pendingReturn!=null?pendingReturn:new Location(world,identity.get("x").getAsDouble(),identity.get("y").getAsDouble(),identity.get("z").getAsDouble(),identity.get("yaw").getAsFloat(),identity.get("pitch").getAsFloat()));
        p.setGameMode(GameMode.SURVIVAL);
        a.core=Objects.requireNonNull(Bukkit.getPluginManager().getPlugin(a.coreName));
        a.token=Files.readString(a.core.getDataFolder().toPath().resolve("client-token.txt")).trim();
        // Both deployed peers used this same accepted calibration profile.
        Path calibration=ROOT.resolve("work/wavedog-punengbho/runtime/ranged-calibration.json");
        if(Files.isRegularFile(calibration))a.calibration=JSON.fromJson(Files.readString(calibration),JsonObject.class);
        heartbeat(a);
        Files.createDirectories(a.runtime);
        Files.writeString(a.runtime.resolve("native-ready.json"),JSON.toJson(Map.of("name",a.name,"backend","server-native","policySha256",policySha,
            "sameSonPolicy",true,"neuralWeightsLoaded",false,"protocolClientRequired",false,"uuid",p.getUniqueId().toString())));
    }
    void input(Actor a,Map<String,Object> row){
        primary();if(a.handle==null||a.core==null)return;
        var message=new LinkedHashMap<String,Object>(row);message.put("token",a.token);if(a.match!=null)message.put("matchId",a.match);
        ((PluginMessageListener)a.core).onPluginMessageReceived(a.channel,a.player(),JSON.toJson(message).getBytes(StandardCharsets.UTF_8));
    }
    void heartbeat(Actor a){
        primary();Player p=a.player();
        if(p==null||Bukkit.getPlayerExact(a.name)!=p||a.handle.isRemoved())return;
        // AuthMe processes login/logout asynchronously. A single forceLogin at
        // join can be overtaken by the old entity's logout. Confirm every
        // heartbeat, retry only our own known native player, and withhold ready
        // until the authentication API actually acknowledges that player.
        var auth=Bukkit.getPluginManager().getPlugin("AuthMe");
        if(auth!=null)try{
            var type=Class.forName("fr.xephi.authme.api.v3.AuthMeApi",true,auth.getClass().getClassLoader());
            var api=type.getMethod("getInstance").invoke(null);
            if(!Boolean.TRUE.equals(type.getMethod("isAuthenticated",Player.class).invoke(api,p))){
                hold(a);type.getMethod("forceLogin",Player.class).invoke(api,p);return;
            }
        }catch(ReflectiveOperationException error){throw new IllegalStateException("Native authentication check failed for "+a.name,error);}
        boolean modelReady=!failed;
        if(modelReady&&a.name.equals("WaveDogBrother")){
            var neural=Bukkit.getPluginManager().getPlugin("WaveDogNeuralFallback");
            try{modelReady=neural!=null&&neural.isEnabled()&&Boolean.TRUE.equals(neural.getClass().getMethod("isModelReady").invoke(neural));}
            catch(ReflectiveOperationException error){modelReady=false;}
        }
        input(a,Map.of("type","heartbeat","modelReady",modelReady,"policySha",policySha));
    }
    /** Called synchronously by the referee's send method; no packet/Node path. */
    public void receiveLobbyChat(UUID playerId,String text){
        primary();
        if(dialogue!=null&&dialogue.isLobbyChatAllowed(playerId))dialogue.lobby(playerId,text);
    }
    public boolean receiveCore(String name,Map<String,Object> row){
        primary();Actor a=actors.get(name);if(a==null||a.handle==null||Bukkit.getPlayerExact(name)!=a.player())return false;
        String type=String.valueOf(row.get("type"));int tick=Bukkit.getCurrentTick();
        if(type.equals("prepare")){
            a.match=String.valueOf(row.get("matchId"));a.opponent=String.valueOf(row.get("opponent"));a.frames.clear();a.active=false;
            a.loggedFrames=0;a.journalFailure=null;
            a.lastDecisionTick=a.lastAttackTick=-1;a.lastWindTick=a.lastAimTick=-1000;a.shotEvent=a.loadCycle=a.rangedEvent=0;a.wasLoading=a.wasBow=false;
            a.shotTick=a.loadEndedAt=-1000;a.shotWeapon="";a.loadResult=null;
            if(name.equals("WaveDogSon"))UhcTools.craftPlate(a.player());
            policy.reset(name,a.opponent);hold(a);
            a.lastAimTick=tick+((Number)row.getOrDefault("startAfterTicks",200)).intValue();
            a.lastWindTick=tick+ThreadLocalRandom.current().nextInt(12,46);
            a.lastDecisionTick=tick+ThreadLocalRandom.current().nextInt(18,65);
            a.lastSwitchTick=-1000;a.player().setSneaking(false);
        }else if(type.equals("start")){
            a.active=true;a.lastDecisionTick=-1;a.lastAimTick=a.lastWindTick=a.lastSwitchTick=-1000;
            a.player().setSneaking(false);
        }
        else if(type.equals("end")){
            if(dialogue!=null)dialogue.end(a,row);
            if(name.equals("WaveDogSon")||name.equals("WaveDogFather"))UhcTools.end(a);
            a.active=false;hold(a);a.player().setSneaking(false);var end=new LinkedHashMap<String,Object>(row);
            Bukkit.getScheduler().runTask(this,()->save(a,end));
        }else if(a.match!=null&&Objects.equals(a.match,row.get("matchId"))){
            var copy=new LinkedHashMap<String,Object>(row);
            if(type.equals("damage")&&a.active&&!a.loading&&!a.executing&&a.lastDispatchTick!=tick
                &&Boolean.TRUE.equals(row.get("melee"))&&!Boolean.TRUE.equals(row.get("cancelled"))
                &&name.equals(row.get("victim"))&&Objects.equals(a.opponent,row.get("attacker"))
                &&row.get("amount") instanceof Number damage&&damage.doubleValue()==0
                &&row.get("shieldModifier") instanceof Number shield&&shield.doubleValue()<0
                &&a.player().getInventory().getHeldItemSlot()==7
                &&a.player().getInventory().getItemInMainHand().getType().name().endsWith("_AXE")
                &&a.player().getCooledAttackStrength(.5f)>=1.0f&&!a.player().hasCooldown(Material.SHIELD)){
                copy.put("axeReadyAtBlock",true);
                // Revisit the policy at tick end, after vanilla has finished the
                // attack and announced any shield disable. No recursive strike.
                a.lastDecisionTick=-1;
            }
            // Native attack receipts are synchronous. Preserve the original
            // apply -> receipt order, so a confirmed hit clears its pending ID.
            if(a.executing)a.deferredReceipts.add(copy);else policy.receipt(name,copy,tick);
            if(!a.frames.isEmpty()&&List.of("damage","blocked_melee","shield_disabled","attack_packet").contains(type)){
                @SuppressWarnings("unchecked") var events=(List<Object>)a.frames.getLast().computeIfAbsent("nativeEvents",key->new ArrayList<>());events.add(copy);
            }
        }
        return true;
    }
    private void journalFailure(Actor a,Exception error){
        a.journalFailure=error;
        if(isEnabled())Bukkit.getScheduler().runTask(this,()->{
            fail(error);input(a,Map.of("type","learning_error","reason","Native trajectory persistence failed"));
        });
    }
    private static Path partialJournal(Actor a,String match){return a.runtime.resolve(match+"-native-frames.partial");}
    private static void appendJournal(Path path,List<Map<String,Object>> frames)throws IOException{
        Files.createDirectories(path.getParent());
        try(var output=Files.newBufferedWriter(path,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND)){
            for(var frame:frames){output.write(JSON.toJson(frame));output.newLine();}
        }
    }
    private void flushHistory(Actor a){
        // Observation reads the last 256 frames for lag history. Older rows
        // are immutable and can leave the server thread in bounded batches.
        if(a.frames.size()<384||a.journalFailure!=null)return;
        var batch=List.copyOf(a.frames.subList(0,128));a.frames.subList(0,128).clear();
        a.loggedFrames+=batch.size();var path=partialJournal(a,a.match);
        writer.execute(()->{try{if(a.journalFailure==null)appendJournal(path,batch);}
            catch(Exception error){journalFailure(a,error);}});
    }
    void save(Actor a,Map<String,Object> end){
        if(a.frames.isEmpty())return;
        String match=a.match;var frames=List.copyOf(a.frames);var outcome=new LinkedHashMap<String,Object>(end);
        long count=a.loggedFrames+frames.size();
        a.loading=true;
        writer.execute(()->{try{
            if(a.journalFailure!=null)return;
            Files.createDirectories(a.evaluations);Path completed=a.runtime.resolve(match+"-native-frames.jsonl");
            Path partial=partialJournal(a,match);appendJournal(partial,frames);
            Path evaluation=a.evaluations.resolve(match+".json.gz");
            try(var input=Files.newBufferedReader(partial,StandardCharsets.UTF_8);
                var zip=new JsonWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(evaluation)),StandardCharsets.UTF_8))){
                zip.beginObject().name("matchId").value(match).name("backend").value("server-native")
                    .name("trainingSkipped").value(true).name("neuralWeightsLoaded").value(false)
                    .name("outcome").jsonValue(JSON.toJson(outcome)).name("frames").beginArray();
                for(String line;(line=input.readLine())!=null;)zip.jsonValue(line);
                zip.endArray().endObject();
            }
            Files.move(partial,completed,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            Path report=a.runtime.resolve(match+"-report.json"),receipt=a.runtime.resolve(match+"-training.json");
            Files.writeString(report,JSON.toJson(Map.of("matchId",match,"frames",count,"completedFrames",completed.toString(),"backend","server-native","outcome",outcome)));
            Files.writeString(receipt,JSON.toJson(Map.of("event","evaluation_saved","fighter",Set.of("WaveDogBrother","WaveDogFather","WaveDogSister").contains(a.name)?a.name:"Punengbho","trainingSkipped",true,
                "checkpointSha256",policySha,"file",evaluation.toString(),"backend","server-native")));
            Bukkit.getScheduler().runTask(this,()->{a.loading=false;heartbeat(a);});
        }catch(Exception e){journalFailure(a,e);}});
    }
    void hold(Actor a){if(a.handle==null)return;a.handle.zza=a.handle.xxa=0;a.handle.setJumping(false);a.player().setSprinting(false);a.handle.stopUsingItem();}
    void decide(Actor a,int tick){
        long began=System.nanoTime();
        var target=Bukkit.getPlayerExact(a.opponent);if(target==null||target.isDead()||a.player().getWorld()!=target.getWorld()){hold(a);return;}
        if(dialogue!=null&&!a.frames.isEmpty())dialogue.offer(a,a.frames.getLast());
        Long interval=null;
        if(!a.frames.isEmpty()&&a.frames.getLast().get("nativeTiming") instanceof Map<?,?> previous&&previous.get("startedNanos") instanceof Number started)interval=began-started.longValue();
        a.lastDecisionTick=tick;var frame=frame(a,target,tick);long observed=System.nanoTime();var plan=policy.decide(a.name,frame);long planned=System.nanoTime();
        var row=new LinkedHashMap<String,Object>(frame);row.put("plan",JSON.fromJson(plan,Map.class));
        row.put("backend","server-native");row.put("matchId",a.match);row.put("policySha256",policySha);a.frames.add(row);
        Map<String,Object> actual;a.executing=true;
        try{actual=execute(a,target,plan.getAsJsonObject("command"),tick);}finally{a.executing=false;}
        row.put("actual",actual);policy.applied(a.name,plan.getAsJsonObject("command"),actual,tick);
        for(var receipt:a.deferredReceipts)policy.receipt(a.name,receipt,tick);a.deferredReceipts.clear();decisions++;
        if(dialogue!=null)dialogue.offer(a,row);
        long finished=System.nanoTime();var timing=new LinkedHashMap<String,Object>();
        timing.put("startedNanos",began);timing.put("intervalNanos",interval);timing.put("observationNanos",observed-began);
        timing.put("policyNanos",planned-observed);timing.put("executionAndReceiptNanos",finished-planned);timing.put("totalNanos",finished-began);
        row.put("nativeTiming",timing);row.put("decisionTrigger","tick");
        flushHistory(a);
    }
    // PlayerMoveEvent is raised BEFORE its destination is committed. Enqueue
    // behind the packet handler and then re-read the actual entity. Never use
    // getTo() as an accepted position or drive a second physics tick here.
    @EventHandler(priority=EventPriority.MONITOR) public void acceptedMove(PlayerMoveEvent event){
        if(failed)return;
        for(var a:actors.values())if(a.active&&!a.refreshQueued&&event.getPlayer().getName().equals(a.opponent)){
            a.refreshQueued=true;
            // Always enqueue behind the current movement packet, even on the
            // main thread. processQueue can wait for the following tick;
            // execute() here could run inline before the position is accepted.
            MinecraftServer.getServer().schedule(new net.minecraft.server.TickTask(Bukkit.getCurrentTick(),()->{
                a.refreshQueued=false;
                if(!failed&&a.active)try{primary();decide(a,Bukkit.getCurrentTick());
                    if(!a.frames.isEmpty())a.frames.getLast().put("decisionTrigger","accepted-move");
                }catch(Throwable error){
                    getLogger().log(java.util.logging.Level.SEVERE,"Native move decision failed for "+a.name,error);
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),a.command+" stop");hold(a);
                }
            }));
        }
    }
    @EventHandler public void tick(ServerTickEndEvent event){
        if(failed)return;long began=System.nanoTime();int tick=Bukkit.getCurrentTick();
        try{
            for(var p:Bukkit.getOnlinePlayers()){
                var at=p.getLocation();var before=positions.put(p.getUniqueId(),at);
                Vector v=before!=null&&before.getWorld()==at.getWorld()&&before.distanceSquared(at)<64?at.toVector().subtract(before.toVector()):new Vector();
                motion.put(p.getUniqueId(),v);
            }
            if(fixture!=null&&!fixture.done){fixture.tick(tick);for(var a:actors.values())if(a.handle!=null)a.handle.physics(tick);return;}
            // Alternate update order to avoid a permanently privileged side.
            var list=new ArrayList<>(actors.values());if((tick&1)!=0)Collections.reverse(list);
            for(var a:list)try{
                if(a.handle!=null&&(Bukkit.getPlayerExact(a.name)!=a.player()||a.handle.isRemoved())){
                    // Quit/kick has already removed the server entity.
                    a.handle=null;a.active=false;a.refreshQueued=false;
                }
                if(a.handle==null){
                    // Leave time for the previous AuthMe logout to settle.
                    if(tick%20==0&&getConfig().getBoolean("enabled",false))spawn(a);
                    continue;
                }
                if(a.player().isDead()){
                    hold(a);var old=a.handle;Location respawn=null;
                    for(var item:a.player().getMetadata("wavedog-return-after-duel"))if(item.value() instanceof Location at)respawn=at.clone();
                    if(Bukkit.getPlayerExact(a.name)==a.player()&&!old.isRemoved())MinecraftServer.getServer().getPlayerList().remove(old);
                    a.handle=null;a.refreshQueued=false;
                    if(respawn!=null)positions.put(old.getUUID(),respawn);
                    continue;
                }
                if(a.active&&a.lastDecisionTick!=tick){
                    decide(a,tick);
                }else if(!a.active){
                    hold(a);
                    Player p=a.player();int left=a.lastAimTick-tick;
                    boolean greeting=a.match!=null&&p.hasMetadata("wavedog-preparation-cage")&&left>20;
                    if(greeting){
                        p.setSneaking(tick<a.lastSwitchTick);
                        if(tick>=a.lastWindTick){
                            int choice=ThreadLocalRandom.current().nextInt(3);
                            if(choice==0){a.lastSwitchTick=tick+ThreadLocalRandom.current().nextInt(4,11);p.setSneaking(true);}
                            else if(choice==1&&p.isOnGround())a.handle.jumpFromGround();
                            else p.swingMainHand();
                            a.lastWindTick=tick+ThreadLocalRandom.current().nextInt(18,56);
                        }
                        if(dialogue!=null&&tick>=a.lastDecisionTick){
                            var target=Bukkit.getPlayerExact(a.opponent);
                            if(target!=null&&target.getWorld()==p.getWorld())dialogue.offer(a,frame(a,target,tick));
                            a.lastDecisionTick=tick+ThreadLocalRandom.current().nextInt(70,121);
                        }
                    }else{
                        p.setSneaking(false);
                        if(left>0&&left<=20){
                            var target=Bukkit.getPlayerExact(a.opponent);
                            if(target!=null&&target.getWorld()==p.getWorld())aim(a,target,false);
                        }
                    }
                }
                boolean watchFire=a.active&&a.name.equals("WaveDogSon");
                int fireBefore=watchFire?a.player().getFireTicks():0;
                boolean lavaBefore=watchFire&&a.player().isInLava();
                a.handle.physics(tick);
                if(watchFire&&a.active&&a.player().getFireTicks()>0&&(fireBefore<=0||lavaBefore&&!a.player().isInLava())){
                    var player=a.player();float yaw=player.getYaw(),pitch=player.getPitch();
                    String action;
                    try{action=UhcTools.douseAfterPhysics(a,tick);}
                    finally{player.setRotation(yaw,pitch);}
                    if(!action.isEmpty()&&!a.frames.isEmpty())a.frames.getLast().put("uhcAfterPhysics",
                        Map.of("action",action,"buckets",UhcTools.bucketSlots(player),"tick",tick));
                }
                if(tick%20==0)heartbeat(a);
            }catch(Throwable error){
                // One actor's lifecycle must not stop the other controller.
                getLogger().log(java.util.logging.Level.SEVERE,"Native actor failed: "+a.name,error);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),a.command+" stop");
                if(a.handle!=null){hold(a);if(Bukkit.getPlayerExact(a.name)==a.player()&&!a.handle.isRemoved())MinecraftServer.getServer().getPlayerList().remove(a.handle);a.handle=null;}
            }
            lastNanos=System.nanoTime()-began;peakNanos=Math.max(peakNanos,lastNanos);
        }catch(Throwable e){fail(e);}
    }
    String block(String name,int x,int y,int z){
        primary();Actor a=actors.get(name);World w=a==null||a.player()==null?null:a.player().getWorld();
        if(w==null||!w.isChunkLoaded(x>>4,z>>4)||y<w.getMinHeight()||y>=w.getMaxHeight())return "null";
        var block=w.getBlockAt(x,y,z);var shapes=new ArrayList<List<Double>>();
        for(var b:block.getCollisionShape().getBoundingBoxes())shapes.add(List.of(b.getMinX(),b.getMinY(),b.getMinZ(),b.getMaxX(),b.getMaxY(),b.getMaxZ()));
        return JSON.toJson(Map.of("shapes",shapes));
    }
    boolean clear(String name,double x,double y,double z,double tx,double ty,double tz){
        primary();Actor a=actors.get(name);if(a==null||a.player()==null)return false;
        return clear(new Location(a.player().getWorld(),x,y,z),new Vector(tx,ty,tz));
    }
    private static boolean clear(Location from,Vector end){
        Vector direction=end.clone().subtract(from.toVector());
        double length=direction.length();
        return length<1e-10||from.getWorld().rayTraceBlocks(from,direction.normalize(),length,FluidCollisionMode.NEVER,false)==null;
    }
    static double reach(Player p,Entity target){
        var e=p.getEyeLocation();var b=target.getBoundingBox();
        return Math.sqrt(Math.pow(e.getX()-Math.clamp(e.getX(),b.getMinX(),b.getMaxX()),2)
            +Math.pow(e.getY()-Math.clamp(e.getY(),b.getMinY(),b.getMaxY()),2)+Math.pow(e.getZ()-Math.clamp(e.getZ(),b.getMinZ(),b.getMaxZ()),2));
    }
    static boolean loaded(ItemStack item){return item!=null&&item.getItemMeta() instanceof CrossbowMeta meta&&meta.hasChargedProjectiles();}
    static boolean has(Player p,Material type){for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==type)return true;return false;}
    static ItemStack crossbow(Player p){for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.CROSSBOW)return item;return null;}
    Vector velocity(Player p){
        var actor=actors.get(p.getName());
        if(actor!=null&&actor.handle!=null&&actor.player()==p){
            var pending=actor.handle.queuedMotion;
            return pending==null?p.getVelocity():new Vector(pending.x,pending.y,pending.z);
        }
        var at=p.getLocation();var before=positions.get(p.getUniqueId());
        if(before!=null&&before.getWorld()==at.getWorld()&&before.distanceSquared(at)>1e-12&&before.distanceSquared(at)<64)
            return at.toVector().subtract(before.toVector());
        return motion.getOrDefault(p.getUniqueId(),new Vector());
    }
    Map<String,Object> body(Player p){
        var at=p.getLocation();var v=velocity(p);var row=new LinkedHashMap<String,Object>();
        row.put("x",at.getX());row.put("y",at.getY());row.put("z",at.getZ());row.put("eyeY",p.getEyeLocation().getY());
        row.put("vx",v.getX());row.put("vy",v.getY());row.put("vz",v.getZ());row.put("ground",p.isOnGround());
        row.put("eyeHeight",p.getEyeHeight());row.put("height",p.getHeight());row.put("half",p.getWidth()/2);row.put("entityId",p.getEntityId());
        row.put("yaw",Math.toRadians(180-at.getYaw()));row.put("health",p.getHealth());row.put("food",p.getFoodLevel());row.put("sprint",p.isSprinting());
        row.put("nativeYaw",at.getYaw());row.put("nativePitch",at.getPitch());
        row.put("charge",p.getCooledAttackStrength(0));row.put("held",p.getInventory().getHeldItemSlot());row.put("using",p.hasActiveItem());row.put("useTicks",p.getHandRaisedTime());
        // Player.attack evaluates cooldown at the half-tick point. Expose that
        // exact value so the policy does not lose a legal knockback tick.
        row.put("attackChargeAtHit",p.getCooledAttackStrength(.5f));
        for(var pair:Map.of("attackRange",Attribute.ENTITY_INTERACTION_RANGE,"attackSpeed",Attribute.ATTACK_SPEED,"attackDamage",Attribute.ATTACK_DAMAGE).entrySet()){
            var attribute=p.getAttribute(pair.getValue());if(attribute!=null)row.put(pair.getKey(),attribute.getValue());
        }
        row.put("critical",p.getFallDistance()>0&&!p.isOnGround()&&!p.isInWater()&&!p.isClimbing()&&!p.isInsideVehicle()&&!p.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS));
        row.put("fallDistance",p.getFallDistance());row.put("wireGround",p.isOnGround());row.put("wireFalling",p.getFallDistance()>0);
        row.put("noDamageTicks",p.getNoDamageTicks());row.put("maxNoDamageTicks",p.getMaximumNoDamageTicks());row.put("lastDamage",p.getLastDamage());
        row.put("shieldAvailable",!p.hasCooldown(Material.SHIELD)&&has(p,Material.SHIELD));row.put("shielding",p.isBlocking());
        row.put("hasBow",has(p,Material.BOW));row.put("hasCrossbow",has(p,Material.CROSSBOW));row.put("crossbowLoaded",loaded(crossbow(p)));
        int arrows=0;for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.ARROW)arrows+=item.getAmount();row.put("arrows",arrows);
        row.put("jumpAvailable",p.isOnGround()&&p.getFoodLevel()>6&&!p.isInWater()&&!p.isInsideVehicle());
        row.put("serverVelocity",Map.of("x",p.getVelocity().getX(),"y",p.getVelocity().getY(),"z",p.getVelocity().getZ()));
        var box=p.getBoundingBox();row.put("box",List.of(box.getMinX(),box.getMinY(),box.getMinZ(),box.getMaxX(),box.getMaxY(),box.getMaxZ()));
        return row;
    }
    Map<String,Object> frame(Actor a,Player target,int tick){
        Player p=a.player();var self=body(p);var targetBody=body(target);var v=velocity(target);
        self.put("physicsTick",a.handle.lastPhysicsTick);
        var impulse=v.clone();boolean observedGroundMotion=false;
        var targetActor=actors.get(target.getName());
        if(target.isOnGround()&&targetActor!=null&&targetActor.player()==target&&targetActor.handle.queuedMotion==null){
            // Native deltaMovement is the residual AFTER drag, not distance
            // travelled in the last tick. Using it as ground speed makes the
            // next contact perpetually two ticks away against a retreating
            // opponent. Preserve the impulse separately; forecast ground
            // travel from the same accepted position deltas used for humans.
            var before=positions.get(target.getUniqueId());var at=target.getLocation();
            if(before!=null&&before.getWorld()==at.getWorld()&&before.distanceSquared(at)<64){
                var delta=at.toVector().subtract(before.toVector());
                v=delta.lengthSquared()>1e-12?delta:motion.getOrDefault(target.getUniqueId(),new Vector());
                observedGroundMotion=true;
            }
        }
        var arrows=new ArrayList<Map<String,Object>>();for(var entity:p.getNearbyEntities(32,16,32))if(entity instanceof AbstractArrow arrow&&!arrow.isInBlock()){
            var at=arrow.getLocation();var velocity=arrow.getVelocity();var item=new LinkedHashMap<String,Object>();item.put("id",arrow.getEntityId());
            item.put("x",at.getX());item.put("y",at.getY());item.put("z",at.getZ());item.put("vx",velocity.getX());item.put("vy",velocity.getY());item.put("vz",velocity.getZ());item.put("ageMs",0);
            if(a.name.equals("WaveDogSon")){item.put("inWater",arrow.isInWater());item.put("noGravity",!arrow.hasGravity());}
            if(arrow.getShooter() instanceof Entity shooter)item.put("shooterId",shooter.getEntityId());arrows.add(item);
        }
        boolean shield=target.hasActiveItem()&&target.getActiveItem().getType()==Material.SHIELD;
        var toward=p.getLocation().toVector().subtract(target.getLocation().toVector());var facing=target.getLocation().getDirection();facing.setY(0);
        double facingDot=facing.dot(toward)/Math.max(.001,Math.hypot(toward.getX(),toward.getZ()));
        boolean bow=target.hasActiveItem()&&target.getActiveItem().getType()==Material.BOW;
        boolean loading=target.hasActiveItem()&&target.getActiveItem().getType()==Material.CROSSBOW&&!loaded(target.getActiveItem());
        boolean knownLoaded=loaded(crossbow(target));
        if(loading&&!a.wasLoading){a.loadCycle++;a.rangedEvent++;}
        if(bow&&!a.wasBow)a.rangedEvent++;
        if(!loading&&a.wasLoading){a.loadEndedAt=tick;a.loadResult=knownLoaded?"charged":"unconfirmed";}
        a.wasLoading=loading;a.wasBow=bow;
        var targetFloor=target.getWorld().rayTraceBlocks(target.getLocation().add(0,.1,0),new Vector(0,-1,0),16,FluidCollisionMode.NEVER,false);
        double floor=targetFloor==null?target.getWorld().getMinHeight():targetFloor.getHitPosition().getY();
        var seen=new LinkedHashMap<String,Object>(targetBody);seen.put("visible",p.getWorld()==target.getWorld()&&p.getLocation().distanceSquared(target.getLocation())<4096&&p.hasLineOfSight(target));
        seen.put("shield",target.isBlocking());seen.put("shieldRaised",shield);seen.put("held",target.getInventory().getItemInMainHand().getType().name());seen.put("arrows",arrows);
        var o=new LinkedHashMap<String,Object>();o.put("tick",tick);o.put("visible",seen.get("visible"));o.put("reach",reach(p,target));o.put("otherReach",reach(target,p));
        o.put("distance",p.getLocation().distance(target.getLocation()));o.put("targetGrounded",target.isOnGround());o.put("targetAirborne",!target.isOnGround());
        o.put("targetShieldRaised",shield);o.put("targetShieldFacing",target.isBlocking()&&facingDot>0);o.put("targetFacingDot",facingDot);o.put("targetBow",bow);o.put("targetLoading",loading);
        o.put("targetLoadCycle",a.loadCycle);o.put("targetShotEvent",a.shotEvent);o.put("targetShotTick",a.shotTick);o.put("targetShotWeapon",a.shotWeapon);
        o.put("targetKnownLoaded",knownLoaded);o.put("targetLoadResult",a.loadResult);o.put("targetLoadEndedAt",a.loadEndedAt);o.put("rangedEvent",a.rangedEvent);
        o.put("targetYaw",targetBody.get("yaw"));o.put("shieldRaised",p.hasActiveItem()&&p.getActiveItem().getType()==Material.SHIELD);o.put("shieldEffective",p.isBlocking());
        o.put("offhandShieldReady",p.getInventory().getItemInOffHand().getType()==Material.SHIELD);o.put("loaded",self.get("crossbowLoaded"));o.put("arrows",self.get("arrows"));
        o.put("targetAttackCharge",target.getCooledAttackStrength(0));o.put("positionSource","server-native-live-v1");o.put("serverTick",tick);o.put("wallMargin",1.5);
        o.put("charge",self.get("charge"));o.put("ground",self.get("ground"));o.put("held",self.get("held"));o.put("shieldReady",self.get("shieldAvailable"));
        o.put("targetSwingRecent",tick-a.lastSwing<=1);o.put("targetRanged",bow||loading||loaded(crossbow(target)));
        self.put("attackAgeTicks",tick-a.lastAttackTick);self.put("weaponAgeTicks",tick-a.lastSwitchTick);self.put("ceilingClear",p.getWorld().getBlockAt(p.getLocation().add(0,2.8,0)).isPassable());
        var frame=new LinkedHashMap<String,Object>();frame.put("self",self);frame.put("seen",seen);frame.put("observation",o);
        frame.put("targetVelocity",Map.of("x",v.getX(),"y",v.getY(),"z",v.getZ()));frame.put("targetFloorY",floor);
        frame.put("targetMotion",Map.of("sampleTick",tick,"observedGroundMotion",observedGroundMotion,
            "velocityKind",observedGroundMotion?"accepted-ground-displacement":"impulse-or-observed-air-motion",
            "physicsVelocity",Map.of("x",impulse.getX(),"y",impulse.getY(),"z",impulse.getZ())));
        frame.put("usingKind",p.hasActiveItem()?p.getActiveItem().getType().name().toLowerCase(Locale.ROOT):null);
        int opponentPing=Math.max(0,target.getPing());
        frame.put("latency",Map.of("oneWayMs",0,"serverQueueMs",0,"observationAgeMs",0,"rttMs",0,"opponentRttMs",opponentPing));
        frame.put("offhand",p.getInventory().getItemInOffHand().getType().name().toLowerCase(Locale.ROOT));
        var enemyHandle=((CraftPlayer)target).getHandle();var enemyAttack=enemyHandle.entityAttackRange();
        double baseRange=enemyAttack.effectiveMaxRange(enemyHandle)+enemyAttack.hitboxMargin();
        double leniency=io.papermc.paper.configuration.GlobalConfiguration.get().misc.clientInteractionLeniencyDistance.or(3.0);
        var geometry=new LinkedHashMap<String,Object>();
        geometry.put("outgoingReach",reach(p,target));geometry.put("incomingLiveReach",reach(target,p));
        geometry.put("opponentBaseRange",baseRange);geometry.put("serverLeniency",leniency);
        geometry.put("serverPacketRangeMax",baseRange+leniency);
        geometry.put("serverAcceptsCurrentAttackRange",enemyAttack.isInRange(enemyHandle,a.handle.getBoundingBox(),leniency));
        // This is the server tracker's last broadcast base, not an assertion
        // about packet delivery or a remote client's unreported local state.
        var tracked=((CraftWorld)p.getWorld()).getHandle().getChunkSource().chunkMap.entityMap.get(a.handle.getId());
        var candidates=new ArrayList<Map<String,Object>>();
        int viewTicks=Math.min(8,Math.max(2,(int)Math.ceil(opponentPing/100.0)+2));
        if(tracked!=null&&tracked.seenBy.contains(enemyHandle.connection)){
            var base=tracked.serverEntity.getPositionBase();
            candidates.add(Map.of("x",base.x,"y",base.y,"z",base.z,"ticksRemaining",viewTicks,"source","tracker-broadcast-base","deliveryConfirmed",false));
        }
        var ticks=new HashSet<Integer>();
        for(int i=a.frames.size()-1,read=0;i>=0&&read<256;i--,read++){
            var old=a.frames.get(i);
            if(!(old.get("observation") instanceof Map<?,?> obs)||!(obs.get("tick") instanceof Number stamp))continue;
            int age=tick-stamp.intValue();if(age>viewTicks)break;
            if(age<=0||!ticks.add(stamp.intValue())||!(old.get("self") instanceof Map<?,?> prior))continue;
            candidates.add(Map.of("x",prior.get("x"),"y",prior.get("y"),"z",prior.get("z"),
                "ticksRemaining",viewTicks-age,"source","observed-server-history","deliveryConfirmed",false));
        }
        geometry.put("defenseCandidates",candidates);geometry.put("clientViewEstimated",true);
        geometry.put("opponentPingMs",opponentPing);geometry.put("viewExposureTicks",viewTicks);
        frame.put("combatGeometry",geometry);
        frame.put("allServerPlayers",Bukkit.getOnlinePlayers().stream().map(this::body).toList());
        frame.put("opponent",target.getName());frame.put("matchId",a.match==null?"fixture-"+a.name:a.match);
        var neural=Bukkit.getPluginManager().getPlugin("WaveDogNeuralFallback");
        boolean useNeural=!a.name.equals("WaveDogSister");
        if(a.name.equals("WaveDogFather")){
            var practice=CrystalActions.observation(a,target,tick);
            frame.put("crystalPractice",practice);
            useNeural=Boolean.TRUE.equals(practice.get("swordOnly"));
        }else if(a.name.equals("WaveDogSister"))frame.put("macePractice",SisterActions.observation(a));
        if(useNeural&&neural!=null&&neural.isEnabled())try{
            frame.put("neuralFallback",neural.getClass().getMethod("propose",String.class,Map.class,int.class).invoke(neural,a.name,frame,tick));
        }catch(ReflectiveOperationException error){throw new IllegalStateException("Frozen neural fallback bridge failed",error);}
        return frame;
    }
    static boolean flag(JsonObject object,String key){return object.has(key)&&!object.get(key).isJsonNull()&&object.get(key).getAsBoolean();}
    static double number(JsonObject object,String key,double fallback){return object.has(key)&&!object.get(key).isJsonNull()?object.get(key).getAsDouble():fallback;}
    static String string(JsonObject object,String key,String fallback){return object.has(key)&&!object.get(key).isJsonNull()?object.get(key).getAsString():fallback;}
    boolean offhand(Actor a,Material type){
        var inv=a.player().getInventory();if(inv.getItemInOffHand().getType()==type)return true;
        for(int slot=0;slot<36;slot++){var item=inv.getItem(slot);if(item!=null&&item.getType()==type){
            a.handle.stopUsingItem();var old=inv.getItemInOffHand();inv.setItemInOffHand(item);inv.setItem(slot,old);return true;}}
        return false;
    }
    void aim(Actor a,Player target,boolean ranged){
        var eye=a.player().getEyeLocation();var b=target.getBoundingBox();
        double x=Math.clamp(eye.getX(),b.getMinX()+1e-7,b.getMaxX()-1e-7),y=Math.clamp(eye.getY(),b.getMinY()+1e-7,b.getMaxY()-1e-7),z=Math.clamp(eye.getZ(),b.getMinZ()+1e-7,b.getMaxZ()-1e-7);
        Vector direction=new Vector(x-eye.getX(),y-eye.getY(),z-eye.getZ());
        if(ranged){
            var tv=velocity(target);
            var floor=target.getWorld().rayTraceBlocks(target.getLocation().add(0,.1,0),new Vector(0,-1,0),16,FluidCollisionMode.NEVER,false);
            var params=new LinkedHashMap<String,Object>(Map.of("eye",Map.of("x",eye.getX(),"y",eye.getY()-.1,"z",eye.getZ()),"feet",Map.of("x",target.getX(),"y",target.getY(),"z",target.getZ()),
                "motion",Map.of("x",tv.getX(),"y",tv.getY(),"z",tv.getZ()),"airborne",!target.isOnGround(),"floorY",floor==null?target.getY():floor.getHitPosition().getY(),"height",target.getHeight(),"speed",3.15));
            // Crossbow bolts do not inherit the shooter's walking velocity.
            params.put("inherited",Map.of("x",0,"y",0,"z",0));
            if(a.calibration!=null)params.put("profile",a.calibration);
            String solved=policy.rangedAim(JSON.toJson(params));
            if(!solved.equals("null")){var d=JSON.fromJson(solved,JsonObject.class).getAsJsonObject("direction");direction=new Vector(d.get("x").getAsDouble(),d.get("y").getAsDouble(),d.get("z").getAsDouble());}
        }
        Location look=eye.clone().setDirection(direction);a.player().setRotation(look.getYaw(),look.getPitch());
    }
    static Location sonMeleeLook(Location eye,BoundingBox box,double allowed){
        double minX=box.getMinX()+.0001,maxX=box.getMaxX()-.0001;
        double minY=box.getMinY()+.0001,maxY=box.getMaxY()-.0001;
        double minZ=box.getMinZ()+.0001,maxZ=box.getMaxZ()-.0001;
        Vector origin=eye.toVector();
        double x=Math.clamp(eye.getX(),minX,maxX),y=Math.clamp(eye.getY(),minY,maxY),z=Math.clamp(eye.getZ(),minZ,maxZ);
        Vector nearest=new Vector(x,y,z);
        Location direct=clearMeleeLook(eye,origin,box,nearest,allowed);
        if(direct!=null)return direct;
        var points=new ArrayList<Vector>();
        for(double px:new double[]{x,minX,maxX})for(double py:new double[]{y,Math.max(minY,y-.22),Math.min(maxY,y+.18)})
            for(double pz:new double[]{z,minZ,maxZ}){
                var point=new Vector(px,py,pz);
                if(!point.equals(nearest)&&point.distanceSquared(origin)<=allowed*allowed&&!points.contains(point))points.add(point);
            }
        points.sort(Comparator.comparingDouble(point->point.distanceSquared(origin)));
        for(var point:points){
            var look=clearMeleeLook(eye,origin,box,point,allowed);
            if(look!=null)return look;
        }
        return null;
    }
    private static Location clearMeleeLook(Location eye,Vector origin,BoundingBox box,Vector point,double allowed){
        Vector direction=point.clone().subtract(origin);
        if(direction.lengthSquared()<1e-12)direction=box.getCenter().subtract(origin);
        var look=eye.clone().setDirection(direction);
        var ray=box.rayTrace(origin,look.getDirection(),allowed);
        if(ray==null)return null;
        return clear(eye,ray.getHitPosition())?look:null;
    }
    Map<String,Object> strike(Actor a,Player target,JsonObject c,int tick){
        return strike(a,target,c,tick,null);
    }
    private Map<String,Object> strike(Actor a,Player target,JsonObject c,int tick,Location meleeLook){
        if(a.handle.handActionLocked())return Map.of("attempted",false,"reason","item-use");
        long id=++a.attackId;
        input(a,Map.of("type","attack_intent","attackId",id,"target",target.getName(),"kind",string(c,"kind","native-son")));
        if(meleeLook!=null)a.player().setRotation(meleeLook.getYaw(),meleeLook.getPitch());
        else if(!a.name.equals("WaveDogSister"))aim(a,target,false);
        var eye=a.player().getEyeLocation();var b=target.getBoundingBox();
        double distance=reach(a.player(),target);var range=a.player().getAttribute(Attribute.ENTITY_INTERACTION_RANGE);double allowed=Math.min(3,range==null?3:range.getValue());
        var ray=b.rayTrace(eye.toVector(),eye.getDirection(),allowed);
        boolean legal=a.player().getWorld()==target.getWorld()&&!target.isDead()&&distance<=allowed&&ray!=null
            &&clear(a.name,eye.getX(),eye.getY(),eye.getZ(),ray.getHitPosition().getX(),ray.getHitPosition().getY(),ray.getHitPosition().getZ());
        double charge=a.player().getCooledAttackStrength(.5f);
        var result=new LinkedHashMap<String,Object>();result.put("id",id);result.put("attempted",false);result.put("charge",charge);
        boolean sprintBefore=a.player().isSprinting();result.put("sprintBefore",sprintBefore);
        var targetBeforeVelocity=target.getVelocity();result.put("targetBeforeVelocity",Map.of("x",targetBeforeVelocity.getX(),"y",targetBeforeVelocity.getY(),"z",targetBeforeVelocity.getZ()));
        // Player.attack() already fires Paper's pre-attack event. Calling it
        // ourselves as well consumes the referee intent twice and loses IDs.
        double healthBefore=target.getHealth()+target.getAbsorptionAmount();
        if(legal){
            a.currentAttack=result;a.lastDispatchTick=tick;
            try{
                a.handle.stopUsingItem();
                a.player().swingMainHand();a.player().attack(target);
            }
            finally{a.currentAttack=null;}
            if(Boolean.TRUE.equals(result.get("attempted")))a.lastAttackTick=tick;
        }
        result.put("held",a.player().getInventory().getHeldItemSlot());result.put("reach",distance);result.put("allowedRange",allowed);
        result.put("rayDistance",ray==null?null:ray.getHitPosition().distance(eye.toVector()));result.put("source","server-native-attack-handler-v1");result.put("serverTick",tick);
        double actualDamage=Math.max(0,healthBefore-target.getHealth()-target.getAbsorptionAmount());
        result.put("targetDamage",actualDamage);result.put("targetMotionPacketObserved",result.containsKey("targetVelocityPacket"));
        double horizontalSpeed=0,horizontalDelta=0;
        if(result.get("targetVelocityPacket") instanceof Map<?,?> packet){
            double dx=target.getX()-a.player().getX(),dz=target.getZ()-a.player().getZ(),length=Math.max(.001,Math.hypot(dx,dz));
            double px=((Number)packet.get("x")).doubleValue(),pz=((Number)packet.get("z")).doubleValue();
            horizontalSpeed=(px*dx+pz*dz)/length;
            horizontalDelta=((px-targetBeforeVelocity.getX())*dx+(pz-targetBeforeVelocity.getZ())*dz)/length;
        }
        result.put("targetOutwardSpeed",horizontalSpeed);result.put("outwardKnockbackDelta",horizontalDelta);
        result.put("outwardMotionConfirmed",result.containsKey("targetVelocityPacket")&&horizontalSpeed>.02);
        result.put("hitKind",actualDamage<=0?"no-positive-damage":Boolean.TRUE.equals(result.get("nativeCritical"))?"critical":
            !result.containsKey("targetVelocityPacket")?"damage-without-motion-packet":horizontalDelta<=.01?"damage-without-horizontal-knockback":
            horizontalSpeed<=.02?"knockback-did-not-stop-approach":sprintBefore&&charge>.9?"sprint-knockback":"ordinary-knockback");
        if(string(c,"kind","").equals("legacy86-stun")){
            result.put("targetShieldCooldown",target.getCooldown(Material.SHIELD));
            result.put("targetDamage",Math.max(0,healthBefore-target.getHealth()-target.getAbsorptionAmount()));
            result.put("targetMotionPacketObserved",result.containsKey("targetVelocityPacket"));
            var at=target.getLocation();result.put("targetMotionOrigin",Map.of("x",at.getX(),"y",at.getY(),"z",at.getZ()));
        }
        return result;
    }
    @EventHandler(priority=EventPriority.HIGHEST)public void verifyNativeAttack(PrePlayerAttackEntityEvent e){
        // A movement callback is queued behind the packet handler. The next
        // attack may be processed in the same packet batch before that queued
        // callback. Re-read the accepted entities HERE, while still on the
        // main thread, through the same policy and ordinary attack dedup gate.
        if(!e.isCancelled()&&e.willAttack()&&e.getAttacked() instanceof EnderCrystal){
            Actor father=actors.get("WaveDogFather");String attacker=e.getPlayer().getName();
            if(father!=null&&father.active&&(attacker.equals(father.name)||attacker.equals(father.opponent))
                &&reach(e.getPlayer(),e.getAttacked())>3)e.setCancelled(true);
        }
        if(!e.isCancelled()&&e.willAttack()&&e.getAttacked() instanceof Player defender){
            var attacker=e.getPlayer();
            var defending=actors.get(defender.getName());
            boolean duelOpponent=defending!=null&&defending.active&&defending.player()==defender
                &&attacker.getName().equals(defending.opponent);
            // Bot strikes already use the same eye-to-box limit in strike().
            if(duelOpponent&&(reach(attacker,defender)>3.0
                ||defending.name.equals("WaveDogSon")&&!attacker.hasLineOfSight(defender))){
                e.setCancelled(true);
                return;
            }
            if(duelOpponent&&!failed&&!defending.loading&&!defending.executing
                &&defending.lastDispatchTick!=Bukkit.getCurrentTick()&&reach(defender,attacker)<=4.5){
                try{
                    decide(defending,Bukkit.getCurrentTick());
                    if(!defending.frames.isEmpty()){
                        var row=defending.frames.getLast();row.put("decisionTrigger","incoming-attack");
                        row.put("incomingAttack",Map.of("attacker",attacker.getName(),
                            "liveReach",reach(defender,attacker),"acceptedPosition",true,"queued",false));
                    }
                }catch(Throwable problem){
                    getLogger().log(java.util.logging.Level.SEVERE,"Native incoming-attack response failed for "+defending.name,problem);
                    // An error must neither cancel the incoming attack nor
                    // stop the other actor's independent match lifecycle.
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),defending.command+" stop");hold(defending);
                }
            }
        }
        var a=actors.get(e.getPlayer().getName());if(a==null||a.handle==null||a.player()!=e.getPlayer()||a.currentAttack==null)return;
        if(!(e.getAttacked() instanceof Player target)||target.getWorld()!=a.player().getWorld()||target.isDead()){e.setCancelled(true);return;}
        var eye=a.player().getEyeLocation();var attribute=a.player().getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
        double allowed=Math.min(3,attribute==null?3:attribute.getValue());
        var ray=target.getBoundingBox().rayTrace(eye.toVector(),eye.getDirection(),allowed);
        if(reach(a.player(),target)>allowed||ray==null||!clear(a.name,eye.getX(),eye.getY(),eye.getZ(),ray.getHitPosition().getX(),ray.getHitPosition().getY(),ray.getHitPosition().getZ()))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.MONITOR)public void nativeAttackReceipt(PrePlayerAttackEntityEvent e){
        var a=actors.get(e.getPlayer().getName());if(a==null||a.handle==null||a.player()!=e.getPlayer()||a.currentAttack==null)return;
        a.currentAttack.put("attempted",!e.isCancelled()&&e.willAttack());
        a.currentAttack.put("cancelled",e.isCancelled());
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void nativeDamageReceipt(EntityDamageEvent e){
        if(e.getDamageSource().getDamageType()==org.bukkit.damage.DamageType.BAD_RESPAWN_POINT
            &&e.getFinalDamage()>0&&e.getEntity() instanceof Player victim){
            var father=actors.get("WaveDogFather");
            if(father!=null&&father.active&&!father.frames.isEmpty()
                &&(victim==father.player()||victim.getName().equals(father.opponent))){
                var sample=new LinkedHashMap<String,Object>();
                sample.put("type","damage");sample.put("weapon","respawn_anchor");sample.put("victim",victim.getName());
                sample.put("amount",e.getFinalDamage());sample.put("serverTick",Bukkit.getCurrentTick());
                var origin=e.getDamageSource().getDamageLocation();
                if(origin!=null){
                    sample.put("origin",List.of(origin.getX(),origin.getY(),origin.getZ()));
                    if(victim==father.player())CrystalActions.incomingAnchorHit(father,origin,Bukkit.getCurrentTick());
                }
                @SuppressWarnings("unchecked") var events=(List<Object>)father.frames.getLast()
                    .computeIfAbsent("nativeEvents",key->new ArrayList<>());
                events.add(sample);
            }
        }
        if(e instanceof EntityDamageByEntityEvent explosion
            &&explosion.getDamager() instanceof EnderCrystal crystal&&e.getFinalDamage()>0){
            Actor father=actors.get("WaveDogFather");
            if(father!=null&&father.active&&!father.frames.isEmpty()&&explosion.getEntity() instanceof Player victim){
                boolean own=crystal.getScoreboardTags().contains("wavedog-father-crystal");
                if(own&&victim.getName().equals(father.opponent)||!own&&victim==father.player()){
                    var sample=Map.of("type","damage","weapon","end_crystal",
                        "attacker",own?father.name:father.opponent,"victim",victim.getName(),
                        "amount",e.getFinalDamage(),"cancelled",false,"serverTick",Bukkit.getCurrentTick());
                    @SuppressWarnings("unchecked") var events=(List<Object>)father.frames.getLast().get("nativeEvents");
                    if(events==null){events=new ArrayList<>();father.frames.getLast().put("nativeEvents",events);}
                    events.add(sample);
                }
            }
        }
        if(e instanceof EntityDamageByEntityEvent outgoing&&outgoing.getDamager() instanceof Player attacker){
            var striking=actors.get(attacker.getName());
            if(striking!=null&&striking.handle!=null&&striking.player()==attacker&&striking.currentAttack!=null){
                striking.currentAttack.put("nativeCritical",outgoing.isCritical());
                striking.currentAttack.put("damageEventAmount",outgoing.getFinalDamage());
            }
        }
        if(!(e.getEntity() instanceof Player p))return;var a=actors.get(p.getName());
        if(a==null||a.handle==null||a.player()!=p||a.handle.hurtContext==null)return;
        var hit=a.handle.hurtContext;hit.positiveDamage|=e.getFinalDamage()>0;
        hit.blocked|=e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)&&e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING)<0;
        if(a.active&&!a.frames.isEmpty()&&e instanceof EntityDamageByEntityEvent attack){
            Entity source=attack.getDamager();if(source instanceof Projectile projectile&&projectile.getShooter() instanceof Entity shooter)source=shooter;
            if(source instanceof Player attacker){
                var sample=new LinkedHashMap<String,Object>();sample.put("serverTick",Bukkit.getCurrentTick());sample.put("atNanos",System.nanoTime());
                sample.put("attacker",attacker.getName());sample.put("victim",p.getName());sample.put("attackerReach",reach(attacker,p));
                sample.put("victimReach",reach(p,attacker));sample.put("critical",attack.isCritical());sample.put("amount",e.getFinalDamage());
                sample.put("attackerBody",body(attacker));sample.put("victimBody",body(p));
                @SuppressWarnings("unchecked") var snapshots=(List<Object>)a.frames.getLast().get("nativeDamageSnapshots");
                if(snapshots==null){snapshots=new ArrayList<>();a.frames.getLast().put("nativeDamageSnapshots",snapshots);}snapshots.add(sample);
            }
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)public void nativeVelocityReceipt(PlayerVelocityEvent e){
        var a=actors.get(e.getPlayer().getName());if(a!=null&&a.handle!=null&&a.player()==e.getPlayer()&&a.handle.hurtContext!=null)a.handle.hurtContext.velocity=true;
        // Paper initializes this event with the PRE-HIT vector. If plugins
        // leave it alone, the packet instead uses the live post-hit velocity.
        // Capture that pending payload before vanilla restores the old value.
        for(var attacker:actors.values())if(attacker.currentAttack!=null&&e.getPlayer().getName().equals(attacker.opponent)){
            @SuppressWarnings("unchecked") var before=(Map<String,Number>)attacker.currentAttack.get("targetBeforeVelocity");
            var event=e.getVelocity();boolean modified=before!=null&&(Math.abs(event.getX()-before.get("x").doubleValue())>1e-9
                ||Math.abs(event.getY()-before.get("y").doubleValue())>1e-9||Math.abs(event.getZ()-before.get("z").doubleValue())>1e-9);
            var v=modified?event:e.getPlayer().getVelocity();attacker.currentAttack.put("targetVelocityPacket",Map.of("x",v.getX(),"y",v.getY(),"z",v.getZ()));
        }
    }
    private Map<String,Object> continueItemUse(Actor a,Player target,JsonObject c,JsonObject order){
        var p=a.player();var handle=a.handle;
        handle.exclusiveUseTick=Bukkit.getCurrentTick();
        Material item=p.getActiveItem().getType();
        boolean father=a.name.equals("WaveDogFather");
        boolean eating=father?CrystalActions.eatingApple(p):UhcTools.eatingApple(p);
        var rangedResult=new LinkedHashMap<String,Object>();
        String ranged=string(c,"ranged","");
        if(item==Material.CROSSBOW){
            if(loaded(p.getActiveItem())){
                handle.releaseUsingItem();rangedResult.put("loadReleased",true);
            }else if(!ranged.equals("load-crossbow"))handle.stopUsingItem();
        }else if(item==Material.BOW){
            if(!ranged.equals("bow"))handle.stopUsingItem();
            else if(flag(c,"rangedRelease")){
                aim(a,target,true);handle.releaseUsingItem();rangedResult.put("bowReleased",true);
            }
        }
        double yaw=Math.toRadians(p.getYaw()),forward=number(c,"forward",0),side=number(c,"side",0);
        Vector heading=null;
        if(eating&&father){
            heading=CrystalActions.appleBlastHeading(a,target);
        }else if(eating){
            heading=p.getLocation().toVector().subtract(target.getLocation().toVector()).setY(0);
            if(heading.lengthSquared()>.001)heading.normalize();
            if(order!=null&&order.get("rangedFallback") instanceof JsonObject fallback
                &&fallback.get("worldHeading") instanceof JsonObject retreat){
                heading=new Vector(number(retreat,"x",0),0,number(retreat,"z",0));
            }
            var route=UhcTools.steer(a,target,heading);
            if(route!=null)heading=route.heading();
            if(heading.lengthSquared()>.02){
                p.setRotation((float)Math.toDegrees(Math.atan2(-heading.getX(),heading.getZ())),0);
                yaw=Math.toRadians(p.getYaw());
            }
        }else if(c.get("worldHeading") instanceof JsonObject move){
            heading=new Vector(number(move,"x",0),0,number(move,"z",0));
        }
        if(heading!=null){
            forward=-Math.sin(yaw)*heading.getX()+Math.cos(yaw)*heading.getZ();
            side=Math.cos(yaw)*heading.getX()+Math.sin(yaw)*heading.getZ();
        }
        p.setSprinting(false);handle.setJumping(false);
        float scale=.2f*(p.isSneaking()?.3f:1f);
        handle.zza=(float)Math.clamp(forward,-1,1)*scale;handle.xxa=(float)Math.clamp(side,-1,1)*scale;
        var actual=new LinkedHashMap<String,Object>();
        actual.put("attacked",false);actual.put("attacks",List.of());actual.put("rangedResult",rangedResult);
        actual.put("held",p.getInventory().getHeldItemSlot());actual.put("sprint",false);actual.put("jump",false);
        actual.put("shield",p.isBlocking());actual.put("using",p.hasActiveItem());actual.put("itemUseLocked",true);
        actual.put("physicsTick",handle.lastPhysicsTick);actual.put("forward",handle.zza);actual.put("side",handle.xxa);
        if(eating)actual.put("uhcAction","eat-apple");
        if(eating&&a.name.equals("WaveDogFather")&&heading.lengthSquared()>.01)actual.put("fatherTerrain","blast-escape-eating");
        return actual;
    }
    Map<String,Object> execute(Actor a,Player target,JsonObject c,int tick){
        primary();Player p=a.player();var handle=a.handle;
        if(a.name.equals("WaveDogSister"))return SisterActions.execute(this,a,target,c,tick);
        boolean father=a.name.equals("WaveDogFather");
        boolean fatherSword=father&&flag(c,"fatherSword");
        boolean son=a.name.equals("WaveDogSon")&&c.has("uhc");
        var order=son?c.getAsJsonObject("uhc"):null;
        if(handle.handActionLocked())return continueItemUse(a,target,c,order);
        String uhc=son?UhcTools.decide(a,target,order,flag(c,"motionRetreat"),tick):"";
        if(handle.usingExclusiveItem())return continueItemUse(a,target,c,order);
        JsonObject fallback=son&&order.get("rangedFallback") instanceof JsonObject choice?choice:null;
        boolean keepShotShield=son&&keepSonShotShield(p.getActiveItem().getType(),tick-a.shotTick,uhc,fallback);
        if(keepShotShield)uhc="arrow-shield";
        else if(uhc.equals("arrow-fallback")&&fallback!=null){
            c=fallback;uhc=string(c,"intent","arrow-fallback");
        }
        String ranged=string(c,"ranged","");boolean attack=flag(c,"attack"),shielding=flag(c,"shield");String kind=string(c,"kind","");
        Location sonLook=null;
        UhcTools.Route blockedMelee=null;
        if(son&&uhc.isEmpty()&&attack&&ranged.isEmpty()&&!shielding&&a.lastDispatchTick!=tick){
            var range=p.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
            double allowed=Math.min(3,range==null?3:range.getValue());
            if(reach(p,target)<=allowed){
                sonLook=sonMeleeLook(p.getEyeLocation(),target.getBoundingBox(),allowed);
                if(sonLook==null){
                    blockedMelee=UhcTools.recoverBlockedMelee(a,target,tick,allowed);
                    uhc=blockedMelee.action();attack=false;
                }
            }
        }
        boolean mining=uhc.startsWith("web-cut")||uhc.equals("web-blocked")||uhc.startsWith("wall-cut")||uhc.equals("wall-blocked")
            ||uhc.startsWith("upper-web-cut")||uhc.equals("upper-web-blocked");
        if(a.name.equals("WaveDogSon")&&!(mining&&uhc.endsWith("-cutting")))UhcTools.stopMining(a);
        boolean utility=mining||Set.of("crit-shield","arrow-shield","ranged-shield").contains(uhc);
        boolean appleMovement=uhc.equals("apple-retreat");
        boolean crossingWall=uhc.startsWith("wall-cross-");
        boolean wallHop=uhc.equals("wall-hop")||uhc.equals("wall-hop-travel")||crossingWall;
        boolean syncJump=uhc.equals("wall-sync-jump");
        if(wallHop){attack=false;ranged="";shielding=false;}
        if(utility){attack=false;ranged="";shielding=uhc.endsWith("-shield");}
        if(!ranged.isEmpty()&&!shielding)attack=false;
        boolean fatherApple=father&&CrystalActions.eatingApple(p);
        if(fatherApple&&utility){
            handle.stopUsingItem();var inventory=p.getInventory();var apples=inventory.getItemInOffHand();
            inventory.setItemInOffHand(inventory.getItem(4));inventory.setItem(4,apples);fatherApple=false;
        }else if(fatherApple){attack=false;ranged="";shielding=false;}
        if(p.hasActiveItem()&&(attack||!shielding)&&!fatherApple)handle.stopUsingItem();
        float runningYaw=p.getYaw(),runningPitch=p.getPitch();
        var crystalResult=father&&!utility?CrystalActions.execute(a,target,
            c.has("crystal")?velocity(target):null,tick):Map.of();
        boolean fatherMelee=Boolean.TRUE.equals(crystalResult.get("fatherMelee"));
        if(fatherMelee){
            c=c.deepCopy();
            c.addProperty("slot",0);
            c.addProperty("doubleAttack",false);
            c.addProperty("sprint",false);
            sonLook=sonMeleeLook(p.getEyeLocation(),target.getBoundingBox(),3);
            attack=sonLook!=null;
        }
        boolean holdBlast=crystalResult.containsKey("holdPosition");
        String blastWait=crystalResult.get("blastWait") instanceof String wait?wait:"";
        boolean waiting=!blastWait.isEmpty();
        if(blastWait.startsWith("blast-escape")){
            ranged="";
            shielding=false;
        }
        if(holdBlast||waiting||crystalResult.containsKey("anchorPriority")||crystalResult.containsKey("crystalMode"))attack=false;
        if(crystalResult.containsKey("crystalStruck")||crystalResult.containsKey("pearlThrown")
            ||crystalResult.containsKey("escapePearl")||mining||blastWait.endsWith("-cutting")){
            // The crystal or pearl action already used its authoritative aim.
        }else if(c.has("worldHeading")&&!c.get("worldHeading").isJsonNull()&&!flag(c,"keepTargetLook")){
            var h=c.getAsJsonObject("worldHeading");double hx=number(h,"x",0),hz=number(h,"z",0);
            if(Math.hypot(hx,hz)>.5)p.setRotation((float)Math.toDegrees(Math.atan2(-hx,hz)),0);
        }else if(c.has("arrowYaw")&&!c.get("arrowYaw").isJsonNull())p.setRotation((float)(180-Math.toDegrees(c.get("arrowYaw").getAsDouble())),0);
        else if(!flag(c,"keepLook"))aim(a,target,!ranged.isEmpty());
        double forward=number(c,"forward",0),side=number(c,"side",0);
        if(holdBlast){forward=0;side=0;}
        else if(crystalResult.get("anchorHeading") instanceof List<?> heading){
            double hx=((Number)heading.get(0)).doubleValue(),hz=((Number)heading.get(1)).doubleValue();
            forward=0;side=0;
            double length=Math.hypot(hx,hz);
            if(length>.01){p.setRotation((float)Math.toDegrees(Math.atan2(-hx,hz)),0);forward=Math.min(1,length);}
        }
        if(!holdBlast&&!crystalResult.containsKey("anchorHeading")&&c.has("worldHeading")&&!c.get("worldHeading").isJsonNull()){
            var h=c.getAsJsonObject("worldHeading");double hx=number(h,"x",0),hz=number(h,"z",0),yaw=Math.toRadians(p.getYaw());
            forward=-Math.sin(yaw)*hx+Math.cos(yaw)*hz;side=Math.cos(yaw)*hx+Math.sin(yaw)*hz;
        }
        if(utility){forward=0;side=0;if(shielding&&(!c.has("arrowYaw")||c.get("arrowYaw").isJsonNull()))aim(a,target,false);}
        String fatherTerrain=blastWait;
        if(father&&!waiting&&!holdBlast&&!attack){
            var route=UhcTools.crystalSelfEscape(a,target,tick);
            if(route!=null){
                fatherTerrain=route.action();var heading=route.heading();
                if(heading.lengthSquared()>.01)p.setRotation((float)Math.toDegrees(Math.atan2(-heading.getX(),heading.getZ())),0);
                forward=heading.lengthSquared()>.01?1:0;side=0;
            }
        }
        boolean fatherMining=fatherTerrain.endsWith("-cutting");
        if(father&&!fatherMining)UhcTools.stopMining(a);
        int slot=(int)number(c,"slot",p.getInventory().getHeldItemSlot());
        if(!utility&&!fatherMining&&!handle.handActionLocked()&&ranged.isEmpty()&&(slot==0||slot==7)&&slot!=p.getInventory().getHeldItemSlot()){
            handle.stopUsingItem();p.getInventory().setHeldItemSlot(slot);handle.resetAttackStrengthTicker();a.lastSwitchTick=tick;
        }
        boolean safetyRoute=false;
        if(son&&!utility){
            double yaw=Math.toRadians(p.getYaw());
            var desired=new Vector(-Math.sin(yaw)*forward+Math.cos(yaw)*side,0,Math.cos(yaw)*forward+Math.sin(yaw)*side);
            if(appleMovement){
                desired=UhcTools.appleEscapeHeading(a);
            }
            if(wallHop)desired=UhcTools.wallHopHeading(a);
            if(blockedMelee!=null)desired=blockedMelee.heading();
            boolean chase=blockedMelee==null&&!appleMovement&&!wallHop&&!attack&&!shielding&&!uhc.startsWith("arrow-")&&!uhc.startsWith("ranged-")
                &&!flag(c,"motionRetreat")&&(!p.hasLineOfSight(target)||syncJump||p.isOnGround()&&forward>.35);
            var around=chase?UhcTools.aroundWall(a,target,tick):null;
            if(around!=null){desired=around;if(uhc.isEmpty())uhc="wall-detour";}
            var route=crossingWall?null:UhcTools.steer(a,target,desired);
            if(route!=null||appleMovement||wallHop||around!=null||blockedMelee!=null){
                if(route!=null&&(uhc.isEmpty()||uhc.equals("arrow-dodge")))uhc=route.action();
                var h=route!=null?route.heading():desired;
                if(!attack&&h.lengthSquared()>.02){p.setRotation((float)Math.toDegrees(Math.atan2(-h.getX(),h.getZ())),0);yaw=Math.toRadians(p.getYaw());}
                forward=-Math.sin(yaw)*h.getX()+Math.cos(yaw)*h.getZ();side=Math.cos(yaw)*h.getX()+Math.sin(yaw)*h.getZ();
                safetyRoute=true;
            }
        }
        boolean sprint=!fatherMelee&&blockedMelee==null&&(flag(c,"sprint")||safetyRoute||waiting)
            &&forward>.5&&p.getFoodLevel()>6&&!shielding&&ranged.isEmpty();
        p.setSneaking(flag(c,"sneak"));p.setSprinting(sprint);
        boolean jump=(!father||fatherSword)&&!waiting&&!utility&&ranged.isEmpty()&&p.isOnGround()&&(syncJump||(uhc.equals("wall-hop")||uhc.equals("wall-cross-jump"))&&forward>.5
            ||!safetyRoute&&flag(c,"jump"));
        if(jump&&!wallHop&&!syncJump&&kind.equals("legacy86-close")&&reach(p,target)>2.5)jump=false;
        handle.setJumping(false);if(jump)handle.jumpFromGround();
        var rangedResult=new LinkedHashMap<String,Object>();
        if(shielding&&!p.hasCooldown(Material.SHIELD)&&offhand(a,Material.SHIELD)){
            if(!p.hasActiveItem())handle.gameMode.useItem(handle,handle.level(),handle.getOffhandItem(),InteractionHand.OFF_HAND);
        }else if(!ranged.isEmpty()&&offhand(a,Material.CROSSBOW)){
            boolean ready=loaded(p.getInventory().getItemInOffHand());
            if(ranged.equals("fire-crossbow")){
                if(ready){handle.releaseUsingItem();aim(a,target,true);handle.gameMode.useItem(handle,handle.level(),handle.getOffhandItem(),InteractionHand.OFF_HAND);rangedResult.put("fireSent",!loaded(p.getInventory().getItemInOffHand()));}
                else rangedResult.put("fireRejected","native-crossbow-not-loaded");
            }else if(ranged.equals("load-crossbow")){
                if(ready){handle.releaseUsingItem();rangedResult.put("loadReleased",true);}
                else if(!p.hasActiveItem()){
                    handle.gameMode.useItem(handle,handle.level(),handle.getOffhandItem(),InteractionHand.OFF_HAND);
                    rangedResult.put("useStarted",handle.usingExclusiveItem());
                    if(handle.usingExclusiveItem())handle.exclusiveUseTick=Bukkit.getCurrentTick();
                }
            }
        }else if(!shielding&&ranged.isEmpty()&&!a.name.equals("WaveDogBrother")&&!a.name.equals("WaveDogFather"))offhand(a,Material.SHIELD);
        var attacks=new ArrayList<Map<String,Object>>();
        if(attack&&a.lastDispatchTick!=tick){
            float beforeYaw=p.getYaw(),beforePitch=p.getPitch();
            if(flag(c,"critical"))p.setSprinting(false);
            if(!fatherMelee&&kind.equals("legacy86-ground")&&p.getFoodLevel()>6)p.setSprinting(true);
            try{
                attacks.add(strike(a,target,c,tick,sonLook));
                if(flag(c,"doubleAttack")&&a.active){var second=c.deepCopy();attacks.add(strike(a,target,second,tick,sonLook));
                    int returnSlot=(int)number(c,"stunReturnSlot",0);
                    if(returnSlot!=7)returnSlot=0;
                    if(p.getInventory().getHeldItemSlot()!=returnSlot){p.getInventory().setHeldItemSlot(returnSlot);handle.resetAttackStrengthTicker();a.lastSwitchTick=tick;}}
            }finally{
                if(flag(c,"keepLook")||!flag(c,"keepTargetLook"))p.setRotation(beforeYaw,beforePitch);
                // Vanilla consumes sprint on a knockback hit. Restore the
                // selected route's sprint only AFTER the attack and aim restore,
                // so a rear intercept does not turn recovery into a walk.
                if(kind.equals("legacy86-ground")&&sprint&&!jump&&!p.hasActiveItem()&&p.getFoodLevel()>6)
                    p.setSprinting(true);
            }
        }
        if(attack&&flag(c,"reblockAfterAttack")&&!p.hasCooldown(Material.SHIELD)&&offhand(a,Material.SHIELD)){
            if(!p.hasActiveItem())handle.gameMode.useItem(handle,handle.level(),handle.getOffhandItem(),InteractionHand.OFF_HAND);
        }
        // Use-item changes above must slow movement in this very tick too.
        float scale=(p.hasActiveItem()?.2f:1f)*(p.isSneaking()?.3f:1f);
        handle.zza=(float)Math.clamp(forward,-1,1)*scale;handle.xxa=(float)Math.clamp(side,-1,1)*scale;
        var actual=new LinkedHashMap<String,Object>();actual.put("attacked",attacks.stream().anyMatch(r->Boolean.TRUE.equals(r.get("attempted"))));
        actual.put("attacks",attacks);actual.put("rangedResult",rangedResult);actual.put("held",p.getInventory().getHeldItemSlot());
        if(!crystalResult.isEmpty())actual.put("crystalResult",crystalResult);
        if(!uhc.isEmpty())actual.put("uhcAction",uhc);
        if(!fatherTerrain.isEmpty())actual.put("fatherTerrain",fatherTerrain);
        if(son&&(uhc.contains("water")||uhc.contains("lava")||p.getFireTicks()>0))actual.put("uhcBuckets",UhcTools.bucketSlots(p));
        if(son&&(p.isInLava()||p.getFireTicks()>0))actual.put("uhcFire",Map.of("inLava",p.isInLava(),"fireTicks",p.getFireTicks(),
            "inWater",p.isInWater(),"bucketAttempt",UhcTools.bucketAttempt(a)));
        actual.put("sprint",p.isSprinting());actual.put("jump",jump);actual.put("shield",p.isBlocking());actual.put("using",p.hasActiveItem());
        actual.put("physicsTick",handle.lastPhysicsTick);
        actual.put("forward",handle.zza);actual.put("side",handle.xxa);return actual;
    }

    static boolean keepSonShotShield(Material active,int shotAge,String action,JsonObject fallback){
        return active==Material.SHIELD&&shotAge>=0&&shotAge<=2&&(action.isEmpty()
            ||action.equals("arrow-fallback")&&(fallback==null||flag(fallback,"shield")));
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void fatherBlockPlaced(BlockPlaceEvent e){
        var actor=actors.get("WaveDogFather");
        boolean opponent=actor!=null&&e.getPlayer().getName().equals(actor.opponent);
        if(actor!=null&&actor.active&&e.canBuild()&&e.getBlockReplacedState().getType().isAir()
            &&(e.getPlayer()==actor.player()||opponent))
            CrystalActions.placed(actor,e.getBlockPlaced(),opponent,Bukkit.getCurrentTick());
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void uhcWater(PlayerBucketEmptyEvent e){
        var son=actors.get("WaveDogSon");
        if(son==null||!son.active||!e.getPlayer().getName().equals(son.opponent))return;
        if(e.getBucket()==Material.WATER_BUCKET)UhcTools.waterPlaced(son,e.getBlock());
        else if(e.getBucket()==Material.LAVA_BUCKET)UhcTools.enemyLavaPlaced(son,e.getBlock());
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true) public void uhcBucketFill(PlayerBucketFillEvent e){checkUhcBucket(e);}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true) public void uhcBucketEmpty(PlayerBucketEmptyEvent e){checkUhcBucket(e);}
    @EventHandler(priority=EventPriority.LOWEST) public void allowArenaBucket(PlayerBucketEmptyEvent e){
        var son=actors.get("WaveDogSon");
        // Paper initially cancels buckets under spawn protection. The arena's
        // own guard still validates the active match and its temporary blocks.
        if(e.isCancelled()&&son!=null&&son.player()==e.getPlayer()&&UhcTools.arenaBucketInSpawn(son,e))e.setCancelled(false);
    }
    private void checkUhcBucket(PlayerBucketEvent e){
        var son=actors.get("WaveDogSon");
        if(son!=null&&son.active&&son.player()==e.getPlayer()&&!UhcTools.acceptsBucket(son,e))e.setCancelled(true);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void pearlLand(PlayerTeleportEvent e){
        if(e.getCause()!=PlayerTeleportEvent.TeleportCause.ENDER_PEARL)return;
        Actor father=actors.get("WaveDogFather");
        if(father!=null&&father.active&&father.player()==e.getPlayer())CrystalActions.pearlLanded(father);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void shot(EntityShootBowEvent e){
        for(var a:actors.values())if(a.active&&e.getEntity().getName().equals(a.opponent)){
            a.shotEvent++;a.shotTick=Bukkit.getCurrentTick();a.shotWeapon=e.getBow()!=null&&e.getBow().getType()==Material.CROSSBOW?"crossbow":"bow";
        }
    }
    @EventHandler(priority=EventPriority.MONITOR) public void swing(PlayerAnimationEvent e){for(var a:actors.values())if(a.active&&e.getPlayer().getName().equals(a.opponent))a.lastSwing=Bukkit.getCurrentTick();}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!sender.isOp())return true;
        try{
            String action=args.length==0?"status":args[0];
            if(action.equals("fixture")){
                if(!Boolean.getBoolean("wavedog.native.fixture"))throw new IllegalStateException("Native mechanics fixture is disabled on this server");
                fixture=args.length>1&&args[1].equals("sprint-jump")?new NativeSprintJumpProbe(this):new NativeMechanicsProbe(this);
                if(args.length>1&&args[1].equals("advanced")){fixture.elapsed=599;fixture.advancedOnly=true;}
                sender.sendMessage("Isolated native mechanics fixture started.");
            }
            else if(action.equals("capture")){for(var a:actors.values())capture(a);sender.sendMessage("Native identities captured; existing clients unchanged.");}
            else if(action.equals("spawn")){for(var a:actors.values())spawn(a);getConfig().set("enabled",true);saveConfig();sender.sendMessage("Native actors spawned; no duel started.");}
            else if(action.equals("reload-policy")){
                if(args.length!=2||!args[1].matches("[0-9a-f]{64}"))throw new IllegalArgumentException("reload-policy requires a complete managed SHA-256");
                for(var a:actors.values()){
                    if(a.active||a.loading)throw new IllegalStateException("Actor is busy: "+a.name);
                    var referee=Bukkit.getPluginManager().getPlugin(a.coreName);
                    for(String key:List.of("active","preparing","learning")){
                        var flag=referee.getClass().getDeclaredField(key);flag.setAccessible(true);
                        if(flag.getBoolean(referee))throw new IllegalStateException("Referee is busy: "+a.name+" / "+key);
                    }
                }
                String previousDirectory=getConfig().getString("policy-directory","");
                var directory=ROOT.resolve("work/wavedog-native/policies").resolve(args[1]);
                NativePolicy next=null;
                try{
                    getConfig().set("policy-directory",directory.toString());next=new NativePolicy(this);
                    for(var a:actors.values())if(a.opponent!=null)next.reset(a.name,a.opponent);
                }catch(Throwable error){if(next!=null)next.close();getConfig().set("policy-directory",previousDirectory);throw error;}
                var before=policy;policy=next;policySha=args[1];saveConfig();
                for(var a:actors.values()){hold(a);a.refreshQueued=false;heartbeat(a);}
                before.close();sender.sendMessage("Native policy reloaded: "+policySha+"; no duel started.");
            }
            else if(action.equals("despawn")){
                if(actors.values().stream().anyMatch(a->a.active||a.loading))throw new IllegalStateException("Cannot remove an active or persisting actor");
                getConfig().set("enabled",false);saveConfig();
                for(var a:actors.values())if(a.handle!=null){hold(a);if(Bukkit.getPlayerExact(a.name)==a.player()&&!a.handle.isRemoved())MinecraftServer.getServer().getPlayerList().remove(a.handle);a.handle=null;}
                sender.sendMessage("Native actors removed; protocol rollback is available.");
            }
            else if(action.equals("restart-speech")){
                if(!getConfig().getBoolean("dialogue-enabled",false))throw new IllegalStateException("Perception speech is disabled in config");
                if(dialogue!=null){dialogue.close();dialogue=null;}
                dialogue=new PerceptionDialogueBridge(this);
                sender.sendMessage("Perception speech worker restarted; combat actors stayed online.");
            }
            else if(action.equals("teach")||action.equals("quiet")){
                if(!(sender instanceof Player teacher))throw new IllegalArgumentException("Teach from your player account during your duel");
                if(action.equals("teach")&&args.length<4||action.equals("quiet")&&args.length!=2)
                    throw new IllegalArgumentException("Use /wdnative teach <bot> <intent> <phrase> or /wdnative quiet <bot>");
                Actor target=null;
                for(var actor:actors.values())if(actor.name.equalsIgnoreCase(args[1])
                    ||actor.name.equalsIgnoreCase("WaveDog"+args[1])){target=actor;break;}
                boolean preparing=target!=null&&target.player()!=null
                    &&target.player().hasMetadata("wavedog-preparation-cage")
                    &&target.lastAimTick-Bukkit.getCurrentTick()>20;
                if(target==null||!target.active&&!preparing||target.match==null||!teacher.getName().equals(target.opponent))
                    throw new IllegalStateException("You must be fighting that bot to teach it");
                String phrase=action.equals("teach")?String.join(" ",Arrays.copyOfRange(args,3,args.length)):"";
                if(phrase.length()>40||phrase.chars().anyMatch(Character::isISOControl))
                    throw new IllegalArgumentException("Phrase must be at most 40 characters on one line");
                String intent=action.equals("teach")?args[2]:"silence";
                Path feedback=ROOT.resolve("outputs/pvp-perception-language/live-feedback.jsonl");
                Files.createDirectories(feedback.getParent());
                Files.writeString(feedback,JSON.toJson(Map.of("id",UUID.randomUUID().toString(),
                    "teacher",teacher.getName(),"speaker",target.name,"matchId",target.match,
                    "intent",intent,"phrase",phrase,"tick",Bukkit.getCurrentTick(),
                    "submittedAt",System.currentTimeMillis()))+"\n",StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,StandardOpenOption.APPEND);
                sender.sendMessage("Teaching example queued for "+target.name+". The speech model will check the PvP event before learning.");
            }
            else sender.sendMessage(JSON.toJson(Map.of("backend","server-native","failed",failed,"decisions",decisions,"lastMs",lastNanos/1e6,"peakMs",peakNanos/1e6,"policySha256",policySha,
                "actors",actors.values().stream().map(a->Map.of("name",a.name,"native",a.handle!=null&&Bukkit.getPlayerExact(a.name)==a.player()&&!a.handle.isRemoved(),"active",a.active,"persisting",a.loading,"frames",a.loggedFrames+a.frames.size(),
                    "playerClass",a.handle==null?"":a.handle.getClass().getName(),"uuid",a.handle==null?"":a.player().getUniqueId().toString())).toList())));
        }catch(Exception e){sender.sendMessage("Native command failed: "+e);getLogger().log(java.util.logging.Level.WARNING,"Native command failed",e);}
        return true;
    }
}
