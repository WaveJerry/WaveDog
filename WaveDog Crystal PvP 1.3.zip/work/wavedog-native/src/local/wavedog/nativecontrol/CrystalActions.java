package local.wavedog.nativecontrol;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.entity.*;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Candidate analysis and ordinary player interactions for Father. */
final class CrystalActions {
    private static final int FLOOR=221;
    private static final String TAG="wavedog-father-crystal";
    private static final Map<NativeControl.Actor,Bout> BOUTS=new WeakHashMap<>();
    private static final BlockFace[] SIDES={BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST};
    private static final BlockFace[] SUPPORTS={BlockFace.DOWN,BlockFace.NORTH,BlockFace.SOUTH,BlockFace.WEST,BlockFace.EAST,BlockFace.UP};
    private static final double[][] TOP_AIMS={{.5,.5},{.12,.12},{.12,.88},{.88,.12},{.88,.88}};

    private static final class Bout {
        final String match;
        final Set<Block> placedBlocks=new LinkedHashSet<>();
        final Set<Block> opponentObsidian=new HashSet<>();
        int decidedTick=-1,pearlUntil=-1,pearlRetry=-1,escapePearlUntil=-1;
        boolean hold;
        UhcTools.Route waitRoute;
        int appleReturnSlot=-1,appleCount;
        Block pendingAnchor,failedAnchor,opponentAnchor,lastShelterAnchor,shelterFoot;
        Block sealedHead;
        int pendingUntil,retryAnchorAt,opponentAnchorUntil;
        Location shelterStand;
        int shelterCheckAt,shelterFollowUntil,shelterSealedAt;
        Vec3 shelterPressure,firingAnchor;
        int shelterPressureUntil;
        Vec3 lastRetreatedBlast;
        int retreatUntil=-1,retreatReadyAt=-1,retreatSeenAt=-1,counterUntil=-1;
        Block shelterDefenseCover;
        Location shelterFlank;
        Bout(String match){this.match=match;}
    }
    private record Click(Location aim,BlockHitResult hit){}
    private record CrystalHit(EnderCrystal crystal,Location look,BlastDamage.Score score){}
    private record PearlLanding(Location position,Location impact,int ticks){}
    private record PursuitPearl(Location look,PearlLanding landing,Block blast,boolean anchor,float score){}
    private record BlastThreat(Vec3 origin,boolean anchor,float damage,boolean placed){}
    private record BlastRun(Vector heading,float damage){}
    private record EscapePearl(Location look,PearlLanding landing,float damage){}
    private record ShelterAnchor(Block anchor,Block cover,BlastDamage.Score damage){}
    private record ShelterPearl(Location look,PearlLanding landing,ShelterAnchor attack,double score){}

    static boolean arenaColumn(Location p){
        return p.getWorld().getName().equals("world")&&p.getX()>=992&&p.getX()<1037
            &&p.getZ()>=992&&p.getZ()<1037;
    }
    private static boolean inside(Location p){
        return arenaColumn(p)&&p.getY()>=FLOOR&&p.getY()<225;
    }
    static boolean combatCell(Location p){
        var world=p.getWorld();
        if(arenaColumn(p))return inside(p);
        return p.getBlockY()>=world.getMinHeight()&&p.getBlockY()<world.getMaxHeight()
            &&world.isChunkLoaded(p.getBlockX()>>4,p.getBlockZ()>>4);
    }
    static Map<String,Object> observation(NativeControl.Actor actor,Player opponent,int tick){
        var p=actor.player();int totems=0;
        for(var item:p.getInventory().getContents())if(item!=null&&item.getType()==Material.TOTEM_OF_UNDYING)totems+=item.getAmount();
        boolean arena=inside(p.getLocation())&&inside(opponent.getLocation());
        boolean anchor=anchorReady(actor);
        boolean crystal=amount(p,2,Material.END_CRYSTAL)>0;
        var bout=BOUTS.get(actor);
        boolean pending=bout!=null&&Objects.equals(actor.match,bout.match)&&tick<=bout.pendingUntil
            &&bout.pendingAnchor!=null&&bout.pendingAnchor.getBlockData() instanceof RespawnAnchor charged
            &&(charged.getCharges()>0||amount(p,6,Material.GLOWSTONE)>0);
        boolean activeGround=combatCell(p.getLocation())&&combatCell(opponent.getLocation());
        return Map.of("inArena",arena,"anchorReady",anchor,"crystalReady",crystal,"totems",totems,
            "swordOnly",activeGround&&!crystal&&!anchor&&!pending);
    }
    static boolean enclosed(Location feet){
        var world=feet.getWorld();
        var body=feet.clone().add(0,.6,0);
        int walls=coverSides(world,body);
        if(walls>=3)return true;
        if(feet.getY()>FLOOR+.4&&feet.getY()<=FLOOR+1.3){
            var atFloor=body.clone();atFloor.setY(FLOOR+.6);
            if(coverSides(world,atFloor)>=3)return true;
        }
        return walls>=2&&world.rayTraceBlocks(feet.clone().add(0,1.65,0),
            new Vector(0,1,0),1.25,FluidCollisionMode.NEVER,true)!=null;
    }
    private static int coverSides(World world,Location body){
        int walls=0;
        for(BlockFace side:SIDES)
            if(world.rayTraceBlocks(body,side.getDirection(),1.7,FluidCollisionMode.NEVER,true)!=null)walls++;
        return walls;
    }
    private static Bout bout(NativeControl.Actor actor){
        var current=BOUTS.get(actor);
        if(current==null||!Objects.equals(actor.match,current.match)){
            current=new Bout(actor.match);
            BOUTS.put(actor,current);
        }
        return current;
    }
    static boolean arenaDebris(Block block){
        return combatCell(block.getLocation())&&switch(block.getType()){
            case OBSIDIAN,GLOWSTONE,RESPAWN_ANCHOR -> true;
            default -> false;
        };
    }
    static void placed(NativeControl.Actor actor,Block block,boolean opponent,int tick){
        if(!arenaDebris(block))return;
        var bout=bout(actor);
        bout.placedBlocks.add(block);
        if(block.getType()==Material.OBSIDIAN){
            if(opponent)bout.opponentObsidian.add(block);
            else bout.opponentObsidian.remove(block);
        }
        if(opponent&&block.getType()==Material.RESPAWN_ANCHOR){
            bout.opponentAnchor=block;
            bout.opponentAnchorUntil=tick+10;
        }
    }
    static void incomingAnchorHit(NativeControl.Actor actor,Location location,int tick){
        var bout=bout(actor);
        var point=new Vec3(location.getX(),location.getY(),location.getZ());
        if(!point.equals(bout.firingAnchor)){
            rememberPressure(bout,point,tick);
            bout.counterUntil=tick+45;
        }
    }
    private static void rememberPressure(Bout bout,Vec3 origin,int tick){
        if(bout.shelterPressure==null||bout.shelterPressure.distanceToSqr(origin)>2.25)bout.shelterFlank=null;
        bout.shelterPressure=origin;
        bout.shelterPressureUntil=tick+75;
    }

    private static boolean anchorReady(NativeControl.Actor actor){
        var p=actor.player();return amount(p,5,Material.RESPAWN_ANCHOR)>0&&amount(p,6,Material.GLOWSTONE)>0
            &&!RespawnAnchorBlock.canSetSpawn(actor.handle.level(),position(p.getLocation().getBlock()));
    }

    static void pearlLanded(NativeControl.Actor actor){
        Bout bout=BOUTS.get(actor);
        if(bout==null||!Objects.equals(bout.match,actor.match))return;
        if(bout.escapePearlUntil>=0){bout.escapePearlUntil=-1;return;}
        bout.pearlUntil=-1;
        bout.decidedTick=-1;
    }

    static boolean equipTotem(Player player){
        var inventory=player.getInventory();
        if(!inventory.getItemInOffHand().getType().isAir())return false;
        int slot=inventory.first(Material.TOTEM_OF_UNDYING);
        if(slot<0)return false;
        var totem=inventory.getItem(slot);
        inventory.setItem(slot,null);inventory.setItemInOffHand(totem);
        return true;
    }

    private static Vec3 center(Block block,double y){return new Vec3(block.getX()+.5,block.getY()+y,block.getZ()+.5);}
    private static List<Integer> coordinates(Block block){return block==null?List.of():List.of(block.getX(),block.getY(),block.getZ());}
    private static boolean emptyPlacement(Block block){
        if(!combatCell(block.getLocation())||!block.getType().isAir())return false;
        return block.getWorld().getNearbyEntities(new org.bukkit.util.BoundingBox(block.getX(),block.getY(),block.getZ(),
            block.getX()+1,block.getY()+1,block.getZ()+1),e->e instanceof LivingEntity||e instanceof EnderCrystal).isEmpty();
    }
    private static boolean canPlace(Block block){
        return block.getRelative(BlockFace.DOWN).getType().isSolid()&&emptyPlacement(block);
    }
    private static double range(Player player){return Objects.requireNonNull(player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE)).getValue();}
    private static Click aimBlock(Player player,Block block,boolean top){
        return aimBlock(player.getEyeLocation(),range(player),block,top,null);
    }
    private static Click aimBlock(Location eye,double range,Block block,boolean top,Block cover){
        if(!top){
            var side=aimBlock(eye,range,block,.5,.5,.5,false,cover);
            if(side!=null)return side;
        }
        for(var offset:TOP_AIMS){
            var click=aimBlock(eye,range,block,offset[0],.999,offset[1],top,cover);
            if(click!=null)return click;
        }
        return null;
    }
    private static Click aimBlock(Location eye,double range,Block block,double x,double y,double z,boolean top,Block cover){
        var spot=block.getLocation().add(x,y,z);
        if(cover!=null&&blocksRay(eye,cover,new Vec3(spot.getX(),spot.getY(),spot.getZ())))return null;
        var aim=eye.clone().setDirection(spot.toVector().subtract(eye.toVector()));
        var hit=eye.getWorld().rayTraceBlocks(eye,aim.getDirection(),range,FluidCollisionMode.NEVER,true);
        if(hit==null||!block.equals(hit.getHitBlock())||top&&hit.getHitBlockFace()!=BlockFace.UP)return null;
        var at=hit.getHitPosition();var face=hit.getHitBlockFace();
        var faceNms=Direction.valueOf(face.name());
        return new Click(aim,new BlockHitResult(new Vec3(at.getX(),at.getY(),at.getZ()),faceNms,position(block),false));
    }
    private static Click placementClick(Location eye,double reach,Block cell,Block cover,Block second){
        return placementClick(eye,reach,cell,cover,second,false);
    }
    private static Click placementClick(Location eye,double reach,Block cell,Block cover,Block second,boolean allowAnchorSupport){
        for(BlockFace side:SUPPORTS){
            Block support=cell.getRelative(side);
            if(!support.getType().isSolid()||!allowAnchorSupport&&support.getType()==Material.RESPAWN_ANCHOR)continue;
            var face=side.getOppositeFace();
            for(var sample:TOP_AIMS){
                double x=side.getModX()!=0?.5-side.getModX()*.499:sample[0];
                double y=side.getModY()!=0?.5-side.getModY()*.499:sample[1];
                double z=side.getModZ()!=0?.5-side.getModZ()*.499:side.getModX()!=0?sample[0]:sample[1];
                if(second!=null&&blocksRay(eye,second,new Vec3(support.getX()+x,support.getY()+y,support.getZ()+z)))continue;
                var click=aimBlock(eye,reach,support,x,y,z,false,cover);
                if(click!=null&&click.hit().getDirection().name().equals(face.name()))return click;
            }
        }
        return null;
    }
    private static boolean place(NativeControl.Actor actor,int slot,Material material,Block cell){
        Player player=actor.player();
        return emptyPlacement(cell)&&click(actor,slot,material,
            placementClick(player.getEyeLocation(),range(player),cell,null,null))==1&&cell.getType()==material;
    }
    private static BlockPos position(Block b){return new BlockPos(b.getX(),b.getY(),b.getZ());}
    private static Vec3 eye(Player player){var l=player.getEyeLocation();return new Vec3(l.getX(),l.getY(),l.getZ());}
    private static boolean blocksRay(Location start,Block cover,Vec3 target){
        var cube=BlastDamage.cube(cover);var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        return cube.contains(eye)||cube.clip(eye,target).isPresent();
    }
    private static int amount(Player player,int slot,Material expected){
        var item=player.getInventory().getItem(slot);
        return item!=null&&item.getType()==expected?item.getAmount():0;
    }
    private static int click(NativeControl.Actor actor,int slot,Material material,Block block,boolean top){
        return click(actor,slot,material,aimBlock(actor.player(),block,top));
    }
    private static int click(NativeControl.Actor actor,int slot,Material material,Click aim){
        Player player=actor.player();var inv=player.getInventory();int before=amount(player,slot,material);
        if(aim==null||before==0||player.getGameMode()!=GameMode.SURVIVAL||player.hasCooldown(material))return 0;
        int previous=inv.getHeldItemSlot();inv.setHeldItemSlot(slot);player.setRotation(aim.aim().getYaw(),aim.aim().getPitch());
        try{actor.handle.gameMode.useItemOn(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND,aim.hit());}
        finally{inv.setHeldItemSlot(previous);}
        return before-amount(player,slot,material);
    }

    static boolean safeAttack(BlastDamage.Score score,Player player,Player opponent){
        return score.worthwhile(player,opponent)&&!urgentBlast(score.self(),effectiveHealth(player));
    }

    private static Block select(Player player,Player opponent,boolean anchor,Block excluded){
        return select(player,opponent,anchor,excluded,player.getLocation(),opponent.getLocation());
    }
    private static Block select(Player player,Player opponent,boolean anchor,Block excluded,Location own,Location enemy){
        var start=own.clone().add(0,player.getEyeHeight(),0);
        var eye=new Vec3(start.getX(),start.getY(),start.getZ());
        var world=player.getWorld();
        var ownBox=player.getBoundingBox().clone().shift(own.toVector().subtract(player.getLocation().toVector()));
        var enemyBox=opponent.getBoundingBox().clone().shift(enemy.toVector().subtract(opponent.getLocation().toVector()));
        double reach=range(player);
        int radius=anchor?2:1;
        boolean arena=arenaColumn(own);
        int bottom=arena?(anchor?FLOOR:FLOOR-1):Math.max(world.getMinHeight(),own.getBlockY()-2);
        int top=arena?(anchor?224:Math.min(223,Math.max(own.getBlockY(),enemy.getBlockY())))
            :Math.min(world.getMaxHeight()-1,own.getBlockY()+3);
        var candidates=new LinkedHashSet<Block>();
        for(int y=bottom;y<=top;y++){
            for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++)
                candidates.add(world.getBlockAt(enemy.getBlockX()+dx,y,enemy.getBlockZ()+dz));
            for(var side:SIDES)for(int distance=1;distance<=3;distance++)
                candidates.add(world.getBlockAt(own.getBlockX()+side.getModX()*distance,y,own.getBlockZ()+side.getModZ()*distance));
        }
        Block best=null;
        float value=0;
        for(var block:candidates){
            if(block.equals(excluded)||eye.distanceToSqr(center(block,.5))>(reach+1)*(reach+1))continue;
            boolean readyBase=!anchor&&(block.getType()==Material.OBSIDIAN||block.getType()==Material.BEDROCK);
            if(!combatCell(block.getLocation())&&!(readyBase&&block.getY()==FLOOR-1&&arenaColumn(block.getLocation())))continue;
            Block hypotheticalBase=null;
            if(anchor){
                if(!emptyPlacement(block)||ownBox.overlaps(BoundingBox.of(block))||enemyBox.overlaps(BoundingBox.of(block))
                    ||placementClick(start,reach,block,null,null)==null)continue;
            }else{
                var below=block.getRelative(BlockFace.DOWN);
                if(readyBase){
                    if(aimBlock(start,reach,block,false,null)==null)continue;
                }else{
                    if(amount(player,1,Material.OBSIDIAN)==0||!canPlace(block)||ownBox.overlaps(BoundingBox.of(block))
                        ||enemyBox.overlaps(BoundingBox.of(block))
                        ||aimBlock(start,reach,below,true,null)==null)continue;
                    hypotheticalBase=block;
                }
                var spawn=block.getRelative(BlockFace.UP);
                var cube=BlastDamage.cube(spawn).expandTowards(0,1,0);
                var entitySpace=new BoundingBox(cube.minX,cube.minY,cube.minZ,cube.maxX,cube.maxY,cube.maxZ);
                var crystalBox=new BoundingBox(cube.minX-.5,cube.minY,cube.minZ-.5,cube.maxX+.5,cube.maxY,cube.maxZ+.5);
                if(!spawn.getType().isAir()||enemyBox.overlaps(entitySpace)||ownBox.overlaps(entitySpace)
                    ||!world.getNearbyEntities(entitySpace).isEmpty()
                    ||NativeControl.sonMeleeLook(start,crystalBox,3)==null)continue;
            }
            var score=BlastDamage.estimate(player,opponent,center(block,anchor?.5:1),anchor,hypotheticalBase,own,enemy);
            if(safeAttack(score,player,opponent)&&score.value()>value){best=block;value=score.value();}
        }
        return best;
    }

    private static boolean finishAnchor(NativeControl.Actor actor,Player opponent,Block anchor,BlastDamage.Score score,
                                        Map<String,Object> receipt){
        return finishAnchor(actor,opponent,anchor,score,receipt,false);
    }

    private static boolean finishAnchor(NativeControl.Actor actor,Player opponent,Block anchor,BlastDamage.Score score,
                                        Map<String,Object> receipt,boolean footAnchor){
        var player=actor.player();
        if(!(anchor.getBlockData() instanceof RespawnAnchor data))return false;
        if(footAnchor&&hurtImmune(opponent))return false;
        if(!anchorDamageAllowed(score,player,opponent,footAnchor))return false;
        if(data.getCharges()==0){
            if(click(actor,6,Material.GLOWSTONE,anchor,false)!=1)return false;
            receipt.put("glowstoneConsumed",1);
            score=BlastDamage.estimate(player,opponent,center(anchor,.5),true,null);
        }
        if(!(anchor.getBlockData() instanceof RespawnAnchor charged)||charged.getCharges()==0)return false;
        if(!anchorDamageAllowed(score,player,opponent,footAnchor))return false;
        receipt.put("anchorDamage",Map.of("self",score.self(),"target",score.target(),"charge",charged.getCharges()));
        var bout=bout(actor);
        bout.firingAnchor=center(anchor,.5);
        try{click(actor,0,Material.NETHERITE_SWORD,anchor,false);}
        finally{bout.firingAnchor=null;}
        if(anchor.getType()==Material.RESPAWN_ANCHOR)return false;
        receipt.put("anchorDetonated",true);return true;
    }

    private static boolean anchorDamageAllowed(BlastDamage.Score score,Player player,Player opponent,boolean footAnchor){
        return footAnchor?score.self()<effectiveHealth(player):safeAttack(score,player,opponent);
    }

    private static boolean hurtImmune(Player opponent){
        return opponent.getNoDamageTicks()>opponent.getMaximumNoDamageTicks()/2;
    }

    private static CrystalHit scoreCrystal(Player player,Player opponent,EnderCrystal crystal){
        if(crystal.isDead()||NativeControl.reach(player,crystal)>3)return null;
        var at=crystal.getLocation();var score=BlastDamage.estimate(player,opponent,new Vec3(at.getX(),at.getY(),at.getZ()),false,null);
        if(!safeAttack(score,player,opponent))return null;
        Location start=player.getEyeLocation(),look=NativeControl.sonMeleeLook(start,crystal.getBoundingBox(),3);
        if(look==null)return null;
        RayTraceResult ray=player.getWorld().rayTraceEntities(start,look.getDirection(),3,0,
            entity->entity!=player&&entity.isValid()&&(entity instanceof LivingEntity||entity instanceof EnderCrystal));
        if(ray==null||ray.getHitEntity()!=crystal)return null;
        var obstruction=player.getWorld().rayTraceBlocks(start,look.getDirection(),ray.getHitPosition().distance(start.toVector()),FluidCollisionMode.NEVER,true);
        return obstruction==null?new CrystalHit(crystal,look,score):null;
    }
    private static boolean hitCrystal(NativeControl.Actor actor,CrystalHit hit,int tick,Map<String,Object> receipt){
        if(hit==null||actor.lastDispatchTick==tick)return false;
        Player player=actor.player();actor.lastDispatchTick=tick;
        player.setRotation(hit.look().getYaw(),hit.look().getPitch());player.swingMainHand();player.attack(hit.crystal());
        receipt.put("crystalDamage",Map.of("self",hit.score().self(),"target",hit.score().target()));
        if(!hit.crystal().isDead()&&hit.crystal().isValid())return false;
        receipt.put("crystalStruck",true);return true;
    }

    private static boolean throwPearl(NativeControl.Actor actor,Location look){
        Player player=actor.player();
        int before=amount(player,7,Material.ENDER_PEARL);
        if(before==0||player.hasCooldown(Material.ENDER_PEARL))return false;
        var inventory=player.getInventory();
        int previous=inventory.getHeldItemSlot();
        inventory.setHeldItemSlot(7);
        player.setRotation(look.getYaw(),look.getPitch());
        try{
            actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND);
        }finally{
            inventory.setHeldItemSlot(previous);
        }
        return amount(player,7,Material.ENDER_PEARL)==before-1;
    }

    private static PearlLanding predictPearl(NativeControl.Actor actor,Player opponent,Location look){
        var self=actor.player();var level=actor.handle.level();
        Vec3 start=eye(self).subtract(0,.1,0);
        var direction=look.getDirection();var momentum=actor.handle.getDeltaMovement();
        Vec3 speed=new Vec3(direction.getX(),direction.getY(),direction.getZ()).scale(1.5)
            .add(momentum.x,self.isOnGround()?0:momentum.y,momentum.z);
        var enemy=opponent.getBoundingBox();
        var target=new AABB(enemy.getMinX(),enemy.getMinY(),enemy.getMinZ(),enemy.getMaxX(),enemy.getMaxY(),enemy.getMaxZ()).inflate(.35);
        for(int tick=0;tick<12;tick++){
            speed=speed.subtract(0,.03,0);var end=start.add(speed);
            var hit=level.clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,actor.handle));
            if(target.contains(start)||target.clip(start,hit.getLocation()).isPresent())return null;
            if(hit.getType()!=HitResult.Type.MISS){
                var p=hit.getLocation();var landing=new Location(self.getWorld(),start.x,start.y,start.z);
                if(hit.getDirection()!=Direction.UP||!combatCell(landing)||landing.getY()-p.y>1.5
                    ||!landing.getBlock().isPassable()||!landing.clone().add(0,1,0).getBlock().isPassable())return null;
                return new PearlLanding(landing,new Location(self.getWorld(),p.x,p.y+.001,p.z),tick+1);
            }
            start=end;speed=speed.scale(.99);
        }
        return null;
    }
    private static boolean pursuitPearl(NativeControl.Actor actor,Player opponent,Bout bout,Vector velocity,
                                         boolean anchor,boolean crystal,int tick,Map<String,Object> receipt){
        var player=actor.player();
        if(tick<bout.pearlRetry||amount(player,7,Material.ENDER_PEARL)==0
            ||player.hasCooldown(Material.ENDER_PEARL)||player.getLocation().distanceSquared(opponent.getLocation())<=9)return false;
        bout.pearlRetry=tick+8;
        var plan=planPursuitPearl(actor,opponent,velocity,anchor,crystal);
        if(plan==null||!throwPearl(actor,plan.look()))return false;
        bout.pearlUntil=tick+plan.landing().ticks()+4;
        var at=plan.landing().position();
        receipt.put("pearlThrown",true);
        receipt.put("pearlMode",plan.anchor()?"anchor":"crystal");
        receipt.put("pearlPlan",Map.of("landing",List.of(at.getX(),at.getY(),at.getZ()),
            "flightTicks",plan.landing().ticks(),"blast",coordinates(plan.blast())));
        hold(bout,receipt);
        return true;
    }

    private static PursuitPearl planPursuitPearl(NativeControl.Actor actor,Player opponent,Vector velocity,
                                                  boolean anchor,boolean crystal){
        var player=actor.player();
        var own=player.getLocation();
        var target=opponent.getLocation();
        var eye=player.getEyeLocation();
        var approach=own.toVector().subtract(target.toVector()).setY(0);
        if(approach.lengthSquared()<.01)return null;
        approach.normalize();
        float pearlCost=BlastDamage.pearlDamage(player);
        if(pearlCost>=effectiveHealth(player))return null;
        PursuitPearl bestCrystal=null,bestAnchor=null;
        var enemy=((CraftPlayer)opponent).getHandle();
        var motion=velocity==null?opponent.getVelocity():velocity;
        for(int angle:new int[]{0,55,-55,95,-95,145,-145}){
            var goal=target.clone().add(approach.clone().rotateAroundY(Math.toRadians(angle)).multiply(3.15));
            if(!combatCell(goal)||eye.distanceSquared(goal)<1)continue;
            var look=eye.clone().setDirection(goal.toVector().subtract(eye.toVector()));
            var landing=predictPearl(actor,opponent,look);
            if(landing==null||!UhcTools.crystalEscapeLanding(player,landing.position())
                ||!UhcTools.crystalEscapeLanding(player,landing.impact()))continue;
            var delta=new Vec3(motion.getX(),opponent.isOnGround()?0:motion.getY(),motion.getZ()).scale(Math.min(4,landing.ticks()));
            if(delta.lengthSqr()>2.25)delta=delta.normalize().scale(1.5);
            var travel=net.minecraft.world.entity.Entity.collideBoundingBox(enemy,delta,enemy.getBoundingBox(),enemy.level(),List.of());
            var projected=target.clone().add(travel.x,travel.y,travel.z);
            double distance=landing.position().distanceSquared(projected);
            if(!combatCell(projected)||distance<4||distance>25||own.distanceSquared(landing.position())<1)continue;
            for(boolean useAnchor:new boolean[]{true,false}){
                if(useAnchor?!anchor:!crystal)continue;
                var base=select(player,opponent,useAnchor,null,landing.position(),projected);
                if(base==null)continue;
                Block newBase=(!useAnchor&&base.getType().isAir())?base:null;
                var damage=BlastDamage.estimate(player,opponent,center(base,useAnchor?.5:1),useAnchor,newBase,
                    landing.position(),projected);
                if(damage.self()+pearlCost>=effectiveHealth(player))continue;
                float score=damage.value()-pearlCost-.15f*landing.ticks();
                var plan=new PursuitPearl(look,landing,base,useAnchor,score);
                if(useAnchor){
                    if(bestAnchor==null||score>bestAnchor.score())bestAnchor=plan;
                }else if(bestCrystal==null||score>bestCrystal.score())bestCrystal=plan;
            }
        }
        return bestCrystal!=null?bestCrystal:bestAnchor;
    }

    private static BlastThreat blastThreat(Player player,Player opponent,Bout bout,int tick){
        if(!combatCell(player.getLocation())||player.getWorld()!=opponent.getWorld()
            ||player.getLocation().distanceSquared(opponent.getLocation())>256)return null;
        var feet=opponent.getLocation().getBlock();
        var wielding=opponent.getInventory().getItemInMainHand().getType();
        boolean loading=wielding==Material.GLOWSTONE||opponent.getInventory().getItemInOffHand().getType()==Material.GLOWSTONE;
        BlastThreat best=null;
        var world=player.getWorld();
        var level=((CraftPlayer)player).getHandle().level();
        var enemyEye=opponent.getEyeLocation();
        var ownEye=eye(player);
        double reach=range(opponent);
        int search=(int)Math.min(6,Math.ceil(reach));
        int bottom=Math.max(world.getMinHeight(),feet.getY()-search);
        int top=Math.min(world.getMaxHeight()-1,feet.getY()+search);
        if(arenaColumn(feet.getLocation())){bottom=Math.max(FLOOR,bottom);top=Math.min(224,top);}
        var cursor=new BlockPos.MutableBlockPos();
        for(int dx=-search;dx<=search;dx++)for(int dz=-search;dz<=search;dz++)for(int y=bottom;y<=top;y++){
            int x=feet.getX()+dx,z=feet.getZ()+dz;
            var state=level.getBlockState(cursor.set(x,y,z));
            if(!(state.getBlock() instanceof RespawnAnchorBlock)||RespawnAnchorBlock.canSetSpawn(level,cursor))continue;
            var b=world.getBlockAt(x,y,z);
            if(state.getValue(RespawnAnchorBlock.CHARGE)==0&&!loading
                &&!(tick<=bout.opponentAnchorUntil&&b.equals(bout.opponentAnchor)))continue;
            if(!combatCell(b.getLocation()))continue;
            var point=center(b,.5);
            if(ownEye.distanceToSqr(point)>121)continue;
            float damage=BlastDamage.exposureDamage(player,point,true,null);
            if((best==null||damage>best.damage())
                &&aimBlock(enemyEye,reach,b,false,null)!=null)best=new BlastThreat(point,true,damage,true);
        }
        for(var entity:opponent.getNearbyEntities(4,4,4))if(entity instanceof EnderCrystal crystal&&NativeControl.reach(opponent,crystal)<=3){
            var at=crystal.getLocation();
            var point=new Vec3(at.getX(),at.getY(),at.getZ());
            if(ownEye.distanceToSqr(point)>169)continue;
            float damage=BlastDamage.exposureDamage(player,point,false,null);
            if((best==null||damage>best.damage())
                &&NativeControl.sonMeleeLook(enemyEye,crystal.getBoundingBox(),3)!=null)best=new BlastThreat(point,false,damage,true);
        }
        if(best==null&&(wielding==Material.RESPAWN_ANCHOR
            ||opponent.getInventory().getItemInOffHand().getType()==Material.RESPAWN_ANCHOR)){
            var hit=world.rayTraceBlocks(enemyEye,enemyEye.getDirection(),reach,FluidCollisionMode.NEVER,true);
            if(hit!=null&&hit.getHitBlock()!=null&&hit.getHitBlockFace()!=null){
                var intended=hit.getHitBlock().getRelative(hit.getHitBlockFace());
                if(!RespawnAnchorBlock.canSetSpawn(level,position(intended))&&emptyPlacement(intended)){
                    var point=center(intended,.5);
                    float damage=BlastDamage.exposureDamage(player,point,true,null);
                    best=new BlastThreat(point,true,damage,false);
                }
            }
        }
        return best;
    }

    static boolean urgentBlast(float damage,double health){
        return damage>0&&(damage>=4||damage>=health);
    }
    private static Vector awayFromBlast(Player player,Player opponent,BlastThreat threat){
        var away=player.getLocation().toVector().subtract(new Vector(threat.origin().x,0,threat.origin().z)).setY(0);
        if(away.lengthSquared()<.01)away=player.getLocation().toVector().subtract(opponent.getLocation().toVector()).setY(0);
        return away.lengthSquared()<.01?new Vector(0,0,1):away.normalize();
    }

    private static BlastRun blastRun(Player player,Player opponent,BlastThreat threat,boolean eating){
        var start=player.getLocation();
        var away=awayFromBlast(player,opponent,threat);
        BlastRun best=null;
        float bestScore=threat.damage();
        for(int angle:new int[]{0,30,-30,60,-60,90,-90,135,-135,180}){
            var heading=away.clone().rotateAroundY(Math.toRadians(angle));
            double step=eating?.45:.8;
            var next=start.clone().add(heading.clone().multiply(step));
            if(!UhcTools.crystalEscapePath(player,next))continue;
            float near=BlastDamage.exposureDamage(player,threat.origin(),threat.anchor(),null,next);
            if(near>threat.damage()+.05f)continue;
            var further=start.clone().add(heading.clone().multiply(step*2));
            float far=UhcTools.crystalEscapePath(player,further)?
                BlastDamage.exposureDamage(player,threat.origin(),threat.anchor(),null,further):near;
            float score=.6f*near+.4f*far;
            if(score<bestScore-.05f){best=new BlastRun(heading,far);bestScore=score;}
        }
        return best;
    }

    private static EscapePearl escapePearl(NativeControl.Actor actor,Player opponent,BlastThreat threat){
        var player=actor.player();
        if(amount(player,7,Material.ENDER_PEARL)==0||player.hasCooldown(Material.ENDER_PEARL))return null;
        float pearlCost=BlastDamage.pearlDamage(player);
        double health=effectiveHealth(player);
        if(pearlCost>=health)return null;
        var start=player.getLocation();
        var eye=player.getEyeLocation();
        var away=awayFromBlast(player,opponent,threat);
        EscapePearl best=null;
        double bestScore=Double.POSITIVE_INFINITY;
        for(int angle:new int[]{0,35,-35,70,-70,110,-110,180})for(double length:new double[]{5,8}){
            var goal=start.clone().add(away.clone().rotateAroundY(Math.toRadians(angle)).multiply(length));
            goal.setY((arenaColumn(goal)?FLOOR:start.getBlockY())+.02);
            if(!combatCell(goal))continue;
            var look=eye.clone().setDirection(goal.toVector().subtract(eye.toVector()));
            var landing=predictPearl(actor,opponent,look);
            if(landing==null||landing.ticks()>7||start.distanceSquared(landing.position())<4
                ||!UhcTools.crystalEscapeLanding(player,landing.position())
                ||!UhcTools.crystalEscapeLanding(player,landing.impact()))continue;
            float damage=pearlCost+Math.max(
                BlastDamage.exposureDamage(player,threat.origin(),threat.anchor(),null,landing.position()),
                BlastDamage.exposureDamage(player,threat.origin(),threat.anchor(),null,landing.impact()));
            double score=damage+.20*landing.ticks();
            if(damage<health&&damage<threat.damage()-.75f&&score<bestScore){
                best=new EscapePearl(look,landing,damage);
                bestScore=score;
            }
        }
        return best;
    }

    static Vector appleBlastHeading(NativeControl.Actor actor,Player opponent){
        var player=actor.player();
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        var threat=blastThreat(player,opponent,bout(actor),Bukkit.getCurrentTick());
        var route=threat==null||!urgentBlast(threat.damage(),effectiveHealth(player))?null:blastRun(player,opponent,threat,true);
        if(route!=null)return route.heading();
        if(own.distanceSquared(enemy)<=25&&player.hasLineOfSight(opponent))
            return UhcTools.crystalReposition(player,opponent,true,0);
        return new Vector();
    }

    private static boolean emergencyDefense(NativeControl.Actor actor,Player opponent,Bout bout,BlastThreat threat,int tick,
                                            Map<String,Object> receipt){
        var player=actor.player();
        if(threat!=null&&!urgentBlast(threat.damage(),effectiveHealth(player)))threat=null;
        if(threat==null&&tick>bout.escapePearlUntil)return false;
        var run=threat==null?null:blastRun(player,opponent,threat,false);
        if(threat!=null&&!threat.placed()&&run==null&&tick>bout.escapePearlUntil)return false;
        UhcTools.stopMining(actor);
        if(threat!=null){
            receipt.put("incomingBlast",Map.of("type",threat.anchor()?"anchor":"crystal","damage",threat.damage(),
                "origin",List.of(threat.origin().x,threat.origin().y,threat.origin().z),"placed",threat.placed()));
        }
        if(threat!=null&&threat.placed()&&tick>bout.escapePearlUntil&&tick>bout.pearlUntil
            &&(run==null||urgentBlast(run.damage(),effectiveHealth(player)))){
            var pearl=escapePearl(actor,opponent,threat);
            if(pearl!=null&&throwPearl(actor,pearl.look())){
                bout.escapePearlUntil=tick+pearl.landing().ticks()+4;
                var land=pearl.landing().position();
                receipt.put("escapePearl",Map.of("landing",List.of(land.getX(),land.getY(),land.getZ()),
                    "flightTicks",pearl.landing().ticks(),"damage",pearl.damage()));
            }
        }
        String action=tick<=bout.escapePearlUntil?"blast-escape-pearl":run==null?"blast-escape-blocked":"blast-escape-run";
        bout.waitRoute=new UhcTools.Route(run==null?new Vector():run.heading(),action);
        waitReceipt(bout,receipt);
        return true;
    }

    private static boolean briefBlastRetreat(NativeControl.Actor actor,Player opponent,Bout bout,BlastThreat threat,int tick,
                                             Map<String,Object> receipt){
        if(threat==null||!threat.placed()||threat.damage()<=1.5)return false;
        if(tick>=bout.retreatReadyAt&&(tick>bout.retreatSeenAt+2||!threat.origin().equals(bout.lastRetreatedBlast))){
            bout.lastRetreatedBlast=threat.origin();
            bout.retreatUntil=tick+1;
            bout.retreatReadyAt=tick+7;
            bout.counterUntil=tick+45;
        }
        bout.retreatSeenAt=tick;
        if(tick>bout.retreatUntil)return false;
        var run=blastRun(actor.player(),opponent,threat,false);
        if(run==null||run.damage()>=effectiveHealth(actor.player()))return false;
        UhcTools.stopMining(actor);
        receipt.put("incomingBlast",Map.of("type",threat.anchor()?"anchor":"crystal","damage",threat.damage(),
            "origin",List.of(threat.origin().x,threat.origin().y,threat.origin().z),"placed",true));
        return stepRoute(bout,new UhcTools.Route(run.heading(),"blast-escape-step"),receipt);
    }

    private static Block pressureCover(NativeControl.Actor actor,Bout bout,Vec3 origin,int tick,Map<String,Object> receipt){
        var player=actor.player();
        if(!player.isOnGround()||amount(player,1,Material.OBSIDIAN)==0
            ||bout.shelterDefenseCover!=null&&bout.shelterDefenseCover.getType()==Material.OBSIDIAN)return null;
        var own=player.getLocation();
        var direction=new Vector(origin.x-own.getX(),0,origin.z-own.getZ());
        if(direction.lengthSquared()<1)return null;
        direction.normalize();
        var eye=player.getEyeLocation();
        double reach=range(player);
        float best=BlastDamage.exposureDamage(player,origin,true,null);
        if(best<3)return null;
        Block choice=null;
        for(double distance:new double[]{.85,1.3,1.8})for(int turn:new int[]{0,24,-24}){
            var cell=own.clone().add(direction.clone().rotateAroundY(Math.toRadians(turn)).multiply(distance)).getBlock();
            if(!canPlace(cell)||!emptyPlacement(cell)||placementClick(eye,reach,cell,null,null)==null)continue;
            float damage=BlastDamage.exposureDamage(player,origin,true,cell);
            if(damage<best-1&&damage<3&&damage<effectiveHealth(player)){
                best=damage;
                choice=cell;
            }
        }
        if(choice==null)return null;
        UhcTools.stopMining(actor);
        if(!place(actor,1,Material.OBSIDIAN,choice))return null;
        bout.shelterDefenseCover=choice;
        bout.shelterCheckAt=tick;
        receipt.put("siegeDefenseCover",coordinates(choice));
        return choice;
    }

    private static UhcTools.Route pressureFlank(Player player,Player opponent,Bout bout,Vec3 origin){
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        var across=own.toVector().subtract(enemy.toVector()).setY(0);
        if(across.lengthSquared()<1)return null;
        across.normalize();
        float currentDamage=BlastDamage.exposureDamage(player,origin,true,null);
        double best=Double.POSITIVE_INFINITY;
        for(int turn:new int[]{45,-45,65,-65,25,-25}){
            var direction=across.clone().rotateAroundY(Math.toRadians(turn));
            var stand=enemy.clone().add(direction.multiply(4.55));
            stand.setY(own.getY());
            double distance=own.distanceSquared(stand);
            if(distance<.7||distance>64||!UhcTools.crystalEscapePath(player,stand))continue;
            var targetBox=stand.clone().add(0,player.getEyeHeight(),0);
            if(!combatCell(targetBox))continue;
            float at=BlastDamage.exposureDamage(player,origin,true,null,stand);
            if(at>currentDamage+.65||at>=3.25||at>=effectiveHealth(player))continue;
            var halfway=own.clone().add(stand.toVector().subtract(own.toVector()).multiply(.5));
            float routeDamage=BlastDamage.exposureDamage(player,origin,true,null,halfway);
            if(routeDamage>Math.max(3.25,currentDamage+.75))continue;
            double score=2*at+routeDamage+.28*Math.sqrt(distance);
            if(score<best){bout.shelterFlank=stand;best=score;}
        }
        return bout.shelterFlank==null?null:shelterWalk(own,bout.shelterFlank);
    }

    private static boolean stepRoute(Bout bout,UhcTools.Route route,Map<String,Object> receipt){
        if(route==null)return false;
        bout.waitRoute=route;
        waitReceipt(bout,receipt);
        return true;
    }

    static Map<String,Object> execute(NativeControl.Actor actor,Player opponent,Vector velocity,int tick){
        Player player=actor.player();
        if(player.getGameMode()!=GameMode.SURVIVAL||player.getWorld()!=opponent.getWorld())return Map.of();
        Bout bout=bout(actor);
        if(bout.decidedTick==tick){
            if(bout.waitRoute!=null){var repeat=new LinkedHashMap<String,Object>();waitReceipt(bout,repeat);return repeat;}
            return bout.hold?Map.of("holdPosition",true):Map.of();
        }
        bout.decidedTick=tick;bout.hold=false;bout.waitRoute=null;
        var receipt=new LinkedHashMap<String,Object>();
        restoreAppleSlot(player,bout,receipt);
        restockObsidian(player);
        if(equipTotem(player))receipt.put("totemEquipped",true);
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        if(!combatCell(own)||!combatCell(enemy))return receipt;
        double distance=own.distanceSquared(enemy);
        boolean anchor=anchorReady(actor);
        boolean crystal=amount(player,2,Material.END_CRYSTAL)>0;
        var head=opponent.getEyeLocation().getBlock();
        boolean opponentSheltering=distance<=144&&(opponentInCover(opponent,bout)||head.equals(bout.sealedHead));
        boolean anchorCover=anchor&&opponentSheltering;
        var existingFoot=opponentSheltering?existingFootAnchor(actor,opponent):null;
        boolean criticalHeal=effectiveHealth(player)<=8&&canStartApple(actor);
        if(!criticalHeal&&opponentSheltering&&headRingClosed(head)&&existingFoot!=null
            &&useExistingFootAnchor(actor,opponent,existingFoot,tick,receipt))return receipt;
        var threat=blastThreat(player,opponent,bout,tick);
        if(anchorCover&&threat!=null&&threat.anchor()&&threat.placed()&&threat.damage()>1.5){
            rememberPressure(bout,threat.origin(),tick);
        }
        if(briefBlastRetreat(actor,opponent,bout,threat,tick,receipt))return receipt;
        if(anchorCover&&threat!=null&&threat.anchor()&&threat.placed()
            &&urgentBlast(threat.damage(),effectiveHealth(player))
            &&pressureCover(actor,bout,threat.origin(),tick,receipt)!=null){
            float damage=BlastDamage.exposureDamage(player,threat.origin(),true,null);
            threat=new BlastThreat(threat.origin(),true,damage,true);
        }
        if(emergencyDefense(actor,opponent,bout,threat,tick,receipt))return receipt;
        if(receipt.containsKey("siegeDefenseCover")){hold(bout,receipt);return receipt;}
        if(tick<=bout.pearlUntil){hold(bout,receipt);return receipt;}
        bout.pearlUntil=-1;

        if(criticalHeal&&startApple(actor,bout,receipt))return receipt;
        var pressure=anchorCover&&tick<=bout.shelterPressureUntil?bout.shelterPressure:null;
        if(!opponentSheltering){
            bout.shelterStand=null;bout.shelterCheckAt=0;bout.lastShelterAnchor=null;bout.shelterFlank=null;
            bout.shelterFoot=null;bout.sealedHead=null;
        }
        if(distance<=64){
            if(opponentSheltering&&(anchor||existingFoot!=null)){
                if(!headRingClosed(head)){
                    closeHeadRing(actor,bout,head,tick,receipt);
                    return receipt;
                }
                bout.sealedHead=head;
                if(existingFoot!=null&&hurtImmune(opponent)){
                    hold(bout,receipt);
                    return receipt;
                }
                if(anchor&&siegeAnchor(actor,opponent,bout,tick,pressure,receipt))return receipt;
                if(existingFoot!=null){
                    stepRoute(bout,UhcTools.crystalPursuit(player,opponent),receipt);
                    return receipt;
                }
            }
            var existing=bestCrystal(player,opponent);
            if(existing!=null){
                UhcTools.stopMining(actor);
                if(hitCrystal(actor,existing,tick,receipt)){
                    receipt.put("crystalMode",true);hold(bout,receipt);return receipt;
                }
            }
            var base=crystal?select(player,opponent,false,null):null;
            if(base!=null){
                UhcTools.stopMining(actor);
                if(spawnCrystal(actor,opponent,base,tick,receipt)){
                    receipt.put("crystalMode",true);hold(bout,receipt);return receipt;
                }
            }
            if(!anchorCover&&tryAnchor(actor,opponent,bout,tick,anchor,receipt))return receipt;
        }
        if(anchorCover&&distance>64&&tick<=bout.counterUntil
            &&shelterPearl(actor,opponent,bout,tick,pressure,shelterAnchorCells(enemy),receipt))return receipt;
        if(!anchor&&!crystal){
            startApple(actor,bout,receipt);
            return receipt;
        }
        if(anchorCover&&stepRoute(bout,UhcTools.crystalPursuit(player,opponent),receipt))return receipt;
        if(distance<=9&&reachSword(player,opponent)){
            UhcTools.stopMining(actor);
            receipt.put("fatherMelee",true);
            return receipt;
        }
        if(distance>=36&&player.getHealth()<player.getMaxHealth()-1&&startApple(actor,bout,receipt))return receipt;
        if(distance<=144&&pursuitPearl(actor,opponent,bout,velocity,anchor,crystal,tick,receipt))return receipt;
        UhcTools.Route route=UhcTools.clearCrystalOpening(actor,opponent,bout.placedBlocks,false);
        if(route==null)route=UhcTools.crystalPursuit(player,opponent);
        if(route==null){
            var around=UhcTools.aroundWall(actor,opponent,tick);
            if(around!=null)route=new UhcTools.Route(around,"crystal-detour");
        }
        if(route==null){
            var offset=UhcTools.crystalReposition(player,opponent,false,tick/12);
            if(offset.lengthSquared()>.01)route=new UhcTools.Route(offset,"crystal-angle");
        }
        stepRoute(bout,route,receipt);
        return receipt;
    }

    private static boolean opponentInCover(Player opponent,Bout bout){
        var feet=opponent.getLocation();
        var roof=opponent.getWorld().rayTraceBlocks(feet.clone().add(0,opponent.getHeight(),0),
            new Vector(0,1,0),1.15,FluidCollisionMode.NEVER,true);
        if(roof!=null&&roof.getHitBlock()!=null&&roof.getHitBlock().getType()!=Material.BARRIER)return true;
        if(bout.opponentObsidian.isEmpty())return false;
        int sides=0;
        for(var face:SIDES){
            var side=feet.getBlock().getRelative(face);
            for(int height=0;height<=1;height++){
                var wall=side.getRelative(BlockFace.UP,height);
                if(wall.getType()!=Material.OBSIDIAN||!bout.opponentObsidian.contains(wall))continue;
                if(++sides==2)return true;
                break;
            }
        }
        return false;
    }

    private static boolean headRingClosed(Block head){
        for(var side:SIDES)if(!head.getRelative(side).getType().isOccluding())return false;
        return true;
    }

    private static Block ringPlacement(Location eye,double reach,Block wall){
        if(!emptyPlacement(wall))return null;
        if(placementClick(eye,reach,wall,null,null,true)!=null)return wall;
        var support=wall.getRelative(BlockFace.DOWN);
        return canPlace(support)&&placementClick(eye,reach,support,null,null)!=null?support:null;
    }

    private static void closeHeadRing(NativeControl.Actor actor,Bout bout,Block head,int tick,Map<String,Object> receipt){
        var player=actor.player();
        var eye=player.getEyeLocation();
        var own=player.getLocation();
        double reach=range(player);
        var walls=new ArrayList<Block>();
        for(var side:SIDES)if(!head.getRelative(side).getType().isOccluding())walls.add(head.getRelative(side));
        walls.sort(Comparator.comparingDouble((Block wall)->wall.getLocation().add(.5,.5,.5).distanceSquared(eye)).reversed());
        var placed=new ArrayList<List<Integer>>();
        UhcTools.stopMining(actor);
        boolean sneaking=player.isSneaking();
        try{
            player.setSneaking(true);
            for(var wall:walls){
                if(amount(player,1,Material.OBSIDIAN)==0)break;
                var cell=ringPlacement(eye,reach,wall);
                if(cell==null)continue;
                if(click(actor,1,Material.OBSIDIAN,placementClick(eye,reach,cell,null,null,true))!=1
                    ||cell.getType()!=Material.OBSIDIAN)continue;
                placed.add(coordinates(cell));
                if(!cell.equals(wall)&&emptyPlacement(wall)&&amount(player,1,Material.OBSIDIAN)>0
                    &&click(actor,1,Material.OBSIDIAN,placementClick(eye,reach,wall,null,null,true))==1
                    &&wall.getType()==Material.OBSIDIAN)placed.add(coordinates(wall));
            }
        }finally{player.setSneaking(sneaking);}
        if(!placed.isEmpty())receipt.put("shelterHeadBlocks",placed);
        if(headRingClosed(head)){
            bout.sealedHead=head;
            bout.shelterSealedAt=tick;
            receipt.put("shelterHeadSealed",coordinates(head));
            hold(bout,receipt);
            return;
        }
        Location next=null;
        double best=Double.POSITIVE_INFINITY;
        if(amount(player,1,Material.OBSIDIAN)>0){
            var center=head.getLocation().add(.5,0,.5);
            for(var side:SUPPORTS){
                if(side.getModY()!=0)continue;
                var direction=side.getDirection();
                for(int angle:new int[]{0,45}){
                    var stand=center.clone().add(direction.clone().rotateAroundY(Math.toRadians(angle)).multiply(3.25));
                    stand.setY(own.getY());
                    double distance=stand.distanceSquared(own);
                    if(distance<.16||distance>=best||!UhcTools.crystalEscapePath(player,stand))continue;
                    var projectedEye=stand.clone().add(0,player.getEyeHeight(),0);
                    if(walls.stream().anyMatch(wall->!wall.getType().isOccluding()&&ringPlacement(projectedEye,reach,wall)!=null)){
                        next=stand;best=distance;
                    }
                }
            }
        }
        if(next!=null){stepRoute(bout,shelterWalk(own,next),receipt);return;}
        hold(bout,receipt);
    }

    private static boolean siegeAnchor(NativeControl.Actor actor,Player opponent,Bout bout,int tick,Vec3 pressure,
                                       Map<String,Object> receipt){
        var player=actor.player();
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        if(sealAndOpenFoot(actor,opponent,bout,tick,receipt))return true;
        if(hurtImmune(opponent)){
            hold(bout,receipt);
            return true;
        }
        var options=shelterAnchorCells(enemy);
        var plan=shelterAnchorAt(player,opponent,own,options,bout.failedAnchor,tick<bout.retryAnchorAt);
        if(plan!=null){
            UhcTools.stopMining(actor);
            bout.shelterStand=null;
            if(plan.cover()!=null){
                if(receipt.containsKey("siegeDefenseCover")||!place(actor,1,Material.OBSIDIAN,plan.cover()))return false;
                receipt.put("anchorBlastCover",coordinates(plan.cover()));
            }
            if(attackAnchor(actor,opponent,bout,tick,plan.anchor(),receipt)){
                recordShelterBlast(bout,plan.anchor(),own,tick,receipt);
                return true;
            }
        }
        if(finishPendingAnchor(actor,opponent,bout,tick,receipt))return true;
        if(tick<=bout.counterUntil&&shelterPearl(actor,opponent,bout,tick,pressure,options,receipt))return true;

        if(bout.shelterFlank!=null){
            var flank=bout.shelterFlank;
            if(pressure!=null&&own.distanceSquared(flank)>.25&&flank.distanceSquared(enemy)<=49
                &&UhcTools.crystalEscapePath(player,flank))return stepRoute(bout,shelterWalk(own,flank),receipt);
            bout.shelterFlank=null;
        }
        if(pressure!=null&&BlastDamage.exposureDamage(player,pressure,true,null)>=3){
            if(!receipt.containsKey("siegeDefenseCover")&&pressureCover(actor,bout,pressure,tick,receipt)!=null){
                hold(bout,receipt);
                return true;
            }
            var flank=pressureFlank(player,opponent,bout,pressure);
            if(flank==null){
                var threat=new BlastThreat(pressure,true,BlastDamage.exposureDamage(player,pressure,true,null),true);
                var retreat=blastRun(player,opponent,threat,false);
                if(retreat!=null)flank=new UhcTools.Route(retreat.heading(),"shelter-anchor-flank");
            }
            UhcTools.stopMining(actor);
            if(stepRoute(bout,flank,receipt))return true;
            hold(bout,receipt);
            return true;
        }

        if(bout.shelterStand!=null){
            if(own.distanceSquared(bout.shelterStand)>.12&&bout.shelterStand.distanceSquared(enemy)<=36
                &&UhcTools.crystalEscapePath(player,bout.shelterStand))
                return stepRoute(bout,shelterWalk(own,bout.shelterStand),receipt);
            if(tick<=bout.shelterFollowUntil&&bout.lastShelterAnchor!=null
                &&own.distanceSquared(bout.shelterStand)<=.12
                &&bout.lastShelterAnchor.getLocation().add(.5,.5,.5).distanceSquared(enemy)<=6.25){
                hold(bout,receipt);
                return true;
            }
            bout.shelterStand=null;
        }
        if(player.isOnGround()&&own.distanceSquared(enemy)<=30.25&&tick>=bout.shelterCheckAt){
            bout.shelterCheckAt=tick+5;
            var away=own.toVector().subtract(enemy.toVector()).setY(0);
            if(away.lengthSquared()<.01)away=new Vector(0,0,1);
            away.normalize();
            for(int turn:new int[]{0,35,-35,65,-65}){
                var stand=enemy.clone().add(away.clone().rotateAroundY(Math.toRadians(turn)).multiply(3.65));
                stand.setY(own.getY());
                if(own.distanceSquared(stand)<.45||own.distanceSquared(stand)>9
                    ||!UhcTools.crystalEscapePath(player,stand)
                    ||pressure!=null&&BlastDamage.exposureDamage(player,pressure,true,null,stand)>=3
                    ||shelterAnchorAt(player,opponent,stand,options,bout.failedAnchor,tick<bout.retryAnchorAt)==null)continue;
                bout.shelterStand=stand;
                UhcTools.stopMining(actor);
                return stepRoute(bout,shelterWalk(own,stand),receipt);
            }
        }
        return stepRoute(bout,UhcTools.clearCrystalOpening(actor,opponent,bout.placedBlocks,true),receipt);
    }

    private static boolean besideFeet(Block block,Block feet){
        return block.getY()==feet.getY()
            &&Math.abs(block.getX()-feet.getX())+Math.abs(block.getZ()-feet.getZ())<=1;
    }

    private static Block existingFootAnchor(NativeControl.Actor actor,Player opponent){
        var player=actor.player();
        var feet=opponent.getLocation().getBlock();
        var cells=new ArrayList<Block>();
        cells.add(feet);
        for(var side:SIDES)cells.add(feet.getRelative(side));
        for(var cell:cells){
            if(!(cell.getBlockData() instanceof RespawnAnchor data)
                ||RespawnAnchorBlock.canSetSpawn(actor.handle.level(),position(cell))
                ||data.getCharges()==0&&amount(player,6,Material.GLOWSTONE)==0)continue;
            return cell;
        }
        return null;
    }

    private static boolean useExistingFootAnchor(NativeControl.Actor actor,Player opponent,Block cell,int tick,
                                                  Map<String,Object> receipt){
        if(hurtImmune(opponent))return false;
        var player=actor.player();
        if(aimBlock(player,cell,false)==null)return false;
        var damage=BlastDamage.estimate(player,opponent,center(cell,.5),true,null);
        if(!anchorDamageAllowed(damage,player,opponent,true))return false;
        UhcTools.stopMining(actor);
        if(!finishAnchor(actor,opponent,cell,damage,receipt,true))return false;
        receipt.put("existingFootAnchor",coordinates(cell));
        recordShelterBlast(bout(actor),cell,player.getLocation(),tick,receipt);
        return true;
    }

    private static boolean sealAndOpenFoot(NativeControl.Actor actor,Player opponent,Bout bout,int tick,
                                           Map<String,Object> receipt){
        var player=actor.player();
        var eye=player.getEyeLocation();
        var feet=opponent.getLocation().getBlock();
        var block=bout.shelterFoot;
        if(block!=null&&!besideFeet(block,feet)){
            UhcTools.stopMining(actor);
            block=null;
            bout.shelterFoot=null;
        }
        if(block==null){
            double bestDistance=Double.POSITIVE_INFINITY;
            for(var side:SIDES){
                var candidate=feet.getRelative(side);
                if(!bout.placedBlocks.contains(candidate)||!arenaDebris(candidate)
                    ||candidate.getType()==Material.RESPAWN_ANCHOR||aimBlock(player,candidate,false)==null)continue;
                var point=center(candidate,.5);
                double distance=eye.toVector().distanceSquared(new Vector(point.x,point.y,point.z));
                if(distance<bestDistance){bestDistance=distance;block=candidate;}
            }
            if(block==null)return false;
        }
        if(block.getType()==Material.RESPAWN_ANCHOR)return false;
        if(!block.getType().isAir()){
            var route=UhcTools.mineShelterFoot(actor,block,bout.placedBlocks);
            if(route==null){
                if(!player.isOnGround()&&block.equals(bout.shelterFoot)&&tick<=bout.shelterSealedAt+8){
                    hold(bout,receipt);
                    return true;
                }
                bout.shelterFoot=null;
                return false;
            }
            bout.shelterFoot=block;
            if(!route.action().equals("shelter-foot-cut"))return stepRoute(bout,route,receipt);
            receipt.put("shelterFootOpened",coordinates(block));
        }
        if(bout.shelterFoot==null||!emptyPlacement(block))return false;
        if(hurtImmune(opponent)){
            hold(bout,receipt);
            return true;
        }
        var own=player.getLocation();
        var origin=center(block,.5);
        var away=own.toVector().subtract(new Vector(origin.x,own.getY(),origin.z));
        if(away.lengthSquared()>=.01&&own.distanceSquared(new Location(own.getWorld(),origin.x,origin.y,origin.z))<6.25){
            var stand=own.clone().add(away.normalize().multiply(.85));
            if(UhcTools.crystalEscapePath(player,stand)&&placementClick(stand.clone().add(0,player.getEyeHeight(),0),
                range(player),block,null,null)!=null)return stepRoute(bout,shelterWalk(own,stand),receipt);
            return false;
        }
        var damage=BlastDamage.estimate(player,opponent,origin,true,null);
        if(!anchorDamageAllowed(damage,player,opponent,true))return false;
        if(!damage.enoughTargetDamage(opponent)){
            if(!block.equals(bout.lastShelterAnchor)||tick>bout.shelterFollowUntil)return false;
            hold(bout,receipt);
            return true;
        }
        if(!place(actor,5,Material.RESPAWN_ANCHOR,block))return false;
        receipt.put("anchorConsumed",1);
        receipt.put("anchorPlacement",Map.of("anchor",coordinates(block)));
        damage=BlastDamage.estimate(player,opponent,origin,true,null);
        if(!finishAnchor(actor,opponent,block,damage,receipt,true)){hold(bout,receipt);return true;}
        recordShelterBlast(bout,block,player.getLocation(),tick,receipt);
        return true;
    }

    private static void recordShelterBlast(Bout bout,Block block,Location stand,int tick,Map<String,Object> receipt){
        receipt.put("shelterAnchor",true);
        receipt.put("anchorPriority",true);
        bout.lastShelterAnchor=block;
        bout.shelterStand=stand;
        bout.shelterFollowUntil=tick+10;
        hold(bout,receipt);
    }

    private static boolean shelterPearl(NativeControl.Actor actor,Player opponent,Bout bout,int tick,Vec3 pressure,
                                        List<Block> options,Map<String,Object> receipt){
        var player=actor.player();
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        if(tick<bout.pearlRetry||!player.isOnGround()||own.distanceSquared(enemy)<16
            ||amount(player,7,Material.ENDER_PEARL)==0||player.hasCooldown(Material.ENDER_PEARL))return false;
        bout.pearlRetry=tick+8;
        float cost=BlastDamage.pearlDamage(player);
        double health=effectiveHealth(player);
        if(cost>=health-1)return false;
        var eye=player.getEyeLocation();
        var approach=own.toVector().subtract(enemy.toVector()).setY(0).normalize();
        boolean liveAnchor=pressure!=null
            &&new Location(own.getWorld(),pressure.x,pressure.y,pressure.z).getBlock().getType()==Material.RESPAWN_ANCHOR;
        ShelterPearl best=null;
        for(int turn:new int[]{55,-55,80,-80,110,-110,25,-25}){
            var goal=enemy.clone().add(approach.clone().rotateAroundY(Math.toRadians(turn)).multiply(3.45));
            goal.setY(player.getLocation().getBlockY()+.02);
            if(!combatCell(goal)||goal.distanceSquared(own)<3)continue;
            var look=eye.clone().setDirection(goal.toVector().subtract(eye.toVector()));
            var landing=predictPearl(actor,opponent,look);
            if(landing==null||own.distanceSquared(landing.position())<3
                ||!UhcTools.crystalEscapeLanding(player,landing.position())
                ||!UhcTools.crystalEscapeLanding(player,landing.impact()))continue;
            float incoming=pressure==null?0:Math.max(
                BlastDamage.exposureDamage(player,pressure,true,null,landing.position()),
                BlastDamage.exposureDamage(player,pressure,true,null,landing.impact()));
            if(liveAnchor&&incoming>=3)continue;
            if(!liveAnchor)incoming*=.2f;
            if(cost+incoming>=health-1)continue;
            var attack=shelterAnchorAt(player,opponent,landing.position(),options,bout.failedAnchor,tick<bout.retryAnchorAt);
            if(attack==null||attack.damage().self()+cost+incoming>=health)continue;
            double score=attack.damage().value()-incoming-cost-.2*landing.ticks();
            if(best==null||score>best.score())best=new ShelterPearl(look,landing,attack,score);
        }
        if(best==null)return false;
        UhcTools.stopMining(actor);
        if(!throwPearl(actor,best.look()))return false;
        bout.pearlUntil=tick+best.landing().ticks()+4;
        bout.shelterStand=null;
        bout.shelterFlank=null;
        var at=best.landing().position();
        receipt.put("pearlThrown",true);
        receipt.put("pearlMode","shelter-anchor");
        receipt.put("pearlPlan",Map.of("landing",List.of(at.getX(),at.getY(),at.getZ()),
            "flightTicks",best.landing().ticks(),"blast",coordinates(best.attack().anchor())));
        hold(bout,receipt);
        return true;
    }

    private static UhcTools.Route shelterWalk(Location own,Location stand){
        var heading=stand.toVector().subtract(own.toVector()).setY(0);
        return new UhcTools.Route(heading.lengthSquared()>1?heading.normalize():heading,"shelter-anchor-angle");
    }

    private static List<Block> shelterAnchorCells(Location enemy){
        var feet=enemy.getBlock();
        var options=new ArrayList<Block>();
        for(var side:SIDES){
            var cell=feet.getRelative(side);
            if(emptyPlacement(cell))options.add(cell);
        }
        return options;
    }

    private static ShelterAnchor shelterAnchorAt(Player player,Player opponent,Location stand,List<Block> options,
                                                 Block failed,boolean skipFailed){
        var own=player.getLocation();
        var enemy=opponent.getLocation();
        var eye=stand.clone().add(0,player.getEyeHeight(),0);
        var body=player.getBoundingBox().clone().shift(stand.toVector().subtract(own.toVector()));
        double reach=range(player);
        ShelterAnchor best=null;
        for(var anchor:options){
            if(skipFailed&&anchor.equals(failed)||body.overlaps(BoundingBox.of(anchor)))continue;
            var origin=center(anchor,.5);
            var blast=new Location(own.getWorld(),origin.x,origin.y,origin.z);
            if(stand.distanceSquared(blast)<6.25||enemy.distanceSquared(blast)>6.25
                ||eye.distanceSquared(blast)>(reach+.85)*(reach+.85)
                ||placementClick(eye,reach,anchor,null,null)==null
                ||!visibleAnchor(eye,reach,anchor,null))continue;
            var direct=BlastDamage.estimate(player,opponent,origin,true,null,stand,enemy);
            if(!direct.enoughTargetDamage(opponent))continue;
            Block cover=null;
            var damage=direct;
            if(direct.self()>1&&amount(player,1,Material.OBSIDIAN)>0){
                var delta=blast.toVector().subtract(stand.toVector()).setY(0);
                for(double fraction:new double[]{.35,.53,.68}){
                    var cell=stand.clone().add(delta.clone().multiply(fraction)).getBlock();
                    if(cell.equals(anchor)||!canPlace(cell)||body.overlaps(BoundingBox.of(cell))
                        ||placementClick(eye,reach,cell,null,null)==null
                        ||placementClick(eye,reach,anchor,cell,null)==null
                        ||!visibleAnchor(eye,reach,anchor,cell))continue;
                    var shielded=BlastDamage.estimate(player,opponent,origin,true,cell,stand,enemy);
                    if(safeAttack(shielded,player,opponent)&&shielded.value()>damage.value()+.25){
                        damage=shielded;
                        cover=cell;
                    }
                }
            }
            if(safeAttack(damage,player,opponent)&&(best==null
                ||damage.value()-(cover==null?0:.25)>best.damage().value()-(best.cover()==null?0:.25)))
                best=new ShelterAnchor(anchor,cover,damage);
        }
        return best;
    }

    private static boolean visibleAnchor(Location eye,double reach,Block anchor,Block cover){
        if(visibleAnchorPoint(eye,reach,anchor.getLocation().add(.5,.5,.5),cover))return true;
        for(var offset:TOP_AIMS){
            if(visibleAnchorPoint(eye,reach,anchor.getLocation().add(offset[0],.999,offset[1]),cover))return true;
        }
        return false;
    }

    private static boolean visibleAnchorPoint(Location eye,double reach,Location point,Block cover){
        var direction=point.toVector().subtract(eye.toVector());
        double distance=direction.length();
        return distance<=reach&&distance>.001
            &&(cover==null||!blocksRay(eye,cover,new Vec3(point.getX(),point.getY(),point.getZ())))
            &&eye.getWorld().rayTraceBlocks(eye,direction,distance,FluidCollisionMode.NEVER,true)==null;
    }

    private static boolean tryAnchor(NativeControl.Actor actor,Player opponent,Bout bout,int tick,
                                     boolean anchor,Map<String,Object> receipt){
        if(finishPendingAnchor(actor,opponent,bout,tick,receipt))return true;
        var selected=anchor?select(actor.player(),opponent,true,tick<bout.retryAnchorAt?bout.failedAnchor:null):null;
        return selected!=null&&attackAnchor(actor,opponent,bout,tick,selected,receipt);
    }

    private static boolean finishPendingAnchor(NativeControl.Actor actor,Player opponent,Bout bout,int tick,
                                               Map<String,Object> receipt){
        var player=actor.player();
        if(bout.pendingAnchor!=null){
            var pending=bout.pendingAnchor;
            bout.pendingAnchor=null;
            if(tick<=bout.pendingUntil&&pending.getType()==Material.RESPAWN_ANCHOR){
                var score=BlastDamage.estimate(player,opponent,center(pending,.5),true,null);
                if(finishAnchor(actor,opponent,pending,score,receipt)){
                    receipt.put("anchorPriority",true);hold(bout,receipt);return true;
                }
            }
        }
        return false;
    }

    private static boolean attackAnchor(NativeControl.Actor actor,Player opponent,Bout bout,int tick,
                                        Block block,Map<String,Object> receipt){
        Player player=actor.player();
        UhcTools.stopMining(actor);
        if(!place(actor,5,Material.RESPAWN_ANCHOR,block)){
            bout.failedAnchor=block;bout.retryAnchorAt=tick+12;
            receipt.put("anchorPlacementFailed",true);
            return false;
        }
        receipt.put("anchorConsumed",1);
        receipt.put("anchorPlacement",Map.of("anchor",coordinates(block)));
        var score=BlastDamage.estimate(player,opponent,center(block,.5),true,null);
        if(!safeAttack(score,player,opponent))return false;
        if(!finishAnchor(actor,opponent,block,score,receipt)){
            bout.pendingAnchor=block;bout.pendingUntil=tick+4;
            return false;
        }
        receipt.put("anchorPriority",true);
        hold(bout,receipt);
        return true;
    }

    private static CrystalHit bestCrystal(Player player,Player opponent){
        CrystalHit best=null;
        for(Entity e:player.getNearbyEntities(3.5,3.5,3.5))if(e instanceof EnderCrystal crystal){
            var hit=scoreCrystal(player,opponent,crystal);
            if(hit!=null&&(best==null||hit.score().value()>best.score().value()))best=hit;
        }
        return best;
    }
    private static boolean spawnCrystal(NativeControl.Actor actor,Player opponent,Block base,int tick,Map<String,Object> receipt){
        var player=actor.player();
        if(base.getType().isAir()){
            if(click(actor,1,Material.OBSIDIAN,base.getRelative(BlockFace.DOWN),true)!=1)return false;
            receipt.put("basePlaced",true);receipt.put("obsidianConsumed",1);
        }
        var score=BlastDamage.estimate(player,opponent,center(base,1),false,null);
        if(!safeAttack(score,player,opponent))return false;
        if(click(actor,2,Material.END_CRYSTAL,base,false)==1){
            var at=base.getLocation().add(.5,1,.5);
            receipt.put("crystalSpawned",true);receipt.put("crystalConsumed",1);
            for(var entity:player.getWorld().getNearbyEntities(at,.25,.25,.25,e->e instanceof EnderCrystal)){
                entity.addScoreboardTag(TAG);hitCrystal(actor,scoreCrystal(player,opponent,(EnderCrystal)entity),tick,receipt);
            }
            return true;
        }
        return false;
    }

    private static double effectiveHealth(Player player){
        return player.getHealth()+player.getAbsorptionAmount();
    }
    private static boolean reachSword(Player player,Player opponent){
        return player.getInventory().getHeldItemSlot()==0&&amount(player,0,Material.NETHERITE_SWORD)>0
            &&player.getCooledAttackStrength(.5f)>=.9
            &&opponent.getNoDamageTicks()<=opponent.getMaximumNoDamageTicks()/2
            &&NativeControl.sonMeleeLook(player.getEyeLocation(),opponent.getBoundingBox(),3)!=null;
    }
    private static void restoreAppleSlot(Player player,Bout bout,Map<String,Object> receipt){
        if(bout.appleReturnSlot<0)return;
        var inventory=player.getInventory();
        if(inventory.getHeldItemSlot()==4)inventory.setHeldItemSlot(bout.appleReturnSlot);
        if(amount(player,4,Material.GOLDEN_APPLE)<bout.appleCount)receipt.put("appleFinished",true);
        bout.appleReturnSlot=-1;
    }
    static boolean wantsApple(double health,double maxHealth,double absorption,boolean regenerating){
        return absorption<.5||health<maxHealth-1&&!regenerating;
    }
    static boolean eatingApple(Player player){
        return player.hasActiveItem()&&player.getActiveItem().getType()==Material.GOLDEN_APPLE
            &&player.getInventory().getItemInMainHand().getType()==Material.GOLDEN_APPLE;
    }
    private static boolean canStartApple(NativeControl.Actor actor){
        var player=actor.player();
        return amount(player,4,Material.GOLDEN_APPLE)>0&&!player.isInLava()&&!player.hasActiveItem()&&!actor.handle.handActionLocked()
            &&wantsApple(player.getHealth(),player.getMaxHealth(),player.getAbsorptionAmount(),
                player.hasPotionEffect(org.bukkit.potion.PotionEffectType.REGENERATION));
    }
    private static boolean startApple(NativeControl.Actor actor,Bout bout,Map<String,Object> receipt){
        if(!canStartApple(actor))return false;
        var player=actor.player();
        int apples=amount(player,4,Material.GOLDEN_APPLE);
        UhcTools.stopMining(actor);
        var inventory=player.getInventory();
        int previous=inventory.getHeldItemSlot();
        inventory.setHeldItemSlot(4);
        actor.handle.gameMode.useItem(actor.handle,actor.handle.level(),actor.handle.getMainHandItem(),InteractionHand.MAIN_HAND);
        if(!eatingApple(player)){
            actor.handle.stopUsingItem();
            inventory.setHeldItemSlot(previous);
            return false;
        }
        bout.appleReturnSlot=previous;
        bout.appleCount=apples;
        receipt.put("appleStarted",true);
        hold(bout,receipt);
        return true;
    }
    private static void restockObsidian(Player player){
        var inventory=player.getInventory();
        var supply=inventory.getItem(1);
        if(supply!=null&&!supply.getType().isAir())return;
        int slot=inventory.first(Material.OBSIDIAN);
        if(slot<0||slot>35)return;
        inventory.setItem(1,inventory.getItem(slot));
        inventory.setItem(slot,null);
    }
    private static void waitReceipt(Bout bout,Map<String,Object> receipt){
        var route=bout.waitRoute;
        receipt.put("blastWait",route.action());
        receipt.put("anchorHeading",List.of(route.heading().getX(),route.heading().getZ()));
    }
    private static void hold(Bout bout,Map<String,Object> receipt){bout.hold=true;receipt.put("holdPosition",true);}
}
