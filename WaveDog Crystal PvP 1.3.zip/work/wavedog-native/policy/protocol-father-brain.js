'use strict'

// Placement, blast scoring and item use share the native world's current state.
function createFatherBrain(){
  function createState(){return {}}
  function decide(s,frame,probe,tick){
    const command={kind:'legacy86-ground',phase:'CRYSTAL',slot:0,forward:0,
      side:0,sprint:false,jump:false,shield:false,attack:false,doubleAttack:false,keepTargetLook:true,crystal:{}}
    return {mode:'CRYSTAL',phase:'CRYSTAL',selectedBranch:'father:crystal-first',command}
  }
  return {createState,reset(){},decide,receipt(){},applied(){},rangedApplied(){}}
}

module.exports={createFatherBrain}
