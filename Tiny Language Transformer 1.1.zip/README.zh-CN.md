# Tiny Language Transformer WaveDog

这个包用于已有 WaveDog Native Control 的 Paper 服。它包含共享聊天模型、词元解码、训练与检查代码，以及聊天桥接源码。战斗插件和竞技场须已具备。大厅由 WaveDog 应答，对战中由当前参战机器人应答。

## 接入

把包内的 `work`、`outputs` 合并到 WaveDog 配置的工作区根目录。在 `work/pvp-dual-brain` 安装 Node.js 依赖 `npm ci --omit=dev`。服务器需要 `WaveDogChatSense.jar` 捕捉普通聊天，并在 `WaveDogNativeControl/config.yml` 设置 `dialogue-enabled: true`。现有插件的 `/wdnative restart-speech` 可单独重载语言进程。

## 词元怎样关联战况

- `generation-context.js` 记录近战命中次数、盾挡次数、距离、对手生命值与落地状态、收到的伤害、暴击标记与帧间隔。
- `generation-runtime.mjs` 将最近四帧的 Son、PvP、事件向量和最多 23 个聊天语素投影到 48 维。每个词元有独立的输入嵌入和输出投影。Transformer 在已生成前缀及这些输入上做注意力，再预测下一个词元。
- `train-contextual.js` 用相同提问配不同战况做监督，并用有可核实事件的真人对局补充向量分布。文本进入训练前转换成词元 ID，每个训练位置预测一个 ID。`contextual/tokenized-supervision.jsonl` 展示拆分后的合成语料。真人原始轨迹和聊天保留在本地工作区。
- `reply-attribution.mjs` 固定生成前缀，逐项消融输入以测量每个词元的对数概率变化，同时测量两路向量的交互效应。空列表表示样例里没有达到显示阈值的变化。标点和语气助词通常主要由语言上下文决定。

这一版在箭命中、剑连、盾挡三个中文场景优先走上下文生成。明确的英文请求、其他意图和未通过事实校验的候选走共享旧模型。普通聊天里的相关提问可引用当前对局最近五秒的可验证事件。

## 本地训练和检查

从工作区根目录执行以下命令。可在训练步数后追加原生对局轨迹文件，第一局固定用作留出验证。

```powershell
node work/pvp-dual-brain/perception-language/train-contextual.js outputs/pvp-perception-language/contextual 700
node work/pvp-dual-brain/perception-language/reply-attribution.mjs outputs/pvp-perception-language/reply-context.int8.bin outputs/pvp-perception-language/contextual/sample-input.jsonl
node work/pvp-dual-brain/perception-language/test-live-online.js outputs/pvp-perception-language/reply.int8.bin outputs/pvp-perception-language/reply-context.int8.bin
```

训练权重保存在 `outputs/pvp-perception-language/contextual/reply-context.float.json`，量化候选为同目录的 `reply-context.int8.bin`。完成验收后，把候选复制到上一级 `outputs/pvp-perception-language/reply-context.int8.bin` 供服务器读取。
