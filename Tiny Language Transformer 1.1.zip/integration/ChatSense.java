package local.wavedog.chatsense;

import com.google.gson.Gson;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Routes regular player chat to the current duel or to the lobby dialogue. */
public final class ChatSense extends JavaPlugin implements Listener {
    private final Gson json=new Gson();
    private final ExecutorService io=Executors.newSingleThreadExecutor(r->{
        var thread=new Thread(r,"WaveDog-chat-capture");thread.setDaemon(true);return thread;
    });
    private final Path log=Path.of(System.getProperty("wavedog.workspace","D:/CodexWorkspace/ban"))
        .resolve("outputs/pvp-perception-language/player-chat.jsonl");

    @Override public void onEnable(){Bukkit.getPluginManager().registerEvents(this,this);}
    @Override public void onDisable(){
        io.shutdown();
        try{io.awaitTermination(5,TimeUnit.SECONDS);}catch(InterruptedException error){Thread.currentThread().interrupt();}
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void chat(AsyncChatEvent event){
        String text=PlainTextComponentSerializer.plainText().serialize(event.message()).strip();
        if(text.isEmpty()||text.length()>160||text.chars().anyMatch(Character::isISOControl))return;
        UUID id=event.getPlayer().getUniqueId();
        Bukkit.getScheduler().runTask(this,()->capture(id,text));
    }
    private void capture(UUID id,String text){
        Player player=Bukkit.getPlayer(id);
        if(player==null||player.hasMetadata("wavedog-native-player"))return;
        Plugin nativeControl=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
        if(nativeControl==null||!nativeControl.isEnabled())return;
        try{
            Field actorsField=nativeControl.getClass().getDeclaredField("actors");actorsField.setAccessible(true);
            @SuppressWarnings("unchecked") Map<String,Object> actors=(Map<String,Object>)actorsField.get(nativeControl);
            for(MetadataValue value:player.getMetadata("wavedog-duel-owner")){
                String speaker=value.asString();Object actor=actors.get(speaker);
                if(actor==null)continue;
                Class<?> type=actor.getClass();
                Field matchField=type.getDeclaredField("match"),opponentField=type.getDeclaredField("opponent"),activeField=type.getDeclaredField("active");
                matchField.setAccessible(true);opponentField.setAccessible(true);activeField.setAccessible(true);
                String match=(String)matchField.get(actor),opponent=(String)opponentField.get(actor);
                if(match==null||!player.getName().equals(opponent)
                    ||!activeField.getBoolean(actor)&&!player.hasMetadata("wavedog-preparation-cage"))continue;
                Map<String,Object> row=Map.of("id",UUID.randomUUID().toString(),"speaker",speaker,
                    "matchId",match,"player",player.getName(),"text",text,
                    "tick",Bukkit.getCurrentTick(),"submittedAt",System.currentTimeMillis());
                String line=json.toJson(row)+"\n";
                io.execute(()->{
                    try{Files.createDirectories(log.getParent());Files.writeString(log,line,StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
                    catch(Exception error){getLogger().warning("Could not record duel chat: "+error);}
                });
                return;
            }
            nativeControl.getClass().getMethod("receiveLobbyChat",UUID.class,String.class).invoke(nativeControl,id,text);
        }catch(ReflectiveOperationException error){getLogger().warning("Could not route player chat: "+error);}
    }
}
