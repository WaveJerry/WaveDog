// Bridge written technique goals into the existing focus channels without
// changing the trained policy or optimizer tensor shapes. These are context
// hints; action choice and credit assignment remain with the learned policy.
export const FOCUS_NAMES = ['FREE', 'CHARGE', 'SHIELD', 'AXE_BREAK', 'CRITICAL',
  'SPRINT_KB', 'ESCAPE', 'SYNC', 'FLANK', 'COMBO', 'BOW', 'CROSSBOW',
  'DODGE', 'WALL', 'LATENCY', 'OPPONENT']

export function conditionTechniqueObservation (observation, focus, cues = [], publicArena = null, publicTerrain = null) {
  if (!Array.isArray(observation) || observation.length !== 98)
    throw Error('Technique bridge expects 98 public observation values')
  const conditioned = [...observation]
  if (publicTerrain && Number.isFinite(publicTerrain.episodeTick))
    conditioned[17] = Math.max(0, Math.min(1, publicTerrain.episodeTick/2400))
  // Protocol actors can duel in any world location. Their loaded block rays,
  // rather than an obsolete fixed arena floor, define the terrain inputs.
  if (publicTerrain && Number.isFinite(publicTerrain.groundY)
      && Number.isFinite(publicTerrain.selfY)) {
    conditioned[16] = Math.max(-1, Math.min(1, (publicTerrain.selfY-publicTerrain.groundY)/4))
    if (Array.isArray(publicTerrain.walls) && publicTerrain.walls.length === 4
        && publicTerrain.walls.every(x => Number.isFinite(x) && x >= 0))
      publicTerrain.walls.forEach((x, i) => { conditioned[56+i] = Math.min(1,x/8) })
  }
  if (publicArena) {
    const { self, bounds } = publicArena
    const coords = [self?.x, self?.z, bounds?.minX, bounds?.maxX, bounds?.minZ, bounds?.maxZ]
    if (coords.every(Number.isFinite) && bounds.maxX > bounds.minX && bounds.maxZ > bounds.minZ
        && self.x >= bounds.minX && self.x <= bounds.maxX && self.z >= bounds.minZ && self.z <= bounds.maxZ) {
      conditioned[56] = Math.min(1, (self.x - bounds.minX) / 8)
      conditioned[57] = Math.min(1, (bounds.maxX - self.x) / 8)
      conditioned[58] = Math.min(1, (self.z - bounds.minZ) / 8)
      conditioned[59] = Math.min(1, (bounds.maxZ - self.z) / 8)
    }
  }
  // Absolute world yaw let the policy learn "north attacks, south waits".
  // Use the already public target-relative yaw instead: facing the named
  // opponent has the same representation on every spawn side.
  if (conditioned[31] > .5) {
    const relativeYaw = Math.PI * conditioned[78]
    conditioned[14] = Math.sin(relativeYaw)
    conditioned[15] = Math.cos(relativeYaw)
  }
  const primary = FOCUS_NAMES.indexOf(focus)
  if (primary <= 0) return conditioned
  conditioned[80 + primary] = 1
  if (!Array.isArray(cues)) return conditioned
  for (const [position, cue] of cues.slice(0, 2).entries()) {
    const index = FOCUS_NAMES.indexOf(cue)
    if (index > 0 && index !== primary)
      conditioned[80 + index] = Math.max(conditioned[80 + index],
        position === 0 ? .45 : .3)
  }
  return conditioned
}
