import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {loadReplyModel} from './generation-runtime.mjs'

const groups = {
  ownHealth:{son:[0]}, enemyHealth:{replyContext:[1]},
  distance:{son:[18,19,20],replyContext:[0]},
  enemyGround:{replyContext:[2]}, meleeHits:{replyContext:[3]},
  shieldBlocks:{replyContext:[4]}, damage:{replyContext:[5,6]},
  verifiedEvents:{event:'all'}, pvp:{pvp:'all'}, chat:{}
}
const pairs = [
  ['ownHealth','meleeHits'], ['ownHealth','distance'], ['ownHealth','shieldBlocks'],
  ['chat','verifiedEvents'], ['chat','distance'], ['chat','meleeHits'], ['chat','shieldBlocks']
]

function ablate(sample, names) {
  const history = sample.history.map(frame => {
    const result = {...frame}
    for(const name of names){
      for(const [key,indices] of Object.entries(groups[name])){
        if(!result[key])continue
        result[key]=result[key].map((value,index)=>indices==='all'||indices.includes(index)?0:value)
      }
    }
    return result
  })
  return {...sample,history,chat:names.includes('chat')?'':sample.chat}
}

export function tokenAttribution(model,sample){
  const base = model.trace(sample)
  if(!base.text || base.steps.at(-1)?.id!==3)return {text:'',tokens:[]}
  const ids = base.steps.map(step=>step.id)
  const single = Object.fromEntries(Object.keys(groups).map(name=>
    [name,model.trace(ablate(sample,[name]),ids).steps]))
  const joint = pairs.map(names=>[names,model.trace(ablate(sample,names),ids).steps])
  const strongest = (items,limit) => items
    .filter(([,value])=>Math.abs(value)>=.05)
    .sort((a,b)=>Math.abs(b[1])-Math.abs(a[1]))
    .slice(0,limit).map(([source,change])=>({source,deltaLogProbability:Number(change.toFixed(3))}))
  const tokens = base.steps.slice(0,-1).map(({token,logProbability},index)=>({
    token,
    probability:Number(Math.exp(logProbability).toFixed(4)),
    vectors:strongest(Object.entries(single).map(([name,steps])=>[name,logProbability-steps[index].logProbability]),3),
    combinations:strongest(joint.map(([[a,b],steps])=>[
      [a,b], logProbability-single[a][index].logProbability-single[b][index].logProbability+steps[index].logProbability
    ]),2)
  }))
  return {intent:sample.intent,text:base.text,embeddingWidth:model.embeddingWidth,tokens}
}

if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [checkpoint,input]=process.argv.slice(2)
  if(!checkpoint || !input)throw Error('usage: node reply-attribution.mjs model.bin samples.jsonl')
  const model=loadReplyModel(checkpoint)
  for(const line of fs.readFileSync(input,'utf8').split(/\r?\n/u))
    if(line.trim())console.log(JSON.stringify(tokenAttribution(model,JSON.parse(line))))
}
