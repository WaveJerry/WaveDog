import fs from 'node:fs'
import {split} from './generation-runtime.mjs'

function grams(text) {
  const tokens=split(text)
  return new Set(tokens.slice(1).map((token,i)=>tokens[i]+'|'+token))
}

export function openLobbyLearning(file) {
  const entries=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):[]
  const rows=new Map(entries.map(entry=>[entry.text,{...entry,grams:grams(entry.text)}]))
  return {
    recognize(text) {
      if(rows.has(text))return rows.get(text).intent
      const features=grams(text)
      if(features.size<3)return null
      const scores=new Map()
      for(const candidate of rows.values()){
        const shared=[...features].filter(feature=>candidate.grams.has(feature)).length
        if(shared<3)continue
        const score=shared/Math.max(features.size,candidate.grams.size)
        scores.set(candidate.intent,Math.max(scores.get(candidate.intent)||0,score))
      }
      const ranked=[...scores].sort((a,b)=>b[1]-a[1])
      if(!ranked.length||ranked[0][1]<.8||ranked[0][1]-(ranked[1]?.[1]??0)<.15)return null
      return ranked[0][0]
    },
    remember(text,intent) {
      if(rows.has(text))return false
      if(text.length>40)return false
      rows.set(text,{text,intent,grams:grams(text)})
      if(rows.size>256)rows.delete(rows.keys().next().value)
      const temp=file+'.tmp'
      fs.writeFileSync(temp,JSON.stringify([...rows.values()].map(({text,intent})=>({text,intent})))+'\n')
      fs.renameSync(temp,file)
      return true
    }
  }
}
