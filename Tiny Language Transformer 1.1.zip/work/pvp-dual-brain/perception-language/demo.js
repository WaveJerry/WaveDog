import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {DialogueEngine} from './infer.js'
import {pvpFromDual,speak} from './dialogue.js'

await tf.setBackend('cpu');await tf.ready()
const engine=new DialogueEngine(process.argv[2]||path.resolve('outputs/pvp-perception-language/checkpoint.json'))
const son=Array(98).fill(0);son[0]=.7;son[1]=1;son[2]=1;son[31]=1;son[97]=.1
const pvp=pvpFromDual({actions:[1,1,0,0,2,1,0,0,0]})
const situations=[
  {label:'对方打中一箭',events:{enemyBowHit:true}},
  {label:'对方反复后撤',events:{enemyRetreat:true}},
  {label:'本局胜利',events:{boutEnd:true,won:true}}
]
for(const [index,item] of situations.entries()){
  engine.reset('WaveDogSon')
  const prediction=engine.decide({speaker:'WaveDogSon',sonVector:son,pvpVector:pvp,
    events:item.events,now:Date.now()+index*10000,rng:()=>0})
  // Teacher-approved example shows the phrase inventory even if the model
  // correctly abstains due to low confidence on this synthetic context.
  const intended={enemyBowHit:'nice_bow',enemyRetreat:'retreat_roast',boutEnd:'gg_win'}
  const cue=Object.keys(item.events).find(key=>intended[key])
  const example=speak(intended[cue],item.events,{},Date.now(),()=>0)
  console.log(JSON.stringify({situation:item.label,prediction,approvedExample:example}))
}
engine.dispose()
