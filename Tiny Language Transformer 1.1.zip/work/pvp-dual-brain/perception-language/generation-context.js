const unit = value => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0

// Values describe accepted game state and resolved events, never future actions.
export function replyFeatures({distance, enemyHealth, enemyGround, combo, blocks, damage, critical, elapsed}) {
  return [
    unit(distance / 16), unit(enemyHealth / 20), Number(Boolean(enemyGround)),
    unit(combo / 5), unit(blocks / 4), unit(damage / 10), Number(Boolean(critical)), unit(elapsed / 100)
  ]
}

export function replyFeaturesFromFrame(frame, hits, blocks, lastTick, incoming) {
  return replyFeatures({
    distance:frame.observation.distance, enemyHealth:frame.seen.health, enemyGround:frame.seen.ground,
    combo:hits, blocks, damage:incoming?.amount, critical:incoming?.nativeCritical,
    elapsed:frame.tick-lastTick
  })
}

export function replyHistory(history, size) {
  const rows = history.slice(-size)
  return Array(Math.max(0, size-rows.length)).fill(rows[0]).concat(rows)
}

export const contextualIntents = ['nice_bow', 'combo_hype', 'shield_respect']

export function eventQuestion(chat) {
  if (!/[？?吗么]|几下|几刀|几次/u.test(chat)) return null
  if (/箭/u.test(chat) && /远|距离/u.test(chat)) return 'nice_bow'
  if (/连|接/u.test(chat) && /几下|几刀|几次/u.test(chat)) return 'combo_hype'
  if (/盾|挡住/u.test(chat) && /挡|打到|打上/u.test(chat)) return 'shield_respect'
  return null
}

// Predicates serve as teacher labels and as checks for specific factual claims.
// They are never inserted into the model's input or used as decoder routes.
export function replyFacts(intent, frame) {
  const [distance,,,combo,blocks] = frame.replyContext
  return {
    tired:frame.son[0] <= .3,
    specific: intent === 'nice_bow' ? distance >= .5
      : intent === 'combo_hype' ? combo >= .6 : blocks >= .5
  }
}

export function groundedReply(text, intent, frame, lastText) {
  if (!text || text === lastText || text.length > 40 || !/^\p{Script=Han}[\p{Script=Han}，。！？、]+[。！？]$/u.test(text))
    return false
  const {tired,specific} = replyFacts(intent,frame)
  if (/残血|没血|血线|快没了|先缓|喘口气|差点寄/u.test(text) && !tired) return false
  if (/这么远|远处|隔老远/u.test(text) && (intent !== 'nice_bow' || !specific)) return false
  if (/没多远/u.test(text) && (intent !== 'nice_bow' || specific)) return false
  if (/打残|一中我就残血/u.test(text)) return false
  if (/贴这么近|近身射/u.test(text) && (intent !== 'nice_bow' || frame.replyContext[0] > .25)) return false
  if (/第三下|三刀|三下/u.test(text) && (intent !== 'combo_hype' || !specific)) return false
  if (/连挡|又挡|又被.*挡|至少挡了两下|两下都.*盾/u.test(text) &&
      (intent !== 'shield_respect' || !specific)) return false
  return {
    nice_bow:/箭|射|远.*中/u, combo_hype:/连|刀|接上/u, shield_respect:/盾|挡/u
  }[intent]?.test(text) ?? false
}
