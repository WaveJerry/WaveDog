import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {PerceptionTransformer,DEFAULT_CONFIG} from './model.js'
import {INTENTS,toTensors} from './dialogue.js'
import {examples} from './teacher.js'

await tf.setBackend('cpu');await tf.ready()
const steps=Number(process.argv[2]||120)
const width=Number(process.argv[3]||DEFAULT_CONFIG.width)
const layers=Number(process.argv[4]||DEFAULT_CONFIG.layers)
if(!Number.isInteger(steps)||steps<1||steps>10000)throw Error('steps must be 1..10000')
const model=new PerceptionTransformer(INTENTS.length,{width,layers,heads:4})
const optimizer=tf.train.adam(.0015)
const start=performance.now()
let lastLoss=0
for(let step=0;step<steps;step++){
  const samples=examples(16,20261122+step*37)
  const input=toTensors(samples)
  const labels=tf.tensor1d(samples.map(sample=>sample.label),'int32')
  const cost=optimizer.minimize(()=>tf.tidy(()=>{
    const truth=tf.oneHot(labels,INTENTS.length)
    return tf.mean(tf.losses.softmaxCrossEntropy(truth,model.logits(input)))
  }),true,model.params)
  lastLoss=cost.dataSync()[0]
  cost.dispose();labels.dispose();for(const tensor of Object.values(input))tensor.dispose()
  if((step+1)%20===0)process.stdout.write(JSON.stringify({step:step+1,loss:lastLoss})+'\n')
}
const held=examples(96,9172001),input=toTensors(held)
const logits=tf.tidy(()=>tf.argMax(model.logits(input),1))
const prediction=[...logits.dataSync()]
let correct=0;for(let i=0;i<held.length;i++)if(prediction[i]===held[i].label)correct++
logits.dispose();for(const tensor of Object.values(input))tensor.dispose()
const result={teacherSeedOnly:true,steps,width,layers,parameters:model.parameterCount(),
  finalLoss:lastLoss,syntheticHoldoutAccuracy:correct/held.length,
  elapsedSeconds:(performance.now()-start)/1000}
const directory=path.resolve(process.argv[5]||'outputs/pvp-perception-language')
fs.mkdirSync(directory,{recursive:true})
fs.writeFileSync(path.join(directory,'checkpoint.json'),JSON.stringify(model.snapshot()))
fs.writeFileSync(path.join(directory,'training-report.json'),JSON.stringify(result,null,2)+'\n')
model.dispose();optimizer.dispose()
process.stdout.write(JSON.stringify(result)+'\n')
