import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {Worker} from 'node:worker_threads'
import {examples} from './teacher.js'

const checkpoint=path.resolve('outputs/pvp-perception-language/checkpoint.json')
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-online-'))
const adapter=path.join(directory,'adapter.json')
const worker=new Worker(new URL('./online-trainer.js',import.meta.url),
  {workerData:{checkpoint,adapter}})
const next=()=>new Promise((resolve,reject)=>{
  const fail=error=>{worker.off('message',receive);reject(error)}
  const receive=row=>{worker.off('error',fail);resolve(row)}
  worker.once('message',receive);worker.once('error',fail)
})
try{
  assert.equal((await next()).ready,true)
  const sample=examples(1,20261122)[0]
  const item={id:'local-test-1',history:sample.history,persona:sample.persona,
    label:sample.label,phrase:sample.label===0?'':'测试台词'}
  worker.postMessage(item)
  const trained=await next()
  assert.equal(trained.trained,true)
  assert.equal(trained.revision,1)
  assert(Number.isFinite(trained.loss))
  const saved=JSON.parse(fs.readFileSync(adapter,'utf8'))
  assert.equal(saved.trainedExamples,1)
  assert(saved.seenIds.includes(item.id))
  worker.postMessage(item)
  assert.equal((await next()).duplicate,true)
  console.log(JSON.stringify({pass:true,revision:saved.revision,loss:trained.loss,
    adapterBytes:fs.statSync(adapter).size}))
}finally{
  await worker.terminate()
  assert(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep))
  assert(path.basename(directory).startsWith('wavedog-online-'))
  fs.rmSync(directory,{recursive:true,force:true})
}
