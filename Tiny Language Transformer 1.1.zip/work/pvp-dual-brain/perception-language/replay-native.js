import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {DialogueEngine} from './infer.js'
import {pvpFromDual} from './dialogue.js'

const [trace,speaker,checkpoint]=process.argv.slice(2)
if(!trace||!speaker)throw Error('usage: replay-native.js <native-frames.jsonl> <WaveDogSon|...> [checkpoint]')
const maxFrames=Number(process.argv[5]||1000)
await tf.setBackend('cpu');await tf.ready()
const engine=new DialogueEngine(checkpoint||path.resolve('outputs/pvp-perception-language/checkpoint.json'))
const output=path.resolve('outputs/pvp-perception-language/replay.jsonl')
fs.mkdirSync(path.dirname(output),{recursive:true})
const stream=fs.createWriteStream(output,{encoding:'utf8'})
let count=0,said=0,previousSample=null,recentBotHits=[]
for await(const line of readline.createInterface({input:fs.createReadStream(trace,{encoding:'utf8'}),crlfDelay:Infinity})){
  if(count>=maxFrames)break
  let row;try{row=JSON.parse(line)}catch{continue}
  const tick=row.observation?.tick
  if(!Number.isInteger(tick)||!row.self||!row.seen)continue
  row.tick=tick
  const damage=(row.nativeEvents||[]).filter(event=>event.type==='damage'
    &&!event.cancelled&&event.amount>0)
  const ownHit=damage.some(event=>event.attacker===speaker)
  if(ownHit&&recentBotHits.at(-1)!==tick)recentBotHits.push(tick)
  recentBotHits=recentBotHits.filter(t=>tick-t<=30)
  const retreat=previousSample&&row.seen.visible&&previousSample.seen.visible
    &&tick-previousSample.tick<=20&&tick-previousSample.tick>=2
    &&Math.hypot(row.seen.x-previousSample.seen.x,row.seen.z-previousSample.seen.z)>.75
    &&row.observation.distance-previousSample.observation.distance>.7
    &&!damage.length
  const enemyHit=damage.find(event=>event.victim===speaker)
  const events={
    boutStart:count===0,
    enemyRetreat:Boolean(retreat),
    enemyBowHit:Boolean(enemyHit&&!enemyHit.melee
      &&['bow','crossbow'].includes(row.observation.targetShotWeapon)),
    enemyMaceHit:Boolean(enemyHit?.melee&&row.seen.held==='MACE'),
    ownCombo:recentBotHits.length>=2,
    ownLowHealth:row.self.health<=6,
    enemyShield:Boolean(row.observation.targetShieldRaised)
  }
  if(tick%20!==0&&!Object.values(events).some(Boolean)){
    if(!previousSample||tick-previousSample.tick>=8)previousSample=row
    count++;continue
  }
  let sonVector
  try{sonVector=nativeObservation(row,{})}catch{previousSample=row;count++;continue}
  const actions=row.neuralFallback?.proposal?.actions
  const pvpVector=actions?pvpFromDual({actions}):pvpFromDual()
  const reply=engine.decide({speaker,sonVector,pvpVector,events,now:1e12+tick*50})
  if(reply.said){stream.write(JSON.stringify({tick,events,...reply})+'\n');said++}
  if(!previousSample||tick-previousSample.tick>=8)previousSample=row
  count++
}
await new Promise((resolve,reject)=>stream.end(error=>error?reject(error):resolve()))
engine.dispose()
console.log(JSON.stringify({frames:count,said,file:output,liveChatSent:false}))
