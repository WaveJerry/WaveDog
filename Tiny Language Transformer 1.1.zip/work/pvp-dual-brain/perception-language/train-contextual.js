import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {frame, pvpFromDual} from './dialogue.js'
import {ReplyTransformer, seeded, trainReply} from './generation-experiment.js'
import {CONTEXTUAL, SPECIAL, compactCheckpoint, loadReplyModel, split} from './generation-runtime.mjs'
import {contextualIntents, groundedReply, replyFacts, replyFeatures, replyFeaturesFromFrame,
  replyHistory} from './generation-context.js'

const lessons = {
  nice_bow:{
    event:'enemyBowHit',
    questions:['这箭射得远吗？','刚才这箭离你远吗？','我这一箭算远吗？','刚才那箭距离远吗？'],
    scenes:[
      ['这箭来得突然。','这箭够快，打中了。'],
      ['隔这么远还能中？','隔这么远，这箭还能中。'],
      ['我都残血了，这箭还中了。','这箭够疼，我先喘口气。'],
      ['隔这么远还中一箭，我都残血了。','你这远处一箭，我血线见底了。']
    ],
    answers:['这箭离我没多远。','隔了这么远，箭还是中了。']
  },
  combo_hype:{
    event:'ownCombo',
    questions:['你连了几下？','刚才接了几刀？','这套连上几下了？','刚才一共连了几刀？'],
    scenes:[
      ['第一刀接上了，后面也连住了。','这两下接得顺。'],
      ['第三下也接上了。','前两刀连住了，第三下也没断。'],
      ['血线这么低，这两下得抓住。','我都残血了，还真给我连上了。'],
      ['残血还能接上第三下。','血线快没了，第三下居然也连住了。']
    ],
    answers:['两下连上了。','至少连了三下。']
  },
  shield_respect:{
    event:'enemyShield',
    questions:['刚才盾挡住了吗？','那下打到盾了吗？','我刚才挡住几下？','刚才有打上盾吗？'],
    scenes:[
      ['这下敲盾上了。','你这盾抬得够快。'],
      ['这么打又被你挡了。','好，两下都敲盾上了。'],
      ['我都残血了，这刀还打在盾上。','血线这么低，还被你挡了一下。'],
      ['残血这几刀还让你连挡了。','我都快没血了，你又挡住了。']
    ],
    answers:['挡着了，我这下打在盾上。','至少挡了两下，我又敲到盾了。']
  }
}
const cues = ['','厉害啊','这一波有点意思','打得可以']
const examples = []
for(const [intent, lesson] of Object.entries(lessons)){
  for(const tired of [false,true]){
    for(const specific of [false,true]){
      const scene = lesson.scenes[2*Number(tired)+Number(specific)]
      for(const text of scene) for(const chat of cues) examples.push({intent,tired,specific,chat,text})
      for(const chat of lesson.questions.slice(0,-1))
        examples.push({intent,tired,specific,chat,text:lesson.answers[Number(specific)]})
    }
  }
}
const vocabulary = [...SPECIAL,
  ...new Set([...examples.flatMap(row=>split(row.chat+row.text)),
    ...Object.values(lessons).flatMap(lesson=>lesson.questions.flatMap(split))]),
  ...contextualIntents.map(intent=>`<intent:${intent}>`)]

function synthetic({intent,tired,specific,chat}, seed){
  const random = seeded(seed)
  const row = Array.from({length:CONTEXTUAL.history}, (_,index) => {
    const last = index === CONTEXTUAL.history-1
    const distance = intent==='nice_bow' && specific ? 8.5+random()*7 : 1.5+random()*4
    const combo = intent==='combo_hype' ? (specific ? 3+Math.floor(random()*3) : 2) : 0
    const blocks = intent==='shield_respect' ? (specific ? 2+Math.floor(random()*3) : 1) : 0
    const son = Array(98).fill(0)
    son[0] = tired ? .08+random()*.22 : .4+random()*.6
    son[1] = random()
    son[2] = Number(random()>.2)
    son[20] = Math.tanh(distance/6)
    son[23] = Number(intent==='shield_respect')
    son[31] = 1
    const events = {ownLowHealth:tired}
    if(last) events[lessons[intent].event]=true
    const earlierCombo = index===CONTEXTUAL.history-2 ? Math.max(0,combo-1) : Math.floor(random()*6)
    const earlierBlocks = index===CONTEXTUAL.history-2 ? Math.max(0,blocks-1) : Math.floor(random()*5)
    return {...frame({sonVector:son,pvpVector:pvpFromDual(),events}),
      replyContext:replyFeatures({distance,enemyHealth:7+random()*13,enemyGround:random()>.2,
        combo:last?combo:earlierCombo,blocks:last?blocks:earlierBlocks,
        damage:intent==='nice_bow'&&last?1+random()*5:0,elapsed:5+random()*15})}
  })
  return {intent,history:row,chat}
}

// Keep complete matches separate. The only text attached to a trace is authored
// supervision for its verified event. Player chat and identities are not exported.
async function replay(file){
  const samples = []
  const recent = []
  let hits=[],blocks=[],lastTick=-Infinity,speaker
  for await(const line of readline.createInterface({input:fs.createReadStream(file),crlfDelay:Infinity})){
    let raw
    try{raw=JSON.parse(line)}catch{continue}
    const tick=raw.observation?.tick
    if(!Number.isFinite(tick)||tick<lastTick||!raw.self||!raw.seen)continue
    const damage=(raw.nativeEvents??[]).filter(row=>row.type==='damage'&&!row.cancelled)
    speaker ??= damage.flatMap(row=>[row.attacker,row.victim]).find(name=>/^WaveDog/i.test(name??''))
    if(!speaker || (!damage.length && tick-lastTick<20))continue
    hits=hits.filter(t=>tick-t<=30)
    blocks=blocks.filter(t=>tick-t<=60)
    const blocked=damage.some(row=>row.attacker===speaker && row.melee && row.amount===0 && row.shieldModifier<0)
    const hit=damage.some(row=>row.attacker===speaker && row.melee && row.amount>0)
    const incoming=damage.find(row=>row.victim===speaker&&row.amount>0)
    const shot=incoming?.melee===false&&['bow','crossbow'].includes(raw.observation.targetShotWeapon)
    if(hit&&hits.at(-1)!==tick)hits.push(tick)
    if(blocked&&blocks.at(-1)!==tick)blocks.push(tick)
    const intent=shot?'nice_bow':blocked?'shield_respect':hit&&hits.length>=2?'combo_hype':null
    const events={ownLowHealth:raw.self.health<=6}
    if(intent)events[lessons[intent].event]=true
    raw.tick=tick
    const observed=frame({sonVector:nativeObservation(raw,{}),
      pvpVector:pvpFromDual(raw.neuralFallback?.proposal??{}),events})
    observed.replyContext=replyFeaturesFromFrame(raw,hits.length,blocks.length,lastTick,incoming)
    recent.push(observed)
    if(recent.length>CONTEXTUAL.history)recent.shift()
    if(intent) samples.push({intent,history:replyHistory(recent,CONTEXTUAL.history),chat:''})
    lastTick=tick
  }
  return samples
}

function sceneChecks(intent, text) {
  const specific={
    nice_bow:/这么远|远处/u,
    combo_hype:/第三下|三下/u,
    shield_respect:/两下|连挡|又挡|又被/u
  }[intent]
  return {specific:specific.test(text),tired:/残血|血线|喘口气|没血|打残/u.test(text)}
}

const output=path.resolve(process.argv[2]??'outputs/pvp-perception-language/contextual')
const steps=Number(process.argv[3]??700)
const resume=process.argv.includes('--resume')
const evaluateOnly=process.argv.includes('--evaluate')
const traceFiles=process.argv.slice(4).filter(value=>!value.startsWith('--'))
if(!Number.isSafeInteger(steps)||steps<1)throw Error('steps must be a positive integer')
await tf.setBackend('cpu')
await tf.ready()
const traces=await Promise.all(traceFiles.map(replay))
const replayExamples=traces.slice(1).flat().map((sample,index)=>{
  const facts=replyFacts(sample.intent,sample.history.at(-1))
  const scene=lessons[sample.intent].scenes[2*Number(facts.tired)+Number(facts.specific)]
  return {...sample,text:scene[index%scene.length]}
})
const take=Math.max(1,Math.ceil(replayExamples.length/(examples.length/3)))
const trainRows=examples.concat(replayExamples.filter((_,i)=>i%take===0))
console.log(JSON.stringify({examples:trainRows.length,synthetic:examples.length,trainMatches:Math.max(0,traces.length-1),
  replayCounts:traces.map(rows=>rows.length)}))
const previous=resume||evaluateOnly?JSON.parse(fs.readFileSync(path.join(output,'reply-context.float.json'),'utf8')):null
const canResume=previous&&vocabulary.every(token=>previous.tokens.includes(token))
if(evaluateOnly&&!canResume)throw Error('training vocabulary does not match the saved model')
const model=new ReplyTransformer(canResume?previous.tokens:vocabulary,CONTEXTUAL)
try{
  if(canResume)model.restore(previous)
  const tokenize=({text,...row})=>({...row,replyIds:split(text).map(token=>model.vocabulary.get(token))})
  const prior=evaluateOnly?JSON.parse(fs.readFileSync(path.join(output,'report.json'),'utf8')):null
  const loss=prior?.loss??trainReply(model,steps,trainRows.map(tokenize),(row,seed)=>row.history?row:synthetic(row,seed)).loss
  fs.mkdirSync(output,{recursive:true})
  const lessonsByToken=examples.map(tokenize).map(({chat,...row})=>({
    ...row,chatIds:split(chat).map(token=>model.vocabulary.get(token))
  }))
  fs.writeFileSync(path.join(output,'tokenized-supervision.jsonl'),lessonsByToken.map(row=>JSON.stringify(row)).join('\n')+'\n')
  const snapshot=model.snapshot()
  const binary=compactCheckpoint(snapshot)
  const weights=path.join(output,'reply-context.int8.bin')
  fs.writeFileSync(weights,binary)
  fs.writeFileSync(path.join(output,'reply-context.float.json'),JSON.stringify(snapshot))
  const compact=loadReplyModel(weights)
  const evaluate=sample=>{
    const text=compact.generate(sample)
    const latest=sample.history.at(-1)
    const truth=replyFacts(sample.intent,latest)
    return {intent:sample.intent,chat:sample.chat,truth,text,grounded:groundedReply(text,sample.intent,latest),
      ...Object.fromEntries(Object.entries(sceneChecks(sample.intent,text)).map(([key,actual])=>[key+'Correct',truth[key]===actual]))}
  }
  const paired=contextualIntents.flatMap((intent,i)=>[false,true].flatMap(tired=>[false,true].map(specific=>
    evaluate(synthetic({intent,tired,specific,chat:''},900+i)))))
  const questionSamples=contextualIntents.flatMap((intent,i)=>[false,true].map(specific=>
    synthetic({intent,tired:true,specific,chat:lessons[intent].questions.at(-1)},950+i)))
  const questions=questionSamples.map(evaluate)
  fs.writeFileSync(path.join(output,'sample-input.jsonl'),questionSamples.map(sample=>JSON.stringify(sample)).join('\n')+'\n')
  const heldout=(traces[0]??[]).map(evaluate)
  const counts=rows=>({total:rows.length,grounded:rows.filter(row=>row.grounded).length,
    specificCorrect:rows.filter(row=>row.specificCorrect).length,tiredCorrect:rows.filter(row=>row.tiredCorrect).length})
  const report={steps:prior?.steps??steps,continued:prior?.continued??Boolean(canResume),
    loss,bytes:binary.length,parameterCount:model.params.reduce((sum,p)=>sum+p.size,0),
    syntheticExamples:examples.length,replayExamples:trainRows.length-examples.length,
    paired,questions,heldout:counts(heldout),holdoutExamples:heldout.slice(0,12)}
  fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n')
  console.log(JSON.stringify({bytes:binary.length,paired:counts(paired),
    questions:{total:questions.length,grounded:questions.filter(row=>row.grounded).length,
      specificCorrect:questions.filter(row=>row.specificCorrect).length},heldout:counts(heldout)}))
}finally{model.dispose()}
