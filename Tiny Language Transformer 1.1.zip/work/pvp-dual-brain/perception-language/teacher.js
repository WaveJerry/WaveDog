import {INTENTS,frame,persona,pvpFromDual} from './dialogue.js'

// Curated PvP contexts and labels. They are an initial teacher set, not human
// chat logs and not proof of generalization to live players.
const recipes = {
  silence:{},
  opener:{boutStart:1},
  retreat_roast:{enemyRetreat:1},
  nice_bow:{enemyBowHit:1},
  nice_mace:{enemyMaceHit:1},
  nice_crystal:{enemyCrystalHit:1},
  combo_hype:{ownCombo:1},
  shield_respect:{enemyShield:1},
  clutch:{ownLowHealth:1},
  gg_win:{boutEnd:1,won:1},
  gg_loss:{boutEnd:1,lost:1},
  tilt:{enemyRetreat:1,ownLowHealth:1}
}
const botNames=['WaveDogSon','WaveDogBrother','WaveDogFather','WaveDogSister']
function next(seed){return ()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32}}

function oneFrame(intent,random,age=0){
  const events=age===0?{...recipes[intent]}:{}
  if(random()<.3)events.enemyNear=true
  if(intent==='silence'&&random()<.3)events.quiet=true
  if(intent==='retreat_roast'&&random()<.2)events.enemyShield=true
  const son=Array(98).fill(0)
  son[0]=events.ownLowHealth?.15:.45+random()*.5
  son[1]=random();son[2]=random()<.8?1:0
  son[31]=random()<.9?1:0
  const distance=events.enemyRetreat?3.5+random()*5:1.5+random()*5
  son[97]=Math.tanh((distance-3)/.75)
  son[23]=events.enemyShield?1:0
  son[28]=events.enemyBowHit?1:0
  son[26]=events.ownCombo?1:0
  const actions=[Math.floor(random()*9),random()<.5?0:1,0,0,
    events.ownCombo?2:random()<.3?2:0,1,0,0,0]
  const pvp=pvpFromDual({actions})
  return frame({sonVector:son,pvpVector:pvp,events})
}

export function examples(count=384,seed=20261122){
  const random=next(seed),samples=[]
  for(let index=0;index<count;index++){
    const label=index%5===0?'silence':INTENTS[1+Math.floor(random()*(INTENTS.length-1))]
    const length=2+Math.floor(random()*7)
    const history=Array.from({length},(_,i)=>oneFrame(label,random,length-i-1))
    const name=botNames[Math.floor(random()*botNames.length)]
    samples.push({history,persona:persona(name),label:INTENTS.indexOf(label),name})
  }
  return samples
}
