import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import {fileURLToPath} from 'node:url'

export const HISTORY = 2
export const CHAT = 8
export const REPLY = 28
export const WIDTH = 32
export const HEADS = 4
const LEGACY = {history: HISTORY, chat: CHAT, reply: REPLY, width: WIDTH, heads: HEADS, context: 0}
export const CONTEXTUAL = {history: 4, chat: 24, reply: 36, width: 48, heads: 4, context: 8}
export const SPECIAL = ['<pad>', '<unknown>', '<start>', '<end>']
const compounds = new Set(('后撤 拉扯 走位 控距 预判 连招 节奏 换血 丝滑 暴击 盾反 格挡 盾牌 举盾 弓箭 重锤 水晶 竞技场 对战 按钮 中文 英文 准备 开打 继续 认了 极限 低血量 发言 帮忙 随时 可以 打得 敌人 疾跑 失灵').split(' '))
const suffixes = new Map([['fighting',['fight','ing']],['going',['go','ing']],['landed',['land','ed']]])
export function split(text) {
  const pieces = text.match(/[A-Za-z]+|\p{Script=Han}+|[^]/gu) ?? []
  return pieces.flatMap(part => {
    if (!/^\p{Script=Han}/u.test(part)) return suffixes.get(part) ?? [part]
    const chars = Array.from(part)
    const tokens = []
    for (let i = 0; i < chars.length;) {
      const word = [3,2].map(size => chars.slice(i,i+size).join('')).find(piece => compounds.has(piece))
      tokens.push(word ?? chars[i])
      i += word ? word.length : 1
    }
    return tokens
  })
}
export function promptIds(sample, vocabulary, capacity = CHAT) {
  const marker = sample.intent ? vocabulary.get(`<intent:${sample.intent}>`) : undefined
  const ids = split(sample.chat).slice(-(capacity - Number(marker !== undefined)))
    .map(token => vocabulary.get(token) ?? 1)
  const padded = [...Array(capacity - ids.length - Number(marker !== undefined)).fill(0), ...ids]
  return marker === undefined ? padded : [marker, ...padded]
}

export function eventInput(frame, contextWidth) {
  return contextWidth ? frame.event.concat(frame.replyContext ?? Array(contextWidth).fill(0)) : frame.event
}

export function compactCheckpoint(saved) {
  const scales = []
  const data = []
  for (const weight of saved.weights) {
    const peak = weight.values.reduce((max, value) => Math.max(max, Math.abs(value)), 0)
    const scale = peak ? peak / 127 : 1
    const bytes = Buffer.alloc(weight.values.length)
    weight.values.forEach((value, i) => bytes.writeInt8(Math.round(value / scale), i))
    scales.push({shape: weight.shape, scale})
    data.push(bytes)
  }
  const format = saved.config ? 'wavedog-reply-int8-v3' : 'wavedog-reply-int8-v2'
  const header = Buffer.from(JSON.stringify({format, tokens: saved.tokens, scales, config:saved.config}), 'utf8')
  const length = Buffer.alloc(4)
  length.writeUInt32LE(header.length)
  return Buffer.concat([length, header, ...data])
}

function projection(input, weight, bias) {
  const out = Float32Array.from(bias)
  for (let i = 0; i < input.length; i++)
    for (let j = 0; j < out.length; j++) out[j] += input[i] * weight[i * out.length + j]
  return out
}

function add(a, b) {
  return a.map((value, i) => value + b[i])
}

function normalize(input, scale, bias) {
  const mean = input.reduce((sum, value) => sum + value, 0) / input.length
  const variance = input.reduce((sum, value) => sum + (value - mean) ** 2, 0) / input.length
  const denominator = Math.sqrt(variance + 1e-5)
  return input.map((value, i) => (value - mean) / denominator * scale[i] + bias[i])
}

export function loadReplyModel(file) {
  const binary = fs.readFileSync(file)
  let offset = 4 + binary.readUInt32LE()
  if (offset > binary.length) throw Error('invalid checkpoint header')
  const {format, tokens, scales, config} = JSON.parse(binary.subarray(4, offset).toString('utf8'))
  const geometry = format === 'wavedog-reply-int8-v2' ? LEGACY : CONTEXTUAL
  if (!(format === 'wavedog-reply-int8-v2' ||
      format === 'wavedog-reply-int8-v3' && Object.keys(CONTEXTUAL).every(key=>config?.[key] === CONTEXTUAL[key]))
      || scales.length !== 26 || SPECIAL.some((token, i) => tokens[i] !== token))
    throw Error('unsupported checkpoint')
  const {history, chat:chatCapacity, reply:replyCapacity, width, heads, context:contextWidth} = geometry
  const prefix = history * 3 + chatCapacity
  if (scales[0].shape[0] !== 98 || scales[2].shape[0] !== 367 || scales[4].shape[0] !== 16 + contextWidth ||
      scales[24].shape[0] !== tokens.length || scales[24].shape[1] !== width ||
      scales[25].shape[0] !== prefix + replyCapacity || scales[25].shape[1] !== width)
    throw Error('checkpoint dimensions do not match the reply model')
  const weights = scales.map(({shape, scale}) => {
    const count = shape.reduce((n, dim) => n * dim, 1)
    const values = Float32Array.from({length: count}, (_, i) => binary.readInt8(offset + i) * scale)
    offset += count
    return values
  })
  if (offset !== binary.length) throw Error('checkpoint length mismatch')
  const words = new Map(tokens.map((token, i) => [token, i]))
  const vector = (table, index) => table.subarray(index * width, index * width + width)
  const layer = (input, i) => projection(input, weights[i], weights[i + 1])
  const headWidth = width / heads

  function decode(sample, {random = null, allowed = null, forced = null, observe = null} = {}) {
    if (sample.history?.length !== history || typeof sample.chat !== 'string') throw Error(`expected ${history} frames and a chat string`)
    const context = sample.history.flatMap(row => ['son', 'pvp', 'event'].map((key, i) => {
      const input = key === 'event' ? eventInput(row, contextWidth) : row[key]
      if (input?.length !== [98, 367, 16 + contextWidth][i] || !Array.from(input).every(Number.isFinite))
        throw Error('invalid ' + key + ' vector')
      return layer(input, i * 2)
    }))
    const chat = promptIds(sample, words, chatCapacity)
    const prompt = [...context, ...chat.map(id => vector(weights[24], id))]
      .map((token, i) => add(token, vector(weights[25], i)))
    const keys = prompt.map(token => layer(token, 8))
    const values = prompt.map(token => layer(token, 10))
    const reply = []
    let id = 2
    for (let step = 0; step < replyCapacity; step++) {
      const token = add(vector(weights[24], id), vector(weights[25], prefix + step))
      const query = layer(token, 6)
      keys.push(layer(token, 8))
      values.push(layer(token, 10))
      const attention = new Float32Array(width)
      for (let h = 0; h < heads; h++) {
        const start = h * headWidth
        const scores = keys.map(key => {
          let dot = 0
          for (let j = start; j < start + headWidth; j++) dot += query[j] * key[j]
          return dot / Math.sqrt(headWidth)
        })
        const peak = Math.max(...scores)
        const mass = scores.map(score => Math.exp(score - peak))
        const total = mass.reduce((sum, value) => sum + value, 0)
        values.forEach((value, i) => {
          for (let j = start; j < start + headWidth; j++) attention[j] += value[j] * mass[i] / total
        })
      }
      const first = normalize(add(token, layer(attention, 12)), weights[18], weights[19])
      const ff = layer(first, 14).map(value => Math.max(0, value))
      const state = normalize(add(first, layer(ff, 16)), weights[20], weights[21])
      const next = allowed?.(id, step)
      if (next && !next.size) return ''
      const scores = layer(state, 22)
      id = forced ? forced[step] : choose(scores, random, next, tokens)
      observe?.(id,scores)
      if (id === 3) break
      if (step === replyCapacity - 1) return ''
      reply.push(tokens[id])
    }
    return reply.join('')
  }

  function trace(sample, forced = null) {
    if(forced && (!forced.length || forced.at(-1)!==3 || forced.length>replyCapacity ||
        forced.some(id=>!Number.isInteger(id)||id<3||id>=tokens.length)))throw Error('invalid reply token sequence')
    const steps = []
    const text = decode(sample,{forced,observe(id,scores){
      let maximum = -Infinity
      for(let index=3;index<scores.length;index++)
        if(!tokens[index].startsWith('<intent:'))maximum=Math.max(maximum,scores[index])
      let sum = 0
      for(let index=3;index<scores.length;index++)
        if(!tokens[index].startsWith('<intent:'))sum+=Math.exp(scores[index]-maximum)
      steps.push({id,token:tokens[id],logProbability:scores[id]-maximum-Math.log(sum)})
    }})
    return {text,steps}
  }
  return {generate:(sample,random,allowed)=>decode(sample,{random,allowed}),
    trace, vocabulary:words, history, embeddingWidth:width}
}

export function choose(scores, random, allowed = null, tokens = null) {
  const ranked = Array.from(scores, (score, id) => ({score, id})).slice(3)
    .filter(({id}) => !tokens?.[id].startsWith('<intent:') && (!allowed || allowed.has(id)))
    .sort((a, b) => b.score - a.score)
  if (!ranked.length) return 3
  if (!random) return ranked[0].id
  const candidates = ranked.slice(0, allowed ? 6 : 3)
  const temperature = allowed ? 1.10 : .72
  const weights = candidates.map(candidate => Math.exp((candidate.score - ranked[0].score) / temperature))
  let draw = random() * weights.reduce((sum, weight) => sum + weight, 0)
  return (candidates.find((_, i) => (draw -= weights[i]) <= 0) ?? ranked[0]).id
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (!process.argv[2]) throw Error('usage: node generation-runtime.mjs model.bin < input.jsonl')
  const model = loadReplyModel(process.argv[2])
  for await (const line of readline.createInterface({input: process.stdin, crlfDelay: Infinity})) {
    try {
      const text = model.generate(JSON.parse(line))
      console.log(JSON.stringify({said: Boolean(text), text}))
    } catch (error) {
      console.log(JSON.stringify({error: error.message}))
    }
  }
}
