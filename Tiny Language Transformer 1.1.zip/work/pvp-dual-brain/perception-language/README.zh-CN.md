# WaveDog 感知 Transformer：核心代码与使用教程

## 0. 这是谁的思路，目前做到了哪里

这个架构来自 **WaveJ 提出的创新思路**：让 Son 和现有 PvP Transformer 的向量协作，由一个小型感知 Transformer 决定 PvP 场景下何时说话、用什么玩家口吻说话。未来它可以发展为全局模式选择器；本版只输出 PvP 台词，不发战斗动作，也不切换生存模式。

本目录提供可运行的 **v1 原型**：向量接口、Transformer、训练脚本、检查点、离线推理和语义约束。训练样本是按你的口吻要求由当前助手整理的 PvP 情境种子及合成扰动。它们不是足以证明真人聊天质量的样本；上线前还要用真实对局片段、人工修订台词和未见过的玩家做盲测。

## 1. 一眼看懂数据流

```mermaid
flowchart LR
    S[Son 公共观测 98 维] --> P[三路向量投影]
    T[PvP GRU 64 + GTrXL 256 + 动作头 47] --> P
    E[公开 PvP 事件 16 维] --> P
    P --> H[最近 8 次观察的 Transformer]
    I[机器人个性 4 维] --> H
    H --> C[12 类说话意图 / 沉默]
    C --> G[事件真实性检查 + 8 秒冷却]
    G --> W[多样化 PvP 短句]
```

一个完整输入是：

```js
{
  speaker: 'WaveDogSon',
  sonVector: Array(98),
  pvpVector: Array(367),
  events: { enemyBowHit: true }
}
```

`sonVector` 与现有 `nativeObservation()` 的 98 维约定一致。`pvpVector` 的前 64 维放 GRU 隐状态，随后 256 维放 GTrXL 慢分支输出，最后 47 维放九个动作头的概率。当前冻结推理接口只公开动作索引，因此 `pvpFromDual({actions})` 能先把这 47 维做成独热向量；前 320 维留空。**留空向量不等于模型已经理解那 320 维**。未来暴露真正隐向量后，必须用其真实分布重训语言模型。

`events` 只允许填入已经观察或结算的事实，例如“对手的箭实际命中”“对局已经结束”。没有这条事实，模型即便猜到了相应意图，文本层也会拒绝说“好弓箭”或“gg”。

## 2. 核心代码逐步读

### 第一步：把两个战斗向量接起来

看 [`dialogue.js`](./dialogue.js) 的 `pvpFromDual()`、`frame()`、`toTensors()`。

```js
const pvp = pvpFromDual({fast, slow, probabilities})
const row = frame({sonVector, pvpVector:pvp, events})
const input = toTensors([{history:[row], persona:persona('WaveDogSon')}])
```

`pvpFromDual()` 校验长度，并把三段向量拼成 367 维。`frame()` 再把 16 个事件布尔量变成固定顺序的事件向量。`toTensors()` 维护最近 8 次观察；历史不够时在前面补零，得到模型需要的张量形状：

| 张量 | 形状 | 含义 |
| --- | --- | --- |
| `son` | `[批量, 8, 98]` | Son 可见战况 |
| `pvp` | `[批量, 8, 367]` | PvP 模型的向量与动作头 |
| `event` | `[批量, 8, 16]` | 已确认的 PvP 事件 |
| `persona` | `[批量, 4]` | Son / Brother / Father / Sister 身份 |

一名机器人只保留自己的 8 帧短时记忆；所有机器人可以共用一份权重。这样不会把 Son 的对手、Sister 的对手或不同对局的历史混在一起。

### 第二步：注意力怎样读这些向量

看 [`model.js`](./model.js) 中的 `Dense`、`AttentionBlock.apply()` 和 `PerceptionTransformer.logits()`。

```js
const tokens = tf.stack([
  this.son.apply(son),
  this.pvp.apply(pvp),
  this.event.apply(event)
], 2).reshape([batch, 8 * 3, width])
```

每个时间点变成三个 token：Son、PvP、事件。再加一个 `[CLS]` 汇总 token 和一个身份 token，总数为 26。位置向量保留先后顺序。注意力层做四件事：

1. `q/k/v` 线性投影，把每个 token 映射成“我要找什么 / 我有什么 / 我要传什么”；
2. `softmax(QKᵀ / √d)` 算各 token 的关联程度；
3. 把关联到的信息加权合并，再做残差、归一化和前馈层；
4. 取 `[CLS]` 的最终向量，送进 12 类意图输出头。

默认结构是 4 层、宽 128、4 个注意力头。它比通用 1.5B 语言模型小得多；这也意味着它只能做经过训练和约束的 PvP 短句选择，不能取代通用聊天模型。

`eventHead` 还从最新的 16 维已确认事件直接预测意图，再与 Transformer 的 `[CLS]` 预测相加。它让罕见的真实命中事件不会淹没在 26 个历史 token 中；长时序的权衡仍由 Transformer 学习。

### 第三步：说不说，以及具体说什么

看 [`dialogue.js`](./dialogue.js) 的 `INTENTS`、`PHRASES`、`REQUIRED` 和 `speak()`。12 类包含 `silence`、`nice_bow`、`retreat_roast`、`gg_win`、`gg_loss`、`tilt` 等。

模型只决定意图。短句从同意图的多种玩家说法中选：例如对手实际后撤时可以说“666后撤怪”“跑男来了”“你跑尼玛个东方明珠塔跑”；对手的箭确实命中后可以说“好弓箭”“弓狗”。`tilt` 类可以出现“LL”“也够”“野狗”，但必须有对手后撤且自己血量吃紧的局势。社区用语整理及逐条触发条件见 [`COMMUNITY-PHRASES.zh-CN.md`](./COMMUNITY-PHRASES.zh-CN.md)；`ez`、`L`、`git gud`、`?` 和笑脸只在已获胜的结算场景中作为候选，`not even close` 只在自己低血量时作为反讽候选。当前短句库共 112 条。

`REQUIRED` 是事实校验：胜局 `gg` 要有对局结束和胜利；夸箭要有箭命中；夸重锤要有对手重锤命中。`speak()` 还限制 8 秒内重复发言、18 秒内重复同一意图，避开每帧刷屏和机械播报。这里不接收任意聊天文本，输出也只能落在 PvP 短句库内。

### 第四步：训练、保存和恢复

[`teacher.js`](./teacher.js) 把整理好的情境与正确意图组成初始教师样本；[`train.js`](./train.js) 每步重新扰动距离、血量、动作和身份，用交叉熵训练模型。权重写到 `outputs/pvp-perception-language/checkpoint.json`，训练指标写到同目录 `training-report.json`。

```js
const cost = optimizer.minimize(() => tf.tidy(() => {
  const truth = tf.oneHot(labels, INTENTS.length)
  return tf.mean(tf.losses.softmaxCrossEntropy(truth, model.logits(input)))
}), true, model.params)
```

`model.snapshot()` 保存每个权重的形状和值；`model.restore()` 严格比对模型结构与形状后恢复。这个“保存→恢复→相同输出”的检查在 `test.js` 中已经验证。

`syntheticHoldoutAccuracy` 只衡量合成情境的识别率。要评估真人效果，应按**整场对局**划分训练/验证，不可把同一局的相邻帧分别放进两边；记录无意义发言率、事实错误率、重复率、说话延迟与服务器 TPS，再让真人盲评自然度。

### 第五步：离线推理

[`infer.js`](./infer.js) 中的 `DialogueEngine` 为每个机器人维持各自历史，调用模型得到意图概率，再做事件校验和短句选择。没有足够置信度、事件不符合、或者还在冷却期时返回 `said:false`。调用方只在 `said:true` 时把 `text` 发进游戏聊天。

```js
const engine = new DialogueEngine('outputs/pvp-perception-language/checkpoint.json')
const result = engine.decide({speaker:'WaveDogSon',sonVector,pvpVector,
  events:{enemyBowHit:true}})
if (result.said) console.log(result.text)
engine.reset('WaveDogSon') // 对局切换时清掉短时记忆
engine.dispose()
```

## 3. 本机怎么运行

在 `D:\CodexWorkspace\ban` 运行；Node 使用现有 `E:\node\node.exe`，依赖使用现有 `work/pvp-dual-brain/node_modules`。

```powershell
& 'E:\node\node.exe' work/pvp-dual-brain/perception-language/test.js
& 'E:\node\node.exe' work/pvp-dual-brain/perception-language/train.js 160 128 4
& 'E:\node\node.exe' work/pvp-dual-brain/perception-language/demo.js
```

训练命令的三个数字分别是训练步数、隐藏宽度和层数。默认宽度 128、4 层，头数固定为 4。完成后查看 `outputs/pvp-perception-language/training-report.json`。`demo.js` 会同时输出模型在合成局势下的选择，以及由事实门槛允许的台词示例；模型选择沉默时，不应把示例句误当成模型实际发言。

当前默认模型实际训练了 120 步，共 **860,888 个参数**；JSON 检查点 **17,906,030 字节，低于 25 MB**。合成留出集 95/96 个意图正确（98.96%）。这是同一教师规则生成的留出集，不能解释为真人胜率或聊天自然度。

运行 `python work/pvp-dual-brain/perception-language/package.py` 可重新生成 `outputs/pvp-perception-language/WaveDog-Perception-Transformer-v1.zip`。交付包包含源码、模型、训练报告和 Java 桥接源码，压缩后约 **7.9 MB**；它使用本机已有的 Node.js 和 TensorFlow.js 依赖，包内不包含这些运行时依赖。

也可以给 `infer.js` 逐行喂 JSON，每行含 `speaker`、98 维 `sonVector`、367 维 `pvpVector` 和 `events`：

```powershell
Get-Content .\输入.jsonl | & 'E:\node\node.exe' work/pvp-dual-brain/perception-language/infer.js
```

要用现有 Son 对局记录做**离线回放**，运行：

```powershell
$trace = (Get-ChildItem work/wavedog-son/runtime -Filter '*native-frames.jsonl' | Select-Object -First 1).FullName
& 'E:\node\node.exe' work/pvp-dual-brain/perception-language/replay-native.js $trace WaveDogSon outputs/pvp-perception-language/checkpoint.json 1000
```

回放只写 `outputs/pvp-perception-language/replay.jsonl`，不发游戏聊天。一次现有 748 帧 Son 对局的回放产生了 2 句（开局和实际连击），没有逐帧播报。当前回放使用已有冻结模型的九个动作索引作 47 维独热向量；真正的 320 维内部隐状态仍待模型接口开放及重训。

## 4. 接到真正的 WaveDog 时怎么写

1. `PerceptionDialogueBridge.java` 在服务端接收已结算的公开对局帧，放进有界异步队列。它不会在 Bukkit 主线程运行模型。
2. [`live-worker.js`](./live-worker.js) 通过 `nativeObservation(frame, config)` 得到 Son 兼容的 98 维向量，从现有冻结 PvP 模型的九个动作索引得到最后 47 维独热向量。当前主服尚未导出 GRU/GTrXL 的 320 维内部隐状态，因此这段仍是零。未来导出后，调用 `pvpFromDual({fast,slow,probabilities})` 并用真实分布重训。
3. Worker 为每名机器人和每场对局保存独立历史。服务端按低频与已结算事件送帧，模型只回传 `said:true` 的短句；Java 在主线程用机器人玩家身份发送。桥接故障只使发言停用，战斗策略和裁判继续运行。
4. 服务端配置 `plugins/WaveDogNativeControl/config.yml` 中的 `dialogue-enabled: true` 开启发言；改为 `false` 可关闭。现有 `/qwen` 仍是独立自由问答插件，不被此模型替换。
5. 收集“局势摘要→候选意图→实际发言→真人反馈”审计记录，再用真人修订语料训练。不要把目前的合成样本分数称为实战自然度。

### 局内教学与玩家聊天

新版在玻璃罩准备期每局至少发一句随机开场话，并以随机间隔做蹲起、跳跃、挥手动作；倒计时剩 1 秒时停止招呼、转向对手，玻璃罩消失后才执行战斗策略。感知模型选择沉默时，首个准备期观测会从同一开场语料中随机补一句；同局不会重复补发。玻璃罩内不会攻击。

和机器人对战的 OP 玩家可在聊天框输入：

```text
/wdnative teach sister 重锤 这锤可以
/wdnative teach father 水晶 这颗水晶有东西
/wdnative teach son 弓箭 好箭
/wdnative teach sister 开局 来，碰一把
/wdnative quiet sister
```

`teach` 的参数依次是机器人、情境、希望它说的短句。机器人可用 `son`、`brother`、`father`、`sister` 或全名；情境可用 `开局`、`后撤`、`弓箭`、`重锤`、`水晶`、`连招`、`盾`、`残血`、`赢`、`输`、`上头`，也可用 `INTENTS` 里的英文名。`quiet` 表示此刻应该安静。命令只接受当前对手本人在准备期前 9 秒或交战中提交的样本。只有战况帧确实包含相应事件，教学才生效；例如没有重锤命中就不会把“这锤可以”当作已发生事实。游戏里会收到生效或拒绝的回执。

`WaveDogChatSense` 只收集当前对局对手在准备期和交战中的普通聊天。`live-worker.js` 把最近 8 秒的玩家消息作为局内教学的上下文。`online-trainer.js` 是独立 Node 工作线程；它只更新感知 Transformer 的发言头与小型聊天特征权重，不占用 Minecraft 战斗线程。每条有效教学保存到 `online-examples.jsonl`，权重增量原子写入 `online-adapter.json`，发言进程收到更新后立即应用；重启时会继续读取。基础检查点保持不变，错误教学可从备份恢复适配器。

当前聊天特征用字符和二字片段哈希，能把相近的玩家说法映射到类似发言意图；输出仍受已确认 PvP 事件与短句库约束。它已经能读取并利用玩家消息，但**还不是自由生成文字的语言模型**。直接聊天不会被当成正确答案自动训练，必须用教学命令确认希望的回应。完整生成器仍需更多真人标注、训练和独立验证。

游戏内桥接已在隔离 Paper 服验证：Sister 通过原生玩家聊天事件发出 1 句，文本没有 Unicode 损坏；同期风弹与重锤动作仍通过原版机制。实际主服也已验证新版桥接启动，日志出现 `Local PvP perception speech ready`，五名原生角色加载且状态无失败，随后正常停服。主服验证仅证明模型成功加载，不代表已经通过真人对局发言测试。这个模型没有任何模式切换权限。未来可把 `intent` 和状态摘要送给你预告的全局 Transformer，但那是另一个阶段。

## 5. 改出更像玩家的话，应该改哪里

- 要加“好弓箭”“gg”“LL”一类短句：改 `dialogue.js` 的对应 `PHRASES`。只改台词不会改模型权重。
- 要加“鼠标失灵了？”一类句子：先实现可核验的对手空挥事件并增加训练情境；现在只把它记在社区语录文档，避免误说。
- 要加新的说话情境：先加 `EVENTS`、`INTENTS` 和 `REQUIRED`，然后在 `teacher.js` 给出正反例，重训并更新检查点。事件必须能从真实 PvP 回执得到。
- 要让 Father/Sister 说话气质不同：调整 `persona()` 与每个意图下的短句分布，再用分机器人语料训练；四个实例仍可共用权重。
- 要改成长句自由生成：需要更多真实标注和文本解码器。先保证短句版事实正确、节奏自然，再扩展；直接拿几句样例训练开放式生成会快速重复和胡说。

最关键的边界是：**感觉像玩家**来自情境选择、说话节奏与语言变化；**可信**来自原版事件回执与发言门槛。两者都需要真实玩家反馈才能调到位。
