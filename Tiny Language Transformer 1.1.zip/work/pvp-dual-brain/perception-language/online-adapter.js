import fs from 'node:fs'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {INTENTS,PHRASES} from './dialogue.js'

export const INTENT_ALIASES=Object.freeze({
  quiet:'silence',安静:'silence',开局:'opener',后撤:'retreat_roast',弓箭:'nice_bow',
  重锤:'nice_mace',水晶:'nice_crystal',连招:'combo_hype',盾:'shield_respect',
  残血:'clutch',赢:'gg_win',输:'gg_loss',上头:'tilt'
})
export const intentName=value=>{
  const name=INTENT_ALIASES[value]||value
  return INTENTS.includes(name)?name:null
}
export const CHAT_WIDTH=256
export function chatFeatures(message=''){
  const text=String(message).normalize('NFKC').toLowerCase().trim().slice(0,160)
  const features=new Array(CHAT_WIDTH).fill(0)
  if(!text)return features
  for(let width=1;width<=2;width++)for(let i=0;i+width<=text.length;i++){
    const gram=text.slice(i,i+width)
    if(/^\s+$/u.test(gram))continue
    let hash=2166136261
    for(let j=0;j<gram.length;j++)hash=Math.imul(hash^gram.charCodeAt(j),16777619)
    features[(hash>>>0)%CHAT_WIDTH]++
  }
  const norm=Math.hypot(...features)||1
  return features.map(value=>value/norm)
}
export function chatBias(adapter,message=''){
  const features=chatFeatures(message),bias=new Array(INTENTS.length).fill(0)
  if(!adapter?.chatWeights)return bias
  for(let i=0;i<CHAT_WIDTH;i++)if(features[i])for(let j=0;j<INTENTS.length;j++)
    bias[j]+=features[i]*adapter.chatWeights[i*INTENTS.length+j]
  return bias
}
export const baseHash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')

const headParameters=model=>[...model.head.params,...model.eventHead.params]
export function makeAdapter(model,hash){
  return {schema:'wavedog-perception-online-v1',baseSha256:hash,revision:0,trainedExamples:0,
    processedOffset:0,
    weights:headParameters(model).map(p=>({shape:p.shape,values:[...p.dataSync()]})),
    chatWeights:new Array(CHAT_WIDTH*INTENTS.length).fill(0),phrases:{},seenIds:[]}
}
export function applyAdapter(model,adapter,hash){
  if(adapter?.schema!=='wavedog-perception-online-v1'||adapter.baseSha256!==hash)
    throw Error('online adapter does not match base model')
  const params=headParameters(model)
  if(adapter.weights.length!==params.length)throw Error('online head count mismatch')
  if(!Array.isArray(adapter.chatWeights)||adapter.chatWeights.length!==CHAT_WIDTH*INTENTS.length
    ||adapter.chatWeights.some(x=>!Number.isFinite(x)))throw Error('invalid online chat weights')
  for(let i=0;i<params.length;i++){
    const saved=adapter.weights[i],parameter=params[i]
    if(JSON.stringify(saved.shape)!==JSON.stringify(parameter.shape)
      ||saved.values.length!==parameter.size||saved.values.some(x=>!Number.isFinite(x)))
      throw Error('invalid online head '+i)
    const tensor=tf.tensor(saved.values,saved.shape)
    parameter.assign(tensor);tensor.dispose()
  }
  for(const [intent,phrases] of Object.entries(adapter.phrases||{})){
    if(!PHRASES[intent]||!Array.isArray(phrases))throw Error('invalid online phrase intent')
    for(const phrase of phrases){
      if(typeof phrase!=='string'||phrase.length<1||phrase.length>40||/[\r\n\u0000-\u001f]/u.test(phrase))
        throw Error('invalid online phrase')
      if(!PHRASES[intent].includes(phrase))PHRASES[intent].push(phrase)
    }
  }
}
export function captureAdapter(model,adapter){
  adapter.weights=headParameters(model).map(p=>({shape:p.shape,values:[...p.dataSync()]}))
  return adapter
}
