"""Package the shared WaveDog speech worker without combat data or player logs."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
workspace = root.parents[2]
output = workspace / 'outputs/pvp-perception-language'
sources = [file for file in root.iterdir()
    if file.suffix in ('.js', '.mjs', '.md', '.py')]
dependencies = [root.parent / name for name in ('package.json', 'package-lock.json',
    'native-observation.js', 'technique-conditioning.js', 'combat-observation.js')]
artifacts = [output / name for name in ('checkpoint.json', 'training-report.json', 'reply.int8.bin',
    'reply-context.int8.bin', 'contextual/report.json', 'contextual/sample-input.jsonl',
    'contextual/tokenized-supervision.jsonl')]
files = {file.relative_to(workspace).as_posix(): file.read_bytes()
    for file in sources + dependencies + artifacts}
files['README.zh-CN.md'] = (root / 'CONTEXTUAL.zh-CN.md').read_bytes()
files['integration/PerceptionDialogueBridge.java'] = (workspace /
    'outputs/wavedog-brother-release/work/wavedog-native/src/local/wavedog/nativecontrol/PerceptionDialogueBridge.java').read_bytes()
files['integration/ChatSense.java'] = (workspace /
    'work/wavedog-chat-sense/src/local/wavedog/chatsense/ChatSense.java').read_bytes()
files['integration/WaveDogChatSense.jar'] = (workspace /
    'outputs/pvp-perception-language/token-release/plugins/WaveDogChatSense.jar').read_bytes()
manifest = {'ideaBy': 'WaveJ', 'scope': 'PvP and lobby dialogue for WaveDog',
    'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
archive = output / 'Tiny Language Transformer WaveDog.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipfile_out:
    for name, data in sorted(files.items()):
        zipfile_out.writestr(name, data)
    zipfile_out.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
assert archive.stat().st_size < 25_000_000, archive.stat().st_size
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
    'checkpointBytes': (output / 'checkpoint.json').stat().st_size,
    'files': len(files)}, ensure_ascii=False))
