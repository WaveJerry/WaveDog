import assert from 'node:assert/strict'
import fs from 'node:fs'
import {canSpeak, frame, PHRASES, speak} from './dialogue.js'
import {createTokenSpeech, tokenTransitions} from './generation-live.js'
import {loadReplyModel,split} from './generation-runtime.mjs'
import {eventQuestion} from './generation-context.js'
import {tokenAttribution} from './reply-attribution.mjs'

const file=process.argv[2]
assert(file,'pass the trained reply.int8.bin path')
const model=loadReplyModel(file)
const speech=createTokenSpeech(file)
const cases={
  opener:{boutStart:true},retreat_roast:{enemyRetreat:true},nice_bow:{enemyBowHit:true},
  nice_mace:{enemyMaceHit:true},nice_crystal:{enemyCrystalHit:true},combo_hype:{ownCombo:true},
  shield_respect:{enemyShield:true},clutch:{ownLowHealth:true},
  gg_win:{boutEnd:true,won:true},gg_loss:{boutEnd:true,lost:true},tilt:{ownLowHealth:true,enemyRetreat:true}
}
const fixture=(events={},health=1)=>{
  const son=Array(98).fill(0)
  son[0]=health;son[2]=son[31]=1
  return frame({sonVector:son,pvpVector:Array(367).fill(0),events})
}
let corpusSize=0
for(const [intent,phrases] of Object.entries(PHRASES)){
  assert(cases[intent]&&canSpeak(intent,cases[intent]),intent)
  for(const phrase of phrases){
    const tokens=split(phrase)
    assert.equal(tokens.join(''),phrase)
    assert(tokens.every(token=>model.vocabulary.has(token)),phrase)
    corpusSize++
  }
  const events=cases[intent],low=Boolean(events.ownLowHealth)
  const history=[fixture(),fixture(events,low ? .2 : 1)]
  const input={intent,history,events,chat:'',shieldBlocked:true,low,lastText:null,random:null}
  assert(speech.battle(input),intent+' failed to generate')
  assert.equal(speech.battle({...input,events:{}}),null)
}
assert.equal(speech.battle({intent:'shield_respect',history:[fixture()],events:{enemyShield:true},
  chat:'',shieldBlocked:false,low:false,lastText:null,random:null}),null)
assert.equal(speak('opener',{boutStart:true},{},Date.now(),Math.random,()=>null),null)
for(const prompt of ['你好','怎么开打','你会什么'])assert(speech.lobby(prompt),prompt)
assert.equal(speech.lobby('今天天气如何'),null)

const examples=['这箭挺准，继续打。','这箭挺准，还能接着打。','这箭漂亮，继续打。']
const unseen='这箭漂亮，还能接着打。'
assert(!examples.includes(unseen))
const transitions=tokenTransitions(model.vocabulary,examples)
let prev=2
for(const next of [...split(unseen).map(token=>model.vocabulary.get(token)),3]){
  assert(transitions(prev).has(next),'missing compositional transition')
  prev=next
}
const history=[fixture(),fixture({enemyBowHit:true})]
const random=seed=>{
  let state=seed
  return ()=>((state=(Math.imul(state,1664525)+1013904223)>>>0)/4294967296)
}
const variety=new Set(Array.from({length:160},(_,i)=>model.generate(
  {history,chat:'请讲中文',intent:'nice_bow'},random(701+i*997),transitions)))
const novel=[...variety].filter(text=>text&&!examples.includes(text))
assert(novel.includes(unseen),'decoder did not generate the held-out combination')
const [contextualFile,samplesFile]=process.argv.slice(3)
if(contextualFile){
  const contextual=loadReplyModel(contextualFile)
  const integrated=createTokenSpeech(file,null,contextualFile)
  const samples=fs.readFileSync(samplesFile,'utf8').trim().split(/\r?\n/u).map(JSON.parse)
  const expectations=[/没多远/u,/这么远/u,/两下/u,/三下/u,/挡着|打在盾/u,/两下/u]
  assert.equal(samples.length,expectations.length)
  samples.forEach((sample,index)=>{
    const latest=sample.history.at(-1)
    const input={...sample,events:latest.events,shieldBlocked:true,directQuestion:true}
    assert.equal(eventQuestion(sample.chat),sample.intent)
    assert.match(integrated.battle(input),expectations[index])
    assert.equal(integrated.battle({...input,events:{}}),null)
    const audit=tokenAttribution(contextual,sample)
    assert.equal(audit.tokens.map(row=>row.token).join(''),audit.text)
    assert.equal(audit.embeddingWidth,48)
    assert(audit.tokens.some(row=>row.vectors.length>0))
  })
}
console.log(JSON.stringify({passed:true,corpusSize,intents:Object.keys(cases).length,novel:unseen,
  distinctReplies:[...variety].filter(Boolean).length,contextual:Boolean(contextualFile)}))
