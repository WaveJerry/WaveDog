// Same 98-channel normalization as CombatLearner.features + the existing v2
// combat/technique adapters. Only immutable accepted server observations enter.
import {conditionCombatObservation} from './combat-observation.js'
import {conditionTechniqueObservation} from './technique-conditioning.js'
export function nativeObservation(f,config){
 const s=f.self,o=f.seen,tick=f.tick,x=Array(98).fill(0),r=(s.nativeYaw??180-(s.yaw??Math.PI)*180/Math.PI)*Math.PI/180,si=Math.sin(r),co=Math.cos(r)
 const wrap=v=>((v+180)%360+360)%360-180
 x[0]=s.health/20;x[1]=s.charge;x[2]=Number(s.ground);x[3]=s.vx*co+s.vz*si;x[4]=s.vy;x[5]=-s.vx*si+s.vz*co
 x[6]=Number(s.shieldAvailable);x[7]=Number(s.shielding);x[8]=Number(s.using);x[9]=s.useTicks/25
 x[10]=s.arrows/5;x[11]=Number(s.crossbowLoaded);x[12]=s.held/8;x[13]=(s.nativePitch??0)/90;x[14]=si;x[15]=co
 x[16]=(s.y-(f.targetFloorY??s.y))/4;x[17]=Math.min(1,tick/2400)
 if(o.visible){const dx=o.x-s.x,dz=o.z-s.z
  x[18]=Math.tanh((dx*co+dz*si)/6);x[19]=Math.tanh((o.y-s.y)/3);x[20]=Math.tanh((-dx*si+dz*co)/6)
  x[21]=Math.sin(((o.nativeYaw??0)-(s.nativeYaw??0))*Math.PI/180);x[22]=Math.cos(((o.nativeYaw??0)-(s.nativeYaw??0))*Math.PI/180)
  x[23]=Number(f.observation.targetShieldRaised);x[24]=Number(o.using);x[25]=0
  x[26]=Number((o.held||'').includes('SWORD'));x[27]=Number((o.held||'').includes('AXE'));x[28]=Number(o.held==='BOW');x[29]=Number((o.held||'').includes('CROSSBOW'));x[30]=0;x[31]=1
  x[78]=wrap(Math.atan2(-dx,dz)*180/Math.PI-(s.nativeYaw??0))/180
  x[79]=(-Math.atan2(o.y+1-s.eyeY,Math.hypot(dx,dz))*180/Math.PI-(s.nativePitch??0))/90
 }
 for(const [i,a] of (o.arrows||[]).slice(0,4).entries()){const z=32+6*i,dx=a.x-s.x,dz=a.z-s.z
  x[z]=Math.tanh((dx*co+dz*si)/12);x[z+1]=Math.tanh((a.y-s.y)/6);x[z+2]=Math.tanh((-dx*si+dz*co)/12)
  x[z+3]=(a.vx*co+a.vz*si)/4;x[z+4]=a.vy/4;x[z+5]=(-a.vx*si+a.vz*co)/4
 }
 const walls=f.publicTerrain?.walls||[0,0,0,0];walls.forEach((d,i)=>x[56+i]=Math.min(1,d/8));x[73]=1
 for(let i=0;i<12;i++)x[60+i]=f.previousObservation?.[18+i]??0
 x[96]=0;x[97]=Math.tanh((f.observation.reach-3)/.75)
 const bounded=x.map(v=>Number.isFinite(v)?Math.max(-3,Math.min(3,v)):0)
 return conditionTechniqueObservation(conditionCombatObservation(bounded,f,config),'CRITICAL',['COMBO'],null,{...f.publicTerrain,selfY:s.y})
}
