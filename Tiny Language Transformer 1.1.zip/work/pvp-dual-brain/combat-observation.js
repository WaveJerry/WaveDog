// New-policy-only own-state channels. Older checkpoints remain byte compatible.
export function conditionCombatObservation(observation,request,config={}){
  if(config.combatObservationVersion!==2)return observation
  const x=[...observation],s=request.self||{},clip=(v,n)=>Number.isFinite(v)?Math.max(0,Math.min(1,v/n)):0
  const values=[Number(Boolean(s.sprint)),Number(Boolean(s.wireFalling)),Number(s.wireGround===true),
    Number(typeof s.wireGround==='boolean'),clip(s.attackAgeTicks,25),clip(s.weaponAgeTicks,25),
    clip(s.fallDistance,3),Number(Number.isFinite(s.fallDistance)),Number(Boolean(s.critical)),
    clip(s.food,20),Number(s.attackAgeTicks!==undefined),Number(s.weaponAgeTicks!==undefined)]
  values.forEach((v,i)=>{x[60+i]=v})
  return x
}
