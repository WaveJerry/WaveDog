# wavedog 我的世界pvp机器人

WaveDog 的 Minecraft 盾斧 PVP 实验项目：协议玩家、战斗观测与预测、8.6 控制器适配，以及 Transformer/GRU 训练和评估工具。

## 这份快照

本仓库导出自已校验的「盾斧pvp无敌版」运行备份，控制器版本为 `8f53c747896306754eaf249bb742735a60be152de4ca783713ecf925fa1f828f`。它与该备份版本对应，不包含之后的落地交接修复。

本版本实战执行的是 **8.6 Java 控制逻辑 + JS 协议适配和公开威胁预测**；保存了神经模型相关源码，当前执行路径没有改成 Transformer 权重决策。500 Hz 是本地监测目标，不代表服务器每秒有 500 次新状态，也没有实战零失误保证。

## 目录

- `work/pvp-player-client/`：协议玩家、运动监测、威胁预测、发包节流、执行与回归测试。
- `work/legacy86-reference/src/`：原版 8.6 Java 运行桥接源码。
- `work/pvp-dual-brain/`：Transformer/GRU 模型、训练、评估与复盘工具。
- `work/wavedog-punengbho/`：独立模型身份的服务启动辅助脚本；游戏名为 WaveDog。
- `docs/DISTRIBUTION.md`：源码、模型和可启动运行包的发布方法。
- `SOURCE_MANIFEST.json`：所选源码的 SHA256 清单。

## 开发和运行

Node 依赖由两份 `package-lock.json` 固定版本，可分别在 `work/pvp-player-client` 和 `work/pvp-dual-brain` 执行 `npm ci` 安装。

这是一份源码与训练工具快照，**不是解压即可开服的包**。从源码运行还需要相应插件、8.6 参考 JAR、模型、服务器和本地配置；Java 桥接源码不等于所有服务器插件的完整源码。历史启动/部署脚本含原开发机路径，使用前需配置，不能直接当成通用安装器运行。

需要直接开服时使用单独发布的运行包，解压执行 `start.cmd`。完整私人备份还包含服务器凭据与玩家数据，不能直接作为公开 Release；公开运行包须使用新的空白配置与自行取得的依赖。

## Git 管理范围

只跟踪源码、依赖锁文件、文档和匿名化测试观测。模型权重、优化器、Java/Node/Python 运行环境、`node_modules`、服务器世界、对局录像、日志和真实认证信息不进入 Git 历史。

未在这次导出中新增开源许可证；第三方组件遵循各自许可证。
