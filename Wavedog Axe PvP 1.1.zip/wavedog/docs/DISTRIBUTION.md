# GitHub 发布安排

仓库 slug 建议 `wavedog`，README 标题和仓库简介为「wavedog 我的世界pvp机器人」。

## GitHub 限制

- 网页上传仓库单文件上限 25 MiB。
- 普通 Git 超过 50 MiB 警告，超过 100 MiB 拒绝。
- 官方建议仓库最好小于 1 GB，强烈建议小于 5 GB。
- Release 的每个附件须小于 2 GiB；与 Git 文件限制不同。
- Git LFS 能管理大文件，但有存储、下载流量及套餐限制，删除普通 Git 文件也不会自动清掉历史里的大文件。

来源（2026-11-19 核对）：
- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
- https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases

## 当前备份

当前私人备份 ZIP 为 1,832,754,688 字节，约 1.71 GiB，低于 Release 单附件上限。它含真实认证配置、控制令牌和服务器数据，留作私人完整备份，不直接公开上传。

其中 Qwen GGUF 原文件约 1.04 GiB，ZIP 后仍约 1.02 GiB；它已经量化，重新压缩不能保证明显缩小。服务器 JAR 等也已压缩。

## 推荐布局

1. Git 仓库只提交本目录源码；不提交完整备份 ZIP。
2. 模型和可启动运行包单独作为 Release 附件，或从其原始来源下载；有不同版本时标明对应控制器与 SHA256。
3. 若制作更小运行包：依赖通过安装器按锁文件安装，公开第三方模型按固定版本下载；自有模型单独下载。这会把「离线、双击即开」改为「首次启动联网安装」，不是等效删减。
4. 世界、个人对局数据、密码与控制令牌不进入公开发布包；新环境生成独立配置。

## 上传

可以在 GitHub 网页新建 `wavedog`，解压源码 ZIP 后把其中的文件上传到仓库根目录（不是上传 ZIP 本身）。本工具只生成本地可审阅材料，没有创建远程仓库或上传任何数据。

若使用 Git，在本目录设置你的远程仓库后再提交和推送。完整备份 ZIP 始终位于本目录之外，不会被 `.gitignore` 配置失误顺带提交。
