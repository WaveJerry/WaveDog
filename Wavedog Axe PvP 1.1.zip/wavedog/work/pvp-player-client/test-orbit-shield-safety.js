'use strict'
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path')
const {confirmedRear}=require('./protocol-mechanical-math')
const {createState,plan,applied,receipt}=require('./protocol-wavedog-brain')
const {executeCommand}=require('./protocol-wavedog-executor')
const base={tick:10,health:20,ground:true,visible:true,shieldReady:true,shieldEffective:true,
  offhandShieldReady:true,targetShieldRaised:true,targetShieldFacing:true,targetYaw:0,targetFacingDot:1,
  self:{x:0,z:-.8},sentPosition:{x:0,z:-.8},target:{x:0,z:0},targetGrounded:true,
  distance:.8,reach:.5,charge:1,held:7,wallMargin:8,orbitDraw:0,orbitSide:-1,openingDraw:0}
for(const health of [0,1,4.99,5]){
  const p=plan(createState(),{...base,health},null)
  assert(!p.command.orbit&&p.command.shield&&!p.command.attack,`HP=${health} cannot start an orbit`)
}
let s=createState(),p=plan(s,base,null)
assert(p.command.orbit)
applied(s,p.command,false,10)
p=plan(s,{...base,tick:11,health:5},null)
assert(!p.command.orbit&&p.command.shield&&!p.command.sprint,'low HP cancels an active orbit immediately')
receipt(s,{type:'blocked_melee',blockId:1},11)
p=plan(s,{...base,tick:12,health:3},null)
assert.equal(p.command.kind,'counter','low HP never disables a real shield counter')
assert(!confirmedRear({x:0,z:.5},{x:0,z:-.1},{x:0,z:0},0),'local rear / wire front fails closed')
assert(confirmedRear({x:0,z:.5},{x:0,z:.3},{x:0,z:0},0),'normal position packet unlocks a rear hit')
assert(!confirmedRear({x:1,z:.03},{x:1,z:.03},{x:0,z:0},0),'near-side uncertainty is not a rear')
p=plan(createState(),{...base,targetShieldFacing:false,reach:2,distance:2,
  targetFacingDot:1,openingDraw:0},null)
assert(!p.command.attack,'freshly raised frontal shield cannot become a guard opening')
const rear={...base,self:{x:0,z:1},sentPosition:{x:0,z:.8},targetFacingDot:-1,targetShieldFacing:false}
p=plan(createState(),rear,null)
assert.equal(p.command.kind,'orbit-rear')
// Execution must reject a target that turns its shield after planning. No use
// entity/intent packet is allowed and a usable shield is immediately restored.
const controls={},packets=[],bot={entity:{position:rear.self,yaw:0,onGround:true,velocity:{y:0}},
  quickBarSlot:7,food:20,inventory:{slots:[]},_client:{write:(name,data)=>packets.push({name,data})},
  setControlState:(k,v)=>{controls[k]=v},getControlState:k=>controls[k],
  activateItem:()=>packets.push({name:'use_item'}),attack:()=>packets.push({name:'use_entity'})}
let use=null
const result=executeCommand({bot,planned:p,frame:{seen:{visible:true},observation:rear},
  target:{position:rear.target,yaw:Math.PI},tick:10,session:{state:createState(),attackedDecisions:new Set(),attackOwners:new Map()},
  charge:()=>1,look:()=>{},aim:()=>{},offhand:()=>true,stopUse:()=>{use=null},
  getUse:()=>use,setUse:v=>{use=v},plugin:()=>packets.push({name:'intent'}),onAttack:()=>{},shieldUntil:0})
assert(!result.attacked&&!packets.some(p=>['use_entity','intent'].includes(p.name)))
assert.equal(result.owners.attack,'rear-not-confirmed-on-wire');assert.equal(use.kind,'shield')
// Replay two verified zero-damage shield hits using the actual packet order.
const runtime=path.resolve(__dirname,'../wavedog-protocol/runtime'),mid='5ff64a39-68fd-48dd-8bd1-271aaca0258c'
const rows=fs.readFileSync(path.join(runtime,mid+'-frames.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
const wire=fs.readFileSync(path.join(runtime,mid+'-packets.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
const replay=[]
for(const tick of [127620,127792]){
  const f=rows.find(f=>f.tick===tick),i=wire.findIndex(p=>p.tick===tick&&p.name==='use_entity')
  assert(f&&i>0,'real attack evidence required')
  const prior=wire.slice(0,i).findLast(p=>['position','position_look'].includes(p.name)).data
  assert(wire.slice(i+1).some(p=>p.tick===tick&&p.name==='position_look'),'attack preceded the new position')
  const o={...f.observation,health:f.self.health,sentPosition:prior,targetShieldRaised:true}
  s=createState('WaveJerry');s.orbitUntil=tick+2;s.orbitLastAt=tick-1
  p=plan(s,o,null)
  assert(!p.command.attack,`tick ${tick} must not repeat the blocked orbit strike`)
  replay.push({tick,oldKind:f.command.kind,oldFacing:o.targetFacingDot,wirePosition:prior,
    attackSuppressed:!p.command.attack})
}
const output={event:'ORBIT_SHIELD_SAFETY_PASS',lowHealthThreshold:5,replay,
  pendingPositionDoesNotAuthorizeRear:true,executorRechecksFacing:true,realCounterPreserved:true}
fs.mkdirSync(path.join(runtime,'orbit-and-entry'),{recursive:true})
fs.writeFileSync(path.join(runtime,'orbit-and-entry/replay-verification.json'),JSON.stringify(output,null,2))
console.log(JSON.stringify(output))
