'use strict'
// Test opponent only: alternate public shield and sword-pressure phases.
// Relative ticks make whole-bout schedules reproducible across new logins.
function shieldCycle(tick, startTick, offset = 0, disabledUntil = -1) {
  if (![tick, startTick, offset, disabledUntil].every(Number.isSafeInteger)) {
    throw new Error('Integer public simulation ticks required')
  }
  const elapsed = Math.max(0, tick - startTick)
  const phaseTick = ((elapsed + offset) % 96 + 96) % 96
  const scheduledShield = phaseTick < 40
  return { phaseTick, scheduledShield, raiseShield: scheduledShield && tick >= disabledUntil }
}
module.exports = { shieldCycle }
