/** Group nearby native melee damage into one exchange and measure net health. */
function analyzeExchanges (fighter, opponent, events, gapMs = 1500) {
  const damage = events.filter(e => e.type === 'damage' && e.source === 'MELEE'
    && !e.cancelled && e.amount > 0
    && ((e.attacker === fighter && e.victim === opponent)
      || (e.attacker === opponent && e.victim === fighter)))
    .sort((a,b) => Date.parse(a.at)-Date.parse(b.at))
  const outcomes = []
  let current = null
  const finish = () => {
    if (!current) return
    const net = +(current.dealt-current.received).toFixed(2)
    const loss = net < 0
    outcomes.push({ at: current.lastAt, kind: loss ? 'lost-melee-exchange'
      : net > 0 ? 'won-melee-exchange' : 'even-melee-exchange',
    dealt: +current.dealt.toFixed(2), received: +current.received.toFixed(2),
    net, reward: loss ? -Math.min(.08, -net/20*.15) : 0 })
  }
  for (const event of damage) {
    const at = Date.parse(event.at)
    if (!current || at - current.last > gapMs) {
      finish()
      current = { last: at, lastAt: event.at, dealt: 0, received: 0 }
    }
    current.last = at; current.lastAt = event.at
    if (event.attacker === fighter) current.dealt += event.amount
    else current.received += event.amount
  }
  finish()
  return { exchangeCount: outcomes.length,
    lostExchanges: outcomes.filter(row => row.net < 0).length,
    wonExchanges: outcomes.filter(row => row.net > 0).length,
    exchangeNet: +outcomes.reduce((sum,row) => sum + row.net, 0).toFixed(2),
    exchangeOutcomes: outcomes }
}

module.exports = { analyzeExchanges }
