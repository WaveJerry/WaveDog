'use strict'
const assert=require('node:assert/strict')
const fs=require('node:fs'),path=require('node:path')
const {planAirThreat,ageEnvelope,airborneEnvelope}=require('./protocol-legacy86-threat')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {executeCommand}=require('./protocol-legacy86-executor')
const {createOutputGate}=require('./protocol-legacy86-output-gate')
const {frame,probe,executorFixture}=require('./test-legacy86-control')
const evidence=require('./fixtures/critical-20261119.json')
const openFloor=()=>({clear:true,supported:true,floorY:221,margin:1.5})
async function run(){
  const replay=evidence.air.map(r=>({tick:r.tick,old:r.oldPlan,
    candidate:planAirThreat(structuredClone(r.frame),openFloor)}))
  const stale=replay.find(r=>r.tick===20716)
  assert(stale.old.route.safe,'require the actual false-safe verdict, not a fabricated example')
  assert(!stale.candidate.route.safe,'69ms-old near-apex packet must not promise a safe escape')
  const rise=replay.find(r=>r.tick===20712)
  assert(rise.candidate.criticalTicks[0]<rise.old.criticalTicks[0],
    'elapsed flight time must advance the possible critical phase')
  const low=replay.find(r=>r.tick===20735)
  assert.equal(low.old.action,'interrupt')
  assert.notEqual(low.candidate.action,'interrupt','20% sword charge cannot promise knockback interruption')
  for(const r of replay){
    assert.equal(r.candidate.timing.delayTicks,0)
    assert(r.candidate.timing.attackDelayTicks>=2)
  }
  const flight=airborneEnvelope({x:3,y:1,z:0,vx:-.1,vy:.15,vz:0},{floorY:0})
  const shifted=ageEnvelope(flight,1.5)
  for(const e of shifted)for(const phase of [1,2]){
    const original=flight[e.tick+phase];if(!original)continue
    assert(e.radius+1e-9>=original.radius+Math.hypot(original.x-e.x,original.z-e.z))
    assert(e.yMin<=original.yMin&&e.yMax>=original.yMax)
    assert(!original.criticalPossible||e.criticalPossible)
  }
  const gate=createOutputGate()
  gate.permit({slot:0,decidedTick:100,worldHeading:{x:1,z:0}},0)
  assert(gate.permit({slot:0,decidedTick:100,airDodgeUrgent:true,worldHeading:{x:-1,z:0}},2),
    'new defense must cancel an approach before the navigation deadline')
  for(let ms=4;ms<50;ms+=2)assert(!gate.permit({slot:0,decidedTick:100,
    airDodgeUrgent:true,worldHeading:{x:ms%4?1:-1,z:0}},ms),'no 500Hz defense packet oscillation')

  const brain=createBrain();await brain.ready
  try{
    const s=createState('WaveJerry');s.swordOnly=true;await brain.reset(s,123)
    const f=structuredClone(evidence.air.find(r=>r.tick===20735).frame)
    const p=await brain.decide(s,f,openFloor,20735)
    assert(!p.command.attack&&!p.command.jump,'real original AIR_INTERRUPT must not execute the weak tap')
    assert(p.command.airDodgeUrgent&&p.command.worldHeading,'a denied interrupt must submit its evasion')
    const rearState=createState('WaveJerry')
    for(const r of evidence.shield){
      const f={self:r.self,seen:r.seen,observation:r.observation,targetVelocity:r.observation.targetVelocity}
      const input=brain.publicInput(rearState,f,r.tick,false)
      assert.notEqual(input.senses.opportunity,'ORBIT_BACK','GUARD_CLOSE side-plane sample is not a confirmed back')
      assert(input.view.targetBlocking)
      const planned={mode:'LEGACY86',owners:{},command:structuredClone(r.command)}
      const ctx=executorFixture(planned,f)
      ctx.bot.entity.position={x:r.self.x,y:r.self.y,z:r.self.z};ctx.bot.quickBarSlot=7
      ctx.target={position:r.seen,yaw:r.observation.targetYaw,width:.6,height:1.8,
        metadata:{8:3},equipment:[{name:'diamond_axe'},{name:'shield'}]}
      ctx.getSentPosition=()=>r.observation.sentPosition
      const actual=executeCommand(ctx)
      assert(!actual.attacked&&actual.attackSuppressedReason==='rear-not-confirmed-on-wire')
      assert(!ctx.wire.some(p=>p.name==='use_entity'),'recorded GUARD_CLOSE attacks must never reach the shield again')
      assert.equal(ctx.getUse()?.kind,'shield','rejected opening restores defense')
    }
    // Live target turning after the plan, and latest sent position replacing
    // an older locally-rear frame, both must close the attack window.
    const rear=frame({self:{z:1,shieldAvailable:true},seen:{x:0,z:0},
      observation:{reach:.7,targetShieldRaised:true,targetShieldFacing:false,
        targetYaw:0,sentPosition:{x:0,y:0,z:1}}})
    const make=(kind='legacy86')=>{
      const p={mode:'LEGACY86',owners:{},command:{kind,phase:'GUARD_CLOSE',slot:7,
        attack:true,shield:false,forward:0,side:0,decidedTick:101}}
      const ctx=executorFixture(p,rear);ctx.bot.entity.position={x:0,y:0,z:1}
      ctx.bot.quickBarSlot=7;ctx.target.position={x:0,y:0,z:0};ctx.target.yaw=0
      ctx.target.metadata[8]=3;ctx.getSentPosition=()=>({x:0,y:0,z:1})
      return ctx
    }
    assert(executeCommand(make()).attacked,'confirmed exposed rear remains attackable')
    const turned=make();turned.target.yaw=Math.PI
    assert(!executeCommand(turned).attacked,'fresh enemy rotation overrides an old rear plan')
    const wireFront=make();wireFront.getSentPosition=()=>({x:0,y:0,z:-1})
    assert(!executeCommand(wireFront).attacked,'local rear cannot conceal the latest sent front position')
    const trade=make();trade.target.metadata[8]=0
    assert(executeCommand(trade).attacked,'enemy lowering shield to interrupt still permits trading')
    const counter=make('legacy86-counter');counter.target.yaw=Math.PI
    assert(executeCommand(counter).attacked,'real shield counter retains permission to break a front shield')
  }finally{await brain.close()}
  const out=path.resolve(__dirname,'../../outputs/wavedog-performance-20261118/latest-critical/critical-replay.json')
  fs.writeFileSync(out,JSON.stringify({scope:evidence.scope,matchId:evidence.matchId,
    liveZeroCriticalsProven:false,replay},null,2))
  console.log('AGED_AIR_WINDOW_WEAK_INTERRUPT_AND_LIVE_SHIELD_REAR_REGRESSIONS_PASS')
}
run().catch(error=>{console.error(error);process.exitCode=1})
