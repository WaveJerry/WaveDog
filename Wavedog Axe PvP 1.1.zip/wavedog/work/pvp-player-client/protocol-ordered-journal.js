'use strict'
const fs = require('node:fs')

// Packet logging must not open/write/close a file synchronously inside every
// input. The stream preserves order; close is awaited before canonical frames
// are rewritten with the native damage receipts attached after each tick.
function createOrderedJournal (file, onError = () => {}, open = fs.createWriteStream) {
  let stream, failure, closing, closed = false
  function failed (error) {
    if (!failure) { failure = error; onError(error) }
  }
  return {
    append (row) {
      if (closed) throw Error('Journal is already closing')
      if (failure) throw failure
      if (!stream) {
        stream = open(file, { flags: 'a', encoding: 'utf8' })
        stream.on('error', failed)
      }
      stream.write(JSON.stringify(row, (_, value) => typeof value === 'bigint'
        ? value.toString() : value) + '\n')
    },
    close () {
      if (closing) return closing
      closed = true
      closing = new Promise((resolve, reject) => {
        if (failure) { reject(failure); return }
        if (!stream) { resolve(); return }
        stream.once('error', reject)
        stream.once('finish', () => failure ? reject(failure) : resolve())
        stream.once('close', () => {
          if (!stream.writableFinished) reject(failure || Error('Journal closed before finish'))
        })
        stream.end()
      })
      return closing
    }
  }
}
module.exports = { createOrderedJournal }
