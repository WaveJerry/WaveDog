"""Check basic inferred actions before inviting a human into the arena."""
from pathlib import Path
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
focus = sys.argv[1] if len(sys.argv) > 1 else 'FREE'
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classpath = ';'.join(map(str, [base / 'bridge-classes', base.parent / 'pvp-neural-lab/classes',
                            server / 'versions/1.21.1/paper-1.21.1.jar',
                            server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
cases = [
    ('close_charged', 0, 1058.5, 962.4, 1),
    ('close_recharging', 0, 1058.5, 962.4, .3),
    ('far_target', 0, 1058.5, 968.5, 1),
    ('behind_target', 0, 1058.5, 958.5, 1),
    ('angled_target', -10, 1058.1, 962.9, 1),
]
lines = []
for i, (name, yaw, target_x, target_z, charge) in enumerate(cases, 1):
    opponent = 'WaveJerry' if i % 2 else 'WPlayer02'
    lines.append(json.dumps({'command': 'reset', 'opponent': opponent}))
    lines.append(json.dumps({'command': 'act', 'requestId': i, 'opponent': opponent, 'tick': 30,
                             'yaw': yaw, 'pitch': 0, 'focus': focus,
                             'self': {'x': 1058.5, 'y': 221, 'z': 960.5, 'eyeY': 222.62,
                                      'ground': True, 'charge': charge, 'health': 20,
                                      'shieldAvailable': True, 'held': 7},
                             'seen': {'visible': True, 'x': target_x, 'y': 221,
                                      'z': target_z, 'held': 'DIAMOND_AXE', 'yaw': 180}}))
result = subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp', classpath,
                         'local.wavedog.lab.ProtocolPlayerBridge', str(base / 'new-learning/models')],
                        input='\n'.join(lines)+'\n', text=True, capture_output=True, check=True)
rows = [json.loads(line) for line in result.stdout.splitlines()]
actions = {name: next(row for row in rows if row.get('requestId') == i)
           for i, (name, *_rest) in enumerate(cases, 1)}
print(json.dumps(actions, ensure_ascii=False, indent=2))
assert actions['far_target']['forward'] > .5 and actions['far_target']['sprint']
assert actions['close_charged']['attack']
assert not actions['close_recharging']['attack']
assert abs(actions['behind_target']['yaw']) >= 90
assert abs(actions['angled_target']['yaw'] - 9.5) < 10
assert all(actions[name]['opponent'] == ('WaveJerry' if i % 2 else 'WPlayer02')
           for i, (name, *_rest) in enumerate(cases, 1))
