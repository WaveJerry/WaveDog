"""Open a named player's round only after the GRU and Qwen gate is fresh."""
from pathlib import Path
import importlib.util
import json
import sys
import time

base = Path(__file__).resolve().parent
opponent = sys.argv[1] if len(sys.argv) > 1 else 'WaveJerry'
round_number = int(sys.argv[2]) if len(sys.argv) > 2 else 1
readiness = base / 'new-learning/human-trial-ready.json'
receipt = base / 'new-learning/invite-receipt.json'
spec = importlib.util.spec_from_file_location('rcon', 'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
deadline = time.monotonic() + 3600

while time.monotonic() < deadline:
    try:
        ready = json.loads(readiness.read_text(encoding='utf-8'))
        if time.time() - readiness.stat().st_mtime > 5 or not all(ready.get(k) for k in ('gruReady', 'coachReady', 'kitReady')):
            time.sleep(2)
            continue
        if opponent not in rcon.command('list').split(':', 1)[-1].split(', '):
            time.sleep(2)
            continue
        time.sleep(4)  # Let AuthMe finish its login flow.
        response = rcon.command(f'duelgate invite {opponent} {round_number}')
        if f'Dialog opened for round {round_number}' in response:
            receipt.write_text(json.dumps({'at': time.time(), 'opponent': opponent, 'round': round_number,
                                           'response': response.strip(), 'qwenFocus': ready['qwenFocus']}, indent=2), encoding='utf-8')
            break
    except (OSError, ValueError, KeyError):
        pass
    time.sleep(2)
