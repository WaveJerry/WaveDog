'use strict'
// Legacy v2 demos recorded "raised" as shield=true. Deployed players expose
// shield=true only after five public ticks. Adapt causally, never from outcome.
function deployedShieldObservation(request,history){
  const seen=request.seen
  if(!seen?.visible){history.shieldAt=null;return request}
  const raised=Boolean(seen.shieldRaised??seen.shield)
  history.shieldAt=raised?(history.shieldAt??request.tick):null
  return {...request,seen:{...seen,shieldRaised:raised,
    shield:raised&&request.tick-history.shieldAt>=5}}
}
module.exports={deployedShieldObservation}
