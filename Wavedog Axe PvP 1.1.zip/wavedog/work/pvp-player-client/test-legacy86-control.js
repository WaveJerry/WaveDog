'use strict'
const assert=require('node:assert/strict')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {airborneEnvelope,planAirThreat,planSpacing,createThreatClock,arenaCenter,eyeBoxReach}=require('./protocol-legacy86-threat')
const {createRouteProbe}=require('./protocol-legacy86-route')
const {executeCommand}=require('./protocol-legacy86-executor')
const {encodeRequest}=require('./protocol-legacy86-runtime')
const {createOutputGate}=require('./protocol-legacy86-output-gate')
function frame(over={}){
  const f={self:{x:0,y:0,z:0,eyeY:1.62,vx:0,vy:0,vz:0,ground:true,critical:false,
    charge:1,health:20,food:20,shieldAvailable:false,shielding:false,arrows:5,
    crossbowLoaded:true,hasBow:true,hasCrossbow:true,useTicks:0,held:0,inventoryObservation:{switching:false,hasShield:true}},
    seen:{x:3.29,y:0,z:0,visible:true,held:'DIAMOND_SWORD',arrows:[]},
    targetVelocity:{x:0,y:0,z:0},targetMotion:{sampleTick:100},targetFloorY:0,offhand:'shield',
    observation:{tick:100,visible:true,reach:2.99,otherReach:2.99,distance:3.29,
      targetGrounded:true,targetAirborne:false,targetFacingDot:1,wallMargin:8,
      shieldReady:false,charge:1,held:0,ground:true,mutualOutOfReach:false}}
  return {...f,...over,self:{...f.self,...over.self},seen:{...f.seen,...over.seen},
    observation:{...f.observation,...over.observation}}
}
const solid=[[0,0,0,1,1,1]]
const probe=createRouteProbe({origin:{x:0,y:0,z:0},blockAt:(x,y,z)=>({shapes:y<0?solid:[]})})
async function run(){
  const output=createOutputGate();let sent=0
  for(let ms=0;ms<1000;ms+=2){
    // Even constantly changing navigation must not become 500 look packets.
    if(output.permit({forward:1,side:ms%4?1:-1,shield:false,slot:0},ms))sent++
  }
  assert(sent<=20,'500 judgments must coalesce to at most 20 nonurgent outputs per second')
  assert(output.permit({attack:true,shield:false,slot:0},999),'a real entry attack bypasses navigation delay')
  assert(output.permit({attack:false,shield:true,slot:0},1000),'raising shield bypasses navigation delay')
  assert(output.permit({ranged:'fire-crossbow',rangedId:1,slot:0},1001),'new synchronization shot is immediate')
  const physicalGate=createOutputGate()
  assert(physicalGate.permit({forward:1,slot:0},0))
  assert(!physicalGate.permit({forward:-1,slot:0},2,{physical:true}),
    'physical+preview navigation must share one clock, not immediately reverse each other')
  const budget=createOutputGate(),packets=[]
  for(let ms=0;ms<10000;ms+=2){
    while(packets.length&&packets[0]<=ms-1000)packets.shift()
    if(ms%50===0)packets.push(ms) // ordinary physics/connection packet
    if(budget.permit({attack:true,shield:ms%4===0,slot:ms%4===0?7:0},ms,
        {physical:ms%50===0,outboundPackets:packets.length}))
      for(let n=0;n<18;n++)packets.push(ms) // full adversarial combat transaction
    assert(packets.length<=260,'even urgent oscillation must remain below the server 500 packet limit')
  }
  assert(budget.counts.packetBudgetWait>0,'sustained urgent spam must back off, not bypass the budget')
  // Envelope containment under arbitrary steering, not only fixed headings.
  for(let trial=0;trial<100;trial++){
    let body={x:3,y:1,z:0,vx:.2,vy:.31,vz:-.03},vx=body.vx,vy=body.vy,vz=body.vz
    const envelope=airborneEnvelope(body,{positionError:0,velocityError:0,floorY:-100})
    for(const e of envelope){
      assert(Math.hypot(body.x-e.x,body.z-e.z)<=e.radius+1e-8)
      const a=trial*13.7+e.tick*7.123
      body.x+=vx+Math.cos(a)*.026;body.z+=vz+Math.sin(a)*.026;body.y+=vy
      vx=(vx+Math.cos(a)*.026)*.91;vz=(vz+Math.sin(a)*.026)*.91;vy=(vy-.08)*.98
    }
  }
  const reset=frame({targetRecentHitTicks:0})
  const resetPlan=planAirThreat(reset,probe)
  assert(resetPlan.valid&&resetPlan.jumpResetPossible&&resetPlan.threat,'hit+ground must admit a jump-reset punishment')
  assert.notEqual(resetPlan.action,'interrupt','unseen future reset must not be called a live rising interrupt')
  const descending=frame({seen:{x:2.7,y:.7},targetVelocity:{x:-.1,y:-.2,z:0},
    observation:{targetGrounded:false,targetAirborne:true,reach:2.4}})
  const danger=planAirThreat(descending,probe)
  assert(danger.threat&&danger.criticalTicks.includes(0),'current falling threat included')
  const guarded=planAirThreat(frame({...descending,self:{shieldAvailable:true}}),probe)
  assert.equal(guarded.action,'guard')
  const noRoute=planAirThreat(descending,()=>({clear:false,supported:true,margin:0}))
  assert.equal(noRoute.action,'no-guaranteed-route');assert.equal(noRoute.route,null)
  const late=planAirThreat(frame({seen:{x:2.8,y:.8},targetVelocity:{x:-.1,y:.04,z:0},
    observation:{targetGrounded:false,targetAirborne:true,reach:2.5},
    latency:{oneWayMs:25,serverQueueMs:50,decisionMs:4,observationAgeMs:30}}),probe)
  assert(late.risingTail);assert.notEqual(late.action,'interrupt','positive vy at late ascent is not automatically safe')
  assert(late.timing.attackDelayTicks>=2,'strike safety includes network and server tick queue')
  assert.equal(late.timing.delayTicks,0,'local evasion must not hold old controls for the attack queue')
  const wallProbe=createRouteProbe({origin:{x:0,y:0,z:0},blockAt:(x,y,z)=>({shapes:y<0||x<=-1?solid:[]})})
  const spacing=planSpacing(frame({self:{x:.35},seen:{x:3},observation:{reach:2.35}}),wallProbe)
  assert(spacing,'must have an open lateral route beside a wall')
  assert(spacing.heading.x>-.9,'must not blindly retreat into the wall')
  let now=0,count=0
  const clock=createThreatClock({now:()=>now,evaluate:()=>{count++;return {valid:true}}})
  for(let i=0;i<501;i++){now=i*2;clock.update(reset,probe,'a')}
  assert.equal(count,501,'500 Hz recomputes actual verdicts')

  const brain=createBrain();await brain.ready
  try{
    assert.equal(arenaCenter({x:1030,y:221,z:1014}).name,'main-arena')
    assert.equal(arenaCenter({x:0,y:0,z:0}),null,'unknown arenas must not inherit main-arena coordinates')
    assert.equal(eyeBoxReach({x:0,y:0,z:0},{x:3.3,y:0,z:0}),3)
    const diagonal=3/Math.SQRT2+.3
    assert(Math.abs(eyeBoxReach({x:0,y:0,z:0},{x:diagonal,y:0,z:diagonal})-3)<1e-12)
    const centerFrame=frame({self:{x:1030,y:221,z:1014,charge:.2},
      seen:{x:1030,y:221,z:1010},observation:{reach:3.7,distance:4},targetVelocity:{x:0,y:0,z:.05}})
    const centerProbe=createRouteProbe({origin:centerFrame.self,blockAt:(x,y,z)=>({shapes:y<221?solid:[]})})
    const centerMove=planSpacing(centerFrame,centerProbe)
    assert(centerMove.heading.x<0,'otherwise equivalent spacing routes must favour arena centre')
    const centerInput=brain.publicInput(createState('enemy'),centerFrame,99,false)
    assert(centerInput.senses.centerDistance>10&&Math.abs(centerInput.senses.centerSide)>.9,
      'original 8.6 must receive its real centre bias instead of zero constants')
    const hold=executorFixture({mode:'LEGACY86',command:{forward:1,side:0,sprint:true,
      worldHeading:{x:0,z:0},attack:false,jump:false,offhand:'shield'},owners:{}},frame())
    const heldStill=executeCommand(hold)
    assert(!heldStill.controls.forward&&!heldStill.controls.back&&!heldStill.controls.sprint,
      'a stationary forecast must not execute forward sprint')
    const guardedState=createState('enemy');await brain.reset(guardedState,123)
    const noArrow=frame({self:{shieldAvailable:true},observation:{shieldReady:true}})
    const noArrowPlan=await brain.decide(guardedState,noArrow,probe,100)
    assert.equal(brain.publicInput(guardedState,noArrow,100,false).senses.shieldCoversRanged,false)
    assert.notEqual(noArrowPlan.original.phase,'ARROW_GUARD','own shield alone is not a projectile threat')
    const unbounded=frame({observation:{tick:101},targetMotion:{sampleTick:101}})
    const input=brain.publicInput(guardedState,unbounded,101)
    input.senses.jumpSpace={threat:false,move:2,clearance:Infinity,x:0,z:0,sprint:false,jump:false}
    assert.equal(JSON.parse(encodeRequest(input)).senses.jumpSpace.clearance,'Infinity')
    assert.throws(()=>encodeRequest({charge:NaN}),/Invalid NaN.*charge/)
    const survived=await brain.runtime.request(input)
    assert(survived.decision,'unbounded clearance must survive actual JS-to-Java record decoding')
    const s=createState('enemy');s.swordOnly=true;s.hadHop=true
    await brain.reset(s,123)
    const first=await brain.decide(s,frame(),probe,100)
    assert.equal(first.command.slot,0);assert(first.command.attack,'charged sword at legal contact must attack')
    // Every same-tick preview starts from a copied controller including RNG.
    let previous
    for(let i=0;i<50;i++){
      const p=await brain.decide(s,frame(),probe,100,{preview:true})
      if(previous)assert.deepEqual(p.original,previous)
      previous=p.original
    }
    const next=await brain.decide(s,frame({observation:{tick:101},targetMotion:{sampleTick:101}}),probe,101)
    const baseline=createBrain();await baseline.ready
    try{
      const b=createState('enemy');b.swordOnly=true;b.hadHop=true;await baseline.reset(b,123)
      await baseline.decide(b,frame(),probe,100)
      const expected=await baseline.decide(b,frame({observation:{tick:101},targetMotion:{sampleTick:101}}),probe,101)
      assert.deepEqual(next.original,expected.original,'previews may not mutate next physical decision')
    }finally{await baseline.close()}
    const shieldFrame=frame({seen:{shieldRaised:true,shield:true},observation:{tick:102,
      targetShieldFacing:true,targetShieldRaised:true},targetMotion:{sampleTick:102}})
    const stun=await brain.decide(s,shieldFrame,probe,102)
    assert.equal(stun.command.kind,'legacy86-stun');assert(stun.command.doubleAttack)
    const x=executorFixture(stun,shieldFrame),out=executeCommand(x)
    assert.equal(out.attacks.length,2);assert.equal(x.wire.filter(p=>p.name==='use_entity').length,2)
    assert.equal(x.bot.quickBarSlot,0,'double strike immediately returns to sword')
    assert.notEqual(out.attacks[0].id,out.attacks[1].id)
    brain.applied(s,stun.command,out,102)
    const duplicate=executorFixture({...stun,command:{...stun.command}},shieldFrame)
    duplicate.session.state.pending=s.pending
    const rejected=executeCommand(duplicate)
    assert(!rejected.attacked,'an already queued preview cannot replay a pending stun pair')
    const held=await brain.decide(s,shieldFrame,probe,102,{preview:true})
    assert(!held.command.attack&&!held.command.doubleAttack,'same shield observation must not replay stun pair')
    const outside=frame({seen:{x:3.301},observation:{tick:103,reach:3.001,otherReach:3.001,distance:3.301}})
    const noHit=await brain.decide(s,outside,probe,103)
    assert(!noHit.command.attack,'outside legal box reach must not authorize melee')
    brain.receipt(s,{type:'damage',attacker:'enemy',victim:'Punengbho',melee:true,amount:3},103)
    assert.equal(s.lastDamage,103)
    const counter=createState('enemy');await brain.reset(counter,123)
    brain.receipt(counter,{type:'blocked_melee',blockId:12,shieldDisabled:true},200)
    const counterFrame=frame({self:{held:7},observation:{tick:200},targetMotion:{sampleTick:200}})
    const counterPlan=await brain.decide(counter,counterFrame,probe,200)
    assert.equal(counterPlan.original.phase,'COUNTER');assert(counterPlan.command.attack)
    const cx=executorFixture(counterPlan,counterFrame);cx.tick=200;cx.bot.quickBarSlot=7
    const hit=executeCommand(cx);assert(hit.attacked)
    brain.applied(counter,counterPlan.command,hit,200)
    brain.receipt(counter,{type:'damage',attacker:'Punengbho',victim:'enemy',melee:true,
      amount:4,nativeCritical:false,attackId:hit.executedAttackId},200)
    const hop=await brain.decide(counter,frame({self:{held:7,charge:.05},observation:{tick:201},
      targetMotion:{sampleTick:201}}),probe,201)
    assert(hop.original.counterHopActive);assert(hop.command.jump);assert.equal(hop.command.slot,0)
    const hopSync=await brain.decide(counter,frame({self:{held:7,charge:.05},
      observation:{tick:201,loaded:true,arrows:5,targetShotEvent:1,targetShotTick:201},targetMotion:{sampleTick:201}}),probe,201,{preview:true})
    assert.equal(hopSync.command.slot,0,'offhand synchronization cannot retain pre-hop axe')
    assert.equal(hopSync.command.ranged,null,'sword equip precedes use that would freeze mainhand')
    const hx=executorFixture(hop,frame());hx.tick=201;hx.bot.quickBarSlot=7
    const jumped=executeCommand(hx);brain.applied(counter,hop.command,jumped,201)
    const flight=await brain.decide(counter,frame({self:{held:0,ground:false,vy:.3,charge:.1},
      observation:{tick:202},targetMotion:{sampleTick:202}}),probe,202)
    assert(!flight.command.jump,'one confirmed counter may submit only one hop')
    const landed=await brain.decide(counter,frame({observation:{tick:212},targetMotion:{sampleTick:212}}),probe,212)
    assert(counter.swordOnly);assert.equal(landed.command.slot,0,'landing cannot return to the normal axe branch')
    const swordContact=await brain.decide(counter,frame({observation:{tick:213},targetMotion:{sampleTick:213}}),probe,213)
    assert.equal(swordContact.command.slot,0)
    assert(swordContact.command.attack,'post-hop sword role must agree with original contact checks: '+JSON.stringify(swordContact))
    const restored=frame({self:{shieldAvailable:true,shielding:true},seen:{shieldRaised:true,shield:true},
      observation:{tick:214,shieldReady:true,shieldEffective:true,targetShieldRaised:true,targetShieldFacing:true},
      targetMotion:{sampleTick:214}})
    const shieldMode=await brain.decide(counter,restored,probe,214)
    assert(!brain.publicInput(counter,restored,214,false).swordMode,'usable shield cannot retain unshielded sword-mode patch')
    assert.notEqual(shieldMode.command.kind,'legacy86-stun','both shields up cannot enter unshielded stun overlay')
    const shieldEntry=createState('enemy');shieldEntry.previousReach=3.1
    const entryInput=brain.publicInput(shieldEntry,restored,215,false)
    assert.equal(entryInput.senses.opportunity,'NONE','front shield entering reach is not an unprotected attack window')
    shieldEntry.lastBlock=215
    assert.equal(brain.publicInput(shieldEntry,restored,215,false).senses.opportunity,'BREAK_COUNTER',
      'a real blocked melee still authorizes the original counter')
    const defense=createState('enemy');defense.airDefense=true;defense.airPastInterrupt=true
    await brain.reset(defense,123)
    const separatedAir=frame({seen:{x:7,y:1},targetVelocity:{x:0,y:.15,z:0},
      observation:{tick:300,reach:6.7,otherReach:6.7,targetGrounded:false,targetAirborne:true},
      targetMotion:{sampleTick:300}})
    const retained=await brain.decide(defense,separatedAir,probe,300)
    assert(retained.airPlan.threat&&retained.airPlan.risingTail,
      'Yarm regression: one apparently distant update cannot reopen a late jump interrupt or cancel avoidance')
    const confirmedLand=await brain.decide(defense,frame({observation:{tick:301},targetMotion:{sampleTick:301}}),probe,301)
    assert(!defense.airDefense&&!defense.airPastInterrupt,'confirmed landing clears the prior airborne defense episode')
    console.log('LEGACY86_PUBLIC_THREAT_COPY_STATE_SWORD_STUN_PASS')
  }finally{await brain.close()}
}
function executorFixture(planned,f){
  const wire=[],controls={},inventory={slots:[]};inventory.slots[45]={name:'shield'}
  let use=null
  const bot={inventory,quickBarSlot:0,food:20,
    get heldItem(){return {name:this.quickBarSlot===0?'diamond_sword':'diamond_axe'}},
    entity:{position:{x:0,y:0,z:0},yaw:-Math.PI/2,pitch:0,eyeHeight:1.62,onGround:true,velocity:{x:0,y:0,z:0}},
    _client:{write:(name,data)=>wire.push({name,data})},
    setQuickBarSlot(slot){this.quickBarSlot=slot;this._client.write('held_item_slot',{slot})},
    setControlState(k,v){controls[k]=v},getControlState:k=>!!controls[k],
    activateItem(){this._client.write('use_item',{})},attack(){this._client.write('use_entity',{})}}
  return {bot,wire,planned,frame:f,target:{position:{x:3.29,y:0,z:0},width:.6,height:1.8,
    metadata:{8:1},equipment:[{name:'diamond_sword'},{name:'shield'}]},tick:102,
    session:{id:'test',opponent:'enemy',state:{nextId:100},attackOwners:new Map(),attackedDecisions:new Set()},
    charge:()=>1,look(yaw,pitch){bot.entity.yaw=yaw;bot.entity.pitch=pitch;bot._client.write('look',{yaw,pitch})},
    aim(){bot._client.write('look',{})},offhand:()=>true,stopUse(){use=null},getUse:()=>use,setUse:v=>{use=v},
    plugin:r=>bot._client.write('custom_payload',r),onSwitch(){},onAttack(){},shieldUntil:0,
    lastAttackTick:-1000,getSentPosition:()=>({x:0,y:0,z:0}),clearPath:()=>true,exactBoxAim:true}
}
if(require.main===module)run().catch(error=>{console.error(error);process.exitCode=1})
module.exports={frame,probe,executorFixture}
