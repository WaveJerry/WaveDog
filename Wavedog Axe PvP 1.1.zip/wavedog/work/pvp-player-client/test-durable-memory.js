const assert = require('node:assert/strict')
const { selectPlayerExperience, selectMeasuredLessons } = require('./durable-memory')

const rows = Array.from({ length: 24 }, (_, i) => ({ id: String(i),
  text: `lesson ${i}`, player: i < 5 ? 'user-seed' : 'player' }))
const seen = new Set()
for (let i = 0; i < 24; i++) {
  const picked = selectPlayerExperience(rows, i)
  assert.ok(picked.length <= 8)
  picked.forEach(text => seen.add(text))
}
assert.deepEqual(seen, new Set(rows.map(row => row.text)))

const corrected = [...rows, { id:'current-control',player:'user-seed',
  text:'current WaveDog and GRU control',supersedes:['0','1'] }]
for (let i=0;i<24;i++) {
  const picked=selectPlayerExperience(corrected,i)
  assert.ok(!picked.includes('lesson 0'))
  assert.ok(!picked.includes('lesson 1'))
  assert.ok(picked.includes('current WaveDog and GRU control'))
}

const measured = Array.from({ length: 40 }, (_, i) => ({ lesson: `measured ${i}`,
  lessonSource: 'measured-after-Qwen' }))
const seenMeasured = new Set()
for (let i = 0; i < 40; i++)
  selectMeasuredLessons(measured, i, 6).forEach(text => seenMeasured.add(text))
assert.deepEqual(seenMeasured, new Set(measured.map(row => row.lesson)))
console.log('DURABLE_MEMORY_ROTATION_PASS player=24 measured=40')
