'use strict'
const assert=require('node:assert/strict')
const {nearestHitPoint,nearestHitPointExact,nearestBoxPoint}=require('./protocol-mechanical-math')
const {modelRelativeView,rayTargetPoint}=require('./protocol-pure-executor')
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z)
let cases=0
for(const offset of [0,1000,-1000,100000])for(const sign of [-1,1])for(const axis of ['x','z']){
  const target={position:{x:offset,y:221,z:offset},width:.6,height:1.8}
  const eye={x:offset,y:222.62,z:offset};eye[axis]+=sign*3.29995
  const box=nearestBoxPoint(eye,target),legacy=nearestHitPoint(eye,target),aim=nearestHitPointExact(eye,target)
  assert(Math.abs(dist(eye,box)-2.99995)<1e-9)
  assert(dist(eye,legacy)>3,'old inward aim point can reject a legal extreme-edge hit')
  assert(dist(eye,aim)<3,'same closest-point aim remains inside the requested legal band')
  const view=modelRelativeView(eye,target,0,0,true)
  const hit=rayTargetPoint(eye,target,view.yaw,view.pitch)
  assert(hit&&dist(eye,hit)<=3,'real viewing ray intersects the physical box within reach')
  const outside={...eye};outside[axis]+=sign*.0001
  const outsideView=modelRelativeView(outside,target,0,0,true)
  assert.equal(rayTargetPoint(outside,target,outsideView.yaw,outsideView.pitch),null,
    'improved aim never grants reach beyond three blocks')
  cases++
}
// Aiming at the box is stable at edges/corners and at large world coordinates.
for(const offset of [0,1000,10000000]){
 const t={position:{x:offset,y:221,z:offset},width:.6,height:1.8}
 const eye={x:offset+2.4,y:224,z:offset-2.4},point=nearestHitPointExact(eye,t)
 assert(point.x>=offset-.3&&point.x<=offset+.3)
 assert(point.z>=offset-.3&&point.z<=offset+.3)
 assert(point.y>=221&&point.y<=222.8)
 cases++
}
console.log('EXACT_BOX_AIM_AND_LEGAL_REACH_PASS '+cases)
