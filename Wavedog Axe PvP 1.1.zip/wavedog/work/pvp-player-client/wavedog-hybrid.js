// Human mechanical controller. Base handoff survives arrow and ranged overlays.
const hop=require('./wavedog-counter-escape-hop')
const { publicArrowThreat }=require('./wavedog-arrow-predictor')
const { plannedBowDrawMs }=require('./ballistic-aim')
function createState(){
  return { mode:'hand', firstAt:0, blockCandidateAt:0, blockKind:'',
    lastHandledBlockAt:0, counterSentAt:0, counterPacketAt:-Infinity,
    counterBroken:false,
    exitStartedAt:0, hop:hop.create(),
    horizontalExitObserved:false, edgeAttackSent:false, lastExitAttackAt:0,
    lastExitAttackKind:'', lastHurtAt:0, rangedMode:null, rangedStartedAt:0,
    lastRangedAttemptAt:-Infinity, lastLoadAt:-Infinity, rangedFireSentAt:0,
    dodgeUntil:0, dodgeSide:0, dodgeJump:false, dodgeArrowId:null,
    returnAxePending:false, guardSide:0, guardSideUntil:0,
    orbitUntil:0, nextOrbitAt:0,
    previousDistance:null, lastAction:null, lastRangedOverlay:false,
    lastMovementOverride:false, metrics:{guardFrames:0,counterAttempts:0,
      counterHits:0,brokenShieldCounterHits:0,exitFrames:0,exits:0,
      failedExits:0,criticalExitAttempts:0,edgeExitAttempts:0,exitHits:0,
      syncFrames:0,noShieldFrames:0,rangedFireRequests:0,
      crossbowLoadFrames:0,bowDrawFrames:0,arrowDodges:0}}
}
function output(s,kind,decision,opts={}){
  s.lastAction=kind;s.lastRangedOverlay=Boolean(opts.ranged)
  s.lastMovementOverride=Boolean(opts.movement)
  return {kind,decision,movementOverride:Boolean(opts.movement),
    lockJump:Boolean(opts.lockJump),rangedOverlay:Boolean(opts.ranged)}
}
function toGru(s,t){s.mode='sync';s.syncStartedAt=t;s.rangedMode=null}
function advance(s,o){
  const t=o.now
  let handedOffThisFrame=false
  if(s.mode==='counter'&&t-s.counterSentAt>350)
    s.mode=o.shieldReady?'hand':'sync'
  if(s.mode==='exit'){
    if(o.distance>=3.6)s.horizontalExitObserved=true
    hop.observe(s.hop,t,o.ground)
    if(s.hop.active&&!s.hop.airborne&&o.wallMargin<1.4)hop.blocked(s.hop)
    // After takeoff, injury, wall contact and arrows cannot hand off in air.
    if(!s.hop.active){
      if(s.hop.airborne&&s.horizontalExitObserved&&s.lastHurtAt<=s.exitStartedAt)
        s.metrics.exits++
      else s.metrics.failedExits++
      toGru(s,t)
      s.returnAxePending=true
      handedOffThisFrame=true
    }
  }
  // A shield-disable packet can arrive before the blocked-hit sound. Give that
  // public cue one short window to reach the counter before handing off.
  if(s.mode==='hand'&&!o.shieldReady
      &&t-o.opponentSwingAt>400&&t-o.shieldDisabledAt>400)toGru(s,t)
  if(!handedOffThisFrame&&!s.returnAxePending&&s.mode==='sync'
      &&o.shieldReady)
    s.mode='hand'
}
function guardMove(s,o){
  const t=o.now
  if(t>=s.guardSideUntil){
    s.guardSide=o.flankSide||1
    s.guardSideUntil=t+500
  }
  // Port the GUARD_ADVANCE/GUARD_CLOSE pressureMove boundary: close distance,
  // then move sideways instead of driving through the opponent's hitbox.
  const overlap=o.distance<=.8
  const flank=o.opponentShieldEffective&&o.opponentShieldFacing
  return {forward:overlap?0:1,side:flank||overlap?s.guardSide:0,
    sprint:false,jump:false,sneak:false}
}
function guard(s,o){
  const t=o.now
  // WaveDog ORBIT_BURST: a short, committed forward-side sprint around a
  // shielding opponent, then immediately return to guard. It never attacks.
  if(t<s.orbitUntil){
    if(!o.ground||o.opponentSwingRecent||o.wallMargin<1.4)
      s.orbitUntil=0
    else return output(s,'shield-orbit',{forward:1,side:s.guardSide,
      sprint:true,jump:false,sneak:false,slot:7,shield:false,
      attack:false,use:false,release:true},{movement:true})
  }
  if(o.ground&&o.shieldRaised&&o.distance<=.9
      &&o.opponentShieldEffective&&o.opponentShieldFacing
      &&!o.opponentSwingRecent&&o.wallMargin>=1.4
      &&t>=s.nextOrbitAt){
    s.guardSide=o.flankSide||1
    s.orbitUntil=t+250;s.nextOrbitAt=t+900
    return output(s,'shield-orbit',{forward:1,side:s.guardSide,
      sprint:true,jump:false,sneak:false,slot:7,shield:false,
      attack:false,use:false,release:true},{movement:true})
  }
  return output(s,'shield-pressure',{...guardMove(s,o),slot:7,
    shield:true,attack:false,use:false,release:false},{movement:true})
}
function arrow(s,o){
  const t=o.now
  if(o.arrowThreat&&o.shieldReady&&
      (o.shieldRaised||o.arrowThreat.time>=5||!o.arrowThreat.side)){
    s.dodgeUntil=0;s.metrics.guardFrames++
    return output(s,'arrow-guard',{forward:0,side:0,sprint:false,
      jump:false,sneak:false,slot:s.mode==='exit'?0:7,
      shield:true,attack:false,use:false,
      release:false},{movement:true})
  }
  if(o.arrowThreat?.side&&(t>=s.dodgeUntil||s.dodgeArrowId!==o.arrowThreat.id)){
    s.dodgeUntil=t+Math.min(450,Math.max(150,(o.arrowThreat.time+1)*50))
    s.dodgeSide=o.arrowThreat.side;s.dodgeJump=o.arrowThreat.jump
    s.dodgeArrowId=o.arrowThreat.id;s.metrics.arrowDodges++
  }
  if(t<s.dodgeUntil)return output(s,'arrow-side-jump',{
    forward:0,side:s.dodgeSide,sprint:true,jump:Boolean(o.ground&&s.dodgeJump),
    sneak:false,slot:s.mode==='exit'?0:7,
    shield:false,attack:false,use:false,release:true
  },{movement:true})
  return null
}
function exit(s,o){
  const t=o.now,f=s.hop;s.metrics.exitFrames++
  const jump=o.ground&&hop.submitJump(f,t)
  if(f.airborne&&!f.exitAccepted&&o.distance>=2.35&&o.distance<=3.05
      &&!o.opponentShieldEffective){
    if(hop.criticalAvailable(f,o.selfVy<-.08&&o.selfY>o.targetY+.05
        &&o.swordCharge>=.9,o.selfVy)){
      f.criticalSubmitted=true;s.lastExitAttackAt=t
      s.lastExitAttackKind='critical';s.metrics.criticalExitAttempts++
      return output(s,'critical-exit',{forward:1,side:0,sprint:false,
        jump:false,sneak:false,shield:false,slot:0,attack:true,use:false,
        release:true,resumeAwayAfterAttack:true},{movement:true})
    }
    if(!s.edgeAttackSent&&o.distance>=2.75&&o.swordCharge>=.85&&!o.closingFast){
      s.edgeAttackSent=true;s.lastExitAttackAt=t
      s.lastExitAttackKind='edge';s.metrics.edgeExitAttempts++
      return output(s,'edge-exit-hit',{forward:1,side:0,sprint:true,
        jump:false,sneak:false,shield:false,slot:0,attack:true,use:false,
        release:true,resumeAwayAfterAttack:true},{movement:true})
    }
  }
  return output(s,'single-jump-exit',{forward:o.wallMargin<1.4?0:1,
    side:0,sprint:true,jump,sneak:false,slot:0,
    shield:false,attack:false,use:false,
    release:true,aimAway:true},{movement:true})
}
function safeRange(s,o){
  const min=5+Math.max(.2,o.opponentSpeed||0)*(o.crossbowLoaded?8:26)
  return o.distance>=min&&o.distance<=18&&!o.closingFast&&!o.arrowThreat
    &&!o.opponentShieldEffective&&o.wallMargin>=1.2
    &&o.now-s.lastHurtAt>300
}
function ranged(s,o){
  const t=o.now
  const motion={forward:0,side:o.flankSide||1,sprint:false,
    jump:false,sneak:false}
  if(s.rangedMode&&(!safeRange(s,o)||t-s.rangedStartedAt>2500))
    s.rangedMode=null
  if(!s.rangedMode&&safeRange(s,o)&&t-s.lastRangedAttemptAt>1500){
    if(o.crossbowLoaded&&(o.opponentRanged
        ||t-s.firstAt>=5000&&o.distance<=16))
      s.rangedMode='crossbow'
    else if(o.opponentRanged&&o.arrows>0)s.rangedMode='bow'
    else if(!o.crossbowLoaded&&o.arrows>0&&t-s.firstAt>5000
        &&o.distance>=12&&t-s.lastLoadAt>5000){
      s.rangedMode='load';s.lastLoadAt=t
    }
    s.rangedStartedAt=t
  }
  if(s.rangedMode==='crossbow'){
    if(o.offhand==='crossbow'){
      s.rangedMode=null;s.lastRangedAttemptAt=t;s.rangedFireSentAt=t
      s.metrics.rangedFireRequests++
      return output(s,'crossbow-fire',{...motion,slot:4,shield:false,
        attack:false,use:true,release:false},{ranged:true,movement:true})
    }
    return output(s,'crossbow-ready',{...motion,slot:4,shield:false,
      attack:false,use:true,release:false},{ranged:true,movement:true})
  }
  if(s.rangedMode==='load'){
    if(o.crossbowLoaded){
      s.rangedMode=null;s.lastRangedAttemptAt=t
      return output(s,'crossbow-load-release',{...motion,slot:4,
        shield:false,attack:false,use:false,release:true},
        {ranged:true,movement:true})
    }
    s.metrics.crossbowLoadFrames++
    return output(s,'crossbow-load',{...motion,slot:4,shield:false,
      attack:false,use:true,release:false},{ranged:true,movement:true})
  }
  if(s.rangedMode==='bow'){
    if(o.bowUsing&&o.bowDrawMs>=plannedBowDrawMs(o.distance)){
      s.rangedMode=null;s.lastRangedAttemptAt=t
      return output(s,'bow-release',{...motion,slot:1,shield:false,
        attack:false,use:false,release:true},{ranged:true,movement:true})
    }
    s.metrics.bowDrawFrames++
    return output(s,'bow-draw',{...motion,slot:1,shield:false,
      attack:false,use:true,release:false},{ranged:true,movement:true})
  }
  return null
}
function plan(s,o){
  const t=o.now;if(!s.firstAt)s.firstAt=t
  s.lastAction=null;s.lastRangedOverlay=false;s.lastMovementOverride=false
  advance(s,o)
  const defence=arrow(s,o);if(defence){s.orbitUntil=0;return defence}
  if(s.mode==='exit')return exit(s,o)
  if(s.returnAxePending){
    s.returnAxePending=false
    return output(s,'landed-return-axe',{forward:1,side:0,sprint:true,
      jump:false,sneak:false,slot:7,shield:false,
      attack:false,use:false,release:true,aimAway:true},{movement:true})
  }
  if(s.mode==='counter')return output(s,'counter-confirm-wait',{
    forward:0,side:0,sprint:false,jump:false,sneak:false,slot:7,
    shield:o.shieldReady,attack:false,use:false,release:false},
    {movement:true})
  const counter=s.mode==='hand'&&s.blockKind==='public-block'
    &&s.blockCandidateAt>s.lastHandledBlockAt
    &&t-s.blockCandidateAt<=350&&s.lastHurtAt<s.blockCandidateAt
    &&o.distance<=3.2&&o.charge>=.7
    &&(o.shieldRaised||o.shieldCooldownRemainingMs>0)
  if(counter){
    s.lastHandledBlockAt=s.blockCandidateAt;s.mode='counter'
    s.counterSentAt=t;s.counterPacketAt=-Infinity
    s.counterBroken=o.shieldCooldownRemainingMs>0
    s.rangedMode=null;s.metrics.counterAttempts++
    return output(s,'shield-counter',{forward:1,side:0,sprint:true,
      jump:false,sneak:false,slot:7,shield:false,attack:true,
      use:false,release:true},{movement:true})
  }
  const shot=ranged(s,o);if(shot)return shot
  if(s.mode==='sync'){s.metrics.syncFrames++;return null}
  s.metrics.guardFrames++
  return guard(s,o)
}
function counterHurt(s,t,broken=false){
  if(s.mode!=='counter'||s.counterPacketAt<s.counterSentAt
      ||t-s.counterPacketAt>350)return false
  broken=broken||s.counterBroken
  s.metrics.counterHits++;if(broken)s.metrics.brokenShieldCounterHits++
  if(!broken){s.mode='hand';return true}
  s.mode='exit';s.exitStartedAt=t;s.horizontalExitObserved=false
  s.edgeAttackSent=false;s.lastExitAttackAt=0;s.lastExitAttackKind=''
  s.rangedMode=null;hop.arm(s.hop,t);return true
}
function exitHurt(s,t){
  if(s.mode!=='exit'||!s.lastExitAttackAt||t-s.lastExitAttackAt>350)
    return false
  s.metrics.exitHits++
  if(s.lastExitAttackKind==='edge')hop.acceptExit(s.hop)
  s.lastExitAttackAt=0;return true
}
module.exports={createState,publicArrowThreat,plan,counterHurt,exitHurt}
