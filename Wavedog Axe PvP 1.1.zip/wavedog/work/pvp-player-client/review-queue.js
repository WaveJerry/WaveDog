/** Alternate old and live Qwen reviews without losing a completed bout. */
function takeBatch (current, history, limit, force, historicalTurn) {
  if (!current.length && !history.length) return null
  const useHistory = history.length && (!current.length
    || (current.length < limit && !force) || historicalTurn)
  if (!useHistory && !force && current.length < limit) return null
  const source = useHistory ? history : current
  const batch = source.splice(0, limit)
    .sort((a,b) => String(a.at).localeCompare(String(b.at)))
  return { batch, source, historical: Boolean(useHistory), nextHistoricalTurn: !useHistory }
}

module.exports = { takeBatch }
