'use strict'
const {orbitGoal,orbitHeading,confirmedRear}=require('./protocol-mechanical-math')
// One planner. No network, inventory, movement or attack side effects here.
// Public observations only; receipt IDs bind counter ownership to an actual hit.
function createState (opponent = 'opponent') {
  return { opponent, mode: 'GUARD', blocked: null, pending: null, shieldUntil: 0,
    escapeAt: 0, airborne: false, jumpSent: false, exitHit: false,
    orbitUntil: 0, nextOrbit: 0, side: 1,
    ranged: null, rangedAt: 0, rangedPhase:null,rangedSerial:0,spentShotEvent:0,
    rangedUseAt:0,orbitGoal:null,orbitLastAt:-1000,orbitWoundAt:-1000,
    rearSeen:false,rearAt:-1000,rearSpent:-1000,sideUntil:0,
    previousReach:Infinity,openingSeen:false,openingAt:-1000,takeOpening:false,
    nextRanged: 0, transitions: [], nextId: 1 }
}
function transition (s, mode, tick, reason) {
  if (s.mode === mode) return
  s.transitions.push({ tick, from: s.mode, to: mode, reason })
  s.mode = mode
}
function receipt (s, e, tick) {
  if (e.type === 'shield_disabled') s.shieldUntil = tick + e.cooldownTicks
  if (e.type === 'self_state') s.shieldUntil = tick + e.shieldCooldown
  if (e.type === 'blocked_melee') s.blocked = { tick, id: e.blockId }
  if(e.type==='damage'&&e.victim==='WaveDog'&&e.melee&&!e.cancelled&&e.amount>0
      &&s.mode==='GUARD'&&(tick<s.orbitUntil||tick-s.orbitLastAt<=1)) {
    s.orbitWoundAt=tick;s.orbitUntil=0
  }
  if (e.type === 'attack_packet' && s.pending?.id === e.attackId)
    s.pending.packet = e.willAttack !== false
  if (e.type !== 'damage' || e.cancelled || !(e.amount > 0)) return
  if (e.attacker === 'WaveDog' && e.victim === s.opponent
      && s.pending?.id === e.attackId && s.pending.packet && tick - s.pending.tick <= 8) {
    if (s.pending.kind === 'counter') {
      if (tick < s.shieldUntil) {
        transition(s, 'ESCAPE', tick, 'this-counter-native-hit-and-shield-disabled')
        s.escapeAt = tick; s.airborne = s.jumpSent = s.exitHit = false
      } else transition(s, 'GUARD', tick, 'counter-hit-shield-available')
    } else if (s.pending.kind === 'escape-critical' && e.nativeCritical) {
      transition(s, 'NEURAL', tick, 'native-escape-critical')
    }
    s.pending = null
  }
}
const neutral = () => ({ forward: 0, side: 0, sprint: false, jump: false,
  sneak: false, slot: null, attack: false, shield: false, offhand: 'shield', ranged: null })
function requestAttack (s, c, kind, tick) {
  c.attack = true; c.shield = false; c.kind = kind; c.attackId = s.nextId++
  s.pending = { id: c.attackId, kind, tick, packet: false }
}
function plan (s, o, neural) {
  const t = o.tick, c = neutral()
  const owners = { movement: 'mechanical', sprint: 'mechanical', jump: 'mechanical',
    sneak: 'disabled', mainhand: 'mechanical', attack: 'mechanical', shield: 'mechanical', offhand: 'mechanical' }
  const shieldReady = o.shieldReady && t >= s.shieldUntil
  // Charge belongs to the observed held weapon, not the slot we plan to select.
  const holdingAxe = o.held === 7
  const orbitAllowed=Number.isFinite(o.health)&&o.health>5
  if(!orbitAllowed){s.orbitUntil=0;s.orbitWoundAt=-1000;s.orbitLastAt=-1000}
  const airGuard=shieldReady&&o.visible&&Boolean(o.targetAirborneThreat||o.targetCriticalThreat)
  // Original OrbitContact: a newly seen rear window is independent of whether
  // this controller started an orbit. Claim it once; never turn it into spam.
  const rear = o.visible && o.reach <= 3 && confirmedRear(o.self,o.sentPosition,o.target,o.targetYaw)
    && !o.targetCriticalThreat
  if (rear && !s.rearSeen) s.rearAt = t
  s.rearSeen = rear
  const enteredReach=o.visible&&o.reach<=3&&s.previousReach>3
  s.previousReach=o.visible?o.reach:Infinity
  // Raised-but-not-yet-effective is not evidence that the shield is down.
  // While using a shield, only a packet-confirmed rear can arm an opening.
  const exposed=o.visible&&(o.targetShieldRaised?rear:!o.targetShieldFacing)
  if(!exposed){s.openingSeen=false;s.takeOpening=false}
  else if(!s.openingSeen||t-s.openingAt>=2){
    s.openingSeen=true;s.openingAt=t
    const chance=(rear ? .85 : .3)*(o.targetSwingRecent ? .15 : 1)
    s.takeOpening=(o.openingDraw??Math.random())<chance
  }
  if (s.pending && t - s.pending.tick > 8) {
    if (s.pending.kind === 'counter') transition(s, shieldReady ? 'GUARD' : 'NEURAL', t, 'counter-no-confirmed-hit')
    s.pending = null
  }
  if (s.mode === 'ESCAPE') {
    if (!o.ground) s.airborne = true
    if (s.airborne && (o.mutualOutOfReach || o.ground))
      transition(s, 'NEURAL', t, o.mutualOutOfReach ? 'mutual-reach-exit' : 'landing-fallback')
    else if (!s.airborne && t - s.escapeAt > 5)
      transition(s, 'NEURAL', t, 'takeoff-blocked-no-legacy-retreat')
  }
  if (s.mode === 'GUARD' && !shieldReady && (!s.blocked || t - s.blocked.tick > 6))
    transition(s, 'NEURAL', t, 'shield-disabled-no-counter-opportunity')
  if (s.mode === 'NEURAL' && shieldReady) transition(s, 'SHIELD_RETURN', t, 'shield-cooldown-ended')
  if (s.mode === 'SHIELD_RETURN' && o.shieldEffective && shieldReady)
    transition(s, 'GUARD', t, 'shield-effective-five-ticks')

  if (s.mode === 'NEURAL') {
    if (neural && t - neural.decidedTick >= 0 && t - neural.decidedTick <= 3) {
      Object.assign(c, { forward: neural.forward, side: neural.side, sprint: neural.sprint,
        jump: neural.jump, slot: [0,7].includes(neural.slot) ? neural.slot : o.held,
        attack: neural.attack, kind: 'neural', decidedTick: neural.decidedTick,
        observedWeaponEpoch: neural.observedWeaponEpoch })
      for (const k of ['movement','sprint','jump','mainhand','attack']) owners[k] = 'neural'
    } else for (const k of ['movement','sprint','jump','mainhand','attack']) owners[k] = 'neutral-expired'
  } else if (s.mode === 'ESCAPE') {
    c.slot = 0; c.aimAway = true; c.forward = 1; c.sprint = true
    if (!s.jumpSent && o.ground) c.jump = true
    c.escapeAttackStatus = !s.airborne ? 'awaiting-takeoff'
      : s.exitHit ? 'already-sent' : s.pending ? 'awaiting-hit-receipt'
      : !o.visible ? 'target-not-visible' : o.reach > 3 ? 'out-of-reach'
      : o.targetShieldFacing ? 'target-shield-facing'
      : o.critical ? o.charge > .9 ? 'critical-ready' : 'critical-undercharged'
      : 'awaiting-real-fall-or-edge'
    if (s.airborne && !s.exitHit && !s.pending && o.reach <= 3 && o.visible && !o.targetShieldFacing) {
      if (o.critical && o.charge > .9) {
        requestAttack(s, c, 'escape-critical', t); c.critical = true
      } else if (o.reach >= 2.72 && o.receding && o.charge >= .85) {
        requestAttack(s, c, 'escape-edge', t)
      }
    }
  } else {
    // The counter packet already prepared the escape sword. While its native
    // hit receipt is in flight, do not switch back to axe and reset charge a
    // second time. This is COUNTER ownership only, never neural weapon control.
    c.slot = s.mode === 'COUNTER' && !shieldReady && s.pending?.packet && o.held === 0 ? 0 : 7
    c.shield = shieldReady
    if (s.mode === 'GUARD' && !airGuard) {
      if (t >= s.sideUntil) {
        s.side = (o.sideDraw ?? Math.random()) < .5 ? -1 : 1
        s.sideUntil = t + 8 + Math.floor((o.sideDurationDraw ?? Math.random()) * 9)
      }
      // Original pressureMove: approach diagonally, side-step only in overlap.
      c.forward = o.reach > .65 ? 1 : 0
      c.side = o.visible ? s.side : 0
      const wasOrbit=t<s.orbitUntil||t-s.orbitLastAt<=1
      const wounded=t-s.orbitWoundAt<=3
      const rearWindow=rear && (s.rearAt>s.rearSpent || o.charge>=.999)
      // A fresh real block outranks a rear opening; only the former can arm
      // the shield-break counter -> sword-hop chain.
      const blockPending=s.blocked && t-s.blocked.tick<=6
      if(!blockPending&&!s.pending&&rear&&(wounded||rearWindow||wasOrbit)
          &&o.visible&&o.reach<=3&&!o.targetShieldFacing&&!o.targetCriticalThreat
          &&holdingAxe&&(wounded||o.charge>=.999)) {
        requestAttack(s,c,wounded?'orbit-reply':'orbit-rear',t)
        c.forward=1;c.side=0;c.sprint=true;s.orbitUntil=0;s.orbitWoundAt=-1000
      } else if(!blockPending&&!s.pending&&exposed&&o.reach<=3&&holdingAxe&&o.charge>=.999
          &&!o.targetCriticalThreat&&(enteredReach||s.takeOpening)){
        // Original pressure(): take a newly entered/exposed window, rather
        // than waiting forever for a block when the opponent does not attack.
        requestAttack(s,c,'guard-opening',t)
        c.forward=1;c.side=0;s.orbitUntil=0
      } else if(t<s.orbitUntil) {
        if(!o.ground||o.wallMargin<.8||o.targetCriticalThreat) s.orbitUntil=0
        else {
          c.worldHeading=orbitHeading(o.self,o.target,s.orbitGoal)
          if(!c.worldHeading)s.orbitUntil=0
          else {c.shield=false;c.forward=1;c.side=0;c.sprint=true;c.orbit=true}
        }
      } else if(orbitAllowed&&!s.pending&&!wounded&&o.shieldEffective&&o.targetShieldFacing
          &&o.distance<=.85&&o.reach<.85&&o.ground
          &&o.targetGrounded!==false&&!o.targetCriticalThreat&&!o.targetSwingRecent
          &&holdingAxe&&o.charge>=.999&&t>=s.nextOrbit&&o.wallMargin>1.2&&o.self&&o.target) {
        s.nextOrbit=t+8
        if((o.orbitDraw??Math.random())<.45) {
          s.side=o.orbitSide??(Math.random()<.5?-1:1)
          s.orbitGoal=orbitGoal(o.targetYaw,s.side<0);s.orbitUntil=t+5
          c.worldHeading=orbitHeading(o.self,o.target,s.orbitGoal)
          if(c.worldHeading){c.shield=false;c.forward=1;c.side=0;c.sprint=true;c.orbit=true}
        }
      }
      if (blockPending && o.visible && o.reach <= 3
          && holdingAxe && o.charge >= .7 && !s.pending && !c.attack) {
        requestAttack(s, c, 'counter', t)
        // The attack is still made with the axe. Prepare the sword immediately
        // AFTER that packet when the shield is already disabled; waiting until
        // the next frame wastes the last airborne sword-charge window.
        if (!shieldReady) c.afterAttackSlot = 0
        c.sprint = true; c.forward = 1
        transition(s, 'COUNTER', t, 'confirmed-own-melee-block')
      }
    }
    // COUNTER immediately asks to re-raise; an attack command itself releases.
  }
  if (s.mode === 'COUNTER' && !c.attack) c.shield = shieldReady

  // Ranged is an offhand overlay, never a movement command or an early return.
  const legalStrike = c.attack && o.visible && o.reach <= 3
  const mirrorBowShot=s.ranged==='bow'&&(o.targetShotEvent||0)>(s.rangedShotEvent||0)
    &&t-(o.targetShotTick??-1000)>=0&&t-o.targetShotTick<=3
  const arrowShield=shieldReady&&o.offhandShieldReady
    &&(o.shieldEffective||o.arrowThreat?.time>=5)
  const bowDodgeReply=mirrorBowShot&&o.arrowThreat&&!arrowShield
  const urgent = legalStrike || ['COUNTER','SHIELD_RETURN'].includes(s.mode)
    || Boolean(s.blocked && t - s.blocked.tick < 7) || o.arrowThreat&&!bowDodgeReply
  // No autonomous anti-rush shot. A loaded bolt belongs to shot-for-shot
  // synchronization; drawing/loading or approaching is not a shot event.
  // Mirroring a public ranged action is legal at close range too. The former
  // blanket six-block cutoff silently disabled the original close bow mirror
  // and repeatedly cancelled crossbow loading when either player approached.
  // Real melee/arrow emergencies still preempt within this same command.
  const safe = o.visible && !urgent && s.mode !== 'ESCAPE'
  if (!safe) {s.ranged=null;s.rangedPhase=null}
  if(s.ranged==='load-crossbow'&&!o.targetLoading&&!o.targetKnownLoaded){s.ranged=null;s.rangedPhase=null}
  if(s.ranged==='bow'&&!o.targetBow&&!mirrorBowShot){s.ranged=null;s.rangedPhase=null}
  if(s.rangedPhase==='verify-fire') {
    if(!o.loaded||t-s.rangedUseAt>=8){s.ranged=null;s.rangedPhase=null;s.nextRanged=Math.max(s.nextRanged,t+15)}
  }
  if(s.rangedPhase==='verify-load'&&o.loaded){s.ranged=null;s.rangedPhase=null;s.nextRanged=t+15}
  if(s.ranged&&t-s.rangedAt>45){s.ranged=null;s.rangedPhase=null;s.nextRanged=t+15}
  if (safe && !s.ranged && t >= s.nextRanged) {
    if (o.loaded && (o.targetShotEvent || 0) > s.spentShotEvent
        && t - (o.targetShotTick ?? -1000) >= 0 && t - o.targetShotTick <= 3) {
      s.ranged = 'fire-crossbow';s.rangedSource='ranged-sync'
    }
    else if (!o.loaded && o.arrows > 0 && o.targetLoading)
      s.ranged = 'load-crossbow'
    else if (o.arrows > 0 && o.targetBow) s.ranged = 'bow'
    if (s.ranged) {
      if(s.ranged!=='fire-crossbow')s.rangedSource='ranged-sync'
      s.rangedAt=t;s.rangedPhase='prepare';s.rangedSerial++;s.rangedShotEvent=o.targetShotEvent||0
    }
  }
  if (s.ranged&&!s.rangedPhase.startsWith('verify')) {
    c.shield = false; c.offhand = s.ranged === 'bow' ? 'bow' : 'crossbow'
    c.ranged=s.ranged;c.rangedId=s.rangedSerial
    c.rangedRelease=s.ranged==='bow'&&mirrorBowShot
    if(c.rangedRelease)s.rangedShotEvent=o.targetShotEvent
    // A main-hand slot update also interrupts offhand use in vanilla. Only
    // the ranged overlay owns these two channels until it ends/preempts.
    c.slot = o.held; c.attack = false
    owners.mainhand = owners.attack = 'mechanical-ranged'
    c.rangedReason=s.rangedSource||'ranged-sync'
    if(s.ranged==='load-crossbow'&&o.loaded){c.ranged=null;s.ranged=null;s.rangedPhase=null}
  }
  // Arrow emergency can cancel ranged use or a planned strike in the same tick.
  if (o.arrowThreat) {
    const releaseWhileDodging=bowDodgeReply&&c.ranged==='bow'&&c.rangedRelease&&!legalStrike
    if(!releaseWhileDodging){s.ranged = null;s.rangedPhase=null;c.ranged = null}
    c.attack = false;c.worldHeading=null;c.orbit=false
    owners.attack = owners.shield = 'mechanical-arrow'
    // Side keys were predicted in the current view, so preserve that view
    // during a dodge; turning toward the target would reverse the dodge.
    if (arrowShield) {
      c.shield = true; c.offhand = 'shield'; c.arrowYaw = o.arrowThreat.yaw
      c.aimAway=false;c.forward=c.side=0;c.sprint=c.jump=false
      owners.movement=owners.sprint=owners.jump='mechanical-arrow'
      owners.offhand = 'mechanical-arrow'
    } else {
      c.shield = false; c.side = o.arrowThreat.side || 0
      c.forward = 0; c.sprint = false; c.jump = Boolean(o.ground && o.arrowThreat.jump)
      c.aimAway = false
      c.keepLook = true
      owners.movement = owners.sprint = owners.jump = 'mechanical-arrow'
    }
  }
  // Original shieldAirborne has priority over pressure/opening/orbit/counter
  // and ranged use whenever a usable shield faces a current/future air threat.
  // A truly disabled shield leaves ESCAPE/NEURAL and their helpers untouched.
  if(airGuard){
    s.orbitUntil=0;s.ranged=null;s.rangedPhase=null
    c.shield=true;c.offhand='shield';c.attack=false;c.ranged=null;c.orbit=false
    c.worldHeading=null;c.aimAway=false;c.keepLook=false;c.jump=false;c.sprint=false
    // Prepare the axe BEFORE starting shield use. Once raised (including its
    // five-tick warm-up), keep the active stack: switching would drop protection.
    c.slot=o.shieldRaised||o.shieldEffective?o.held:7;c.guardAirborne=true
    c.forward=0;c.side=0;delete c.arrowYaw
    for(const key of ['movement','sprint','jump','mainhand','attack','shield','offhand'])owners[key]='mechanical-airborne-guard'
  }
  c.sneak = false
  return { command: c, owners, mode: s.mode }
}
function rangedApplied(s,command,result,tick) {
  if(!command.ranged||command.rangedId!==s.rangedSerial)return
  if(result.fireSent) {
    s.rangedPhase='verify-fire';s.rangedUseAt=tick
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
  } else if(result.loadReleased) {s.rangedPhase='verify-load';s.rangedUseAt=tick}
  else if(result.bowReleased) {
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
    s.ranged=null;s.rangedPhase=null;s.nextRanged=tick+8
  }
  else if(result.useStarted)s.rangedPhase='using'
}
function applied (s, command, attacked, tick) {
  if(s.mode==='ESCAPE'&&command.aimAway&&command.jump)s.jumpSent=true
  if (s.pending && !s.pending.packet && s.pending.tick === tick && !attacked) {
    const counter=s.pending.kind==='counter';s.pending=null
    if(counter)transition(s,'GUARD',tick,'counter-not-sent-retry-original-block')
  }
  if (attacked && command.kind === 'counter') {
    s.blocked=null
    if(s.pending?.id===command.attackId)s.pending.packet=true
  }
  if (attacked && ['escape-critical','escape-edge'].includes(command.kind)) s.exitHit=true
  if (attacked && command.kind === 'orbit-rear') s.rearSpent=s.rearAt
  if(command.orbit&&Number.isFinite(tick))s.orbitLastAt=tick
}
module.exports = { createState, receipt, plan, applied, rangedApplied }
