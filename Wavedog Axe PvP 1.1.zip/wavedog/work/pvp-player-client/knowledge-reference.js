const fs = require('node:fs')
const path = require('node:path')

const source = path.join(__dirname, 'new-learning', 'reference',
  'shield-axe-pvp-knowledge-20261111.md')
const focusTopics = {
  FREE: ['共同目标', '风格'], CHARGE: ['蓄力', '连招'], SHIELD: ['有效盾', '持盾', '盾反'],
  AXE_BREAK: ['有效盾', '眩晕破盾'], CRITICAL: ['暴击', '跳劈', '惩罚暴击'],
  SPRINT_KB: ['疾跑', 'W-tap'], ESCAPE: ['跑跳', '脱离', '弓、弩'],
  SYNC: ['同步换血', '连招'], FLANK: ['绕盾', '绕反'], COMBO: ['连招', '极限控距'],
  BOW: ['弓、弩', '箭矢防御', '弓弩弹道'], CROSSBOW: ['弓、弩', '跑跳', '弓弩弹道'],
  DODGE: ['箭矢防御', '跳劈', '来箭侧移'], WALL: ['墙、中心'],
  LATENCY: ['感知、延迟'], OPPONENT: ['复盘', '风格']
}

function chapters (markdown) {
  return String(markdown).split(/(?=^## [^#])/m).filter(part => part.startsWith('## '))
    .map(part => ({ title: part.split('\n', 1)[0].slice(3), body: part }))
}

function referenceFor (question = '', focus = 'FREE', maxChars = 850) {
  if (!fs.existsSync(source)) return []
  const items = chapters(fs.readFileSync(source, 'utf8'))
  const topics = focusTopics[focus] || focusTopics.FREE
  const query = String(question).toLowerCase()
  const grams = new Set()
  for (const word of query.match(/[\p{Script=Han}]{2,}|[a-z0-9_-]{3,}/gu) || []) {
    if (/^[a-z0-9_-]+$/.test(word)) grams.add(word)
    else for (let i = 0; i < word.length - 1; i++) grams.add(word.slice(i, i + 2))
  }
  const ranked = items.map((item, index) => {
    const title = item.title.toLowerCase()
    const body = item.body.toLowerCase()
    const topicHits = topics.filter(topic => title.includes(topic.toLowerCase())).length
    const queryHits = [...grams].reduce((score, gram) =>
      score + (title.includes(gram) ? 5 : body.includes(gram) ? 1 : 0), 0)
    return { ...item, index, score: topicHits * 8 + queryHits }
  }).sort((a, b) => b.score - a.score || a.index - b.index)
  const chosen = ranked.filter(item => item.score > 0).slice(0, 2)
  if (!chosen.length) chosen.push(ranked[0])
  const budget = Math.max(180, Math.floor(maxChars / chosen.length))
  return chosen.map(item => item.body.slice(0, budget).trim())
}

module.exports = { chapters, referenceFor, source }
