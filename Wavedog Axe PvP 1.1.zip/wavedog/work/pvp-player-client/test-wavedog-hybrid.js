const assert = require('node:assert/strict')
const brain = require('./wavedog-hybrid')
const hop = require('./wavedog-counter-escape-hop')
const { composeControl } = require('./control-arbitration')

const obs = (now, extra = {}) => ({
  now, distance: 3, charge: .9, swordCharge: .9,
  ground: true, wallMargin: 6, shieldReady: true,
  shieldRaised: true, shieldCooldownRemainingMs: 0,
  opponentShieldEffective: false, opponentSpeed: .2,
  opponentRanged: false, crossbowLoaded: true,
  offhand: 'shield', arrows: 4, closingFast: false,
  opponentSwingAt: -Infinity, shieldDisabledAt: -Infinity,
  flankSide: 1, opponentShieldFacing: false,
  arrowThreat: null, selfY: 221, targetY: 221, selfVy: 0,
  ...extra
})
const gru = { forward: 1, side: -1, sprint: true, jump: true,
  sneak: true, shield: false, attack: true, slot: 0,
  use: false, release: false }

const guard = brain.createState()
assert.equal(brain.plan(guard, obs(100, { distance: 24 })).kind,
  'shield-pressure') // A preloaded crossbow does not force an opening load.
const pressure = brain.plan(guard, obs(150, {
  distance: 2.7, opponentShieldEffective: true }))
assert.equal(pressure.kind, 'shield-pressure')
const guarded = composeControl(gru, pressure, true)
assert.equal(guarded.decision.attack, false)
assert.equal(guarded.decision.shield, true)
assert.equal(guarded.decision.jump, false)
assert.equal(guarded.decision.sneak, false)
assert.equal(guarded.decision.forward, 1)
assert.equal(guarded.owners.movement, 'WaveDog')
assert.deepEqual(guarded.ignoredHeads,[0,1,2,3,4,5,6,7,8])
assert.ok(guarded.ignoredHeads.includes(2))
assert.ok(guarded.ignoredHeads.includes(3))
assert.ok(guarded.ignoredHeads.includes(4))

const orbit = brain.createState()
const around = brain.plan(orbit, obs(100, { distance:.8,
  opponentShieldEffective:true, opponentShieldFacing:true }))
assert.equal(around.kind,'shield-orbit')
assert.equal(around.decision.shield,false)
assert.equal(around.decision.attack,false)
assert.equal(around.decision.sprint,true)
assert.equal(composeControl(gru,around,true).owners.movement,'WaveDog')
assert.equal(brain.plan(orbit,obs(410,{distance:1.2,
  opponentShieldEffective:true,opponentShieldFacing:true})).kind,
  'shield-pressure')

const brokenBlock = brain.createState()
brokenBlock.blockCandidateAt = 100
brokenBlock.blockKind = 'public-block'
const brokenCounter = brain.plan(brokenBlock,obs(120,{
  shieldReady:false,shieldRaised:false,shieldCooldownRemainingMs:5000,
  shieldDisabledAt:90,opponentSwingAt:80,distance:2.5 }))
assert.equal(brokenCounter.kind,'shield-counter')
brokenBlock.counterPacketAt = 125
assert.equal(brain.counterHurt(brokenBlock,140,false),true)
assert.equal(brokenBlock.mode,'exit')

guard.blockCandidateAt = 200
guard.blockKind = 'public-block'
const counter = brain.plan(guard, obs(210, { distance: 2.7 }))
assert.equal(counter.kind, 'shield-counter')
const counterInput = composeControl(gru, counter, true)
assert.equal(counterInput.decision.attack, true)
assert.equal(counterInput.decision.slot, 7)
assert.equal(counterInput.decision.jump, false)
assert.equal(counterInput.decision.sneak, false)
assert.equal(counterInput.owners.movement, 'WaveDog')
assert.ok(counterInput.ignoredHeads.includes(2))
assert.ok(counterInput.ignoredHeads.includes(3))
assert.equal(brain.counterHurt(guard, 230, true), false) // No attack packet.
guard.counterPacketAt = 205
assert.equal(brain.counterHurt(guard, 230, true), false) // Previous packet.
guard.counterPacketAt = 225
assert.equal(brain.counterHurt(guard, 250, true), true)
assert.equal(guard.mode, 'exit')
const takeoff = brain.plan(guard, obs(260, { distance: 2.6 }))
assert.equal(takeoff.decision.jump, true)
assert.equal(takeoff.decision.slot, 0)
assert.equal(brain.plan(guard, obs(310, {
  ground: false, distance: 2.6, selfVy: .3 })).kind, 'single-jump-exit')
guard.lastHurtAt = 330
assert.equal(brain.plan(guard, obs(350, {
  ground: false, distance: 2.6, wallMargin: .5,
  selfVy: -.05 })).kind, 'single-jump-exit')
assert.equal(guard.mode, 'exit') // Damage and a wall do not hand off in air.
assert.equal(brain.plan(guard, obs(400, {
  ground: false, distance: 2.9, shieldReady: false,
  shieldRaised: false, arrowThreat:
  { id: 10, time: 2, side: -1, jump: false } })).kind, 'arrow-side-jump')
assert.equal(guard.mode, 'exit') // Arrow overlay preserves base state.
const landing = brain.plan(guard, obs(700, {
  ground: true, distance: 2.9 }))
assert.equal(landing.kind, 'landed-return-axe')
assert.equal(landing.decision.slot, 7)
assert.equal(guard.mode, 'sync') // Landed inside reach still hands off.
const landingInput = composeControl(gru, landing, true)
assert.equal(landingInput.decision.attack, false)
assert.equal(landingInput.decision.jump, false)
assert.equal(landingInput.decision.slot, 7)
assert.equal(landingInput.owners.mainHand, 'WaveDog')
assert.equal(landingInput.owners.weapon, 'WaveDog')
assert.equal(landingInput.owners.movement, 'WaveDog')
assert.equal(brain.plan(guard, obs(750, {
  distance: 2.9, shieldReady: false, shieldRaised: false })), null)
assert.equal(guard.mode, 'sync')
assert.equal(brain.plan(guard, obs(800, {
  shieldReady: true, shieldRaised: false })).kind, 'shield-pressure')
assert.equal(brain.plan(guard, obs(850, {
  shieldReady: true, shieldRaised: true })).kind, 'shield-pressure')
assert.equal(guard.mode, 'hand')

const miss = brain.createState()
miss.mode = 'counter'; miss.counterSentAt = 100
assert.equal(brain.plan(miss, obs(500)).kind, 'shield-pressure')
assert.equal(miss.mode, 'hand')
const intactShield = brain.createState()
intactShield.mode = 'counter'; intactShield.counterSentAt = 100
intactShield.counterPacketAt = 125
assert.equal(brain.counterHurt(intactShield, 150, false), true)
assert.equal(intactShield.mode, 'hand')
assert.equal(brain.plan(intactShield, obs(200)).kind, 'shield-pressure')
const swingOnly = brain.createState()
swingOnly.blockCandidateAt = 100
swingOnly.blockKind = 'swing'
assert.equal(brain.plan(swingOnly, obs(150)).kind, 'shield-pressure')
const noTakeoff = brain.createState()
noTakeoff.mode = 'exit'; noTakeoff.exitStartedAt = 100
hop.arm(noTakeoff.hop, 100)
assert.equal(brain.plan(noTakeoff, obs(300)).kind, 'landed-return-axe')
assert.equal(noTakeoff.mode, 'sync')

const falling = brain.createState()
falling.mode = 'exit'; falling.exitStartedAt = 100
hop.arm(falling.hop, 100)
brain.plan(falling, obs(150, { distance: 2.6 }))
const criticalExit = brain.plan(falling, obs(250, {
  ground: false, distance: 2.6, selfVy: -.2,
  selfY: 222, targetY: 221, swordCharge: 1 }))
assert.equal(criticalExit.kind, 'critical-exit')
assert.equal(criticalExit.decision.slot, 0)
assert.equal(criticalExit.decision.sprint, false)
assert.equal(criticalExit.decision.resumeAwayAfterAttack, true)

const ranged = brain.createState()
assert.equal(brain.plan(ranged, obs(400, {
  distance: 10, offhand: 'shield' })).kind, 'shield-pressure')
assert.equal(brain.plan(ranged, obs(5600, {
  distance: 10, offhand: 'shield' })).kind, 'crossbow-ready')
assert.equal(ranged.mode, 'hand')
assert.equal(brain.plan(ranged, obs(5650, {
  distance: 10, offhand: 'crossbow' })).kind, 'crossbow-fire')
assert.equal(ranged.mode, 'hand')
assert.equal(brain.plan(ranged, obs(5700, {
  distance: 10, crossbowLoaded: false, offhand: 'crossbow' })).kind,
  'shield-pressure')

console.log('CONTROL_CHAIN_PASS')
