'use strict'
const {spawn}=require('node:child_process')
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto')
// Gson accepts these strings as doubles. JSON's default Infinity -> null would
// destroy the meaning of an unbounded route clearance and crash record decode.
function encodeRequest(row){
  return JSON.stringify(row,(key,value)=>{
    if(typeof value!=='number'||Number.isFinite(value))return value
    if(Number.isNaN(value))throw Error('Invalid NaN in legacy86 request field: '+key)
    return value===Infinity?'Infinity':'-Infinity'
  })
}
function createLegacyRuntime({onError=()=>{}}={}){
  const base=path.resolve(__dirname,'../legacy86-reference')
  const cfg=JSON.parse(fs.readFileSync(path.join(base,'launch.json'),'utf8'))
  const jar=cfg.classpath.split(path.delimiter).find(p=>p.endsWith('PvPArenaAI.jar'))
  const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')
  if(sha(jar)!==cfg.originalJarSha256||sha(cfg.model)!==cfg.modelSha256)throw Error('8.6 reference bytes changed')
  const child=spawn(cfg.java,['--add-opens=java.base/java.util=ALL-UNNAMED','-cp',cfg.classpath,'local.pvpbot.ai.Legacy86Runtime',cfg.model],
    {windowsHide:true,stdio:['pipe','pipe','pipe']})
  child.once('spawn',()=>{
    try{const os=require('node:os');os.setPriority(child.pid,os.constants.priority.PRIORITY_HIGH)}catch{}
  })
  let sequence=0,buffer='',closed=false,failed=null
  const pending=new Map()
  function fail(error){
    failed=error
    for(const p of pending.values()){clearTimeout(p.timer);p.reject(error)}pending.clear()
    if(!closed)onError(error)
  }
  child.on('error',fail);child.on('exit',code=>fail(Error('8.6 runtime exited: '+code)))
  child.stderr.on('data',()=>{}) // Compiler/runtime diagnostics never contain player credentials.
  child.stdout.setEncoding('utf8');child.stdout.on('data',data=>{
    buffer+=data
    for(let n;(n=buffer.indexOf('\n'))>=0;){
      const line=buffer.slice(0,n);buffer=buffer.slice(n+1)
      try{
        const row=JSON.parse(line),p=pending.get(row.id)
        if(!p)continue
        pending.delete(row.id);clearTimeout(p.timer)
        if(row.ok)p.resolve(row.result);else p.reject(Error(row.error))
      }catch(error){fail(error)}
    }
  })
  const request=row=>new Promise((resolve,reject)=>{
    if(closed||failed)return reject(failed||Error('8.6 runtime closed'))
    const requestId=++sequence
    const wire=encodeRequest({...row,requestId})+'\n'
    const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('8.6 runtime request timeout'))},2000)
    pending.set(requestId,{resolve,reject,timer});child.stdin.write(wire)
  })
  const classSha256=Object.fromEntries(['Legacy86Reference.class','Legacy86Runtime.class','Legacy86Runtime$Attempt.class','Legacy86Snapshot.class']
    .map(name=>[name,sha(path.join(base,'classes/local/pvpbot/ai',name))]))
  return {request,sha:cfg.originalJarSha256,modelSha:cfg.modelSha256,pid:child.pid,classSha256,
    callback:(method,...args)=>request({command:'callback',method,args}),
    async close(){closed=true;fail(Error('8.6 runtime closing'));child.stdin.end();child.kill()}}
}
module.exports={createLegacyRuntime,encodeRequest}
