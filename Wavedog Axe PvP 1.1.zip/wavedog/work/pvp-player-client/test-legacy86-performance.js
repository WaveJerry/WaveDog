'use strict'
const assert=require('node:assert/strict')
const fs=require('node:fs'),path=require('node:path')
const {performance,monitorEventLoopDelay}=require('node:perf_hooks')
const {createRouteProbe}=require('./protocol-legacy86-route')
const {createCollisionCache}=require('./protocol-legacy86-collision-cache')
const {createRoutePlanner}=require('./protocol-legacy86-planner')
const {planAirThreat,planSpacing}=require('./protocol-legacy86-threat')
const {createAsyncJournal}=require('./protocol-async-journal')
const {createHighRateLoop,monoMs}=require('./protocol-high-rate-loop')
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms))
const solid=[[0,0,0,1,1,1]]
async function run(){
  const os=require('node:os')
  try{os.setPriority(0,os.constants.priority.PRIORITY_HIGH)}catch{}
  let lookups=0,wall=false
  const cache=createCollisionCache({blockAt:(x,y,z)=>{lookups++;return {shapes:y<221||wall&&x===1121?solid:[]}}})
  let p=createRouteProbe({origin:{x:1122.5,y:221,z:960.5},blockAt:(...args)=>cache.get(...args)})
  assert.equal(lookups,0,'constructing a probe must not eagerly allocate 3969 blocks')
  assert(p({x:1122.5,y:221,z:960.5}).clear)
  const first=lookups;p({x:1122.5,y:221,z:960.5});assert.equal(lookups,first)
  assert(first<100,'one local query must read only touched cells')
  cache.get(1121,221,960);wall=true;cache.invalidate({x:1121,y:221,z:960})
  assert(cache.get(1121,221,960).shapes.length,'block updates must expose a newly placed wall')
  wall=false;cache.clear()
  p=createRouteProbe({origin:{x:1122.5,y:221,z:960.5},blockAt:(...args)=>cache.get(...args)})
  const f={self:{x:1122.5,y:221,z:960.5,vx:.1,vy:0,vz:0,ground:true,charge:1,shieldAvailable:false},
    seen:{x:1125.79,y:221.8,z:960.5},targetVelocity:{x:-.2,y:-.1,z:0},targetFloorY:221,
    observation:{visible:true,reach:2.99,targetAirborne:true,targetGrounded:false},latency:{}}
  const planner=createRoutePlanner()
  try{
    const r=await planner.evaluate(f,p)
    assert.deepEqual(r.airPlan,planAirThreat(f,p),'off-thread air result must equal the original pure computation')
    const ground={...f,seen:{...f.seen,y:221},targetVelocity:{x:-.1,y:0,z:0},
      observation:{...f.observation,targetAirborne:false,targetGrounded:true}}
    const g=await planner.evaluate(ground,p)
    assert.deepEqual(g.spacing,planSpacing(ground,p),'off-thread spacing must preserve the same scoring')
    const backlog=await Promise.all(Array.from({length:100},()=>planner.evaluate(f,p)))
    assert(backlog.filter(x=>!x.superseded).length<=2,'never replay 100 queued stale plans')
    assert(planner.stats.superseded>=98)
    const delay=monitorEventLoopDelay({resolution:1});delay.enable()
    const activeWork=[]
    // Exercise both the bounded airborne search and the new contact-angle
    // refinement while the monitoring thread is running.
    const approach={...ground,self:{...ground.self,vx:.05},
      seen:{...ground.seen,x:1126,y:221},observation:{...ground.observation,reach:3.2},
      latency:{observationAgeMs:0}}
    let sequence=0
    const timer=setInterval(()=>activeWork.push(planner.evaluate(++sequence%2?f:approach,p)),20)
    let delivered=0,lastCycles=0,measuredHz=0,maxIntervalMs=0,missedDeadlines=0,recentMisses=[]
    const loop=createHighRateLoop({hz:500,onCycle:a=>{delivered++;lastCycles=a.cycles;measuredHz=a.measuredHz;
      maxIntervalMs=a.maxIntervalMs;missedDeadlines=a.missedDeadlines;recentMisses=a.recentMisses}})
    loop.reset('perf-check')
    loop.sample({matchId:'perf-check',revision:1,atMs:monoMs(),tick:1,source:'packet',
      opponent:{position:{x:3,y:0,z:0},visible:true,grounded:true,half:.3,height:1.8}})
    const started=performance.now();await wait(2200)
    clearInterval(timer);await Promise.all(activeWork);await loop.close()
    const eventLoopP99Ms=delay.percentile(99)/1e6,eventLoopMaxMs=delay.max/1e6;delay.disable()
    const result={targetMonitoringHz:500,workerCycles:lastCycles,delivered,measuredHz,maxIntervalMs,missedDeadlines,recentMisses,
      elapsedMs:performance.now()-started,eventLoopP99Ms,eventLoopMaxMs,planner:planner.stats,cache:cache.stats,
      scope:'offline synthetic public terrain; no live PvP acceptance'}
    const out=path.resolve(__dirname,'../../outputs/wavedog-performance-20261118/offline-performance.json')
    fs.writeFileSync(out,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
    assert(lastCycles>500,'monitoring must continue under planner load')
    assert(measuredHz>=450,'detect a real monitoring-frequency regression instead of just asserting the configured target')
  }finally{await planner.close()}
  // Slow I/O + concurrent appends: no loss, no reordering, finalization waits.
  let content='',calls=0
  const journal=createAsyncJournal({io:{appendFile:async(file,text)=>{calls++;await wait(15);content+=text}}})
  for(let i=0;i<1000;i++)journal.append('bout',i+'\n')
  await wait(2)
  for(let i=1000;i<1100;i++)journal.append('bout',i+'\n')
  await journal.flush('bout')
  assert.equal(content,Array.from({length:1100},(_,i)=>i+'\n').join(''))
  assert(calls<10,'writes should batch, not perform one filesystem call per packet')
  assert.equal(journal.stats.queuedBytes,0)
  console.log('ASYNC_PLANNER_CACHE_JOURNAL_PERFORMANCE_PASS')
}
run().catch(error=>{console.error(error);process.exitCode=1})
