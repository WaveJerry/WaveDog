"""Read native events and completed selfplay to audit skill coverage without claiming mastery."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import json
import sys

base = Path(__file__).resolve().parent
rounds_file = base / 'new-learning/selfplay/rounds.jsonl'
native_file = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogSelfPlayGate/bouts.jsonl')
since = datetime.fromisoformat(sys.argv[1].replace('Z', '+00:00')) if len(sys.argv) > 1 else datetime.now(timezone.utc)


def rows(path):
    with path.open(encoding='utf-8') as source:
        for line in source:
            try:
                row = json.loads(line)
                if datetime.fromisoformat(row['at'].replace('Z', '+00:00')) >= since:
                    yield row
            except (ValueError, KeyError):
                continue


rounds = [r for r in rows(rounds_file) if r.get('reason') == 'death' and not r.get('trainingError')]
events = list(rows(native_file))
styles = defaultdict(Counter)
focuses = defaultdict(Counter)
for row in rounds:
    for fighter, result in row.get('fighters', {}).items():
        styles[fighter][result.get('style', 'UNKNOWN')] += 1
        focuses[fighter][result.get('focus', 'UNKNOWN')] += 1
damages = [e for e in events if e.get('type') == 'damage' and not e.get('cancelled')]
melee = [e for e in damages if e.get('source', 'MELEE') == 'MELEE']
arrows = [e for e in damages if e.get('source') == 'ARROW']
report = {
    'since': since.isoformat(), 'completed_rounds': len(rounds),
    'trained_fighters': sum(len(r.get('training', [])) for r in rounds),
    'per_fighter_style_coverage': {n: dict(v) for n, v in styles.items()},
    'per_fighter_focus_coverage': {n: dict(v) for n, v in focuses.items()},
    'melee_damage_events': len(melee),
    'mean_native_melee_charge': round(sum(e.get('native_attack_charge', 0) for e in melee) / len(melee), 3) if melee else None,
    'shield_disables': sum(e.get('type') == 'shield_disable' and not e.get('cancelled') for e in events),
    'arrow_launches': sum(e.get('type') == 'arrow_launch' for e in events),
    'arrow_damage_events': len(arrows),
    'native_fall_windows': sum(e.get('attacker_fall_distance', 0) > 0 and not e.get('attacker_on_ground')
                               and not e.get('attacker_sprinting') for e in melee),
    'client_ranged_use_requests': sum(f.get('rangedUseChoices', 0) for r in rounds for f in r['fighters'].values()),
    'client_crossbow_loaded_observations': sum(f.get('crossbowLoadedObservations', 0) for r in rounds for f in r['fighters'].values()),
    'low_health_decisions': sum(f.get('lowHealthDecisions', 0) for r in rounds for f in r['fighters'].values()),
    'low_health_attack_choices': sum(f.get('lowHealthAttackChoices', 0) for r in rounds for f in r['fighters'].values()),
    'low_health_visible_opponent_hurts': sum(f.get('visibleOpponentHurtWhileLow', 0) for r in rounds for f in r['fighters'].values()),
    'low_health_retreat_choices': sum(f.get('lowHealthRetreatChoices', 0) for r in rounds for f in r['fighters'].values()),
    'all_six_styles_revisited': bool(styles) and all(len([s for s in v if s != 'UNKNOWN']) == 6 for v in styles.values()),
    'all_sixteen_focuses_revisited': bool(focuses) and all(len([f for f in v if f != 'UNKNOWN']) == 16 for v in focuses.values()),
}
report['assessment'] = 'ACTION_EVIDENCE_MISSING' if not report['arrow_launches'] or not report['native_fall_windows'] else 'NEEDS_SKILL_QUALITY_REVIEW'
print(json.dumps(report, ensure_ascii=False, indent=2))
