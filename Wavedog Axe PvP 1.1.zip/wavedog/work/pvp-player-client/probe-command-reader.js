'use strict'
const fs=require('node:fs')
// Missing/partial commands must stop the fixture, not replay stale controls.
function readProbeCommand(file){
  try{
    const row=JSON.parse(fs.readFileSync(file,'utf8'))
    return row&&typeof row==='object'&&!Array.isArray(row)?row:null
  }catch(error){
    if(error instanceof SyntaxError||error.code==='ENOENT')return null
    throw error
  }
}
module.exports={readProbeCommand}
