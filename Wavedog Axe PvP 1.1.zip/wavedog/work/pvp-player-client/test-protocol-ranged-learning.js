'use strict'
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path')
const {EventEmitter}=require('node:events')
const {createRangedLearning}=require('./protocol-ranged-learning')
const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-ranged-'))
try{
  const log=[],jobs=[]
  const learner=createRangedLearning({root:runtime,runtime,log:(type,row)=>log.push({type,...row}),
    spawnProcess:(executable,args,options)=>{
      const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter()
      assert(options.windowsHide);assert(!options.shell)
      jobs.push({executable,args,child});return child
    }})
  assert.equal(learner.profile(),null)
  assert.equal(learner.completed('WaveDogSon',false),false,'scripted opponents cannot calibrate human motion')
  assert.equal(learner.completed('WaveJerry',true),false,'invalid traces cannot calibrate')
  assert.equal(learner.completed('WaveJerry',false),true)
  assert.equal(learner.completed('wasplan',false),false,'one calibration process at a time')
  assert(jobs[0].args.includes('--publish-runtime'))
  jobs[0].child.stdout.emit('data',Buffer.from('{"bouts":32,"samples":6048,"acceptedBuckets":1}\n'))
  jobs[0].child.emit('close',0)
  assert.equal(log[0].applyFromNextBout,true)
  assert.equal(log[0].liveArrowAccuracyVerified,false)
  const profile={schema:'public-motion-lead-calibration-v1',futureObservationsInLiveInput:false,
    baselineLead:.65,buckets:{'ground:medium':{accepted:true,lead:.53}}}
  fs.writeFileSync(path.join(runtime,'ranged-calibration.json'),JSON.stringify(profile))
  const pinned=learner.profile()
  profile.baselineLead=.6
  fs.writeFileSync(path.join(runtime,'ranged-calibration.json'),JSON.stringify(profile))
  assert.equal(pinned.baselineLead,.65,'already prepared bout retains its prediction model')
  assert.equal(learner.profile().baselineLead,.6,'next preparation sees saved profile')
  assert.equal(learner.completed('wasplan',false),true)
  jobs[1].child.stderr.emit('data',Buffer.from('insufficient validation'))
  jobs[1].child.emit('close',1)
  assert.equal(log.at(-1).type,'ranged-calibration-not-published')
  console.log('RANGED_LEARNING_ASYNC_NEXT_BOUT_PASS')
}finally{fs.rmSync(runtime,{recursive:true,force:true})}
