/** Map a learned retreat run-jump intention to ordinary player key presses. */
function movementInputs (decision, usingItem = false) {
  const forward = Number(decision.forward)
  const side = Number(decision.side)
  const retreatRunJump = forward < -.5 && Boolean(decision.sprint)
    && Boolean(decision.jump) && !decision.shield && !usingItem
  return { forward: forward > .5 || retreatRunJump,
    back: forward < -.5 && !retreatRunJump,
    left: side < -.5, right: side > .5,
    sprint: Boolean(decision.sprint) && !decision.shield && !usingItem,
    jump: Boolean(decision.jump), sneak: Boolean(decision.sneak),
    retreatRunJump }
}

module.exports = { movementInputs }
