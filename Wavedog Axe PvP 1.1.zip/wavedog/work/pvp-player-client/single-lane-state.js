const fs = require('node:fs')
const path = require('node:path')

/** Durable position in a ten-pair cycle; one arena is active at a time. */
class SingleLaneState {
  constructor (file, arenaCount) {
    this.file = file
    this.arenaCount = arenaCount
    this.value = fs.existsSync(file)
      ? JSON.parse(fs.readFileSync(file, 'utf8'))
      : { format: 1, cycle: 1, nextArena: 1, completed: [] }
    if (this.value.format !== 1 || !Number.isInteger(this.value.cycle)
        || this.value.cycle < 1 || !Number.isInteger(this.value.nextArena)
        || this.value.nextArena < 1 || this.value.nextArena > arenaCount
        || !Array.isArray(this.value.completed)
        || this.value.completed.length > arenaCount)
      throw Error('Invalid single-lane cycle state')
  }

  save () {
    fs.mkdirSync(path.dirname(this.file), { recursive: true })
    const temporary = `${this.file}.tmp`
    fs.writeFileSync(temporary, JSON.stringify(this.value))
    fs.renameSync(temporary, this.file)
  }

  complete (report) {
    if (report.trainingError || !report.training?.length)
      throw Error('Cannot advance a bout without a PPO or frozen-opponent receipt')
    if (report.arena !== this.value.nextArena)
      throw Error(`Expected arena ${this.value.nextArena}, got ${report.arena}`)
    const summary = {
      matchId: report.matchId, at: report.at, arena: report.arena,
      bout: report.bout, winner: report.winner, reason: report.reason,
      native: report.native,
      fighters: Object.fromEntries(Object.entries(report.fighters).map(([name, row]) =>
        [name, { role: row.leagueRole, focus: row.focus, style: row.style,
          attacks: row.attacks, misses: row.misses,
          charge: row.meanAttackCharge }])),
      tactics: Object.fromEntries(Object.entries(report.tactics || {}).map(([name, row]) =>
        [name, { shieldBreaks: row.shieldBreaks || 0,
          counterHits: row.counterHits || 0,
          counterEscapes: row.counterEscapes || 0,
          nativeCriticalHits: row.nativeCriticalHits || 0,
          edgeHits: row.edgeHits || 0 }]))
    }
    this.value.completed.push(summary)
    this.value.nextArena = report.arena % this.arenaCount + 1
    this.save()
    return this.value.completed.length === this.arenaCount
  }

  reviewed () {
    if (this.value.completed.length !== this.arenaCount)
      throw Error('Cannot finish an incomplete training cycle')
    this.value.cycle++
    this.value.completed = []
    this.save()
  }
}

module.exports = { SingleLaneState }
