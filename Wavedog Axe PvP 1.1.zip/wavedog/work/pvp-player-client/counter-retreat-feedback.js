/** Only native block -> native counter-hit chains may earn retreat shaping. */
function counterRetreatFeedback (tactics) {
  const entries = []
  for (const result of tactics?.counterOutcomes || []) {
    if (result.edgeBlock && result.blockAt)
      entries.push({ at: result.blockAt, reward: .02, kind: 'edge-block' })
    if (result.progressAt)
      entries.push({ at: result.progressAt, reward: .02, kind: 'counter-separation-progress' })
    if (result.escaped && result.outAt)
      entries.push({ at: result.outAt, reward: .08, kind: 'safe-counter-exit' })
    if (result.punished && result.punishAt)
      entries.push({ at: result.punishAt, reward: -.05, kind: 'counter-punished' })
  }
  return entries
}

module.exports = { counterRetreatFeedback }
