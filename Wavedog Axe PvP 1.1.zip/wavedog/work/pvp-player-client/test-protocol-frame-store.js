'use strict'
const assert=require('node:assert/strict')
const {saveCompletedFrames}=require('./protocol-frame-store')
async function main(){
  const frames=[{tick:1,nativeReceived:3}],writes=[];let attempts=0
  let io={writeFile:async(...args)=>writes.push(args),rename:async()=>{
    if(++attempts<3)throw Object.assign(Error('reader open'),{code:'EPERM'})}}
  let result=await saveCompletedFrames('bout.jsonl',frames,io,async()=>{})
  assert(result.canonical);assert.equal(result.retries,2)
  assert.equal(JSON.parse(writes[0][1]).nativeReceived,3)
  io.rename=async()=>{throw Object.assign(Error('reader open'),{code:'EBUSY'})}
  result=await saveCompletedFrames('bout.jsonl',frames,io,async()=>{})
  assert(!result.canonical);assert.equal(result.path,'bout.jsonl.complete')
  console.log('PROTOCOL_FRAME_STORE_RETRY_AND_DURABLE_FALLBACK_PASS')
}
main().catch(error=>{console.error(error);process.exitCode=1})
