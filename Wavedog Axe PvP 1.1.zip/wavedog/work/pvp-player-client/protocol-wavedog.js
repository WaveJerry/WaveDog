'use strict'
const fs = require('node:fs'), path = require('node:path'), net = require('node:net')
const crypto = require('node:crypto')
const mineflayer = require('mineflayer'), { Vec3 } = require('vec3')
const brain = require('./protocol-wavedog-brain')
const {createFrameClock}=require('./protocol-frame-clock')
const {createPublicHealthTracker}=require('./protocol-public-health')
const {createOrderedJournal}=require('./protocol-ordered-journal')
const {observeRanged,projectileShooterId}=require('./protocol-ranged-observation')
const {executeCommand}=require('./protocol-wavedog-executor')
const {attackCharge}=require('./protocol-attack-charge')
const {requestOffhandSwap}=require('./protocol-offhand-swap')
const {nearestHitPoint,currentViewPacket,immediateLook}=require('./protocol-mechanical-math')
const {damageFeedback}=require('./attack-reward')
const {forecast,forecastFloor,observeMotion}=require('./protocol-airborne-guard')
const { publicArrowThreat } = require('./wavedog-arrow-predictor')
const { bowSpeed, plannedBowDrawMs, solvePitch, leadTarget } = require('./ballistic-aim')
const {solveRangedAim}=require('./protocol-ranged-aim')
const {createRangedLearning}=require('./protocol-ranged-learning')
const root = path.resolve(__dirname, '../..')
const runtime = path.join(root, 'work/wavedog-protocol/runtime')
fs.mkdirSync(runtime, { recursive: true })
const tokenFile = 'D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogProtocolCore/client-token.txt'
const channel = 'wavedog:control'
const credential = path.join(runtime, 'auth.json')
if (!fs.existsSync(credential)) fs.writeFileSync(credential,
  JSON.stringify({ password: crypto.randomBytes(20).toString('hex') }))
const password = JSON.parse(fs.readFileSync(credential)).password
const log = (type, row = {}) => fs.appendFileSync(path.join(runtime, 'client-events.jsonl'),
  JSON.stringify({ at: new Date().toISOString(), type, ...row }) + '\n')
let bot, socket, publicHealth, modelReady = false, policySha, session, tick = 0, requestId = 0
let modelBuffer = '', latest, use = null, switching = false, lastSwing = -1000
let authAt = 0, shieldUntil = 0, lastHeartbeat = 0, closing = false
let nativeSelf = null, lastAttackTick = -1000, lastSentPosition=null
let weaponEpoch = 0
const rangedLearning=createRangedLearning({root,runtime,log})
let rangedCalibration=rangedLearning.profile()
const requestContexts = new Map()
const sourceSha256 = Object.fromEntries(['protocol-wavedog.js','protocol-wavedog-brain.js',
  'protocol-wavedog-executor.js','protocol-attack-charge.js','protocol-offhand-swap.js','protocol-frame-clock.js','protocol-public-health.js','protocol-ordered-journal.js','protocol-ranged-observation.js','protocol-frame-store.js','attack-reward.js','protocol-mechanical-math.js','protocol-airborne-guard.js','wavedog-arrow-predictor.js','ballistic-aim.js','protocol-ranged-aim.js','protocol-ranged-learning.js']
  .map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,name))).digest('hex')]))
const controllerCode=crypto.createHash('sha256').update(JSON.stringify(sourceSha256)).digest('hex')
const awaitingTraining = new Map(), execution = new Map()
const frameClock=createFrameClock(physics)
function model (row) {
  if (!socket || socket.destroyed || !modelReady) return false
  socket.write(JSON.stringify(row) + '\n'); return true
}
function plugin (row) {
  if (!bot?._client || bot._client.state !== 'play' || !fs.existsSync(tokenFile)) return
  bot._client.write('custom_payload', { channel,
    data: Buffer.from(JSON.stringify({ ...row, token: fs.readFileSync(tokenFile, 'utf8').trim() })) })
}
function modelConnect () {
  socket = net.connect(18766, '127.0.0.1'); modelBuffer = ''
  // Frame requests and execution receipts are small adjacent writes. Never
  // wait for a delayed TCP acknowledgement before sending the next control.
  socket.setNoDelay(true)
  socket.setEncoding('utf8')
  socket.on('data', data => {
    modelBuffer += data
    for (let n; (n = modelBuffer.indexOf('\n')) >= 0;) {
      const line = modelBuffer.slice(0,n); modelBuffer = modelBuffer.slice(n+1)
      try { onModel(JSON.parse(line)) } catch (e) { log('model-message-error', { error: String(e) }) }
    }
  })
  socket.on('error', e => log('model-connection-error', { error: e.code }))
  socket.on('close', () => {
    modelReady = false; latest = null
    if (session?.active) { session.invalid = true; log('model-disconnect-during-bout', { matchId: session.id }) }
    if (!closing) setTimeout(modelConnect, 2000)
  })
}
function onModel (row) {
  if (row.event === 'transport_ready' || row.event === 'ready') {
    modelReady = row.modelReady !== false
    model({ command: 'model_status', requestId: 'WaveDog-connect' })
  }
  if (row.event === 'model_status') {
    modelReady = row.ready; policySha = row.checkpointSha256
    fs.writeFileSync(path.join(runtime, 'model-status.json'), JSON.stringify(row, null, 2))
  }
  if (row.fighter === 'WaveDog' && row.model === 'DUAL-GRU-GTRXL') {
    const context=requestContexts.get(row.requestId);requestContexts.delete(row.requestId)
    if (session?.active && context?.matchId===session.id && row.opponent === session.opponent
        && row.decidedTick === context.tick && row.decidedTick >= session.startTick) {
      row.responseMs=performance.now()-context.requestedAt
      row.observedWeaponEpoch=context.weaponEpoch
      if (!latest || row.decidedTick > latest.decidedTick) latest = row
      policySha = row.checkpointSha256
      session.inferences++
    }
  }
  if (row.fighter === 'WaveDog' && ['trained','trained_partial','training_error'].includes(row.event)) {
    const old = awaitingTraining.get(row.round)
    if (!old) return
    // Persist the training receipt before reopening the next-match gate.
    fs.writeFileSync(path.join(runtime, old.id + '-training.json'), JSON.stringify(row, null, 2))
    if (row.event === 'training_error' || row.quarantined) {
      plugin({ type: 'learning_error', matchId: old.id,
        reason: row.error || '轨迹已保存并隔离，本局未更新权重：' + (row.reasons || []).join(',') })
      // Analysis can still inspect a rejected bout; never announce a PPO
      // weight merge for an update the validation gate refused to publish.
      if (row.quarantined) model({ command: 'review', matchId: old.id,
        fighter: 'WaveDog', opponent: old.opponent, outcome: old.outcome, frames: old.frames })
    } else {
      const manifest = JSON.parse(fs.readFileSync(path.join(root, 'work/pvp-8.6-dual-fresh/model/checkpoint.json')))
      policySha = manifest.sha256
      plugin({ type: 'merged', matchId: old.id, sha256: policySha, persisted:true })
      model({ command: 'review', matchId: old.id, fighter: 'WaveDog', opponent: old.opponent,
        outcome: old.outcome, frames: old.frames })
    }
    log('training-receipt', { matchId: old.id, ...row })
    awaitingTraining.delete(row.round)
  }
  if (row.event === 'review_saved') {
    plugin({ type: 'reviewed', matchId: row.matchId }); log('qwen-review-saved', row)
  }
  if (['error','service_error','training_error','model_not_ready'].includes(row.event)) {
    log('model-error', row)
    if (row.event === 'service_error' || row.event === 'model_not_ready') modelReady = false
  }
}
function stopUse () {
  if (use || bot.usingHeldItem) bot.deactivateItem()
  use = null
}
function offhand (wanted) {
  if (switching) return false
  const current = bot.inventory.slots[45]
  if (current?.name === wanted) return true
  if (!switching) {
    const item = bot.inventory.items().find(i => i.name === wanted)
    if (!item) return false
    stopUse(); switching = true
    const currentBot=bot
    const swap=requestOffhandSwap(currentBot,item)
    swap.completion.catch(e => log('inventory-error', { error: String(e) }))
      .finally(() => { switching = false })
    return swap.ready
  }
  return false
}
function loaded (item) {
  if (!item) return false
  const data = item.componentMap?.get('charged_projectiles')?.data
  const projectiles = Array.isArray(data) ? data : data?.projectiles
  if (projectiles?.some(p => (p.itemCount ?? p.count ?? 0) > 0)) return true
  const c = item.components?.find(c => c.type === 'charged_projectiles' || c.type === 'minecraft:charged_projectiles')
  return Boolean(c?.data?.projectiles?.length || c?.data?.items?.length
    || item.nbt?.value?.Charged?.value || item.nbt?.value?.ChargedProjectiles?.value?.value?.length)
}
function ownLoaded () { return bot.inventory.slots.some(i => i?.name === 'crossbow' && loaded(i)) }
function charge (slot = bot.quickBarSlot) {
  return attackCharge({ tick, lastSwing, slot, nativeSelf })
}
function clearPath (a, b) {
  const delta = new Vec3(b.x-a.x,b.y-a.y,b.z-a.z), length = delta.norm()
  return length < .001 || !bot.world.raycast(new Vec3(a.x,a.y,a.z),delta.scaled(1/length),length)
}
function eyeBox (eye, feet, height = 1.8) {
  return Math.hypot(Math.max(0,Math.abs(eye.x-feet.x)-.3),
    Math.max(0,feet.y-eye.y,eye.y-feet.y-height),Math.max(0,Math.abs(eye.z-feet.z)-.3))
}
function wall (x,z) {
  const p = bot.entity.position, hit = bot.world.raycast(p.offset(0,.9,0),new Vec3(x,0,z),8)
  return hit?.intersect ? p.offset(0,.9,0).distanceTo(hit.intersect) : 8
}
function publicFrame (target) {
  const e = bot.entity, p = e.position, v = e.velocity, eye = p.offset(0,e.eyeHeight || 1.62,0)
  const flags = Number(target?.metadata?.[8] || 0)
  const targetItem = flags & 2 ? target?.equipment?.[1] : target?.equipment?.[0]
  const using = Boolean(flags & 1), isShield = using && targetItem?.name === 'shield'
  const tp = target?.position, visible = Boolean(target && p.distanceTo(tp) < 64
    && (clearPath(eye,tp.offset(0,1.3,0)) || clearPath(eye,tp.offset(0,.6,0))))
  const targetFloor=visible?bot.world.raycast(tp.offset(0,.1,0),new Vec3(0,-1,0),16):null
  const motion=visible?observeMotion(session.targetMotion,{x:tp.x,y:tp.y,z:tp.z,
    grounded:target.publicGrounded,floorY:targetFloor?.intersect?.y},tick):null
  if(motion)session.targetMotion=motion
  const targetVelocity=motion?{x:motion.vx,y:motion.vy,z:motion.vz}:{x:0,y:0,z:0}
  if (isShield && !session.targetShieldAt) session.targetShieldAt = tick
  if (!isShield) session.targetShieldAt = 0
  const effective = isShield && tick-session.targetShieldAt >= 5
  const targetForward = target ? new Vec3(-Math.sin(target.yaw),0,-Math.cos(target.yaw)) : new Vec3(0,0,0)
  const towardSelf = tp ? p.minus(tp) : new Vec3(0,0,0)
  const facing = Boolean(effective && targetForward.dot(towardSelf) > 0)
  const arrows = Object.values(bot.entities).filter(a => /^(arrow|spectral_arrow)$/.test(a.name || '')
    && a.position.distanceTo(p)<32 && clearPath(eye,a.position)).map(a => ({ id:a.id,
    x:a.position.x,y:a.position.y,z:a.position.z,vx:a.velocity?.x||0,vy:a.velocity?.y||0,vz:a.velocity?.z||0,
    shooterId:a.publicShooterId }))
  const own = nativeSelf && tick-nativeSelf.receivedTick<=3 ? nativeSelf : null
  // moveSlotItem briefly holds the replaced stack on the inventory cursor.
  // That is not a shield break and must not transfer the base combat state.
  const hasShield=bot.inventory.slots.some(i=>i?.name==='shield')
    ||bot.inventory.selectedItem?.name==='shield'||Boolean(switching&&session.hasShield)
  if(!switching)session.hasShield=hasShield
  const self = { x:p.x,y:p.y,z:p.z,eyeY:eye.y,vx:v.x,vy:v.y,vz:v.z,
    ground:e.onGround, critical:!e.onGround && lastSentPosition?.falling===true && !e.isInWater && !e.isInLava,
    charge:charge(), health:bot.health,food:bot.food,
    shieldAvailable:(own ? own.shieldCooldown===0 : tick>=shieldUntil) && hasShield,
    shielding:Boolean(own?.shielding && own.using && own.activeItem==='SHIELD'
      && own.useTicks>=5 && use?.kind==='shield' && tick-use.tick>=5),
    arrows:bot.inventory.items().filter(i=>i.name==='arrow').reduce((s,i)=>s+i.count,0),
    crossbowLoaded:ownLoaded(),hasBow:bot.inventory.slots.some(i=>i?.name==='bow'),
    hasCrossbow:bot.inventory.slots.some(i=>i?.name==='crossbow'),
    using:own ? own.using : Boolean(use),useTicks:own ? own.useTicks : use?tick-use.tick:0,held:bot.quickBarSlot }
  const seen = visible ? { visible:true,x:tp.x,y:tp.y,z:tp.z,yaw:180-target.yaw*180/Math.PI,
    shield:effective,shieldRaised:isShield,held:(target.equipment?.[0]?.name||'UNKNOWN').toUpperCase(),using,
    swing:session.swingAt||0,arrows } : { visible:false,arrows }
  const rangedObserved=observeRanged(session,{tick,visible,using,activeItem:targetItem,
    mainhand:target?.equipment?.[0],offhand:target?.equipment?.[1],fired:session.targetFired},loaded)
  session.targetFired=false
  const {targetBow,targetLoading}=rangedObserved
  const threat = publicArrowThreat(arrows,{...self,entityId:e.id,yaw:e.yaw,ceilingClear:!bot.blockAt(p.offset(0,2.8,0))?.boundingBox?.includes('block')},wall,clearPath)
  if (threat) {
    const a = arrows.find(a=>a.id===threat.id)
    threat.yaw = Math.atan2(-(a.x-p.x),-(a.z-p.z))
  }
  const floor = bot.world.raycast(p.offset(0,.1,0),new Vec3(0,-1,0),8)
  const terrain = { selfY:p.y,groundY:floor?.intersect?.y ?? p.y,
    walls:[wall(-1,0),wall(1,0),wall(0,-1),wall(0,1)] }
  const reach = visible ? eyeBox(eye,tp,target.height || 1.8) : Infinity
  const otherReach = visible ? eyeBox(tp.offset(0,1.62,0),p,e.height || 1.8) : Infinity
  const distance = visible ? p.distanceTo(tp) : Infinity
  if (visible) seen.publicHealth = publicHealth?.observe(session.opponent, true, distance) || null
  let airEnvelope=null
  if(visible&&motion&&!motion.grounded){
    const body={x:tp.x,y:tp.y,z:tp.z,vx:motion.vx,vy:motion.vy,vz:motion.vz,
      eye:target.eyeHeight||1.62,halfX:(target.width||.6)/2,halfZ:(target.width||.6)/2,
      height:target.height||1.8,grounded:false}
    const steering=.0196*1.3 // Original sprint-capable bound; opponent food is private.
    const floor=forecastFloor(body,steering,bot.game.minY??-64,(x,y,z)=>{
      const block=bot.blockAt(new Vec3(x,y,z),false)
      return block?.shapes?.length?y+Math.max(...block.shapes.map(shape=>shape[4])):null
    })
    const weapon=target.equipment?.[0]?.name||''
    airEnvelope=forecast({x:p.x,y:p.y,z:p.z,vx:v.x,vy:v.y,vz:v.z,eye:eye.y-p.y,
      halfX:(e.width||.6)/2,halfZ:(e.width||.6)/2,height:e.height||1.8,grounded:e.onGround},
      body,floor,steering,/_(axe|sword)$/.test(weapon),true,1,weapon.endsWith('_axe')?1:1.6)
    // Critical readiness is a possible bound only, never hidden enemy CD.
  }
  const separation=visible?Math.hypot(tp.x-p.x,tp.z-p.z):null
  const receding=visible&&session.lastSeparation!=null&&separation>session.lastSeparation+.01
  session.lastSeparation=separation
  const targetMotion=visible&&motion?{source:'public-position-samples',matchId:session.id,
    opponent:session.opponent,sampleTick:motion.tick,vx:motion.vx,vy:motion.vy,vz:motion.vz,
    grounded:motion.grounded}:null
  const towardDistance=visible?Math.hypot(towardSelf.x,towardSelf.z):0
  const approachSpeed=visible&&motion&&towardDistance>.1
    ?(motion.vx*towardSelf.x+motion.vz*towardSelf.z)/towardDistance:0
  const ownClosing=visible&&towardDistance>.1
    ?-(v.x*towardSelf.x+v.z*towardSelf.z)/towardDistance:0
  const approachTicks=visible?Math.max(0,otherReach-3)/Math.max(.32,approachSpeed+ownClosing):0
  return { self,seen,publicTerrain:terrain,targetVelocity,targetMotion,nativeSelf:own,observation:{ tick,ground:e.onGround,
    health:self.health,self:{x:p.x,z:p.z},sentPosition:lastSentPosition,
    target:visible?{x:tp.x,z:tp.z}:null,targetYaw:target?.yaw,
    targetFacingDot:visible?targetForward.dot(towardSelf)/Math.max(.001,Math.hypot(towardSelf.x,towardSelf.z)):null,
    targetGrounded:motion?.grounded??false,targetVelocity,
    targetAirborne:visible&&Boolean(motion&&!motion.grounded),airEnvelope,
    targetCriticalPossible:visible&&Boolean(motion&&!motion.grounded&&motion.vy<=.08),
    targetCriticalThreat:Boolean(airEnvelope?.valid&&airEnvelope.criticalTick>=0),
    targetAirborneThreat:Boolean(airEnvelope?.valid?airEnvelope.meleeTick>=0:visible&&motion&&!motion.grounded),
    visible,distance,reach,charge:self.charge,held:self.held,critical:self.critical,
    mutualOutOfReach:visible&&reach>3&&otherReach>3,
    shieldReady:self.shieldAvailable,shieldEffective:self.shielding,
    shieldRaised:use?.kind==='shield',
    targetShieldFacing:facing,targetShieldRaised:isShield,targetSwingRecent:tick-(session.swingAt||-1000)<=1,
    targetApproaching:approachSpeed>.06,targetApproachSpeed:approachSpeed,targetApproachTicks:approachTicks,
    offhandShieldReady:bot.inventory.slots[45]?.name==='shield'&&!switching,
    wallMargin:Math.min(...terrain.walls),receding,arrowThreat:threat,
    loaded:self.crossbowLoaded,arrows:self.arrows,targetRanged:targetBow||targetLoading||session.targetKnownLoaded,
    rangedEvent:session.targetRangedEvent||0,
    ...rangedObserved } }
}
function look (yaw,pitch=0) {
  immediateLook(bot,yaw,pitch)
}
function aim (target, ranged, velocity) {
  if (!target) return
  const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
  const point=ranged?target.position.offset(0,Math.min(1.3,(target.height||1.8)*.7),0)
    :nearestHitPoint(eye,target)
  const speed=ranged==='bow'?bowSpeed((tick-(use?.tick??tick))*50):3.15
  // Landing prediction must not aim through the observed floor. This is the
  // target's public block surface, not its hidden input or movement intention.
  const targetFloor=ranged?bot.world.raycast(target.position.offset(0,.1,0),new Vec3(0,-1,0),16):null
  const floorY=targetFloor?.intersect?.y
  if(ranged&&Number.isFinite(floorY)){
    const v=bot.entity.velocity
    const inherited=ranged==='bow'?{x:v.x,y:bot.entity.onGround?0:v.y,z:v.z}:{x:0,y:0,z:0}
    const solution=solveRangedAim({eye:{x:eye.x,y:eye.y-.1,z:eye.z},inherited,
      feet:target.position,motion:velocity,airborne:session.targetMotion?.grounded===false,
      floorY,height:target.height||1.8,speed,profile:rangedCalibration})
    if(solution){
      session.lastRangedAim={tick,weapon:ranged,...solution}
      const d=solution.direction
      look(Math.atan2(-d.x,-d.z),Math.atan2(d.y,Math.hypot(d.x,d.z)));return
    }
  }
  const at=ranged?leadTarget(eye,point,velocity,speed,{airborne:Math.abs(velocity.y)>.08,
    floorY:Number.isFinite(floorY)?floorY+point.y-target.position.y:undefined}):point
  const dx=at.x-eye.x,dz=at.z-eye.z,dy=at.y-eye.y,h=Math.hypot(dx,dz)
  look(Math.atan2(-dx,-dz),ranged?solvePitch(h,dy,speed):Math.atan2(dy,h))
}
// Only this function emits combat controls. It never waits for a model response.
function execute (planned, frame, target) {
  const actual=executeCommand({bot,planned,frame,target,tick,session,charge,look,aim,
    offhand,stopUse,getUse:()=>use,setUse:value=>{use=value},plugin,
    shieldUntil,lastAttackTick,weaponEpoch,bowDrawMs:plannedBowDrawMs,ownLoaded,
    canHit:entity=>{const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
      return clearPath(eye,nearestHitPoint(eye,entity))},
    onSwitch:()=>{lastSwing=tick;weaponEpoch++},onAttack:()=>{lastSwing=lastAttackTick=tick}})
  if(planned.command.decidedTick!==undefined){
    const decidedTick=planned.command.decidedTick,heads=execution.get(decidedTick)||new Set()
    for(let i=0;i<9;i++)if(!actual.ignoredHeads.includes(i))heads.add(i)
    execution.set(decidedTick,heads)
    model({command:'executed',fighter:'WaveDog',decidedTick,
      ignoredHeads:Array.from({length:9},(_,i)=>i).filter(i=>!heads.has(i))})
  }
  brain.applied(session.state,planned.command,actual.attacked,tick)
  brain.rangedApplied(session.state,planned.command,actual.rangedResult,tick)
  return {...actual,offhandBusy:switching}
}

function physics () {
  if(!session?.active||bot.health<=0){bot.clearControlStates();if(use)stopUse();return}
  try {
    const target=bot.players[session.opponent]?.entity
    const observedAt=performance.now()
    const frame=publicFrame(target)
    const observationMs=performance.now()-observedAt
    const request={command:'act',fighter:'WaveDog',opponent:session.opponent,matchId:session.id,
      requestId:++requestId,tick,trainingScope:'hybrid_native_player',focus:'FREE',style:'AGGRESSIVE',
      observedOpponentSwingAge:session.swingAt?Math.min(20,tick-session.swingAt):-1,
      observedOpponentMotion:frame.targetMotion,
      yaw:180-bot.entity.yaw*180/Math.PI,pitch:-bot.entity.pitch*180/Math.PI,
      self:frame.self,seen:frame.seen,publicTerrain:{...frame.publicTerrain,episodeTick:tick-session.startTick}}
    requestContexts.set(request.requestId,{matchId:session.id,tick,weaponEpoch,requestedAt:performance.now()})
    for(const [id,context]of requestContexts)if(tick-context.tick>20)requestContexts.delete(id)
    model(request)
    const planningAt=performance.now()
    const planned=brain.plan(session.state,frame.observation,latest)
    const planningMs=performance.now()-planningAt
    const actual=execute(planned,frame,target)
    const row={tick,self:frame.self,seen:frame.seen,publicTerrain:frame.publicTerrain,
      observedOpponentMotion:frame.targetMotion,
      observation:frame.observation,nativeSelf:frame.nativeSelf,controllerCode,
      owner:planned.mode==='NEURAL'?'dual':'mechanical',mode:planned.mode,owners:actual.owners,
      command:planned.command,actualPackets:actual.packets,executed:actual.controls,executionMs:actual.executionMs,
      timings:{observationMs,planningMs,executionMs:actual.executionMs,
        modelResponseMs:latest?.responseMs,modelActionAgeTicks:latest?tick-latest.decidedTick:null},
      offhand:actual.offhand,offhandBusy:actual.offhandBusy,rangedResult:actual.rangedResult,
      rangedAim:session.lastRangedAim?.tick===tick?session.lastRangedAim:null,
      executedHeld:actual.held,executedItemName:actual.heldItemName,
      attackHeld:actual.attackHeld,attackItemName:actual.attackItemName,attackId:actual.executedAttackId,weaponEpoch,
      attackSuppressedReason:actual.attackSuppressedReason,
      opponentRangedEvent:frame.observation.rangedEvent,
      modelTick:latest?.decidedTick,modelAction:latest||null,ignoredHeads:actual.ignoredHeads,policySha,attackPacket:actual.attacked,shieldRequested:actual.shieldRequested,
      nativeDealt:0,nativeReceived:0}
    session.frames.push(row)
    session.frameJournal.append(row)
    if(session.state.transitions.length){for(const change of session.state.transitions.splice(0))log('handoff',{matchId:session.id,...change})}
  }catch(e){log('frame-error',{matchId:session.id,error:e.stack});session.invalid=true;bot.clearControlStates();stopUse()}
}
async function finishBout(old,row){
  if(old.finalizing||old.outcome)return
  old.finalizing=true
  try{
    await Promise.all([old.frameJournal.close(),old.packetJournal.close()])
    const saved=await require('./protocol-frame-store').saveCompletedFrames(old.file,old.frames)
    if(!saved.canonical)log('completed-frames-sidecar',{matchId:old.id,...saved})
    old.outcome={winner:row.winner,reason:row.reason,invalid:Boolean(old.invalid)}
    fs.writeFileSync(path.join(runtime,old.id+'-report.json'),JSON.stringify({
      matchId:old.id,opponent:old.opponent,frames:old.frames.length,inferences:old.inferences,
      outcome:old.outcome,policySha,completedFrames:saved.path},null,2))
    rangedLearning.completed(old.opponent,old.invalid)
    if(row.hadFrames&&old.frames.length&&modelReady){
      awaitingTraining.set(old.round,old)
      model({command:row.winner&&!old.invalid?'finish':'partial',fighter:'WaveDog',
        opponent:old.opponent,matchId:old.id,round:old.round,win:row.winner==='WaveDog',health:bot.health})
    }else if(row.hadFrames)plugin({type:'learning_error',matchId:old.id,reason:'No valid frames or model offline'})
    log('end',{matchId:old.id,...old.outcome})
  }catch(error){
    log('bout-finalize-error',{matchId:old.id,error:String(error)})
    plugin({type:'learning_error',matchId:old.id,reason:'Frame persistence failed; raw log retained'})
  }finally{old.finalizing=false}
}
function onPlugin (row) {
  row={...row};for(const key of ['attacker','victim','winner'])if(row[key]==='WaveDog_test')row[key]='WaveDog'
  // Recover an interrupted end callback at idle without losing the in-memory
  // rollout or restarting the learner. Preparation never has recorded frames.
  if(row.type==='heartbeat_ack'&&!row.active&&!row.preparing&&session
      &&!session.active&&session.frames.length&&!session.outcome&&!session.finalizing)
    void finishBout(session,{winner:'',reason:'recovered-end-save',hadFrames:true})
  if(row.type==='prepare'){
    rangedCalibration=rangedLearning.profile()
    bot.clearControlStates();stopUse();latest=null;nativeSelf=null;execution.clear();requestContexts.clear()
    session={id:row.matchId,opponent:row.opponent,round:Date.now(),active:false,
      state:brain.createState(row.opponent),frames:[],inferences:0,attackOwners:new Map(),attackedDecisions:new Set(),
      file:path.join(runtime,row.matchId+'-frames.jsonl')}
    const prepared=session
    const journalError=error=>{prepared.invalid=true;log('journal-error',{matchId:prepared.id,error:String(error)})}
    session.frameJournal=createOrderedJournal(session.file,journalError)
    session.packetJournal=createOrderedJournal(path.join(runtime,row.matchId+'-packets.jsonl'),journalError)
    shieldUntil=0;lastSwing=lastAttackTick=tick-30
    log('prepare',{matchId:row.matchId,opponent:row.opponent,policySha,controllerCode,sourceSha256})
  }
  if(row.type==='start'&&session?.id===row.matchId){
    session.active=true;session.startTick=tick;latest=null
    publicHealth?.beginMatch(session.id)
    model({command:'reset',fighter:'WaveDog',opponent:session.opponent,matchId:session.id,role:'current',learning:true,focus:'FREE'})
    log('start',{matchId:session.id,policySha})
  }
  if(!session||row.matchId!==session.id)return
  if(row.type==='self_state'){nativeSelf={...row,receivedTick:tick};shieldUntil=tick+row.shieldCooldown}
  if(row.type==='shield_disabled') {shieldUntil=tick+row.cooldownTicks;stopUse()}
  if(row.type==='blocked_melee'&&row.shieldDisabled)shieldUntil=Math.max(shieldUntil,tick+100)
  brain.receipt(session.state,row,tick)
  if(['damage','blocked_melee','shield_disabled','attack_packet'].includes(row.type)){
    log('native',{matchId:session.id,...row})
    if(row.type==='damage'&&!row.cancelled){
      const f=session.frames.at(-1)
      if(f){if(row.attacker==='WaveDog')f.nativeDealt+=row.amount;else f.nativeReceived+=row.amount
        ;(f.nativeEvents||=([])).push(row)}
      const a=session.attackOwners.get(row.attackId)
      if(a?.kind==='neural'&&row.attacker==='WaveDog'&&row.victim===session.opponent&&row.melee)
        model({command:'native_step',fighter:'WaveDog',decidedTick:a.decidedTick,
          reward:damageFeedback({...row,source:'MELEE',native_critical:row.nativeCritical},undefined,a.attackReach)})
      else if(row.victim==='WaveDog'&&f?.owners.movement==='neural'
          &&execution.get(f.command.decidedTick)?.has(0))
        model({command:'native_step',fighter:'WaveDog',decidedTick:f.command.decidedTick,reward:-row.amount/20})
    }
  }
  if(row.type==='end'){
    session.active=false;bot.clearControlStates();stopUse()
    void finishBout(session,row)
  }
}
function connect () {
  lastSentPosition=null
  bot=mineflayer.createBot({host:'127.0.0.1',port:25566,username:'WaveDog_test',auth:'offline',version:'1.21.1',hideErrors:true})
  publicHealth=createPublicHealthTracker(bot._client,()=>tick)
  const wire=bot._client,write=wire.write
  const recorded=new Set(['look','position','position_look','flying','use_entity','arm_animation',
    'entity_action','block_dig','use_item','held_item_slot','window_click'])
  wire.write=function(name,data){
    if(session?.active)data=currentViewPacket(name,data,bot.entity)
    if(session?.active&&recorded.has(name))session.packetJournal.append({tick,name,data})
    const result=write.call(this,name,data)
    if(['position','position_look'].includes(name)&&[data.x,data.y,data.z].every(Number.isFinite)){
      const ground=data.onGround??data.flags?.onGround
      const falling=Boolean(lastSentPosition&&tick-lastSentPosition.tick<=2&&!ground&&data.y<lastSentPosition.y-.00001)
      lastSentPosition={x:data.x,y:data.y,z:data.z,onGround:ground,falling,tick}
    }else if(name==='flying'&&lastSentPosition){
      lastSentPosition={...lastSentPosition,onGround:data.onGround??data.flags?.onGround,falling:false,tick}
    }
    frameClock.movementWritten(name)
    return result
  }
  bot.once('spawn',()=>{
    bot._client.registerChannel(channel,null,true)
    const simulate=bot.physics.simulatePlayer.bind(bot.physics)
    bot.physics.simulatePlayer=(state,world)=>{
      frameClock.beforeSimulation()
      if(use||bot.usingHeldItem){state.control={...state.control,sprint:false,
        forward:Number(state.control.forward)*.2,back:Number(state.control.back)*.2,
        left:Number(state.control.left)*.2,right:Number(state.control.right)*.2}}
      return simulate(state,world)
    }
    log('spawn',{protocol:bot.version,entityId:bot.entity.id})
    fs.writeFileSync(path.join(runtime,'client-ready.json'),JSON.stringify({pid:process.pid,protocol:bot.version,at:new Date().toISOString(),controllerCode,sourceSha256}))
  })
  bot.on('forcedMove',()=>{lastSentPosition=null;frameClock.clear()})
  bot._client.on('custom_payload',packet=>{
    if(packet.channel!==channel)return
    try{onPlugin(JSON.parse(packet.data.toString('utf8')))}catch(e){log('plugin-message-error',{error:e.stack})}
  })
  bot.on('physicsTick',()=>{tick++;frameClock.physicsTick()})
  bot._client.on('set_cooldown',packet=>{
    if(packet.itemID===bot.registry.itemsByName.shield?.id&&packet.cooldownTicks>0){
      shieldUntil=tick+packet.cooldownTicks;if(use?.kind==='shield')stopUse()
    }
  })
  bot._client.on('animation',packet=>{
    if(session&&[0,3].includes(packet.animation)&&packet.entityId===bot.players[session.opponent]?.entity?.id)session.swingAt=tick
  })
  for(const name of ['rel_entity_move','entity_move_look','entity_teleport','entity_look','sync_entity_position'])
    bot._client.on(name,packet=>{
      if(typeof packet.onGround!=='boolean')return
      queueMicrotask(()=>{const entity=bot.entities[packet.entityId];if(entity)entity.publicGrounded=packet.onGround})
    })
  // Preserve the shooter's public ID from the ordinary 1.21.1 spawn packet.
  bot._client.on('spawn_entity',packet=>{
    // Our listener can run before Mineflayer's entity listener. Read the
    // populated entity after all listeners for this public packet complete.
    queueMicrotask(()=>{
    const entity=bot.entities[packet.entityId]
    if(!entity||!/^(arrow|spectral_arrow)$/.test(entity.name||''))return
    entity.publicShooterId=projectileShooterId(packet.objectData)
    const opponent=session&&bot.players[session.opponent]?.entity
    if(opponent&&(entity.publicShooterId===opponent.id
        ||entity.publicShooterId==null&&entity.position.distanceTo(opponent.position)<2)){
      session.targetFired=true;session.targetRangedEvent=(session.targetRangedEvent||0)+1
    }
    })
  })
  bot.on('messagestr',message=>{
    if(Date.now()-authAt<1500)return
    if(/\/register/i.test(message)){authAt=Date.now();bot.chat('/register '+password+' '+password)}
    else if(/\/login/i.test(message)){authAt=Date.now();bot.chat('/login '+password)}
    // Never journal authentication chat or credentials.
  })
  bot.on('kicked',reason=>log('kicked',{reason:JSON.stringify(reason).replaceAll(password,'[redacted]')}))
  bot.on('error',e=>log('client-error',{error:e.code||e.message}))
  bot.on('end',reason=>{log('disconnected',{reason});use=null;nativeSelf=null;latest=null;if(!closing)setTimeout(connect,4000)})
}
modelConnect();connect()
setInterval(()=>{
  if(!bot?.entity)return
  fs.writeFileSync(path.join(runtime,'client-state.json'),JSON.stringify({tick,shieldUntil,use,
    active:session?.active,mode:session?.state?.mode,controllerCode,nativeSelf,
    inventory:bot.inventory.slots.flatMap((i,slot)=>i?[{slot,name:i.name}]:[])}))
  plugin({type:'heartbeat',modelReady:Boolean(modelReady&&policySha),policySha:policySha||'unknown'})
  if(Date.now()-lastHeartbeat>10000){lastHeartbeat=Date.now();model({command:'model_status',requestId:'WaveDog-periodic'})}
},1000)
function shutdown(){closing=true;bot?.clearControlStates();socket?.end();bot?.quit('WaveDog controller shutdown');setTimeout(()=>process.exit(),500)}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown)
