'use strict'
const {attackCharge}=require('./protocol-attack-charge')
// Correlate our own cooldown sample with the actual input that reset it.
// Receiving a sample later does not mean the server sampled it after a hit.
function createPilotChargeObserver(){
  let reset=null
  return {
    clear(){reset=null},
    reset({tick,slot,attackId=null,serverTick=null}){
      reset={tick,slot,attackId,beforeServerTick:serverTick,confirmedServerTick:null,observedLow:false}
    },
    receipt(row){
      if(reset&&reset.attackId!==null&&row.type==='attack_packet'
          &&row.attackId===reset.attackId&&Number.isFinite(row.serverTick))
        reset.confirmedServerTick=row.serverTick
    },
    read(args){
      const local=attackCharge({...args,nativeSelf:null}),n=args.nativeSelf
      let usable=Boolean(n&&n.held===args.slot&&args.tick-n.receivedTick<=3
        &&n.receivedTick>args.lastSwing),reason=null
      if(usable&&reset&&reset.slot===args.slot){
        const boundary=reset.attackId===null?reset.beforeServerTick:reset.confirmedServerTick
        if(!Number.isFinite(boundary)||!Number.isFinite(n.serverTick)||n.serverTick<=boundary){
          usable=false;reason='sample-not-after-confirmed-reset'
        }else if(!reset.observedLow){
          const adjusted=attackCharge({...args,nativeSelf:n})
          if(n.charge<.9&&adjusted<=local+.05)reset.observedLow=true
          else if(local<1){usable=false;reason='reset-not-yet-visible-in-native-charge'}
        }
      }
      return {value:attackCharge({...args,nativeSelf:usable?n:null}),
        source:usable?'causal-own-server-sample':'local-input-reset-clock',
        rejectedNativeReason:reason,resetAttackId:reset?.attackId??null,
        confirmedResetServerTick:reset?.confirmedServerTick??null}
    }
  }
}
module.exports={createPilotChargeObserver}
