"""Summarize observed client motion during human duels (diagnostic only)."""
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import json
import math


PATH = Path(__file__).resolve().parent / 'new-learning/selfplay/human-frames.jsonl'


def time(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def main():
    grouped = defaultdict(list)
    with PATH.open(encoding='utf-8') as stream:
        for line in stream:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('kind') == 'frame':
                grouped[(row['matchId'], row['fighter'])].append(row)
    for (match, fighter), frames in grouped.items():
        samples = defaultdict(list)
        for before, after in zip(frames, frames[1:]):
            if after['frame'] != before['frame'] + 1:
                continue
            delta = (time(after['at']) - time(before['at'])).total_seconds()
            distance = math.hypot(after['self']['x'] - before['self']['x'],
                                  after['self']['z'] - before['self']['z'])
            if not 0.025 < delta < 0.2 or distance >= 1:
                continue
            if before['self']['shielding'] and after['self']['shielding']:
                state = 'shield'
            elif not before['self']['shielding'] and not after['self']['shielding']:
                state = 'free'
            else:
                continue
            samples[state].append((distance / delta, before['frame'], distance))
        if not samples:
            continue
        values = {}
        for state, rows in samples.items():
            speeds = sorted(x[0] for x in rows)
            values[state] = {'samples': len(rows), 'median_blocks_per_second': round(speeds[len(speeds)//2], 3),
                             'p95_blocks_per_second': round(speeds[int(.95*(len(speeds)-1))], 3),
                             'top': [(round(speed, 3), frame, round(distance, 3))
                                     for speed, frame, distance in sorted(rows, reverse=True)[:5]]}
        print(json.dumps({'matchId': match, 'fighter': fighter, 'motion': values}, ensure_ascii=False))


if __name__ == '__main__':
    main()
