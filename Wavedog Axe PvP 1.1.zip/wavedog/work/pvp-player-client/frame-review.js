// Compact, chronological presentation of every recorded client frame.
// The gzip archive remains the lossless source of truth.
const crypto = require('node:crypto')

const round = value => Number.isFinite(value) ? Math.round(value * 100) / 100 : null

function frameChunks (archive, width = 64) {
  if (!archive || !archive.fighters || !Number.isInteger(width) || width < 1)
    throw Error('Invalid frame archive or chunk width')
  const rows = []
  const expected = {}
  for (const [fighter, bout] of Object.entries(archive.fighters)) {
    const frames = bout.frames || []
    const actions = bout.actions || []
    expected[fighter] = { frames: frames.length, actions: actions.length }
    const byFrame = new Map()
    for (const action of actions) {
      if (!byFrame.has(action.frame)) byFrame.set(action.frame, [])
      byFrame.get(action.frame).push(action)
    }
    for (let index = 0; index < frames.length; index++) {
      const frame = frames[index], self = frame.self || {}, seen = frame.seen || {}
      const commands = (byFrame.get(frame.frame) || []).map(action => {
        const s = action.selected || {}, e = action.executed || {}
        return [s.forward, s.side, s.sprint ? 1 : 0, s.jump ? 1 : 0,
          s.sneak ? 1 : 0, s.shield ? 1 : 0, s.attack ? 1 : 0, s.slot,
          s.use ? 1 : 0, s.release ? 1 : 0,
          e.forward ? 1 : 0, e.back ? 1 : 0, e.left ? 1 : 0,
          e.right ? 1 : 0, e.sprint ? 1 : 0, e.jump ? 1 : 0,
          e.mainSlot, e.attackPackets || 0, e.swingWithoutTarget || 0,
          round(e.attackCharge), round(e.attackDistance), e.weaponSwitched ? 1 : 0]
      })
      rows.push({ at: frame.at, fighter, index, frame: frame.frame,
        data: [fighter, frame.frame, frame.at,
          round(self.x), round(self.y), round(self.z),
          round(self.vx), round(self.vy), round(self.vz),
          round(self.health), self.food, round(self.charge), self.ground ? 1 : 0,
          self.held, self.shieldAvailable ? 1 : 0, self.shielding ? 1 : 0,
          self.opponentSwingAge,
          round(seen.x), round(seen.y), round(seen.z), round(seen.yaw),
          round(seen.vy), seen.shield ? 1 : 0, seen.held,
          seen.using ? 1 : 0, seen.swing,
          round(Math.hypot((self.x || 0) - (seen.x || 0),
            (self.y || 0) - (seen.y || 0), (self.z || 0) - (seen.z || 0))),
          commands] })
      byFrame.delete(frame.frame)
    }
    if (byFrame.size) throw Error(`Actions without observation frames: ${fighter}`)
  }
  rows.sort((a, b) => String(a.at).localeCompare(String(b.at))
    || a.fighter.localeCompare(b.fighter) || a.index - b.index)
  const chunks = []
  for (let offset = 0; offset < rows.length; offset += width) {
    const part = rows.slice(offset, offset + width)
    const data = part.map(row => row.data)
    chunks.push({ index: chunks.length, start: offset, end: offset + part.length,
      firstAt: part[0].at, lastAt: part.at(-1).at,
      sha256: crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex'),
      rows: data })
  }
  if (chunks.reduce((n, chunk) => n + chunk.rows.length, 0) !==
      Object.values(expected).reduce((n, item) => n + item.frames, 0))
    throw Error('Frame coverage mismatch')
  return { expected, rows: rows.length, chunks }
}

function chunkEvidence (chunk) {
  const fighters = {}
  for (const row of chunk.rows) {
    const [name, frame, at, , , , , vy, , health, , charge, ground,
      held, , , , , , , , , , , , , distance, commands] = row
    const item = fighters[name] ||= { firstFrame: frame, lastFrame: frame,
      firstAt: at, lastAt: at, frames: 0, healthStart: health,
      healthEnd: health, nearFrames: 0, farFrames: 0, swordFrames: 0,
      fallingFrames: 0, attackRequests: 0, attackPackets: 0,
      airSwings: 0, jumps: 0, sprintFrames: 0, chargeAtAttack: [] }
    item.lastFrame = frame; item.lastAt = at; item.frames++
    item.healthEnd = health
    if (distance <= 3) item.nearFrames++
    if (distance > 3.5) item.farFrames++
    if (held === 0) item.swordFrames++
    if (!ground && vy < 0) item.fallingFrames++
    for (const action of commands) {
      item.attackRequests += action[6] || 0
      item.attackPackets += action[17] || 0
      item.airSwings += action[18] || 0
      item.jumps += action[15] || 0
      item.sprintFrames += action[14] || 0
      if (action[17] && action[19] != null)
        item.chargeAtAttack.push(action[19])
    }
  }
  for (const item of Object.values(fighters)) {
    const charges = item.chargeAtAttack
    item.meanPacketCharge = charges.length
      ? round(charges.reduce((a, b) => a + b, 0) / charges.length) : null
    delete item.chargeAtAttack
  }
  return { index: chunk.index, firstAt: chunk.firstAt,
    lastAt: chunk.lastAt, frames: chunk.rows.length, fighters }
}

module.exports = { frameChunks, chunkEvidence }
