'use strict'
const {Physics,PlayerState}=require('prismarine-physics')
const HORIZON=16
const keys=()=>({forward:true,back:false,left:false,right:false,sprint:true,jump:false,sneak:false})
// Local traversability sensing, NOT a movement controller. Each alternative
// uses ordinary player physics against received blocks, including collision
// shape, step height, floor support and current knockback. Nothing is applied
// to the bot. Unknown terrain and dangerous drops never count as clear space.
function createNavigationProbe(bot){
  let cache,unknown
  const world={getBlock(p){
    const q=p.floored(),key=q.x+','+q.y+','+q.z
    if(!cache.has(key))cache.set(key,bot.blockAt(q,false))
    const b=cache.get(key);if(!b)unknown=true;return b
  }}
  const physics=Physics(bot.registry,world)
  function supported(pos){
    for(let x=Math.floor(pos.x-.3);x<=Math.floor(pos.x+.3);x++)
      for(let z=Math.floor(pos.z-.3);z<=Math.floor(pos.z+.3);z++){
        const p=pos.clone();p.x=x;p.y=Math.floor(pos.y-.001);p.z=z
        const block=world.getBlock(p)
        for(const a of block?.shapes||[]){
          if(Math.abs(p.y+a[4]-pos.y)<.02&&p.x+a[0]<pos.x+.3&&p.x+a[3]>pos.x-.3
              &&p.z+a[2]<pos.z+.3&&p.z+a[5]>pos.z-.3)return true
        }
      }
    return false
  }
  return {observe(target,tick){
    const began=performance.now(),origin=bot.entity.position
    if(!target||!bot.entity.onGround)return null
    const dx=target.position.x-origin.x,dz=target.position.z-origin.z,d=Math.hypot(dx,dz)
    if(d<.01)return null
    cache=new Map()
    const toward={x:dx/d,z:dz/d},right={x:-toward.z,z:toward.x}
    const directions={toward,away:{x:-toward.x,z:-toward.z},right,
      left:{x:-right.x,z:-right.z},towardRight:{x:toward.x+right.x,z:toward.z+right.z},
      towardLeft:{x:toward.x-right.x,z:toward.z-right.z},
      awayRight:{x:-toward.x+right.x,z:-toward.z+right.z},awayLeft:{x:-toward.x-right.x,z:-toward.z-right.z}}
    const routes={}
    for(const [name,input]of Object.entries(directions)){
      unknown=false
      const length=Math.hypot(input.x,input.z),dir={x:input.x/length,z:input.z/length}
      const state=new PlayerState(bot,keys());state.attributes=structuredClone(bot.entity.attributes||{})
      state.jumpQueued=false;state.yaw=Math.atan2(-dir.x,-dir.z);state.pitch=0
      let distance=0,lastSupported=0,reason='horizon-clear',steps=0,steppedUp=false
      for(let i=0;i<HORIZON;i++){
        const previous=state.pos.clone()
        try{physics.simulatePlayer(state,world)}catch{reason='unknown-terrain';break}
        if(unknown){reason='unknown-terrain';break}
        if(state.isInWater||state.isInLava||state.isInWeb){reason='liquid-or-web';break}
        if(state.pos.y<origin.y-.6){reason='unsupported-drop';distance=lastSupported;break}
        if(state.isCollidedHorizontally){reason='body-collision';break}
        const foot=world.getBlock(state.pos.offset(0,-.05,0))
        if(!foot){reason='unknown-support';distance=lastSupported;break}
        if(['magma_block','campfire','soul_campfire','powder_snow','fire','soul_fire','sweet_berry_bush','wither_rose'].includes(foot.name)){
          reason='hazardous-support';distance=lastSupported;break
        }
        steppedUp||=state.pos.y>previous.y+.01
        distance=Math.max(distance,(state.pos.x-origin.x)*dir.x+(state.pos.z-origin.z)*dir.z)
        // onGround can describe the vertical collision before this tick's
        // horizontal edge crossing. Confirm support under the final body.
        if(state.onGround&&supported(state.pos))lastSupported=distance
        steps=i+1
      }
      if(reason==='horizon-clear'&&!state.onGround){reason='unconfirmed-landing';distance=lastSupported}
      routes[name]={clearance:Math.max(0,Math.min(8,distance)),reason,steps,steppedUp}
    }
    return {version:1,tick,origin:{x:origin.x,y:origin.y,z:origin.z},toward,
      routes,horizonTicks:HORIZON,probeMs:performance.now()-began,
      publicReceivedBlocksOnly:true,controlsApplied:false,globalPathfinding:false}
  }}
}
module.exports={createNavigationProbe,HORIZON}
