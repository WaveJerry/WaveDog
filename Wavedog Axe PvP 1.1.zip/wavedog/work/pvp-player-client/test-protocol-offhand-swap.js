'use strict'
const assert = require('node:assert/strict')
const {requestOffhandSwap} = require('./protocol-offhand-swap')
const registry = require('prismarine-registry')('1.21.1')
const Item = require('prismarine-item')(registry)
const windows = require('prismarine-windows')(registry)

function fixture () {
  const inventory = windows.createWindow(0, 'minecraft:inventory', 'Inventory')
  const calls = []
  for (const [slot, name] of [[37, 'bow'], [40, 'crossbow'], [43, 'diamond_axe'], [45, 'shield']])
    inventory.updateSlot(slot, new Item(registry.itemsByName[name].id, 1))
  const bot = {inventory, quickBarSlot: 7, currentWindow: null,
    async clickWindow (slot, mouseButton, mode) {
      calls.push({slot, mouseButton, mode})
      inventory.acceptClick({slot, mouseButton, mode, item: inventory.slots[slot]})
    },
    async equip (item, destination) { calls.push({fallback: true, destination, slot: item.slot}) }
  }
  return {bot, calls}
}

async function main () {
  const {bot, calls} = fixture()
  const axe = bot.inventory.slots[43]
  const bow = bot.inventory.slots[37]
  let swap = requestOffhandSwap(bot, bow)
  assert(swap.ready)
  await swap.completion
  assert.deepEqual(calls, [{slot:45, mouseButton:1, mode:2}])
  assert.equal(bot.inventory.slots[45], bow)
  assert.equal(bot.inventory.slots[37].name, 'shield')
  assert.equal(bot.inventory.slots[43], axe)
  assert.equal(bot.quickBarSlot, 7)
  assert.equal(bot.inventory.selectedItem, null)
  swap = requestOffhandSwap(bot, bot.inventory.slots[37])
  assert(swap.ready)
  await swap.completion
  assert.equal(bot.inventory.slots[45].name, 'shield')
  assert.equal(bot.inventory.slots[37], bow)
  for (const state of ['cursor', 'container', 'dig', 'selected']) {
    const x = fixture()
    if (state === 'cursor') x.bot.inventory.selectedItem = x.bot.inventory.slots[43]
    if (state === 'container') x.bot.currentWindow = {id:1}
    if (state === 'dig') x.bot.lastDigTime = new Date()
    if (state === 'selected') x.bot.quickBarSlot = 1
    const result = requestOffhandSwap(x.bot, x.bot.inventory.slots[37])
    assert(!result.ready)
    await result.completion
    assert.equal(x.calls[0].fallback, true)
    assert.equal(x.bot.inventory.slots[45].name, 'shield')
  }
  const x = fixture()
  x.bot.inventory.updateSlot(10, new Item(registry.itemsByName.bow.id, 1))
  const result = requestOffhandSwap(x.bot, x.bot.inventory.slots[10])
  assert(!result.ready)
  await result.completion
  assert.equal(x.calls[0].fallback, true)
  console.log('OFFHAND_VANILLA_NUMBER_SWAP_PASS: real inventory model, one click, unchanged mainhand and cursor, guarded fallbacks')
}
main().catch(error => { console.error(error); process.exitCode = 1 })
