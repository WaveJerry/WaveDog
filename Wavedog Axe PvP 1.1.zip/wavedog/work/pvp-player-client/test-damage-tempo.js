const assert = require('node:assert/strict')
const { analyzeDamageTempo } = require('./damage-tempo')

const at = tick => new Date(1794430000000 + tick * 50).toISOString()
const hit = (tick, sequence, attacker, weapon, amount) => ({
  at: at(tick), tick, sequence, type: 'damage', source: 'MELEE',
  attacker, victim: attacker === 'Bot' ? 'Human' : 'Bot', weapon, amount
})
let result = analyzeDamageTempo('Bot', 'Human', [
  hit(0, 1, 'Bot', 'DIAMOND_SWORD', 3),
  hit(8, 2, 'Bot', 'DIAMOND_SWORD', 3),
  hit(16, 3, 'Bot', 'DIAMOND_SWORD', 3),
  hit(20, 4, 'Human', 'DIAMOND_AXE', 4)
])
assert.equal(result.unansweredFollowupHits, 2)
assert.equal(result.swordFollowupHits, 2)
assert.equal(result.swordIntoAxeWins, 1)
assert.deepEqual(result.tempoOutcomes.map(x => x.kind),
  ['unanswered-sword-followup', 'unanswered-sword-followup'])

result = analyzeDamageTempo('Bot', 'Human', [
  hit(0, 1, 'Bot', 'DIAMOND_AXE', 5),
  hit(8, 2, 'Human', 'DIAMOND_SWORD', 3),
  hit(16, 3, 'Human', 'DIAMOND_SWORD', 3)
])
assert.equal(result.axeIntoSwordLosses, 1)
assert.equal(result.unansweredFollowupHits, 0)
assert.equal(result.tempoOutcomes[0].kind, 'axe-lost-sword-tempo')
console.log('damage tempo OK')
