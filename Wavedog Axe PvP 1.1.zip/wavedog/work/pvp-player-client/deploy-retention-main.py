"""Install only the native selfplay referee after all active bouts settle."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import socket
import subprocess
import time
import sys

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
source = base / 'WaveDogSelfPlayGate.jar'
target = server / 'plugins/WaveDogSelfPlayGate.jar'
model = base / 'new-learning/models/recurrent-ppo.json'
native_bouts = server / 'plugins/WaveDogSelfPlayGate/bouts.jsonl'
spec = importlib.util.spec_from_file_location('rcon', 'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)

recover_stopped = '--recover-stopped' in sys.argv[1:]
with socket.socket() as probe:
    server_listening = probe.connect_ex(('127.0.0.1', 25566)) == 0
if recover_stopped:
    if server_listening:
        raise SystemExit('Recovery requires a stopped server; use normal deployment after pausing bouts')
    status = 'already stopped after watchdog; no active server bouts'
else:
    status = rcon.command('selfplay status')
    if 'desired=0 active=0' not in status:
        raise SystemExit('Refused deployment while bouts remain: ' + status)
if not source.is_file() or not target.is_file() or not model.is_file():
    raise SystemExit('Candidate, installed referee or model missing')

stamp = time.strftime('%Y%m%d-%H%M%S')
backup = base / 'new-learning/backups' / ('deploy-retention-' + stamp)
backup.mkdir(parents=True)
shutil.copy2(target, backup / 'WaveDogSelfPlayGate.jar')
shutil.copy2(model, backup / 'recurrent-ppo.json')
if native_bouts.is_file():
    shutil.copy2(native_bouts, backup / 'bouts.jsonl')
before = hashlib.sha256(model.read_bytes()).hexdigest()
original = hashlib.sha256(target.read_bytes()).hexdigest()
candidate = hashlib.sha256(source.read_bytes()).hexdigest()

if not recover_stopped:
    rcon.command('save-all flush')
    rcon.command('stop')
    for _ in range(90):
        with socket.socket() as connection:
            if connection.connect_ex(('127.0.0.1', 25566)) != 0:
                break
        time.sleep(1)
    else:
        raise SystemExit('Main server did not stop; installed JAR preserved')

shutil.copy2(source, target)
if hashlib.sha256(target.read_bytes()).hexdigest() != candidate:
    raise SystemExit('Installed JAR digest mismatch')
if hashlib.sha256(model.read_bytes()).hexdigest() != before:
    raise SystemExit('Model changed during installation')

runtime = base / 'runtime'
for name in ('home', 'tmp', 'console'):
    (runtime / name).mkdir(parents=True, exist_ok=True)
log = runtime / 'console' / ('retention-' + stamp + '.log')
args = [str(server / 'runtime/java21/bin/java.exe'), '-Xms512M', '-Xmx3G',
        '-Duser.home=' + str(runtime / 'home'), '-Djava.io.tmpdir=' + str(runtime / 'tmp'),
        '-Dhttp.proxyHost=127.0.0.1', '-Dhttp.proxyPort=10808',
        '-Dhttps.proxyHost=127.0.0.1', '-Dhttps.proxyPort=10808',
        '-jar', str(server / 'server.jar'), '--nogui']
with log.open('wb') as output:
    process = subprocess.Popen(args, cwd=server, stdin=subprocess.DEVNULL,
                               stdout=output, stderr=subprocess.STDOUT,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
for _ in range(90):
    if process.poll() is not None:
        raise SystemExit('Main server exited; inspect ' + str(log))
    try:
        if rcon.command('list'):
            break
    except (OSError, TimeoutError, ConnectionError):
        pass
    time.sleep(2)
else:
    raise SystemExit('Main readiness timeout; inspect ' + str(log))

receipt = {'at': stamp, 'server_pid': process.pid, 'server_ready': True,
           'installed_jar_sha256': candidate, 'previous_jar_sha256': original,
           'model_sha256_unchanged': before, 'backup': str(backup),
           'console': str(log), 'selfplay_status': rcon.command('selfplay status')}
(base / 'retention-main-deploy.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
