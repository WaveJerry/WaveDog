/** Small PPO cost for repeatedly passing up a public, charged melee window. */
function chargedOpportunity (frame, action, lastAt = 0) {
  if (!frame || !action || action.executed?.attackPackets || action.selected?.attack)
    return false
  const time = Date.parse(action.at)
  if (!Number.isFinite(time) || time - lastAt < 400) return false
  const own = frame.self, target = frame.seen
  if (!own || !target || own.charge < .85 || own.health <= 0
      || own.shielding || own.activeUseSlot != null || target.shield) return false
  if (own.opponentSwingAge != null && own.opponentSwingAge <= 3) return false
  const distance = Math.hypot(own.x - target.x, own.y - target.y,
    own.z - target.z)
  return distance <= 3
}
module.exports = { chargedOpportunity }
