'use strict'
const {createHighRateLoop,createHighRateControlGate,monoMs}=require('./protocol-high-rate-loop')
const {PublicMotionMonitor}=require('./protocol-high-rate-motion')
function createHighRateController({infer,apply,context,onTrace=()=>{},onCycle=()=>{},onError=()=>{},control=false}){
  let matchId=null,epoch=0,requestRevision=0,pending=null,latest=null,closed=false
  const gate=createHighRateControlGate({apply})
  const monitor=new PublicMotionMonitor()
  const counters={cycles:0,requests:0,responses:0,discarded:0,coalesced:0,errors:0}
  const loop=createHighRateLoop({hz:500,onError,onCycle:analysis=>{
    if(closed||analysis.matchId!==matchId)return
    latest=analysis;counters.cycles++
    onCycle(analysis)
    if(control)gate.check(analysis,monoMs())
    if(!analysis.available)return
    if(pending){counters.coalesced++;return}
    const ctx=context(analysis)
    if(!ctx||ctx.tick!==analysis.physicalTick||ctx.matchId!==matchId)return
    const token={matchId,epoch,revision:++requestRevision,observationRevision:analysis.revision,
      atMs:monoMs(),context:ctx}
    pending=token;counters.requests++
    Promise.resolve().then(()=>infer({...token,analysis})).then(result=>{
      counters.responses++
      // Both bout identity and physical anchor must still be current. New
      // packets supersede old observations, even inside the same physics tick.
      const current=context(latest)
      if(closed||token.epoch!==epoch||!latest||latest.revision!==token.observationRevision
          ||latest.matchId!==matchId||current?.tick!==token.context.tick||!result){
        counters.discarded++;onTrace({type:'refinement-discarded',token,result});return
      }
      const action={...token,atMs:token.atMs,command:result}
      gate.publish(action)
      const execution=control?gate.check(latest,monoMs()):'shadow'
      onTrace({type:'model-refinement',token,analysis,command:result,execution})
    }).catch(error=>{
      if(token.epoch!==epoch||closed){counters.discarded++;return}
      counters.errors++;onError(error)
    }).finally(()=>{if(pending===token)pending=null})
  }})
  return {
    reset(id){matchId=id;epoch=gate.reset(id);pending=null;latest=null;requestRevision=0;monitor.reset(id);loop.reset(id);return epoch},
    sample(s){if(!monitor.ingest(s))return false;return loop.sample(s)},
    analyze(){return monitor.analyze(monoMs())},
    get stats(){return {...counters,controlGate:gate.counts}},
    async close(){closed=true;epoch++;pending=null;await loop.close()}
  }
}
module.exports={createHighRateController}
