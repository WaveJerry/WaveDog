'use strict'
// Only the active hand, public equipment components and visible arrow spawn
// are evidence. Elapsed charging time alone never proves an enemy loaded bow.
function observeRanged (s, o, loaded) {
  const bow = o.visible && o.using && o.activeItem?.name === 'bow'
  const loading = o.visible && o.using && o.activeItem?.name === 'crossbow' && !loaded(o.activeItem)
  const start = loading && !s.targetLoading
  if (start || bow && !s.targetBow) s.targetRangedEvent = (s.targetRangedEvent || 0) + 1
  // A visible projectile spawn is separate from drawing/loading. Keeping the
  // two serials separate prevents spending the opening bolt on a load gesture.
  if (o.fired) {
    s.targetShotEvent = (s.targetShotEvent || 0) + 1
    s.targetShotTick = o.tick
  }
  if (start) {s.targetLoadAt = o.tick;s.targetLoadCycle=(s.targetLoadCycle||0)+1}
  const crossbows = o.visible ? [o.mainhand, o.offhand].filter(i => i?.name === 'crossbow') : []
  if (o.fired || loading) s.targetKnownLoaded = false
  else if (crossbows.length) s.targetKnownLoaded = crossbows.some(loaded)
  if (s.targetLoading && !loading) {
    s.targetLoadEndedAt = o.tick
    s.targetLoadResult = !o.visible ? 'unobserved' : s.targetKnownLoaded ? 'charged' : 'unconfirmed'
  }
  s.targetLoading = loading; s.targetBow = bow
  return { targetBow: bow, targetLoading: loading, targetKnownLoaded: Boolean(s.targetKnownLoaded),
    targetLoadCycle:s.targetLoadCycle||0,
    targetLoadResult: s.targetLoadResult || null, targetLoadEndedAt: s.targetLoadEndedAt ?? -1000,
    rangedEvent: s.targetRangedEvent || 0, targetShotEvent: s.targetShotEvent || 0,
    targetShotTick: s.targetShotTick ?? -1000 }
}
// In this 1.21.1 protocol, arrow objectData is the shooter's entity ID itself.
// Real server check: player 1655 spawned an arrow with objectData 1655. The
// former '- 1' assigned it to 1654 and lost every named-opponent shot event.
function projectileShooterId (objectData) {
  return Number.isSafeInteger(objectData) && objectData > 0 ? objectData : null
}
module.exports = { observeRanged, projectileShooterId }
