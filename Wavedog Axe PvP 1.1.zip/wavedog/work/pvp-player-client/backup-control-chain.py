"""Snapshot live learning files before replacing the human control chain."""
from pathlib import Path
import hashlib
import json
import shutil
import time

base = Path(__file__).resolve().parent
root = base / 'new-learning'
target = root / 'backups' / ('control-chain-' + time.strftime('%Y%m%d-%H%M%S'))
target.mkdir(parents=True, exist_ok=False)
sources = [*sorted((root / 'models').glob('*.json')),
           *sorted((root / 'selfplay').glob('*')),
           *sorted(root.glob('*.jsonl')),
           *sorted(root.glob('*.json')),
           Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogSelfPlayGate/bouts.jsonl')]
manifest = []
for source in sources:
    if not source.is_file():
        continue
    relative = source.relative_to(root) if source.is_relative_to(root) else Path('native-bouts.jsonl')
    copy = target / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, copy)
    original_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    copy_hash = hashlib.sha256(copy.read_bytes()).hexdigest()
    if original_hash != copy_hash:
        raise RuntimeError(f'Backup mismatch: {source}')
    manifest.append({'source': str(source), 'backup': str(relative),
                     'bytes': copy.stat().st_size, 'sha256': copy_hash})
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps({'backup': str(target), 'files': len(manifest),
                  'bytes': sum(row['bytes'] for row in manifest),
                  'model_sha256': next(row['sha256'] for row in manifest
                    if Path(row['backup']).as_posix() == 'models/recurrent-ppo.json')}))
