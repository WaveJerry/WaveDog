const assert = require('node:assert/strict')
const { swingFeedback, damageFeedback, hungerFeedback } = require('./attack-reward')

const hit = { source: 'MELEE', amount: 6, native_critical: false }
assert.equal(damageFeedback(hit, 2.5), .3)
assert(damageFeedback(hit, 3.1) > damageFeedback(hit, 2.5))
assert.equal(damageFeedback({ ...hit, amount: 0 }, 3.2), 0,
  'edge position without native damage earns nothing')
assert(damageFeedback({ ...hit, native_critical: true }, 3.1)
  > damageFeedback(hit, 3.1), 'native critical increases damage credit')
assert.equal(damageFeedback({ source: 'ARROW', amount: 6 }, 3.2), .3)
assert(damageFeedback(hit,undefined,2.999)>damageFeedback(hit,undefined,2.9))
assert.equal(damageFeedback(hit,3.3,3.001),.3,'out-of-reach measurements earn no edge bonus')
assert.equal(damageFeedback({...hit,amount:0},undefined,2.999),0)
assert.equal(damageFeedback({...hit,cancelled:true},undefined,2.999),0)
assert(swingFeedback(.3, true) < swingFeedback(1, true),
  'fast clicks cost more even when the attack packet is sent')
assert.equal(swingFeedback(1, true), swingFeedback(2, true),
  'waiting beyond full charge cannot increase attack value')
assert(swingFeedback(.5, true) < swingFeedback(.85, true),
  'ordinary attack opportunity cost follows continuous charge growth')
assert(swingFeedback(.3, false) < swingFeedback(.3, true),
  'air swing loses charge without scoring a hit')
assert(damageFeedback({ ...hit, amount: 1 }, 2.8) + swingFeedback(.55, true) > 0,
  'a useful light hit can retain positive feedback')
assert.equal(hungerFeedback(20, 19), -.025)
assert.equal(hungerFeedback(19, 20), 0)
assert.equal(hungerFeedback(null, 19), 0)
console.log('ATTACK_REWARD_PASS')
