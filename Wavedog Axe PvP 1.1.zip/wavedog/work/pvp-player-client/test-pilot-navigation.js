'use strict'
const assert=require('node:assert/strict'),{Vec3}=require('vec3')
const mc=require('minecraft-data')('1.21.1'),Block=require('prismarine-block')('1.21.1')
const {createNavigationProbe}=require('./protocol-pilot-navigation')
function fixture(kind){
  const bot={version:'1.21.1',registry:mc,jumpTicks:0,jumpQueued:false,inventory:{slots:[]},
    entity:{position:new Vec3(.5,0,.5),velocity:new Vec3(0,-.0784,0),onGround:true,yaw:0,pitch:0,
      eyeHeight:1.62,effects:{},attributes:{}},
    blockAt(p){const q=p.floored();let name=q.y<0?'stone':'air'
      if(kind==='wall'&&q.z<=-1&&q.y>=0)name='stone'
      if(kind==='corner'&&(q.z<=-1||q.x<=-1)&&q.y>=0)name='stone'
      if(kind==='step'&&q.z<=-1&&q.y===0)name='stone_slab'
      if(kind==='stairs'&&q.z<=-1&&q.y===0)name='oak_stairs'
      if(kind==='fence'&&q.z===-1&&q.y===0)name='oak_fence'
      if(kind==='low-ceiling'&&q.z<=-1&&q.y===1)name='stone'
      if(kind==='pit'&&q.z<=-1)name='air'
      if(kind==='lava'&&q.z<=-1&&q.y===0)name='lava'
      if(kind==='unknown'&&q.z<=-1)return null
      const b=Block.fromStateId(mc.blocksByName[name].defaultState,0);b.position=q;return b},
    setControlState(){throw Error('navigation sensor cannot drive the bot')}}
  return {bot,probe:createNavigationProbe(bot),target:{position:new Vec3(.5,0,-3)}}
}
const reports={},timings=[]
for(const kind of ['flat','wall','corner','step','stairs','fence','low-ceiling','pit','lava','unknown']){
  const x=fixture(kind),before=JSON.stringify(x.bot.entity),r=x.probe.observe(x.target,10)
  assert.equal(JSON.stringify(x.bot.entity),before,'look-ahead cannot mutate live player '+kind)
  reports[kind]=r.routes
  timings.push(r.probeMs)
}
assert(reports.flat.toward.clearance>2)
assert(reports.wall.toward.clearance<.5&&reports.wall.left.clearance>2)
assert(reports.corner.toward.clearance<.5&&reports.corner.left.clearance<.5&&reports.corner.right.clearance>2)
assert(reports.step.toward.clearance>2&&reports.step.toward.steppedUp,'normal half-block step uses vanilla step height')
assert(reports.stairs.toward.clearance>2&&reports.stairs.toward.steppedUp,'stairs use their real collision shapes')
assert(reports.fence.toward.clearance<1,'fence is not ordinary walkable floor')
assert(reports['low-ceiling'].toward.clearance<.5,'head collision counts even when chest rays miss')
assert.equal(reports.pit.toward.reason,'unsupported-drop')
assert(reports.pit.toward.clearance<.8,'only supported edge distance: '+JSON.stringify(reports.pit.toward))
assert.equal(reports.lava.toward.reason,'liquid-or-web')
assert.equal(reports.unknown.toward.reason,'unknown-terrain')
console.log('LOCAL_PLAYER_BODY_NAVIGATION_OBSERVATION_PASS',JSON.stringify({routes:Object.fromEntries(Object.entries(reports).map(([k,v])=>[k,v.toward])),probeMs:timings}))
