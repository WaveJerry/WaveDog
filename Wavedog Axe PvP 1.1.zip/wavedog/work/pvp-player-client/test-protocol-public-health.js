'use strict'
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const nbt = require('prismarine-nbt')
const { formattedHearts, createPublicHealthTracker } = require('./protocol-public-health')
const hearts = { text: '', extra: Array.from({ length: 10 }, () => ({ text: '❤', color: '#ff3333' })) }
const encoded = nbt.comp({ text: nbt.string(''), extra: nbt.list(nbt.comp(hearts.extra.map(h =>
  ({ text: nbt.string(h.text), color: nbt.string(h.color) })))) })
assert.deepEqual(formattedHearts(encoded), { capacity: 20, absorptionUpper: 0 })
assert.deepEqual(formattedHearts({ ...hearts, extra: [...hearts.extra, { text: '❤', color: '#ffcc33' }] }),
  { capacity: 20, absorptionUpper: 2 })
assert.equal(formattedHearts({ text: '❤', color: 'unknown' }), null)
const client = new EventEmitter(); let tick = 5
const tracker = createPublicHealthTracker(client, () => tick)
client.emit('scoreboard_objective', { name: 'wd_hearts', action: 0 })
client.emit('scoreboard_display_objective', { position: 2, name: 'wd_hearts' })
tracker.beginMatch('one')
function score (extra = {}) { client.emit('scoreboard_score', { itemName: 'Fighter', scoreName: 'wd_hearts',
  value: 1, number_format: 2, styling: encoded, ...extra }) }
score() // Modern packet deliberately has no action field.
assert.equal(tracker.observe('Fighter', true, 2).healthUpper, 1)
assert.equal(tracker.observe('Fighter', true, 2).healthLowerExclusive, 0)
assert.equal(tracker.observe('Fighter', false, 2), null)
assert.equal(tracker.observe('Fighter', true, 11), null)
assert.equal(tracker.observe('Other', true, 2), null)
tracker.beginMatch('two')
assert.equal(tracker.observe('Fighter', true, 2), null, 'old bout HP cannot leak')
score({ number_format: undefined, styling: undefined, action: 0 })
assert.equal(tracker.observe('Fighter', true, 2).absorptionKnown, false)
client.emit('reset_score', { entity_name: 'Fighter', objective_name: 'wd_hearts' })
assert.equal(tracker.observe('Fighter', true, 2), null)
score(); client.emit('scoreboard_objective', { name: 'wd_hearts', action: 1 })
assert.equal(tracker.observe('Fighter', true, 2), null)
console.log('PUBLIC_HEALTH_PACKETS_PASS')
