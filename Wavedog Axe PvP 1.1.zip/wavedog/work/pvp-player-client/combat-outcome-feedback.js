// Credit actual GRU combat choices with public/native outcomes after a bout.
const millis = value => Date.parse(value)
const damage = (event, attacker, victim) =>
  event.type === 'damage' && !event.cancelled && event.amount > 0 &&
  event.attacker === attacker && event.victim === victim

function jumpOutcomes (session, events) {
  const jumps = session.jumpEpisodes || []
  const frames = session.frameHistory || []
  return jumps.map((jump, index) => {
    const start = millis(jump.at)
    const landing = frames.find(row => row.frame > jump.frame &&
      row.self.ground && millis(row.at) > start)
    const next = jumps[index + 1] && millis(jumps[index + 1].at)
    const end = Math.min(start + 1300, landing ? millis(landing.at) + 150 : Infinity,
      next || Infinity)
    const own = events.filter(e => damage(e, session.name, session.opponent)
      && millis(e.at) >= start && millis(e.at) <= end)
    const taken = events.filter(e => damage(e, session.opponent, session.name)
      && millis(e.at) >= start && millis(e.at) <= end)
    const dealt = own.reduce((n, e) => n + e.amount, 0)
    const received = taken.reduce((n, e) => n + e.amount, 0)
    const criticalHit = own.some(e => e.source === 'MELEE' &&
      e.attacker_fall_distance > 0 && !e.attacker_on_ground &&
      !e.attacker_sprinting)
    const immediateHit = taken.some(e => millis(e.at) - start <= 250)
    let kind = 'trade', reward = 0
    if (criticalHit && dealt >= received) { kind = 'falling-hit'; reward = .05 }
    else if (dealt > 0 && received === 0) { kind = 'safe-hit'; reward = .02 }
    else if (received > dealt && !immediateHit) {
      kind = 'punished-jump'; reward = -.025
    } else if (dealt === 0 && received === 0) {
      kind = 'empty-jump'; reward = -.007
    } else if (immediateHit && dealt === 0) kind = 'possible-jump-reset'
    return { decidedFrame: jump.decidedFrame, kind, reward,
      dealt, received, start: jump.at }
  })
}

function shieldOutcomes (session, events) {
  const actions = session.actionHistory || []
  const episodes = []
  let current = null
  for (const action of actions) {
    const active = action.executed?.using && action.executed?.offhand === 'shield'
    if (active && !current) current = { start: millis(action.at), at: action.at,
      decidedFrame: null, distance: null }
    if (active && current) {
      if (current.decidedFrame == null && action.selected?.shield &&
          Number.isInteger(action.decidedFrame) &&
          !action.ignoredHeads.includes(4))
        current.decidedFrame = action.decidedFrame
      if (current.distance == null) {
        const frame = session.frameHistory?.find(row => row.frame === action.frame)
        if (frame) current.distance = Math.hypot(frame.self.x-frame.seen.x,
          frame.self.z-frame.seen.z)
      }
    }
    if (!active && current) {
      current.end = millis(action.at); episodes.push(current); current = null
    }
  }
  if (current) {
    current.end = millis(actions.at(-1)?.at || current.at)
    episodes.push(current)
  }
  return episodes.filter(item => item.decidedFrame != null).map(item => {
    const within = event => millis(event.at) >= item.start &&
      millis(event.at) <= item.end + 100
    const blocked = events.filter(e => e.type === 'damage' && !e.cancelled &&
      e.victim === session.name && e.attacker === session.opponent &&
      e.victim_blocking && e.shield_modifier < 0 && within(e))
    const taken = events.filter(e => damage(e, session.opponent, session.name)
      && within(e))
    const durationMs = item.end - item.start
    let kind = 'held-shield', reward = 0
    if (blocked.length) { kind = 'native-block'; reward = .045 }
    else if (taken.length) { kind = 'shield-bypassed'; reward = -.015 }
    else if (durationMs < 250) { kind = 'cancelled-before-effective'; reward = -.006 }
    else if (item.distance != null && item.distance > 5) {
      kind = 'distant-shield'; reward = -.004
    }
    return { decidedFrame: item.decidedFrame, kind, reward,
      durationMs, blocks: blocked.length, start: item.at }
  })
}

module.exports = { jumpOutcomes, shieldOutcomes }
