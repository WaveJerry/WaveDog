// Share the one live WaveDog model service with protocol-player training clones.
// The server's WaveDog client remains connected to the same service and checkpoint.
const net = require('node:net')

const socket = net.connect({ host: '127.0.0.1', port: 18766 })
socket.setNoDelay(true)
socket.on('connect', () => process.stdin.pipe(socket))
socket.on('data', chunk => process.stdout.write(chunk))
socket.on('error', error => {
  process.stderr.write(`Fresh dual service: ${error.message}\n`)
  process.exitCode = 1
})
socket.on('close', () => process.exit(process.exitCode || 1))
process.stdin.on('end', () => socket.end())
