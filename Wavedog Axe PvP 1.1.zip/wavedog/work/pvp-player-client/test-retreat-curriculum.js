const assert = require('node:assert/strict')
const { schedule } = require('./curriculum')
const { counterRetreatPlan } = require('./retreat-curriculum')

const styles = ['AGGRESSIVE','DEFENSIVE','RANGED','FLANK','GROUND_COMBO','MIXED']
const focuses = ['FREE','CHARGE','SHIELD','AXE_BREAK','CRITICAL','SPRINT_KB','ESCAPE',
  'SYNC','FLANK','COMBO','BOW','CROSSBOW','DODGE','WALL','LATENCY','OPPONENT']
const seen = new Set()
let special = 0, critical = 0, tempo = 0, ranged = 0
for (let bout = 1; bout <= 90; bout++) for (let pair = 0; pair < 10; pair++) {
  const plans = [0,1].map(side => counterRetreatPlan(
    schedule(pair*2+side,bout,styles,focuses,'CRITICAL',413),pair*2+side,bout))
  assert.notEqual(plans[0].style, plans[1].style)
  assert.equal(plans[0].matchup, plans[1].matchup)
  seen.add(plans[0].matchup)
  if (bout % 5 === 0 && pair % 2 === 0) {
    special++
    assert.deepEqual(new Set(plans.map(p => p.focus)),new Set(['ESCAPE','CRITICAL']))
  }
  if (bout % 5 === 2 && pair % 2 === 0) {
    critical++
    assert.deepEqual(new Set(plans.map(p => p.focus)),new Set(['CRITICAL','SPRINT_KB']))
  }
  if (bout % 5 === 4 && pair % 2 === 1) {
    tempo++
    assert.deepEqual(new Set(plans.map(p => p.focus)),new Set(['COMBO','SYNC']))
  }
  if (bout % 5 === 3) {
    ranged++
    assert(plans.some(p => ['BOW','CROSSBOW'].includes(p.focus)))
    assert(plans.some(p => p.focus === 'DODGE'))
    assert(plans.every(p => p.curriculumSource === 'ranged-tempo-research'))
  }
}
for (let a = 0; a < styles.length; a++) for (let b = a + 1; b < styles.length; b++)
  assert(seen.has(`${styles[a]} vs ${styles[b]}`),
    `missing broad matchup ${styles[a]} vs ${styles[b]}`)
assert.equal(special,90)
assert.equal(critical,90)
assert.equal(tempo,90)
assert.equal(ranged,180)
console.log('RETREAT_CURRICULUM_PASS retreat=10% critical=10% tempo=10% ranged=20% varied focus coverage')
