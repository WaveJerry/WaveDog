// Ordinary Minecraft 1.21.1 network players. One shared GRU checkpoint and
// Qwen memory create temporary bout actors; native deaths decide PPO updates.
const mineflayer = require('mineflayer')
const mcData = require('minecraft-data')('1.21.1')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const childProcess = require('node:child_process')
const zlib = require('node:zlib')
const { promisify } = require('node:util')
const { Vec3 } = require('vec3')
const { RaycastIterator } = require('prismarine-world').iterators
const { schedule: scheduleCurriculum } = require('./curriculum')
const { selectPlayerExperience, selectMeasuredLessons } = require('./durable-memory')
const { NativeEventStream, mergeTimeline } = require('./native-feedback')
const { bowSpeed, plannedBowDrawMs, solvePitch, leadTarget } = require('./ballistic-aim')
const { analyzeTactics } = require('./tactical-outcomes')
const { analyzeLandingChoices } = require('./critical-tactics')
const { wholeBout } = require('./whole-bout')
const { referenceFor } = require('./knowledge-reference')
const { nearbyFlyingArrows } = require('./public-observation')
const { takeBatch } = require('./review-queue')
const { SharedOutcomeMemory } = require('./shared-outcome-memory')
const { counterRetreatFeedback } = require('./counter-retreat-feedback')
const { EDGE_PRIORITY, edgePriorityPlan, edgePriorityReward } = require('./edge-priority')
const { OPERATOR_TACTICS, tacticalGoal } = require('./edge-tactical-goal')
const { counterRetreatPlan } = require('./retreat-curriculum')
const { techniqueGoal } = require('./technique-goals')
const { immediateRoundFact } = require('./immediate-round-memory')
const { movementInputs } = require('./movement-inputs')
const { chargedOpportunity } = require('./attack-opportunity')
const { targetBoxWithinReach, targetBoxDistance } = require('./melee-reach')
const { nearestHitPoint, immediateLook, currentViewPacket } = require('./protocol-mechanical-math')
const { frameChunks, chunkEvidence } = require('./frame-review')
const { swingFeedback, damageFeedback, hungerFeedback } = require('./attack-reward')
const { SingleLaneState } = require('./single-lane-state')
const { exploiterPlan } = require('./exploiter-curriculum')

const execFile = promisify(childProcess.execFile)
const base = __dirname
const server = path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server')
const freshDual = process.env.WAVEDOG_FRESH_DUAL === '1'
const store = freshDual
  ? path.join(base, '..', 'pvp-8.6-dual-fresh', 'model', 'coach')
  : path.join(base, 'new-learning', 'selfplay')
const manualGoalPath = path.join(store, 'manual-next-goal.json')
const checkpoint = path.join(base, 'new-learning', 'models')
const readyFile = path.join(base, 'new-learning', 'selfplay-ready.json')
const token = fs.readFileSync(path.join(server, 'plugins', 'WaveDogSelfPlayGate', 'selfplay-token.txt'), 'utf8').trim()
const serverRunId = crypto.createHash('sha256').update(token).digest('hex').slice(0, 12)
const count = Number(process.argv.find(a => a.startsWith('--bots='))?.split('=')[1] || 2)
const rangedValidation = process.env.WAVEDOG_VALIDATION_RANGED === '1'
const debugCrossbow = process.env.WAVEDOG_DEBUG_CROSSBOW === '1'
const singleLane = process.env.WAVEDOG_SINGLE_LANE === '1'
const manualLane = singleLane && process.env.WAVEDOG_MANUAL_LANE === '1'
if (!Number.isInteger(count) || count < 2 || count > 60 || count % 2) throw Error('--bots must be even 2..60')
const arenaCount = count / 2
const laneState = singleLane
  ? new SingleLaneState(path.join(store, 'single-lane-state.json'), arenaCount) : null
const names = Array.from({ length: count }, (_, i) => `NBot${String(i + 1).padStart(2, '0')}`)
const authPath = path.join(base, '.auth-selfplay.json')
const credentials = fs.existsSync(authPath) ? JSON.parse(fs.readFileSync(authPath, 'utf8')) : {}
for (const name of names) credentials[name] ||= crypto.randomBytes(18).toString('hex')
fs.writeFileSync(authPath, JSON.stringify(credentials), { mode: 0o600 })
fs.mkdirSync(store, { recursive: true })

const focusNames = new Set(freshDual
  ? ['FREE','CHARGE','CRITICAL','SPRINT_KB','ESCAPE','FLANK','COMBO','WALL','LATENCY','OPPONENT']
  : ['FREE','CHARGE','SHIELD','AXE_BREAK','CRITICAL','SPRINT_KB','ESCAPE','SYNC','FLANK','COMBO','BOW','CROSSBOW','DODGE','WALL','LATENCY','OPPONENT'])
const styleNames = new Set(freshDual
  ? ['AGGRESSIVE','DEFENSIVE','FLANK','GROUND_COMBO','MIXED']
  : ['AGGRESSIVE','DEFENSIVE','FLANK','GROUND_COMBO','RANGED','MIXED'])
const focusSchema = { type: 'string', enum: [...focusNames] }
const coachSchema = { type: 'object', properties: {
  focus: focusSchema, style: { type: 'string', enum: [...styleNames] },
  reason: { type: 'string', maxLength: 120 } },
required: ['focus','style','reason'], additionalProperties: false }
const reviewSchema = { type: 'object', properties: {
  focusA: focusSchema, focusB: focusSchema, lesson: { type: 'string', maxLength: 120 } },
required: ['focusA','focusB','lesson'], additionalProperties: false }
const batchReviewSchema = { type: 'object', properties: {
  focus: focusSchema, lesson: { type: 'string', maxLength: 90 } },
required: ['focus','lesson'], additionalProperties: false }
const REVIEW_BATCH_SIZE = freshDual ? 1 : count >= 20 ? 12 : 4
// The shared CPU trainer serializes all actors. Large concurrent bouts can
// queue for many minutes; a short timeout would start a new bout before PPO.
const TRAINING_WAIT_MS = 60 * 60 * 1000
const curriculumSeed = Number.parseInt(serverRunId.slice(0, 8), 16)
const styleRotation = freshDual
  ? ['AGGRESSIVE','DEFENSIVE','FLANK','GROUND_COMBO','MIXED']
  : ['AGGRESSIVE','DEFENSIVE','RANGED','FLANK','GROUND_COMBO','MIXED']
const historyRoles = ['history-44kk','history-48k','history-53k','history-119k']
const focusRotation = [...focusNames]
function manualGoalFor (index, bout) {
  if (!manualLane || !fs.existsSync(manualGoalPath)) return null
  try {
    const row = JSON.parse(fs.readFileSync(manualGoalPath, 'utf8'))
    const arena = Math.floor(index / 2) + 1
    if (row.cycle !== laneState.value.cycle || row.arena !== arena || row.bout !== bout)
      return null
    const side = index % 2 ? 'b' : 'a'
    const goal = row.fighters?.[side]
    if (!goal || !focusNames.has(goal.focus) || !styleNames.has(goal.style)
        || typeof goal.goal !== 'string' || !goal.goal.trim())
      throw Error('Invalid manual training goal')
    return { focus: goal.focus, style: goal.style,
      goal: goal.goal.slice(0, 140), goalStage: goal.goalStage || 'MELEE',
      techniqueCues: Array.isArray(goal.techniqueCues)
        ? goal.techniqueCues.filter(x => focusNames.has(x)).slice(0, 2) : [],
      matchup: row.matchup || 'operator-directed technique study',
      curriculumSource: 'operator-directed-technique', scheduledFocus: goal.focus }
  } catch (error) {
    log('manual_goal_error', { error: String(error) })
    return null
  }
}
function curriculumFor (fighter, bout) {
  const index = names.indexOf(fighter)
  const manualGoal = manualGoalFor(index, bout)
  if (manualGoal) return manualGoal
  if (freshDual && Math.floor(index / 2) === 1 && bout % 3 === 1) {
    // One occasional fair scripted opponent; alternate physical bot sides.
    // The other cage and ordinary bouts retain shared-brain self-play.
    focusNames.add('SYNC')
    if (!focusSchema.enum.includes('SYNC')) focusSchema.enum.push('SYNC')
    const probe = index % 2 === Math.floor(bout / 3) % 2
    return { focus: probe ? 'CRITICAL' : Math.floor(bout / 3) % 2 ? 'SYNC' : 'OPPONENT',
      style: probe ? 'AGGRESSIVE' : 'MIXED',
      techniqueCues: probe ? ['SPRINT_KB', 'COMBO'] : ['SPRINT_KB', 'COMBO'],
      goalStage: 'MELEE', curriculumSource: 'wavejerry-critical-exploiter',
      goal: probe ? '模仿两局实测跑跳下落暴击与命中后退距，作为公平脚本对手，不参与PPO'
        : '比较上升抢断、下落躲避、可接上的惩罚暴击与出距前补刀；专项试受击tick地面起跳，实际击退和净换血验收，不能宣称起跳即重置成功' }
  }
  if (rangedValidation && validationOrigin === null) validationOrigin = bout
  const validationBout = bout - validationOrigin + 1
  if (rangedValidation && validationBout <= 4) return { style: 'RANGED',
    focus: (validationBout + index) % 2 ? 'BOW' : 'CROSSBOW',
    scheduledFocus: 'VALIDATION', curriculumSource: 'ranged-validation' }
  const rangedBout = !freshDual && bout % 5 === 3
  const allowedFocus = rangedBout
    ? focusRotation : focusRotation.filter(focus => !['BOW','CROSSBOW','DODGE'].includes(focus))
  const qwenPool = sharedLessons.filter(row => row.lessonSource === 'measured-after-Qwen'
    && allowedFocus.includes(row.focus) && row.focus !== 'FREE')
    .sort((a,b) => String(b.boutAt || b.at || '').localeCompare(String(a.boutAt || a.at || '')))
    .slice(0, 48)
  // Every clone samples the same shared knowledge pool; no Bot owns a permanent brain.
  const qwen = qwenPool.length ? qwenPool[crypto.randomInt(Math.min(12,qwenPool.length))] : null
  const plan = scheduleCurriculum(index, bout, styleRotation, allowedFocus,
    qwen?.focus, curriculumSeed)
  const withGoal = freshDual ? edgePriorityPlan(plan, index, bout)
    : exploiterPlan(counterRetreatPlan(plan, index, bout),
      index, bout, mergedOutcomes.latest(24))
  const technique = techniqueGoal(withGoal.focus, index, bout)
  const freshGoals = {
    FREE: '自由探索剑斧近战变式，按原生命中、净换血和胜负留优去劣',
    CHARGE: '普通攻击争取高蓄力，必要轻击用于抢救、打断或收尾；比较原生伤害',
    CRITICAL: '通常疾跑接近并选落点，真实下落出暴击刀前短暂松疾跑，攻击后若继续接近再疾跑；或受击后真实下落窗口惩罚暴击，按原生暴击与净换血验收',
    SPRINT_KB: '最高优先练习合法射程边界的疾跑击退刀，打断对手平 A 起手，不给后续跳劈机会；深入近身才重点考虑惩罚暴击、剑连击。按实际击退、未被接连击和净换血验收，不能为守固定距离放弃合法命中',
    ESCAPE: '被连击时沿安全方向后撤出距止损，再选择有效反击',
    FLANK: '用前后横移变化制造难预测的平地走位，仍以合法射程先手、实际位移和净换血验收；少蹲起',
    COMBO: '持续贴脸换血时主动比较切剑连续真实暴击的收益，不要求先有斧头暴击；受击时比较惩罚暴击和同tick跳跃重置；对手举有效盾可选择剑切斧单次破盾再切剑续攻，切换蓄力损失计入净换血',
    WALL: '避开墙角并利用安全地形控距，核对真实位移和伤害',
    LATENCY: '比较逐帧观察、实际发包和原生命中，避免过期动作',
    OPPONENT: '辨认对手剑斧节奏，针对可见动作选择可测反制'
  }
  const freshVariants = {
    CRITICAL: [
      '射程外疾跑选落点跳入距，仅真实下落暴击出刀前短暂松疾跑，攻击后需要接近时恢复疾跑；以原生暴击、命中与净换血验收',
      '自身受击后若仍在射程内且真实下落，选择惩罚暴击窗口；比较回击伤害与继续挨打',
      '斧头真实暴击入近距后评估切剑接连续真实暴击；若对手出距则及时停止追连',
      '对手跳劈下落前用边缘先手或短移出落点打断，分开统计自己命中、对手暴击和净换血'],
    COMBO: [
      '贴脸持续交战尝试切剑连续真实暴击，不要求先用斧头起手；每刀需要足够蓄力、真实下落和出刀前松疾跑，比较原生暴击次数与净换血',
      '地面剑 W-tap 连招：控制双方距离，连不上及时退出，按原生击退和伤害验收',
      '剑连暴期间对手举有效盾时尝试切斧破盾再切剑续攻；被打后可穿插惩罚暴击和受击tick跳跃重置，切换损失和真实击退必须计入，不预设无损秒切'],
    SPRINT_KB: [
      '优先在真实射程边缘先手疾跑击退，断掉对手平 A 再跳劈的起手；不要站着等惩罚暴击，也不在射程外挥空',
      '用短促变向制造难预测的平地走位，避免固定绕圈和无意义蹲起',
      '对手跳劈下落前以合法射程边缘疾跑先手打断，按真实命中和净换血验收',
      '对手平地普通刀准备入距时，在合法边缘先手击退或短移出距；按原生命中和净换血验收'],
    FLANK: [
      '平地横移选择实际侧面位置，再判断入距和出刀；避免原地绕圈',
      '用前后横移的短促变化争取合法射程先手，比较对手反击和净换血'],
    ESCAPE: [
      '被连击时选择安全后撤方向，真实出距后重新评估入距和反击',
      '近距吃亏时一次性脱离攻击范围止损；不能无目的长时间后退']
  }
  const variants = freshVariants[withGoal.focus]
  const freshGoal = variants
    ? variants[(bout - 1 + Math.floor(index / 2)) % variants.length]
    : freshGoals[withGoal.focus]
  const specialCues = {
    'ranged-tempo-research': { BOW: ['ESCAPE', 'DODGE'],
      CROSSBOW: ['ESCAPE', 'DODGE'], DODGE: ['SPRINT_KB', 'SHIELD'] },
    'critical-entry-research': { CRITICAL: ['SPRINT_KB', 'COMBO'],
      SPRINT_KB: ['CHARGE', 'SHIELD'] },
    'sword-tempo-research': { COMBO: ['CHARGE', 'CRITICAL'],
      SYNC: ['SHIELD', 'ESCAPE'] },
    'counter-retreat-research': { ESCAPE: ['SHIELD', 'SPRINT_KB'],
      CRITICAL: ['SPRINT_KB', 'FLANK'] },
    'exploiter-research': { CHARGE: ['SPRINT_KB', 'COMBO'],
      CRITICAL: ['SPRINT_KB', 'COMBO'], ESCAPE: ['SHIELD', 'COMBO'],
      SPRINT_KB: ['CHARGE', 'SHIELD'], COMBO: ['CHARGE', 'CRITICAL'],
      SYNC: ['SHIELD', 'ESCAPE'], BOW: ['ESCAPE', 'DODGE'],
      DODGE: ['BOW', 'SPRINT_KB'] }
  }
  const techniqueCues = (withGoal.curriculumSource === 'edge-interrupt-priority' ? ['CHARGE','ESCAPE'] : specialCues[withGoal.curriculumSource]?.[withGoal.focus]
    || technique.techniqueCues).filter(cue => !freshDual || focusNames.has(cue))
  const qwenChosen = withGoal.curriculumSource === 'shared-Qwen-experiment'
    && qwen?.focus === withGoal.focus
  return { ...withGoal, techniqueCues,
    goal: freshDual ? freshGoal : withGoal.goal || (qwenChosen
    ? `${technique.goal}；Qwen本局问题：${String(qwen.qwenSuggestion || qwen.lesson).slice(0,80)}`
    : technique.goal), goalStage: freshDual ? 'MELEE' : withGoal.goalStage || (withGoal.goal ? (rangedBout ? 'RANGED'
      : withGoal.curriculumSource === 'counter-retreat-research'
        ? withGoal.focus === 'ESCAPE' ? 'STANDOFF' : 'MELEE' : technique.stage)
      : technique.stage), goalMatchId: qwenChosen ? qwen.matchId : null }
}
const humanTrialsPath = path.join(base, 'new-learning', 'human-trial-results.jsonl')
const humanTrials = fs.existsSync(humanTrialsPath) ? fs.readFileSync(humanTrialsPath, 'utf8').split(/\r?\n/)
  .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  .filter(row => row.reason === 'death').slice(-4) : []
const bots = new Map(), readyBots = new Set(), sessions = new Map(), pairs = new Map(), contexts = new Map()
let activeChallenge = null
let validationOrigin = null
const finishWaiters = new Map()
// The main WaveDog plugin has its own request counter on this shared service.
// Keep clone IDs in a disjoint, exactly representable Java long range.
let bridge, bridgeReady = false, bridgeBuffer = '',
  nextRequestId = freshDual ? 1_000_000_000_000 : 0,
  desired = 0, stopping = false
let qwenActive = 0
const qwenQueue = []
const sharedLessonsPath = path.join(store, 'shared-lessons.jsonl')
const roundsPath = path.join(store, 'rounds.jsonl')
const challengesPath = path.join(store, 'human-challenges.jsonl')
const humanEventsPath = path.join(store, 'human-native-events.jsonl')
const humanFramesPath = path.join(store, 'human-frames.jsonl')
const mergedOutcomes = new SharedOutcomeMemory([roundsPath, challengesPath])
const nativeEvents = new NativeEventStream(path.join(server, 'plugins', 'WaveDogSelfPlayGate', 'bouts.jsonl'))
async function takeNativeBout (arena, bout) {
  for (let attempt = 0; attempt < 20; attempt++) {
    const record = nativeEvents.takeRecord(arena, bout)
    if (record) return record
    await new Promise(resolve => setTimeout(resolve, 100))
  }
  return null
}
const coachPath = path.join(store, 'coach-contexts.jsonl')
const playerExperiencePath = path.join(store, 'player-experience.jsonl')
const qwenErrorsPath = path.join(store, 'qwen-errors.jsonl')
const qualityFlagsPath = path.join(store, 'quality-flags.jsonl')
const cloneChatPath = path.join(store, 'clone-chat.jsonl')
// Durable operator-visible receipts for clone -> shared-brain commits.  These
// are emitted only after the PPO worker has written the checkpoint, so a
// queued rollout or a failed training request is never reported as learned.
const trainingNotificationsPath = path.join(store, 'training-notifications.jsonl')
const frameArchive = path.join(store, 'frame-bouts')
const frameReviewPath = path.join(store, 'frame-review-receipts.jsonl')
fs.mkdirSync(frameArchive, { recursive: true })
const researchHistory = fs.existsSync(roundsPath)
  ? fs.readFileSync(roundsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { return [JSON.parse(line)] } catch { return [] }
  }).filter(row => row.reason === 'death' && Object.values(row.tactics || {})
    .some(t => Number.isInteger(t?.edgeCounterEscapes))).slice(-24) : []
function researchFocusChoices () {
  // Qwen can choose across all three phases; measured gaps are supplied as
  // context rather than enforced as a fixed focus gate.
  return [...focusNames]
}
function researchEvidence () {
  const recent = researchHistory.slice(-24)
  const count = key => recent.reduce((sum, row) => sum + Object.values(row.tactics || {})
    .reduce((n,t) => n + (t[key] || 0),0),0)
  return { bouts: recent.length,
    blockedMelee: count('blockedMelee'), counterHits: count('counterHits'),
    counterProgress: count('counterProgress'), counterPunished: count('counterPunished'),
    counterEscapes: count('counterEscapes'),
    edgeHits: count('edgeHits'), safeEdgeHits: count('safeEdgeHits'),
    sprintEdgeHits: count('sprintEdgeHits'),
    landingAttempts: count('landingAttempts'),
    landingCriticalHits: count('landingCriticalHits'),
    sprintJumpEntries: count('sprintJumpEntries'),
    sprintJumpCriticalHits: count('sprintJumpCriticalHits'),
    longRunJumpEntries: count('longRunJumpEntries'),
    longRunJumpCriticalHits: count('longRunJumpCriticalHits'),
    nativeCriticalHits: count('nativeCriticalHits'),
    swordFollowupHits: count('swordFollowupHits'),
    arrowLaunches: count('arrowLaunches'), arrowHits: count('arrowHits'),
    safeHitExits: count('safeHitExits'), edgeCounterEscapes: count('edgeCounterEscapes'),
    counterEscapeArrows: count('counterEscapeArrows'),
    edgeCounterPunished: count('edgeCounterPunished'),
    rangedExchange: count('rangedExchange') }
}
const invalidMatchIds = new Set(fs.existsSync(qualityFlagsPath)
  ? fs.readFileSync(qualityFlagsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { const row = JSON.parse(line); return row.status === 'mechanics-invalid' ? [row.matchId] : [] }
    catch { return [] }
  }) : [])
const invalidReviewMatchIds = new Set(fs.existsSync(qualityFlagsPath)
  ? fs.readFileSync(qualityFlagsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { const row = JSON.parse(line)
      return row.status === 'review-invalid' ? [row.matchId] : []
    } catch { return [] }
  }) : [])
const allSharedLessons = fs.existsSync(sharedLessonsPath) ? fs.readFileSync(sharedLessonsPath, 'utf8').split(/\r?\n/)
  .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } }) : []
const sharedLessons = allSharedLessons.filter(row =>
  !invalidMatchIds.has(row.matchId)
  && !(invalidReviewMatchIds.has(row.matchId)
    && row.lessonSource === 'measured-after-Qwen')
  && row.lesson !== '可检验的一句话')
let experienceReadIndex = 0, lessonReadIndex = 0
// Old per-name contexts remain in the append-only archive but are never
// reloaded as a permanent Bot identity. Each bout receives a new clone.
function reviewKey (row) {
  if (row.matchId) return row.matchId
  const at = String(row.at || '')
  const era = at < '2026-11-11T09:13:52' ? 'before-1713'
    : at < '2026-11-11T09:54:20' ? '1713-to-1754' : 'after-1754'
  return `${era}:${row.arena}:${row.bout}`
}
const reviewedKeys = new Set(allSharedLessons.map(reviewKey))
const humanReviewedKeys = new Set(allSharedLessons.filter(row => row.source === 'human-challenge-Qwen').map(reviewKey))
const humanQueuedReviews = new Set()
const queuedReviews = new Set(), pendingReviews = []
const historicalRoundBacklog = [], historicalHumanBacklog = []
let batchReviewsActive = 0, reviewRetryAfter = 0
let reviewBatchLimit = REVIEW_BATCH_SIZE
let reviewHistoricalTurn = true

function now () { return new Date().toISOString() }
function append (file, row) { fs.appendFileSync(file, JSON.stringify({ at: now(), ...row }) + '\n') }
function notifySharedBrainMerge (receipt, source = 'clone') {
  if (receipt.quarantined) {
    const notice = { event: 'shared_brain_quarantined', fighter: receipt.fighter,
      round: receipt.round, rolloutSeq: receipt.rolloutSeq, reasons: receipt.reasons,
      trainedFrames: 0, rawTrajectoryPreserved: true }
    append(trainingNotificationsPath, notice); log('shared_brain_quarantined', notice)
    return
  }
  const notice = {
    event: 'shared_brain_merge', source,
    fighter: receipt.fighter, round: receipt.round,
    rolloutSeq: receipt.rolloutSeq,
    partial: receipt.event === 'trained_partial',
    rolloutFrames: receipt.rollout_frames || 0,
    trainedFrames: receipt.trained_frames || 0,
    ppoUpdates: receipt.gradient_updates_after,
    trainedEpisodes: receipt.trained_episodes,
    checkpoint: receipt.checkpoint,
    checkpointSha256: receipt.sha256 || null,
    optimizer: 'PPO+Adam',
    sharedPolicy: 'GRU64+GTrXL4x256',
    qwen: 'review-and-memory-only; no weight update'
  }
  append(trainingNotificationsPath, notice)
  log('shared_brain_merge', notice)
}
function playerExperience (limit = 8) {
  if (!fs.existsSync(playerExperiencePath)) return []
  const rows = fs.readFileSync(playerExperiencePath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  return selectPlayerExperience(rows, experienceReadIndex++, limit)
}
function recentLessons (limit) {
  return selectMeasuredLessons([...sharedLessons].sort((a,b) =>
    String(a.boutAt || a.at || '').localeCompare(String(b.boutAt || b.at || ''))),
  lessonReadIndex++, limit)
}
function orderedMemory () {
  const experience = playerExperience(6)
  const lessons = recentLessons(2)
  const playerRows = fs.existsSync(playerExperiencePath)
    ? fs.readFileSync(playerExperiencePath, 'utf8').split(/\r?\n/).flatMap(line => {
      try { return [JSON.parse(line)] } catch { return [] }
    }) : []
  const rows = [...experience.map(text => {
    const row = [...playerRows].reverse().find(x => x.text?.trim().slice(0, 160) === text)
    return { at: row?.at || '', source: 'player', text: text.slice(0,120) }
  }), ...lessons.map(text => {
    const row = [...sharedLessons].reverse().find(x => x.lesson?.trim().slice(0, 120) === text)
    return { at: row?.boutAt || row?.at || '', source: 'measured', text }
  }), ...mergedOutcomes.latest(2)]
  return rows.sort((a, b) => a.at.localeCompare(b.at))
}
function log (event, data = {}) { console.log(JSON.stringify({ at: now(), event, ...data })) }
function sendBridge (value) { if (!bridge?.stdin.writable) throw Error('GRU bridge is offline'); bridge.stdin.write(JSON.stringify(value) + '\n') }
async function rcon (command) {
  const args = [path.join(base, '..', '..', 'outputs', 'MC-Public', 'rcon_local.py'), ...command.split(' ')]
  const { stdout } = await execFile('python', args, { cwd: base, windowsHide: true, timeout: 20000 })
  return stdout.trim()
}
function scheduleQwen (task, priority = false) {
  return new Promise((resolve, reject) => {
    if (priority) qwenQueue.unshift({ task, resolve, reject })
    else qwenQueue.push({ task, resolve, reject })
    pumpQwen()
  })
}
function pumpQwen () {
  while (qwenActive < 1 && qwenQueue.length) {
    const item = qwenQueue.shift(); qwenActive++
    item.task().then(item.resolve, item.reject).finally(() => { qwenActive--; pumpQwen() })
  }
}
async function inferQwen (messages, maxTokens = 128, schema = null, partialReply = false) {
  const body = { model: 'wavedog-tactics', temperature: 0.25, max_tokens: maxTokens,
    messages, response_format: { type: 'json_object', ...(schema ? { schema } : {}) } }
  const response = await fetch('http://127.0.0.1:18765/v1/chat/completions', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    signal: AbortSignal.timeout(150000) })
  if (!response.ok) throw Error(`Qwen HTTP ${response.status}: ${(await response.text()).slice(0,300)}`)
  const data = await response.json()
  const raw = data.choices[0].message.content
  try { return JSON.parse(raw) }
  catch (error) {
    if (partialReply) {
      const match = raw.match(/"reply"\s*:\s*"((?:\\.|[^"\\])*)/s)
      const reply = match?.[1]?.replace(/\\n/g, ' ').replace(/\\"/g, '"')
        .replace(/\\$/,'').trim().slice(0, 110)
      if (reply) return { reply, focus: 'KEEP', partial: true }
    }
    throw Error(`Qwen JSON parse: ${String(error)}; raw=${raw.slice(0,500)}`)
  }
}
const coachSystem = 'You are one temporary fighter coach for one shared Minecraft 1.21.1 GRU64+GTrXL PPO brain. Frozen historical GRU checkpoints are league opponents and never receive PPO updates. Read the global memory and full bout in chronological order. Select one measurable training goal from FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT; rotate across aggressive pressure, shield counter then horizontal escape, legal edge spacing, native critical entry and its interception, sword combos, shield breaking, bow/crossbow and arrow dodging, without forgetting useful older skills. Minecraft Java 1.21.1 has attack cooldown: diamond axe attack speed 1.0 takes about 20 ticks to charge, diamond sword speed 1.6 about 12.5 ticks. For ordinary melee, charge-dependent base damage rises approximately as 0.2 + 0.8 * charge^2 until charge reaches 1; waiting beyond full charge does not raise that hit further. Each swing resets charge. This is why repeated fast clicks usually waste damage, though a necessary light hit may interrupt, break a shield, or finish. Avoid passive 120-second bouts and invalid weapon selections. Actual food-level loss is a small cost; repeated fast clicks and air swings lose charge. Give credit to native damage in proportion to amount, with extra weight for confirmed criticals and genuine edge-range melee hits, never for a mere pose or distance. Train only with items actually equipped; melee-only bouts have no bow or crossbow. Evaluate attempts by native packets, damage, shield blocks, actual horizontal distance, net exchange, survival and win, not action labels. Defensive play must create an advantage or active escape. Every bout is one causal sequence and failures suggest the next test, not a fixed combo script. Never read hidden opponent input or health. Qwen reviews and assigns goals, not frame-by-frame keys; do not claim Qwen weights changed. Return compact JSON {"focus":"...","style":"...","reason":"specific measurable hypothesis"}.'
const freshCoachSystem = '你是唯一 WaveDog GRU64＋GTrXL＋PPO 主模型的 Qwen 教练。每个分身从同一检查点出发，在 1.21.1 普通玩家规则下只拿钻石剑、钻石斧和护甲，无盾、弓、弩、箭；每局结束轨迹归还同一模型。给本分身一个可测的无盾近战目标，轮换边缘控距、入距暴击、条件惩罚暴击、剑连击、地面 W-tap、被连后撤止损、跳劈打断和高蓄力普通输出。进入合法攻击窗口后必须在窗口内完成一次真实攻击尝试，但不是刚入距就连点：Transformer/GRU 自己选择蓄力、落点和出刀时机，窗口消失前必须行动，不能只转向观察。惩罚暴击必须有条件：对手仍在合法距离、自己处于真实下落窗口并且预计能实际命中时才尝试；对手已经出距或命中窗口消失时，立即改为极限控距、横移和安全脱离，不能为了完成惩罚暴击继续追空挥。高蓄力是倾向，破局、抢救或收尾可轻击。只凭真实发包、原生伤害、距离与胜负判定成功。Qwen 赛后复盘，不控制每帧动作，不声称权重更新。只输出 JSON {"focus":"CRITICAL","style":"AGGRESSIVE","reason":"可测目标"}；focus 从 FREE,CHARGE,CRITICAL,SPRINT_KB,ESCAPE,FLANK,COMBO,WALL,LATENCY,OPPONENT 选，style 从 AGGRESSIVE,DEFENSIVE,FLANK,GROUND_COMBO,MIXED 选。'
const freshTechniqueAgenda = '最高重点：合法三格边界先手疾跑击退，主动打断平 A 起手和跳跃上升期；交权后的第一窗口也要主动争取合法命中，不要只等待惩罚暴击。对手真正挤进近身后，再选择一两格内的惩罚暴击、跑跳暴击和剑连击。熟练掌握多种招式，但不在没必要时乱跳、等暴击或牺牲边界刀。本轮轮换四项可测假设：合法边缘先手打断平地普通刀；先手迎击或短移避开跳劈暴击；自身受击后的真实下落窗口惩罚暴击；贴脸斧暴击后仅在收益补回切武器蓄力损失时切剑连暴。进入攻击窗口后要在窗口内真实出刀，但允许先蓄力、选落点和调整距离，不要求第一帧攻击；禁止窗口内长期眼神对峙直到错失机会。惩罚暴击不是默认动作：若对手已离开合法攻击距离、正在安全脱离，或命中概率不足，立即停止追击，优先极限控距、横移和安全出距；只有真实下落窗口、仍在合法距离且能形成实际命中时才惩罚暴击。距离外接近通常疾跑，只有真实暴击出刀前短暂松疾跑。只凭原生伤害、暴击、相对距离与净换血验收，不能把尝试写成成功。'
const freshReachRule = '只避免合法射程外的无意义空挥。是否在射程内应看玩家眼位到对方碰撞箱，目标中心超过三格仍可能合法命中。合法入距后不必死守极限边缘；GRU 和 Transformer 自选蓄力、瞄准、暴击或普通攻击时机，满蓄力且可命中时不要一直等待。'
const coachMethodology = '总方法论：只有一份在更新的GRU＋GTrXL，当前分身按整局时序逐帧体验并汇总；冻结历史对手只用于联赛检验。轮换激进、盾反后撤、边缘控距、普通暴击与反制、剑连击、弓弩和侧跳等风格，弱项专题练而不遗忘其他打法。Minecraft 1.21.1钻石斧约20tick、钻石剑约12.5tick满蓄力；普通输出偏高蓄力，必要轻击保留，低蓄力连点不能算进步。只用实际装备，以原生命中、伤害交换、真实出距、盾挡、箭伤和胜负验收；历史局或空挥不能冒充成功。'
const cloneReplySchema = { type: 'object', properties: {
  reply: { type: 'string', maxLength: 100 },
  focus: { type: 'string', enum: ['KEEP', ...focusNames] }
}, required: ['reply', 'focus'], additionalProperties: false }
const cloneChatPending = new Set()
function whisperChunks (bot, player, message) {
  const plain = String(message).replace(/[\r\n]+/g, ' ').trim()
  for (let i = 0; i < plain.length; i += 150) bot.whisper(player, plain.slice(i, i + 150))
}
async function answerCloneWhisper (name, player, question) {
  const bot = bots.get(name), session = sessions.get(name)
  if (!bot || !bot.players[player]) return
  if (!session) {
    whisperChunks(bot, player, `[${name}] 这局尚未开始。与总 Qwen 交谈请用 /qwen。`)
    return
  }
  if (!question?.trim() || question.length > 300) return
  if (cloneChatPending.has(name)) {
    whisperChunks(bot, player, `[${name}] 当前分身上一条还在思考。`)
    return
  }
  cloneChatPending.add(name)
  const matchId = session.matchId
  const userTurn = { at: now(), matchId, bot: name, player, role: 'user', text: question }
  session.dialogue.push(userTurn); append(cloneChatPath, userTurn)
  try {
    const answer = await scheduleQwen(() => inferQwen([
      { role: 'system', content: `你是总 Qwen 当前局的 ${name} 临时分身。只回答玩家这一问，用不超过35个汉字；不重复背景和训练清单。GRU 逐帧操控。若玩家明确指定本局训练方向才改变 focus，否则 KEEP。只返回短 JSON：{"reply":"一句话","focus":"KEEP"}。` },
      { role: 'user', content: JSON.stringify({ question, matchId,
        currentClone: { fighter: name, opponent: session.opponent,
          focus: session.focus, style: session.style, goal: session.goal,
          elapsedFrames: session.framesSeen,
          observedWholeBout: wholeBout(name, session.opponent,
            session.frameHistory, session.actionHistory, [], 8) },
        conversationThisBout: session.dialogue.slice(-6),
        sharedBrain: { experience: playerExperience(4), lessons: recentLessons(3),
          recentCompletedBouts: mergedOutcomes.latest(2),
          archivedKnowledge: referenceFor(question, session.focus, 750) } }) }
    ], 100, cloneReplySchema, true), false)
    if (sessions.get(name) !== session) {
      append(cloneChatPath, { matchId, bot: name, player, role: 'late-answer',
        text: String(answer.reply || '').slice(0, 260) })
      whisperChunks(bot, player, `[${name}] 该局已结束，刚才的对话已汇入总记录。`)
      return
    }
    if (typeof answer.reply !== 'string' || !answer.reply.trim()) throw Error('empty clone answer')
    if (answer.focus !== 'KEEP') {
      if (!focusNames.has(answer.focus)) throw Error('invalid clone focus')
      session.focus = answer.focus
      session.goal = question.slice(0, 120)
      const context = contexts.get(name)
      if (context?.matchId === matchId) {
        context.focus = answer.focus; context.goal = session.goal
        append(coachPath, context)
      }
    }
    const reply = { at: now(), matchId, bot: name, player,
      role: 'assistant', text: answer.reply, focus: answer.focus }
    session.dialogue.push(reply); append(cloneChatPath, reply)
    whisperChunks(bot, player, `[${name} Qwen] ${answer.reply}`)
    log('clone_qwen_reply', { matchId, bot: name, player, focus: answer.focus })
  } catch (error) {
    append(qwenErrorsPath, { phase: 'clone-private-chat', matchId, bot: name,
      player, error: String(error) })
    whisperChunks(bot, player, `[${name} Qwen] 本次回答失败；你的话已保存进这局记录。`)
  } finally { cloneChatPending.delete(name) }
}
async function coachFighter (fighter, opponent) {
  const previous = contexts.get(fighter)
  const index = names.indexOf(fighter)
  const suggestedStyle = styleRotation[(Math.floor(index/2)+(index%2))%styleRotation.length]
  try {
    const answer = await scheduleQwen(() => inferQwen([
      { role: 'system', content: freshDual ? freshCoachSystem + freshTechniqueAgenda + freshReachRule : coachSystem + ' Long-term research: learn ordinary native falling criticals and entry criticals from outside reach; defend with effective shield or a legal first hit. Compare axe and sword by native damage over an exchange, especially unanswered sword follow-ups near an unshielded opponent. A falling pose, weapon selection, or missing later critical is not proof. Preserve all prior skills.' },
      { role: 'user', content: JSON.stringify({ fighter, opponent, suggestedStyle,
        previousFocus: previous?.focus || 'FREE', previousStyle: previous?.style || suggestedStyle,
        previousReason: previous?.reason || '', ownRecent: previous?.ownRecent || [],
        chronologicalMemory: orderedMemory(),
        priorityTeaching: fs.existsSync(path.join(store, 'operator-critical-defense.json'))
          ? JSON.parse(fs.readFileSync(path.join(store, 'operator-critical-defense.json'), 'utf8')) : null,
        recentResearchEvidence: researchEvidence(),
        recentValidatedHumanTrials: humanTrials,
        trainingAgenda: freshDual
          ? '纯剑斧局：边缘控距、满程跑跳暴击、惩罚暴击、剑斧换伤、被连后撤止损和连招打断，轮换不同风格；只用真实伤害验收。'
          : '你自主比较相持、缠斗和远距的近期实测缺口，再给本分身一个可测目标。候选包括边缘疾跑原生命中及真实击退、射程外选落点并尽量跑满整次疾跑跳打原生暴击（攻击前松疾跑）、盾反水平出距、剑斧换伤、远距安全装弩、实际发箭和侧跳躲箭。用实际水平行程与原生伤害验收，不把挥刀、起跳或未受伤冒充成功；保留其他风格并在下一局轮换。',
        question: 'What weakness or strength should this fighter test next against this named opponent?' }) }
    ], 160, coachSchema))
    if (!focusNames.has(answer.focus)) throw Error(`Invalid focus ${answer.focus}`)
    const context = { fighter, opponent, focus: answer.focus,
      style: suggestedStyle,
      reason: String(answer.reason || '').slice(0, 160),
      ownRecent: previous?.ownRecent || [], source: 'Qwen2.5-1.5B-Instruct' }
    contexts.set(fighter, context); append(coachPath, context)
    return context
  } catch (error) {
    append(qwenErrorsPath, { phase: 'fighter', fighter, opponent, error: String(error) })
    throw error
  }
}
async function reviewArchivedFrames (report) {
  if (!report.frameArchive?.path) throw Error(`Missing frame archive: ${report.matchId}`)
  const packed = fs.readFileSync(path.join(store, report.frameArchive.path))
  const archiveSha = crypto.createHash('sha256').update(packed).digest('hex')
  if (archiveSha !== report.frameArchive.sha256)
    throw Error(`Frame archive checksum mismatch: ${report.matchId}`)
  const archive = JSON.parse(zlib.gunzipSync(packed).toString('utf8'))
  if (archive.matchId !== report.matchId) throw Error('Frame archive match mismatch')
  const plan = frameChunks(archive, 96)
  const previous = fs.existsSync(frameReviewPath)
    ? fs.readFileSync(frameReviewPath, 'utf8').split(/\r?\n/).flatMap(line => {
      try { return [JSON.parse(line)] } catch { return [] }
    }).filter(row => row.matchId === report.matchId && row.archiveSha === archiveSha)
    : []
  const completed = previous.find(row => row.status === 'complete'
    && row.framesRead === plan.rows && row.chunksRead === plan.chunks.length)
  if (completed) return completed
  let framesRead = 0
  const timeline = []
  for (const chunk of plan.chunks) {
    const evidence = chunkEvidence(chunk)
    const saved = previous.find(row => row.status === 'chunk'
      && row.index === chunk.index && row.sha256 === chunk.sha256)
    framesRead += chunk.rows.length
    timeline.push(evidence)
    if (!saved) append(frameReviewPath, { status: 'chunk', matchId: report.matchId,
      archiveSha, index: chunk.index, sha256: chunk.sha256,
      frames: chunk.rows.length, cumulativeFrames: framesRead, evidence })
  }
  if (framesRead !== plan.rows) throw Error('Frame review coverage mismatch')
  const receipt = { status: 'complete', matchId: report.matchId, archiveSha,
    framesRead, expected: plan.expected, chunksRead: plan.chunks.length, timeline }
  append(frameReviewPath, receipt)
  return receipt
}
async function replayInterruptedFrameReviews () {
  if (!freshDual || !fs.existsSync(roundsPath)) return
  const completed = new Set(fs.existsSync(frameReviewPath)
    ? fs.readFileSync(frameReviewPath, 'utf8').split(/\r?\n/).flatMap(line => {
      try { const row = JSON.parse(line); return row.status === 'complete' ? [row.matchId] : [] }
      catch { return [] }
    }) : [])
  const pending = fs.readFileSync(roundsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { return [JSON.parse(line)] } catch { return [] }
  }).filter(report => report.frameReviewVersion === 1
    && report.training?.length && !report.trainingError && !completed.has(report.matchId))
  for (const report of pending) {
    try {
      const receipt = await reviewArchivedFrames(report)
      log('frame_review_recovered', { matchId: report.matchId,
        framesRead: receipt.framesRead, chunksRead: receipt.chunksRead })
    } catch (error) {
      append(qwenErrorsPath, { phase: 'frame-review-recovery',
        matchId: report.matchId, error: String(error) })
    }
  }
}
async function reviewPair (pair, report) {
  const freshReviewPrompt = '你是唯一 WaveDog 主大脑的 Qwen 赛后教练。两个分身刚完成无盾无远程剑斧对练。frameReview 是程序逐帧扫描原始轨迹后，按时间顺序每 96 帧汇成的实测时间片；它不是原始帧本身。结合时间片与原生计数复盘开局、换血、脱离和收尾，平局也要指出一个可验证的失败原因。普通刀倾向高蓄力，必要轻击保留。下一局从同一共享 GRU＋Transformer 权重出发。不得把挥刀当命中，不得声称 Qwen 权重更新。只输出 JSON，字段 focusA、focusB、lesson；lesson 请写出至少一个本局数字及下局验收目标，不能复制占位词。focus 仅选 FREE,CHARGE,CRITICAL,SPRINT_KB,ESCAPE,FLANK,COMBO,WALL,LATENCY,OPPONENT。'
  const a = contexts.get(pair.a), b = contexts.get(pair.b)
  const both = [a, b]
  for (const context of both) {
    const own = report.fighters[context.fighter]
    context.ownRecent = [...(context.ownRecent || []), { bout: report.bout, opponent: own.opponent,
      win: report.winner === context.fighter, attacks: own.attacks, misses: own.misses,
      rejected: own.rejected, bowChoices: own.bowChoices, crossbowChoices: own.crossbowChoices,
      ammoConsumed: own.ammoConsumed }].slice(-4)
  }
  if (report.reason !== 'death' && !freshDual) return true
  try {
    const frameReview = freshDual ? await reviewArchivedFrames(report) : null
    const measured = { winner: report.winner, reason: report.reason,
      native: report.native ? Object.fromEntries(Object.entries(report.native)
        .filter(([key]) => key !== 'trace')) : null,
      fighters: Object.fromEntries(Object.entries(report.fighters).map(([name, f]) =>
        [name, { attacks: f.attacks, misses: f.misses,
          meanDistance: f.meanDistance, farFraction: f.farFraction,
          meanAttackCharge: f.meanAttackCharge,
          outOfReachAttackChoices: f.outOfReachAttackChoices,
          critWindowAttempts: f.critWindowAttempts }])) }
    const answer = await scheduleQwen(() => inferQwen([
      { role: 'system', content: freshDual ? freshReviewPrompt : 'You are the shared PvP research brain. Two independent fighter contexts return after one native Minecraft 1.21.1 bout. Use the measured winner, attacks, misses and ammunition. Give one concrete, testable lesson grounded in those counts and a next focus for each fighter. Rotate across aggressive pressure versus shield-counter escape, defensive spacing, flanking, ground combos, ranged tempo, charged attacks and necessary light hits. For close combat consider a real axe shield break and jump reset near an observed hit; both need native evidence. Do not repeat a previous lesson, invent special stun frames or hidden inputs, or claim Qwen weights changed. Return only JSON {"focusA":"AXE_BREAK","focusB":"SYNC","lesson":"specific measured hypothesis"}. Valid focus values: FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT.' },
      { role: 'user', content: JSON.stringify({ completedBout: measured, operatorTactics: OPERATOR_TACTICS,
        priorityTeaching: fs.existsSync(path.join(store, 'operator-critical-defense.json'))
          ? JSON.parse(fs.readFileSync(path.join(store, 'operator-critical-defense.json'), 'utf8')) : null,
        frameReview: frameReview && { framesRead: frameReview.framesRead,
          chunksRead: frameReview.chunksRead, chronologicalTimeline: frameReview.timeline },
        playerKnowledge: playerExperience(4),
        sharedRecent: recentLessons(5),
        trainingAgenda: freshDual
          ? freshTechniqueAgenda + freshReachRule
          : '检查控距连招、惩罚暴击、盾反后撤弓弩、斧击破盾、jump reset；只根据本局可见行为和原生伤害结果提出下一次实验。' }) }
    ], freshDual ? 240 : 160, reviewSchema), true)
    if (!focusNames.has(answer.focusA) || !focusNames.has(answer.focusB))
      throw Error(`Invalid shared focus: ${JSON.stringify(answer).slice(0,350)}`)
    const rawLesson = String(answer.lesson || '').trim()
    const placeholder = freshDual && (rawLesson === '可检验的一句话'
      || rawLesson.length < 12 || !/\d/.test(rawLesson.replace(/NBot\d+/g, ''))
      || /盾反|挡刀|举盾|破盾|弓|弩|箭/.test(rawLesson))
    const first = report.fighters[pair.a], second = report.fighters[pair.b]
    const lesson = placeholder
      ? `本局原生命中${report.native?.meleeHits || 0}、${pair.a}挥空${first.misses}、${pair.b}挥空${second.misses}；下局降低远距空挥并争取合法射程命中。`
      : rawLesson.slice(0, 220)
    if (placeholder) log('shared_qwen_placeholder', { arena: pair.arena,
      bout: pair.bout, answer: rawLesson })
    const row = { at: now(), matchId: reviewKey(report),
      arena: pair.arena, bout: pair.bout, fighters: [pair.a, pair.b],
      focusA: answer.focusA, focusB: answer.focusB, lesson,
      focus: answer.focusA,
      lessonSource: placeholder ? 'measured-fallback-after-Qwen' : 'measured-after-Qwen',
      source: placeholder ? 'native-count-fallback' : 'Qwen2.5-1.5B-Instruct' }
    sharedLessons.push(row); append(sharedLessonsPath, row)
    for (const [context, focus] of [[a, answer.focusA], [b, answer.focusB]]) {
      context.focus = focus; context.reason = lesson
      append(coachPath, context)
    }
    log('shared_qwen_review', { arena: pair.arena, bout: pair.bout, focusA: a.focus, focusB: b.focus, lesson })
    return true
  } catch (error) {
    append(qwenErrorsPath, { phase: 'shared_review', arena: pair.arena, bout: pair.bout, error: String(error) })
    log('shared_qwen_error', { arena: pair.arena, bout: pair.bout, error: String(error) })
    return false
  }
}
function launchPairReview (pair, report) {
  // Qwen is a post-bout coach. It must never hold an arena open or delay the
  // next PPO rollout. reviewPair captures its contexts before sessions clear.
  ;(async () => {
    for (let attempt = 0; attempt < 3 && !stopping; attempt++) {
      if (await reviewPair(pair, report)) return
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 10000))
    }
    log('shared_qwen_review_deferred', { arena: pair.arena, bout: pair.bout })
  })().catch(error => log('shared_qwen_review_background_error', {
    arena: pair.arena, bout: pair.bout, error: String(error)
  }))
}
async function replayMissingReviews () {
  if (!fs.existsSync(roundsPath)) return
  const oldRounds = fs.readFileSync(roundsPath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  const missing = oldRounds.filter(report => report.trainingMode !== 'single-lane'
    && report.training?.length && !report.trainingError
    && !invalidMatchIds.has(reviewKey(report)) && !reviewedKeys.has(reviewKey(report)))
  // Keep old work durable and separate so current learning is not stuck behind it.
  historicalRoundBacklog.push(...missing)
  for (const report of missing) queuedReviews.add(reviewKey(report))
  flushReviewBatches()
  log('review_recovery', { pending: pendingReviews.length,
    historicalBacklog: historicalRoundBacklog.length, reviewed: reviewedKeys.size })
}
function replayMissingHumanReviews () {
  if (!fs.existsSync(challengesPath)) return
  const reports = fs.readFileSync(challengesPath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  const missing = reports.filter(report => !invalidMatchIds.has(reviewKey(report))
    && !humanReviewedKeys.has(reviewKey(report))).reverse()
  historicalHumanBacklog.push(...missing.slice(2))
  for (const report of missing.slice(0,2)) reviewHumanChallenge(report,true)
  log('human_review_recovery', { total: reports.length, reviewed: humanReviewedKeys.size,
    queued: humanQueuedReviews.size, historicalBacklog: historicalHumanBacklog.length })
}
setInterval(() => {
  if (pairs.size || activeChallenge || qwenActive || qwenQueue.length
      || batchReviewsActive) return
  if (historicalHumanBacklog.length) reviewHumanChallenge(historicalHumanBacklog.shift(),true)
}, 60000)
function enqueueReview (report) {
  const key = reviewKey(report)
  if (!report.training?.length || report.trainingError || invalidMatchIds.has(key)
      || reviewedKeys.has(key) || queuedReviews.has(key)) return
  queuedReviews.add(key); pendingReviews.push(report)
  if (pendingReviews.length >= REVIEW_BATCH_SIZE) flushReviewBatches()
}
function compactReviewBout (report) {
  const fighters = Object.entries(report.fighters).map(([name, fighter]) => {
    const whole = report.wholeBouts?.[name]
    const stages = Object.values(whole?.stageTotals || {})
    const netDamage = stages.reduce((sum, stage) => sum
      + Number(stage.dealt || 0) - Number(stage.received || 0), 0)
    const phases = whole?.phases || []
    const step = Math.max(1, Math.ceil(phases.length / 5))
    const phasePath = phases.filter((_, index) =>
      index === 0 || index === phases.length - 1 || index % step === 0)
      .slice(0, 6).map(p => [p[0], p[2], p[5], p[14], p[15], p[16], p[18], p[21]])
    return [name, fighter.leagueRole || 'current', fighter.focus, fighter.goalStage || '',
      String(fighter.goal || '').slice(0, 18), +netDamage.toFixed(1), phasePath]
  })
  const n = report.native
  const native = n ? [n.meleeHits, n.shieldBreaks,
    n.arrowLaunches, n.arrowHits,
    n.chargedMeleeHits ?? null, n.lightMeleeHits ?? null] : null
  const keys = ['blockedMelee','counterHits','counterEscapes','edgeHits',
    'nativeCriticalHits','longRunJumpEntries','longRunJumpCriticalHits',
    'lostExchanges','swordFollowupHits']
  const tactics = keys.map(key => Object.values(report.tactics || {})
    .reduce((sum, row) => sum + Number(row[key] || 0), 0))
  return [report.at, report.winner, fighters, native, tactics]
}
function aggregateReviewStages (batch) {
  return ['STANDOFF','MELEE','RANGED'].map(stage => {
    const sum = { frames: 0, meleeHits: 0, blocked: 0,
      arrowsOut: 0, dealt: 0, received: 0 }
    for (const report of batch) for (const whole of Object.values(report.wholeBouts || {})) {
      const row = whole?.stageTotals?.[stage] || {}
      for (const key of Object.keys(sum)) sum[key] += Number(row[key] || 0)
    }
    return [stage, sum.frames, sum.meleeHits, sum.blocked, sum.arrowsOut,
      +sum.dealt.toFixed(1), +sum.received.toFixed(1)]
  })
}
function deepReviewCase (batch) {
  const report = [...batch].sort((a,b) => {
    const score = row => (row.native?.shieldBreaks || 0)
      + Object.values(row.tactics || {}).reduce((n,t) => n
        + (t.counterPunished || 0)*3 + (t.counterProgress || 0)*2
        + (t.edgeCounterEscapes || 0)*4,0)
    return score(b)-score(a)
  })[0]
  if (!report) return null
  const phases = Object.entries(report.wholeBouts || {}).map(([name, summary]) =>
    [name, (summary.phases || []).slice(0,8).map(p =>
      [p[0], p[2], p[3], p[5], p[14], p[15], p[21]])])
  return { matchId: reviewKey(report), phases,
    stageTransitions: Object.entries(report.wholeBouts || {}).map(([name, summary]) =>
      [name, (summary.stageTransitions || []).slice(0, 12)]),
    nativeEvents: (report.native?.trace || []).filter(event =>
      event[4] === 'shield_disable' || event[4] === 'arrow_launch'
      || (event[4] === 'damage' && Number(event[8]) > 0)).slice(0, 8) }
}
function flushReviewBatches (force = false) {
  if (Date.now() < reviewRetryAfter) return
  while (batchReviewsActive < 1 && (pendingReviews.length || historicalRoundBacklog.length)) {
    const choice = takeBatch(pendingReviews, historicalRoundBacklog,
      reviewBatchLimit, force, reviewHistoricalTurn)
    if (!choice) return
    const { batch, source } = choice
    reviewHistoricalTurn = choice.nextHistoricalTurn
    batchReviewsActive++
    const bouts = batch.map(compactReviewBout)
    const timeline = mergeTimeline(orderedMemory().slice(-4), bouts, [])
    const researchChoices = researchFocusChoices()
    scheduleQwen(() => inferQwen([
      { role: 'system', content: '你是总 Qwen 赛后教练。B=[时间,胜者,双方,原生,战术]；每人=[名字,角色,focus,计划阶段,本局目标,净伤,时间片段]。角色为current才参与PPO更新，history角色均只作冻结对手。时间片段逐局按时序=[秒,最近距离,末血,伤敌,受伤,发箭,挡刀,主阶段]。原生=[命中,破盾,发箭,箭伤]；战术=[挡刀,盾反命中,安全出距,边缘命中,原生暴击,满程跑跳次数,其中原生暴击,换血亏次数,剑后续命中]。stageTotals 每阶段=[阶段,观察帧,原生近战命中,挡刀,发箭,伤敌,受伤]，顺序相持、缠斗、远距。deepCase 有代表局更细的阶段和原生事件。M 是经验，E 是原生事件。每局都要看开局、换血、出距和收尾，判断目标是否由原生结果验证；不要把起跳或挥刀当成命中。满程跑跳是射程外疾跑起跳且实际水平行程至少2.4格，只有原生暴击才算暴击命中。保留流派多样性；旧局缺字段只说未知。仅返回JSON {"focus":"...","lesson":"..."}，lesson不超过35字。' + coachMethodology },
      { role: 'system', content: '本批原生数组新增第5、6项：蓄力≥0.85的近战命中和低蓄力命中；旧记录缺项时为null。请比较真实命中、伤害效率与风险。Java 1.21.1钻石斧约20 tick、剑约12.5 tick满蓄力。普通刀优先高蓄力，必要破盾、抢救或收尾可轻击；连续低蓄力命中不能当成高质量输出。' },
      { role: 'user', content: JSON.stringify({ globalTimeline: timeline.map(row =>
        row.kind === 'memory' ? ['M',row.at,row.source,row.text]
          : row.kind === 'native_event' ? ['E',row.at,row.matchId,row.sequence,...row.event]
            : ['B',...row.bout]),
        deepCase: deepReviewCase(batch),
        stageTotals: aggregateReviewStages(batch),
        archivedKnowledge: referenceFor('', researchChoices[0], 120),
        question: '比较开局、中段、末段及真实胜负，给下一批一个可测实验。' }) }
    ], 120, { ...batchReviewSchema, properties: {
      ...batchReviewSchema.properties, focus: { type: 'string', enum: researchChoices }
    } }), false).then(answer => {
      if (!researchChoices.includes(answer.focus)
          || typeof answer.lesson !== 'string' || !answer.lesson.trim())
        throw Error('Invalid Qwen batch review')
      const counts = batch.reduce((n, report) => {
        for (const x of Object.values(report.fighters)) {
          n.attackPackets += x.attacks || 0; n.crosshairMisses += x.misses || 0
          n.ranged += (x.bowChoices || 0) + (x.crossbowChoices || 0)
          n.arrows += x.ammoConsumed || 0
        }
        if (report.native) {
          n.nativeBouts++
          n.meleeHits += report.native.meleeHits
          if (Number.isFinite(report.native.chargedMeleeHits)
              && Number.isFinite(report.native.lightMeleeHits)) {
            n.chargeMeasuredBouts++
            n.chargedMeleeHits += report.native.chargedMeleeHits
            n.lightMeleeHits += report.native.lightMeleeHits
          }
          n.shieldBreaks += report.native.shieldBreaks
          n.breakFollowupHits += report.native.breakFollowupHits
          n.arrowLaunches += report.native.arrowLaunches
          n.arrowHits += report.native.arrowHits
        }
        if (Object.values(report.tactics || {}).some(t => Number.isInteger(t?.edgeCounterEscapes))) {
          n.tacticBouts++
          for (const t of Object.values(report.tactics)) {
            n.blockedMelee += t.blockedMelee || 0
            n.counterHits += t.counterHits || 0
            n.counterProgress += t.counterProgress || 0
            n.counterPunished += t.counterPunished || 0
            n.counterEscapes += t.counterEscapes || 0
            n.edgeCounterEscapes += t.edgeCounterEscapes || 0
            n.counterEscapeArrows += t.counterEscapeArrows || 0
            n.edgeCounterPunished += t.edgeCounterPunished || 0
            n.rangedExchange += t.rangedExchange || 0
            n.nativeCriticalHits += t.nativeCriticalHits || 0
            n.jumpInCriticalHits += t.jumpInCriticalHits || 0
            n.longRunJumpEntries += t.longRunJumpEntries || 0
            n.longRunJumpCriticalHits += t.longRunJumpCriticalHits || 0
            n.nativeCriticalShieldBlocks += t.nativeCriticalShieldBlocks || 0
            n.fallingThreatFirstHits += t.fallingThreatFirstHits || 0
            n.shieldedCriticalEligibleAttacks += t.shieldedCriticalEligibleAttacks || 0
            n.unansweredFollowupHits += t.unansweredFollowupHits || 0
            n.swordFollowupHits += t.swordFollowupHits || 0
            n.axeIntoSwordLosses += t.axeIntoSwordLosses || 0
            n.swordIntoAxeWins += t.swordIntoAxeWins || 0
          }
        }
        return n
      }, { attackPackets: 0, crosshairMisses: 0, ranged: 0, arrows: 0,
        nativeBouts: 0, meleeHits: 0, chargeMeasuredBouts: 0,
        chargedMeleeHits: 0, lightMeleeHits: 0,
        shieldBreaks: 0, breakFollowupHits: 0,
        arrowLaunches: 0, arrowHits: 0, tacticBouts: 0,
        blockedMelee: 0, counterHits: 0, counterProgress: 0,
        counterPunished: 0, counterEscapes: 0,
        edgeCounterEscapes: 0, counterEscapeArrows: 0,
        edgeCounterPunished: 0, rangedExchange: 0,
        nativeCriticalHits: 0, jumpInCriticalHits: 0,
        longRunJumpEntries: 0, longRunJumpCriticalHits: 0,
        nativeCriticalShieldBlocks: 0, fallingThreatFirstHits: 0,
        shieldedCriticalEligibleAttacks: 0, unansweredFollowupHits: 0,
        swordFollowupHits: 0, axeIntoSwordLosses: 0, swordIntoAxeWins: 0 })
      const suggested = answer.lesson.trim().slice(0,90)
      const measured = counts.nativeBouts
        ? `原生${counts.nativeBouts}局：命中${counts.meleeHits}${counts.chargeMeasuredBouts ? `（其中${counts.chargeMeasuredBouts}局高蓄力${counts.chargedMeleeHits}、轻击${counts.lightMeleeHits}）` : ''}、破盾${counts.shieldBreaks}后5秒跟进${counts.breakFollowupHits}、发箭${counts.arrowLaunches}命中${counts.arrowHits}`
        : `样本${batch.length}局仅有客户端选择计数，尚无可归属的原生战术事件`
      const tactical = counts.tacticBouts
        ? `；战术${counts.tacticBouts}局挡刀${counts.blockedMelee}、盾反命中${counts.counterHits}、拉距进展${counts.counterProgress}、反击被追打${counts.counterPunished}、安全出距${counts.counterEscapes}、边缘盾反出距${counts.edgeCounterEscapes}、原生暴击${counts.nativeCriticalHits}、跳入暴击${counts.jumpInCriticalHits}、满程跑跳${counts.longRunJumpEntries}次其中暴击${counts.longRunJumpCriticalHits}、盾挡下落刀${counts.shieldedCriticalEligibleAttacks}、先手迎击${counts.fallingThreatFirstHits}、剑后续命中${counts.swordFollowupHits}、斧对剑亏损${counts.axeIntoSwordLosses}`
        : '；旧局无新战术观测'
      const lesson = `${measured}${tactical}；待测${answer.focus}`
      for (const report of batch) {
        const key = reviewKey(report)
        const row = { at: now(), boutAt: report.at, arena: report.arena, bout: report.bout,
          matchId: key,
          fighters: Object.keys(report.fighters), focus: answer.focus, lesson,
          batchSize: batch.length, nativeCounts: counts, qwenSuggestion: suggested,
          lessonSource: 'measured-after-Qwen',
          source: 'Qwen2.5-1.5B-Instruct-batch' }
        sharedLessons.push(row); append(sharedLessonsPath, row)
        reviewedKeys.add(key); queuedReviews.delete(key)
      }
      log('shared_qwen_batch', { count: batch.length, focus: answer.focus, lesson, nativeCounts: counts })
    }).catch(error => {
      append(qwenErrorsPath, { phase: 'shared_batch', bouts: batch.map(x => `${x.arena}:${x.bout}`), error: String(error) })
      source.unshift(...batch)
      if (String(error).includes('Qwen HTTP 400') && batch.length > 1)
        reviewBatchLimit = Math.max(1, Math.floor(batch.length/2))
      reviewRetryAfter = Date.now() + (batch.length === 1 ? 60000 : 10000)
      log('shared_qwen_batch_error', { count: batch.length, error: String(error) })
      setTimeout(flushReviewBatches, 10000)
    }).finally(() => { batchReviewsActive--; flushReviewBatches() })
  }
}
setInterval(() => flushReviewBatches(true), 60000)

async function reviewSingleLaneCycle () {
  const { cycle, completed } = laneState.value
  if (completed.length !== arenaCount) return
  const matchId = `single-lane-cycle:${cycle}`
  if (sharedLessons.some(row => row.matchId === matchId)) {
    laneState.reviewed(); return
  }
  const evidence = completed.map(row => ({
    matchId: row.matchId, arena: row.arena, winner: row.winner,
    reason: row.reason, fighters: row.fighters, tactics: row.tactics,
    native: row.native ? {
      meleeHits: row.native.meleeHits,
      chargedMeleeHits: row.native.chargedMeleeHits,
      lightMeleeHits: row.native.lightMeleeHits,
      shieldBreaks: row.native.shieldBreaks,
      nativeCriticalHits: row.native.nativeCriticalHits,
      arrowLaunches: row.native.arrowLaunches,
      arrowHits: row.native.arrowHits
    } : null
  }))
  while (!stopping) {
    try {
      const answer = await scheduleQwen(() => inferQwen([
        { role: 'system', content: `你是唯一共享 PvP 大脑的赛后教练。按顺序复盘本轮 ${arenaCount} 局，冻结历史 GRU 只作对手。依据原生伤害、破盾、暴击、蓄力、空挥、净换血及胜负，选下一轮一个可测重点；保持激进、盾反后撤、控距、jump reset、剑连击与远距反制的多样性。不能把动作标签当成功。仅返回 JSON {"focus":"CHARGE","lesson":"具体短句"}。` },
        { role: 'user', content: JSON.stringify({ cycle, bouts: evidence,
          playerKnowledge: playerExperience(4),
          question: '这十场共同暴露了什么弱项？下一轮十场如何轮换测试并保留有用旧招？' }) }
      ], 160, batchReviewSchema), true)
      if (!focusNames.has(answer.focus) || !answer.lesson?.trim())
        throw Error('Invalid ten-bout Qwen review')
      const row = { at: now(), boutAt: completed.at(-1).at, matchId,
        cycle, bouts: completed.map(item => item.matchId),
        focus: answer.focus, lesson: String(answer.lesson).trim().slice(0, 90),
        qwenSuggestion: String(answer.lesson).trim().slice(0, 90),
        lessonSource: 'measured-after-Qwen',
        source: 'single-lane-ten-bout-Qwen' }
      sharedLessons.push(row); append(sharedLessonsPath, row)
      laneState.reviewed()
      log('single_lane_review', { cycle, focus: row.focus, lesson: row.lesson })
      return
    } catch (error) {
      append(qwenErrorsPath, { phase: 'single_lane_cycle', cycle, error: String(error) })
      log('single_lane_review_retry', { cycle, error: String(error) })
      await new Promise(resolve => setTimeout(resolve, 30000))
    }
  }
}

function startBridge () {
  if (freshDual) {
    bridge = childProcess.spawn(process.execPath,
      [path.join(base, 'fresh-tcp-stdio.js')],
      { cwd: base, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  } else if (process.env.WAVEDOG_DUAL_BRAIN === '1') {
    const dualCheckpoint = path.join(base, '..', 'pvp-dual-brain',
      'models', 'live', 'checkpoint.json')
    bridge = childProcess.spawn(process.execPath,
      [path.join(base, '..', 'pvp-dual-brain', 'dual-bridge.js'), dualCheckpoint],
      { cwd: base, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  } else {
  const cp = [path.join(base, 'bridge-classes'), path.join(base, '..', 'pvp-neural-lab', 'classes'),
    path.join(server, 'versions', '1.21.1', 'paper-1.21.1.jar'),
    path.join(server, 'libraries', 'com', 'google', 'code', 'gson', 'gson', '2.10.1', 'gson-2.10.1.jar')].join(path.delimiter)
  bridge = childProcess.spawn(path.join(server, 'runtime', 'java21', 'bin', 'java.exe'),
    ['-cp', cp, 'local.wavedog.lab.ProtocolPlayerBridge', checkpoint],
    { cwd: base, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  }
  bridge.stdout.on('data', chunk => {
    bridgeBuffer += chunk.toString('utf8')
    for (let at; (at = bridgeBuffer.indexOf('\n')) >= 0;) {
      const line = bridgeBuffer.slice(0, at).trim(); bridgeBuffer = bridgeBuffer.slice(at + 1)
      if (!line) continue
      try { handleBridge(JSON.parse(line)) } catch (error) { log('bridge_parse_error', { error: String(error) }) }
    }
  })
  bridge.stderr.on('data', chunk => log('bridge_stderr', { message: chunk.toString('utf8').slice(0, 300) }))
  bridge.on('exit', code => { bridgeReady = false; fs.rmSync(readyFile, { force: true }); log('bridge_exit', { code }) })
}
function handleBridge (result) {
  if (result.event === 'ready') { bridgeReady = true; log('gru_ready', result); return }
  if (result.model === 'GRU64-PPO' || result.model === 'DUAL-GRU-GTRXL') {
    const session = sessions.get(result.fighter)
    if (session && session.opponent === result.opponent && session.pendingId === result.requestId) {
      session.pendingId = null
      const beforeAttacks = session.attacks, beforeMisses = session.misses
      const beforeSwitches = session.weaponSwitches || 0
      const beforeOutOfReach = session.outOfReachAttackChoices || 0
      const ignoredHeads = applyDecision(session, result)
      session.modelResponses++
      {
        const bot = bots.get(session.name)
        const actionRow = { at: now(), matchId: session.kind === 'human-challenge'
          ? `${serverRunId}:challenge:${session.bout}` : `${serverRunId}:${session.arena}:${session.bout}`,
          kind: 'action', fighter: session.name, opponent: session.opponent,
          frame: session.clientFrame, decidedFrame: result.decidedTick,
          requestId: result.requestId,
          selected: { forward: result.forward, side: result.side,
            sprint: result.sprint, jump: result.jump, sneak: result.sneak,
            shield: result.shield, attack: result.attack, slot: result.slot,
            use: result.use, release: result.release }, ignoredHeads,
          executed: { forward: bot.getControlState('forward'),
            back: bot.getControlState('back'), left: bot.getControlState('left'),
            right: bot.getControlState('right'), sprint: bot.getControlState('sprint'),
            jump: bot.getControlState('jump'), sneak: bot.getControlState('sneak'),
            mainSlot: bot.quickBarSlot, offhand: bot.inventory.slots[45]?.name || '',
            using: bot.usingHeldItem, retreatRunJump: session.retreatRunJump,
            weaponSwitched: (session.weaponSwitches || 0) > beforeSwitches,
            switchChargeBefore: (session.weaponSwitches || 0) > beforeSwitches
              ? session.lastWeaponSwitchCharge : null,
            attackPackets: session.attacks-beforeAttacks,
            swingWithoutTarget: session.misses-beforeMisses,
            outOfReachAttackChoices: session.outOfReachAttackChoices-beforeOutOfReach,
            attackCharge: session.attacks > beforeAttacks || session.misses > beforeMisses
              ? session.lastAttackCharge : null,
            attackDistance: session.attacks > beforeAttacks
              ? session.lastAttackDistance : null,
            attackReach: session.attacks > beforeAttacks
              ? session.lastAttackReach : null,
            attackRadialVelocity: session.attacks > beforeAttacks
              ? session.lastAttackRadialVelocity : null } }
        if (session.kind === 'human-challenge') append(humanFramesPath, actionRow)
        session.actionHistory.push(actionRow)
        const publicFrame = [...session.frameHistory].reverse()
          .find(row => row.frame === actionRow.frame)
        if (session.leagueRole === 'current'
            && chargedOpportunity(publicFrame, actionRow,
              session.lastOpportunityPenaltyAt || 0)) {
          session.lastOpportunityPenaltyAt = Date.parse(actionRow.at)
          session.missedChargeOpportunities++
          sendBridge({ command: 'native_step', fighter: result.fighter,
            decidedTick: result.decidedTick, reward: -.012 })
        }
        if (actionRow.executed.attackPackets || actionRow.executed.swingWithoutTarget) {
          // Every executed click resets charge, including a visible air swing.
          // Damage may still outweigh this cost when a light hit is useful.
          sendBridge({ command: 'native_step', fighter: result.fighter,
            decidedTick: result.decidedTick,
            reward: swingFeedback(session.lastAttackCharge,
              actionRow.executed.attackPackets > 0) })
        }
        if (actionRow.executed.outOfReachAttackChoices) {
          // The model chose an impossible melee swing. Keep the attack head
          // trainable, but do not send a swing or reset native attack charge.
          sendBridge({ command: 'native_step', fighter: result.fighter,
            decidedTick: result.decidedTick,
            reward: -.018 * actionRow.executed.outOfReachAttackChoices })
        }
        if (actionRow.executed.weaponSwitched) {
          const charge = actionRow.executed.switchChargeBefore || 0
          sendBridge({ command: 'native_step', fighter: result.fighter,
            decidedTick: result.decidedTick,
            reward: -.006 - .024 * charge * charge })
        }
      }
      sendBridge({ command: 'executed', fighter: result.fighter,
        decidedTick: result.decidedTick, ignoredHeads })
    } else if (session && session.opponent === result.opponent) {
      // A timed-out decision was never executed. Exclude all its heads from PPO.
      sendBridge({ command: 'executed', fighter: result.fighter,
        decidedTick: result.decidedTick, ignoredHeads: [0,1,2,3,4,5,6,7,8] })
    }
    return
  }
  if (result.event === 'trained' || result.event === 'trained_partial'
      || result.event === 'history_finished') {
    const waiter = finishWaiters.get(result.fighter)
    if (waiter && waiter.round === result.round) {
      finishWaiters.delete(result.fighter); waiter.resolve(result)
    } else if (waiter) log('late_training_receipt', { fighter: result.fighter,
      expectedRound: waiter.round, receivedRound: result.round })
    append(path.join(store, 'training.jsonl'), result)
    // The bridge emits this only after PPO+Adam has saved the shared
    // checkpoint.  Record and print the merge so each temporary clone and
    // the shared main brain have an unambiguous success notification.
    if (result.event === 'trained' || result.event === 'trained_partial')
      notifySharedBrainMerge(result)
    return
  }
  if (result.event === 'training_error') {
    const waiter = finishWaiters.get(result.fighter)
    if (waiter && waiter.round === result.round) {
      finishWaiters.delete(result.fighter); waiter.reject(Error(result.error))
    }
    append(path.join(store, 'training.jsonl'), result)
    log('trainer_error', { fighter: result.fighter, round: result.round,
      error: result.error })
    return
  }
  if (result.event === 'error') log('gru_error', result)
}
function finishFighter (session, winner) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { finishWaiters.delete(session.name); reject(Error('PPO finish timeout')) }, TRAINING_WAIT_MS)
    finishWaiters.set(session.name, { round: session.bout,
      resolve: value => { clearTimeout(timeout); resolve(value) },
      reject: error => { clearTimeout(timeout); reject(error) } })
    sendBridge({ command: 'finish', fighter: session.name, round: session.bout,
      matchId: session.matchId,
      win: winner === session.name, health: winner === session.name ? Math.max(0, session.lastHealth) : 0 })
  })
}
function partialFighter (session) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { finishWaiters.delete(session.name); reject(Error('PPO partial timeout')) }, TRAINING_WAIT_MS)
    finishWaiters.set(session.name, { round: session.bout,
      resolve: value => { clearTimeout(timeout); resolve(value) },
      reject: error => { clearTimeout(timeout); reject(error) } })
    sendBridge({ command: 'partial', fighter: session.name, round: session.bout,
      matchId: session.matchId })
  })
}
function slotFor (bot) { return bot.quickBarSlot }
function shieldEquipped (bot) {
  return bot.inventory.slots[45]?.name === 'shield'
    || bot.inventory.items().some(item => item.name === 'shield')
}
function crossbowLoaded (bot) {
  const crossbow = bot.inventory.slots[45]?.name === 'crossbow'
    ? bot.inventory.slots[45] : bot.inventory.slots[40]
  if (crossbow?.name !== 'crossbow') return false
  const data = crossbow.componentMap?.get('charged_projectiles')?.data
  const projectiles = Array.isArray(data) ? data : data?.projectiles
  return Array.isArray(projectiles) && projectiles.some(item => (item?.itemCount ?? item?.count ?? 0) > 0)
}
function requestOffhand (session, bot, wanted) {
  if (bot.inventory.slots[45]?.name === wanted) return true
  if (session.offhandSwapPending) return false
  const item = bot.inventory.slots.find((entry, index) =>
    index >= 9 && index <= 44 && entry?.name === wanted)
  if (!item) { log('offhand_item_missing', { fighter: session.name, wanted }); return false }
  if (bot.usingHeldItem) stopUse(session, bot)
  session.offhandSwapAttempts++
  session.offhandSwapPending = wanted
  session.offhandSwapPromise = bot.equip(item, 'off-hand').then(() => {
    if (bot.inventory.slots[45]?.name !== wanted) {
      session.offhandSwapErrors++
      log('offhand_swap_unconfirmed', { fighter: session.name, wanted,
        actual: bot.inventory.slots[45]?.name || 'empty' })
    } else session.offhandSwapConfirmed++
  }).catch(error => { session.offhandSwapErrors++
    log('offhand_swap_error', { fighter: session.name,
      wanted, error: String(error) }) }).finally(() => {
      session.offhandSwapPending = null; session.offhandSwapPromise = null
    })
  return false
}
function stopUse (session, bot) {
  if (bot.usingHeldItem) bot.deactivateItem()
  else if (session.activeUseHand) {
    // Mineflayer can clear its local use flag before the server observes a
    // release. Send the ordinary client release packet for the logical use.
    bot._client.write('block_dig', { status: 5,
      location: new Vec3(0,0,0), face: 0, sequence: 0 })
  }
  session.activeUseHand = null
  session.activeUseSlot = null
}
function opponentUseState (entity) {
  // Living-entity hand flags and equipment are ordinary client-visible packets.
  const flags = Number(entity.metadata?.[8] || 0)
  const using = Boolean(flags & 1)
  const offhand = Boolean(flags & 2)
  const active = entity.equipment?.[offhand ? 1 : 0]
  return { using, shielding: using && active?.name === 'shield',
    activeItem: active?.name || '' }
}
const opponentShieldRaisedAt = new Map()
function observedEffectiveShield (entity) {
  const state = opponentUseState(entity)
  if (!state.shielding) { opponentShieldRaisedAt.delete(entity.id); return false }
  if (!opponentShieldRaisedAt.has(entity.id)) opponentShieldRaisedAt.set(entity.id, Date.now())
  return Date.now()-opponentShieldRaisedAt.get(entity.id) >= 250
}
function opponentShieldFacing (bot, target) {
  if (!observedEffectiveShield(target)) return false
  const dx = bot.entity.position.x-target.position.x
  const dz = bot.entity.position.z-target.position.z
  const distance = Math.max(.01,Math.hypot(dx,dz))
  return (-Math.sin(target.yaw)*dx-Math.cos(target.yaw)*dz)/distance > 0
}
function ownAttackCharge (session, slot, time = Date.now()) {
  return Math.min(1, (time-session.lastSwing)/(slot === 0 ? 625 : 1000))
}
function installVanillaUseMovement (bot) {
  const simulate = bot.physics.simulatePlayer.bind(bot.physics)
  bot.physics.simulatePlayer = (state, world) => {
    if (bot.usingHeldItem) {
      state.control = { ...state.control,
        forward: Number(state.control.forward)*.2, back: Number(state.control.back)*.2,
        left: Number(state.control.left)*.2, right: Number(state.control.right)*.2,
        sprint: false }
    }
    return simulate(state, world)
  }
  const setControl = bot.setControlState.bind(bot)
  bot.setControlState = (control, enabled) => {
    if (control === 'sprint' && enabled && bot.usingHeldItem) return
    setControl(control, enabled)
  }
}
function targetUnderCrosshair (bot, target) {
  const reach = 3.0
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight, 0)
  const yaw = bot.entity.yaw, pitch = bot.entity.pitch
  const direction = new Vec3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch))
  const block = bot.world.raycast(eye, direction, reach)
  const iterator = new RaycastIterator(eye, direction, Math.min(reach, block ? eye.distanceTo(block.intersect) : reach))
  let picked = null, distance = reach
  for (const entity of Object.values(bot.entities)) {
    if (entity.id === bot.entity.id || !entity.position || !entity.width || !entity.height) continue
    if (entity.position.distanceTo(bot.entity.position) > reach + entity.width) continue
    const half = entity.width / 2
    const hit = iterator.intersect([[-half, 0, -half, half, entity.height, half]], entity.position)
    if (hit && eye.distanceTo(hit.pos) < distance) { picked = entity; distance = eye.distanceTo(hit.pos) }
  }
  return picked?.id === target.id
}
function aimAtVisibleOpponent (bot, target, rangedSlot = null, drawMs = 0,
  observedVelocity = target.velocity) {
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight - (rangedSlot ? .1 : 0), 0)
  const point = rangedSlot ? target.position.offset(0, Math.min(1.3, target.height * 0.7), 0)
    : nearestHitPoint(eye,target)
  const distance = Math.hypot(point.x-eye.x, point.z-eye.z)
  const speed = rangedSlot === 1
    ? bowSpeed(Math.max(drawMs, plannedBowDrawMs(distance))) : rangedSlot === 4 ? 3.15 : 0
  const airborne = target.position.y > 221.12
    || Math.abs(observedVelocity?.y || 0) > .08
  const aim = rangedSlot ? leadTarget(eye, point, observedVelocity, speed,
    { airborne, floorY: 221 + Math.min(1.3, target.height * .7) }) : point
  const dx = aim.x-eye.x, dy = aim.y-eye.y, dz = aim.z-eye.z
  const horizontal = Math.hypot(dx,dz)
  const yaw = Math.atan2(-dx, -dz)
  const pitch = rangedSlot ? solvePitch(horizontal, dy, speed) : Math.atan2(dy, horizontal)
  const delta = Math.atan2(Math.sin(yaw-bot.entity.yaw), Math.cos(yaw-bot.entity.yaw))
  immediateLook(bot,yaw,pitch)
  return Math.abs(delta)*180/Math.PI
}
function applyDecision (session, decision) {
  const bot = bots.get(session.name), target = bot.players[session.opponent]?.entity
  if (!bot.entity || !target) return [0,1,2,3,4,5,6,7,8]
  const ignoredHeads = [6,7] // Camera is directly aimed at the public target.
  session.decisions++
  if (bot.health < 6) {
    session.lowHealthDecisions++
    if (decision.attack) session.lowHealthAttackChoices++
    if (decision.shield) session.lowHealthShieldChoices++
    if (decision.use && [1,4].includes(Number(decision.slot))) session.lowHealthRangedChoices++
    if (Number(decision.forward) > .5) session.lowHealthAdvanceChoices++
    if (Number(decision.forward) < -.5) session.lowHealthRetreatChoices++
  }
  const slot = Number(decision.slot)
  const range = bot.entity.position.distanceTo(target.position)
  const useMs = Date.now() - session.useStarted
  if (session.activeUseHand === 'off' && session.activeUseSlot === -1
      && (!decision.shield || Date.now() < session.shieldDisabledUntil))
    stopUse(session, bot)
  const rangedSlot = session.activeUseHand === 'off' && [1,4].includes(session.activeUseSlot)
    ? session.activeUseSlot : decision.use && [1,4].includes(slot) ? slot : null
  // A normal client can turn its camera directly toward a visible opponent.
  // The named opponent is a public entity, not a hidden native combat state.
  const movement = movementInputs(decision, bot.usingHeldItem)
  session.retreatRunJump = movement.retreatRunJump
  const rearYaw = movement.retreatRunJump
    ? Math.atan2(-(target.position.x-bot.entity.position.x),
      -(target.position.z-bot.entity.position.z)) + Math.PI : null
  const correction = movement.retreatRunJump
    ? Math.abs(Math.atan2(Math.sin(rearYaw-bot.entity.yaw),
      Math.cos(rearYaw-bot.entity.yaw)))*180/Math.PI
    : aimAtVisibleOpponent(bot, target, rangedSlot, useMs,
      session.observedTargetVelocity || target.velocity)
  if (movement.retreatRunJump) immediateLook(bot,rearYaw,0)
  session.aimDegrees += correction
  if (correction > 18) session.largeTurns++
  const forward = Number(decision.forward)
  bot.setControlState('forward', movement.forward); bot.setControlState('back', movement.back)
  bot.setControlState('left', movement.left); bot.setControlState('right', movement.right)
  // Using any item applies native slowdown; an active shield must not retain sprint.
  bot.setControlState('sprint', movement.sprint)
  bot.setControlState('sneak', movement.sneak)
  bot.setControlState('jump', movement.jump)
  if (session.activeUseHand === 'off' && bot.usingHeldItem && session.activeUseSlot === 4) {
    if (!crossbowLoaded(bot) && range > 6 && useMs < 1800) {
      session.crossbowHoldTicks++
      return [...ignoredHeads,4,5]
    }
    stopUse(session, bot)
    // Let the release packet reach the server before a separate learned use
    // decision can fire an already loaded crossbow. Reusing in this callback
    // repeatedly cancelled the release/fire boundary.
    return [...ignoredHeads,4,5]
  }
  if (session.activeUseHand === 'off' && bot.usingHeldItem && session.activeUseSlot === 1) {
    if (useMs < plannedBowDrawMs(range)) {
      session.bowHoldTicks++
      return [...ignoredHeads,4,5]
    }
    stopUse(session, bot)
    session.bowReleaseRequests++
    return [...ignoredHeads,4,5]
  }
  if (slot === 1) session.bowChoices++
  if (slot === 4) session.crossbowChoices++
  if ((slot === 1 || slot === 4) && decision.use) session.rangedUseChoices++
  if ([0,7].includes(slot) && bot.quickBarSlot !== slot) {
    if (bot.usingHeldItem) stopUse(session, bot)
    session.lastWeaponSwitchCharge = ownAttackCharge(session, bot.quickBarSlot)
    bot.setQuickBarSlot(slot)
    session.lastSwing = Date.now()
    session.weaponSwitches = (session.weaponSwitches || 0) + 1
  }
  if (decision.shield && Date.now() >= session.shieldDisabledUntil) {
    if (!requestOffhand(session, bot, 'shield')) return [...ignoredHeads,4,5]
    if (!bot.usingHeldItem) {
      bot.setControlState('sprint', false)
      bot.activateItem(true); session.activeUseHand = 'off'; session.activeUseSlot = -1
      session.useStarted = Date.now()
    }
  } else if (decision.use && [1,4].includes(slot)) {
    const wanted = slot === 1 ? 'bow' : 'crossbow'
    if (!requestOffhand(session, bot, wanted)) return [...ignoredHeads,4,5]
    if (!bot.usingHeldItem) {
      if (slot === 4 && crossbowLoaded(bot)) session.crossbowFireRequests++
      bot.activateItem(true); session.activeUseHand = 'off'; session.activeUseSlot = slot
      session.useStarted = Date.now()
      if (slot === 4) session.crossbowLoadAttempts++
    } else if (slot === 4 && session.activeUseSlot === 4 && crossbowLoaded(bot))
      stopUse(session, bot)
  }
  if (decision.release && bot.usingHeldItem) stopUse(session, bot)
  if (decision.attack) {
    if (!targetBoxWithinReach(bot, target)) {
      session.outOfReachAttackChoices++
      return ignoredHeads
    }
    const mainSlot = slotFor(bot)
    const charge = ownAttackCharge(session, mainSlot)
    const distance = bot.entity.position.distanceTo(target.position)
    const shieldBreak = mainSlot === 7 && distance <= 3 && opponentShieldFacing(bot, target)
    const urgentLight = bot.health < 6 && distance <= 2.5 && charge >= .55
    if (charge < .85 && !shieldBreak && !urgentLight) session.lowChargeChoices++
    if (bot.usingHeldItem) stopUse(session, bot)
    if (!bot.entity.onGround && bot.entity.velocity.y < -.08) {
      // Mineflayer emits stop_sprinting immediately before the attack packet.
      bot.setControlState('sprint', false)
      if (charge >= .9) session.critWindowAttempts++
    }
    session.lastAttackAttempt = Date.now()
    session.lastAttackCharge = charge
    session.lastAttackDistance = distance
    session.lastAttackReach = targetBoxDistance(bot,target)
    const dx=target.position.x-bot.entity.position.x,dz=target.position.z-bot.entity.position.z
    session.lastAttackRadialVelocity=(bot.entity.velocity.x*dx+bot.entity.velocity.z*dz)
      / Math.max(.001,Math.hypot(dx,dz))
    const oldYaw=bot.entity.yaw,oldPitch=bot.entity.pitch
    try {
      aimAtVisibleOpponent(bot, target)
      session.cameraFineAim++
      if (targetUnderCrosshair(bot, target)) {
        bot.attack(target); session.attacks++
        if (charge < .85) session.lightAttacks++
        session.chargeSum += charge
      }
      else { bot.swingArm(); session.misses++ }
      session.lastSwing = Date.now()
    } finally {
      if (movement.retreatRunJump) immediateLook(bot,oldYaw,oldPitch)
    }
  }
  return ignoredHeads
}
function requestAction (session) {
  const bot = bots.get(session.name), target = bot.players[session.opponent]?.entity
  if (!bridgeReady || !bot.entity || !target || bot.health <= 0) return
  const time = Date.now()
  session.minHealth = Math.min(session.minHealth, bot.health)
  if (session.pendingId && time-session.pendingAt < 500) return
  session.lastRequest = time
  const own = bot.entity
  const distance = own.position.distanceTo(target.position)
  session.distanceSamples++
  session.distanceSum += distance
  if (distance <= 3) session.reachSamples++
  if (distance > 5) session.farSamples++
  const hasBow = bot.inventory.slots.some(item => item?.name === 'bow')
  const hasCrossbow = bot.inventory.slots.some(item => item?.name === 'crossbow')
  const self = { x: own.position.x, y: own.position.y, z: own.position.z,
    eyeY: own.position.y+own.eyeHeight, vx: own.velocity.x, vy: own.velocity.y, vz: own.velocity.z,
    ground: own.onGround, critical: !own.onGround && own.velocity.y < -.08,
    charge: ownAttackCharge(session, slotFor(bot), time),
    health: bot.health, food: bot.food,
    shieldAvailable: shieldEquipped(bot) && time >= session.shieldDisabledUntil,
    shielding: bot.usingHeldItem && session.activeUseHand === 'off' && session.activeUseSlot === -1
      && time-session.useStarted >= 250,
    arrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n,item) => n+item.count,0),
    crossbowLoaded: crossbowLoaded(bot), hasBow, hasCrossbow,
    using: bot.usingHeldItem,
    useTicks: bot.usingHeldItem ? Math.round((time-session.useStarted)/50) : 0,
    held: slotFor(bot) }
  if (self.crossbowLoaded) session.crossbowLoadedObservations++
  const targetUse = opponentUseState(target)
  const effectiveShield = observedEffectiveShield(target)
  if (targetUse.shielding) session.opponentShieldObservations++
  const seen = { visible: target.position.distanceTo(own.position) < 64,
    x: target.position.x, y: target.position.y, z: target.position.z,
    yaw: 180-target.yaw*180/Math.PI, shield: effectiveShield,
    held: target.heldItem?.name?.toUpperCase() || 'UNKNOWN',
    using: targetUse.using, swing: session.opponentSwing,
    arrows: nearbyFlyingArrows(bot, 32) }
  const requestId = ++nextRequestId
  session.modelRequests++
  session.currentArrows = self.arrows
  session.pendingId = requestId; session.pendingAt = time
  const opponentSwingAge = session.lastOpponentSwingAt
    && time-session.lastOpponentSwingAt <= 500
    ? Math.max(0,Math.round((time-session.lastOpponentSwingAt)/50)) : -1
  const goal = freshDual
    ? tacticalGoal(self, { ...seen, vy: session.observedTargetVelocity?.y ?? 0 }, session.focus, session.techniqueCues)
    : { focus: session.focus, techniqueCues: session.techniqueCues, phase: 'legacy' }
  if (session.liveTacticalGoal?.phase !== goal.phase) log('operator_tactical_phase',
    { fighter: session.name, phase: goal.phase, reach: goal.reach, focus: goal.focus })
  session.liveTacticalGoal = goal
  sendBridge({ command: 'act', fighter: session.name, opponent: session.opponent,
    matchId: session.matchId, requestId, tick: session.clientFrame,
    trainingScope: freshDual && session.kind === 'selfplay'
      ? 'fresh_dual_sword_axe_unshielded' : null,
    yaw: 180-own.yaw*180/Math.PI, pitch: -own.pitch*180/Math.PI,
    observedOpponentHurts: session.visibleOpponentHurt,
    observedOpponentSwingAge: opponentSwingAge,
    self, seen, focus: goal.focus,
    style: session.style, techniqueCues: goal.techniqueCues })
}
function recordFighterFrame (session, bot) {
  const own = bot.entity, target = bot.players[session.opponent]?.entity
  if (!own || !target) return
  const time = Date.now(), targetUse = opponentUseState(target)
  const prior = session.lastObservedTarget
  if (prior && time-prior.at >= 25 && time-prior.at <= 250) {
    const ticks = (time-prior.at)/50
    const vx = (target.position.x-prior.x)/ticks
    const vy = (target.position.y-prior.y)/ticks
    const vz = (target.position.z-prior.z)/ticks
    if (Math.hypot(vx,vy,vz) > .003) {
      session.observedTargetVelocity = { x: vx, y: vy, z: vz }
      session.lastTargetMotionAt = time
    } else if (time-(session.lastTargetMotionAt || 0) > 100)
      session.observedTargetVelocity = { x: 0, y: 0, z: 0 }
  }
  session.lastObservedTarget = { at: time, x: target.position.x,
    y: target.position.y, z: target.position.z }
  const frameRow = { at: now(), matchId: session.kind === 'human-challenge'
    ? `${serverRunId}:challenge:${session.bout}` : `${serverRunId}:${session.arena}:${session.bout}`,
    kind: 'frame', fighter: session.name, opponent: session.opponent, tacticalGoal: session.liveTacticalGoal || null,
    frame: session.clientFrame, serverAgeAnchor: bot.time.age,
    self: { x: own.position.x, y: own.position.y, z: own.position.z,
      vx: own.velocity.x, vy: own.velocity.y, vz: own.velocity.z,
      ground: own.onGround, health: bot.health, food: bot.food,
      charge: ownAttackCharge(session, slotFor(bot), time),
      shieldAvailable: shieldEquipped(bot) && time >= session.shieldDisabledUntil,
      shielding: bot.usingHeldItem && session.activeUseSlot === -1
        && time-session.useStarted >= 250,
      opponentSwingAge: session.lastOpponentSwingAt
        && time-session.lastOpponentSwingAt <= 500
        ? Math.max(0,Math.round((time-session.lastOpponentSwingAt)/50)) : null,
      held: slotFor(bot), offhand: bot.inventory.slots[45]?.name || '',
      activeUseSlot: bot.usingHeldItem ? session.activeUseSlot : null,
      crossbowLoaded: crossbowLoaded(bot),
      arrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n,item) => n+item.count,0) },
    seen: { x: target.position.x, y: target.position.y, z: target.position.z,
      yaw: 180-target.yaw*180/Math.PI, shield: observedEffectiveShield(target),
      held: target.heldItem?.name || '', using: targetUse.using,
      vy: session.observedTargetVelocity?.y ?? target.velocity.y,
      swing: session.opponentSwing,
      arrows: nearbyFlyingArrows(bot, 32) } }
  if (session.kind === 'human-challenge') append(humanFramesPath, frameRow)
  session.frameHistory.push(frameRow)
}
function humanEventWindows (session, events) {
  const frames = session.frameHistory, actions = session.actionHistory
  if (!frames.length || !events?.length) return []
  const salient = events.filter(e => e.type === 'shield_disable' || e.type === 'arrow_launch'
    || (e.type === 'damage' && !e.cancelled && e.amount > 0))
  const selected = salient.length <= 8 ? salient : [...salient.slice(0,4), ...salient.slice(-4)]
  return selected.map(event => {
    const at = Date.parse(event.at)
    const frame = frames.reduce((best, row) => Math.abs(Date.parse(row.at)-at) < Math.abs(Date.parse(best.at)-at)
      ? row : best, frames[0])
    const action = [...actions].reverse().find(row => Date.parse(row.at) <= at
      && at-Date.parse(row.at) < 500)
    return { at: event.at, type: event.type,
      attacker: event.attacker || event.shooter || '', victim: event.victim || '',
      amount: event.type === 'damage' ? event.amount : null,
      frame: frame.frame, frameGapMs: Math.abs(Date.parse(frame.at)-at),
      distance: Math.hypot(frame.self.x-frame.seen.x, frame.self.y-frame.seen.y,
        frame.self.z-frame.seen.z),
      selfHealth: frame.self.health, selfCharge: frame.self.charge,
      selfY: frame.self.y, selfVy: frame.self.vy,
      targetY: frame.seen.y, targetVy: frame.seen.vy, targetYaw: frame.seen.yaw,
      selfShield: frame.self.shielding, targetShield: frame.seen.shield,
      mainSlot: frame.self.held, offhand: frame.self.offhand,
      action: action?.selected || null, executed: action?.executed || null }
  })
}
function applyNativeStepFeedback (events, fighters) {
  if (!events?.length) return 0
  const byName = new Map(fighters.filter(Boolean).map(session => [session.name, session]))
  const launches = events.filter(e => e.type === 'arrow_launch')
  let applied = 0
  const reward = (name, at, value, requireAttack = false) => {
    const session = byName.get(name)
    if (!session) return
    const action = [...session.actionHistory].reverse().find(row =>
      Date.parse(row.at) <= Date.parse(at)
      && Date.parse(at)-Date.parse(row.at) <= (requireAttack ? 500 : 1200)
      && (!requireAttack || row.executed?.attackPackets > 0))
    if (!action) return null
    const credited = typeof value === 'function' ? value(action) : value
    sendBridge({ command: 'native_step', fighter: name,
      decidedTick: action.decidedFrame,
      reward: Math.max(-1,Math.min(1,credited)) })
    applied++
    return action
  }
  for (const event of events) {
    if (event.cancelled) continue
    if (event.type === 'damage' && event.amount > 0) {
      let attributionAt = event.at
      if (event.source === 'ARROW') {
        const launch = [...launches].reverse().find(row => row.shooter === event.attacker
          && row.tick <= event.tick && event.tick-row.tick <= 80)
        if (launch) attributionAt = launch.at
      }
      if (event.source === 'MELEE')
        reward(event.attacker, event.at,
          action => damageFeedback(event, action.executed?.attackDistance, action.executed?.attackReach), true)
      else reward(event.attacker, attributionAt, damageFeedback(event))
      reward(event.victim, event.at, -damageFeedback(event))
    } else if (event.type === 'shield_disable') {
      reward(event.attacker, event.at, .04, true)
      reward(event.victim, event.at, -.04)
    } else if (event.type === 'damage' && event.victim_blocking && event.shield_modifier < 0) {
      reward(event.victim, event.at, .015)
      reward(event.attacker, event.at, -.015, true)
    }
  }
  return applied
}
function applyTacticalStepFeedback (session, tactics) {
  let applied = 0
  const edgeBonusBudget = { remaining: EDGE_PRIORITY.extraBudget }
  for (const result of counterRetreatFeedback(tactics)) {
    const at = Date.parse(result.at)
    const action = [...session.actionHistory].reverse().find(row =>
      Date.parse(row.at) <= at && at-Date.parse(row.at) <= 350)
    if (!action) continue
    sendBridge({ command: 'native_step', fighter: session.name,
      decidedTick: action.decidedFrame, reward: result.reward })
    applied++
  }
  for (const result of [...(tactics?.spacingOutcomes || []),
    ...(tactics?.criticalOutcomes || []), ...(tactics?.tempoOutcomes || []),
    ...(tactics?.exchangeOutcomes || [])]) {
    const at = Date.parse(result.at)
    const action = [...session.actionHistory].reverse().find(row =>
      result.decidedFrame !== undefined ? row.decidedFrame === result.decidedFrame
        : Date.parse(row.at) <= at && at-Date.parse(row.at) <= 500)
    if (!action) continue
    sendBridge({ command: 'native_step', fighter: session.name,
      decidedTick: action.decidedFrame,
      reward: edgePriorityReward(result, edgeBonusBudget) })
    applied++
  }
  return applied
}
function applyLandingFeedback (session, landing) {
  let applied = 0
  for (const result of landing.landingOutcomes) {
    if (!result.reward) continue
    sendBridge({ command: 'native_step', fighter: session.name,
      decidedTick: result.decidedFrame, reward: result.reward })
    applied++
  }
  return applied
}
function archiveBoutFrames (matchId, fighters) {
  const name = matchId.replace(/[^a-zA-Z0-9_-]/g, '_') + '.json.gz'
  const target = path.join(frameArchive, name)
  const packed = zlib.gzipSync(Buffer.from(JSON.stringify({ matchId,
    fighters: Object.fromEntries(fighters.filter(Boolean).map(s => [s.name, {
      opponent: s.opponent, focus: s.focus, style: s.style,
      leagueRole: s.leagueRole,
      goal: s.goal, frames: s.frameHistory, actions: s.actionHistory,
      dialogue: s.dialogue }])) }), 'utf8'), { level: 6 })
  const temp = target + '.tmp'
  fs.writeFileSync(temp, packed); fs.renameSync(temp, target)
  return { path: path.relative(store, target), bytes: packed.length,
    sha256: crypto.createHash('sha256').update(packed).digest('hex') }
}
function beginFighter (name, arena, bout, opponent, kind = 'selfplay') {
  const bot = bots.get(name)
  const curriculum = curriculumFor(name, bout)
  // WaveDog remains the only trainable brain. On an occasional self-play
  // cycle, one fighter in arena 1 is replaced by an immutable historical
  // snapshot; the other fighter is still a clone of the shared current
  // GRU+GTrXL brain and is the only side that can produce PPO updates.
  const historyArena = (freshDual || process.env.WAVEDOG_DUAL_BRAIN === '1')
    && kind === 'selfplay' && arena === 1 && bout % 4 === 0
  const criticalProbe = freshDual && kind === 'selfplay' && arena === 2 && bout % 3 === 1
  const leagueRole = criticalProbe && names.indexOf(name) % 2 === Math.floor(bout / 3) % 2
    ? 'wavejerry-critical-exploiter' : historyArena
    && names.indexOf(name) % 2 === (bout + arena) % 2
    ? historyRoles[(bout + arena) % historyRoles.length] : 'current'
  const matchId = kind === 'human-challenge'
    ? `${serverRunId}:challenge:${bout}` : `${serverRunId}:${arena}:${bout}`
  const context = { fighter: name, opponent, matchId, focus: curriculum.focus,
    style: curriculum.style, matchup: curriculum.matchup || null,
    goal: curriculum.goal || null, goalStage: curriculum.goalStage || null,
    techniqueCues: curriculum.techniqueCues || [],
    exploiterTarget: curriculum.exploiterTarget || null,
    exploiterRole: curriculum.exploiterRole || null,
    techniqueCues: curriculum.techniqueCues || [],
    goalMatchId: curriculum.goalMatchId || null,
    source: leagueRole === 'wavejerry-critical-exploiter' ? 'public-only-human-critical-script'
      : leagueRole === 'current' ? 'temporary-shared-brain-clone'
      : `frozen-${leagueRole}-opponent`, sharedRevision: sharedLessons.length,
    curriculumSource: curriculum.curriculumSource }
  contexts.set(name, context); append(coachPath, context)
  const session = { name, arena, bout, opponent, kind, started: Date.now(), lastSwing: Date.now()-1000,
    focus: curriculum.focus, style: curriculum.style, leagueRole,
    exploiterTarget: curriculum.exploiterTarget || null,
    exploiterRole: curriculum.exploiterRole || null,
    scheduledFocus: curriculum.scheduledFocus,
    curriculumSource: curriculum.curriculumSource,
    matchup: curriculum.matchup || null, goal: curriculum.goal || null,
    goalStage: curriculum.goalStage || null,
    goalMatchId: curriculum.goalMatchId || null, matchId,
    sharedRevision: sharedLessons.length, dialogue: [],
    lastAttackAttempt: 0, lastRequest: 0, pendingId: null, pendingAt: 0,
    lastHealth: 20, lastFood: null,
    clientFrame: 0, framesSeen: 0, modelRequests: 0, modelResponses: 0,
    frameHistory: [], actionHistory: [],
    minHealth: 20, lowHealthDecisions: 0, lowHealthAttackChoices: 0,
    lowHealthShieldChoices: 0, lowHealthRangedChoices: 0,
    lowHealthAdvanceChoices: 0, lowHealthRetreatChoices: 0,
    visibleOpponentHurt: 0, visibleOpponentHurtWhileLow: 0,
    shieldDisabledUntil: 0, useStarted: Date.now(), activeUseHand: null,
    offhandSwapPending: null, offhandSwapPromise: null,
    offhandSwapAttempts: 0, offhandSwapConfirmed: 0, offhandSwapErrors: 0,
    activeUseSlot: null, opponentSwing: 0, lastOpponentSwingAt: 0,
    retreatRunJump: false,
    decisions: 0, attacks: 0, misses: 0, cameraFineAim: 0,
    aimDegrees: 0, largeTurns: 0, distanceSamples: 0,
    distanceSum: 0, reachSamples: 0, farSamples: 0,
    suppressedLowCharge: 0, lowChargeChoices: 0, lightAttacks: 0, chargeSum: 0,
    missedChargeOpportunities: 0, lastOpportunityPenaltyAt: 0,
    outOfReachAttackChoices: 0,
    critWindowAttempts: 0, opponentShieldObservations: 0,
    bowChoices: 0, crossbowChoices: 0, rangedUseChoices: 0,
    bowHoldTicks: 0, bowReleaseRequests: 0, crossbowHoldTicks: 0,
    crossbowLoadAttempts: 0,
    crossbowFireRequests: 0,
    crossbowLoadedObservations: 0, startArrows: freshDual ? 0 : 5,
    currentArrows: freshDual ? 0 : 5 }
  sessions.set(name, session)
  sendBridge({ command: 'reset', fighter: name, opponent,
    matchId, focus: session.focus,
    learning: leagueRole === 'current', role: leagueRole })
  bot.clearControlStates()
  log('fighter_start', { name, opponent, arena, bout, kind, focus: session.focus,
    style: session.style, leagueRole, matchup: session.matchup, goal: session.goal,
    goalStage: session.goalStage,
    sharedRevision: session.sharedRevision })
}

async function finishHumanChallenge (challenge, winner, reason) {
  if (challenge.ending) return
  challenge.ending = true
  const session = sessions.get(challenge.bot)
  if (!session || session.kind !== 'human-challenge' || session.bout !== challenge.id) {
    log('human_challenge_missing_session', { id: challenge.id, bot: challenge.bot })
    return
  }
  const bot = bots.get(challenge.bot)
  bot.clearControlStates()
  if (bot.usingHeldItem) bot.deactivateItem()
  if (session.offhandSwapPromise) await session.offhandSwapPromise
  sessions.delete(challenge.bot)
  const matchId = `${serverRunId}:challenge:${challenge.id}`
  let native = null, training = null, trainingError = null, frameWindows = []
  let wholeBoutSummary = null
  let nativeFeedbackSent = 0, tactics = null
  try {
    const record = await takeNativeBout(challenge.arena, -challenge.id)
    native = record?.summary || null
    frameWindows = humanEventWindows(session, record?.events)
    wholeBoutSummary = wholeBout(session.name, session.opponent,
      session.frameHistory, session.actionHistory, record?.events || [], 18)
    tactics = record ? analyzeTactics(session.name, session.opponent,
      record.events, session.frameHistory, session.actionHistory) : null
    nativeFeedbackSent = applyNativeStepFeedback(record?.events, [session])
    if (record) {
      const landing = analyzeLandingChoices(session.name, session.opponent,
        session.actionHistory, session.frameHistory, record.events)
      nativeFeedbackSent += applyLandingFeedback(session, landing)
      const { landingOutcomes, ...landingSummary } = landing
      Object.assign(tactics, landingSummary)
    }
    nativeFeedbackSent += applyTacticalStepFeedback(session, tactics)
    append(humanEventsPath, { matchId, arena: challenge.arena, bout: -challenge.id,
      bot: challenge.bot, opponent: session.opponent, observed: Boolean(record),
      events: record?.events || [] })
  }
  catch (error) { log('native_feedback_error', { challenge: challenge.id, error: String(error) }) }
  try {
    if (session.decisions > 0 && reason === 'death' && [challenge.bot, session.opponent].includes(winner))
      training = await finishFighter(session, winner)
    else if (session.decisions > 0) training = await partialFighter(session)
    else sendBridge({ command: 'reset', fighter: session.name, opponent: '', learning: false })
  } catch (error) { trainingError = String(error); log('human_challenge_training_error', { id: challenge.id, error: trainingError }) }
  const report = { at: now(), matchId,
    arena: challenge.arena, bout: -challenge.id, kind: 'human-challenge',
    bot: challenge.bot, opponent: session.opponent, winner, reason, native,
    frameWindows, wholeBout: wholeBoutSummary, nativeFeedbackSent, tactics,
    goal: session.goal, goalStage: session.goalStage,
    goalMatchId: session.goalMatchId,
    sharedRevision: session.sharedRevision, dialogue: session.dialogue,
    focus: session.focus, style: session.style, decisions: session.decisions,
    framesSeen: session.framesSeen, modelRequests: session.modelRequests,
    modelResponses: session.modelResponses,
    attackPackets: session.attacks, crosshairMisses: session.misses,
    outOfReachAttackChoices: session.outOfReachAttackChoices,
    bowChoices: session.bowChoices, crossbowChoices: session.crossbowChoices,
    ammoConsumed: Math.max(0,session.startArrows-session.currentArrows),
    offhandSwapAttempts: session.offhandSwapAttempts,
    offhandSwapConfirmed: session.offhandSwapConfirmed,
    offhandSwapErrors: session.offhandSwapErrors,
    training, trainingError }
  append(challengesPath, report)
  mergedOutcomes.add(report)
  const context = contexts.get(challenge.bot)
  if (context?.matchId === matchId) {
    append(coachPath, { ...context, winner, finished: true,
      wholeBout: wholeBoutSummary, training })
    contexts.delete(challenge.bot)
  }
  reviewHumanChallenge(report)
  log('human_challenge_end', { id: challenge.id, winner, reason,
    trained: Boolean(training), native: Boolean(native) })
}

function reviewHumanChallenge (report, historical = false) {
  const key = reviewKey(report)
  if (invalidMatchIds.has(key)) return
  if (humanReviewedKeys.has(key) || humanQueuedReviews.has(key)) return
  humanQueuedReviews.add(key)
  const brief = [report.at, report.matchId, report.arena, report.bout, report.winner,
    [report.bot, report.style, report.focus, report.attackPackets,
      report.crosshairMisses, report.bowChoices, report.crossbowChoices,
      report.ammoConsumed, report.framesSeen, report.modelRequests, report.modelResponses], report.native
      ? Object.fromEntries(Object.entries(report.native).filter(([key]) => key !== 'trace')) : null]
  const timeline = mergeTimeline(orderedMemory().slice(-4), [brief], (report.native?.trace || [])
    .filter(event => event[4] === 'shield_disable' || event[4] === 'arrow_launch'
      || (event[4] === 'damage' && Number(event[8]) > 0)).slice(0, 16)
    .map(event => ({ at: event[0], kind: 'native_event', matchId: report.matchId,
      sequence: event[1], event: event.slice(2) })))
  const whole = report.wholeBout || {}
  const boundedWholeBout = {
    durationMs: whole.durationMs,
    stageTotals: whole.stageTotals,
    stageTransitions: (whole.stageTransitions || []).slice(0, 12),
    phases: (whole.phases || []).slice(0, 8).map(p =>
      [p[0], p[2], p[3], p[5], p[6], p[10], p[14], p[15], p[16], p[18], p[19], p[21]])
  }
  const boundedWindows = (report.frameWindows || []).slice(0, 12).map(w => [
    w.at, w.type, w.attacker, w.victim, w.amount, w.frameGapMs,
    Number.isFinite(w.distance) ? +w.distance.toFixed(2) : null,
    w.selfCharge, w.selfVy, w.targetVy, w.selfShield, w.targetShield,
    w.action?.jump, w.action?.sprint, w.action?.attack,
    w.executed?.jump, w.executed?.sprint, w.executed?.attackPackets])
  scheduleQwen(() => inferQwen([
    { role: 'system', content: '你是总 Qwen 真人局复盘教练。wholeBout 给三阶段总计和阶段顺序；phases 每项=[秒,最近距,最远距,末血,有效盾帧,出刀包,伤敌,受伤,发箭,挡刀,破盾,主阶段]。frameWindows 每项=[时间,事件,攻击者,受害者,伤害,观测时差,距离,蓄力,自身竖速,对手竖速,自身盾,对手盾,所选跳,所选疾跑,所选攻击,实跳,实疾跑,实际攻击包]。按开局、相持、缠斗、远距、收尾顺序分析真实胜负，给下一批一个可测目标。满程跑跳暴击须看实际水平行程和原生暴击。没有箭伤不等于躲箭成功，候选暴击不等于原生暴击；观测时差大时不可推断严格因果。不读隐藏输入。仅返回JSON {"focus":"...","lesson":"..."}；focus从FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT选。' },
    { role: 'user', content: JSON.stringify({ globalTimeline: timeline.map(row =>
      row.kind === 'memory' ? ['M', row.at, row.source, row.text]
        : row.kind === 'native_event' ? ['E', row.at, row.sequence, ...row.event]
          : ['B', ...row.bout]),
      wholeBout: boundedWholeBout,
      archivedKnowledge: referenceFor('', report.focus, 180),
      dialogueThisBout: (report.dialogue || []).slice(-4).map(d => [d.role, d.text]),
      frameWindows: boundedWindows, tactics: report.tactics || null,
      question: '按开局、接近、换血、脱离、远程或再入、收尾的顺序解释本局实际胜负。给下一批分身一个具体可测目标，注明本局哪一段提供证据；没有证据就明确说待验证。' }) }
  ], 100, batchReviewSchema), !historical).then(answer => {
    if (!focusNames.has(answer.focus) || !answer.lesson?.trim()) throw Error('Invalid human challenge review')
    const measured = report.native
      ? `真人局原生命中${report.native.meleeHits}、破盾${report.native.shieldBreaks}、箭伤${report.native.arrowHits}`
      : '真人局原生事件尚未归属，保留待核查'
    const row = { at: now(), matchId: report.matchId, fighters: [report.bot, report.opponent],
      focus: answer.focus, lesson: `${measured}；待测${answer.focus}`,
      qwenSuggestion: String(answer.lesson).slice(0,90),
      lessonSource: 'measured-after-Qwen', source: 'human-challenge-Qwen' }
    sharedLessons.push(row); append(sharedLessonsPath, row)
    humanReviewedKeys.add(key); humanQueuedReviews.delete(key)
    log('human_challenge_review', { matchId: report.matchId, focus: answer.focus })
  }).catch(error => {
    humanQueuedReviews.delete(key)
    append(qwenErrorsPath, { phase: 'human_challenge', matchId: report.matchId, error: String(error) })
    log('human_challenge_review_error', { matchId: report.matchId, error: String(error) })
    setTimeout(() => reviewHumanChallenge(report, historical), historical ? 300000 : 60000)
  })
}
async function endPair (pair, winner, reason) {
  if (pair.ending) return
  pair.ending = true
  const fighters = [pair.a, pair.b].map(name => sessions.get(name))
  for (const session of fighters) {
    if (!session) continue
    const bot = bots.get(session.name)
    bot.clearControlStates(); if (bot.usingHeldItem) bot.deactivateItem()
    if (session.offhandSwapPromise) await session.offhandSwapPromise
    sessions.delete(session.name)
  }
  let native = null, nativeFeedbackSent = 0, tactics = {}, nativeEvents = []
  try {
    const record = await takeNativeBout(pair.arena, pair.bout)
    native = record?.summary || null
    nativeEvents = record?.events || []
    nativeFeedbackSent = applyNativeStepFeedback(record?.events, fighters)
    if (record) for (const session of fighters.filter(Boolean)) {
      tactics[session.name] = analyzeTactics(session.name, session.opponent,
        record.events, session.frameHistory, session.actionHistory)
      const landing = analyzeLandingChoices(session.name, session.opponent,
        session.actionHistory, session.frameHistory, record.events)
      nativeFeedbackSent += applyLandingFeedback(session, landing)
      const { landingOutcomes, ...landingSummary } = landing
      Object.assign(tactics[session.name], landingSummary)
    }
    for (const session of fighters.filter(Boolean))
      nativeFeedbackSent += applyTacticalStepFeedback(session, tactics[session.name])
  }
  catch (error) { log('native_feedback_error', { arena: pair.arena, bout: pair.bout, error: String(error) }) }
  const matchId = `${serverRunId}:${pair.arena}:${pair.bout}`
  const wholeBouts = Object.fromEntries(fighters.filter(Boolean).map(s => [s.name,
    wholeBout(s.name, s.opponent, s.frameHistory, s.actionHistory, nativeEvents, 8)]))
  let frameArchiveReceipt = null
  try { frameArchiveReceipt = archiveBoutFrames(matchId, fighters) }
  catch (error) { log('frame_archive_error', { matchId, error: String(error) }) }
  const report = { at: now(), arena: pair.arena, bout: pair.bout,
    matchId, winner, reason, trainingMode: singleLane ? 'single-lane' : 'concurrent',
    frameReviewVersion: freshDual ? 1 : 0,
    native, nativeFeedbackSent, tactics,
    wholeBouts, frameArchive: frameArchiveReceipt,
    fighters: Object.fromEntries(fighters.filter(Boolean).map(s => [s.name, {
      opponent: s.opponent, decisions: s.decisions, framesSeen: s.framesSeen,
      modelRequests: s.modelRequests, modelResponses: s.modelResponses,
      attacks: s.attacks, misses: s.misses,
      cameraFineAim: s.cameraFineAim, bowChoices: s.bowChoices, crossbowChoices: s.crossbowChoices,
      meanDistance: s.distanceSamples ? Math.round(100*s.distanceSum/s.distanceSamples)/100 : null,
      reachFraction: s.distanceSamples ? Math.round(1000*s.reachSamples/s.distanceSamples)/1000 : 0,
      farFraction: s.distanceSamples ? Math.round(1000*s.farSamples/s.distanceSamples)/1000 : 0,
      largeTurns: s.largeTurns,
      suppressedLowCharge: s.suppressedLowCharge,
      lowChargeChoices: s.lowChargeChoices,
      lightAttacks: s.lightAttacks,
      missedChargeOpportunities: s.missedChargeOpportunities,
      outOfReachAttackChoices: s.outOfReachAttackChoices,
      meanAttackCharge: s.attacks ? Math.round(1000*s.chargeSum/s.attacks)/1000 : null,
      critWindowAttempts: s.critWindowAttempts,
      opponentShieldObservations: s.opponentShieldObservations,
      minHealth: Math.round(100*s.minHealth)/100,
      lowHealthDecisions: s.lowHealthDecisions,
      lowHealthAttackChoices: s.lowHealthAttackChoices,
      lowHealthShieldChoices: s.lowHealthShieldChoices,
      lowHealthRangedChoices: s.lowHealthRangedChoices,
      lowHealthAdvanceChoices: s.lowHealthAdvanceChoices,
      lowHealthRetreatChoices: s.lowHealthRetreatChoices,
      visibleOpponentHurt: s.visibleOpponentHurt,
      visibleOpponentHurtWhileLow: s.visibleOpponentHurtWhileLow,
      rangedUseChoices: s.rangedUseChoices,
      bowHoldTicks: s.bowHoldTicks, bowReleaseRequests: s.bowReleaseRequests,
      crossbowHoldTicks: s.crossbowHoldTicks,
      crossbowLoadAttempts: s.crossbowLoadAttempts,
      crossbowFireRequests: s.crossbowFireRequests,
      crossbowLoadedObservations: s.crossbowLoadedObservations,
      offhandSwapAttempts: s.offhandSwapAttempts,
      offhandSwapConfirmed: s.offhandSwapConfirmed,
      offhandSwapErrors: s.offhandSwapErrors,
      ammoConsumed: Math.max(0,s.startArrows-s.currentArrows),
      focus: s.focus, style: s.style, leagueRole: s.leagueRole,
      exploiterTarget: s.exploiterTarget, exploiterRole: s.exploiterRole,
      scheduledFocus: s.scheduledFocus,
      matchup: s.matchup, goal: s.goal, goalStage: s.goalStage,
      goalMatchId: s.goalMatchId,
      sharedRevision: s.sharedRevision, dialogue: s.dialogue,
      curriculumSource: s.curriculumSource }])), training: [] }
  if (reason === 'death' && [pair.a,pair.b].includes(winner) && fighters.every(s => s && s.decisions > 0)) {
    const receipts = await Promise.allSettled(fighters.map(session => finishFighter(session, winner)))
    for (const receipt of receipts) {
      if (receipt.status === 'fulfilled') report.training.push(receipt.value)
      else report.trainingError = String(receipt.reason)
    }
    if (report.trainingError) log('training_error', { arena: pair.arena,
      bout: pair.bout, error: report.trainingError })
  } else if (fighters.every(s => s && s.decisions > 0)) {
    const receipts = await Promise.allSettled(fighters.map(partialFighter))
    for (const receipt of receipts) {
      if (receipt.status === 'fulfilled') report.training.push(receipt.value)
      else report.trainingError = String(receipt.reason)
    }
    if (report.trainingError) log('partial_training_error', { arena: pair.arena,
      bout: pair.bout, error: report.trainingError })
  } else {
    for (const session of fighters.filter(Boolean)) sendBridge({ command: 'reset', fighter: session.name,
      opponent: '', learning: false })
  }
  append(roundsPath, report)
  mergedOutcomes.add(report)
  const fact = immediateRoundFact(report)
  sharedLessons.push(fact); append(sharedLessonsPath, fact)
  if (reason === 'death' && Object.values(tactics)
    .some(t => Number.isInteger(t?.edgeCounterEscapes))) {
    researchHistory.push(report)
    if (researchHistory.length > 24) researchHistory.shift()
  }
  log('bout_end', { arena: pair.arena, bout: pair.bout, winner, reason,
    trained: report.training.filter(row => row.event === 'trained'
      || row.event === 'trained_partial').length,
    attacks: fighters.map(s => s?.attacks || 0) })
  if (freshDual && report.training.length && !report.trainingError) {
    // Do not hold the arena open while Qwen reviews the previous bout.
    // Training and the next rollout continue; the review is durable and
    // updates the next curriculum when it completes.
    launchPairReview(pair, report)
  } else if (!singleLane) enqueueReview(report)
  for (const session of fighters.filter(Boolean)) {
    const context = contexts.get(session.name)
    if (context?.matchId === matchId) {
      append(coachPath, { ...context, winner, finished: true,
        wholeBout: wholeBouts[session.name], training: report.training })
      contexts.delete(session.name)
    }
  }
  pairs.delete(pair.arena)
  if (report.trainingError && desired) {
    desired = 0
    try { await rcon('selfplay pause') }
    catch (error) { log('training_failure_pause_error', { error: String(error) }) }
  }
  if (singleLane && !report.trainingError) {
    try { await advanceSingleLane(pair, report) }
    catch (error) {
      desired = 0
      log('single_lane_error', { arena: pair.arena, bout: pair.bout,
        error: String(error.stack || error) })
      try { await rcon('selfplay pause') } catch {}
    }
  } else if (!stopping && desired >= pair.arena) nextArena(pair.arena)
}
async function prepareSingleLanePair (arena) {
  const pairNames = names.slice((arena - 1) * 2, arena * 2)
  for (const name of pairNames) if (!bots.has(name)) createBot(name)
  for (let attempt = 0; attempt < 180 && !stopping; attempt++) {
    if (pairNames.every(name => readyBots.has(name))) return
    await new Promise(resolve => setTimeout(resolve, 500))
  }
  throw Error(`Pair ${arena} did not join the server`)
}
async function advanceSingleLane (pair, report) {
  const cycleFinished = laneState.complete(report)
  for (const name of [pair.a, pair.b]) {
    const bot = bots.get(name)
    bots.delete(name); readyBots.delete(name)
    if (bot) bot.quit()
  }
  if (cycleFinished) await reviewSingleLaneCycle()
  if (stopping) return
  const next = laneState.value.nextArena
  await prepareSingleLanePair(next)
  if (manualLane) {
    log('single_lane_waiting_for_operator', { cycle: laneState.value.cycle, nextArena: next })
    return
  }
  const status = await rcon('selfplay status')
  if (status.includes('desired=0')) {
    log('single_lane_waiting', { cycle: laneState.value.cycle, nextArena: next })
    return
  }
  log('single_lane_next', { cycle: laneState.value.cycle, arena: next })
  await nextArena(next)
}
async function nextArena (arena) {
  for (let attempt = 0; attempt < 180 && !stopping; attempt++) {
    try {
      const result = await rcon(`selfplay next ${arena}`)
      if (result.startsWith('Started') || result.includes('Already active')) return
      if (result.includes('outside active count')) return
      if (attempt % 5 === 0) log('next_waiting', { arena, attempt, result })
    } catch (error) { if (attempt % 5 === 0) log('next_error', { arena, attempt, error: String(error) }) }
    await new Promise(resolve => setTimeout(resolve, 2000))
  }
  log('arena_stalled', { arena })
  if (!stopping && desired >= arena) setTimeout(() => nextArena(arena), 5000)
}
function onSparMessage (name, message) {
  const challengeStart = message.match(/WCHALLENGE_START:(\d+):(\d+):([^:]+):([^\s]+)/)
  if (challengeStart && challengeStart[4] === token) {
    const id = Number(challengeStart[1]), arena = Number(challengeStart[2])
    const opponent = challengeStart[3]
    const challenge = { id, arena, bot: name, opponent, ending: false }
    activeChallenge = challenge
    const activate = (attempt = 0) => {
      if (activeChallenge !== challenge || challenge.ending) return
      if (pairs.has(arena) || sessions.has(name)) {
        if (attempt < 240) setTimeout(() => activate(attempt+1), 250)
        else log('human_challenge_activation_timeout', { id, arena, bot: name })
        return
      }
      beginFighter(name, arena, id, opponent, 'human-challenge')
      log('human_challenge_start', { id, arena, bot: name, opponent })
    }
    activate()
    return true
  }
  const challengeEnd = message.match(/WCHALLENGE_END:(\d+):([^:]+):([^:]+):([^\s]+)/)
  if (challengeEnd && challengeEnd[4] === token) {
    const id = Number(challengeEnd[1]), challenge = activeChallenge
    if (challenge && challenge.id === id && challenge.bot === name) {
      activeChallenge = null
      finishHumanChallenge(challenge, challengeEnd[2], challengeEnd[3])
        .catch(error => log('human_challenge_end_error', { id, error: String(error) }))
    }
    return true
  }
  const start = message.match(/WSPAR_START:(\d+):(\d+):([^:]+):([^\s]+)/)
  if (start && start[4] === token) {
    const arena = Number(start[1]), bout = Number(start[2]), opponent = start[3]
    let pair = pairs.get(arena)
    if (!pair || pair.bout !== bout) {
      pair = { arena, bout, a: `NBot${String((arena-1)*2+1).padStart(2,'0')}`,
        b: `NBot${String((arena-1)*2+2).padStart(2,'0')}`, ending: false }
      pairs.set(arena, pair)
    }
    beginFighter(name, arena, bout, opponent)
    return true
  }
  const end = message.match(/WSPAR_END:(\d+):(\d+):([^:]+):([^:]+):([^\s]+)/)
  if (end && end[5] === token) {
    const arena = Number(end[1]), bout = Number(end[2]), pair = pairs.get(arena)
    if (pair && pair.bout === bout) endPair(pair, end[3], end[4]).catch(error => log('pair_end_error', { arena, error: String(error) }))
    return true
  }
  return false
}
function createBot (name) {
  const bot = mineflayer.createBot({ host: '127.0.0.1', port: 25566,
    username: name, version: '1.21.1', auth: 'offline', keepAlive: true,
    checkTimeoutInterval: 120000 })
  const wire=bot._client,write=wire.write
  wire.write=function(name,data){return write.call(this,name,currentViewPacket(name,data,bot.entity))}
  bots.set(name, bot)
  let movementInstalled = false
  let crossbowProbeInstalled = false
  bot.on('messagestr', message => {
    if (onSparMessage(name, message)) return
    if (/register|注册/i.test(message) && !/already|已注册/i.test(message)) bot.chat(`/register ${credentials[name]} ${credentials[name]}`)
    else if (/\/login|登录|log in/i.test(message)) bot.chat(`/login ${credentials[name]}`)
  })
  bot.on('whisper', (player, message) => {
    if (names.includes(player)) return
    answerCloneWhisper(name, player, message?.trim()).catch(error =>
      log('clone_whisper_error', { name, player, error: String(error) }))
  })
  bot.on('health', () => {
    const session = sessions.get(name)
    if (!session) return
    const received = Math.max(0,session.lastHealth-bot.health)
    session.lastHealth = bot.health
    const foodCost = hungerFeedback(session.lastFood, bot.food)
    session.lastFood = Number.isFinite(bot.food) ? bot.food : session.lastFood
    if (foodCost < 0) {
      const at = Date.now()
      const recent = session.actionHistory.filter(row =>
        at-Date.parse(row.at) <= 12000 && at-Date.parse(row.at) >= 0
        && (row.executed?.forward || row.executed?.back || row.executed?.left
          || row.executed?.right || row.executed?.jump || row.executed?.attackPackets))
        .slice(-24)
      for (const row of recent) sendBridge({ command: 'native_step', fighter: name,
        decidedTick: row.decidedFrame, reward: foodCost / recent.length })
    }
    if (received > 0) {
      if (session.kind === 'human-challenge') append(humanFramesPath,
        { matchId: `${serverRunId}:challenge:${session.bout}`, kind: 'feedback',
          fighter: name, frame: session.clientFrame, received, health: bot.health })
    }
  })
  bot.on('entityHurt', entity => {
    const session = sessions.get(name)
    if (!session || entity?.username !== session.opponent) return
    session.visibleOpponentHurt++
    const desperate = bot.health < 6
    if (desperate) session.visibleOpponentHurtWhileLow++
    // A normal client sees the hurt animation. Reward it modestly; native deaths
    // still decide the bout and the exact hidden damage never enters observations.
    if (session.kind === 'human-challenge') append(humanFramesPath,
      { matchId: `${serverRunId}:challenge:${session.bout}`, kind: 'feedback',
        fighter: name, frame: session.clientFrame, visibleOpponentHurt: true,
        rewardProxy: desperate ? 1 : .5 })
  })
  bot.on('entitySwingArm', entity => {
    const session = sessions.get(name)
    if (session && entity?.username === session.opponent) {
      session.opponentSwing++
      session.lastOpponentSwingAt = Date.now()
    }
  })
  require('./learning-frame-listener').installLearningFrames(bot,
    { sessions, recordFighterFrame, requestAction })
  bot._client.on('set_cooldown', packet => {
    const session = sessions.get(name)
    if (session && packet.itemID === mcData.itemsByName.shield.id
        && (packet.cooldownTicks ?? packet.cooldown ?? 0) > 0) {
      session.shieldDisabledUntil = Date.now()+50*(packet.cooldownTicks ?? packet.cooldown)
    }
  })
  bot.on('kicked', reason => log('bot_kicked', { name, reason: String(reason).slice(0,220) }))
  bot.on('error', error => log('bot_error', { name, error: String(error).slice(0,220) }))
  bot.on('end', reason => {
    if (activeChallenge?.bot === name) {
      const challenge = activeChallenge; activeChallenge = null
      finishHumanChallenge(challenge, 'NONE', 'disconnect')
        .catch(error => log('human_challenge_end_error', { id: challenge.id, error: String(error) }))
    }
    readyBots.delete(name)
    log('bot_end', { name, reason: String(reason) })
    if (!stopping) setTimeout(() => {
      if (!stopping && bots.get(name) === bot) createBot(name)
    }, 3000 + Math.floor(Math.random()*3000))
  })
  bot.on('spawn', () => {
    if (!movementInstalled) { installVanillaUseMovement(bot); movementInstalled = true }
    if (debugCrossbow && !crossbowProbeInstalled) {
      crossbowProbeInstalled = true
      bot.inventory.on('updateSlot', (slot, oldItem, item) => {
        if (slot !== 40 || item?.name !== 'crossbow') return
        const component = item.componentMap?.get('charged_projectiles')
        log('crossbow_component', { name, slot,
          types: item.components?.map(value => value.type),
          data: JSON.stringify(component?.data ?? null).slice(0,500) })
      })
    }
    readyBots.add(name)
    log('bot_spawn', { name })
  })
}
async function initialize () {
  startBridge()
  replayInterruptedFrameReviews().catch(error =>
    log('frame_review_recovery_error', { error: String(error) }))
  replayMissingReviews().catch(error => log('review_recovery_error', { error: String(error) }))
  replayMissingHumanReviews()
  if (singleLane) {
    while (!bridgeReady) await new Promise(resolve => setTimeout(resolve, 1000))
    if (laneState.value.completed.length === arenaCount)
      await reviewSingleLaneCycle()
    const arena = laneState.value.nextArena
    await prepareSingleLanePair(arena)
    desired = arenaCount
    const result = await rcon(`selfplay lane ${arenaCount}`)
    log('single_lane_enabled', { arena, cycle: laneState.value.cycle, result })
    if (!result.includes('Single physical arena enabled'))
      throw Error(`Could not enable one physical arena: ${result}`)
    if (manualLane) log('single_lane_waiting_for_operator',
      { cycle: laneState.value.cycle, nextArena: arena })
    else await nextArena(arena)
    return
  }
  for (const name of names) { createBot(name); await new Promise(resolve => setTimeout(resolve, 500)) }
  while (!bridgeReady) await new Promise(resolve => setTimeout(resolve, 1000))
  log('bots_created', { count, connected: readyBots.size })
  for (let arena = 1; arena <= arenaCount; arena++) {
    desired = arena
    fs.writeFileSync(readyFile, JSON.stringify({ at: now(), bots: count, bridgeReady,
      qwenContexts: contexts.size, desired: arenaCount }))
    const result = await rcon(`selfplay start ${arena}`)
    log('arena_enabled', { arena, result })
    if (!result.includes('started=1')) nextArena(arena)
  }
  desired = arenaCount
}
const readinessTimer = setInterval(() => {
  if (stopping || !bridgeReady) { fs.rmSync(readyFile,{force:true}); return }
  fs.writeFileSync(readyFile, JSON.stringify({ at: now(), bots: count, bridgeReady,
    qwenContexts: contexts.size, desired: arenaCount, activePairs: pairs.size,
    singleLane, manualLane, laneCycle: laneState?.value.cycle,
    laneNextArena: laneState?.value.nextArena,
    laneCompleted: laneState?.value.completed.length,
    qwenQueue: qwenQueue.length, qwenActive,
    reviewPending: pendingReviews.length, historicalReviewPending: historicalRoundBacklog.length }))
}, 1000)
process.on('SIGINT', () => { stopping = true; clearInterval(readinessTimer);
  fs.rmSync(readyFile,{force:true}); for (const bot of bots.values()) bot.quit();
  if (bridge?.stdin.writable) sendBridge({ command: 'close' }); process.exit(0) })
log('selfplay_boot', { bots: count, arenas: arenaCount,
  architecture: freshDual || process.env.WAVEDOG_DUAL_BRAIN === '1' ? 'GRU64+GTrXL4x256' : 'GRU64',
  checkpoint: freshDual
    ? path.join(base,'..','pvp-8.6-dual-fresh','model','checkpoint.json')
    : process.env.WAVEDOG_DUAL_BRAIN === '1'
    ? path.join(base,'..','pvp-dual-brain','models','live','checkpoint.json')
    : path.join(checkpoint,'recurrent-ppo.json') })
initialize().catch(error => { log('selfplay_init_error', { error: String(error) }); process.exitCode = 1 })
