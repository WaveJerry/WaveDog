'use strict'
// Direct state-machine translation of the frozen 8.6 CounterEscapeHop class.
// This module chooses no heading, weapon, attack or ownership transition.
function createCounterEscapeHop () {
  let counterAt, submittedAt, active, spent, airborne, criticalSubmitted, exitAccepted
  function reset () {
    counterAt = submittedAt = -1000
    active = spent = airborne = criticalSubmitted = exitAccepted = false
  }
  reset()
  return {
    reset,
    arm (tick) {
      if (tick <= counterAt) return
      counterAt = tick; submittedAt = -1000; active = true
      spent = airborne = criticalSubmitted = exitAccepted = false
    },
    observe (tick, onGround) {
      if (!active) return
      if (!onGround) { airborne = true; spent = true }
      else if (airborne) active = false
      else if (submittedAt >= 0 && tick - submittedAt > 3 || submittedAt < 0 && tick - counterAt > 3) {
        active = false; spent = true
      }
    },
    jumpSubmitted (tick) {
      if (!active || spent || tick < counterAt) return
      submittedAt = tick; spent = true
    },
    active: () => active,
    wasAirborne: () => airborne,
    allowsJump: () => !active || !spent,
    belongsTo: tick => counterAt >= 0 && tick === counterAt,
    criticalAvailable: (nativeCriticalWindow, velocityY) => active && airborne
      && !criticalSubmitted && !exitAccepted && nativeCriticalWindow
      && Number.isFinite(velocityY) && velocityY < 0,
    criticalSubmitted () { criticalSubmitted = true },
    acceptExit () { exitAccepted = true },
    exitAccepted: () => exitAccepted,
    blocked () { active = false; spent = true }
  }
}
module.exports = { createCounterEscapeHop }
