'use strict'
const fs=require('node:fs'),path=require('node:path')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {createHighRateLoop,monoMs}=require('./protocol-high-rate-loop')
const {frame,probe}=require('./test-legacy86-control')
async function benchmark(airborne){
  const brain=createBrain();await brain.ready
  const state=createState('enemy');state.swordOnly=true;state.hadHop=true
  await brain.reset(state,123)
  let tick=100,busy=0,committing=false,cycles=0,decisions=0,coalesced=0,errors=[],missed=0,latencies=[],physics=[]
  let routeCache=new Map()
  const make=()=>frame({routeCache,seen:airborne?{x:3.29,y:.6}:{},targetVelocity:airborne?{x:-.1,y:.2,z:0}:{x:0,y:0,z:0},
    observation:{tick,targetGrounded:!airborne,targetAirborne:airborne},targetMotion:{sampleTick:tick}})
  // Warm class loading, reflection metadata, JSON and compiled routes.
  await brain.decide(state,make(),probe,tick)
  for(let i=0;i<30;i++)await brain.decide(state,make(),probe,tick,{preview:true})
  const started=monoMs(),duration=5000
  const loop=createHighRateLoop({hz:500,onCycle:async row=>{
    cycles++;missed=row.missedDeadlines
    if(busy>=2||committing){coalesced++;return}
    busy++
    const at=monoMs()
    try{
      if(Math.floor((at-started)/50)+100>tick){tick=Math.floor((at-started)/50)+100
        routeCache=new Map()
        committing=true;const t=monoMs();await brain.decide(state,make(),probe,tick);physics.push(monoMs()-t);committing=false}
      await brain.decide(state,make(),probe,tick,{preview:true});decisions++;latencies.push(monoMs()-at)
    }catch(error){errors.push(String(error))}finally{busy--}
  }})
  loop.reset('bench')
  await new Promise(resolve=>setTimeout(resolve,duration))
  await loop.close()
  while(busy)await new Promise(resolve=>setTimeout(resolve,2))
  await brain.close()
  latencies.sort((a,b)=>a-b)
  const q=p=>latencies[Math.min(latencies.length-1,Math.floor(latencies.length*p))]
  return {scenario:airborne?'full-airborne-threat-and-wall-routes':'ground-spacing',durationMs:duration,
    synthetic:true,gameConnected:false,cycles,cycleHz:cycles*1000/duration,decisions,
    decisionHz:decisions*1000/duration,coalesced,missedTimerDeadlines:missed,
    decisionMs:{p50:q(.5),p95:q(.95),p99:q(.99),max:q(1)},errors}
}
;(async()=>{
  const results=[await benchmark(false),await benchmark(true)]
  const target=path.resolve(__dirname,'../../outputs/direct86-20261118/frequency.json')
  fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,JSON.stringify({results},null,2))
  console.log(JSON.stringify({results,report:target},null,2))
})().catch(error=>{console.error(error);process.exitCode=1})
