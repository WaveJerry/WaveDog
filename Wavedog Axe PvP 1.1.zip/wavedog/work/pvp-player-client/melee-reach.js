// A player attacks from eye position toward an entity's hitbox. Centre-to-centre
// distance alone incorrectly rejects legal edge hits against a player hitbox.
function targetBoxDistance (bot, target) {
  const own = bot?.entity
  const eye = own?.position
  const at = target?.position
  if (!eye || !at || ![eye.x, eye.y, eye.z, own.eyeHeight,
    at.x, at.y, at.z, target.width, target.height].every(Number.isFinite)
      || target.width <= 0 || target.height <= 0) return Infinity
  const eyeY = eye.y + own.eyeHeight
  const dx = Math.max(0, Math.abs(eye.x - at.x) - target.width / 2)
  const dy = Math.max(0, at.y - eyeY, eyeY - (at.y + target.height))
  const dz = Math.max(0, Math.abs(eye.z - at.z) - target.width / 2)
  return Math.hypot(dx,dy,dz)
}
function targetBoxWithinReach (bot, target, reach = 3) {
  return Number.isFinite(reach) && reach > 0 && targetBoxDistance(bot,target) <= reach
}
module.exports = { targetBoxWithinReach, targetBoxDistance }
