'use strict'
// Adversarial TEST OPPONENT only. Never imported by WaveDog/Punengbho control.
const {nearestHitPoint}=require('./protocol-mechanical-math')
function eyeReach(position,eyeHeight,target){
  const eye={x:position.x,y:position.y+eyeHeight,z:position.z},point=nearestHitPoint(eye,target)
  return Math.hypot(point.x-eye.x,point.y-eye.y,point.z-eye.z)
}
function edgePlan({position,sentPosition,eyeHeight=1.62,target,tick,lastAttack,lastWeaponTick,weapon='sword'}){
  const reach=eyeReach(position,eyeHeight,target)
  const wireReach=sentPosition?eyeReach(sentPosition,eyeHeight,target):Infinity
  const age=Math.max(0,tick-Math.max(lastAttack,lastWeaponTick)),cooldown=weapon==='axe'?20:12.5
  const charge=Math.min(1,(age+.5)/cooldown)
  // Approach quickly while outside. Ground back/side movement close to the
  // boundary obeys normal player speed; no back-facing sprint cheat.
  const attack=reach<=3&&wireReach<=3&&charge>=.9
  const sprintStrike=attack&&reach>=2.7
  const forward=sprintStrike||reach>3.08?1:reach<2.91?-1:0
  return {reach,wireReach,charge,forward,sprint:forward>0,jump:false,
    // Earliest legal aim/contact. If an opponent penetrates the boundary,
    // still respond rather than refusing to attack until exactly 3.000.
    attack,
    edgeWindow:reach>=2.7&&reach<=3&&wireReach>=2.7&&wireReach<=3}
}
module.exports={edgePlan,eyeReach}
