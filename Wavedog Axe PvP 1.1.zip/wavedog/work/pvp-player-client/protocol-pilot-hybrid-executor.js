'use strict'
const pure=require('./protocol-pure-executor')
const mechanical=require('./protocol-pilot-mechanical-executor')
const {immediate}=require('./protocol-pilot-hybrid-brain')
function executeCommand(ctx){
  // Unassisted shieldless play executes the exact existing learned adapter.
  const result=(immediate(ctx.planned)?mechanical:pure).executeCommand(ctx)
  result.ignoredHeads=[...new Set([...result.ignoredHeads,...(ctx.planned.command.blockedModelHeads||[])])]
  return result
}
module.exports={executeCommand}
