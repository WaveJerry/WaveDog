'use strict'
function createPrecisionWait(wake){
  if(process.platform!=='win32')return {backend:'atomics',
    wait:(ms,value)=>Atomics.wait(wake,0,value,Math.max(0,ms)),close(){}}
  const koffi=require('koffi'),kernel=koffi.load('kernel32.dll')
  const create=kernel.func('void* __stdcall CreateWaitableTimerExW(void*, void*, uint32_t, uint32_t)')
  const set=kernel.func('int __stdcall SetWaitableTimer(void*, int64_t*, int32_t, void*, void*, int)')
  const wait=kernel.func('uint32_t __stdcall WaitForSingleObject(void*, uint32_t)')
  const close=kernel.func('int __stdcall CloseHandle(void*)')
  const current=kernel.func('void* __stdcall GetCurrentThread()')
  const getPriority=kernel.func('int __stdcall GetThreadPriority(void*)')
  const setPriority=kernel.func('int __stdcall SetThreadPriority(void*, int32_t)')
  // CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS. A dedicated
  // waitable timer avoids the Windows 15.6ms timeout quantization.
  const timer=create(null,null,2,0x1f0003)
  if(!timer)throw Error('High-resolution Windows waitable timer unavailable')
  const thread=current(),previousPriority=getPriority(thread),priorityRaised=Boolean(setPriority(thread,2))
  const now=()=>Number(process.hrtime.bigint())/1e6
  return {backend:'windows-high-resolution-waitable-timer',priorityRaised,
    wait(ms,value){
      if(ms<=0)return
      const deadline=now()+ms
      // Wake a bounded 0.3 ms early to absorb timer dispatch jitter. The short
      // final wait runs only on this dedicated worker, never the game thread.
      // Do not replay missed 2 ms observations in a burst after an OS stall.
      const due=-BigInt(Math.max(1,Math.round(Math.max(.001,ms-.3)*10000)))
      if(!set(timer,[due],0,null,null,0))throw Error('Failed to arm precision timer')
      if(wait(timer,1000)!==0)throw Error('Precision timer wait failed')
      while(now()<deadline){if(Atomics.load(wake,0)!==value)break}
    },close(){setPriority(thread,previousPriority);close(timer)}}
}
module.exports={createPrecisionWait}
