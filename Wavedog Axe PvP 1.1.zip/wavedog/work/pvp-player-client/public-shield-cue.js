// All inputs here come from ordinary client-visible use, animation and sound
// packets. The native referee is deliberately excluded from live control.
function shieldBlockSound (name) {
  return /(?:^|:)item[._]shield[._]block$/i.test(String(name || ''))
}
function creditedMeleeBlock (session, now, distance) {
  return session?.kind === 'human-challenge'
    && now - session.lastEffectiveShieldAt >= 0
    && now - session.lastEffectiveShieldAt <= 150
    && now - session.opponentSwingAt >= 0
    && now - session.opponentSwingAt <= 400
    && Number.isFinite(distance) && distance <= 3.5
}
module.exports = { shieldBlockSound, creditedMeleeBlock }
