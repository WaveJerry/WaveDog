"""Backfill full bout-tagged native events for recorded human challenges.

The referee log is read only. Existing archives are never replaced.
"""
from collections import defaultdict
from pathlib import Path
import json


BASE = Path(__file__).resolve().parent
STORE = BASE / 'new-learning' / 'selfplay'
CHALLENGES = STORE / 'human-challenges.jsonl'
ARCHIVE = STORE / 'human-native-events.jsonl'
REFEREE = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogSelfPlayGate/bouts.jsonl')


def rows(path):
    if not path.exists():
        return
    with path.open(encoding='utf-8') as stream:
        for line in stream:
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def main():
    archived = {row.get('matchId') for row in rows(ARCHIVE)}
    wanted = defaultdict(list)
    for report in rows(CHALLENGES):
        if report.get('matchId') in archived:
            continue
        trace = (report.get('native') or {}).get('trace') or []
        if len(trace) < 2 or trace[0][4] != 'start' or trace[-1][4] != 'end':
            continue
        wanted[(report['arena'], report['bout'], trace[0][0])].append(report)

    active = {}
    completed = []
    for event in rows(REFEREE):
        arena, bout = event.get('arena'), event.get('bout')
        if arena is None or bout is None or bout >= 0:
            continue
        key = (arena, bout)
        if event.get('type') == 'start':
            for report in wanted.get((arena, bout, event.get('at')), []):
                active[key] = (report, [])
        current = active.get(key)
        if current is None:
            continue
        report, events = current
        events.append(event)
        if event.get('type') == 'end':
            if event.get('at') == report['native']['trace'][-1][0]:
                completed.append({'at': report['at'], 'matchId': report['matchId'],
                                  'arena': arena, 'bout': bout, 'bot': report['bot'],
                                  'opponent': report['opponent'], 'observed': True,
                                  'events': events})
            del active[key]

    with ARCHIVE.open('a', encoding='utf-8') as stream:
        for record in completed:
            stream.write(json.dumps(record, ensure_ascii=False, separators=(',', ':')) + '\n')
    print(json.dumps({'archived': len(completed), 'events': sum(len(x['events']) for x in completed),
                      'unmatched': sum(map(len, wanted.values())) - len(completed)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
