'use strict'
const assert=require('node:assert/strict')
const hybrid=require('./protocol-pilot-hybrid-brain')
const {executeCommand}=require('./protocol-pilot-hybrid-executor')
const pure=require('./protocol-pure-executor')
const pureBrain=require('./protocol-pure-brain')
const {createDecisionDispatch}=require('./protocol-decision-dispatch')
const obs=(extra={})=>({tick:10,visible:true,ground:true,distance:8,reach:7.7,
  health:20,held:0,charge:1,shieldReady:false,shieldEffective:false,offhandShieldReady:false,
  wallMargin:8,targetShieldFacing:false,targetShieldRaised:false,loaded:false,arrows:10,
  self:{x:0,z:0},target:{x:0,z:-8},targetYaw:0,openingDraw:1,...extra})
const act=(extra={})=>({decidedTick:10,observedWeaponEpoch:0,slot:0,attack:false,forward:1,side:0,
  sprint:true,jump:false,sneak:false,shield:false,use:false,release:false,
  pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0,...extra})
function neural(){const s=hybrid.createState('target');s.mode='NEURAL';s.shieldUntil=100;return s}
function fixture(planned,o=obs({reach:2.5,distance:2.8})){
  const wire=[],controls={};let use=null
  const bot={quickBarSlot:o.held,food:20,inventory:{slots:[]},
    entity:{position:{x:0,y:0,z:0},yaw:0,pitch:0,eyeHeight:1.62,onGround:o.ground,velocity:{y:0}},
    get heldItem(){return {name:this.quickBarSlot===0?'diamond_sword':'diamond_axe'}},
    _client:{write:(name,data)=>wire.push({name,data})},
    setControlState(k,v){if(k==='sprint'&&Boolean(controls[k])!==v)this._client.write('entity_action',{actionId:v?3:4});controls[k]=v},
    getControlState:k=>Boolean(controls[k]),
    setQuickBarSlot(slot){this.quickBarSlot=slot;this._client.write('held_item_slot',{slot})},
    attack(){this._client.write('use_entity',{})},activateItem(){this._client.write('use_item',{})}}
  bot.inventory.slots[45]={name:'crossbow'}
  const ctx={bot,wire,tick:o.tick,weaponEpoch:0,lastAttackTick:-1000,shieldUntil:100,planned,
    session:{id:'hybrid',opponent:'target',state:neural(),attackedDecisions:new Set(),attackOwners:new Map()},
    target:{position:{x:0,y:0,z:-o.distance},width:.6,height:1.8},
    frame:{seen:{visible:true},self:{y:0,eyeY:1.62,critical:Boolean(o.critical)},observation:o,targetVelocity:{}},
    getUse:()=>use,setUse:v=>{use=v},
    stopUse(){if(use)bot._client.write('block_dig',{status:5});use=null},
    offhand(name){bot.inventory.slots[45]={name};return true},ownLoaded:()=>o.loaded,clearPath:()=>true,charge:()=>o.charge,
    getSentPosition:()=>({...bot.entity.position}),plugin:row=>bot._client.write('custom_payload',row),
    onSwitch(){ctx.weaponEpoch++},onAttack(){ctx.lastAttackTick=ctx.tick},
    look(yaw,pitch){bot.entity.yaw=yaw;bot.entity.pitch=pitch;bot._client.write('look',{yaw,pitch})},
    aim(target,kind){ctx.look((kind?.includes('crossbow')||kind==='bow')?.4:0,0)}}
  return ctx
}
// With no helper active, ALL learned melee packet decisions stay identical.
for(const input of [act({attack:true}),act({attack:true,sprint:false,jump:true}),
  act({aimYawOffset:180,flightLook:true,attack:true}),act({forward:-1,side:1,sprint:false}),
  act({slot:7,attack:true}),act({aimYawOffset:90,attack:false})]){
  const o=obs({reach:2.5,distance:2.8}),s=neural()
  const p=hybrid.refreshNeuralPlan(hybrid.plan(s,o,null),o,input)
  assert(!hybrid.immediate(p))
  const a=fixture(p,o),b=fixture(pureBrain.plan(null,o,input),o)
  const x=executeCommand(a),y=pure.executeCommand(b)
  assert.deepEqual(a.wire,b.wire,'mechanical composition must not change a learned melee packet')
  assert.deepEqual(x.controls,y.controls)
  assert.deepEqual(x.ignoredHeads,y.ignoredHeads)
}
let s=neural(),o=obs(),p=hybrid.plan(s,o,act({slot:4,use:true,shield:true}))
p=hybrid.refreshNeuralPlan(p,o,act({slot:4,use:true,shield:true}))
assert(!p.command.use&&!p.command.shield&&p.command.slot===0)
assert.deepEqual(p.command.blockedModelHeads,[4,5])
assert(executeCommand(fixture(p)).ignoredHeads.includes(4),'offhand override never gets PPO action credit')
// A delayed model reply does not delay guard/shot synchronization.
s=hybrid.createState('target');o=obs({shieldReady:true,shieldEffective:true,held:7})
p=hybrid.plan(s,o,null);let executions=0
const dispatch=createDecisionDispatch(()=>executions++)
dispatch.open({tick:10,matchId:'m',requestId:1})
if(hybrid.immediate(p))dispatch.deadline(null)
assert.equal(executions,1)
assert(!dispatch.reply({decidedTick:10,requestId:1},'m',10),'late inference cannot execute a second command')
// Missing charged-equipment packet gets a bounded grace, never a new load.
s=neural();p=hybrid.plan(s,obs({targetLoading:true}),act({slot:7}))
assert.equal(p.command.ranged,'load-crossbow');assert.equal(p.command.slot,0)
hybrid.rangedApplied(s,p.command,{useStarted:true},10)
for(const tick of [11,12]){
 p=hybrid.plan(s,obs({tick,targetLoading:false,targetLoadResult:'unconfirmed',targetLoadEndedAt:11}),act({decidedTick:tick,slot:7}))
 assert.equal(p.command.ranged,'load-crossbow')
 const x=fixture(p,obs({tick}));x.setUse({kind:'crossbow',tick:10});executeCommand(x)
 assert.equal(x.getUse().tick,10);assert(!x.wire.some(q=>['held_item_slot','block_dig'].includes(q.name)))
}
p=hybrid.plan(s,obs({tick:14,targetLoadResult:'unconfirmed',targetLoadEndedAt:11}),null)
assert.equal(p.command.ranged,null,'a cancelled load cannot be sustained indefinitely')
p=hybrid.plan(neural(),obs({targetKnownLoaded:true,targetLoadResult:'unconfirmed',targetLoadEndedAt:10}),null)
assert.equal(p.command.ranged,null,'already-loaded enemy never starts an autonomous load')
// Incoming arrow + mirrored loaded crossbow: fire once, dodge, restore view.
s=neural();o=obs({loaded:true,targetShotEvent:1,targetShotTick:10,arrowThreat:{time:1,side:-1}})
p=hybrid.plan(s,o,act());assert.equal(p.command.ranged,'fire-crossbow')
let x=fixture(p,o);x.bot.entity.yaw=1.3
let result=executeCommand(x)
assert(result.rangedResult.fireSent&&result.controls.left)
assert.equal(x.bot.entity.yaw,1.3)
assert(x.wire.findIndex(q=>q.name==='look'&&q.data.yaw===.4)<x.wire.findIndex(q=>q.name==='use_item'))
hybrid.rangedApplied(s,p.command,result.rangedResult,10)
p=hybrid.plan(s,obs({tick:11,loaded:true,targetShotEvent:1,targetShotTick:10}),act({decidedTick:11}))
assert.equal(p.command.ranged,null,'same shot cannot fire twice while equipment acknowledgment lags')
assert(!hybrid.plan(neural(),obs({loaded:true}),null).command.ranged,'no opening bolt without a shot')
let shieldBow=hybrid.createState('target')
let shieldBowPlan=hybrid.plan(shieldBow,obs({shieldReady:true,shieldEffective:true,
  offhandShieldReady:true,targetBow:true,targetBowCycle:1}),null)
assert(shieldBowPlan.command.shield&&!shieldBowPlan.command.ranged,'usable shield does not mirror bow draw')
shieldBow=neural()
shieldBowPlan=hybrid.plan(shieldBow,obs({targetBow:true,targetBowCycle:1}),act())
assert.equal(shieldBowPlan.command.ranged,'bow','shieldless period retains bow synchronization')
hybrid.rangedApplied(shieldBow,shieldBowPlan.command,{useStarted:true},10)
shieldBow.shieldUntil=11
shieldBowPlan=hybrid.plan(shieldBow,obs({tick:11,shieldReady:true,mutualOutOfReach:true,targetBow:true,targetBowCycle:1}),act({decidedTick:11}))
assert(shieldBowPlan.command.shield&&!shieldBowPlan.command.ranged&&!shieldBowPlan.command.rangedRelease,
  'shield recovery cancels an ongoing draw without firing')
// Equipment can change between observation and inventory/interaction packets.
o=obs({targetLoading:true});p=hybrid.plan(neural(),o,act());x=fixture(p,o)
x.offhandLoaded=()=>true;result=executeCommand(x)
assert(result.rangedResult.loadAlreadyConfirmed)
assert(!x.wire.some(q=>q.name==='use_item'),'LOAD must never fire an already-loaded actual offhand')
o=obs({loaded:true,targetShotEvent:1,targetShotTick:10});p=hybrid.plan(neural(),o,act());x=fixture(p,o)
x.offhandLoaded=()=>false;result=executeCommand(x)
assert.equal(result.rangedResult.fireRejected,'offhand-crossbow-not-loaded')
assert(!x.wire.some(q=>q.name==='use_item'),'FIRE must never initiate a new load')
const {endUse}=require('./protocol-pilot-use'),cancelPackets=[]
const useBot={usingHeldItem:true,_client:{write:(n,d)=>cancelPackets.push([n,d])},deactivateItem(){cancelPackets.push(['release'])}}
endUse(useBot,{kind:'bow'})
assert.deepEqual(cancelPackets.map(p=>p[1]?.status),[6,6],'cancel bow without RELEASE_USE_ITEM')
cancelPackets.length=0;endUse(useBot,{kind:'bow'},true)
assert.deepEqual(cancelPackets,[['release']],'only a selected synchronized shot releases the bow')
// Native stop confirmation is required before restoring a cancelled bow.
// The new ordinary inventory operation must leave the mainhand untouched.
const {createBowCancellation}=require('./protocol-pilot-use')
let cancelTick=30,ownUse={serverTick:300,receivedTick:30,using:true,activeItem:'BOW'}
const swaps=[],cancelEvents=[],cancelKit={quickBarSlot:7,usingHeldItem:true,
  inventory:{slots:Array(46).fill(null),items(){return this.slots.filter(Boolean)}},
  _client:{write(){throw Error('offhand cancellation must not send swap-hands or release')}},
  deactivateItem(){throw Error('cancel must not release a drawn bow')}}
cancelKit.inventory.slots[43]={name:'diamond_axe',slot:43}
cancelKit.inventory.slots[37]={name:'shield',slot:37}
cancelKit.inventory.slots[45]={name:'bow',slot:45}
const cancellation=createBowCancellation({getBot:()=>cancelKit,getTick:()=>cancelTick,getNative:()=>ownUse,
  isSwitching:()=>false,onEvent:(kind,value)=>cancelEvents.push({kind,...value}),
  swapItem(item){swaps.push(item.name);const old=cancelKit.inventory.slots[45];
    cancelKit.inventory.slots[45]={...item,slot:45};cancelKit.inventory.slots[item.slot]={...old,slot:item.slot}}})
const cancelResult=endUse(cancelKit,{kind:'bow'},false,()=>cancellation.begin())
assert(cancelResult.pending&&!cancelResult.released&&!cancelResult.cancelled)
assert.deepEqual(swaps,['shield']);assert.equal(cancelKit.quickBarSlot,7)
assert.equal(cancelKit.inventory.slots[43].name,'diamond_axe')
assert(!cancellation.poll(),'local inventory prediction is not native stop confirmation')
cancelTick=31;assert(!cancellation.poll(),'stale native state cannot confirm cancellation')
ownUse={serverTick:301,receivedTick:31,using:true,activeItem:'BOW'}
assert(!cancellation.poll(),'still drawing means no restore even after a tick')
cancelTick=32;ownUse={serverTick:302,receivedTick:32,using:false,activeItem:'AIR'}
assert(cancellation.poll());assert(!cancelKit.usingHeldItem)
assert.deepEqual(cancelEvents.map(e=>e.kind),['requested','confirmed'])
assert.equal(swaps.length,1,'do not immediately swap back and erase the cancellation')
// Bow stays drawn despite neural slot proposals and releases on a real shot.
s=neural();o=obs({targetBow:true});p=hybrid.plan(s,o,act({slot:7}))
x=fixture(p,o);x.bot.inventory.slots[45]={name:'bow'};result=executeCommand(x)
hybrid.rangedApplied(s,p.command,result.rangedResult,10)
assert.equal(x.getUse().kind,'bow')
o=obs({tick:11,targetBow:true});p=hybrid.plan(s,o,act({decidedTick:11,slot:7}));x.tick=11;x.planned=p;x.frame.observation=o
executeCommand(x);assert.equal(x.getUse().tick,10)
o=obs({tick:12,targetShotEvent:1,targetShotTick:12});p=hybrid.plan(s,o,act({decidedTick:12,aimYawOffset:180}));x.tick=12;x.planned=p;x.frame.observation=o
result=executeCommand(x);assert(result.rangedResult.bowReleased);assert.equal(x.getUse(),null)
assert(Math.abs(Math.cos(x.bot.entity.yaw)+1)<1e-6)
// Reproduce the live 8-tick dead time without inventing a new draw from a
// projectile event or stale metadata. Both public edges can share one tick.
const {observeBowUse,noteBowShot}=require('./protocol-pilot-bow-observation')
const publicBow={},bowInput={visible:true,using:true,activeItem:{name:'bow'}}
let cycle=observeBowUse(publicBow,bowInput,20)
s=neural();o=obs({tick:20,targetBow:true,...cycle});p=hybrid.plan(s,o,act({decidedTick:20}))
assert.equal(p.command.ranged,'bow');hybrid.rangedApplied(s,p.command,{useStarted:true},20)
o=obs({tick:40,targetBow:true,targetShotEvent:1,targetShotTick:40,...cycle})
p=hybrid.plan(s,o,act({decidedTick:40}))
assert(p.command.rangedRelease);hybrid.rangedApplied(s,p.command,{bowReleased:true},40)
o=obs({tick:41,targetBow:true,targetShotEvent:1,targetShotTick:40,...cycle})
p=hybrid.plan(s,o,act({decidedTick:41}))
assert.equal(p.command.ranged,null,'stale pre-release draw must not restart use')
observeBowUse(publicBow,{...bowInput,using:false},41)
cycle=observeBowUse(publicBow,bowInput,41)
assert.equal(cycle.targetBowCycle,2,'two same-tick packets preserve the next draw')
o=obs({tick:42,targetBow:true,targetShotEvent:1,targetShotTick:40,...cycle})
p=hybrid.plan(s,o,act({decidedTick:42}))
assert.equal(p.command.ranged,'bow','fresh draw resumes before the old 8-tick timer')
assert(!p.command.rangedRelease,'previous shot cannot release the new draw')
hybrid.rangedApplied(s,p.command,{useStarted:true},42)
observeBowUse(publicBow,{...bowInput,using:false},45)
p=hybrid.plan(s,obs({tick:45,targetBow:false,targetShotEvent:1,targetShotTick:40,...cycle}),null)
assert.equal(p.command.ranged,null,'cancelled opponent draw cancels the mirror')
assert.equal(observeBowUse({}, {...bowInput,visible:false},50).targetBowCycle,0,'hidden use is not an observation')
const coalesced={}
assert.equal(observeBowUse(coalesced,bowInput,60).targetBowCycle,1)
noteBowShot(coalesced,80)
assert.equal(observeBowUse(coalesced,bowInput,80).targetBowCycle,1,'shot-tick old use cannot create a draw')
assert.equal(observeBowUse(coalesced,bowInput,81).targetBowCycle,2,'confirmed shot separates draws even without a sampled stop bit')
noteBowShot(coalesced,100)
observeBowUse(coalesced,{...bowInput,using:false},101)
assert.equal(coalesced.bowCycle,2,'a released bow never starts itself without observed use')
// Direct counter packet handoff, no mechanical hop, safe warm-up return.
s=hybrid.createState('target');hybrid.receipt(s,{type:'blocked_melee',blockId:1},10)
hybrid.receipt(s,{type:'shield_disabled',cooldownTicks:100},10)
p=hybrid.plan(s,obs({held:7,charge:.4,reach:.8,distance:1.1}),act({slot:0}))
assert.equal(p.mode,'NEURAL','an unusable counter must not hold shieldless movement for six ticks')
assert.equal(p.owners.mainhand,'neural');assert.equal(p.command.slot,0)
s=hybrid.createState('target');hybrid.receipt(s,{type:'blocked_melee',blockId:1},10)
hybrid.receipt(s,{type:'shield_disabled',cooldownTicks:100},10)
p=hybrid.plan(s,obs({held:7,reach:2.5,distance:2.8}),null)
assert.equal(p.command.kind,'counter');hybrid.applied(s,p.command,true,10)
hybrid.receipt(s,{type:'damage',attacker:'Punengbho',victim:'target',attackId:p.command.attackId,amount:2},11)
assert.equal(s.mode,'NEURAL')
p=hybrid.plan(s,obs({tick:11}),act({decidedTick:11,jump:false}))
assert(!p.command.jump&&!p.command.aimAway&&p.command.slot===0)
hybrid.applied(s,p.command,false,11)
p=hybrid.plan(s,obs({tick:12,ground:false,mutualOutOfReach:true}),act({decidedTick:12}))
assert.equal(p.mode,'NEURAL');assert(!p.command.aimAway)
p=hybrid.plan(s,obs({tick:111,shieldReady:true,mutualOutOfReach:true}),null);assert.equal(p.mode,'SHIELD_RETURN');assert(p.command.shield)
p=hybrid.plan(s,obs({tick:112,shieldReady:true,shieldEffective:false}),null);assert.equal(p.mode,'SHIELD_RETURN')
p=hybrid.plan(s,obs({tick:116,shieldReady:true,shieldEffective:true}),null);assert.equal(p.mode,'GUARD')
console.log('PILOT_HYBRID_SYNC_PASS: exact neural packets, no offhand credit, immediate mechanics, bounded load grace, shot+dodge, bow continuity, native handoff')
