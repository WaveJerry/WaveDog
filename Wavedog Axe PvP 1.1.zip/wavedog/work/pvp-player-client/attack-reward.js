// Reward only observed results. These are PPO feedback values, never action rules.
const clamp = (value, low, high) => Math.max(low, Math.min(high, value))

function swingFeedback (charge, hitTarget) {
  const speedCost = Number.isFinite(charge)
    ? -.045 * .8 * (1 - Math.pow(clamp(charge, 0, 1), 2)) : 0
  // Vanilla's ordinary base-damage multiplier grows with charge squared and
  // saturates at full charge. This small opportunity cost leaves a useful
  // light hit positive when real damage or a shield break outweighs it.
  // A miss is a real swing and resets attack charge even when no attack packet is sent.
  return speedCost + (hitTarget ? 0 : -.018)
}

function damageFeedback (event, attackDistance, attackReach) {
  if (event.cancelled || !(event.amount > 0)) return 0
  const base = event.amount / 20
  if (event.source !== 'MELEE') return base
  const critical = event.native_critical === true ? base * .3 : 0
  // New samples use eye-to-AABB distance measured when the attack is sent.
  // Legacy centre distances remain a separate, backwards-compatible signal.
  // Position alone, a swing, or a client-predicted hit never earns damage credit.
  const edge = attackReach !== undefined
    ? Number.isFinite(attackReach) && attackReach >= 0 && attackReach <= 3
      ? .035 * Math.pow(clamp((attackReach - 2.7) / .3, 0, 1), 2) : 0
    : Number.isFinite(attackDistance)
      ? .035 * clamp((attackDistance - 2.65) / .55, 0, 1) : 0
  return base + critical + edge
}

function hungerFeedback (previousFood, currentFood) {
  if (!Number.isFinite(previousFood) || !Number.isFinite(currentFood)) return 0
  if (currentFood >= previousFood) return 0
  // Food updates are delayed by saturation. Keep this cost small beside a hit
  // or a win; never infer that one individual movement caused the entire loss.
  return -.025 * clamp(previousFood - currentFood, 0, 20)
}

module.exports = { swingFeedback, damageFeedback, hungerFeedback }
