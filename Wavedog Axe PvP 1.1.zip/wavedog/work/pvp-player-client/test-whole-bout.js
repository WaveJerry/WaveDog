const assert = require('node:assert/strict')
const { wholeBout } = require('./whole-bout')

const start = Date.parse('2026-11-13T00:00:00Z')
const frame = (second, distance, health) => ({
  at: new Date(start + second * 1000).toISOString(),
  self: { x: 0, y: 0, z: 0, health, shielding: second === 0 },
  seen: { x: distance, y: 0, z: 0, vy: 0, shield: false }
})
const summary = wholeBout('NBot01', 'NBot02',
  [frame(0, 6, 20), frame(1, 2.8, 20), frame(2, 4.5, 16)],
  [{ at: new Date(start + 1000).toISOString(), selected: { shield: false },
    executed: { attackPackets: 1, back: false, forward: true } }],
  [{ at: new Date(start + 1000).toISOString(), type: 'damage', attacker: 'NBot01',
    victim: 'NBot02', amount: 3, source: 'MELEE' }], 3)
assert.equal(summary.durationMs, 2000)
assert.equal(summary.phases.length, 3)
assert.deepEqual(summary.phases.map(phase => phase[0]), [0, 1, 2])
const hits = summary.phases[1]
assert.equal(hits[summary.columns.indexOf('attacksSent')], 1)
assert.equal(hits[summary.columns.indexOf('dealt')], 3)
assert.equal(summary.phases[2][summary.columns.indexOf('healthEnd')], 16)
assert.deepEqual(summary.phases.map(phase => phase[summary.columns.indexOf('dominantStage')]),
  ['RANGED','MELEE','RANGED'])
assert.equal(summary.stageTotals.RANGED.frames, 2)
assert.equal(summary.stageTotals.MELEE.frames, 1)
assert.equal(summary.stageTotals.MELEE.attackPackets, 1)
assert.equal(summary.stageTotals.MELEE.meleeHits, 1)
assert.equal(summary.stageTotals.MELEE.dealt, 3)
assert.deepEqual(summary.stageTransitions.map(row => row.stage),
  ['RANGED','MELEE','RANGED'])
const at = ms => new Date(start + ms).toISOString()
const shieldFrame = (ms, distance, shielding) => ({ at: at(ms),
  self: { x: 0, y: 0, z: 0, health: 20, shielding },
  seen: { x: distance, y: 0, z: 0, vy: 0, shield: false } })
const stages = wholeBout('A', 'B', [
  shieldFrame(0, 2.7, true), shieldFrame(50, 2.7, false),
  shieldFrame(100, 7, false)], [
  { at: at(0), selected: { shield: true }, executed: { attackPackets: 0 } },
  { at: at(50), selected: { attack: true }, executed: { attackPackets: 1 } },
  { at: at(100), selected: { slot: 4, use: true }, executed: { attackPackets: 0 } }
], [
  { at: at(0), type: 'damage', source: 'MELEE', attacker: 'B', victim: 'A',
    amount: 0, victim_blocking: true, shield_modifier: -7 },
  { at: at(50), type: 'damage', source: 'MELEE', attacker: 'A', victim: 'B', amount: 4 },
  { at: at(100), type: 'arrow_launch', shooter: 'A' },
  { at: at(100), type: 'damage', source: 'ARROW', attacker: 'B', victim: 'A', amount: 2 },
  { at: at(1000), type: 'damage', source: 'MELEE', attacker: 'A', victim: 'B', amount: 9 }
])
assert.equal(stages.stageTotals.STANDOFF.blocked, 1)
assert.equal(stages.stageTotals.STANDOFF.meleeHits, 0)
assert.equal(stages.stageTotals.MELEE.attackPackets, 1)
assert.equal(stages.stageTotals.MELEE.meleeHits, 1)
assert.equal(stages.stageTotals.RANGED.arrowsOut, 1)
assert.equal(stages.stageTotals.RANGED.arrowHits, 1)
assert.equal(stages.stageTotals.RANGED.rangedUseActions, 1)
assert.equal(stages.stageTotals.RANGED.meleeHits, 0)
console.log('WHOLE_BOUT_PASS chronological frame and native result')
