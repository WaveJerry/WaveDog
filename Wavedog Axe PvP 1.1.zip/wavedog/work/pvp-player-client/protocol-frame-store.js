'use strict'
const fs=require('node:fs')
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms))
// Windows readers can briefly deny rename. Keep the completed file durable,
// retry without blocking physics, and never discard the original append log.
async function saveCompletedFrames(file,frames,io=fs.promises,wait=delay){
  const completed=file+'.complete'
  await io.writeFile(completed,frames.map(f=>JSON.stringify(f)+'\n').join(''))
  for(let attempt=0;attempt<12;attempt++){
    try{await io.rename(completed,file);return {path:file,canonical:true,retries:attempt}}
    catch(error){
      if(!['EPERM','EACCES','EBUSY'].includes(error.code))throw error
      await wait(Math.min(200,25*(attempt+1)))
    }
  }
  return {path:completed,canonical:false,retries:12}
}
module.exports={saveCompletedFrames}
