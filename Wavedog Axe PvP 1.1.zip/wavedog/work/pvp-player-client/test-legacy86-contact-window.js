'use strict'
const assert=require('node:assert/strict')
const {planSpacing,route,eyeBoxReach}=require('./protocol-legacy86-threat')
const {createRouteProbe}=require('./protocol-legacy86-route')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {executeCommand}=require('./protocol-legacy86-executor')
const {createOutputGate}=require('./protocol-legacy86-output-gate')
const {frame,probe,executorFixture}=require('./test-legacy86-control')
const {Physics,PlayerState}=require('prismarine-physics')
const {Vec3}=require('vec3')
const flatProbe=y=>createRouteProbe({origin:{x:1122,y,z:956},blockAt:(x,by,z)=>({shapes:by<y?[[0,0,0,1,1,1]]:[]})})
async function run(){
  const mcData=require('minecraft-data')('1.21.1'),Block=require('prismarine-block')('1.21.1')
  const world={getBlock:pos=>{
    const block=new Block(pos.y<0?mcData.blocksByName.stone.id:mcData.blocksByName.air.id,0,0)
    block.position=pos;return block
  }}
  const physics=Physics(mcData,world),controls={forward:false,back:false,left:false,right:false,
    jump:true,sprint:false,sneak:false}
  const bot={entity:{position:new Vec3(0,0,0),velocity:new Vec3(0,0,0),onGround:true,
    isInWater:false,isInLava:false,isInWeb:false,isCollidedHorizontally:false,isCollidedVertically:false,
    elytraFlying:false,yaw:0,pitch:0,effects:{}},jumpTicks:0,jumpQueued:false,
    fireworkRocketDuration:0,version:'1.21.1',inventory:{slots:[]}}
  let landings=0
  for(let tick=0;tick<40;tick++){
    const previousGround=bot.entity.onGround
    physics.simulatePlayer(new PlayerState(bot,controls),world).apply(bot)
    if(previousGround)assert(bot.entity.position.y>0,'held jump relaunches on the first physics step after landing')
    else if(bot.entity.onGround)landings++
  }
  assert(landings>=3,'real client physics must complete repeated jumps, not just contain a jump flag')
  // Actual public geometry from bout 1 tick 14042. This is a short motion
  // replay over an explicitly synthetic flat floor, not a live result.
  const f=frame({self:{x:1121.9132991575339,y:221,z:956.3292939708845,
    vx:-.045142612155503956,vy:-.0784,vz:.10327139596809787},
    seen:{x:1122.7239409536382,y:221,z:959.6699246727442},
    targetVelocity:{x:-.0854910851689772,y:0,z:-.15352720958065205},
    observation:{reach:3.083211006243424,otherReach:3.083211006243424,distance:3.437579614757896},
    previousHeading:{x:-.1628566827563814,z:.9866497356618443},
    latency:{oneWayMs:25,serverQueueMs:50,decisionMs:4,observationAgeMs:0}})
  const spacing=planSpacing(f,flatProbe(221))
  assert.equal(spacing.localDelayTicks,0,'server attack latency must not delay local movement prediction')
  assert(spacing.firstContactTick>=1&&spacing.firstContactReach>=2.90&&spacing.firstContactReach<=3)
  const travel=route(f.self,spacing.heading,spacing.firstContactTick,flatProbe(221))
  const predicted=eyeBoxReach(travel.points.at(-1),{...f.seen,
    x:f.seen.x+f.targetVelocity.x*spacing.firstContactTick,z:f.seen.z+f.targetVelocity.z*spacing.firstContactTick})
  assert(Math.abs(predicted-spacing.firstContactReach)<1e-10)
  const far=frame({self:{x:1002,y:221,z:1014},seen:{x:992,y:221,z:1014},
    observation:{reach:9.7,otherReach:9.7,distance:10}})
  const centerProbe=createRouteProbe({origin:far.self,blockAt:(x,y,z)=>({shapes:y<221?[[0,0,0,1,1,1]]:[]})})
  const recovery=planSpacing(far,centerProbe)
  assert(recovery.heading.x>.5,'far unshielded recovery prefers arena centre, not a fixed enemy-distance ring')
  assert.equal(recovery.objective,'arena-center')
  const gate=createOutputGate()
  gate.permit({slot:0,attack:false},0)
  assert(gate.permit({slot:0,attack:false,spacingUrgent:true,decidedTick:100},2))
  assert(!gate.permit({slot:0,attack:false,spacingUrgent:true,decidedTick:100},4),
    'one timely spacing transition must not turn into 500Hz output')

  const direct=createBrain({planner:{evaluate:async()=>{throw Error('legal contact waited for route search')}}})
  await direct.ready
  try{
    const s=createState('enemy');s.swordOnly=true;await direct.reset(s,123)
    const p=await direct.decide(s,frame(),probe,100)
    assert(p.contactTiming.directContact&&p.command.attack)
    assert.equal(p.command.worldHeading,undefined,'ready edge strike must retain original forward sprint input')
  }finally{await direct.close()}

  const brain=createBrain();await brain.ready
  try{
    const s=createState('enemy');s.swordOnly=true;await brain.reset(s,123)
    const close=over=>frame({seen:{x:1.5},observation:{reach:1.2,otherReach:1.2,distance:1.5},...over})
    const submit=(p,f,tick)=>{
      const ctx=executorFixture(p,f);ctx.tick=tick;ctx.target.position={x:f.seen.x,y:f.seen.y,z:f.seen.z}
      ctx.charge=()=>f.self.charge
      const actual=executeCommand(ctx);brain.applied(s,p.command,actual,tick)
      for(const a of actual.attacks)brain.receipt(s,{type:'damage',attacker:'Punengbho',victim:'enemy',
        melee:true,amount:1,nativeCritical:Boolean(p.command.critical),attackId:a.id},tick)
      return actual
    }
    const start=close({observation:{tick:100,reach:1.2,otherReach:1.2,distance:1.5}})
    const opening=await brain.decide(s,start,probe,100)
    assert.equal(opening.selectedBranch,'close-sword-dps')
    assert(opening.command.attack&&opening.command.jump&&!opening.command.critical)
    assert(submit(opening,start,100).attacked)
    assert(s.closeFight.firstHitDone)
    const rise=close({self:{ground:false,vy:.3,charge:.1},
      observation:{tick:101,reach:1.2,otherReach:1.2,distance:1.5},targetMotion:{sampleTick:101}})
    const rising=await brain.decide(s,rise,probe,101)
    assert(rising.command.jump&&!rising.command.attack,'held jump does not mean spam attacks during ascent')
    for(const tick of [107,119]){
      const fall=close({self:{ground:false,vy:-.2,critical:true,charge:1},
        observation:{tick,reach:1.2,otherReach:1.2,distance:1.5},targetMotion:{sampleTick:tick}})
      const critical=await brain.decide(s,fall,probe,tick)
      assert(critical.command.jump&&critical.command.attack&&critical.command.critical&&!critical.command.sprint)
      assert(submit(critical,fall,tick).attacked)
      if(tick===107){
        const land=close({self:{ground:true,charge:.4},
          observation:{tick:112,reach:1.2,otherReach:1.2,distance:1.5},targetMotion:{sampleTick:112}})
        const landing=await brain.decide(s,land,probe,112)
        assert(landing.command.jump&&!landing.command.attack,'landing retains jump for the next cycle without a new opener')
      }
    }
    const exit=frame({seen:{x:3.2},self:{charge:.4,vx:-.1},targetVelocity:{x:.2,y:0,z:0},
      observation:{tick:124,reach:2.9,otherReach:2.9,distance:3.2},targetMotion:{sampleTick:124}})
    const last=await brain.decide(s,exit,probe,124)
    assert.equal(last.selectedBranch,'close-exit-hit');assert(last.command.attack&&!last.command.jump)
    submit(last,exit,124)
    const separated=frame({seen:{x:3.5},observation:{tick:125,reach:3.2,otherReach:3.2,distance:3.5},
      targetMotion:{sampleTick:125}})
    const left=await brain.decide(s,separated,probe,125)
    assert.equal(s.closeFight,null);assert(!left.command.attack)
    const shield=close({observation:{tick:130,reach:1.2,otherReach:1.2,distance:1.5,
      targetShieldRaised:true,targetShieldFacing:true},targetMotion:{sampleTick:130}})
    const stun=await brain.decide(s,shield,probe,130)
    assert(stun.command.doubleAttack&&stun.command.jump&&stun.command.slot===7)
    const pair=submit(stun,shield,130)
    assert.equal(pair.attacks.length,2);assert.equal(pair.held,0,'stun returns to sword synchronously')
    const after=close({self:{ground:false,critical:true,vy:-.1,charge:.3},
      observation:{tick:135,reach:1.2,otherReach:1.2,distance:1.5},targetMotion:{sampleTick:135}})
    const fallback=await brain.decide(s,after,probe,135)
    assert(fallback.command.attack&&!fallback.command.critical&&fallback.command.jump,
      'a post-stun falling window uses its legal ordinary hit instead of waiting through the whole combo')
  }finally{await brain.close()}

  const punish=createBrain();await punish.ready
  try{
    const s=createState('enemy');s.swordOnly=true;await punish.reset(s,123)
    const arriving=frame({seen:{x:1.6,y:.6},targetVelocity:{x:-.1,y:-.2,z:0},
      observation:{reach:1.3,otherReach:1.3,distance:1.6,targetAirborne:true,targetGrounded:false}})
    const p=await punish.decide(s,arriving,probe,100)
    assert(s.closeFight&&p.command.jump&&!p.command.attack,
      'an unavoidable descending critical is met with a jump/punish preparation, not another ordinary-hit-for-critical opener')
  }finally{await punish.close()}

  // At an edge distance, a genuine safe dodge still precedes a late-ascent
  // trade. The point-blank DPS instruction must not annex edge defence.
  const air={valid:true,threat:true,action:'dodge',risingTail:true,criticalTicks:[0],envelope:[{radius:.1}],
    route:{heading:{x:-1,z:0},sprint:true,safe:true,clearance:3.5}}
  const result={phase:'AIR_INTERRUPT',counterHopActive:false,hasPendingAttack:false,
    decision:{motion:'FORWARD',sprint:true,jump:false,sneak:false,attack:true,shield:false,
      faceAway:false,offhand:'SHIELD',weapon:'SWORD',technique:'AXE_EARLY'}}
  const b=createBrain({runtime:{request:async row=>row.command==='reset'?{}:structuredClone(result),close:async()=>{}},
    planner:{evaluate:async()=>({airPlan:structuredClone(air),spacing:null})}})
  await b.ready
  try{
    const s=createState('enemy');s.swordOnly=true;await b.reset(s,123)
    const p=await b.decide(s,frame({seen:{x:3.1,y:.6},targetVelocity:{x:0,y:-.1,z:0},
      observation:{reach:2.8,targetAirborne:true,targetGrounded:false}}),probe,100)
    assert(!s.closeFight&&!p.command.attack&&!p.command.jump)
  }finally{await b.close()}
  console.log('FIRST_CONTACT_BAND_CENTER_DIRECT_STRIKE_AND_CLOSE_SWORD_DPS_PASS')
}
run().catch(e=>{console.error(e);process.exitCode=1})
