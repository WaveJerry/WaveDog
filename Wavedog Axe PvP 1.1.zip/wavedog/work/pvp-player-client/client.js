// Two ordinary Minecraft 1.21.1 protocol clients for supervised mechanics checks.
// Input delay is applied before client controls and packets, not inside Paper.
const mineflayer = require('mineflayer')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const readline = require('node:readline')
const childProcess = require('node:child_process')
const mcData = require('minecraft-data')('1.21.1')
const { Vec3 } = require('vec3')
const { RaycastIterator } = require('prismarine-world').iterators
const { FullPacketParser } = require('protodef')

// Identify protocol packets discarded by ProtoDef without logging packet data.
const parsePacketBuffer = FullPacketParser.prototype.parsePacketBuffer
FullPacketParser.prototype.parsePacketBuffer = function (buffer) {
  try { return parsePacketBuffer.call(this, buffer) } catch (error) {
    if (error.partialReadError) console.error(JSON.stringify({ event: 'protocol_partial_packet',
      packetIdPrefix: buffer.subarray(0, 3).toString('hex'), bytes: buffer.length,
      error: error.message.slice(0, 180) }))
    throw error
  }
}

const host = process.env.MC_HOST || '127.0.0.1'
const port = Number(process.env.MC_PORT || 25566)
const names = [process.env.MC_BOT_A || 'WPlayer01', process.env.MC_BOT_B || 'WPlayer02']
const authFile = path.join(__dirname, '.auth-local.json')
const credentials = fs.existsSync(authFile) ? JSON.parse(fs.readFileSync(authFile, 'utf8')) : {}
for (const name of names) credentials[name] ||= crypto.randomBytes(18).toString('hex')
fs.writeFileSync(authFile, JSON.stringify(credentials), { mode: 0o600 })

const clients = new Map()
let humanGateToken = null
try { humanGateToken = fs.readFileSync(path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server', 'plugins', 'WaveDogDuelGate', 'duel-token.txt'), 'utf8').trim() } catch {}
const modelClasspath = [path.join(__dirname, 'bridge-classes'), path.join(__dirname, '..', 'pvp-neural-lab', 'classes'),
  path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server', 'versions', '1.21.1', 'paper-1.21.1.jar'),
  path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server', 'libraries', 'com', 'google', 'code', 'gson', 'gson', '2.10.1', 'gson-2.10.1.jar')].join(path.delimiter)
const modelJava = path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server', 'runtime', 'java21', 'bin', 'java.exe')
let gru = null, gruReady = false, modelLine = '', nextModelRequest = 0, pendingModelRequest = null, modelDecision = null
let coachFocus = 'FREE', coachReason = '', coachReady = false, coachOpponent = null
const focusNames = new Set(['FREE','CHARGE','SHIELD','AXE_BREAK','CRITICAL','SPRINT_KB','ESCAPE','SYNC','FLANK','COMBO','BOW','CROSSBOW','DODGE','WALL','LATENCY','OPPONENT'])
async function askLocalCoach(review = null, opponentName = null) {
  try {
    if (!review && !opponentName) {
      const humanFile = path.join(__dirname, 'new-learning', 'human-trial-results.jsonl')
      const file = fs.existsSync(humanFile) ? humanFile : path.join(__dirname, 'new-learning', 'gru-probe-results.jsonl')
      if (fs.existsSync(file)) {
        const lines = fs.readFileSync(file, 'utf8').trim().split(/\r?\n/)
        try { review = JSON.parse(lines.at(-1)) } catch {}
      }
    }
    const opponent = opponentName || review?.opponent || null
    const resultFile = path.join(__dirname, 'new-learning', 'human-trial-results.jsonl')
    const priorBouts = fs.existsSync(resultFile) ? fs.readFileSync(resultFile, 'utf8').split(/\r?\n/)
      .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
      .filter(row => row.opponent === opponent && row.reason === 'death').slice(-3) : []
    const body = { model: 'wavedog-tactics', temperature: 0.2, max_tokens: 80,
      messages: [{ role: 'system', content: 'You coach a Minecraft Java 1.21.1 GRU64 PvP bot against the named opponent. The opponent may be a human or another bot. Use public observations only. Reply with JSON object {"focus":"...","reason":"..."}. Focus is one of FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT. Prefer high charge for ordinary attacks while retaining necessary light hits. Axe breaks a valid shield. Evaluate opening crossbow loading and later bow/crossbow use for spacing, tempo and chip damage as testable PvP ideas, not mandatory moves. Consider load time, arrows, real range and the risk of being rushed and losing a damage trade while drawing or reloading. Review observed results. Do not assume an opponent identity implies a fighting style. You do not issue inputs or claim your own weights are trained.' },
        { role: 'user', content: JSON.stringify({ opponent, instruction: 'Choose the next research focus from measured attempts and misses. Investigate when opening crossbow loading and later ranged tempo are useful, without prescribing a fixed sequence. Preserve supported lessons across bouts; do not treat an invalid trial as a win.',
          latestReview: review, priorBouts, previousFocus: coachFocus, previousReason: coachReason }) }],
      response_format: { type: 'json_object' } }
    const response = await fetch('http://127.0.0.1:18765/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(35000) })
    if (!response.ok) throw Error('HTTP ' + response.status)
    const outer = await response.json(), answer = JSON.parse(outer.choices[0].message.content)
    if (!focusNames.has(answer.focus)) throw Error('Invalid focus ' + answer.focus)
    coachFocus = answer.focus; coachReason = String(answer.reason || '').slice(0, 120); coachReady = true
    coachOpponent = opponent
    const directory = path.join(__dirname, 'new-learning'); fs.mkdirSync(directory, { recursive: true })
    fs.appendFileSync(path.join(directory, 'human-trial-qwen.jsonl'), JSON.stringify({ at: now(), opponent, focus: coachFocus, reason: coachReason, review, source: 'local-qwen-http', model: 'Qwen2.5-1.5B-Instruct' }) + '\n')
    log('controller', 'qwen_coach_ready', { opponent, focus: coachFocus, reason: coachReason })
  } catch (error) { log('controller', 'qwen_coach_error', { error: String(error) }) }
}
function startGru() {
  if (gru) return
  const folder = path.join(__dirname, 'new-learning', 'models')
  gru = childProcess.spawn(modelJava, ['-cp', modelClasspath, 'local.wavedog.lab.ProtocolPlayerBridge', folder], { cwd: __dirname, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  gru.stdout.on('data', chunk => {
    modelLine += chunk.toString('utf8')
    for (let at; (at = modelLine.indexOf('\n')) >= 0;) {
      const line = modelLine.slice(0, at).trim(); modelLine = modelLine.slice(at + 1)
      if (!line) continue
      try { const result = JSON.parse(line)
        if (result.event === 'ready') { gruReady = true; log('controller', 'gru_ready', result) }
        else if (result.model === 'GRU64-PPO') { modelDecision = result; pendingModelRequest = null }
        else if (result.event === 'trained') {
          const directory = path.join(__dirname, 'new-learning')
          fs.appendFileSync(path.join(directory, 'human-trial-training.jsonl'), JSON.stringify({ at: now(), ...result }) + '\n')
          log('controller', 'ppo_checkpoint_saved', result)
        }
        else log('controller', 'gru_event', result)
      } catch (error) { log('controller', 'gru_parse_error', { error: String(error) }) }
    }
  })
  gru.stderr.on('data', chunk => log('controller', 'gru_stderr', { message: chunk.toString('utf8').slice(0, 300) }))
  gru.on('exit', code => { gruReady = false; gru = null; log('controller', 'gru_exit', { code }) })
}
startGru(); askLocalCoach()
const delay = new Map(names.map(name => [name, { input: 0, jitter: 0, observation: 0 }]))
const now = () => new Date().toISOString()
function log(name, event, data = {}) { console.log(JSON.stringify({ at: now(), name, event, ...data })) }
function schedule(name, task) {
  const d = delay.get(name)
  const wait = Math.max(0, d.input + (d.jitter ? Math.floor(Math.random() * (2 * d.jitter + 1)) - d.jitter : 0))
  setTimeout(() => { try { task() } catch (error) { log(name, 'input_error', { error: String(error) }) } }, wait)
}
function visible(name) {
  const bot = clients.get(name)
  if (!bot?.entity) return
  const report = () => log(name, 'client_observation', {
    version: bot.version,
    protocol: bot._client.protocolVersion,
    position: bot.entity.position,
    yaw: bot.entity.yaw,
    pitch: bot.entity.pitch,
    health: bot.health,
    food: bot.food,
    held: bot.heldItem?.name || null,
    nearbyPlayers: Object.fromEntries(Object.entries(bot.players).filter(([n, p]) => n !== name && p.entity)
      .map(([n, p]) => [n, { position: p.entity.position, yaw: p.entity.yaw, held: p.entity.heldItem?.name || null }]))
  })
  setTimeout(report, delay.get(name).observation)
}
function clickAttack(bot, name, intendedTarget, swingOnMiss = true) {
  // Mineflayer's attack(entity) sends use_entity regardless of distance. A
  // vanilla client first picks the entity under the crosshair within reach.
  const reach = 3.0
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight, 0)
  const yaw = bot.entity.yaw, pitch = bot.entity.pitch
  const direction = new Vec3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch))
  const block = bot.world.raycast(eye, direction, reach)
  const blockDistance = block ? eye.distanceTo(block.intersect) : Infinity
  const iterator = new RaycastIterator(eye, direction, reach)
  let picked = null, pickedDistance = Math.min(reach, blockDistance)
  for (const entity of Object.values(bot.entities)) {
    if (entity.id === bot.entity.id || entity.type === 'object' || !entity.position || !entity.width || !entity.height) continue
    if (entity.position.distanceTo(bot.entity.position) > reach + entity.width) continue
    const halfWidth = entity.width / 2
    const hit = iterator.intersect([[-halfWidth, 0, -halfWidth, halfWidth, entity.height, halfWidth]], entity.position)
    if (hit) {
      const distance = eye.distanceTo(hit.pos)
      if (distance <= pickedDistance) { picked = entity; pickedDistance = distance }
    }
  }
  if (picked?.id === intendedTarget.id) {
    bot.attack(picked)
    log(name, 'attack_click', { target: intendedTarget.username, hitDistance: pickedDistance, reach })
    return true
  } else {
    if (swingOnMiss) bot.swingArm()
    log(name, swingOnMiss ? 'attack_miss' : 'attack_rejected', { intended: intendedTarget.username, picked: picked?.username || null,
      centerDistance: bot.entity.position.distanceTo(intendedTarget.position), reach })
    return false
  }
}
function fineAimVisibleTarget(bot, target, maxDegrees = 18) {
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight, 0)
  const point = target.position.offset(0, Math.min(1.3, target.height * 0.7), 0)
  const dx = point.x-eye.x, dy = point.y-eye.y, dz = point.z-eye.z
  const yaw = Math.atan2(-dx, -dz), pitch = Math.atan2(dy, Math.hypot(dx,dz))
  const angle = Math.atan2(Math.sin(yaw-bot.entity.yaw), Math.cos(yaw-bot.entity.yaw))
  const limit = maxDegrees*Math.PI/180
  if (Math.abs(angle) > limit || Math.abs(pitch-bot.entity.pitch) > limit) return false
  const changed = Math.abs(angle) > 0.001 || Math.abs(pitch-bot.entity.pitch) > 0.001
  bot.look(yaw, pitch, true)
  return changed
}
function installVanillaUseMovement(bot, name) {
  const simulate = bot.physics.simulatePlayer.bind(bot.physics)
  bot.physics.simulatePlayer = (state, world) => {
    if (bot.usingHeldItem) {
      // The real 1.21.1 client scales movement input to 20% while using an
      // item; Prismarine Physics currently omits this. Its existing sneak
      // factor (30%) then gives the correct combined 6% movement input.
      state.control = { ...state.control,
        forward: Number(state.control.forward) * 0.2,
        back: Number(state.control.back) * 0.2,
        left: Number(state.control.left) * 0.2,
        right: Number(state.control.right) * 0.2,
        sprint: false }
    }
    return simulate(state, world)
  }
  const setControl = bot.setControlState.bind(bot)
  bot.setControlState = (control, enabled) => {
    if (control === 'sprint' && enabled && bot.usingHeldItem) return
    setControl(control, enabled)
  }
  bot._client.on('set_cooldown', packet => {
    if (packet.itemID === mcData.itemsByName.shield.id && (packet.cooldownTicks ?? packet.cooldown ?? 0) > 0) {
      bot.usingHeldItem = false
      setControl('sprint', false)
      if (name === 'WPlayer01' && humanDuel) humanDuel.shieldDisabledUntil = Date.now() + 50 * (packet.cooldownTicks ?? packet.cooldown)
      log(name, 'native_shield_cooldown', { ticks: packet.cooldownTicks ?? packet.cooldown })
    }
  })
}
for (const name of names) {
  const bot = mineflayer.createBot({ host, port, username: name, version: '1.21.1', auth: 'offline',
    keepAlive: true, checkTimeoutInterval: 30000 })
  clients.set(name, bot)
  let movementInstalled = false
  bot.on('login', () => log(name, 'login', { version: bot.version, protocol: bot._client.protocolVersion }))
  bot.on('spawn', () => { if (!movementInstalled) { installVanillaUseMovement(bot, name); movementInstalled = true }
    log(name, 'spawn', { position: bot.entity?.position }); visible(name) })
  bot.on('health', () => {
    if (name === 'WPlayer01' && humanDuel?.kind === 'human') {
      const received = Math.max(0, humanDuel.lastHealth-bot.health)
      humanDuel.lastHealth = bot.health
      if (received > 0 && gruReady) gru.stdin.write(JSON.stringify({ command: 'feedback', received }) + '\n')
    }
    visible(name)
  })
  bot.on('messagestr', message => {
    if (name === 'WPlayer01' && humanGateToken && message.includes(humanGateToken)) {
      const start = message.match(/WDUEL_START:(\d+):([^:]+):([^\s]+)/)
      const end = message.match(/WDUEL_END:(\d+):([^:]+):([^\s]+)/)
      if (start && start[3] === humanGateToken) { startHumanDuel(Number(start[1]), start[2]); return }
      if (end && end[3] === humanGateToken) { finishHumanDuel(end[2] === 'ABORT' ? 'aborted' : 'death', end[2] === 'ABORT' ? null : end[2]); return }
    }
    if (/register|注册/i.test(message) && !/already|已注册/i.test(message)) {
      schedule(name, () => bot.chat(`/register ${credentials[name]} ${credentials[name]}`))
    } else if (/\/login|登录|log in/i.test(message)) {
      schedule(name, () => bot.chat(`/login ${credentials[name]}`))
    }
    log(name, 'server_message', { message: message.slice(0, 240) })
  })
  bot.on('kicked', reason => log(name, 'kicked', { reason: String(reason).slice(0, 500) }))
  bot.on('error', error => log(name, 'error', { error: String(error) }))
  bot.on('end', reason => { if (name === 'WPlayer01' && humanDuel) finishHumanDuel('disconnected'); if (name === 'WPlayer01') fs.rmSync(modelReadyFile, { force: true }); log(name, 'end', { reason: String(reason) }) })
  if (name === 'WPlayer01') bot.on('entitySwingArm', entity => { if (humanDuel && entity?.username === humanDuel.targetName) humanDuel.opponentSwing++ })
}

let duel = null
let duelUsed = false
function stopDuel(reason, winner = null) {
  if (!duel) return
  const current = duel
  duel = null
  clearInterval(current.timer)
  for (const bot of clients.values()) {
    bot.clearControlStates()
    if (bot.usingHeldItem) bot.deactivateItem()
  }
  const report = { startedAt: current.startedAt, endedAt: now(), reason, winner,
    durationSeconds: Math.round((Date.now() - current.started) / 100) / 10,
    fighters: Object.fromEntries(names.map(name => [name, {
      health: clients.get(name).health, swings: current.swings[name],
      hitClicks: current.hits[name], misses: current.misses[name] }])) }
  const runDir = path.join(__dirname, 'runs')
  fs.mkdirSync(runDir, { recursive: true })
  const output = path.join(runDir, `main-one-bout-${current.startedAt.replace(/[:.]/g, '-')}.json`)
  fs.writeFileSync(output, JSON.stringify(report, null, 2))
  log('controller', 'duel_end', { ...report, output })
}
function startDuelOnce() {
  if (duel || duelUsed || names.some(name => !clients.get(name)?.entity || !clients.get(name)?.players[names.find(other => other !== name)]?.entity)) {
    log('controller', 'duel_unavailable', { active: !!duel, alreadyUsed: duelUsed }); return
  }
  duelUsed = true
  const started = Date.now()
  duel = { started, startedAt: now(), swings: Object.fromEntries(names.map(name => [name, 0])),
    hits: Object.fromEntries(names.map(name => [name, 0])), misses: Object.fromEntries(names.map(name => [name, 0])),
    lastSwing: Object.fromEntries(names.map(name => [name, 0])), timer: null }
  log('controller', 'duel_start', { startedAt: duel.startedAt, styles: { WPlayer01: 'aggressive_axe', WPlayer02: 'opening_shield_counter' },
    training: false, maxSeconds: 90 })
  duel.timer = setInterval(() => {
    if (!duel) return
    const elapsed = Date.now() - started
    const dead = names.filter(name => clients.get(name).health <= 0)
    if (dead.length) { stopDuel('death', dead.length === 1 ? names.find(name => name !== dead[0]) : null); return }
    if (elapsed > 90000) {
      const [a, b] = names.map(name => clients.get(name))
      stopDuel('time_limit', a.health === b.health ? null : a.health > b.health ? names[0] : names[1]); return
    }
    for (const name of names) {
      const bot = clients.get(name)
      const other = names.find(value => value !== name)
      const target = bot.players[other]?.entity
      if (!bot.entity || !target) { stopDuel('target_disconnected'); return }
      const distance = bot.entity.position.distanceTo(target.position)
      bot.lookAt(target.position.offset(0, 1.3, 0), true)
      const openingShield = name === names[1] && elapsed < 1300
      if (openingShield && !bot.usingHeldItem) { bot.setControlState('sprint', false); bot.activateItem(true) }
      if (!openingShield && bot.usingHeldItem) bot.deactivateItem()
      bot.setControlState('forward', distance > (openingShield ? 2.7 : 2.15))
      bot.setControlState('sprint', !openingShield && distance > 3.1)
      if (!openingShield && elapsed > (name === names[0] ? 350 : 1400)
          && Date.now() - duel.lastSwing[name] >= 1050 && distance < 3.35) {
        duel.lastSwing[name] = Date.now() // A miss still consumes the policy's charge budget.
        const appliedDelay = 40 + Math.floor(Math.random() * (name === names[0] ? 41 : 91))
        setTimeout(() => {
          if (!duel || bot.health <= 0 || !bot.players[other]?.entity) return
          bot.lookAt(bot.players[other].entity.position.offset(0, 1.3, 0), true)
          const hit = clickAttack(bot, name, bot.players[other].entity)
          duel.swings[name]++
          if (hit) duel.hits[name]++
          else duel.misses[name]++
        }, appliedDelay)
      }
    }
  }, 100)
}

let humanDuel = null
function slotForInventory(bot, name) {
  const item = bot.heldItem?.name || ''
  if (item.includes('sword')) return 0
  if (item === 'bow') return 1
  if (item === 'crossbow') return 4
  return 7
}
function inventoryReady(bot) {
  const hotbar = bot.inventory.slots
  return hotbar[36]?.name === 'diamond_sword' && hotbar[37]?.name === 'bow'
    && hotbar[38]?.name === 'arrow' && hotbar[38].count === 5
    && hotbar[40]?.name === 'crossbow' && hotbar[43]?.name === 'diamond_axe'
    && bot.inventory.slots[45]?.name === 'shield'
}
const modelReadyFile = path.join(__dirname, 'new-learning', 'human-trial-ready.json')
function publishHumanReadiness() {
  if (!gruReady || !coachReady) { fs.rmSync(modelReadyFile, { force: true }); return }
  const bot = clients.get('WPlayer01')
  if (!bot?.entity || bot._client.ended || !inventoryReady(bot)) { fs.rmSync(modelReadyFile, { force: true }); return }
  fs.mkdirSync(path.dirname(modelReadyFile), { recursive: true })
  fs.writeFileSync(modelReadyFile, JSON.stringify({ at: now(), gruReady, coachReady, kitReady: true,
    qwenFocus: coachFocus, coachOpponent, checkpoint: path.join(__dirname, 'new-learning', 'models', 'recurrent-ppo.json') }))
}
const readinessTimer = setInterval(publishHumanReadiness, 1000)
function requestGruAction() {
  if (!humanDuel || !gruReady || pendingModelRequest || !gru?.stdin.writable) return
  const bot = clients.get('WPlayer01'), target = bot.players[humanDuel.targetName]?.entity
  if (!bot.entity || !target) return
  const nowMs = Date.now(); if (nowMs - humanDuel.lastModelRequest < 100) return
  humanDuel.lastModelRequest = nowMs
  const own = bot.entity, self = { x: own.position.x, y: own.position.y, z: own.position.z,
    eyeY: own.position.y + own.eyeHeight, vx: own.velocity.x, vy: own.velocity.y, vz: own.velocity.z,
    ground: own.onGround, critical: !own.onGround && own.velocity.y < -0.08,
    charge: Math.min(1, (nowMs - humanDuel.lastSwing) / (slotForInventory(bot) === 0 ? 625 : 1000)),
    health: bot.health, shieldAvailable: nowMs >= humanDuel.shieldDisabledUntil,
    shielding: bot.usingHeldItem && slotForInventory(bot) !== 1 && slotForInventory(bot) !== 4,
    arrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n, item) => n + item.count, 0),
    crossbowLoaded: false, using: bot.usingHeldItem, useTicks: bot.usingHeldItem ? Math.round((nowMs-humanDuel.useStarted)/50) : 0,
    held: slotForInventory(bot) }
  const seen = { visible: target.position.distanceTo(own.position) < 64,
    x: target.position.x, y: target.position.y, z: target.position.z,
    yaw: 180 - target.yaw * 180 / Math.PI, shield: Boolean(target.usingHeldItem),
    held: target.heldItem?.name?.toUpperCase() || 'UNKNOWN', using: Boolean(target.usingHeldItem), swing: humanDuel.opponentSwing }
  const requestId = ++nextModelRequest
  pendingModelRequest = { id: requestId, sent: nowMs }
  gru.stdin.write(JSON.stringify({ command: 'act', requestId, opponent: humanDuel.targetName,
    tick: Math.round((nowMs-humanDuel.started)/50),
    yaw: 180 - own.yaw * 180/Math.PI, pitch: -own.pitch*180/Math.PI, self, seen, focus: coachFocus }) + '\n')
  setTimeout(() => { if (pendingModelRequest?.id === requestId) pendingModelRequest = null }, 300)
}
function finishHumanDuel(reason, winner = null) {
  if (!humanDuel) return
  const run = humanDuel; humanDuel = null; modelDecision = null; pendingModelRequest = null
  clearInterval(run.timer); const bot = clients.get('WPlayer01'); bot.clearControlStates()
  if (bot.usingHeldItem) bot.deactivateItem()
  const shouldTrain = run.kind === 'human' && reason === 'death' && (winner === run.targetName || winner === 'WPlayer01') && run.decisions > 0
  const report = { at: now(), round: run.round, kind: run.kind, opponent: run.targetName, reason, winner, durationSeconds: Math.round((Date.now()-run.started)/100)/10,
    botHealth: bot.health, gruDecisions: run.decisions, attacks: run.attacks, misses: run.misses, rejectedAttacks: run.rejectedAttacks,
    cameraFineAim: run.cameraFineAim, bowChoices: run.bowChoices,
    crossbowChoices: run.crossbowChoices, rangedUseChoices: run.rangedUseChoices,
    ammoConsumed: Math.max(0, run.startArrows - bot.inventory.items().filter(item => item.name === 'arrow').reduce((n, item) => n + item.count, 0)),
    qwenFocus: coachFocus, qwenReason: coachReason, model: 'GRU64-PPO', training_requested: shouldTrain }
  const directory = path.join(__dirname, 'new-learning'); fs.mkdirSync(directory, { recursive: true })
  fs.appendFileSync(path.join(directory, run.kind === 'probe' ? 'gru-probe-results.jsonl' : 'human-trial-results.jsonl'), JSON.stringify(report) + '\n')
  log('controller', 'human_duel_end', report)
  if (gruReady) gru.stdin.write(JSON.stringify(shouldTrain
    ? { command: 'finish', round: run.round, win: winner === 'WPlayer01', health: bot.health }
    : { command: 'reset', learning: false }) + '\n')
  askLocalCoach(report, run.targetName)
}
function applyGruDecision() {
  if (!humanDuel || !modelDecision) return
  const bot = clients.get('WPlayer01'), target = bot.players[humanDuel.targetName]?.entity
  if (!target || !bot.entity) return
  const decision = modelDecision; modelDecision = null; humanDuel.decisions++
  if (decision.opponent !== humanDuel.targetName) {
    log('controller', 'gru_opponent_mismatch', { expected: humanDuel.targetName, received: decision.opponent })
    return
  }
  bot.look((180 - Number(decision.yaw)) * Math.PI/180, -Number(decision.pitch) * Math.PI/180, true)
  const forward = Number(decision.forward), side = Number(decision.side)
  bot.setControlState('forward', forward > 0.5); bot.setControlState('back', forward < -0.5)
  bot.setControlState('left', side < -0.5); bot.setControlState('right', side > 0.5)
  bot.setControlState('sprint', Boolean(decision.sprint)); bot.setControlState('sneak', Boolean(decision.sneak))
  bot.setControlState('jump', Boolean(decision.jump))
  const slot = Number(decision.slot)
  if (slot === 1) humanDuel.bowChoices++
  if (slot === 4) humanDuel.crossbowChoices++
  if ((slot === 1 || slot === 4) && decision.use) humanDuel.rangedUseChoices++
  if ([0,1,4,7].includes(slot) && bot.quickBarSlot !== slot) bot.setQuickBarSlot(slot)
  if (decision.shield && !bot.usingHeldItem && Date.now() >= humanDuel.shieldDisabledUntil) {
    bot.activateItem(true); humanDuel.useStarted = Date.now()
  } else if (decision.use && !bot.usingHeldItem) { bot.activateItem(); humanDuel.useStarted = Date.now() }
  else if (decision.use && bot.usingHeldItem && slotForInventory(bot) === 4 && Date.now()-humanDuel.useStarted > 1300) bot.deactivateItem()
  if (decision.release && bot.usingHeldItem) bot.deactivateItem()
  if (decision.attack && Date.now()-humanDuel.lastAttackAttempt >= 200) {
    if (bot.usingHeldItem) bot.deactivateItem()
    humanDuel.lastAttackAttempt = Date.now()
    if (fineAimVisibleTarget(bot, target)) humanDuel.cameraFineAim++
    if (clickAttack(bot, 'WPlayer01', target, false)) { humanDuel.lastSwing = Date.now(); humanDuel.attacks++ }
    else humanDuel.rejectedAttacks++
  }
}
function startHumanDuel(round, targetName, kind = 'human', maxMs = 120000) {
  if (humanDuel || !gruReady || !coachReady) { log('controller', 'human_duel_unavailable', { round, gruReady, coachReady }); return }
  const bot = clients.get('WPlayer01')
  if (!bot?.players[targetName]?.entity) { log('controller', 'human_duel_target_missing', { round, targetName }); return }
  if (!inventoryReady(bot)) { log('controller', 'human_duel_kit_missing', { round }); return }
  const run = { round, kind, targetName, maxMs, started: Date.now(), lastModelRequest: 0, lastSwing: Date.now()-1000, lastAttackAttempt: 0,
    lastHealth: bot.health,
    shieldDisabledUntil: 0, useStarted: Date.now(), opponentSwing: 0, decisions: 0, attacks: 0, misses: 0, rejectedAttacks: 0, cameraFineAim: 0,
    bowChoices: 0, crossbowChoices: 0, rangedUseChoices: 0,
    startArrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n, item) => n + item.count, 0), timer: null }
  humanDuel = run
  if (kind === 'human') {
    if (coachOpponent !== targetName) coachFocus = 'FREE'
    askLocalCoach(null, targetName)
  }
  if (gruReady) gru.stdin.write(JSON.stringify({ command: 'reset', opponent: targetName, learning: kind === 'human' }) + '\n')
  run.timer = setInterval(() => {
    if (!humanDuel) return
    if (Date.now()-run.started > run.maxMs) { finishHumanDuel('time_limit'); return }
    if (!bot.players[run.targetName]?.entity || !bot.entity) { finishHumanDuel('disconnected'); return }
    requestGruAction(); applyGruDecision()
  }, 50)
  log('controller', 'human_duel_start', { round, kind, targetName, model: 'GRU64-PPO', qwenFocus: coachFocus, training: kind === 'human' })
}

const cli = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false })
cli.on('line', line => {
  const [command, name, arg, value] = line.trim().split(/\s+/)
  if (command === 'quit') { if (duel) stopDuel('operator_stop'); if (humanDuel) finishHumanDuel('operator_stop'); clearInterval(readinessTimer); fs.rmSync(modelReadyFile, { force: true }); if (gru) gru.stdin.write(JSON.stringify({ command: 'close' }) + '\n'); for (const bot of clients.values()) bot.quit(); cli.close(); return }
  if (command === 'status') { for (const n of names) visible(n); return }
  if (command === 'readiness') {
    const bot = clients.get('WPlayer01')
    log('controller', 'readiness_diagnostic', { gruReady, coachReady, connected: Boolean(bot?.entity),
      clientEnded: bot?._client?.ended, kitReady: bot ? inventoryReady(bot) : false,
      slots: bot && Object.fromEntries([36,37,38,40,43,45].map(i => [i, { name: bot.inventory.slots[i]?.name,
        count: bot.inventory.slots[i]?.count }])) })
    return
  }
  if (command === 'gru-probe') { startHumanDuel(0, 'WPlayer02', 'probe', 15000); return }
  if (command === 'duel-once') { startDuelOnce(); return }
  if (!clients.has(name)) { log('controller', 'unknown_player', { line }); return }
  const bot = clients.get(name)
  if (command === 'delay') {
    const input = Number(arg), jitter = Number(value || 0)
    if (!Number.isInteger(input) || !Number.isInteger(jitter) || input < 0 || input > 1000 || jitter < 0 || jitter > input) throw Error('delay input 0..1000, jitter 0..input')
    delay.set(name, { ...delay.get(name), input, jitter }); log(name, 'delay', delay.get(name)); return
  }
  if (command === 'observe-delay') {
    const observation = Number(arg)
    if (!Number.isInteger(observation) || observation < 0 || observation > 1000) throw Error('observation delay 0..1000')
    delay.set(name, { ...delay.get(name), observation }); log(name, 'delay', delay.get(name)); return
  }
  if (command === 'move') {
    const control = arg, duration = Number(value || 250)
    if (!['forward', 'back', 'left', 'right', 'jump', 'sprint', 'sneak'].includes(control) || duration < 1 || duration > 10000) throw Error('move control duration')
    schedule(name, () => { bot.setControlState(control, true); setTimeout(() => bot.setControlState(control, false), duration) }); return
  }
  if (command === 'hold-shield') { schedule(name, () => { bot.setControlState('sprint', false); bot.activateItem(true) }); return }
  if (command === 'release') { schedule(name, () => bot.deactivateItem()); return }
  if (command === 'slot') { schedule(name, () => bot.setQuickBarSlot(Number(arg))); return }
  if (command === 'attack' || command === 'look') {
    const target = bot.players[arg]?.entity
    if (!target) { log(name, 'target_not_visible', { target: arg }); return }
    schedule(name, () => {
      bot.lookAt(target.position.offset(0, 1.3, 0), true)
      if (command === 'attack') clickAttack(bot, name, target)
    }); return
  }
  log('controller', 'unknown_command', { line })
})
log('controller', 'ready', { names, version: '1.21.1', commands: 'duel-once; status; move NAME control ms; hold-shield NAME; release NAME; slot NAME n; look NAME TARGET; attack NAME TARGET; delay NAME ms jitter; observe-delay NAME ms; quit' })
