'use strict'
// Counterfactual conversion audit only; never a live controller or PPO input.
const fs=require('node:fs'),zlib=require('node:zlib'),{rayTargetPoint,modelRelativeView}=require('./protocol-pure-executor')
const file=process.argv[2],evaluation=process.argv[3],out=process.argv[4]
if(!file||!evaluation||!out||fs.existsSync(out))throw Error('Supply raw frames, frozen evaluation and unused report path')
const rollout=JSON.parse(zlib.gunzipSync(fs.readFileSync(evaluation)))
const byTick=new Map(rollout.episode.map(f=>[f.decidedTick,f]))
const frames=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse),rows=[]
for(const r of frames){
  if(r.attackSuppressedReason!=='outside-range-or-aim'||!r.seen.visible)continue
  const a=byTick.get(r.command.decidedTick)?.actions
  if(!a||a.length!==9)continue
  const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180],pitches=[-30,-10,-3,0,3,10,30]
  const target={position:r.seen,width:.6,height:1.8},eye={x:r.self.x,y:r.self.eyeY,z:r.self.z}
  const view=modelRelativeView(eye,target,turns[a[6]],pitches[a[7]])
  const old=rayTargetPoint(eye,target,(180-r.command.yaw)*Math.PI/180,-r.command.pitch*Math.PI/180)
  const next=rayTargetPoint(eye,target,view.yaw,view.pitch)
  rows.push({tick:r.tick,reach:r.observation.reach,oldRayIntersects:Boolean(old),refreshedRayIntersects:Boolean(next),
    yawOffset:turns[a[6]],pitchOffset:pitches[a[7]],withinReach:r.observation.reach<=3})
}
const report={source:file,counterfactualNotExecuted:true,usedOnlyCurrentPublicState:true,rows,
  preventedAimMisses:rows.filter(r=>!r.oldRayIntersects&&r.refreshedRayIntersects).length}
if(!rows.length)throw Error('No exact frozen actions aligned; do not claim a successful conversion audit')
fs.writeFileSync(out,JSON.stringify(report,null,2));console.log(JSON.stringify(report))
