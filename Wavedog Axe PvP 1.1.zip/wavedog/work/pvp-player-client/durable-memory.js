/** Bounded coach prompts that revisit every durable player lesson over time. */
function selectPlayerExperience (rows, readIndex, size = 8) {
  const unique = [...new Map(rows.map((row, index) => ({ row, index }))
    .filter(({ row }) => typeof row?.text === 'string' && row.text.trim())
    .map(entry => [entry.row.id || entry.row.text, entry])).values()]
  // Corrections preserve the original event log while preventing obsolete
  // control instructions from rotating back into future Qwen prompts.
  const superseded = new Set(unique.flatMap(({ row }) =>
    Array.isArray(row.supersedes) ? row.supersedes : []))
  const active = unique.filter(({ row }) => !superseded.has(row.id))
  const pinned = active.filter(({ row }) => row.player === 'user-seed').slice(-4)
  const pinnedKeys = new Set(pinned.map(({ index }) => index))
  const others = active.filter(({ index }) => !pinnedKeys.has(index))
  const room = Math.max(0, size - pinned.length)
  const selected = []
  for (let i = 0; i < Math.min(room, others.length); i++)
    selected.push(others[(readIndex * Math.max(1, room) + i) % others.length])
  return [...pinned, ...selected].sort((a, b) => a.index - b.index)
    .slice(0, size).map(({ row }) => row.text.trim().slice(0, 360))
}

function selectMeasuredLessons (rows, readIndex, size = 6) {
  const entries = [...new Map(rows.map((row, index) => ({ row, index }))
    .filter(({ row }) => ['measured-fallback', 'measured-after-Qwen'].includes(row.lessonSource)
      && typeof row.lesson === 'string' && row.lesson.trim())
    .map(entry => [entry.row.lesson, entry])).values()]
  if (entries.length <= size) return entries.map(({ row }) => row.lesson.trim().slice(0, 120))
  const recent = entries.slice(-(size - 1))
  const archive = entries.slice(0, -(size - 1))
  return [archive[readIndex % archive.length], ...recent].sort((a, b) => a.index - b.index)
    .map(({ row }) => row.lesson.trim().slice(0, 120))
}

module.exports = { selectPlayerExperience, selectMeasuredLessons }
