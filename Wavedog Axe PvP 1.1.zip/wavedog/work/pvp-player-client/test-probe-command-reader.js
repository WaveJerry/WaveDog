'use strict'
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict')
const {readProbeCommand}=require('./probe-command-reader')
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'probe-command-read-')),file=path.join(dir,'command.json')
try{
  assert.equal(readProbeCommand(file),null)
  const active={active:true,target:'Punengbho',matchId:'test',mode:'edge-control'}
  fs.writeFileSync(file,JSON.stringify(active));assert.deepEqual(readProbeCommand(file),active)
  for(const partial of ['', '{"active":', 'null', '[]']){
    fs.writeFileSync(file,partial);assert.equal(readProbeCommand(file),null,'partial input cannot repeat prior active order')
  }
  fs.writeFileSync(file,'{"active":false}');assert.deepEqual(readProbeCommand(file),{active:false})
  console.log('PROBE_PARTIAL_COMMAND_FAILS_INACTIVE_WITHOUT_CRASH_PASS')
}finally{if(fs.existsSync(file))fs.unlinkSync(file);fs.rmdirSync(dir)}
