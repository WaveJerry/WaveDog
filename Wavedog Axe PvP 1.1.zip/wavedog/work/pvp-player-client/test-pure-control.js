'use strict'
const assert=require('node:assert/strict')
const {createState,plan}=require('./protocol-pure-brain')
const {executeCommand}=require('./protocol-pure-executor')
function fixture(){
  const wire=[],controls={},bot={quickBarSlot:7,food:20,inventory:{slots:[]},
    entity:{position:{x:0,y:0,z:0},eyeHeight:1.62,yaw:0,pitch:0},
    _client:{write:(n,d)=>wire.push({n,d})},setControlState:(k,v)=>{controls[k]=v},
    getControlState:k=>Boolean(controls[k]),setQuickBarSlot(s){this.quickBarSlot=s},
    activateItem(){wire.push({n:'use_item'})},attack(){wire.push({n:'use_entity'})}}
  bot.inventory.slots[45]={name:'shield'}
  let use=null
  const ctx={bot,wire,tick:10,shieldUntil:0,lastAttackTick:-1000,session:{id:'pure',opponent:'human',state:createState(),attackedDecisions:new Set(),attackOwners:new Map()},
    frame:{seen:{visible:true},targetVelocity:{},observation:{reach:2.2}},target:{position:{x:0,y:0,z:-2.5},width:.6,height:1.8},
    look(y,p){bot.entity.yaw=y;bot.entity.pitch=p;wire.push({n:'look',y,p})},
    aim(){bot.entity.yaw=bot.entity.pitch=0;wire.push({n:'look',y:0,p:0})},
    offhand:n=>{bot.inventory.slots[45]={name:n};return true},getUse:()=>use,setUse:v=>{use=v},stopUse(){if(use)wire.push({n:'release'});use=null},
    plugin:()=>{},onSwitch:()=>{},onAttack:()=>{},ownLoaded:()=>false,clearPath:()=>true,
    getSentPosition:()=>({...bot.entity.position})}
  ctx.action=(a,t=10)=>{ctx.tick=t;ctx.planned=plan(ctx.session.state,{tick:t,shieldReady:false,targetLoading:true,arrowThreat:{time:1,side:-1}},
    {decidedTick:t,forward:0,side:0,sprint:false,jump:false,sneak:false,slot:7,yaw:180,pitch:0,...a});return executeCommand(ctx)}
  return ctx
}
let x=fixture(),out=x.action({forward:1,sprint:true})
assert(out.controls.forward&&out.controls.sprint)
assert(!out.shieldRequested&&!out.rangedResult.useStarted,'enemy ranged use never forces this branch to use a shield or dodge')
out=x.action({shield:true},11);assert(out.shieldRequested&&x.getUse()?.kind==='shield')
out=x.action({shield:true},12);assert(x.getUse()?.kind==='shield','continued shield request holds the shield')
out=x.action({release:true},13);assert.equal(x.getUse(),null)
out=x.action({use:true,slot:4},14);assert.equal(x.getUse().kind,'crossbow')
out=x.action({use:true,slot:4},44);assert.equal(x.getUse().kind,'crossbow','there is no automatic load or bow release timer')
out=x.action({},45);assert.equal(x.getUse(),null,'cancelling the use request releases on wire')
x=fixture();out=x.action({attack:true});assert(out.attacked)
out=executeCommand(x);assert(!out.attacked,'cached action cannot double click')
x=fixture();x.getSentPosition=()=>null;out=x.action({attack:true})
assert(!out.attacked&&out.rejected==='unconfirmed-sent-position','unconfirmed server position cannot authorize a melee packet')
x=fixture();x.getSentPosition=()=>({x:0,y:0,z:2});out=x.action({attack:true})
assert(!out.attacked&&out.rejected==='outside-sent-range-or-aim','local contact cannot authorize a packet outside server reach')
x=fixture();out=x.action({attack:true,yaw:90});assert(!out.attacked,'model camera can miss; the executor does not replace it with target aim')
x=fixture();out=x.action({attack:true,yaw:90,flightLook:true});assert(out.attacked,'a model-selected turn-back hit is executable')
assert(Math.abs(x.bot.entity.yaw-Math.PI/2)<1e-8,'turn-back restores the model-selected view')
x=fixture();out=x.action({attack:true,yaw:37.123,pitch:18.456,flightLook:true,forward:1,side:-1,sprint:true})
assert(out.attacked)
assert.equal(x.bot.entity.yaw,(180-37.123)*Math.PI/180)
assert.equal(x.bot.entity.pitch,-18.456*Math.PI/180)
assert.deepEqual(x.wire.slice(-3).map(p=>p.n),['look','use_entity','look'])
assert(out.controls.forward&&out.controls.left&&out.controls.sprint)
x=fixture();x.bot.attack=()=>{throw Error('write failed')}
assert.throws(()=>x.action({attack:true,yaw:91,pitch:-19,flightLook:true}),/write failed/)
assert.equal(x.bot.entity.yaw,(180-91)*Math.PI/180)
assert.equal(x.bot.entity.pitch,19*Math.PI/180)
x=fixture();x.clearPath=()=>false
out=x.action({attack:true,yaw:91,pitch:-19,flightLook:true})
assert(!out.attacked);assert.equal(x.bot.entity.yaw,(180-91)*Math.PI/180)
x=fixture();x.planned=plan(x.session.state,{tick:20},{decidedTick:1,attack:true,forward:1});x.tick=20
out=executeCommand(x);assert(!out.attacked&&!out.controls.forward&&out.ignoredHeads.length===9)
console.log('PURE_MODEL_ALL_INPUT_AND_NO_MECHANICAL_OVERLAYS_PASS')
