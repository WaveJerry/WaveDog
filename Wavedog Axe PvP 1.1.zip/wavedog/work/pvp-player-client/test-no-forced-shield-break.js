'use strict'
const assert=require('node:assert/strict')
const {createState,plan}=require('./protocol-wavedog-brain')
let checked=0
for(const reach of [.2,1,2.7,2.999,3,3.01])for(const charge of [0,.2,.7,1])
for(const slot of [0,7])for(const attack of [false,true]){
  const s=createState('opponent');s.mode='NEURAL';s.shieldUntil=200
  const o={tick:100,shieldReady:false,shieldEffective:false,visible:true,reach,
    distance:reach+.3,held:0,charge,ground:true,health:20,targetShieldFacing:true,
    targetShieldRaised:true,arrows:0,loaded:false,wallMargin:8}
  const selected={decidedTick:100,forward:1,side:-1,sprint:true,jump:false,slot,attack}
  const p=plan(s,o,selected)
  assert.equal(p.mode,'NEURAL');assert.equal(p.command.slot,slot)
  assert.equal(p.command.attack,attack);assert.equal(p.command.attackId,undefined)
  for(const key of ['movement','sprint','jump','mainhand','attack'])assert.equal(p.owners[key],'neural')
  const stale=plan(s,{...o,tick:104},selected)
  assert.equal(stale.command.attack,false,'expired inference cannot trigger a shield break')
  assert.equal(stale.command.slot,null,'expiry cannot fall back to a forced axe')
  checked++
}
for(const reach of [.5,2.8,3]){
  const s=createState();s.mode='ESCAPE';s.airborne=true;s.shieldUntil=200;s.escapeAt=98
  const p=plan(s,{tick:100,shieldReady:false,ground:false,reach,visible:true,
    targetShieldFacing:true,targetShieldRaised:true,charge:1,critical:true,health:20},null)
  assert.equal(p.command.slot,0);assert.equal(p.command.attack,false,
    'raised enemy shield cannot force an axe attack into the sword escape')
}
console.log('NO_FORCED_SHIELD_BREAK_PASS',checked,'neural cases; live command slots and attacks remain model-owned')
