// One frame has one owner per input domain. No GRU hand input leaks into
// mechanical shield, counter, projectile defence or ranged execution.
const MOVE = ['forward', 'side', 'sprint', 'jump', 'sneak']
const FULL = new Set(['single-jump-exit', 'critical-exit',
  'edge-exit-hit', 'arrow-side-jump', 'landed-return-axe',
  'shield-pressure', 'shield-orbit', 'shield-counter', 'counter-confirm-wait',
  'arrow-guard', 'crossbow-fire', 'crossbow-ready',
  'crossbow-load', 'crossbow-load-release', 'bow-draw', 'bow-release'])
const NEUTRAL = Object.freeze({ forward: 0, side: 0, sprint: false,
  jump: false, sneak: false, shield: false, attack: false,
  slot: 7, use: false, release: false })

function composeControl (gru, machine, humanChallenge) {
  const input = { ...NEUTRAL, ...gru }
  if (!machine) {
    const decision = { ...input }
    decision.sneak = false
    const ignoredHeads = [3, 6, 7, 8]
    if ([1, 4].includes(Number(decision.slot))) {
      decision.slot = 7
      decision.use = false
      ignoredHeads.push(4, 5)
    } else if (decision.use) {
      decision.use = false
      ignoredHeads.push(4)
    }
    if (decision.shield) {
      ignoredHeads.push(1)
    }
    return { decision, ignoredHeads,
      owners: { movement: 'GRU', jump: 'GRU', sneak: 'disabled',
        mainHand: 'GRU', weapon: 'GRU', shield: 'GRU', ranged: 'none' },
      controlOwner: humanChallenge ? 'GRU-sync' : 'GRU-melee' }
  }
  if (Boolean(machine.movementOverride) !== FULL.has(machine.kind))
    throw Error('Movement ownership mismatch: ' + machine.kind)
  if (machine.movementOverride) {
    const decision = { ...NEUTRAL, ...machine.decision, sneak: false }
    return { decision, ignoredHeads: [0,1,2,3,4,5,6,7,8],
      owners: { movement: 'WaveDog', jump: 'WaveDog', sneak: 'disabled',
        mainHand: 'WaveDog', weapon: 'WaveDog',
        shield: 'WaveDog', ranged: machine.rangedOverlay ? 'WaveDog' : 'none' },
      controlOwner: machine.rangedOverlay ? 'WaveDog-ranged'
        : 'WaveDog-mechanical' }
  }
  for (const key of MOVE)
    if (Object.hasOwn(machine.decision, key))
      throw Error('Mechanical hand action controls ' + key + ': ' + machine.kind)
  const hand = machine.decision
  const decision = { ...input,
    jump: machine.lockJump || hand.shield ? false : input.jump,
    sneak: false,
    slot: hand.slot ?? 7, shield: Boolean(hand.shield),
    attack: Boolean(hand.attack), use: Boolean(hand.use),
    release: Boolean(hand.release) }
  const ignoredHeads = [3,4,5,6,7,8]
  if (hand.shield || hand.use) ignoredHeads.push(1)
  if (machine.lockJump || hand.shield) ignoredHeads.push(2)
  return { decision, ignoredHeads,
    owners: { movement: 'GRU',
      jump: machine.lockJump || hand.shield ? 'WaveDog' : 'GRU',
      sneak: 'disabled', mainHand: 'WaveDog', weapon: 'WaveDog',
      shield: 'WaveDog',
      ranged: machine.rangedOverlay ? 'WaveDog' : 'none' },
    controlOwner: machine.rangedOverlay ? 'GRU+WaveDog-ranged'
      : 'GRU+WaveDog-hand' }
}
module.exports = { composeControl, NEUTRAL }
