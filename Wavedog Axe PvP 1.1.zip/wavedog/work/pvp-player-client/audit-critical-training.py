"""Read append-only bout results; report native critical and retreat evidence."""
from pathlib import Path
import argparse
import json

source = Path(__file__).resolve().parent / "new-learning/selfplay/rounds.jsonl"
parser = argparse.ArgumentParser()
parser.add_argument("--since", required=True, help="UTC ISO timestamp of the tested deployment")
args = parser.parse_args()

names = ("nativeCriticalHits", "jumpInCriticalHits", "nativeCriticalShieldBlocks",
         "shieldedCriticalEligibleAttacks", "jumpInShieldBlocks",
         "fallingThreatFirstHits", "unansweredFollowupHits", "swordFollowupHits",
         "axeIntoSwordLosses", "swordIntoAxeWins", "blockedMelee",
         "counterHits", "counterProgress", "counterEscapes", "counterPunished",
         "edgeCounterEscapes")
totals = {name: 0 for name in names}
groups = {"critical-entry-research": 0, "counter-retreat-research": 0,
          "sword-tempo-research": 0, "other": 0}
count = both_updated = archived = 0
first = last = None
with source.open(encoding="utf-8") as handle:
    for line in handle:
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("at", "") < args.since or row.get("reason") != "death":
            continue
        count += 1
        first = first or row["at"]
        last = row["at"]
        sources = {f.get("curriculumSource") for f in row.get("fighters", {}).values()}
        group = next((key for key in groups if key in sources and key != "other"), "other")
        groups[group] += 1
        both_updated += len(row.get("training", [])) == 2 and not row.get("trainingError")
        archived += bool(row.get("frameArchive", {}).get("sha256"))
        for tactic in row.get("tactics", {}).values():
            for name in names:
                totals[name] += tactic.get(name, 0) or 0

print(json.dumps({"since": args.since, "bouts": count, "first": first,
                  "last": last, "bothGruUpdated": both_updated,
                  "framesArchived": archived, "curriculum": groups,
                  "outcomes": totals}, ensure_ascii=False, indent=2))
