"""Compile the native Paper referee for ordinary protocol player selfplay."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import zipfile

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classes = base / 'selfplay-classes'
classes.mkdir(exist_ok=True)
source = base / 'selfplay-src/local/wavedog/selfplay/SelfPlayGate.java'
classpath = os.pathsep.join(map(str, [server / 'versions/1.21.1/paper-1.21.1.jar',
                                     *sorted((server / 'libraries').rglob('*.jar'))]))
subprocess.run([str(server / 'runtime/java21/bin/javac.exe'), '-proc:none', '-encoding', 'UTF-8',
                '--release', '21', '-cp', classpath, '-d', str(classes), str(source)], check=True)
target = base / 'WaveDogSelfPlayGate.jar'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as jar:
    for item in sorted(classes.rglob('*.class')):
        jar.write(item, item.relative_to(classes).as_posix())
    jar.write(base / 'selfplay-plugin.yml', 'plugin.yml')
print(json.dumps({'jar': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
