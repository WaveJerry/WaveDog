// Translate the operator's tactics into existing neural goal channels.
// This module never supplies a movement key, weapon selection or attack command.
const OPERATOR_TACTICS = Object.freeze({
  priority: '合法三格边界先手击退，打断平 A 起手和跳跃上升期，不给后续跳劈连击机会',
  landing: '交权后含刚落地的第一窗口，在合法射程且武器可用时主动争取命中，不为等待惩罚暴击长期空等',
  edge: '对手平地接近、尚未深入近身时优先疾跑击退和平 A 控距；不能距离外挥空，也不能为守边缘而放弃距离内命中',
  deep: '对手真正挤进近身后，允许短促进身到一两格，选择惩罚暴击、跑跳暴击、剑连击或地面连招；不把跳跃当默认动作',
  critical: '真实暴击出刀前松疾跑；普通疾跑击退刀不因等暴击而被延误',
  evidence: '只用公开位置、运动和挥刀时序；按合法命中、真实击退、后续受击及净换血验收，不能把意图写成学会'
})
function tacticalGoal (self, seen, baseFocus, baseCues = []) {
  if (baseFocus !== 'SPRINT_KB' || !seen?.visible)
    return { focus: baseFocus, techniqueCues: baseCues, phase: 'other-curriculum' }
  const eyeY = Number.isFinite(self.eyeY) ? self.eyeY : self.y + 1.62
  const dx = Math.max(0, Math.abs(seen.x - self.x) - .3)
  const dz = Math.max(0, Math.abs(seen.z - self.z) - .3)
  const dy = Math.max(0, seen.y - eyeY, eyeY - (seen.y + 1.8))
  const reach = Math.hypot(dx, dy, dz)
  if (!Number.isFinite(reach))
    return { focus: baseFocus, techniqueCues: baseCues, phase: 'invalid-public-position' }
  // These are editable training contexts, not legal-hit gates. Native reach and
  // all action decisions remain with the existing 7k actor and executor.
  if (reach < 2.4) return { focus: 'COMBO', techniqueCues: ['CRITICAL','CHARGE'],
    phase: 'deep-melee-options', reach }
  return { focus: 'SPRINT_KB', techniqueCues: ['CHARGE','FLANK'], reach,
    phase: reach <= 3 ? (seen.vy > .05 ? 'edge-rising-interrupt' : 'edge-ground-interrupt')
      : 'approach-legal-boundary' }
}
module.exports = { OPERATOR_TACTICS, tacticalGoal }
