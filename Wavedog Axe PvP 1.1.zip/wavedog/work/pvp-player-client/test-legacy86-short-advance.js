'use strict'
const assert=require('node:assert/strict')
const {planShortAdvance}=require('./protocol-legacy86-threat')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {createOutputGate}=require('./protocol-legacy86-output-gate')
const {createRoutePlanner}=require('./protocol-legacy86-planner')
const {frame,probe}=require('./test-legacy86-control')
const latency={oneWayMs:0,serverQueueMs:0,decisionMs:0}
const outside=()=>frame({seen:{x:3.4},observation:{tick:100,reach:3.1,otherReach:3.1,distance:3.4},latency})
async function run(){
  const f=outside(),advance=planShortAdvance(f,probe)
  assert(advance?.available&&advance.contactTicks>=1&&advance.contactTicks<=3)
  assert(advance.predictedReach>=2.90&&advance.predictedReach<=3)
  assert.equal(planShortAdvance(frame({...f,observation:{...f.observation,targetAirborne:true,targetGrounded:false}}),probe),null)
  assert.equal(planShortAdvance(frame({...f,observation:{...f.observation,targetShieldRaised:true}}),probe),null)
  assert.equal(planShortAdvance(frame({...f,observation:{...f.observation,reach:2.95}}),probe),null,
    'already legal contact is not a new advance authorization or a reason to wait')
  assert.equal(planShortAdvance(f,()=>({clear:false,supported:true,margin:0})),null)
  const tooFast=frame({...f,targetVelocity:{x:-.8,y:0,z:0}})
  assert.equal(planShortAdvance(tooFast,probe),null,'a forecast that jumps past the edge band cannot claim a precision approach')
  const gate=createOutputGate()
  assert(gate.permit({slot:0,attack:false},0))
  assert(gate.permit({slot:0,attack:false,precisionApproach:true},2),'a newly selected precision approach must not wait behind navigation coalescing')
  assert(!gate.permit({slot:0,attack:false,precisionApproach:true},4),'unchanged approach must not send at 500 Hz')
  const planner=createRoutePlanner()
  const brain=createBrain({planner});await brain.ready
  try{
    const prepared=await planner.evaluate(f,probe)
    assert.deepEqual(prepared.shortAdvance,advance,'worker uses the same checked short approach')
    const s=createState('enemy');s.swordOnly=true
    // This fixed seed selects the ORIGINAL random opening; do not force the
    // option in the adapter or replace its probability with an attack macro.
    await brain.reset(s,881827381)
    const p=await brain.decide(s,f,probe,100)
    assert.equal(p.original.phase,'ACTIVE_ADVANCE','the restored inputs must reach the original probabilistic branch')
    assert(p.command.precisionApproach)
    assert.deepEqual(p.command.worldHeading,advance.heading,'the movement overlay must execute the route that authorized the option')
    assert(!p.command.attack,'a forecast outside 3 blocks never authorizes an early attack')
    const next=frame({seen:{x:3.25},observation:{tick:101,reach:2.95,otherReach:2.95,distance:3.25},
      targetMotion:{sampleTick:101},latency})
    const hit=await brain.decide(s,next,probe,101)
    assert.equal(hit.original.phase,'ACTIVE_STRIKE')
    assert(hit.command.attack,'the chosen option must submit its first real contact, not resume waiting')
    assert.equal(hit.command.slot,0)
    assert.equal(hit.command.worldHeading,undefined,'ground spacing cannot reverse the selected forward sprint strike')
    assert(hit.command.forward>0&&hit.command.sprint)
    brain.applied(s,hit.command,{attacked:true,executedAttackId:hit.command.attackId,
      switched:false,held:0,controls:{jump:false}},101)
    brain.receipt(s,{type:'damage',attacker:'Punengbho',victim:'enemy',melee:true,
      amount:4,nativeCritical:false,attackId:hit.command.attackId},101)
    // A confirmed first hit must retain the ORIGINAL combo continuation, not
    // have its checked forward route overwritten by generic spacing.
    const flight=frame({seen:{x:5,y:.1},targetVelocity:{x:0,y:-.1,z:0},
      observation:{tick:112,reach:4.7,otherReach:4.7,distance:5,targetGrounded:false,targetAirborne:true},
      targetMotion:{sampleTick:112},latency})
    await brain.decide(s,flight,probe,112)
    const landing=frame({...outside(),observation:{...outside().observation,tick:114},
      targetMotion:{sampleTick:114}})
    const track=await brain.decide(s,landing,probe,114)
    assert.equal(track.original.phase,'COMBO_TRACK')
    assert(track.command.precisionApproach&&!track.command.attack)
    assert.deepEqual(track.command.worldHeading,planShortAdvance(landing,probe).heading)
    const edge=await brain.decide(s,frame({seen:{x:3.28},
      observation:{tick:115,reach:2.98,otherReach:2.98,distance:3.28},
      targetMotion:{sampleTick:115},latency}),probe,115)
    assert.equal(edge.original.phase,'COMBO_EDGE')
    assert(edge.command.attack&&edge.command.sprint&&edge.command.forward>0)
    assert.equal(edge.command.worldHeading,undefined,'landing combo strike retains forward knockback movement')
  }finally{await brain.close();await planner.close()}
  console.log('ORIGINAL_PROBABILISTIC_PRECISION_APPROACH_AND_CONTACT_PASS')
}
run().catch(e=>{console.error(e);process.exitCode=1})
