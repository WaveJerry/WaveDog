const assert = require('node:assert/strict')
const { createOpeningControlTracker } = require('./opening-control-feedback')
const frame = (tick, opts = {}) => ({ tick, self: { ground: true, vy: 0, ...opts.self },
  executed: { jump: false, ...opts.executed },command:{yaw:0,...opts.command},
  seen: { visible: true }, observation: { reach: opts.reach ?? 2.9 } })
const hit = { melee: true, attacker: 'enemy', victim: 'self', amount: 6 }
const tracker = () => createOpeningControlTracker('self', 'enemy')
let t = tracker(); t.damage(hit, frame(10), 9)
let r = t.observe(frame(11, { self: { ground: false, vy: .31 } }))
assert.equal(r.reward, -.05); assert.equal(r.decidedTick, 9)
assert.equal(t.observe(frame(12, { self: { ground: false, vy: .2 } })), null, 'one penalty per opener')
for (const bad of [{ ...hit, cancelled: true }, { ...hit, amount: 0 }, { ...hit, melee: false },
  { ...hit, attacker: 'third-party' }]) {
  t = tracker(); t.damage(bad, frame(10), 9)
  assert.equal(t.observe(frame(11, { self: { ground: false, vy: .3 } })), null)
}
for (const opts of [{ self: { ground: false, vy: .3 } }, { executed: { jump: true } }]) {
  t = tracker(); t.damage(hit, frame(10, opts), 9)
  assert.equal(t.observe(frame(11, { self: { ground: false, vy: .3 } })), null, 'voluntary airborne opener excluded')
}
t = tracker(); t.damage(hit, frame(10), 9)
assert.equal(t.observe(frame(11, { self: { ground: false, vy: .3 }, executed: { jump: true } })), null,
  'deliberate jump-reset ambiguity excluded')
t = tracker(); t.damage({ ...hit, attacker: 'self', victim: 'enemy' }, frame(9), 8)
t.damage(hit, frame(10), 9)
assert.equal(t.observe(frame(11, { self: { ground: false, vy: .3 } })).reward, -.025,
  'later proven control loss also costs, less than losing the opening')
t = tracker(); t.damage(hit, frame(10), 9)
assert.equal(t.observe(frame(15, { self: { ground: false, vy: .3 } })), null, 'delayed unrelated jump excluded')
for (let tick = 20; tick < 31; tick++) t.observe(frame(tick, { reach: 4 }))
t.damage(hit, frame(32), 31)
assert.equal(t.observe(frame(33, { self: { ground: false, vy: .3 } })).exchange, 1)
const forward={executed:{forward:true},self:{vz:.2}}
t=tracker();t.damage(hit,frame(10,forward),9)
assert.equal(t.observe(frame(11,{executed:{forward:true},self:{vz:-.3}})),null)
assert.equal(t.observe(frame(12,{executed:{forward:true},self:{vz:-.2}})).kind,
  'melee-displaced-against-movement','two grounded samples can prove movement loss')
t=tracker();t.damage(hit,frame(10,forward),9)
for(const tick of [11,12])assert.equal(t.observe(frame(tick,{executed:{back:true},self:{vz:-.3}})),null,
  'intentional retreat is not loss of control')
console.log('OPENING_CONTROL_FEEDBACK_PASS')
