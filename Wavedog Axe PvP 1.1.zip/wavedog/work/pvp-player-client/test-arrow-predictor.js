'use strict'
const assert=require('node:assert/strict')
const {publicArrowThreat}=require('./wavedog-arrow-predictor')
const self={x:0,y:0,z:0,vx:0,vy:0,vz:0,ground:true,yaw:0,entityId:10,ceilingClear:true}
const room=()=>8
const own={id:30,x:.18,y:1.52,z:.18,vx:-3.16,vy:-.11,vz:.06,shooterId:10}
assert.equal(publicArrowThreat([own],self,room),null,'own outgoing arrows never cancel ranged use')
const incoming={id:31,x:-6,y:1,z:0,vx:2,vy:0,vz:0,shooterId:11}
assert.equal(publicArrowThreat([incoming],self,room).id,31,'opponent incoming projectile remains a threat')
assert.equal(publicArrowThreat([incoming],self,room,()=>false),null,'solid cover blocks the prediction')
assert.equal(publicArrowThreat([{...incoming,vx:-2}],self,room),null,'away-bound arrow outside the body is harmless')
console.log('PUBLIC_ARROW_OWNERSHIP_AND_INCOMING_PATH_PASS')
