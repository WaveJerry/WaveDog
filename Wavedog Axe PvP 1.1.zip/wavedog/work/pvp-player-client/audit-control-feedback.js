'use strict'
// Replay a completed public trace without changing it or training twice.
const fs=require('node:fs')
const {createOpeningControlTracker}=require('./opening-control-feedback')
const file=process.argv[2]
if(!file)throw Error('Need a completed frame journal')
const frames=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse)
const tracker=createOpeningControlTracker('Punengbho','WaveDogSon'),feedback=[]
for(const frame of frames){
  const result=tracker.observe(frame)
  if(result)feedback.push(result)
  for(const event of frame.nativeEvents||[])tracker.damage(event,frame,frame.modelTick)
}
console.log(JSON.stringify({file,frames:frames.length,retrospectiveOnly:true,
  rewardsNotAppliedAgain:true,feedback}))
