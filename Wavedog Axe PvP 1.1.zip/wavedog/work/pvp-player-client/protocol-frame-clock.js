'use strict'
// Run against a physical frame only after its ordinary movement packet. Idle
// frames need no extra packet; flush them before the next simulation or at the
// end of this call stack. Catch-up physics steps must still run exactly once.
function createFrameClock (run) {
  let pending = 0, serial = 0
  function flush () {
    if (!pending) return
    pending = 0
    run()
  }
  return {
    beforeSimulation: flush,
    physicsTick () {
      if (pending) throw Error('Unflushed physics frame before simulation')
      const id = pending = ++serial
      queueMicrotask(() => { if (pending === id) flush() })
    },
    movementWritten (name) {
      if (['position', 'position_look', 'flying'].includes(name)) flush()
    },
    clear () { pending = 0 }
  }
}
module.exports = { createFrameClock }
