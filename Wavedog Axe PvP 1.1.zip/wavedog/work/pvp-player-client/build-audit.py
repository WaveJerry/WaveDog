from pathlib import Path
import json
import hashlib
import os
import subprocess
import zipfile

base=Path(__file__).resolve().parent
server=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classes=base/'classes';classes.mkdir(exist_ok=True)
source=base/'src/local/wavedog/playeraudit/PlayerAudit.java'
cp=os.pathsep.join(map(str,[server/'versions/1.21.1/paper-1.21.1.jar',*sorted((server/'libraries').rglob('*.jar'))]))
subprocess.run([str(server/'runtime/java21/bin/javac.exe'),'-proc:none','-encoding','UTF-8','--release','21','-cp',cp,'-d',str(classes),str(source)],check=True)
target=base/'WaveDogPlayerAudit.jar'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as jar:
    for item in sorted(classes.rglob('*.class')):jar.write(item,item.relative_to(classes).as_posix())
    jar.write(base/'plugin.yml','plugin.yml')
print(json.dumps({'jar':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2))
