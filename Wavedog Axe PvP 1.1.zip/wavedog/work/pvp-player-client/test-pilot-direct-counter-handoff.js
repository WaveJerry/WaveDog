'use strict'
const assert=require('node:assert/strict')
const brain=require('./protocol-pilot-hybrid-brain')
const observation=(extra={})=>({tick:10,visible:true,ground:true,health:20,held:7,charge:1,
  shieldReady:false,shieldEffective:false,reach:2.7,otherReach:2.7,distance:3,
  self:{x:0,z:0},target:{x:0,z:3},sentPosition:{x:0,z:0},targetYaw:0,
  selfVelocity:{x:0,y:0,z:0},targetVelocity:{x:0,y:0,z:0},wallMargin:8,
  targetShieldFacing:false,openingDraw:1,...extra})
const action=(tick,extra={})=>({decidedTick:tick,slot:7,forward:1,side:-1,sprint:true,
  jump:false,attack:false,...extra})
function counter(){
 const s=brain.createState('target','Punengbho')
 brain.receipt(s,{type:'blocked_melee',blockId:1},10)
 brain.receipt(s,{type:'shield_disabled',cooldownTicks:100},10)
 const p=brain.plan(s,observation(),action(10))
 assert.equal(p.command.kind,'counter')
 assert.equal(p.command.afterAttackSlot,undefined)
 assert(!p.command.jump&&!p.command.aimAway)
 return {s,p}
}
for(const received of [false,true]){
 const {s,p}=counter()
 brain.applied(s,p.command,true,10)
 assert.equal(s.mode,'NEURAL','packet completion, not damage confirmation, ends mechanical melee')
 if(received)brain.receipt(s,{type:'damage',attacker:'Punengbho',victim:'target',
   attackId:p.command.attackId,amount:2},11)
 const chosen=action(11,{slot:0,side:1,jump:true,sprint:false})
 const next=brain.plan(s,observation({tick:11,ground:false,mutualOutOfReach:false}),chosen)
 for(const k of ['movement','jump','sprint','attack','mainhand','look'])assert.equal(next.owners[k],'neural')
 for(const k of ['forward','side','sprint','jump','slot','attack'])assert.equal(next.command[k],chosen[k])
 assert(!next.command.aimAway,'airborne motion is model-selected, never an automatic escape')
}
let {s,p}=counter()
brain.applied(s,p.command,false,10)
assert.equal(s.mode,'GUARD','suppressed counter retains a real retry opportunity')
assert(s.blocked&&!s.pending)
assert.equal(brain.plan(s,observation({tick:11}),null).command.kind,'counter')
;({s,p}=counter())
brain.receipt(s,{type:'attack_packet',attackId:p.command.attackId,willAttack:false},10)
assert.equal(s.mode,'COUNTER','cancelled packet cannot claim execution')
brain.receipt(s,{type:'attack_packet',attackId:p.command.attackId,willAttack:true},10)
assert.equal(s.mode,'NEURAL','native packet evidence is also sufficient without a damage receipt')
// The shield disable message can follow the real attack packet.
s=brain.createState('target','Punengbho');brain.receipt(s,{type:'blocked_melee',blockId:2},10)
p=brain.plan(s,observation({shieldReady:true}),null);brain.applied(s,p.command,true,10)
assert.equal(s.mode,'COUNTER')
brain.receipt(s,{type:'shield_disabled',cooldownTicks:100},11)
assert.equal(s.mode,'NEURAL')
// Expiry of an old outcome record cannot seize neural control again.
brain.plan(s,observation({tick:21,shieldReady:true}),action(21))
assert.equal(s.mode,'NEURAL')
assert(!brain.safeShieldReturn(observation({shieldReady:true,mutualOutOfReach:true,reach:3.1,otherReach:3.1})))
assert(brain.safeShieldReturn(observation({shieldReady:true,mutualOutOfReach:true,reach:6,otherReach:6})))
assert(!brain.safeShieldReturn(observation({shieldReady:true,mutualOutOfReach:true,reach:6,otherReach:6,
 selfVelocity:{x:0,z:1},targetVelocity:{x:0,z:-1}})),'both approaching velocities reduce shield warm-up safety')
assert(!brain.safeShieldReturn(observation({shieldReady:true,mutualOutOfReach:true,reach:6,otherReach:6,targetCriticalThreat:true})))
for(const charge of [.05,.19,.2,.69]){
 const shielded=brain.createState('target','Punengbho')
 brain.receipt(shielded,{type:'blocked_melee',blockId:3},10)
 brain.receipt(shielded,{type:'shield_disabled',cooldownTicks:100},10)
 const low=brain.plan(shielded,observation({charge,targetShieldFacing:true,targetShieldRaised:true}),null)
 assert.equal(low.command.kind,'counter','an effective shield does not need a damage-ready axe')
 brain.applied(shielded,low.command,true,10)
 assert.equal(shielded.mode,'NEURAL','shield break attempt also hands off on its real packet')
}
console.log('DIRECT_COUNTER_PACKET_HANDOFF_NO_ESCAPE_AND_SAFE_SHIELD_RETURN_PASS')
