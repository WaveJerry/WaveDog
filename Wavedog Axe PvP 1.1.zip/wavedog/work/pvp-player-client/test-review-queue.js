const assert = require('node:assert/strict')
const { takeBatch } = require('./review-queue')

const current = [{ at: '3' }, { at: '4' }]
const history = [{ at: '1' }, { at: '2' }, { at: '5' }]
let turn = true
const first = takeBatch(current, history, 2, false, turn)
assert.equal(first.historical, true)
assert.deepEqual(first.batch.map(x => x.at), ['1','2'])
turn = first.nextHistoricalTurn
const second = takeBatch(current, history, 2, false, turn)
assert.equal(second.historical, false)
assert.deepEqual(second.batch.map(x => x.at), ['3','4'])
turn = second.nextHistoricalTurn
const third = takeBatch(current, history, 2, false, turn)
assert.equal(third.historical, true)
assert.deepEqual(third.batch.map(x => x.at), ['5'])
assert.equal(current.length + history.length, 0)
console.log('REVIEW_QUEUE_PASS history and live alternate without loss')
