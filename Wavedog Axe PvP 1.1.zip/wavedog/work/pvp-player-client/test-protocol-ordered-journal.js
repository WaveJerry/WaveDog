'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs'), os = require('node:os'), path = require('node:path')
const { Writable } = require('node:stream')
const { createOrderedJournal } = require('./protocol-ordered-journal')
const { saveCompletedFrames } = require('./protocol-frame-store')
async function main () {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'wavedog-journal-'))
  const file = path.join(folder, 'frames.jsonl')
  try {
    const journal = createOrderedJournal(file)
    const rows = Array.from({ length: 500 }, (_, tick) => ({ tick, id: BigInt(tick), received: 0 }))
    for (const row of rows) journal.append(row)
    assert.equal(journal.close(), journal.close(), 'finalization must be idempotent')
    await journal.close()
    const saved = fs.readFileSync(file, 'utf8').trim().split('\n').map(JSON.parse)
    assert.equal(saved.length, 500)
    assert.deepEqual(saved.map(x => x.tick), rows.map(x => x.tick), 'write order is frame order')
    assert.equal(saved[499].id, '499')
    assert.throws(() => journal.append({ tick: 500 }), /closing/)
    rows.forEach(row => { delete row.id }); rows.at(-1).received = 3
    await saveCompletedFrames(file, rows)
    assert.equal(JSON.parse(fs.readFileSync(file, 'utf8').trim().split('\n').at(-1)).received, 3,
      'drained raw writes must not overwrite the canonical native receipt')
    let errors = 0
    const broken = createOrderedJournal('unused', () => { errors++ }, () => new Writable({
      write (data, encoding, callback) { callback(Error('disk unavailable')) }
    }))
    broken.append({ tick: 1 })
    await assert.rejects(broken.close(), /disk unavailable/)
    assert.equal(errors, 1, 'write failure must be surfaced, not silently dropped')
    await createOrderedJournal(path.join(folder, 'empty')).close()
    console.log('ORDERED_JOURNAL_PASS: packet order, full frame coverage, drain-before-rewrite, errors visible')
  } finally {
    // Only this test's two known files; no recursive deletion of computed paths.
    for (const name of ['frames.jsonl', 'frames.jsonl.complete']) {
      const target = path.join(folder, name)
      if (fs.existsSync(target)) fs.unlinkSync(target)
    }
    fs.rmdirSync(folder)
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
