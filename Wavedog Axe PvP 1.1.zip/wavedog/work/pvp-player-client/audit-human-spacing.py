"""Read ordinary public frames and native receipts for recent WaveJerry bouts."""
from pathlib import Path
from collections import Counter
import json
import math
import sys
from datetime import datetime

store = Path(__file__).resolve().parent / "new-learning/selfplay"
limit = int(sys.argv[1]) if len(sys.argv) > 1 else 4

def rows(name):
    with (store / name).open(encoding="utf-8") as handle:
        for line in handle:
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue

def millis(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp() * 1000

def nearest(frames, at):
    target = millis(at)
    return min(frames, key=lambda row: abs(millis(row["at"]) - target)) if frames else None

def horizontal(frame):
    a, b = frame["self"], frame["seen"]
    return math.hypot(a["x"] - b["x"], a["z"] - b["z"])

challenges = [row for row in rows("human-challenges.jsonl")
              if row.get("opponent") == "WaveJerry"][-limit:]
ids = {row["matchId"] for row in challenges}
frames_by_id = {key: [] for key in ids}
actions_by_id = {key: [] for key in ids}
for row in rows("human-frames.jsonl"):
    key = row.get("matchId")
    if key in ids and row.get("kind") in ("action", "frame"):
        (actions_by_id if row["kind"] == "action" else frames_by_id)[key].append(row)
events_by_id = {row.get("matchId"): row.get("events", [])
                for row in rows("human-native-events.jsonl") if row.get("matchId") in ids}

for report in challenges:
    key, bot = report["matchId"], report["bot"]
    frames, actions, events = frames_by_id[key], actions_by_id[key], events_by_id.get(key, [])
    sent = []
    swings = []
    for action in actions:
        if not (action.get("executed", {}).get("attackPackets")
                or action.get("executed", {}).get("swingWithoutTarget")):
            continue
        frame = nearest(frames, action["at"])
        if frame and abs(millis(frame["at"]) - millis(action["at"])) <= 150:
            sample = {"distance": round(horizontal(frame), 2),
                         "sprint": bool(action["executed"].get("sprint")),
                         "ground": frame["self"].get("ground"),
                         "vy": round(frame["self"].get("vy", 0), 2),
                         "charge": round(frame["self"].get("charge", 0), 2)}
            (sent if action["executed"].get("attackPackets") else swings).append(sample)
    hits = {bot: [], "WaveJerry": []}
    for event in events:
        if event.get("type") != "damage" or event.get("source") != "MELEE" \
                or event.get("cancelled") or event.get("amount", 0) <= 0:
            continue
        attacker = event.get("attacker")
        if attacker in hits:
            frame = nearest(frames, event["at"])
            if frame and abs(millis(frame["at"]) - millis(event["at"])) <= 200:
                hits[attacker].append(round(horizontal(frame), 2))
    close = [a for a in actions if a.get("executed", {}).get("forward")
             and (frame := nearest(frames, a["at"]))
             and horizontal(frame) < 1.5]
    print(json.dumps({"matchId": key, "bot": bot, "winner": report.get("winner"),
                      "durationFrames": len(frames), "nativeHits": {k: len(v) for k, v in hits.items()},
                      "botHitDistances": hits[bot], "opponentHitDistances": hits["WaveJerry"],
                      "sentAttacks": sent, "swingsWithoutTarget": swings,
                      "forwardBelow1_5": len(close),
                      "crosshairMisses": report.get("crosshairMisses"),
                      "counterEscapes": report.get("tactics", {}).get("counterEscapes"),
                      "sprintEdgeHits": report.get("tactics", {}).get("sprintEdgeHits")},
                     ensure_ascii=False))
