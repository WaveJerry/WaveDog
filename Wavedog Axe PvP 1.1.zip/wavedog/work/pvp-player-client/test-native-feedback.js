const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { NativeEventStream, summarizeNativeBout, mergeTimeline } = require('./native-feedback')

const events = [
  { at: '2026-11-11T00:00:00Z', tick: 100, arena: 1, bout: 2, type: 'start' },
  { at: '2026-11-11T00:00:01Z', tick: 120, arena: 1, bout: 2, type: 'damage', source: 'MELEE', attacker: 'A', victim: 'B', amount: 0, victim_blocking: true, shield_modifier: -9 },
  { at: '2026-11-11T00:00:01Z', tick: 120, arena: 1, bout: 2, type: 'shield_disable', attacker: 'A', victim: 'B', cancelled: false },
  { at: '2026-11-11T00:00:02Z', tick: 140, arena: 1, bout: 2, type: 'damage', source: 'MELEE', attacker: 'A', victim: 'B', amount: 4, native_attack_charge: 1, attacker_fall_distance: .4, attacker_on_ground: false, attacker_sprinting: false },
  { at: '2026-11-11T00:00:03Z', tick: 160, arena: 1, bout: 2, type: 'arrow_launch', shooter: 'B', held: 'BOW' },
  { at: '2026-11-11T00:00:04Z', tick: 180, arena: 1, bout: 2, type: 'damage', source: 'ARROW', attacker: 'B', victim: 'A', amount: 2 },
  { at: '2026-11-11T00:00:05Z', tick: 200, arena: 1, bout: 2, type: 'end' }
]
const summary = summarizeNativeBout(events.map((row, index) => ({ ...row, sequence: index+1 })))
assert.equal(summary.shieldBreaks, 1)
assert.equal(summary.breakFollowupHits, 1)
assert.equal(summary.blockThenArrowHits, 1)
assert.equal(summary.arrowLaunches, 1)
assert.equal(summary.arrowHits, 1)
assert.equal(summary.plausibleCriticalHits, 1)
assert.equal(summary.trace.length, 6)
assert.equal(summary.trace[0][4], 'start')
assert.equal(summary.trace.at(-1)[4], 'end')
assert.ok(summary.trace.every((x, i, rows) => i === 0 || x[1] >= rows[i-1][1]))
const timeline = mergeTimeline(
  [{ at: '2026-11-11T00:00:00Z', source: 'player', text: 'older lesson' }],
  [['2026-11-11T00:00:05Z', 'a:1:2'], ['2026-11-11T00:00:04Z', 'b:2:1']],
  [{ at: '2026-11-11T00:00:03Z', kind: 'native_event', sequence: 9, event: [2, 1, 'arrow_launch'] },
    { at: '2026-11-11T00:00:02Z', kind: 'native_event', sequence: 8, event: [1, 2, 'shield_disable'] }])
assert.deepEqual(timeline.map(x => x.at), [
  '2026-11-11T00:00:00Z', '2026-11-11T00:00:02Z', '2026-11-11T00:00:03Z',
  '2026-11-11T00:00:04Z', '2026-11-11T00:00:05Z'])

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wavedog-native-'))
try {
  const file = path.join(dir, 'bouts.jsonl')
  fs.writeFileSync(file, 'old data\n')
  const stream = new NativeEventStream(file)
  fs.appendFileSync(file, events.slice(0, 3).map(x => JSON.stringify(x)).join('\n') + '\n')
  stream.poll()
  assert.equal(stream.takeRecord(1, 2), null)
  fs.appendFileSync(file, events.slice(3).map(x => JSON.stringify(x)).join('\n') + '\n')
  const actual = stream.take(1, 2)
  assert.equal(actual.breakFollowupHits, 1)
  assert.equal(actual.arrowHits, 1)
  assert.equal(stream.take(1, 2), null)
  fs.appendFileSync(file, events.map(x => JSON.stringify(x)).join('\n') + '\n')
  const record = stream.takeRecord(1, 2)
  assert.equal(record.summary.arrowHits, 1)
  assert.equal(record.events.length, events.length)
  assert.equal(record.events[1].victim_blocking, true)
  assert.equal(stream.takeRecord(1, 2), null)
} finally { fs.rmSync(dir, { recursive: true, force: true }) }
console.log('native feedback OK')
