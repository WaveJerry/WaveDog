"""Install a nonblocking, replaceable PvP command guide near the world spawn."""
from pathlib import Path
import importlib.util
import json
import sys

from world_spawn import world_spawn


BASE = Path(__file__).resolve().parent
SERVER = Path("D:/Walt Disney/Minecraft-1.21.1-Server")
TAG = "wavedog_pvp_guide_20261113"
PANELS = [
    (
        -4,
        "PvP AI · 对话与学习\n"
        "唯一总 Qwen + 总 GRU；每局临时分身。\n"
        "/qwen <问题>  向总 Qwen 提问\n"
        "/qwen save <经验>  OP 保存待验证经验\n"
        "/msg NBot03 <内容>  私聊当前局分身\n"
        "分身回答来自总 Qwen 的本局上下文；\n"
        "GRU 负责逐帧动作，Qwen 局后复盘。\n"
        "Bot 编号只是当局载体，不是永久人格。",
    ),
    (
        4,
        "PvP AI · 对战与管理\n"
        "/selfplay duel WaveJerry NBot03  真人挑战\n"
        "进游戏确认框后开始一局；Bot 须在线。\n"
        "/selfplay status  看对局和控制器状态\n"
        "/selfplay start 10  开 10 对 / 20 Bot\n"
        "/selfplay pause  暂停新局，当前局打完\n"
        "/selfplay next 1  手动开第 1 场\n"
        "对练经验及权重持续汇总；异常局单独标记。",
    ),
]


def rcon_module():
    spec = importlib.util.spec_from_file_location("local_rcon", BASE.parents[1] / "outputs/MC-Public/rcon_local.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def panel_command(x, y, z, index, text):
    component = json.dumps({"text": text}, ensure_ascii=False, separators=(",", ":"))
    # SNBT parses the outer quoted string before the text component parses JSON.
    component = component.replace("\\", "\\\\")
    nbt = ("{Tags:[\"" + TAG + "\",\"" + TAG + f"_{index}\"],"
           "billboard:\"center\",alignment:\"left\",line_width:260,"
           "background:1073741824,shadow:1b,"
           "text:'" + component + "'}")
    return f"summon minecraft:text_display {x + .5} {y + 2} {z + 5.5} {nbt}"


def main():
    spawn = world_spawn(SERVER / "world/level.dat")
    x, y, z = (spawn[key] for key in ("SpawnX", "SpawnY", "SpawnZ"))
    if not all(isinstance(v, int) for v in (x, y, z)):
        raise SystemExit("Missing spawn coordinates")
    commands = [panel_command(x + dx, y, z, i, text)
                for i, (dx, text) in enumerate(PANELS, 1)]
    if "--dry-run" in sys.argv:
        print(json.dumps({"spawn": spawn, "commands": commands}, ensure_ascii=False, indent=2))
        return
    rcon = rcon_module()
    for dx, _ in PANELS:
        px, pz = x + dx, z + 5
        if not rcon.command(f"execute if block {px} {y - 1} {pz} minecraft:air run time query daytime") == "":
            raise SystemExit(f"No walking surface at {(px, y - 1, pz)}")
        for py in (y + 1, y + 2, y + 3):
            if not rcon.command(f"execute if block {px} {py} {pz} minecraft:air run time query daytime"):
                raise SystemExit(f"Display space occupied at {(px, py, pz)}")
    old = rcon.command(f"execute if entity @e[type=minecraft:text_display,tag={TAG}] run time query daytime")
    if old:
        response = rcon.command(f"kill @e[type=minecraft:text_display,tag={TAG}]")
        if "Killed" not in response and "杀死" not in response:
            raise SystemExit(f"Could not replace old guide: {response}")
    for index, command in enumerate(commands, 1):
        response = rcon.command(command)
        if "Summoned" not in response and "已召唤" not in response:
            raise SystemExit(f"Panel {index} failed: {response}")
    found = [rcon.command(f"execute if entity @e[type=minecraft:text_display,tag={TAG}_{i}] run time query daytime")
             for i in range(1, len(commands) + 1)]
    if not all(found):
        raise SystemExit(f"Guide verification failed: {found}")
    receipt = {"spawn": spawn, "tag": TAG, "panels": len(commands),
               "positions": [[x + dx + .5, y + 2, z + 5.5] for dx, _ in PANELS],
               "verified": True}
    (BASE / "new-learning/spawn-tutorial-receipt.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
