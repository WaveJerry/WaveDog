// One shared callback uses EventEmitter's actual sender. Its bindings are held
// outside the live-edited controller and cannot migrate between bot closures.
const bindings = new WeakMap()
function learningPhysicsTick () {
  const binding = bindings.get(this)
  if (!binding) return
  const session = binding.sessions.get(this.username)
  if (!session || session.name !== this.username) return
  session.clientFrame++
  session.framesSeen++
  binding.recordFighterFrame(session, this)
  binding.requestAction(session)
}
function installLearningFrames (bot, dependencies, replaceLegacy = false) {
  if (!(dependencies.sessions instanceof Map)
      || typeof dependencies.recordFighterFrame !== 'function'
      || typeof dependencies.requestAction !== 'function') throw Error('Invalid learning-frame dependencies')
  if (replaceLegacy && !bindings.has(bot)) {
    const legacy = bot.listeners('physicsTick').filter(fn => {
      const source = Function.prototype.toString.call(fn)
      return source.includes('session.clientFrame++; session.framesSeen++')
        && source.includes('recordFighterFrame(session, bot)')
        && source.includes('requestAction(session)')
    })
    if (legacy.length !== 1) throw Error('Expected exactly one verified legacy frame listener for ' + bot.username)
    bot.removeListener('physicsTick', legacy[0])
  }
  if (!bindings.has(bot)) bot.on('physicsTick', learningPhysicsTick)
  bindings.set(bot, dependencies)
}
module.exports = { installLearningFrames }
