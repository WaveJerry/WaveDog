// One ordinary 1.21.1 client checks the deployed game command through AuthMe.
const mineflayer = require('mineflayer')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')

const name = 'QwenProbe01'
const credentialFile = path.join(__dirname, '.auth-qwen-probe.json')
const credential = fs.existsSync(credentialFile)
  ? JSON.parse(fs.readFileSync(credentialFile, 'utf8')).password
  : crypto.randomBytes(18).toString('hex')
if (!fs.existsSync(credentialFile))
  fs.writeFileSync(credentialFile, JSON.stringify({ password: credential }), { mode: 0o600 })
const bot = mineflayer.createBot({ host: '127.0.0.1', port: 25566,
  username: name, version: '1.21.1', auth: 'offline', keepAlive: true })
let requested = false, answered = false
function finish (code, result) {
  if (answered) return
  answered = true
  console.log(JSON.stringify(result))
  bot.quit()
  setTimeout(() => process.exit(code), 300)
}
bot.on('spawn', () => {
  if (requested) return
  requested = true
  bot.chat(`/register ${credential} ${credential}`)
  setTimeout(() => bot.chat(`/login ${credential}`), 1200)
  setTimeout(() => bot.chat('/qwen 用一句话说明普通攻击蓄力与必要轻击如何取舍'), 3500)
})
bot.on('messagestr', message => {
  if (/Qwen：|Qwen:/.test(message)) finish(0, { ok: true, answer: message })
  if (/Qwen 回答失败/.test(message)) finish(1, { ok: false, error: message })
})
bot.on('error', error => { if (!answered) console.error(String(error)) })
setTimeout(() => finish(1, { ok: false, error: 'No in-game Qwen reply within 170 seconds' }), 170000)
