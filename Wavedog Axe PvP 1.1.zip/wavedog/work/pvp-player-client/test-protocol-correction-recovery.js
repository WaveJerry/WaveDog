'use strict'
const assert=require('node:assert/strict')
const {createDecisionDispatch}=require('./protocol-decision-dispatch')
const {recoverPositionCorrection}=require('./protocol-correction-recovery')
const applied=[],dispatch=createDecisionDispatch((frame,action,reason)=>applied.push({frame,action,reason}))
const requests=new Map([[1,{tick:10}],[2,{tick:11}]])
let controls={forward:true,sprint:true,jump:true},latest={decidedTick:10},sent={x:10},using=true,cleared=0
dispatch.open({tick:10,matchId:'a',requestId:1})
recoverPositionCorrection({dispatch,frameClock:{clear(){cleared++}},requestContexts:requests,
 clearControls(){controls={forward:false,sprint:false,jump:false}},stopUse(){using=false},
 invalidate(){latest=null;sent={...sent,falling:false}}})
assert.equal(applied.length,1)
assert.equal(applied[0].reason,'forced-move')
assert.equal(applied[0].action,null)
assert.deepEqual(controls,{forward:false,sprint:false,jump:false})
assert.equal(requests.size,0,'old responses cannot repopulate latest after a correction')
assert.equal(latest,null);assert.deepEqual(sent,{x:10,falling:false});assert.equal(using,false);assert.equal(cleared,1)
assert.equal(dispatch.reply({decidedTick:10,requestId:1},'a',10),false)
dispatch.open({tick:11,matchId:'a',requestId:3})
const fresh={decidedTick:11,requestId:3,forward:1,sprint:true,slot:0,attack:true}
assert.equal(dispatch.reply(fresh,'a',11),true)
assert.deepEqual(applied[1].action,fresh,'fresh corrected-state model command is not overwritten')
recoverPositionCorrection({dispatch,frameClock:{clear(){}},requestContexts:requests,
 clearControls(){},stopUse(){},invalidate(){}})
assert.equal(applied.length,2,'correction without a pending frame cannot create a phantom action')
console.log('POSITION_CORRECTION_RELEASES_STALE_INPUT_AND_ACCEPTS_FRESH_MODEL_PASS')
