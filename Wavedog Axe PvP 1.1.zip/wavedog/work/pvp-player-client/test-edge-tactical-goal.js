const assert = require('node:assert/strict')
const { tacticalGoal } = require('./edge-tactical-goal')
const self = { x: 0, y: 221, z: 0, eyeY: 222.62 }
const seen = { visible: true, x: 0, y: 221, z: 3.2, vy: 0 }
const edge = tacticalGoal(self, seen, 'SPRINT_KB')
assert.equal(edge.phase, 'edge-ground-interrupt')
assert(Math.abs(edge.reach - 2.9) < 1e-10)
assert.equal(tacticalGoal(self, { ...seen, vy: .2 }, 'SPRINT_KB').phase, 'edge-rising-interrupt')
assert.equal(tacticalGoal(self, { ...seen, z: 3.5 }, 'SPRINT_KB').phase, 'approach-legal-boundary')
assert.equal(tacticalGoal(self, { ...seen, z: 2 }, 'SPRINT_KB').focus, 'COMBO')
assert.equal(tacticalGoal(self, seen, 'CRITICAL').focus, 'CRITICAL')
assert.equal(tacticalGoal(self, { ...seen, visible: false }, 'SPRINT_KB').phase, 'other-curriculum')
for (const key of ['attack','jump','forward','side','sprint','slot']) assert(!(key in edge))
console.log('EDGE_TACTICAL_GOAL_PASS: public legal-reach contexts; no scripted input; other styles retained')
