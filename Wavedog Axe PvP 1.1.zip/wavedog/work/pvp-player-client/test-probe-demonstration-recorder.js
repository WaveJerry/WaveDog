const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path')
const {Vec3}=require('vec3')
const {createProbeRecorder}=require('./probe-demonstration-recorder')
const file=path.resolve('outputs/punengbho-rebuild-20261117/recorder-test-'+Date.now()+'.jsonl')
const controls={jump:false,sprint:false},bot={username:'teacher',health:20,food:20,quickBarSlot:0,
  entity:{position:new Vec3(0,0,0),velocity:new Vec3(0,0,0),onGround:true,yaw:0,pitch:0},
  world:{raycast:()=>null},getControlState:k=>Boolean(controls[k])}
const recorder=createProbeRecorder(bot),target={position:new Vec3(0,0,2),metadata:[],equipment:[],yaw:0}
const cmd={active:true,demonstrationFile:file,matchId:'recorder-regression',target:'learner',mode:'critical'}
// Deliberately simulate catch-up ticks in ONE synchronous call stack. A
// queueMicrotask finalizer records the second tick's keys on the first tick.
recorder.begin(cmd,target,1);controls.jump=true;controls.sprint=false;recorder.end()
recorder.begin(cmd,target,2);controls.jump=false;controls.sprint=true;recorder.end()
const rows=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse)
assert.equal(rows[0].schema,'exact-protocol-demonstration-v2')
assert.equal(rows[1].executed.jump,true);assert.equal(rows[1].executed.sprint,false)
assert.equal(rows[2].executed.jump,false);assert.equal(rows[2].executed.sprint,true)
bot.inventory={slots:[]}
bot.inventory.slots[45]={name:'shield',count:1}
bot.inventory.slots[37]={name:'bow',count:1}
bot.inventory.slots[40]={name:'crossbow',count:1,
  componentMap:new Map([['charged_projectiles',{data:[{itemCount:1}]}]])}
bot.inventory.slots[44]={name:'arrow',count:5}
recorder.begin({...cmd,shieldDisabledUntil:4},target,3);recorder.end()
recorder.begin({...cmd,shieldDisabledUntil:4},target,4);recorder.end()
const inventoryRows=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse)
assert.equal(inventoryRows[3].publicRequest.self.shieldAvailable,false,'actual local shield cooldown is observed')
assert.equal(inventoryRows[4].publicRequest.self.shieldAvailable,true,'carried but unused shield is not hidden')
assert.equal(inventoryRows[4].publicRequest.self.crossbowLoaded,true)
assert.equal(inventoryRows[4].publicRequest.self.arrows,5)
assert.equal(inventoryRows[4].publicRequest.self.hasBow,true)
assert.equal(inventoryRows[4].publicRequest.self.hasCrossbow,true)
console.log('CATCH_UP_FRAME_RECORDING_PASS')
