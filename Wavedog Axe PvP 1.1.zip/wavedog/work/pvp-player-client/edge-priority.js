// Curriculum emphasis changes learning signals, never the executed movement/attack.
const EDGE_PRIORITY = Object.freeze({ trials: 3, period: 4, multiplier: 6, extraBudget: .6 })
function edgePriorityPlan (plan, index, bout) {
  return (bout + index) % EDGE_PRIORITY.period < EDGE_PRIORITY.trials
    ? { ...plan, focus: 'SPRINT_KB', curriculumSource: 'edge-interrupt-priority' } : plan
}
function edgePriorityReward (result, budget) {
  const verified = Number.isFinite(result.verifiedAttackReach)
    && result.verifiedAttackReach >= 2.7 && result.verifiedAttackReach <= 3
  if (!['safe-edge-hit','retreat-edge-break'].includes(result.kind) || !(result.reward > 0) || !verified) return result.reward
  const extra = Math.min(budget.remaining, result.reward * (EDGE_PRIORITY.multiplier - 1))
  budget.remaining -= extra
  return result.reward + extra
}
module.exports = { EDGE_PRIORITY, edgePriorityPlan, edgePriorityReward }
