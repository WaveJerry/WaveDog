// Temporary ordinary protocol opponent. It never drives WaveDog or spoofs input.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto')
const mineflayer=require('mineflayer')
const {Vec3}=require('vec3')
const {solvePitch}=require('./ballistic-aim')
const {nearestHitPoint,immediateLook}=require('./protocol-mechanical-math')
const {edgePlan,eyeReach}=require('./probe-edge-controller')
const {shieldCycle}=require('./probe-shield-cycle')
const {readProbeCommand}=require('./probe-command-reader')
const dir=path.resolve(process.env.WAVEDOG_PROBE_RUNTIME||path.join(__dirname,'../wavedog-protocol/runtime'));fs.mkdirSync(dir,{recursive:true})
const auth=path.join(dir,'probe-auth.json')
if(!fs.existsSync(auth))fs.writeFileSync(auth,JSON.stringify({password:crypto.randomBytes(18).toString('hex')}))
const password=JSON.parse(fs.readFileSync(auth)).password
const probeName=process.env.WAVEDOG_PROBE_NAME||'WDProtocolProbe'
const bot=mineflayer.createBot({host:'127.0.0.1',port:25566,version:'1.21.1',username:probeName,auth:'offline',hideErrors:true})
const demonstration=require('./probe-demonstration-recorder').createProbeRecorder(bot)
const publicFeedbackFile=process.env.WAVEDOG_PROBE_FEEDBACK||null
const publicFeedback=row=>{if(publicFeedbackFile)fs.appendFileSync(publicFeedbackFile,JSON.stringify({capturedAt:Date.now(),...row})+'\n')}
let tick=0,last=0,authAt=0,useAt=0,mode=null,fixedYaw=null,equipping=false,shieldSince=null
let lastKnownHealth=null,shieldTrialUntil=-1,shieldDisabledUntil=-1,recoveryBrokeAt=null
let lastSentMotion=null,lastWeaponTick=-1000,finished=false
let closeTrade=false,farTradeSince=null
let lastShieldStrike=-1000
let modeStartTick=0,bowDrawCount=0,bowCancelledUntil=0
const writePacket=bot._client.write.bind(bot._client)
bot._client.write=(name,data)=>{
  demonstration.packet(name,data,tick)
  const result=writePacket(name,data)
  if(name==='held_item_slot')lastWeaponTick=tick
  if(['position','position_look'].includes(name)&&Number.isFinite(data.y))
    lastSentMotion={x:data.x,y:data.y,z:data.z,falling:Boolean(lastSentMotion&&data.y<lastSentMotion.y-1e-7&&!data.onGround)}
  return result
}
bot.on('death',()=>{finished=true;bot.clearControlStates()})
bot._client.on('set_cooldown',packet=>{
  if(packet.itemID===bot.registry.itemsByName.shield?.id&&packet.cooldownTicks>0){
    shieldDisabledUntil=tick+packet.cooldownTicks
    const file=path.join(dir,'probe-command.json'),cmd=readProbeCommand(file)||{}
    fs.appendFileSync(path.join(dir,'probe-shield-receipts.jsonl'),JSON.stringify({at:new Date().toISOString(),
      matchId:cmd.matchId??null,tick,cooldownTicks:packet.cooldownTicks,
      source:'ordinary-opponent-client-set_cooldown',recipient:probeName})+'\n')
    publicFeedback({type:'shield-cooldown',recipient:probeName,tick,matchId:cmd.matchId,cooldownTicks:packet.cooldownTicks})
  }
})
function select(name){
  const canonical={diamond_sword:0,diamond_axe:7}[name]
  const preferred=canonical===undefined?null:bot.inventory.slots[36+canonical]
  if(preferred?.name===name){
    if(bot.quickBarSlot===canonical)return true
    if(bot.usingHeldItem)bot.deactivateItem()
    useAt=0;bot.setQuickBarSlot(canonical)
    return bot.heldItem?.name===name
  }
  if(bot.heldItem?.name===name)return true
  const item=bot.inventory.items().find(i=>i.name===name)
  if(!item||equipping)return false
  if(bot.usingHeldItem)bot.deactivateItem()
  useAt=0
  if(item.slot>=36&&item.slot<45)bot.setQuickBarSlot(item.slot-36)
  else {equipping=true;bot.equip(item,'hand').catch(()=>{}).finally(()=>{equipping=false})}
  return bot.heldItem?.name===name
}
bot.once('spawn',()=>{
  fs.writeFileSync(path.join(dir,'probe-ready.json'),JSON.stringify({pid:process.pid,name:probeName,entityId:bot.entity.id}))
  const simulate=bot.physics.simulatePlayer.bind(bot.physics)
  bot.physics.simulatePlayer=(state,world)=>{
    if(bot.usingHeldItem)state.control={...state.control,sprint:false,
      forward:Number(state.control.forward)*.2,back:Number(state.control.back)*.2,
      left:Number(state.control.left)*.2,right:Number(state.control.right)*.2}
    return simulate(state,world)
  }
})
bot.on('messagestr',text=>{
  if(Date.now()-authAt<2000)return
  if(/\/register/i.test(text)){authAt=Date.now();bot.chat('/register '+password+' '+password)}
  else if(/\/login/i.test(text)){authAt=Date.now();bot.chat('/login '+password)}
})
bot.on('physicsTick',()=>{
  tick++
  const file=path.join(dir,'probe-command.json')
  const cmd=readProbeCommand(file)
  if(!cmd){bot.clearControlStates();return}
  const target=bot.players[cmd.target || 'WaveDog']?.entity
  if(!cmd.active&&[0,4,7].includes(cmd.prepareSlot)&&bot.quickBarSlot!==cmd.prepareSlot)
    bot.setQuickBarSlot(cmd.prepareSlot)
  if(finished||!target||!cmd.active){bot.clearControlStates();return}
  publicFeedback({type:'public-client-state',recipient:probeName,tick,matchId:cmd.matchId,health:bot.health,
    position:bot.entity.position,using:bot.usingHeldItem})
  demonstration.begin({...cmd,shieldDisabledUntil,closeJumpVersion:2},target,tick)
  try{
  const d=target.position.minus(bot.entity.position),dist=d.norm()
  if(tick%10===0)fs.writeFileSync(path.join(dir,'probe-state.json'),JSON.stringify({tick,mode,
    slot:bot.quickBarSlot,held:bot.heldItem?.name,using:bot.usingHeldItem,dist,health:bot.health,
    lastSentMotion,lastWeaponTick,finished,
    inventory:bot.inventory.items().map(i=>({slot:i.slot,name:i.name,count:i.count}))}))
  if(cmd.mode!==mode){mode=cmd.mode;useAt=0;fixedYaw=null;shieldSince=null;recoveryBrokeAt=null;
    modeStartTick=tick;bowDrawCount=0;bowCancelledUntil=0;closeTrade=false;farTradeSince=null;if(bot.usingHeldItem)bot.deactivateItem()}
  if(mode==='adapter-stationary'){bot.clearControlStates();return}
  if(mode==='adapter-directional-input'){
    require('./probe-directional-input').adapterTrial({bot,target,tick,cmd,dir,startTick:modeStartTick,lastSentMotion})
    return
  }
  if(mode==='edge-mixed'){
    if(Math.hypot(d.x,d.z)<2.45){closeTrade=true;farTradeSince=null}
    else if(closeTrade&&Math.hypot(d.x,d.z)>3.6){
      farTradeSince??=tick;if(tick-farTradeSince>=3)closeTrade=false
    }else farTradeSince=null
  }
  if(mode==='sync-check'){
    bot.clearControlStates()
    bot.look(Math.atan2(-d.x,-d.z),0,true)
    bot.setControlState('back',Math.hypot(d.x,d.z)<8)
    if(cmd.fire&&!useAt&&select('crossbow')){
      bot.activateItem();useAt=tick
      fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),tick,mode,action:'crossbow-use'})+'\n')
    }
    return
  }
  if(mode==='break-follow'){
    bot.clearControlStates()
    bot.look(Math.atan2(-d.x,-d.z),0,true)
    bot.setControlState('forward',true)
    bot.setControlState('sprint',true)
    if(!select('diamond_axe'))return
    if(fixedYaw===null)fixedYaw=tick
    const flags=Number(target.metadata?.[8]||0)
    const shield=(flags&3)===3&&target.equipment?.[1]?.name==='shield'
    if(shield&&shieldSince===null)shieldSince=tick
    if(!shield)shieldSince=null
    if(!useAt&&dist<=.65&&tick-fixedYaw>=20&&shieldSince!==null&&tick-shieldSince>=5){
      if(bot.usingHeldItem)bot.deactivateItem()
      bot.attack(target);useAt=tick
      fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),tick,mode,action:'one-axe-then-follow'})+'\n')
    }
    return
  }
  if(mode==='load'){
    bot.clearControlStates();bot.look(Math.atan2(-d.x,-d.z),0,true)
    if(!select('crossbow'))return
    if(!useAt){bot.activateItem();useAt=tick}
    else if(tick-useAt===26)bot.deactivateItem()
    return
  }
  if(mode==='shield'){
    if(fixedYaw===null)fixedYaw=Math.atan2(-d.x,-d.z)
    const yaw=cmd.track===false?fixedYaw:Math.atan2(-d.x,-d.z)
    bot.look(cmd.away?yaw+Math.PI:yaw,0,true)
    bot.setControlState('forward',dist>.55);bot.setControlState('sprint',false)
    if(!bot.usingHeldItem){bot.activateItem(true);useAt=tick}
    if(cmd.interrupt&&dist<1.6&&tick-last>=30){bot.deactivateItem();bot.attack(target);last=tick}
    return
  }
  if(mode==='shield-cycle'){
    const plan=shieldCycle(tick,modeStartTick,cmd.shieldCycleOffset??0,shieldDisabledUntil)
    bot.clearControlStates()
    const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
    const point=nearestHitPoint(eye,target),delta={x:point.x-eye.x,y:point.y-eye.y,z:point.z-eye.z}
    immediateLook(bot,Math.atan2(-delta.x,-delta.z),Math.atan2(delta.y,Math.hypot(delta.x,delta.z)))
    // Sampling-only opponent variant: expose actual held-crossbow / shield
    // transitions, without treating a crossbow as a melee sword or firing it.
    // No main or pilot model input is replaced by this probe.
    const cycleWeapon=cmd.shieldCycleWeapon==='crossbow'?'crossbow':'diamond_sword'
    if(!select(cycleWeapon))return
    if(plan.raiseShield){
      bot.setControlState('forward',Math.hypot(d.x,d.z)>1.65)
      if(!bot.usingHeldItem)bot.activateItem(true)
      return
    }
    if(bot.usingHeldItem)bot.deactivateItem()
    bot.setControlState('forward',Math.hypot(d.x,d.z)>1.4)
    bot.setControlState('sprint',Math.hypot(d.x,d.z)>1.4)
    if(cycleWeapon==='diamond_sword'&&lastSentMotion&&eyeReach(bot.entity.position,bot.entity.eyeHeight||1.62,target)<=3
        &&eyeReach(lastSentMotion,bot.entity.eyeHeight||1.62,target)<=3
        &&tick-last>=13&&tick-lastWeaponTick>=12){
      bot.attack(target);last=tick
      fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),
        matchId:cmd.matchId,tick,mode,phase:'shield-cycle-sword-pressure',phaseTick:plan.phaseTick})+'\n')
    }
    return
  }
  if(mode==='bow'){
    bot.clearControlStates();bot.look(Math.atan2(-d.x,-d.z),solvePitch(Math.hypot(d.x,d.z),d.y-.4,3),true)
    bot.setControlState('back',dist<7)
    if(!select('bow'))return
    if(tick<bowCancelledUntil)return
    const record=action=>fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({
      at:new Date().toISOString(),matchId:cmd.matchId,tick,mode,action,draw:bowDrawCount})+'\n')
    if(!useAt){bot.activateItem();useAt=tick;bowDrawCount++;record('bow-draw')}
    else if(cmd.bowCancelEvery>0&&bowDrawCount%cmd.bowCancelEvery===0&&tick-useAt>=10){
      // A normal slot switch cancels this opponent's main-hand draw. Do not
      // call deactivateItem: that would shoot instead of testing cancellation.
      bot.setQuickBarSlot(0);bot.usingHeldItem=false;useAt=0;bowCancelledUntil=tick+8;record('bow-cancel')
    }
    else if(tick-useAt>=20){bot.deactivateItem();useAt=0;record('bow-release')}
    return
  }
  if(mode==='shield-recovery'&&recoveryBrokeAt===null){
    // One ordinary charged axe break, then sword pressure through recovery.
    // This opponent never sets WaveDog's state or changes vanilla mechanics.
    bot.clearControlStates();bot.look(Math.atan2(-d.x,-d.z),0,true)
    bot.setControlState('forward',dist>1.8);bot.setControlState('sprint',dist>1.8)
    if(!select('diamond_axe'))return
    if(fixedYaw===null)fixedYaw=tick
    const shield=(Number(target.metadata?.[8]||0)&3)===3&&target.equipment?.[1]?.name==='shield'
    shieldSince=shield?(shieldSince??tick):null
    if(dist<=2.8&&tick-fixedYaw>=23&&shieldSince!==null&&tick-shieldSince>=5){
      bot.attack(target);recoveryBrokeAt=tick;last=tick
    }
    return
  }
  if(mode==='critical-switch'){
    bot.clearControlStates()
    const flags=Number(target.metadata?.[8]||0)
    const active=flags&2?target.equipment?.[1]:target.equipment?.[0]
    const raised=Boolean(flags&1)&&active?.name==='shield'
    shieldSince=raised?(shieldSince??tick):null
    if(raised){
      const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
      const point=nearestHitPoint(eye,target),delta={x:point.x-eye.x,y:point.y-eye.y,z:point.z-eye.z}
      immediateLook(bot,Math.atan2(-delta.x,-delta.z),Math.atan2(delta.y,Math.hypot(delta.x,delta.z)))
      bot.setControlState('forward',Math.hypot(d.x,d.z)>1.7)
      bot.setControlState('sprint',Math.hypot(d.x,d.z)>1.7)
      const legal=eyeReach(bot.entity.position,bot.entity.eyeHeight||1.62,target)<=3
        &&lastSentMotion&&eyeReach(lastSentMotion,bot.entity.eyeHeight||1.62,target)<=3
      if(tick-shieldSince>=5&&legal&&tick-lastShieldStrike>=20){
        if(!select('diamond_axe'))return
        bot.attack(target);last=lastShieldStrike=tick
        fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),matchId:cmd.matchId,tick,mode,
          phase:'visible-shield-axe-strike',reach:eye.distanceTo(point)})+'\n')
      }else if(lastShieldStrike<modeStartTick)select('diamond_sword')
      // Keep the axe through its actual packet frame. Return to the sword on
      // a subsequent frame; never label an axe strike as sword damage.
      return
    }
  }
  if(mode==='critical'||mode==='critical-switch'||mode==='edge-mixed'&&closeTrade||mode==='shield-recovery'&&tick-recoveryBrokeAt<125){
    bot.clearControlStates()
    if(!select('diamond_sword'))return
    bot.look(Math.atan2(-d.x,-d.z),Math.atan2(d.y-.62,Math.hypot(d.x,d.z)),true)
    bot.setControlState('forward',Math.hypot(d.x,d.z)>1.7)
    bot.setControlState('sprint',Math.hypot(d.x,d.z)>1.7)
    // Ordinary held-space input at close range. Vanilla physics determines
    // when the next jump is possible; no artificial 15-tick rest interval.
    // Distant entry remains grounded rather than jumping into a spacing hit.
    // Explicit defense acceptance uses an incoming jump from outside contact.
    // Ordinary close-critical practice retains its original close start.
    bot.setControlState('jump',Math.hypot(d.x,d.z)<(cmd.risingThreatProbe?4.2:2.45))
    const vertical=Math.max(0,bot.entity.position.y+1.62-target.position.y-1.8)
    const reach=Math.hypot(Math.max(0,Math.abs(d.x)-.3),Math.max(0,Math.abs(d.z)-.3),vertical)
    // The server has to receive a descending position BEFORE the attack.
    // Local predicted vy can already be negative while the wire is at apex.
    if(!bot.entity.onGround&&lastSentMotion?.falling&&reach<=3&&tick-last>=13&&tick-lastWeaponTick>=12){
      bot.setControlState('sprint',false)
      const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
      const point=nearestHitPoint(eye,target),delta={x:point.x-eye.x,y:point.y-eye.y,z:point.z-eye.z}
      immediateLook(bot,Math.atan2(-delta.x,-delta.z),Math.atan2(delta.y,Math.hypot(delta.x,delta.z)))
      bot.attack(target);last=tick
      fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),matchId:cmd.matchId,tick,mode,reach,
        phase:'close-critical',wireReach:reach,charge:1})+'\n')
    }
    return
  }
  if(mode==='combo-shield'){
    if(lastKnownHealth!==null&&bot.health<lastKnownHealth
        &&target.equipment?.[0]?.name==='diamond_sword'&&tick>=shieldDisabledUntil)
      shieldTrialUntil=tick+14
    lastKnownHealth=bot.health
    if(tick<shieldTrialUntil&&tick>=shieldDisabledUntil){
      bot.clearControlStates();bot.look(Math.atan2(-d.x,-d.z),0,true)
      bot.setControlState('forward',dist>.65)
      if(!bot.usingHeldItem)bot.activateItem(true)
      return
    }
    if(bot.usingHeldItem)bot.deactivateItem()
  }
  if(mode==='edge-control'||mode==='edge-mixed'){
    bot.clearControlStates()
    if(!select(cmd.slot===7?'diamond_axe':'diamond_sword'))return
    const plan=edgePlan({position:bot.entity.position,sentPosition:lastSentMotion,
      eyeHeight:bot.entity.eyeHeight||1.62,target,tick,lastAttack:last,lastWeaponTick,
      weapon:bot.heldItem?.name==='diamond_axe'?'axe':'sword'})
    const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
    const point=nearestHitPoint(eye,target),delta={x:point.x-eye.x,y:point.y-eye.y,z:point.z-eye.z}
    immediateLook(bot,Math.atan2(-delta.x,-delta.z),Math.atan2(delta.y,Math.hypot(delta.x,delta.z)))
    bot.setControlState('forward',plan.forward>0);bot.setControlState('back',plan.forward<0)
    bot.setControlState('sprint',plan.sprint)
    const length=Math.hypot(delta.x,delta.y,delta.z)
    const clear=length<.001||!bot.world.raycast(eye,new Vec3(delta.x/length,delta.y/length,delta.z/length),length)
    if(plan.attack&&clear){
      if(bot.usingHeldItem)bot.deactivateItem()
      // A sprint strike can occur on the entry tick; ordinary backward
      // spacing does not gain illegal sprint speed by setting a sprint flag.
      bot.attack(target);last=tick
      fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),
        matchId:cmd.matchId,tick,mode,phase:'ground-edge',reach:plan.reach,wireReach:plan.wireReach,charge:plan.charge,edgeWindow:plan.edgeWindow})+'\n')
    }
    return
  }
  bot.look(Math.atan2(-d.x,-d.z),0,true)
  bot.setControlState('forward',dist>(['close-pressure','combo-shield'].includes(mode)?.45:2.3))
  bot.setControlState('sprint',['pressure','close-pressure','combo-shield'].includes(mode)||dist>3)
  bot.setControlState('jump',false);bot.setControlState('sneak',false)
  const slot=cmd.slot??0
  if(!select(slot===7?'diamond_axe':'diamond_sword'))return
  if(mode==='approach')return
  if(dist<=3&&tick-last>=(slot===7?23:15)){
    if(bot.usingHeldItem)bot.deactivateItem()
    bot.attack(target);last=tick
    fs.appendFileSync(path.join(dir,'probe-attacks.jsonl'),JSON.stringify({at:new Date().toISOString(),tick,slot,dist,
      entityId:bot.entity.id,targetId:target.id,self:bot.entity.position,target:target.position})+'\n')
  }
  }finally{demonstration.end()}
})
bot.on('kicked',()=>process.exit(2));bot.on('error',()=>{})
process.on('SIGTERM',()=>{bot.clearControlStates();bot.quit();setTimeout(()=>process.exit(),200)})
setTimeout(()=>{bot.quit();setTimeout(()=>process.exit(),250)},150000)
