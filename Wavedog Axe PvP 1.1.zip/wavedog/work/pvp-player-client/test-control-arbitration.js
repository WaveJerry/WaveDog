const assert = require('node:assert/strict')
const { composeControl } = require('./control-arbitration')

const gru = { forward: -1, side: 1, sprint: true, jump: true,
  sneak: true, shield: false, attack: true, slot: 0,
  use: false, release: false }
const hand = (kind, decision, rangedOverlay = false) => ({
  kind, decision, movementOverride: false, rangedOverlay
})
const move = (kind, decision) => ({
  kind, decision, movementOverride: true, rangedOverlay: false
})

const shield = composeControl(gru,move('shield-pressure',{
  forward:1,side:1,sprint:false,jump:false,
  shield: true, attack: false, use: false }),true)
assert.equal(shield.decision.forward,1)
assert.equal(shield.decision.side,1)
assert.equal(shield.decision.sneak,false)
assert.equal(shield.decision.jump,false)
assert.equal(shield.decision.shield,true)
assert.equal(shield.controlOwner,'WaveDog-mechanical')
assert.deepEqual(shield.ignoredHeads,[0,1,2,3,4,5,6,7,8])

const counter = composeControl(gru,move('shield-counter',{
  forward:1,side:0,sprint:true,jump:false,slot:7,
  shield: false, attack: true, release: true }),true)
assert.equal(counter.decision.forward,1)
assert.equal(counter.decision.sprint,true)
assert.equal(counter.decision.jump,false)
assert.equal(counter.decision.sneak,false)
assert.equal(counter.decision.slot,7)
assert.equal(counter.decision.attack,true)
assert.ok(counter.ignoredHeads.includes(0))
assert.ok(counter.ignoredHeads.includes(1))
assert.ok(counter.ignoredHeads.includes(2))
assert.ok(counter.ignoredHeads.includes(3))

const ranged = composeControl(gru,{...move('crossbow-fire',{
  forward:0,side:1,sprint:false,jump:false,slot:4,
  shield: false, attack: false, use: true }),rangedOverlay:true},true)
assert.equal(ranged.decision.forward,0)
assert.equal(ranged.decision.side,1)
assert.equal(ranged.decision.sneak,false)
assert.equal(ranged.controlOwner,'WaveDog-ranged')
assert.ok(ranged.ignoredHeads.includes(1)) // Item use prevents sprint.

for (const kind of ['single-jump-exit','critical-exit','edge-exit-hit','arrow-side-jump','landed-return-axe']) {
  const controlled = composeControl(gru,move(kind,{ forward: 1, side: -1,
    sprint: true, jump: true, shield: false, attack: false }),true)
  assert.equal(controlled.decision.forward,1)
  assert.equal(controlled.decision.side,-1)
  assert.equal(controlled.controlOwner,'WaveDog-mechanical')
  assert.deepEqual(controlled.ignoredHeads,[0,1,2,3,4,5,6,7,8])
}

const selfplay = composeControl({ ...gru, slot: 4, use: true },null,false)
assert.equal(selfplay.controlOwner,'GRU-melee')
assert.equal(selfplay.decision.slot,7)
assert.equal(selfplay.decision.use,false)
assert.equal(selfplay.decision.sneak,false)
assert.ok(selfplay.ignoredHeads.includes(3))
assert.ok(selfplay.ignoredHeads.includes(4))
assert.ok(selfplay.ignoredHeads.includes(5))
assert.ok(selfplay.ignoredHeads.includes(8))

assert.throws(() => composeControl(gru,hand('unknown',{
  shield: true, forward: 1 }),true),/controls forward/)
assert.throws(() => composeControl(gru,{
  kind: 'unknown', movementOverride: true,
  decision: { forward: 1 } },true),/ownership mismatch/)
console.log('CONTROL_ARBITRATION_PASS')
