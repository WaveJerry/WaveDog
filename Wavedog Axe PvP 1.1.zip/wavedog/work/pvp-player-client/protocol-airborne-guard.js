'use strict'
// Direct port of the supplied 8.6 AirborneEnvelope, not the retired spacing
// controller. All inputs come from our physics or public entity/block packets.
function finite(body){
  return body&&['x','y','z','vx','vy','vz','eye','halfX','halfZ','height'].every(k=>Number.isFinite(body[k]))
    &&body.halfX>0&&body.halfZ>0&&body.height>0&&body.eye>0
}
function forecast(own,target,floor,steering,melee,critical,charge,attackSpeed){
  if(!finite(own)||!finite(target)||![floor,steering,charge,attackSpeed].every(Number.isFinite)||steering<0||attackSpeed<=0)
    return {valid:false,meleeTick:-1,criticalTick:-1,closestMelee:NaN,closestCritical:NaN,maxSteering:0,ticks:0}
  if(target.grounded||!melee)
    return {valid:true,meleeTick:-1,criticalTick:-1,closestMelee:Infinity,closestCritical:Infinity,maxSteering:0,ticks:0}
  let x=own.x,y=own.y,z=own.z,vx=own.vx,vy=own.grounded?0:own.vy,vz=own.vz
  let tx=target.x,ty=target.y,tz=target.z,tvx=target.vx,tvy=target.vy,tvz=target.vz
  let radius=0,steerVelocity=0,closestMelee=Infinity,closestCritical=Infinity,meleeTick=-1,criticalTick=-1,ticks=0
  for(let i=0;i<=20&&!(i>0&&ty<=floor+1e-6&&tvy<=0);i++){
    ticks=i
    const dx=Math.max(0,Math.abs(tx-x)-own.halfX),dz=Math.max(0,Math.abs(tz-z)-own.halfZ)
    const horizontal=Math.max(0,Math.hypot(dx,dz)-radius),eye=ty+target.eye
    const vertical=Math.max(0,y-eye,eye-(y+own.height)),reach=Math.hypot(horizontal,vertical)
    closestMelee=Math.min(closestMelee,reach)
    if(reach<3&&meleeTick<0)meleeTick=i
    if(critical&&tvy<0&&charge+i*attackSpeed/20>.9){
      closestCritical=Math.min(closestCritical,reach)
      if(reach<3&&criticalTick<0)criticalTick=i
    }
    vx*=own.grounded?.546:.91;vz*=own.grounded?.546:.91
    if(!own.grounded)vy=(vy-.08)*.98
    x+=vx;z+=vz;y+=vy
    radius+=(steerVelocity+=steering);steerVelocity*=.91
    tvy=(tvy-.08)*.98;tx+=(tvx*=.91);tz+=(tvz*=.91);ty+=tvy
  }
  return {valid:true,meleeTick,criticalTick,closestMelee,closestCritical,maxSteering:radius,ticks}
}
// AirborneObservation.floor(): lowest public solid surface in the same 20-tick
// possible footprint. Unknown columns remain the dimension's minimum height.
function forecastFloor(body,steering,minY,surface){
  let vx=body.vx,vz=body.vz,x=body.x,z=body.z,radius=0,sv=0
  let minX=x,maxX=x,minZ=z,maxZ=z
  for(let i=0;i<20;i++){
    sv*=.91;x+=(vx*=.91);z+=(vz*=.91);radius+=(sv+=steering)
    minX=Math.min(minX,x-radius);maxX=Math.max(maxX,x+radius)
    minZ=Math.min(minZ,z-radius);maxZ=Math.max(maxZ,z+radius)
  }
  if(maxX-minX>24||maxZ-minZ>24)return minY
  let floor=Infinity
  for(let x=Math.floor(minX);x<=Math.floor(maxX);x++)for(let z=Math.floor(minZ);z<=Math.floor(maxZ);z++){
    let top=minY
    for(let y=Math.floor(body.y);y>=Math.max(minY,Math.floor(body.y)-8);y--){
      const candidate=surface(x,y,z)
      if(Number.isFinite(candidate)&&candidate<=body.y+1e-6){top=candidate;break}
    }
    floor=Math.min(floor,top)
  }
  return Number.isFinite(floor)?floor:minY
}
// Position samples are not simulation ticks. Repeated packets/frames at the
// same height must not turn an airborne player into a grounded player.
function observeMotion(previous,sample,tick){
  const moved=!previous||['x','y','z'].some(k=>Math.abs(sample[k]-previous[k])>1e-7)
  let state=previous
  if(moved){
    const dt=previous?Math.max(1,tick-previous.tick):1
    const continuous=previous&&tick-previous.tick<=6&&Math.hypot(sample.x-previous.x,sample.y-previous.y,sample.z-previous.z)<4
    state={x:sample.x,y:sample.y,z:sample.z,tick,
      vx:continuous?(sample.x-previous.x)/dt:0,
      vy:continuous?(sample.y-previous.y)/dt:0,
      vz:continuous?(sample.z-previous.z)/dt:0}
  }else state={...previous}
  state.grounded=typeof sample.grounded==='boolean'?sample.grounded
    :Number.isFinite(sample.floorY)?Math.abs(sample.y-sample.floorY)<=1e-6:previous?.grounded??false
  if(state.grounded)state.vy=0
  return state
}
module.exports={forecast,forecastFloor,observeMotion}
