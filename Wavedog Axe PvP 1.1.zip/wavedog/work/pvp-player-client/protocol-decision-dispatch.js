'use strict'
// Dispatch one selected command per physical frame, as soon as its inference
// arrives after the normal movement packet. No action is generated here.
function createDecisionDispatch(apply) {
  let pending = null
  function settle(action, reason) {
    const frame = pending
    if (!frame) return false
    pending = null // Re-entrant callbacks cannot execute the same frame twice.
    apply(frame, action, reason)
    return true
  }
  return {
    open(frame) {
      if (pending) throw Error('Previous decision frame has not been settled')
      pending = frame
    },
    reply(action, matchId, physicalTick) {
      if (!pending || pending.matchId !== matchId || pending.tick !== physicalTick
          || action.decidedTick !== pending.tick || action.requestId !== pending.requestId) return false
      return settle(action, 'model-response')
    },
    deadline(latest) { return settle(latest, 'before-simulation') },
    cancel(reason='bout-ended') {
      if(!['bout-ended','forced-move'].includes(reason))throw Error('Unknown cancellation reason')
      return settle(null, reason)
    },
    hasPending() { return pending !== null }
  }
}
module.exports = { createDecisionDispatch }
