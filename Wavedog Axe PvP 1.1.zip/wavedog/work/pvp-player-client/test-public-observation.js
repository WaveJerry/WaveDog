const assert = require('node:assert/strict')
const { Vec3 } = require('vec3')
const { nearbyFlyingArrows } = require('./public-observation')

const bot = { entity: { position: new Vec3(0, 0, 0) }, entities: {
  front: { name: 'arrow', onGround: true, position: new Vec3(2, 1, 0), velocity: new Vec3(-1, 0, 0) },
  rear: { name: 'arrow', position: new Vec3(-3, 1, 0), velocity: new Vec3(1, 0, 0) },
  stuck: { name: 'arrow', position: new Vec3(1, 1, 0), velocity: new Vec3(0, 0, 0) },
  far: { name: 'arrow', position: new Vec3(40, 1, 0), velocity: new Vec3(-1, 0, 0) },
  player: { name: 'player', position: new Vec3(1, 0, 0), velocity: new Vec3(1, 0, 0) }
} }
const arrows = nearbyFlyingArrows(bot)
assert.equal(arrows.length, 2)
assert.equal(arrows[0].x, 2)
assert.equal(arrows[1].x, -3)
assert.equal(arrows[1].vx, 1)
console.log('PUBLIC_ARROWS_PASS including rear projectile')
