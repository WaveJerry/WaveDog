/** Native damage sequence evidence for sword tempo and unanswered follow-ups. */
function analyzeDamageTempo (fighter, opponent, events, actions = [], frames = []) {
  const hits = events.filter(e => e.type === 'damage' && e.source === 'MELEE'
    && !e.cancelled && e.amount > 0
    && [fighter, opponent].includes(e.attacker))
    .sort((a, b) => a.tick - b.tick || (a.sequence || 0) - (b.sequence || 0))
  let unansweredFollowupHits = 0, swordFollowupHits = 0
  let swordSwitchChains = 0, closeSwordCriticalChains = 0
  let axeIntoSwordLosses = 0, swordIntoAxeWins = 0
  const tempoOutcomes = []
  for (let i = 0; i < hits.length; i++) {
    const current = hits[i]
    if (current.attacker !== fighter) continue
    const previous = [...hits.slice(0, i)].reverse().find(e => e.attacker === fighter)
    if (!previous || current.tick - previous.tick > 30) continue
    if (hits.some(e => e.attacker === opponent && e.tick >= previous.tick
      && e.tick <= current.tick && e.sequence > previous.sequence
      && e.sequence < current.sequence)) continue
    unansweredFollowupHits++
    if (current.weapon === 'DIAMOND_SWORD') {
      swordFollowupHits++
      tempoOutcomes.push({ at: current.at, kind: 'unanswered-sword-followup', reward: .025 })
    }
  }
  // A switch is credited only when the client's executed hotbar history
  // changes from axe to sword and native sword hits follow it.
  const orderedActions = [...actions].filter(a => Number.isFinite(Date.parse(a.at)))
    .sort((a, b) => Date.parse(a.at) - Date.parse(b.at))
  let lastSlot = null, countedThrough = -Infinity
  for (const action of orderedActions) {
    const slot = action.executed?.mainSlot
    if (!Number.isInteger(slot)) continue
    const switched = lastSlot === 7 && slot === 0
    lastSlot = slot
    if (!switched || Date.parse(action.at) <= countedThrough) continue
    const switchAt = Date.parse(action.at)
    const first = hits.find(e => e.attacker === fighter
      && e.weapon === 'DIAMOND_SWORD' && Date.parse(e.at) >= switchAt
      && Date.parse(e.at) <= switchAt + 1500)
    if (!first) continue
    const second = hits.find(e => e.attacker === fighter
      && e.weapon === 'DIAMOND_SWORD' && e.tick > first.tick
      && e.tick <= first.tick + 30)
    if (!second || hits.some(e => e.attacker === opponent
      && e.tick >= first.tick && e.tick <= second.tick)) continue
    swordSwitchChains++
    countedThrough = Date.parse(second.at)
    tempoOutcomes.push({ at: second.at, kind: 'axe-to-sword-two-hit-chain', reward: .035 })
    const pointBlankCritical = [first, second].every(hit => {
      if (hit.native_critical !== true) return false
      const frame = frames.reduce((best, row) =>
        Math.abs(Date.parse(row.at) - Date.parse(hit.at))
          < (best ? Math.abs(Date.parse(best.at) - Date.parse(hit.at)) : Infinity)
          ? row : best, null)
      return frame && Math.abs(Date.parse(frame.at) - Date.parse(hit.at)) <= 150
        && Math.hypot(frame.self.x - frame.seen.x, frame.self.z - frame.seen.z) <= 1.8
    })
    if (pointBlankCritical) {
      closeSwordCriticalChains++
      tempoOutcomes.push({ at: second.at, kind: 'point-blank-sword-critical-chain', reward: .04 })
    }
  }
  let group = []
  const finish = () => {
    if (!group.length) return
    const own = group.filter(e => e.attacker === fighter)
    const enemy = group.filter(e => e.attacker === opponent)
    if (!own.length || !enemy.length) return
    const ownDamage = own.reduce((n, e) => n + e.amount, 0)
    const enemyDamage = enemy.reduce((n, e) => n + e.amount, 0)
    if (own.every(e => e.weapon === 'DIAMOND_AXE')
      && enemy.every(e => e.weapon === 'DIAMOND_SWORD')
      && enemyDamage > ownDamage + .5) {
      axeIntoSwordLosses++
      tempoOutcomes.push({ at: group.at(-1).at, kind: 'axe-lost-sword-tempo', reward: -.025 })
    }
    if (own.every(e => e.weapon === 'DIAMOND_SWORD')
      && enemy.every(e => e.weapon === 'DIAMOND_AXE')
      && ownDamage > enemyDamage + .5) swordIntoAxeWins++
  }
  for (const hit of hits) {
    if (group.length && hit.tick - group.at(-1).tick > 20) { finish(); group = [] }
    group.push(hit)
  }
  finish()
  return { unansweredFollowupHits, swordFollowupHits,
    swordSwitchChains, closeSwordCriticalChains,
    axeIntoSwordLosses, swordIntoAxeWins, tempoOutcomes }
}

module.exports = { analyzeDamageTempo }
