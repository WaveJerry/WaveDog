'use strict'
// Track public use edges on each equipment/metadata event, not only physics
// samples: stop + next draw can both arrive between two decision frames.
function observeBowUse(s,o,tick){
  const drawing=Boolean(o.visible&&o.using&&o.activeItem?.name==='bow')
  // A confirmed visible arrow ends the old draw even if stop/start metadata
  // was coalesced by the server. Do not count its pre-release use bit again
  // in that same tick; a subsequent observed use belongs to the next draw.
  if(drawing&&!s.bowDrawing&&tick<=(s.bowShotTick??-1))
    return {targetBowCycle:s.bowCycle||0,targetBowStartedTick:s.bowStartedTick??null}
  if(drawing&&!s.bowDrawing){s.bowCycle=(s.bowCycle||0)+1;s.bowStartedTick=tick}
  s.bowDrawing=drawing
  return {targetBowCycle:s.bowCycle||0,targetBowStartedTick:s.bowStartedTick??null}
}
function noteBowShot(s,tick){if(s.bowDrawing){s.bowDrawing=false;s.bowShotTick=tick}}
module.exports={observeBowUse,noteBowShot}
