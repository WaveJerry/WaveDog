'use strict'
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path')
const {spawnSync}=require('node:child_process')
const {forecast,forecastFloor,observeMotion}=require('./protocol-airborne-guard')
const {createState,plan,receipt,applied}=require('./protocol-wavedog-brain')
const root=path.resolve(__dirname,'../..'),runtime=fs.mkdtempSync(path.join(require('node:os').tmpdir(),'wavedog-airborne-test-'))
fs.mkdirSync(runtime,{recursive:true})
const own={x:0,y:0,z:0,vx:0,vy:0,vz:0,eye:1.62,halfX:.3,halfZ:.3,height:1.8,grounded:true}
let state=observeMotion(null,{x:3.5,y:.42,z:0,grounded:false,floorY:0},1)
state=observeMotion(state,{x:3.1,y:.753,z:0,grounded:false,floorY:0},2)
const repeated=observeMotion(state,{x:3.1,y:.753,z:0,grounded:false,floorY:0},3)
assert(!repeated.grounded);assert.equal(repeated.vy,state.vy);assert.equal(repeated.tick,2)
const target={...own,x:3.5,y:.753,vx:-.2,vy:.33,grounded:false}
const env=forecast(own,target,0,.0196*1.3,true,true,1,1)
assert(env.meleeTick>=0&&env.criticalTick>=0,'rising approach can have a future critical window')
assert.equal(forecast(own,{...target,grounded:true},0,.02548,true,true,1,1).meleeTick,-1)
assert.equal(forecast(own,{...target,x:40},0,.02548,true,true,1,1).meleeTick,-1,'distant jumps do not freeze ordinary pressure')
assert.equal(forecastFloor(target,.02548,-64,(_x,y)=>y===-1?0:null),0)
const obs={tick:10,visible:true,ground:true,shieldReady:true,shieldEffective:true,offhandShieldReady:true,
  targetAirborneThreat:true,targetCriticalThreat:false,targetGrounded:false,reach:2.8,distance:3,
  charge:1,held:7,wallMargin:8,targetFacingDot:-.9,openingDraw:0,health:20,
  self:{x:0,z:2},sentPosition:{x:0,z:2},target:{x:0,z:0},targetYaw:0}
let s=createState(),p=plan(s,obs,null)
assert(p.command.guardAirborne&&p.command.shield&&!p.command.attack&&!p.command.orbit)
assert.equal(p.command.forward,0)
const grounded=plan(createState(),{...obs,targetAirborneThreat:false,targetCriticalThreat:false,targetGrounded:true},null)
assert(grounded.command.attack,'safe grounded rear openings still work; this is not a permanent attack lock')
receipt(s,{type:'blocked_melee',blockId:1},10)
p=plan(s,obs,null)
assert(p.command.shield&&!p.command.attack,'usable shield stays up instead of countering into the next airborne hit')
s=createState();s.ranged='bow';s.rangedPhase='using';s.rangedAt=9
p=plan(s,{...obs,distance:7,reach:6,arrows:5,targetBow:true},null)
assert(p.command.shield&&!p.command.ranged&&p.command.offhand==='shield','ranged overlay cannot drop the air guard')
p=plan(s,{...obs,arrowThreat:{time:1,side:1,jump:true},offhandShieldReady:false},null)
assert(p.command.shield&&!p.command.jump&&!p.command.keepLook,'arrow dodge cannot drop usable melee protection')
s=createState();s.shieldUntil=100;receipt(s,{type:'blocked_melee',blockId:2},10)
p=plan(s,{...obs,shieldReady:false},null)
assert.equal(p.command.kind,'counter','a truly broken shield keeps its original counter chain')
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,{...obs,shieldReady:false},{decidedTick:10,forward:1,side:0,sprint:true,jump:true,slot:0,attack:true})
assert.equal(p.owners.attack,'neural');assert(p.command.attack,'no usable shield means ordinary neural combat remains independent')
// Replay the real failed bout. Repeated heights and the rising/apex frames
// that released shield must all become guarded without forcing grounded play.
const mid='5ed78565-d86d-4627-97f8-6248a77025d2'
const file=path.join(root,'work/wavedog-protocol/runtime',mid+'-frames.jsonl')
const rows=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse)
let motion=null,protectedReleases=[],groundedOpportunities=0
for(const f of rows){
  if(!f.seen.visible)continue
  const floor=f.publicTerrain.groundY
  motion=observeMotion(motion,{x:f.seen.x,y:f.seen.y,z:f.seen.z,floorY:floor},f.tick)
  const a={...own,x:f.self.x,y:f.self.y,z:f.self.z,vx:f.self.vx,vy:f.self.vy,vz:f.self.vz,grounded:f.self.ground}
  const b={...own,x:f.seen.x,y:f.seen.y,z:f.seen.z,vx:motion.vx,vy:motion.vy,vz:motion.vz,grounded:motion.grounded}
  const envelope=forecast(a,b,floor,.02548,true,true,1,1)
  const o={...f.observation,targetGrounded:motion.grounded,targetAirborneThreat:envelope.valid&&envelope.meleeTick>=0,
    targetCriticalThreat:envelope.valid&&envelope.criticalTick>=0}
  const candidate=plan(createState('WaveJerry'),o,null)
  if(f.self.shieldAvailable&&!f.command.shield&&envelope.meleeTick>=0){
    assert(candidate.command.shield&&!candidate.command.attack);protectedReleases.push(f.tick)
  }
  if(motion.grounded&&!f.command.shield&&candidate.command.attack)groundedOpportunities++
}
assert(protectedReleases.includes(8579)&&protectedReleases.includes(8670)&&protectedReleases.includes(8767))
// Numeric equivalence against the original release's compiled Java class.
const jar=path.join(root,'outputs/WaveDog-Works/WaveDog-盾斧pvp无敌版-含皮肤-test1-8.6-20261110-155759/plugins/PvPArenaAI.jar')
const java='D:/Walt Disney/Minecraft-1.21.1-Server/runtime/java21/bin/'
let run=spawnSync(java+'javac.exe',['-cp',jar,'-d',runtime,path.join(root,'work/wavedog-protocol/tests/AirborneEnvelopeOracle.java')],{encoding:'utf8'})
assert.equal(run.status,0,run.stderr)
let seed=12345;const rnd=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296)
const cases=Array.from({length:100},()=>{
  const a={...own,x:rnd()*4,y:rnd()*2,vx:(rnd()-.5)*.3,vy:(rnd()-.5)*.8,vz:(rnd()-.5)*.3,grounded:rnd()<.5}
  const b={...target,x:rnd()*12,y:rnd()*3,vx:(rnd()-.5)*.8,vy:(rnd()-.5)*.8,vz:(rnd()-.5)*.8,grounded:rnd()<.1}
  return [a,b,0,.02548,rnd()>.1,true,rnd(),1.6]
})
const body=b=>[b.x,b.y,b.z,b.vx,b.vy,b.vz,b.eye,b.halfX,b.halfZ,b.height,Number(b.grounded)]
run=spawnSync(java+'java.exe',['-cp',runtime+path.delimiter+jar,'local.pvpbot.ai.AirborneEnvelopeOracle'],{
  input:cases.map(([a,b,...rest])=>[...body(a),...body(b),...rest.map(x=>typeof x==='boolean'?Number(x):x)].join(' ')).join('\n')+'\n',encoding:'utf8'})
assert.equal(run.status,0,run.stderr)
run.stdout.trim().split('\n').forEach((line,i)=>{
  const values=line.split(','),actual=forecast(...cases[i])
  assert.equal(actual.valid,String(values[0])==='true')
  for(const [j,key]of ['meleeTick','criticalTick','closestMelee','closestCritical','maxSteering','ticks'].entries()){
    const expected=Number(values[j+1]),value=actual[key]
    assert(value===expected||Math.abs(value-expected)<1e-9,`original Java differs: ${i} ${key}`)
  }
})
const result={matchId:mid,originalJavaCases:100,protectedReleases,groundedOpportunities,
  portEquivalent:true,neuralUnshieldedUnchanged:true}
fs.writeFileSync(path.join(runtime,'replay-verification.json'),JSON.stringify(result,null,2))
console.log(JSON.stringify({event:'ORIGINAL_AIRBORNE_SHIELD_PORT_PASS',...result}))
