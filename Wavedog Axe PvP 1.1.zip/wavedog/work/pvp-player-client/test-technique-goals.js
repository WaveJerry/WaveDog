const assert = require('node:assert/strict')
const { techniques, techniqueGoal } = require('./technique-goals')
const { immediateRoundFact } = require('./immediate-round-memory')

assert.equal(Object.keys(techniques).length, 16)
assert.deepEqual(new Set(Object.values(techniques).flatMap(rows => rows.map(row => row[0]))),
  new Set(['STANDOFF','MELEE','RANGED']))
for (const focus of Object.keys(techniques)) {
  const seen = new Set()
  for (let bout = 1; bout <= 90; bout++) for (let fighter = 0; fighter < 20; fighter++) {
    const goal = techniqueGoal(focus, fighter, bout)
    assert(goal.goal.length > 8)
    seen.add(goal.goal)
  }
  assert.equal(seen.size, techniques[focus].length)
}
const fact = immediateRoundFact({ at: '2026-11-13T00:00:00Z', matchId: 'run:1:1',
  winner: 'A', fighters: { A: {}, B: {} }, native: { meleeHits: 3, arrowLaunches: 1 },
  tactics: { A: { blockedMelee: 1, counterHits: 1, counterEscapes: 0,
    nativeCriticalHits: 1, sprintJumpEntries: 2, sprintJumpCriticalHits: 0 }, B: {} } })
assert.equal(fact.lessonSource, 'measured-fallback')
assert.equal(fact.nativeCounts.sprintJumpEntries, 2)
assert.match(fact.lesson, /待Qwen解释/)
console.log('TECHNIQUE_GOALS_PASS 16 focus families, three stages, immediate measured memory')
