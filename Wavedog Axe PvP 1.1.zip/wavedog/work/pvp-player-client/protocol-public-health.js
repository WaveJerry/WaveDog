'use strict'
const { simplify } = require('prismarine-nbt')
// Read the SAME below-name scoreboard packets delivered to an ordinary client.
// Never query Bukkit, RCON, player inventory or referee health receipts here.
function formattedHearts (styling) {
  let text
  try { text = styling?.type ? simplify(styling) : styling } catch (_) { return null }
  if (!text || typeof text !== 'object') return null
  let red = 0, gold = 0, valid = true
  function visit (node, inherited = '') {
    if (!node || typeof node !== 'object') { valid = false; return }
    const color = (node.color || inherited).toLowerCase()
    const value = node.text || ''
    for (const char of value) {
      if (char !== '❤') { if (char.trim()) valid = false; continue }
      if (color === '#ffcc33') gold++
      else if (['#ff3333', '#ff9c9c', '#555555'].includes(color)) red++
      else valid = false
    }
    if (node.extra) for (const child of node.extra) visit(child, color)
  }
  visit(text)
  return valid && red > 0 && red <= 40 && gold <= 20 ? { capacity: red * 2, absorptionUpper: gold * 2 } : null
}
function createPublicHealthTracker (client, currentTick) {
  let objective = false, displayed = false, matchId = null
  const scores = new Map()
  client.on('scoreboard_objective', packet => {
    if (packet.name !== 'wd_hearts') return
    objective = packet.action !== 1
    if (!objective) { displayed = false; scores.clear() }
  })
  client.on('scoreboard_display_objective', packet => {
    if (packet.position === 2) displayed = packet.name === 'wd_hearts'
  })
  client.on('scoreboard_score', packet => {
    if (packet.scoreName !== 'wd_hearts') return
    if (packet.action === 1) { scores.delete(packet.itemName); return }
    if (packet.action !== undefined && packet.action !== 0) return
    const hp = packet.value
    if (!Number.isSafeInteger(hp) || hp < 0 || hp > 80 || typeof packet.itemName !== 'string') return
    const hearts = packet.number_format === 2 ? formattedHearts(packet.styling) : null
    if (hearts && hp > hearts.capacity) return
    scores.set(packet.itemName, { healthUpper: hp, healthLowerExclusive: Math.max(0, hp - 1),
      absorptionKnown: Boolean(hearts), absorptionUpper: hearts?.absorptionUpper ?? null,
      observedTick: currentTick() })
  })
  client.on('reset_score', packet => {
    if (!packet.objective_name || packet.objective_name === 'wd_hearts') scores.delete(packet.entity_name)
  })
  return {
    beginMatch (id) { matchId = id; scores.clear() },
    observe (name, visible, distance) {
      const score = scores.get(name)
      // Vanilla below-name labels are a short-range visual cue. Global score
      // broadcasts must not become remote / occluded opponent health vision.
      if (!matchId || !objective || !displayed || !visible || !Number.isFinite(distance) || distance > 10 || !score) return null
      return { ...score, source: 'public-below-name-scoreboard', objective: 'wd_hearts',
        opponent: name, matchId, roundedUp: true }
    }
  }
}
module.exports = { createPublicHealthTracker, formattedHearts }
