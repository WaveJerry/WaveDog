'use strict'
// One finite mechanical opener, using only received world/self/target data.
// These simulations never apply a PlayerState to the live bot or emit inputs.
const {Physics,PlayerState}=require('prismarine-physics')
const {Vec3}=require('vec3')
const {nearestHitPoint}=require('./protocol-mechanical-math')
const HORIZON=16, MAX_PREP=2
const freshControls=()=>({forward:false,back:false,left:false,right:false,
  sprint:false,jump:false,sneak:false})
function controlsAt(route,elapsed,ground){
  const forward=elapsed<route.prepTicks+route.driveTicks
  return {...freshControls(),forward,sprint:forward,
    jump:ground&&elapsed===route.prepTicks}
}
function createCriticalEntryPredictor(bot){
  const world={getBlock:p=>bot.blockAt(p,false)}
  // A separate engine is essential: the live simulatePlayer wrapper dispatches
  // real decisions and must never be called by a look-ahead.
  const physics=Physics(bot.registry,world)
  const fail=reason=>({eligible:false,reason})
  function assess(o,target,route){
    const elapsed=o.tick-route.startTick
    if(elapsed<0||elapsed>=HORIZON)return fail('opener-expired')
    const state=new PlayerState(bot,freshControls())
    // prismarine-physics edits the sprint modifier in this nested object.
    // PlayerState clones pos/vel but aliases attributes; forecasts must not.
    state.attributes=structuredClone(bot.entity.attributes||{})
    // A holding-jump queue from the previous controller cannot alter this plan.
    state.jumpQueued=false
    const velocity=o.targetVelocity||{x:0,y:0,z:0},base=target.position
    let airborne=!state.onGround,previousY=state.pos.y,fall=0,window=null
    for(let step=1;step<=HORIZON-elapsed;step++){
      const absolute=elapsed+step-1
      state.control=controlsAt(route,absolute,state.onGround)
      state.yaw=route.yaw;state.pitch=0
      try{physics.simulatePlayer(state,world)}catch{return fail('unknown-terrain')}
      if(state.isCollidedHorizontally||state.isInWater||state.isInLava||state.isInWeb)
        return window||fail('trajectory-obstructed')
      if(!world.getBlock(state.pos))return fail('unknown-terrain')
      const descending=!state.onGround&&state.pos.y<previousY-.00001
      fall=descending?fall+previousY-state.pos.y:0
      previousY=state.pos.y
      if(!state.onGround)airborne=true
      else if(airborne)break
      // Reserve one server tick; do not assume that catch-up client frames
      // have already recharged the weapon on the server.
      const predictedCharge=Math.min(1,o.charge+Math.max(0,step-1)/12.5)
      if(!descending||fall<=0||predictedCharge<=.9)continue
      let worstReach=0
      const eye={x:state.pos.x,y:state.pos.y+(bot.entity.eyeHeight||1.62),z:state.pos.z}
      // Continue current motion, brake, or make a modest retreat adjustment.
      // This is a bounded forecast, not knowledge of the opponent's next keys.
      const awayX=base.x-bot.entity.position.x,awayZ=base.z-bot.entity.position.z
      const length=Math.max(.001,Math.hypot(awayX,awayZ))
      for(const hypothesis of ['continue','brake','retreat']){
        const factor=hypothesis==='brake'?Math.min(step,3):step
        const drift=hypothesis==='retreat'?Math.min(.5,step*.035):0
        let y=base.y
        if(o.targetGrounded===false){
          // The observed landing surface bounds the public vertical forecast.
          let vy=velocity.y||0
          for(let k=0;k<step;k++){y+=vy;vy=(vy-.08)*.98}
          if(!Number.isFinite(o.targetFloorY))return fail('unknown-target-landing')
          y=Math.max(o.targetFloorY,y)
        }
        const position={x:base.x+(velocity.x||0)*factor+awayX/length*drift,
          y,z:base.z+(velocity.z||0)*factor+awayZ/length*drift}
        const box={position,width:target.width||.6,height:target.height||1.8}
        const hit=nearestHitPoint(eye,box)
        const reach=Math.hypot(eye.x-hit.x,eye.y-hit.y,eye.z-hit.z)
        worstReach=Math.max(worstReach,reach)
        const ray=new Vec3(hit.x-eye.x,hit.y-eye.y,hit.z-eye.z)
        if(reach>2.8||!Number.isFinite(reach))break
        // A transparent/unknown path is checked again at actual execution.
        if(reach>.001&&bot.world.raycast(new Vec3(eye.x,eye.y,eye.z),ray.scaled(1/reach),reach)){
          worstReach=Infinity;break
        }
      }
      if(worstReach<=2.8){
        const score=worstReach+.02*(elapsed+step)+.03*route.prepTicks
        if(!window||score<window.score)window={eligible:true,reason:'forecast-charged-fall-contact',
          route,hitInTicks:step,worstReach,predictedCharge,score}
      }
    }
    return window||fail('no-reliable-charged-fall-contact')
  }
  return {predict(o,target,existing=null){
    const began=performance.now()
    if(!o.visible||!target||o.held!==0)return fail('sword-or-target-unavailable')
    if(o.targetShieldRaised||o.targetShieldFacing)return fail('opponent-shield-raised')
    if(!Number.isFinite(o.charge)||o.arrowThreat)return fail('charge-or-arrow-emergency')
    if(existing)return {...assess(o,target,existing),predictionMs:performance.now()-began}
    if(!o.ground||o.mutualOutOfReach||o.reach>3)return fail('outside-counter-contact')
    const toward=Math.atan2(-(target.position.x-bot.entity.position.x),-(target.position.z-bot.entity.position.z))
    let best=null
    for(const angle of [0,Math.PI/3,-Math.PI/3,Math.PI])
      for(const driveTicks of [12,4])for(let prepTicks=0;prepTicks<=MAX_PREP;prepTicks++){
        const route={startTick:o.tick,yaw:toward+angle,prepTicks,driveTicks,
          kind:driveTicks===12?'full-sprint-hop':'short-drive-hop'}
        const p=assess(o,target,route)
        if(p.eligible&&(!best||p.score<best.score))best=p
      }
    return {...(best||fail('no-reliable-charged-fall-contact')),predictionMs:performance.now()-began}
  }}
}
module.exports={createCriticalEntryPredictor,controlsAt,HORIZON}
