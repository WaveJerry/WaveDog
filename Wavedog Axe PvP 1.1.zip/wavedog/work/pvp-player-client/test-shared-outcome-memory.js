const assert = require('node:assert/strict')
const { SharedOutcomeMemory } = require('./shared-outcome-memory')

const memory = new SharedOutcomeMemory([], 2)
memory.add({ at: '2026-11-13T00:00:00Z', matchId: 'first', winner: 'NBot01',
  reason: 'death', fighters: { NBot01: { style: 'AGGRESSIVE', focus: 'COMBO' },
    NBot02: { style: 'DEFENSIVE', focus: 'SHIELD' } },
  native: { meleeHits: 7, shieldBreaks: 1, arrowLaunches: 0, arrowHits: 0 } })
memory.add({ at: '2026-11-13T00:01:00Z', matchId: 'second', winner: 'WaveJerry',
  reason: 'death', bot: 'NBot03', opponent: 'WaveJerry', style: 'MIXED',
  focus: 'CRITICAL', native: null })
memory.add({ at: '2026-11-13T00:02:00Z', matchId: 'third', winner: 'NBot02',
  reason: 'death', fighters: { NBot02: { style: 'FLANK', focus: 'ESCAPE' } } })
const latest = memory.latest(2)
assert.deepEqual(latest.map(row => row.text.split(' ')[0]), ['second','third'])
assert.match(latest[0].text, /原生结果待归属/)
assert.match(latest[1].source, /not-Qwen-conclusion/)
console.log('SHARED_OUTCOME_PASS death is visible before Qwen review')
