const assert = require('node:assert/strict')
const { movementInputs } = require('./movement-inputs')

const retreat = movementInputs({ forward: -1, side: 1,
  sprint: true, jump: true, shield: false })
assert.equal(retreat.retreatRunJump,true)
assert.equal(retreat.forward,true)
assert.equal(retreat.back,false)
assert.equal(retreat.sprint,true)
assert.equal(retreat.right,true)
const shielded = movementInputs({ forward: -1, side: 0,
  sprint: true, jump: true, shield: true })
assert.equal(shielded.retreatRunJump,false)
assert.equal(shielded.back,true)
assert.equal(shielded.sprint,false)
console.log('MOVEMENT_INPUTS_PASS retreat run-jump uses forward sprint after turn')
