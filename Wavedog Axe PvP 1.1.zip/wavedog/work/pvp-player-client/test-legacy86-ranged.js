'use strict'
const assert=require('node:assert/strict')
const fs=require('node:fs'),crypto=require('node:crypto')
const old=require('./protocol-pilot-mechanical-brain')
const next=require('./protocol-legacy86-ranged')
const source=fs.readFileSync(require.resolve('./protocol-pilot-mechanical-brain'))
assert.equal(crypto.createHash('sha256').update(source).digest('hex'),next.SOURCE_SHA)
function compare(steps){
  const original=old.createState('enemy','Punengbho');original.mode='NEURAL'
  const owner={lastBlock:-1000,spentBlock:-1000}
  let count=0
  for(const step of steps){
    const o={tick:100+count,visible:true,ground:true,held:0,health:20,reach:4,distance:4.3,
      otherReach:4,charge:1,shieldReady:false,loaded:false,arrows:5,
      targetShieldRaised:false,targetShieldFacing:false,wallMargin:8,
      targetShotEvent:0,targetShotTick:-1000,targetBowCycle:0,targetLoadCycle:0,...step}
    const before=old.plan(original,o,null)
    const frame={self:{shieldAvailable:o.shieldReady},observation:o}
    const after=next.syncRanged(owner,frame,{attack:false,slot:o.held,shield:false,ranged:null})
    for(const key of ['ranged','rangedId','rangedRelease','rangedReason'])
      assert.equal(after?.[key]??null,before.command[key]??null,'same latest ranged behavior: '+key+' step '+count)
    if(step.result){old.rangedApplied(original,before.command,step.result,o.tick)
      next.rangedApplied(owner,after||{},step.result,o.tick)}
    count++
  }
  return count
}
let count=0
count+=compare([
  {loaded:true,targetLoading:true,targetLoadCycle:1,result:{fireSent:true}},
  {loaded:true,targetLoading:true,targetLoadCycle:1},
  {loaded:false,targetLoading:true,targetLoadCycle:1,result:{useStarted:true}},
  {loaded:false,targetLoading:true,targetLoadCycle:1,result:{loadReleased:true}},
  {loaded:true,targetLoading:false,targetKnownLoaded:true,targetLoadCycle:1,result:{fireSent:true}},
  {loaded:true,targetKnownLoaded:true,targetLoadCycle:1},
  {loaded:false,targetKnownLoaded:true,targetLoadCycle:1}
])
count+=compare([
  {targetBow:true,targetBowCycle:1,result:{useStarted:true}},
  {targetBow:true,targetBowCycle:1},
  {targetBow:false,targetBowCycle:1,targetShotEvent:1,targetShotTick:102,
    arrowThreat:{time:1,side:-1},result:{bowReleased:true}},
  {targetBow:true,targetBowCycle:1,targetShotEvent:1,targetShotTick:102},
  {targetBow:true,targetBowCycle:2,targetShotEvent:1,targetShotTick:102,result:{useStarted:true}},
  {shieldReady:true,targetBow:true,targetBowCycle:2}
])
const owner={lastBlock:-1000,spentBlock:-1000}
const blocked=next.syncRanged(owner,{self:{shieldAvailable:false},observation:{tick:100,visible:true,
  targetLoading:true,targetLoadCycle:1,loaded:true,arrows:5,reach:2.9}}, {attack:true,slot:0},{})
assert.equal(blocked,null,'real melee preempts all ranged')
const stopped=next.syncRanged(owner,{self:{shieldAvailable:false},observation:{tick:101,visible:true,
  targetLoading:true,targetLoadCycle:1,loaded:true,arrows:5,reach:4}}, {attack:false,slot:0},{emergency:true})
assert.equal(stopped,null,'airborne emergency cancels offhand use')
console.log('LATEST_RANGED_SYNC_PARITY_PASS: '+count+' temporal steps, native acknowledgments, draw cancel, melee and threat priority')
