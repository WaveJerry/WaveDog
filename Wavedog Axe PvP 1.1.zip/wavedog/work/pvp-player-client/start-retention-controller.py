"""Start one ordinary-player GRU/Qwen selfplay controller after referee readiness."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
bots = int(sys.argv[1]) if len(sys.argv) >= 2 else 2
validation = '--ranged-validation' in sys.argv[2:]
debug_crossbow = '--debug-crossbow' in sys.argv[2:]
single_lane = '--single-lane' in sys.argv[2:]
manual_lane = '--manual-lane' in sys.argv[2:]
if manual_lane and not single_lane:
    raise SystemExit('--manual-lane requires --single-lane')
if bots < 2 or bots > 60 or bots % 2:
    raise SystemExit('bots must be even 2..60')
spec = importlib.util.spec_from_file_location('rcon', 'D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
status = rcon.command('selfplay status')
if 'desired=0 active=0' not in status:
    raise SystemExit('Refused duplicate or active selfplay: ' + status)
ready = base / 'new-learning/selfplay-ready.json'
if ready.exists() and time.time() - ready.stat().st_mtime < 5:
    raise SystemExit('Existing controller heartbeat is fresh')
node = shutil.which('node') or 'E:/node/node.exe'
logdir = base / 'runtime/controller'
logdir.mkdir(parents=True, exist_ok=True)
log = logdir / (time.strftime('%Y%m%d-%H%M%S') + f'-{bots}bots.log')
with log.open('wb') as output:
    environment = os.environ.copy()
    if validation:
        environment['WAVEDOG_VALIDATION_RANGED'] = '1'
    if debug_crossbow:
        environment['WAVEDOG_DEBUG_CROSSBOW'] = '1'
    if '--dual' in sys.argv[2:]:
        environment['WAVEDOG_DUAL_BRAIN'] = '1'
        environment['WAVEDOG_FRESH_DUAL'] = '1'
    if single_lane:
        environment['WAVEDOG_SINGLE_LANE'] = '1'
    if manual_lane:
        environment['WAVEDOG_MANUAL_LANE'] = '1'
    process = subprocess.Popen([node, str(base / 'selfplay.js'), f'--bots={bots}'],
                               cwd=base, stdin=subprocess.DEVNULL,
                               stdout=output, stderr=subprocess.STDOUT,
                               env=environment,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
for _ in range(90):
    if process.poll() is not None:
        raise SystemExit('Controller exited; inspect ' + str(log))
    if ready.exists() and ready.stat().st_mtime > time.time() - 5:
        data = json.loads(ready.read_text(encoding='utf-8'))
        if data.get('bots') == bots and data.get('bridgeReady'):
            result = {'pid': process.pid, 'bots': bots, 'single_lane': single_lane,
                      'manual_lane': manual_lane,
                      'ranged_validation': validation, 'log': str(log),
                      'ready': data, 'gate': rcon.command('selfplay status')}
            print(json.dumps(result, ensure_ascii=False))
            break
    time.sleep(1)
else:
    raise SystemExit('Controller readiness timeout; inspect ' + str(log))
