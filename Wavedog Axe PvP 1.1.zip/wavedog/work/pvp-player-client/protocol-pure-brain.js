'use strict'
function createState(){return {mode:'NEURAL',nextId:1,transitions:[]}}
function plan(s,o,neural){
  const fresh=neural&&o.tick-neural.decidedTick>=0&&o.tick-neural.decidedTick<=3
  const owner=fresh?'neural':'neutral-expired'
  return {mode:'NEURAL',owners:Object.fromEntries(['movement','sprint','jump','sneak',
    'mainhand','attack','shield','offhand','look'].map(k=>[k,owner])),
    command:fresh?{...neural,kind:'neural'}:{forward:0,side:0,sprint:false,jump:false,
      sneak:false,attack:false,shield:false,use:false,release:true,slot:null}}
}
module.exports={createState,plan,receipt(){},applied(){},rangedApplied(){}}
