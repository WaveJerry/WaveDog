// Public client-visible arrow trajectory and collision estimate.
function segmentHitsBox (a, b, center, half, low, high) {
  let enter = 0, leave = 1
  for (const [start, end, min, max] of [
    [a.x-center.x,b.x-center.x,-half,half],
    [a.y-center.y,b.y-center.y,low,high],
    [a.z-center.z,b.z-center.z,-half,half]]) {
    const delta = end-start
    if (Math.abs(delta) < 1e-9) {
      if (start < min || start > max) return false
      continue
    }
    const first = (min-start)/delta, second = (max-start)/delta
    enter = Math.max(enter,Math.min(first,second))
    leave = Math.min(leave,Math.max(first,second))
    if (enter > leave) return false
  }
  return true
}
function publicArrowThreat (arrows, self, wall, clearPath = () => true) {
  let chosen = null
  for (const arrow of arrows || []) {
    if(self.entityId!=null&&arrow.shooterId===self.entityId)continue
    let pos = { x: arrow.x, y: arrow.y, z: arrow.z }
    let vx = arrow.vx || 0, vy = arrow.vy || 0, vz = arrow.vz || 0
    if (vx*vx+vy*vy+vz*vz < .04) continue
    let impact = null
    for (let tick=1; tick<=8; tick++) {
      const next = { x: pos.x+vx, y: pos.y+vy, z: pos.z+vz }
      if (!clearPath(pos,next)) break // An observed solid block stops the path.
      const center = { x: self.x+(self.vx || 0)*Math.min(tick,3)*.7,
        y: self.y+(self.vy || 0)*Math.min(tick,2),
        z: self.z+(self.vz || 0)*Math.min(tick,3)*.7 }
      // 0.3 body half-width + 0.3 native projectile expansion + float margin.
      if (segmentHitsBox(pos,next,center,.62,-.32,2.12)) {
        impact = { tick, next, center }; break
      }
      pos = next
      vx *= .99; vy = vy*.99-.05; vz *= .99
    }
    if (!impact) continue
    const leftX = -Math.cos(self.yaw), leftZ = Math.sin(self.yaw)
    const leftRoom = wall(leftX, leftZ), rightRoom = wall(-leftX, -leftZ)
    const displacement = Math.min(1.2,.16*impact.tick*impact.tick)
    const leftMiss = Math.hypot(impact.center.x+leftX*displacement-impact.next.x,
      impact.center.z+leftZ*displacement-impact.next.z)
    const rightMiss = Math.hypot(impact.center.x-leftX*displacement-impact.next.x,
      impact.center.z-leftZ*displacement-impact.next.z)
    const leftSafe = leftRoom >= .9, rightSafe = rightRoom >= .9
    const side = leftSafe && (!rightSafe || leftMiss >= rightMiss) ? -1
      : rightSafe ? 1 : 0
    const jumpRise = [.0,.42,.75,.99,1.16,1.24,1.23,1.14,.97][impact.tick]
    const jump = Boolean(side && self.ground && self.ceilingClear
      && impact.tick >= 2 && impact.next.y < self.y+jumpRise-.12)
    if (!chosen || impact.tick < chosen.time)
      chosen = { id: arrow.id, time: impact.tick, side, jump,
        miss: Math.hypot(impact.center.x-impact.next.x,
          impact.center.z-impact.next.z) }
  }
  return chosen
}

module.exports = { publicArrowThreat, segmentHitsBox }
