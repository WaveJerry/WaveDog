'use strict'
// Bukkit samples getCooledAttackStrength(0); vanilla melee and the original
// WaveDog critical check use a half-tick sample. Never extrapolate server time
// from local catch-up frames or pretend a low-charge swing is a critical.
function attackCharge ({ tick, lastSwing, slot, nativeSelf }) {
  const cooldown = slot === 0 ? 12.5 : 20
  if (nativeSelf && tick - nativeSelf.receivedTick <= 3
      && nativeSelf.held === slot && nativeSelf.receivedTick > lastSwing)
    return Math.min(1, Math.max(0, nativeSelf.charge + .5 / cooldown))
  return Math.min(1, Math.max(0, (tick - lastSwing + .5) / cooldown))
}
module.exports = { attackCharge }
