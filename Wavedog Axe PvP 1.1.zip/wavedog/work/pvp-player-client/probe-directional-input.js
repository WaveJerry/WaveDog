'use strict'
// Deliberately chosen inputs for a protocol-adapter test, NEVER a model policy.
const fs=require('node:fs'),path=require('node:path')
const {Vec3}=require('vec3')
const {executeCommand}=require('./protocol-pure-executor')
const {plan,createState}=require('./protocol-pure-brain')
const {immediateLook,nearestHitPoint}=require('./protocol-mechanical-math')
const {eyeReach}=require('./probe-edge-controller')
const {attackCharge}=require('./protocol-attack-charge')
let session=null,using=null
function adapterTrial({bot,target,tick,cmd,dir,startTick,lastSentMotion}){
 if(!session||session.id!==cmd.matchId)session={id:cmd.matchId,opponent:cmd.target,
  state:createState(),attackedDecisions:new Set(),attackOwners:new Map(),lastAttack:-1000,weaponEpoch:0,lastWeapon:-1000,startTick:tick}
 const elapsed=tick-session.startTick
 const active=elapsed<28,attack=elapsed===4||elapsed===18
 const selected={decidedTick:tick,slot:0,forward:active?1:0,side:0,sprint:active,
  jump:false,sneak:false,attack:active&&attack,shield:false,use:false,release:false,
  pureAimVersion:2,aimYawOffset:cmd.directionalYaw??180,aimPitchOffset:0,flightLook:attack}
 const frame={self:{...bot.entity.position},seen:{visible:true},targetVelocity:{x:0,y:0,z:0},
  observation:{reach:eyeReach(bot.entity.position,bot.entity.eyeHeight||1.62,target)}}
 const look=(yaw,pitch=0)=>immediateLook(bot,yaw,pitch)
 const aim=()=>{const p=bot.entity.position,eye=p.offset(0,bot.entity.eyeHeight||1.62,0),q=nearestHitPoint(eye,target)
  look(Math.atan2(-(q.x-eye.x),-(q.z-eye.z)),Math.atan2(q.y-eye.y,Math.hypot(q.x-eye.x,q.z-eye.z)))}
 const packets=[],write=bot._client.write
 bot._client.write=function(n,d){if(['look','position_look','use_entity','entity_action'].includes(n))packets.push({name:n,data:d});return write.call(this,n,d)}
 let actual
 try{actual=executeCommand({bot,target,tick,session,frame,planned:plan(session.state,{tick},selected),
  weaponEpoch:session.weaponEpoch,lastAttackTick:session.lastAttack,shieldUntil:0,look,aim,
  getUse:()=>using,setUse:v=>{using=v},stopUse:()=>{if(using)bot.deactivateItem();using=null},
  offhand:()=>false,ownLoaded:()=>false,plugin:()=>{},
  clearPath:(eye,hit)=>{const d=new Vec3(hit.x-eye.x,hit.y-eye.y,hit.z-eye.z),n=d.norm()
   return n<.001||!bot.world.raycast(new Vec3(eye.x,eye.y,eye.z),d.scaled(1/n),n)},
  charge:()=>attackCharge({tick,lastSwing:Math.max(session.lastAttack,session.lastWeapon),slot:bot.quickBarSlot}),
  onSwitch:()=>{session.weaponEpoch++;session.lastWeapon=tick},onAttack:()=>{session.lastAttack=tick}})
 }finally{bot._client.write=write}
 fs.appendFileSync(path.join(dir,'directional-input-frames.jsonl'),JSON.stringify({at:Date.now(),tick,elapsed,
  matchId:cmd.matchId,testOnly:true,modelPolicy:false,position:bot.entity.position,velocity:bot.entity.velocity,
  lastSentMotion,selected,actual,packets})+'\n')
}
module.exports={adapterTrial}
