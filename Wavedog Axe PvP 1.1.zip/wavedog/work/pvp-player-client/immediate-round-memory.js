/** Store measured facts immediately when a bout ends; Qwen interprets later. */
function immediateRoundFact (report) {
  const tactics = Object.values(report.tactics || {})
  const sum = key => tactics.reduce((n, row) => n + Number(row[key] || 0), 0)
  const native = report.native || {}
  const lesson = `局${report.matchId}胜${report.winner}：原生近战${native.meleeHits ?? '?'}、挡刀${sum('blockedMelee')}、盾反命中${sum('counterHits')}、安全出距${sum('counterEscapes')}、暴击${sum('nativeCriticalHits')}、满程跑跳暴击${sum('longRunJumpCriticalHits')}、换血亏${sum('lostExchanges')}、发箭${native.arrowLaunches ?? '?'}；待Qwen解释`
  return { boutAt: report.at, matchId: report.matchId,
    fighters: Object.keys(report.fighters || {}),
    lesson, lessonSource: 'measured-fallback', source: 'native-bout-immediate',
    nativeCounts: { meleeHits: native.meleeHits ?? null,
      arrowLaunches: native.arrowLaunches ?? null,
      blockedMelee: sum('blockedMelee'), counterHits: sum('counterHits'),
      counterEscapes: sum('counterEscapes'), nativeCriticalHits: sum('nativeCriticalHits'),
      lostExchanges: sum('lostExchanges'),
      sprintJumpEntries: sum('sprintJumpEntries'),
      sprintJumpCriticalHits: sum('sprintJumpCriticalHits'),
      longRunJumpEntries: sum('longRunJumpEntries'),
      longRunJumpCriticalHits: sum('longRunJumpCriticalHits') } }
}

module.exports = { immediateRoundFact }
