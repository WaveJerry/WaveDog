"""Two independently named actors update one isolated recurrent PPO checkpoint."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
source = base / 'new-learning/models/recurrent-ppo.json'
folder = base / 'new-learning/multi-bridge-test'
folder.mkdir(parents=True, exist_ok=True)
target = folder / 'recurrent-ppo.json'
shutil.copy2(source, target)
before = json.loads(target.read_text(encoding='utf-8'))
before_hash = hashlib.sha256(target.read_bytes()).hexdigest()
classpath = ';'.join(map(str, [base / 'bridge-classes', base.parent / 'pvp-neural-lab/classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
rows = []
for fighter, opponent, x in [('NBot01', 'NBot02', 1058.5), ('NBot02', 'NBot01', 1058.7)]:
    rows.append({'command': 'reset', 'fighter': fighter, 'opponent': opponent, 'learning': True})
    for tick in range(1, 33):
        rows.append({'command': 'act', 'fighter': fighter, 'opponent': opponent,
            'requestId': tick + (0 if fighter == 'NBot01' else 100), 'tick': tick,
            'yaw': 0, 'pitch': 0, 'focus': 'CHARGE',
            'style': 'AGGRESSIVE' if fighter == 'NBot01' else 'DEFENSIVE',
            'self': {'x': x, 'y': 221, 'z': 960.5, 'eyeY': 222.62,
                'ground': True, 'charge': min(1, tick / 20), 'health': 20,
                'shieldAvailable': True, 'held': 7},
            'seen': {'visible': True, 'x': x, 'y': 221, 'z': 962.4,
                'held': 'DIAMOND_AXE', 'yaw': 180}})
        rows.append({'command': 'executed', 'fighter': fighter, 'decidedTick': tick,
            'ignoredHeads': [6, 7]})
rows.append({'command': 'finish', 'fighter': 'NBot01', 'round': 1, 'win': True, 'health': 10})
rows.append({'command': 'finish', 'fighter': 'NBot02', 'round': 1, 'win': False, 'health': 0})
result = subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp', classpath,
    'local.wavedog.lab.ProtocolPlayerBridge', str(folder)],
    input='\n'.join(json.dumps(row) for row in rows)+'\n', text=True,
    capture_output=True, timeout=90, check=True)
output = [json.loads(line) for line in result.stdout.splitlines()]
assert not [row for row in output if row.get('event') == 'error']
trained = [row for row in output if row.get('event') == 'trained']
assert [row['fighter'] for row in trained] == ['NBot01', 'NBot02']
assert all(row['opponent'] == ('NBot02' if row['fighter'] == 'NBot01' else 'NBot01')
    for row in output if row.get('model') == 'GRU64-PPO')
assert all('decidedTick' in row for row in output if row.get('model') == 'GRU64-PPO')
after = json.loads(target.read_text(encoding='utf-8'))
assert after['updates'] == before['updates'] + 8
assert after['episodes'] == before['episodes'] + 2
assert hashlib.sha256(target.read_bytes()).hexdigest() != before_hash
print(json.dumps({'event': 'two_actor_training_pass', 'updates_before': before['updates'],
    'updates_after': after['updates'], 'episodes_after': after['episodes']}))
