'use strict'
const assert=require('node:assert/strict')
const {deployedShieldObservation}=require('./probe-public-observation')
const history={}
for(let tick=10;tick<16;tick++){
  const request={tick,seen:{visible:true,shield:true}}
  const result=deployedShieldObservation(request,history)
  assert.equal(result.seen.shield,tick>=15)
  assert.equal(request.seen.shield,true,'original raw evidence is never mutated')
}
assert.equal(deployedShieldObservation({tick:16,seen:{visible:true,shield:false}},history).seen.shield,false)
assert.equal(deployedShieldObservation({tick:17,seen:{visible:true,shield:true}},history).seen.shield,false)
deployedShieldObservation({tick:18,seen:{visible:false}},history)
assert.equal(deployedShieldObservation({tick:30,seen:{visible:true,shield:true}},history).seen.shield,false,
  'unobserved time cannot prove a fresh shield effective')
console.log('TEACHER_SHIELD_OBSERVATION_MATCHES_DEPLOYED_WARMUP_PASS')
