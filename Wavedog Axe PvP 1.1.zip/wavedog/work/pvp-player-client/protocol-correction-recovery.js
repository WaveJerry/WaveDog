'use strict'
// A server position correction invalidates both pending inference and held
// movement. Releasing old controls is transport recovery, not a combat action.
function recoverPositionCorrection({dispatch, frameClock, requestContexts, clearControls, stopUse, invalidate}) {
  dispatch.cancel('forced-move')
  clearControls()
  stopUse()
  requestContexts.clear()
  invalidate()
  frameClock.clear()
}
module.exports = {recoverPositionCorrection}
