"""Start the main Paper server for a supervised ordinary protocol-player test."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import socket
import subprocess
import time

base=Path(__file__).resolve().parent
server=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
with socket.socket() as connection:
    if connection.connect_ex(('127.0.0.1',25566))==0:
        raise SystemExit('Main server already running; refused duplicate start')
if (server/'plugins/WaveDogPracticeLab.jar').exists():
    raise SystemExit('Invalid old practice plugin still installed; refused to start training')
candidate=base/'WaveDogPlayerAudit.jar'
destination=server/'plugins/WaveDogPlayerAudit.jar'
shutil.copy2(candidate,destination)
runtime=base/'runtime'
for name in ('home','tmp','console'):(runtime/name).mkdir(parents=True,exist_ok=True)
log=runtime/'console'/(time.strftime('%Y%m%d-%H%M%S')+'.log')
out=log.open('wb')
args=[str(server/'runtime/java21/bin/java.exe'),'-Xms512M','-Xmx3G',
      '-Duser.home='+str(runtime/'home'),'-Djava.io.tmpdir='+str(runtime/'tmp'),
      '-Dhttp.proxyHost=127.0.0.1','-Dhttp.proxyPort=10808',
      '-Dhttps.proxyHost=127.0.0.1','-Dhttps.proxyPort=10808',
      '-jar',str(server/'server.jar'),'--nogui']
process=subprocess.Popen(args,cwd=server,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
out.close()
spec=importlib.util.spec_from_file_location('rcon','D:/CodexWorkspace/ban/outputs/MC-Public/rcon_local.py')
rcon=importlib.util.module_from_spec(spec)
spec.loader.exec_module(rcon)
for _ in range(90):
    if process.poll() is not None:
        raise SystemExit('Main Paper exited; inspect '+str(log))
    try:
        response=rcon.command('list')
        if response:
            break
    except (OSError,TimeoutError,ConnectionError):
        pass
    time.sleep(2)
else:
    raise SystemExit('Main Paper readiness timed out; inspect '+str(log))
receipt={'pid':process.pid,'server':str(server),'console':str(log),'observer_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
         'old_practice_plugin_present':False,'main_ready':True,'training_enabled':False,'port':25566}
(base/'main-player-test.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
