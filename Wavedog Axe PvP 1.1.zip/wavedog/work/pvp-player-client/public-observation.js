/** Client-received projectile entities in every direction, including behind. */
function nearbyFlyingArrows (bot, radius = 32) {
  const origin = bot.entity?.position
  if (!origin) return []
  return Object.values(bot.entities || {})
    // Prismarine entities default onGround=true even for newly spawned flying
    // arrows. Motion and the received spawn/velocity packets are the signal.
    .filter(entity => ['arrow', 'spectral_arrow'].includes(entity.name)
      && entity.position && entity.velocity)
    .map(entity => ({ entity, distance: entity.position.distanceTo(origin) }))
    .filter(({ entity, distance }) => distance <= radius
      && distance > 0
      && Number.isFinite(distance)
      && Number.isFinite(entity.velocity.x)
      && Number.isFinite(entity.velocity.y)
      && Number.isFinite(entity.velocity.z)
      && Math.hypot(entity.velocity.x, entity.velocity.y, entity.velocity.z) > .02)
    .sort((a, b) => a.distance - b.distance)
    .slice(0, 4)
    .map(({ entity }) => ({ x: entity.position.x, y: entity.position.y,
      z: entity.position.z, vx: entity.velocity.x,
      vy: entity.velocity.y, vz: entity.velocity.z }))
}

module.exports = { nearbyFlyingArrows }
