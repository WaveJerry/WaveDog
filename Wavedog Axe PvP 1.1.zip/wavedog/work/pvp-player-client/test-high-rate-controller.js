'use strict'
const assert=require('node:assert/strict')
const {createHighRateController}=require('./protocol-high-rate-controller')
const {monoMs}=require('./protocol-high-rate-loop')
async function test(){
  let current='old',revision=0,tick=0,slowResolve
  const applied=[],errors=[],traces=[]
  const controller=createHighRateController({control:true,
    context:a=>a?{matchId:current,tick}:null,
    infer:token=>current==='old'?new Promise(resolve=>{slowResolve=resolve})
      :Promise.resolve({fixtureOnly:true,matchId:token.matchId,baseTick:tick}),
    apply:(action,proof)=>applied.push({action,proof}),onError:e=>errors.push(String(e)),onTrace:r=>traces.push(r)})
  const sample=()=>{
    tick++
    controller.sample({matchId:current,revision:++revision,atMs:monoMs(),tick,source:'physics',
      self:{position:{x:0,y:0,z:0},sourceTick:tick,grounded:true},
      opponent:{position:{x:3.3,y:0,z:0},sourceTick:tick,grounded:true}})
  }
  const timer=setInterval(sample,50)
  try{
    controller.reset(current);sample()
    // Loading the native timer can take longer on a busy machine. Wait for
    // actual readiness, rather than baking a 150ms startup assumption in.
    const deadline=monoMs()+3000
    while(!slowResolve&&monoMs()<deadline)await new Promise(r=>setTimeout(r,10))
    assert(slowResolve,'old bout request should be in flight')
    current='new';revision=0;controller.reset(current);sample()
    slowResolve({fixtureOnly:true,matchId:'old'})
    await new Promise(r=>setTimeout(r,300))
    assert.equal(errors.length,0)
    assert(applied.length>0)
    assert(applied.every(r=>r.action.matchId==='new'&&r.proof.matchId==='new'))
    assert(traces.some(r=>r.type==='refinement-discarded'))
    assert(controller.stats.cycles>100)
    console.log('HIGH_RATE_CONTROLLER_BOUT_RESET_AND_ASYNC_DISPATCH_PASS '+controller.stats.cycles)
  }finally{clearInterval(timer);await controller.close()}
}
test().catch(error=>{console.error(error);process.exitCode=1})
