'use strict'
// Outcome feedback only: this module never selects or executes an input.
function createOpeningControlTracker (fighter, opponent) {
  let first = null, pending = null, separated = 0, lastDamage = -Infinity, exchange = 0, cost = 0
  function intent (frame) {
    const c=frame.executed,yaw=frame.command?.yaw
    if (!Number.isFinite(yaw)) return null
    const forward=Number(Boolean(c.forward))-Number(Boolean(c.back))
    const side=Number(Boolean(c.right))-Number(Boolean(c.left))
    const length=Math.hypot(forward,side)
    if (!length) return null
    const angle=yaw*Math.PI/180
    return {x:(-forward*Math.sin(angle)-side*Math.cos(angle))/length,
      z:(forward*Math.cos(angle)-side*Math.sin(angle))/length}
  }
  return {
    damage (event, frame, decidedTick) {
      if (!event.melee || event.cancelled || !(event.amount > 0)
          || !((event.attacker === fighter && event.victim === opponent)
            || (event.attacker === opponent && event.victim === fighter))) return
      lastDamage = frame.tick
      const opening=first===null
      if (opening) first = event.attacker
      if (event.attacker === opponent && Number.isSafeInteger(decidedTick)) {
        pending = { tick: frame.tick, decidedTick, exchange, amount: event.amount,
          opening, before:{...frame.self},intent:intent(frame),jumped:Boolean(frame.executed.jump),
          horizontalSamples:0 }
      }
    },
    observe (frame) {
      const reach = frame.observation.reach
      separated = frame.seen.visible && Number.isFinite(reach) && reach > 3.3
        ? separated + 1 : 0
      if (separated >= 10 && frame.tick - lastDamage > 10) {
        if (first !== null) exchange++
        first = pending = null;cost=0
      }
      if (!pending) return null
      // Ambiguous delayed launches, deliberate jumps and jump resets are not
      // labelled as proven failure to control a grounded first exchange.
      if (frame.tick - pending.tick > 4) { pending = null; return null }
      pending.jumped ||= Boolean(frame.executed.jump)
      const before=pending.before,now=frame.self,desired=pending.intent,current=intent(frame)
      const aligned=desired&&current&&desired.x*current.x+desired.z*current.z>.9
      const oldAlong=desired?(before.vx||0)*desired.x+(before.vz||0)*desired.z:0
      const along=desired?(now.vx||0)*desired.x+(now.vz||0)*desired.z:0
      const oldSide=desired?Math.abs((before.vx||0)*desired.z-(before.vz||0)*desired.x):0
      const side=desired?Math.abs((now.vx||0)*desired.z-(now.vz||0)*desired.x):0
      const pushed=aligned&&((oldAlong>=-.03&&along<-.08&&along-oldAlong<-.12)
        ||side>.22&&side-oldSide>.18)
      pending.horizontalSamples=pushed?pending.horizontalSamples+1:0
      const launched=!pending.jumped&&now.ground===false&&now.vy>.08
        &&(before.ground===true||now.vy-(before.vy||0)>.18)
      if (frame.tick > pending.tick && (launched||pending.horizontalSamples>=2)) {
        const reward=-Math.min(pending.opening ? .05 : .025,Math.max(0,.15-cost));cost-=reward
        const result = { tick:pending.tick,decidedTick:pending.decidedTick,exchange:pending.exchange,
          confirmedTick: frame.tick,opening:pending.opening,
          kind: launched?'melee-launched-self':'melee-displaced-against-movement',reward }
        pending = null
        return result
      }
      return null
    }
  }
}
module.exports = { createOpeningControlTracker }
