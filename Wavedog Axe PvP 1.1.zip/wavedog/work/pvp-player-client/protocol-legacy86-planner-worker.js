'use strict'
const {parentPort}=require('node:worker_threads')
const {createRouteProbe}=require('./protocol-legacy86-route')
const {planAirThreat,planSpacing,planShortAdvance}=require('./protocol-legacy86-threat')
let snapshot=null,probe=null
parentPort.on('message',m=>{
  try{
    const started=performance.now()
    if(m.snapshot){
      snapshot=m.snapshot
      const {x0,z0,minY,maxY,n,cells}=snapshot,height=maxY-minY+1
      probe=createRouteProbe({origin:m.origin,radius:m.radius,minY,maxY,blockAt:(x,y,z)=>{
        if(x<x0||x>=x0+n||z<z0||z>=z0+n||y<minY||y>maxY)return null
        const shapes=cells[((x-x0)*n+z-z0)*height+y-minY]
        return shapes===null?null:{shapes}
      }})
    }
    if(!probe||snapshot.key!==m.snapshotKey)throw Error('Missing collision snapshot')
    const frame=m.frame
    frame.routeCache=new Map()
    const airPlan=planAirThreat(frame,probe)
    const spacing=!frame.self.shieldAvailable&&!frame.observation.targetAirborne?planSpacing(frame,probe):null
    const shortAdvance=!airPlan.threat?planShortAdvance(frame,probe):null
    parentPort.postMessage({id:m.id,airPlan,spacing,shortAdvance,computeMs:performance.now()-started})
  }catch(error){parentPort.postMessage({id:m.id,error:String(error)})}
})
