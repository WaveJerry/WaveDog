"""A played bout without a death updates PPO without inventing a winner."""
from pathlib import Path
import json
import shutil
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
folder = base / 'new-learning/partial-learning-test'
folder.mkdir(parents=True, exist_ok=True)
target = folder / 'recurrent-ppo.json'
shutil.copy2(base / 'new-learning/models/recurrent-ppo.json', target)
before = json.loads(target.read_text(encoding='utf-8'))
classpath = ';'.join(map(str, [base / 'bridge-classes', base.parent / 'pvp-neural-lab/classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
rows = [{'command': 'reset', 'fighter': 'NBot01', 'opponent': 'TestPlayer', 'learning': True}]
for tick in range(1, 25):
    rows.append({'command': 'act', 'fighter': 'NBot01', 'opponent': 'TestPlayer',
        'requestId': tick, 'tick': tick, 'yaw': 0, 'pitch': 0, 'focus': 'SHIELD',
        'style': 'DEFENSIVE',
        'self': {'x': 1058.5, 'y': 221, 'z': 960.5, 'eyeY': 222.62,
            'ground': True, 'charge': min(1, tick / 20), 'health': 20,
            'shieldAvailable': True, 'held': 7},
        'seen': {'visible': True, 'x': 1058.5, 'y': 221, 'z': 962.4,
            'held': 'DIAMOND_AXE', 'yaw': 180}})
    rows.append({'command': 'executed', 'fighter': 'NBot01', 'decidedTick': tick,
        'ignoredHeads': [6, 7]})
rows.append({'command': 'partial', 'fighter': 'NBot01', 'round': 42})
result = subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp', classpath,
    'local.wavedog.lab.ProtocolPlayerBridge', str(folder)],
    input='\n'.join(json.dumps(row) for row in rows)+'\n', text=True,
    capture_output=True, timeout=60, check=True)
output = [json.loads(line) for line in result.stdout.splitlines()]
errors = [row for row in output if row.get('event') == 'error']
assert not errors, errors
receipt = next(row for row in output if row.get('event') == 'trained_partial')
after = json.loads(target.read_text(encoding='utf-8'))
assert after['updates'] > before['updates']
assert after['episodes'] == before['episodes']
assert after['penaltyUpdates'] == before['penaltyUpdates'] + 1
assert receipt['gradient_updates_after'] == after['updates']
print(json.dumps({'event': 'partial_learning_pass', 'updates': after['updates'],
    'episodes_unchanged': after['episodes'] == before['episodes']}))
