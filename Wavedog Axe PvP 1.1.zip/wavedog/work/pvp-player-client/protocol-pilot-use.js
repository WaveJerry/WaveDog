'use strict'
// Replacing only the used offhand stack makes vanilla updatingUsingItem stop
// use without releasing an arrow or replacing the charged mainhand weapon.
// Do not put the bow back until a fresh native self receipt confirms the stop.
function createBowCancellation({getBot,getTick,getNative,swapItem,isSwitching,onEvent=()=>{}}){
  let pending=null
  function poll(){
    if(!pending)return true
    const own=getNative(),tick=getTick(),bot=getBot()
    const fresh=own&&own.receivedTick>pending.tick
      &&(pending.serverTick==null||own.serverTick>pending.serverTick)
    if(fresh&&(!own.using||typeof own.activeItem==='string'&&own.activeItem.toUpperCase()!=='BOW')){
      onEvent('confirmed',{...pending,confirmedTick:tick,serverTick:own.serverTick})
      pending=null;bot.usingHeldItem=false;return true
    }
    // A rejected inventory click may restore the original stack. Retry that
    // operation only; never RELEASE the still-drawn bow as a timeout fallback.
    if(tick-pending.lastAttempt>=3&&!isSwitching()&&bot.inventory.slots[45]?.name==='bow'){
      const item=bot.inventory.items().find(i=>i.name===pending.replacement&&i.slot!==36+bot.quickBarSlot)
      if(item){pending.lastAttempt=tick;swapItem(item)}
    }
    return false
  }
  return {
    begin(){
      if(pending)return {cancelled:false,released:false,pending:true,method:'offhand-replacement'}
      const bot=getBot(),items=bot.inventory.items(),selected=36+bot.quickBarSlot
      const item=['shield','crossbow'].map(name=>items.find(i=>i.name===name&&i.slot!==selected&&i.slot!==45)).find(Boolean)
      if(!item||isSwitching())return null
      pending={tick:getTick(),serverTick:getNative()?.serverTick??null,lastAttempt:getTick(),replacement:item.name}
      try{swapItem(item)}catch(error){pending=null;throw error}
      onEvent('requested',{...pending})
      return {cancelled:false,released:false,pending:true,method:'offhand-replacement'}
    },
    poll,
    pending:()=>pending&&({...pending}),
    reset(){pending=null}
  }
}

function endUse(bot,use,releaseBow=false,cancelBow=null){
  if(!use&&!bot.usingHeldItem)return {cancelled:false,released:false}
  if(use?.kind==='bow'&&!releaseBow){
    const replacement=cancelBow?.()
    if(replacement)return replacement
    // Kit-less fallback: the normal swap-hand packet explicitly stops use,
    // but replaces the mainhand twice and therefore resets native charge.
    const packet={status:6,location:{x:0,y:0,z:0},face:0,sequence:0}
    bot._client.write('block_dig',{...packet})
    bot._client.write('block_dig',{...packet})
    bot.usingHeldItem=false
    return {cancelled:true,released:false,method:'swap-hands-and-restore',mainhandChargeResetRisk:true}
  }
  bot.deactivateItem()
  return {cancelled:false,released:true}
}
module.exports={endUse,createBowCancellation}
