'use strict'
const assert=require('node:assert/strict')
const {createState,receipt,plan,applied}=require('./protocol-pilot-mechanical-brain')
const {executeCommand}=require('./protocol-pilot-mechanical-executor')
const base={tick:10,health:20,ground:true,visible:true,shieldReady:true,shieldEffective:true,
  offhandShieldReady:true,held:7,charge:.35,reach:2,distance:2.3,
  self:{x:0,y:0,z:-2.3},sentPosition:{x:0,y:0,z:-2.3},target:{x:0,y:0,z:0},
  targetYaw:0,targetShieldRaised:false,targetShieldFacing:false,targetCriticalThreat:false,
  wallMargin:8,openingDraw:1,orbitDraw:1}
const wound=(s,tick=10,extra={})=>receipt(s,{type:'damage',victim:'Punengbho',attacker:'Opponent',
  melee:true,cancelled:false,amount:2,...extra},tick)
for(const orbit of [false,true]){
  const s=createState('Opponent','Punengbho')
  if(orbit){s.orbitAttempt=true;s.orbitUntil=14;s.orbitLastAt=9}
  wound(s)
  const p=plan(s,base,null)
  assert.equal(p.command.kind,orbit?'orbit-reply':'guard-reply')
  assert(p.command.attack,'same-frame damage reply must not wait for a rear or full charge')
  assert(!p.command.orbit)
  applied(s,p.command,true,10)
  const again=plan(s,{...base,tick:11},null)
  assert(!again.command.attack,'one real wound produces at most one executed reply')
}
for(const extra of [{victim:'WaveDog'},{attacker:'Other'},{amount:0},{cancelled:true},{melee:false}]){
  const s=createState('Opponent','Punengbho');wound(s,10,extra)
  assert(!plan(s,base,null).command.attack,'unrelated/non-damaging events cannot create retaliation')
}
const low=createState('Opponent','Punengbho');low.orbitAttempt=true;low.orbitUntil=14
wound(low);assert(plan(low,{...base,health:4},null).command.attack,'low HP cancels circling, not the real wound')
const retainedBlock=createState('Opponent','Punengbho')
receipt(retainedBlock,{type:'blocked_melee',blockId:1},9);wound(retainedBlock,10)
assert.equal(plan(retainedBlock,base,null).command.kind,'guard-reply',
  'with shield available, an old block record must not suppress a newer real wound at low charge')
const brokenCounter=createState('Opponent','Punengbho')
receipt(brokenCounter,{type:'blocked_melee',blockId:1},9)
receipt(brokenCounter,{type:'shield_disabled',cooldownTicks:100},9);wound(brokenCounter,10)
assert.equal(plan(brokenCounter,{...base,shieldReady:false,charge:.8},null).command.kind,'counter',
  'the real shield-disabled counter retains priority over ordinary guarded retaliation')
const late=createState('Opponent','Punengbho');wound(late)
assert(!plan(late,{...base,tick:14},null).command.attack,'expired wound must not become future spam')
const defended=createState('Opponent','Punengbho');wound(defended)
assert(!plan(defended,{...base,targetShieldRaised:true,targetShieldFacing:true},null).command.attack)
const danger=createState('Opponent','Punengbho');wound(danger)
const dangerPlan=plan(danger,{...base,targetCriticalThreat:true},null)
assert(dangerPlan.command.shield&&!dangerPlan.command.attack,'original critical-risk guard remains')
const noShield=createState('Opponent','Punengbho');noShield.mode='NEURAL';noShield.shieldUntil=100
wound(noShield)
const model={decidedTick:10,forward:-1,side:0,sprint:false,jump:false,attack:false,slot:0}
const noShieldPlan=plan(noShield,{...base,shieldReady:false},model)
assert.equal(noShieldPlan.owners.attack,'neural');assert(!noShieldPlan.command.attack)
const orbit=createState('Opponent','Punengbho')
const front={...base,self:{x:0,y:0,z:-.8},sentPosition:{x:0,y:0,z:-.8},distance:.8,reach:.5,
  targetShieldRaised:true,targetShieldFacing:true,charge:1,targetGrounded:true,orbitDraw:0}
let p=plan(orbit,front,null);assert(p.command.orbit);applied(orbit,p.command,false,10)
for(let tick=11;tick<15;tick++){p=plan(orbit,{...front,tick,shieldEffective:false},null);applied(orbit,p.command,false,tick)}
p=plan(orbit,{...front,tick:15,shieldEffective:false,targetLoading:true,arrows:8},null)
assert(p.command.shield&&!p.command.orbit&&!p.command.attack&&!p.command.ranged,
  'tracked frontal shield with no rear ends in reblock, not more circling or ranged use')
// Verify a front-facing target that released shield can be hit; a last-moment
// re-raise suppresses that same packet and restores our shield.
function executeReply(targetRaised){
  const state=createState('Opponent','Punengbho');wound(state)
  const planned=plan(state,base,null),packets=[],controls={},inventory={slots:[]};inventory.slots[45]={name:'shield'}
  let use={kind:'shield',tick:5}
  const bot={quickBarSlot:7,food:20,inventory,entity:{position:base.self,yaw:Math.PI,pitch:0,onGround:true,velocity:{y:0}},
    _client:{write:(name,data)=>packets.push({name,data})},heldItem:{name:'diamond_axe'},
    setControlState:(k,v)=>{controls[k]=v},getControlState:k=>Boolean(controls[k]),
    activateItem:()=>bot._client.write('use_item',{hand:1}),attack:()=>bot._client.write('use_entity',{mouse:1})}
  const target={position:base.target,yaw:0,width:.6,height:1.8,metadata:{8:targetRaised?3:0},
    equipment:[{name:'diamond_sword'},{name:'shield'}]}
  const result=executeCommand({bot,planned,frame:{self:{...base.self,eyeY:1.62},seen:{visible:true},observation:base},target,tick:10,
    session:{id:'pilot',opponent:'Opponent',state,attackedDecisions:new Set(),attackOwners:new Map()},
    charge:()=>.35,shieldUntil:0,lastAttackTick:-1000,weaponEpoch:0,
    look:(yaw,pitch=0)=>{bot.entity.yaw=yaw;bot.entity.pitch=pitch},aim:()=>{},offhand:()=>true,
    stopUse:()=>{if(use)bot._client.write('block_dig',{status:5});use=null},getUse:()=>use,setUse:v=>{use=v},
    plugin:()=>{},onSwitch:()=>{},onAttack:()=>{},ownLoaded:()=>false})
  return {result,packets,use}
}
const hit=executeReply(false)
assert(hit.result.attacked);assert.equal(hit.use.kind,'shield')
assert.deepEqual(hit.packets.filter(p=>['block_dig','use_entity','use_item'].includes(p.name)).map(p=>p.name),
  ['block_dig','use_entity','use_item'],'release, genuine reply packet, immediate shield request')
const blocked=executeReply(true)
assert(!blocked.result.attacked&&blocked.use.kind==='shield')
console.log('PILOT_ORIGINAL_GUARD_WOUND_AND_ORBIT_REBLOCK_PASS')
