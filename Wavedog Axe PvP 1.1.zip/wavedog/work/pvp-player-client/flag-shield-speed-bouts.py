"""Mark human bouts with measured shield-running defects without deleting data."""
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import json
import math

BASE = Path(__file__).resolve().parent
STORE = BASE / 'new-learning/selfplay'
REFEREE = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogSelfPlayGate/bouts.jsonl')
FLAGS = STORE / 'quality-flags.jsonl'


def rows(path):
    if not path.exists():
        return
    with path.open(encoding='utf-8') as stream:
        for line in stream:
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def stamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def main():
    reports = []
    for report in rows(STORE / 'human-challenges.jsonl'):
        trace = (report.get('native') or {}).get('trace') or []
        if len(trace) < 2:
            continue
        reports.append((report, stamp(trace[0][0]), stamp(trace[-1][0])))
    existing = {row['matchId'] for row in rows(FLAGS)}
    violations = defaultdict(list)
    for event in rows(REFEREE):
        if event.get('type') != 'shield_motion' or not event.get('effective_blocking'):
            continue
        move = event.get('horizontal_move_requested', event.get('horizontal_move', 0))
        if move <= .12 or event.get('knockback_exemption'):
            continue
        if math.hypot(event.get('velocity_x', 0), event.get('velocity_z', 0)) >= .12:
            continue
        at = stamp(event['at'])
        for report, start, end in reports:
            if (report['arena'] == event.get('arena') and report['bout'] == event.get('bout')
                    and report['bot'] == event.get('bot') and start <= at <= end):
                violations[report['matchId']].append(event)
                break
    by_id = {report['matchId']: report for report, _, _ in reports}
    added = []
    with FLAGS.open('a', encoding='utf-8') as stream:
        for match_id, events in sorted(violations.items()):
            if match_id in existing or len(events) < 3:
                continue
            report = by_id[match_id]
            flag = {'at': datetime.now().astimezone().isoformat(), 'matchId': match_id,
                    'bot': report['bot'], 'opponent': report['opponent'],
                    'status': 'mechanics-invalid', 'reason': 'server-effective-shield-with-input-speed',
                    'measuredPackets': len(events),
                    'maxBlocksPerPacket': round(max(e.get('horizontal_move_requested',
                                                       e.get('horizontal_move', 0)) for e in events), 4),
                    'trainingHistoryPreserved': True}
            stream.write(json.dumps(flag, ensure_ascii=False) + '\n')
            added.append(flag)
    print(json.dumps({'flagged': added, 'totalFlagged': len(existing) + len(added)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
