"""Snapshot the shared checkpoint and append-only training records before reload."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import shutil

base = Path(__file__).resolve().parent
root = base / "new-learning"
source = [root / "models/recurrent-ppo.json", *sorted((root / "selfplay").glob("*.jsonl")),
          root / "reference/shield-axe-pvp-knowledge-20261111.md"]
if not all(path.is_file() for path in source):
    raise SystemExit("Required checkpoint or record missing")
target = root / "backups" / ("before-shared-clones-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
target.mkdir(parents=True, exist_ok=False)
manifest = []
for original in source:
    relative = original.relative_to(root)
    copy = target / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, copy)
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    before, after = digest(original), digest(copy)
    if before != after:
        raise SystemExit(f"Backup changed during copy: {relative}")
    manifest.append({"path": relative.as_posix(), "bytes": copy.stat().st_size,
                     "sha256": after})
(target / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"backup": str(target), "files": len(manifest),
                  "modelSha256": manifest[0]["sha256"]}, ensure_ascii=False))
