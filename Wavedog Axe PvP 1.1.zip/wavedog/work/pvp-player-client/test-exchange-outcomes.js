const assert = require('node:assert/strict')
const { analyzeExchanges } = require('./exchange-outcomes')
const at = ms => new Date(1794430000000 + ms).toISOString()
const hit = (ms, attacker, victim, amount) => ({ at: at(ms), type: 'damage',
  source: 'MELEE', attacker, victim, amount })

const outcome = analyzeExchanges('Bot','WaveJerry', [
  hit(0,'WaveJerry','Bot',4), hit(400,'Bot','WaveJerry',2),
  hit(900,'WaveJerry','Bot',3), hit(3200,'Bot','WaveJerry',4)
])
assert.equal(outcome.exchangeCount,2)
assert.equal(outcome.lostExchanges,1)
assert.equal(outcome.wonExchanges,1)
assert.equal(outcome.exchangeOutcomes[0].net,-5)
assert(outcome.exchangeOutcomes[0].reward<0)
assert.equal(outcome.exchangeOutcomes[1].reward,0)
console.log('EXCHANGE_OUTCOMES_PASS loss receives extra native penalty')
