/** Verify critical tactics with public frame history and the Paper damage receipt. */
const time = row => Date.parse(row.at)
const range = row => Math.hypot(row.self.x - row.seen.x, row.self.z - row.seen.z)

function near (frames, at, tolerance = 150) {
  const target = time(at)
  let best = null, gap = Infinity
  for (const frame of frames) {
    const delta = Math.abs(time(frame) - target)
    if (delta < gap) { best = frame; gap = delta }
  }
  return gap <= tolerance ? best : null
}

function jumpIn (frames, event) {
  const hit = near(frames, event)
  if (!hit || range(hit) > 3.35 || hit.self.ground !== false || hit.self.vy >= -.05) return false
  const end = time(event)
  // This is an entry from outside melee range, not a stationary close-range jump.
  const start = frames.find(row => end - time(row) >= 180 && end - time(row) <= 1300
    && row.self.ground === true && range(row) >= 3.6 && range(row) <= 7)
  return Boolean(start && frames.some(row => time(row) > time(start) && time(row) <= end
    && row.self.ground === false && range(row) < range(start) - .4))
}

function opponentJumpIn (frames, event) {
  // The fighter's public view of the opponent can establish an entry and a
  // descending threat. It cannot establish the opponent's hidden input.
  const hit = near(frames, event)
  if (!hit || range(hit) > 3.35 || hit.seen.vy >= -.05
    || hit.seen.y <= hit.self.y + .15) return false
  const end = time(event)
  return frames.some(row => end - time(row) >= 180 && end - time(row) <= 1300
    && range(row) >= 3.6 && range(row) <= 7)
}

/** Credit a chosen takeoff only after observing its actual flight and landing. */
function analyzeLandingChoices (fighter, opponent, actions, frames, events) {
  const ordered = [...actions].sort((a,b) => time(a)-time(b))
  const attempts = []
  let jumping = false
  for (const action of ordered) {
    const active = Boolean(action.executed?.jump)
    if (active && !jumping && !action.ignoredHeads?.includes(2)
        && Number.isInteger(action.decidedFrame)) {
      const start = near(frames, action, 100)
      if (start?.self.ground) {
        const takeoffAt = time(action)
        const airborne = frames.find(row => time(row) > takeoffAt
          && time(row) - takeoffAt <= 350 && row.self.ground === false)
        const landing = airborne && frames.find(row => time(row) > time(airborne)
          && time(row) - takeoffAt <= 1600 && row.self.ground === true)
        if (landing) {
          const end = time(landing)
          const own = events.filter(e => e.type === 'damage' && !e.cancelled
            && e.attacker === fighter && e.victim === opponent && e.amount > 0
            && time(e) >= takeoffAt && time(e) <= end + 100)
          const taken = events.filter(e => e.type === 'damage' && !e.cancelled
            && e.attacker === opponent && e.victim === fighter && e.amount > 0
            && time(e) >= takeoffAt && time(e) <= end + 100)
          const critical = own.some(e => e.source === 'MELEE' && e.native_critical === true)
          const dealt = own.reduce((n,e) => n + e.amount, 0)
          const received = taken.reduce((n,e) => n + e.amount, 0)
          const landingRange = +range(landing).toFixed(2)
          const approach = +(range(start)-landingRange).toFixed(2)
          const horizontalTravel = +Math.hypot(
            landing.self.x - start.self.x, landing.self.z - start.self.z).toFixed(2)
          const sprintEntry = Boolean(action.executed.sprint)
            && (action.selected?.forward > .5 || action.executed.forward)
            && range(start) >= 3.6 && approach > .4
          // A short hop that closes because the opponent moved is not a
          // full-travel sprint jump. Measure the fighter's actual displacement.
          const longRunJump = sprintEntry && horizontalTravel >= 2.4
          const reward = critical && longRunJump ? .08
            : critical && sprintEntry ? .065
            : critical ? .045 : received > dealt ? -.012
            : landingRange <= 3 && approach > .4 ? .006
              : landingRange > 3.5 && dealt === 0 ? -.005 : 0
          attempts.push({ at: action.at, decidedFrame: action.decidedFrame,
            startRange: +range(start).toFixed(2), landingRange, approach,
            horizontalTravel, sprintEntry, longRunJump, critical, dealt: +dealt.toFixed(2),
            received: +received.toFixed(2), reward })
        }
      }
    }
    jumping = active
  }
  return { landingAttempts: attempts.length,
    landedInReach: attempts.filter(a => a.landingRange <= 3).length,
    landingCriticalHits: attempts.filter(a => a.critical).length,
    sprintJumpEntries: attempts.filter(a => a.sprintEntry).length,
    sprintJumpCriticalHits: attempts.filter(a => a.sprintEntry && a.critical).length,
    longRunJumpEntries: attempts.filter(a => a.longRunJump).length,
    longRunJumpCriticalHits: attempts.filter(a => a.longRunJump && a.critical).length,
    landingOutcomes: attempts }
}

function analyzeCriticalTactics (fighter, opponent, events, frames) {
  const damage = events.filter(e => e.type === 'damage' && e.source === 'MELEE' && !e.cancelled)
  const ownHits = damage.filter(e => e.attacker === fighter && e.victim === opponent && e.amount > 0)
  const incoming = damage.filter(e => e.attacker === opponent && e.victim === fighter)
  const outcomes = []
  let nativeCriticalHits = 0, jumpInCriticalHits = 0, jumpInShieldBlocks = 0
  let fallingThreatFirstHits = 0, nativeCriticalShieldBlocks = 0
  let shieldedCriticalEligibleAttacks = 0
  for (const hit of ownHits) {
    if (hit.native_critical === true) {
      nativeCriticalHits++
      outcomes.push({ at: hit.at, kind: 'native-critical-hit', reward: .025 })
      if (jumpIn(frames, hit)) {
        jumpInCriticalHits++
        outcomes.push({ at: hit.at, kind: 'jump-in-critical-hit', reward: .04 })
      }
    }
    const view = near(frames, hit)
    if (view && range(view) <= 3.35 && view.seen.vy < -.05
      && view.seen.y > view.self.y + .15
      && !incoming.some(e => e.native_critical === true && e.amount > 0
        && e.tick >= hit.tick - 2 && e.tick <= hit.tick + 15)) {
      // Landed first against a visible falling threat; this is measurable,
      // but the missing later critical alone does not prove causation.
      fallingThreatFirstHits++
      outcomes.push({ at: hit.at, kind: 'first-hit-vs-falling-threat', reward: .025 })
    }
  }
  for (const attack of incoming) {
    if (!attack.victim_blocking || !(attack.shield_modifier < 0)) continue
    const eligible = attack.attacker_fall_distance > .1
      && attack.attacker_on_ground === false
      && attack.attacker_sprinting === false
      && attack.native_attack_charge > .9
    if (eligible) {
      shieldedCriticalEligibleAttacks++
      outcomes.push({ at: attack.at, kind: 'shield-blocked-falling-attack', reward: .025 })
    }
    if (attack.native_critical === true) {
      nativeCriticalShieldBlocks++
      if (!eligible) outcomes.push({ at: attack.at, kind: 'shield-blocked-native-critical', reward: .025 })
    }
    if ((eligible || attack.native_critical === true) && opponentJumpIn(frames, attack))
      jumpInShieldBlocks++
  }
  return { nativeCriticalHits, jumpInCriticalHits, jumpInShieldBlocks,
    fallingThreatFirstHits, nativeCriticalShieldBlocks,
    shieldedCriticalEligibleAttacks, criticalOutcomes: outcomes }
}

module.exports = { analyzeCriticalTactics, analyzeLandingChoices }
