const assert = require('node:assert/strict')
const { shieldBlockSound, creditedMeleeBlock } = require('./public-shield-cue')

for (const sound of ['item.shield.block', 'minecraft:item.shield.block',
  'minecraft:item_shield_block']) assert.equal(shieldBlockSound(sound), true)
for (const sound of ['item.shield.break', 'minecraft:item_shield_break',
  'entity.player.attack']) assert.equal(shieldBlockSound(sound), false)

const session = { kind:'human-challenge', lastEffectiveShieldAt:100,
  opponentSwingAt:110 }
assert.equal(creditedMeleeBlock(session,150,2.8),true)
assert.equal(creditedMeleeBlock(session,251,2.8),false)
assert.equal(creditedMeleeBlock(session,150,3.6),false)
assert.equal(creditedMeleeBlock({...session,opponentSwingAt:-500},150,2.8),false)
assert.equal(creditedMeleeBlock({...session,lastEffectiveShieldAt:-500},150,2.8),false)
assert.equal(creditedMeleeBlock({...session,kind:'selfplay'},150,2.8),false)
console.log('PUBLIC_SHIELD_CUE_PASS')
