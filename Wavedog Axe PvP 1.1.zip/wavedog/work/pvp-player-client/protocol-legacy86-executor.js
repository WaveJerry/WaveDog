'use strict'
const mechanical=require('./protocol-pilot-mechanical-executor')
function executeCommand(ctx){
  const c=ctx.planned.command
  // Multiple preview replies may already be in flight when the first attack
  // reaches the wire. A new result is not a new attack opportunity.
  const blockedByReceipt=Boolean(c.attack&&(ctx.session.state.pending?.size||ctx.lastAttackTick>=ctx.tick))
  if(blockedByReceipt){
    c.attack=c.doubleAttack=false
    if(ctx.frame.self.shieldAvailable&&!c.ranged){c.shield=true;c.offhand='shield'}
  }
  // A route forecast assumes real forward sprint, not backward+sprint keys.
  // Strike packets briefly face the closest box point and restore this view.
  if(c.worldHeading){
    if(Math.hypot(c.worldHeading.x,c.worldHeading.z)>.5){
      c.arrowYaw=Math.atan2(-c.worldHeading.x,-c.worldHeading.z);c.keepLook=true
    }else{
      // headingKeys(0,0) maps atan2(0,0) to FORWARD. Consume HOLD here.
      c.worldHeading=null;c.forward=c.side=0;c.sprint=false;c.aimAway=false
      c.keepLook=false;delete c.arrowYaw
    }
  }
  const extra={...ctx,legacySneak:true,shieldReceiptGraceTicks:8,
    legacySprintKnockback:ctx.planned.original?.sprintKnockback===true,
    legacyShieldRearGate:!['legacy86-stun','legacy86-counter'].includes(c.kind)}
  const result=mechanical.executeCommand(extra)
  if(blockedByReceipt)result.attackSuppressedReason='pending-or-same-physical-tick-attack'
  result.attacks=result.attacked?[{id:result.executedAttackId,charge:result.attackCharge,
    held:result.attackHeld,packets:[...result.packets]}]:[]
  if(c.doubleAttack&&result.attacked){
    // Exactly two attempts, with separate native intent IDs. Neither a 500Hz
    // poll nor a delayed receipt is allowed to replay this pair.
    const second={...c,attackId:ctx.session.state.nextId++,doubleAttack:false}
    const follow=mechanical.executeCommand({...extra,planned:{...ctx.planned,command:second}})
    result.packets.push(...follow.packets)
    if(follow.attacked)result.attacks.push({id:follow.executedAttackId,charge:follow.attackCharge,
      held:follow.attackHeld,packets:follow.packets})
    // Return immediately, rather than leaving the axe held until next tick.
    if(ctx.bot.quickBarSlot!==0){ctx.bot.setQuickBarSlot(0);ctx.onSwitch();result.switched=true}
    result.held=ctx.bot.quickBarSlot
    result.heldItemName=ctx.bot.heldItem?.name||null
  }
  if(result.attacked&&ctx.frame.self.shieldAvailable
      &&['COUNTER','ORBIT_BACK','ORBIT_TRADE'].includes(c.phase)&&ctx.tick>=ctx.shieldUntil
      &&ctx.offhand('shield')){
    ctx.bot.activateItem(true);ctx.setUse({kind:'shield',tick:ctx.tick})
    result.shieldRequested=true;result.using='shield'
  }
  result.ignoredHeads=Array.from({length:9},(_,i)=>i)
  return result
}
module.exports={executeCommand}
