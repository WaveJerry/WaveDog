'use strict'
const {createThreatClock,planSpacing,planShortAdvance,arenaCenter,eyeBoxReach}=require('./protocol-legacy86-threat')
const {createLegacyRuntime}=require('./protocol-legacy86-runtime')
const {orbitGoal,orbitHeading,confirmedRear}=require('./protocol-mechanical-math')
const {syncRanged,rangedApplied}=require('./protocol-legacy86-ranged')
const finite=(n,fallback=4)=>Number.isFinite(n)?n:fallback
const age=(tick,at)=>at===undefined?1000:Math.max(0,tick-at)
const neutral=()=>({forward:0,side:0,sprint:false,jump:false,sneak:false,attack:false,
  slot:null,shield:false,offhand:'shield',ranged:null,kind:'legacy86',ppoEligible:false})
const decisionFields=['previousReach','previousShield','targetLandAt','targetWasGrounded','airPastInterrupt',
  'airDefense','hadHop','swordOnly','wasHop','stun','stunSerial','lastStunAt','orbitGoal','lastPhase','rangedSync','closeFight']
function decisionDraft(s){
  const draft={...s,threatClock:createThreatClock()}
  for(const key of decisionFields)if(s[key]&&typeof s[key]==='object')draft[key]=structuredClone(s[key])
  return draft
}
function resolveContact(frame,wasHop){
  const air=frame.airPlan,o=frame.observation
  // A failed escape forecast is not permission to forbid all damage forever.
  // Counter-hop and working shields retain their original ownership.
  return !wasHop&&!frame.self.shieldAvailable&&o.visible&&o.reach<=2&&air.threat
    &&air.action==='no-guaranteed-route'&&!air.route?.safe&&!o.arrowThreat
}
function immediateGroundContact(s,frame,tick){
  const a=frame.self,o=frame.observation
  return !s.wasHop&&!s.closeFight&&!s.airDefense&&!a.shieldAvailable&&!a.using
    &&a.ground&&a.charge>=.999&&o.visible&&o.targetGrounded&&!o.targetAirborne
    &&o.reach<=3&&!o.targetShieldRaised&&!o.targetShieldFacing&&!o.arrowThreat
    &&!o.targetCriticalThreat&&age(tick,s.lastHit)>2
    &&frame.targetMotion&&tick-frame.targetMotion.sampleTick<=2&&(frame.latency?.observationAgeMs??0)<=50
}
function closeFightIntent(s,frame,tick){
  const a=frame.self,o=frame.observation
  if(s.wasHop||!s.swordOnly||a.shieldAvailable&&!s.closeFight||!o.visible||o.reach>3||o.arrowThreat)return null
  if(!s.closeFight&&frame.airPlan.threat&&frame.airPlan.route?.safe)return null
  const next=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},
    {...frame.seen,x:frame.seen.x+frame.targetVelocity.x,z:frame.seen.z+frame.targetVelocity.z})
  const unavoidableEntry=o.targetAirborne&&frame.targetVelocity.y<0&&frame.airPlan.threat
    &&!frame.airPlan.route?.safe&&next<=2
  return s.closeFight||o.reach<=2||unavoidableEntry
    ?s.closeFight||{enteredAt:tick,firstHitDone:false,afterStunAt:null}:null
}
function closeFightCommand(s,frame,tick){
  const a=frame.self,o=frame.observation,v=frame.targetVelocity
  const dx=frame.seen.x-a.x,dz=frame.seen.z-a.z,n=Math.max(.001,Math.hypot(dx,dz))
  const separating=((v.x-a.vx)*dx+(v.z-a.vz)*dz)/n
  const next=eyeBoxReach({...a,x:a.x+a.vx,z:a.z+a.vz},
    {...frame.seen,x:frame.seen.x+v.x,z:frame.seen.z+v.z})
  const exiting=o.reach>=2.6&&separating>.03&&next>3
  const critical=Boolean(a.critical&&a.charge>.9)
  const opening=!s.closeFight.firstHitDone&&a.ground&&a.charge>=.9&&!o.targetAirborne
  const stunFallback=s.closeFight.afterStunAt!==null&&a.critical&&a.charge>=.2
  const attack=!o.targetShieldFacing&&(critical||opening||stunFallback||exiting&&a.charge>=.2)
  return {slot:0,shield:false,offhand:'shield',ranged:null,kind:'legacy86-close',
    intent:exiting?'close-exit-hit':'close-sword-dps',attackRole:exiting?'exit':'close-dps',
    forward:1,side:0,sprint:!critical&&a.ground,jump:!exiting,sneak:false,
    attack,critical:attack&&critical,doubleAttack:false,worldHeading:null,aimAway:false,keepLook:false}
}
function createState(opponent,fighter='Punengbho'){
  return {opponent,fighter,mode:'LEGACY86',nextId:1,transitions:[],lastBlock:-1000,
    lastDamage:-1000,lastHit:-1000,breakAt:-1000,counterAt:-1000,spentBlock:-1000,
    previousReach:Infinity,swordOnly:false,wasHop:false,shieldUntil:0,pending:new Map(),
    threatClock:createThreatClock(),stun:null,stunSerial:0,lastStunAt:-1000,decisionVersion:0}
}
function publicInput(s,frame,tick,commit=true){
  const o=frame.observation,a=frame.self,b=frame.seen,v=frame.targetVelocity
  const reach=finite(o.reach),other=finite(o.otherReach),visible=Boolean(o.visible)
  const dx=visible?b.x-a.x:0,dz=visible?b.z-a.z:0,d=Math.hypot(dx,dz)||1
  const ux=dx/d,uz=dz/d,sideX=-uz,sideZ=ux
  const center=frame.arenaCenter||arenaCenter(a),cx=center?center.x-a.x:0,cz=center?center.z-a.z:0
  const centerDistance=Math.hypot(cx,cz),cn=Math.max(.001,centerDistance)
  const separationSpeed=(v.x-a.vx)*ux+(v.z-a.vz)*uz
  const entered=reach<=3&&s.previousReach>3;if(commit)s.previousReach=reach
  const shield=Boolean(o.shieldReady),raised=Boolean(o.targetShieldRaised)
  const rear=raised&&confirmedRear(a,o.sentPosition,b,o.targetYaw)
  let opportunity='NONE'
  if(visible&&reach<=3){
    if(s.lastBlock>s.spentBlock&&age(tick,s.lastBlock)<=6)opportunity='BREAK_COUNTER'
    else if(o.targetAirborne&&v.y>0&&!raised)opportunity='RISE_INTERRUPT'
    else if((!raised||rear)&&(s.lastDamage===tick||age(tick,s.lastDamage)<=2))opportunity='ORBIT_TRADE'
    else if((!raised||rear)&&o.receding&&separationSpeed>.03&&reach>=2.3)opportunity='EXIT'
    else if(entered&&(!raised||rear))opportunity='ENTRY'
    else if(raised&&rear)opportunity='ORBIT_BACK'
  }
  const view={tick,distance:finite(o.distance),visible,targetBlocking:Boolean(o.targetShieldFacing||raised&&!rear),
    targetAxe:/AXE$/.test(b.held||''),targetFacing:(o.targetFacingDot??1)>0,
    ownShieldAvailable:shield,ownShieldJustDisabled:age(tick,s.breakAt)<=1,
    targetShieldJustDropped:s.previousShield===true&&!raised,targetAttackedRecently:Boolean(o.targetSwingRecent),
    ownAttackReady:a.charge>=.999,ownWounded:age(tick,s.lastDamage)<=2,
    nearWall:o.wallMargin<1.2,targetNearWall:false,hasArrows:a.arrows>0,
    targetDrawingRanged:Boolean(o.targetBow||o.targetLoading),targetHoldingRanged:Boolean(o.targetRanged),
    targetMotion:o.targetApproaching?'APPROACH':o.receding?'RETREAT':Math.hypot(v.x,v.z)>.025?'STRAFE':'STILL',
    targetInReach:reach<=3,ownAttackCharge:a.charge,bowDrawTicks:a.using&&frame.usingKind==='bow'?a.useTicks:0,
    rangedUseTicks:a.useTicks,ownCrossbowCharged:a.crossbowLoaded,
    ownOffhand:({shield:'SHIELD',bow:'BOW',crossbow:'CROSSBOW',arrow:'ARROW'})[frame.offhand]||'EMPTY'}
  if(commit)s.previousShield=raised
  const swordPhase=s.swordOnly&&!s.wasHop&&!shield
  const senses={opportunity,enteredReach:entered,ownWeapon:swordPhase?0:a.held===0?1:0,
    weaponInputReady:!a.inventoryObservation?.switching,onGround:a.ground,
    ownReachDistance:reach,targetReachDistance:other,estimatedReach:reach,estimatedTargetReach:other,
    meleeRayDistance:reach,estimateAge:visible?0:1000,
    targetMotionFresh:Boolean(frame.targetMotion&&tick-frame.targetMotion.sampleTick<=2),
    targetForward:v.x*ux+v.z*uz,targetSide:v.x*sideX+v.z*sideZ,targetY:v.y,
    ownForward:a.vx*ux+a.vz*uz,ownSide:a.vx*sideX+a.vz*sideZ,ownY:a.vy,
    targetFacingDot:o.targetFacingDot??1,separationSpeed,health:a.health,food:a.food,
    arrows:a.arrows,blocking:a.shielding,holdingShield:frame.offhand==='shield',
    targetShieldRaised:raised,targetShieldDisabled:!raised&&age(tick,s.targetShieldDisabledAt)<100,
    targetAirborne:o.targetAirborne,targetCriticalPossible:o.targetCriticalPossible,
    targetCritThreat:o.targetCriticalThreat,targetCritEta:frame.airPlan?.criticalTicks?.[0]??60,
    targetSword:/SWORD$/.test(b.held||''),ownCriticalWindow:a.critical,ownCriticalReady:a.critical&&a.charge>.9,
    ownShieldCooldown:Math.max(0,s.shieldUntil-tick),ownBreakAge:age(tick,s.breakAt),
    ownShieldWarmup:o.shieldRaised?Math.max(0,5-a.useTicks):5,
    damageAge:age(tick,s.lastDamage),attackAge:age(tick,s.lastAttempt),counterEscapeAge:age(tick,s.counterAt),
    blockedMeleeAge:age(tick,s.lastBlock),lastBlockTick:s.lastBlock,lastMeleeTick:s.lastAttempt??-1000,
    counterAxeHitTick:s.counterAt,targetAttackAge:age(tick,frame.swingAt),
    ownKnockbackAge:age(tick,s.lastDamage),targetKnockbackAge:age(tick,s.lastHit),
    targetLandAge:o.targetGrounded?age(tick,s.targetLandAt):1000,
    targetCharged:Boolean(o.targetKnownLoaded),crossbowPresent:a.hasCrossbow,crossbowLoaded:a.crossbowLoaded,
    crossbowCanLoad:a.hasCrossbow&&a.arrows>0,bowPresent:a.hasBow,
    usingRanged:['bow','crossbow'].includes(frame.usingKind),shieldCoversRanged:shield&&Boolean(o.arrowThreat),
    shieldShouldRaise:shield&&Boolean(o.arrowThreat),cancelRangedForArrow:Boolean(o.arrowThreat),
    targetShieldDisabledAge:undefined,rangeControl:!shield,escapeSword:s.wasHop,
    escapeViable:true,escapeJumpEligible:true,jumpInputReady:!s.wasHop,retreatJumpEligible:!s.wasHop,
    wallEscapeAvailable:true,retreatBlocked:false,collisionOverlap:reach<.65,
    retreatOpened:o.mutualOutOfReach,fallDistance:a.fallDistance??0,
    centerDistance,centerForward:(cx*ux+cz*uz)/cn,centerSide:(cx*sideX+cz*sideZ)/cn}
  delete senses.targetShieldDisabledAge
  if(o.airEnvelope?.valid)senses.airEnvelope=o.airEnvelope
  if(frame.airPlan?.valid){
    const p=frame.airPlan.route
    senses.targetCritThreat=frame.airPlan.threat
    senses.jumpSpace={threat:frame.airPlan.threat,move:2,clearance:p?.clearance??0,
      x:p?.heading.x??0,z:p?.heading.z??0,sprint:p?.sprint??false,jump:false}
    // Existence of a route is not evidence that it escapes the crit window.
    // Otherwise counterFlight keeps fleeing along a known-unsafe route.
    senses.wallEscapeAvailable=Boolean(p?.safe);senses.escapeViable=Boolean(p?.safe)
    senses.retreatBlocked=!p
    if(frame.airPlan.threat&&frame.airPlan.criticalTicks.length){
      const crit=frame.airPlan.criticalTicks[0]
      senses.airEnvelope={valid:true,meleeTick:crit,criticalTick:crit,
        closestMelee:0,closestCritical:0,maxSteering:frame.airPlan.envelope.at(-1)?.radius??0,
        ticks:frame.airPlan.envelope.length-1}
    }
  }
  if(o.arrowThreat){
    const threat=o.arrowThreat,safe=Array(18).fill(false),viable=Array(18).fill(false)
    const move=threat.side<0?4:threat.side>0?5:0;safe[move]=viable[move]=true
    senses.projectilePlan={threat:true,eta:finite(threat.ticks,1),miss:0,preferredMove:move,
      safeMoves:safe,viableMoves:viable,shieldSafe:shield,releaseUse:true,primaryId:threat.id}
  }
  return {command:'frame',view,senses,swordMode:swordPhase,targetGrounded:Boolean(o.targetGrounded),
    shortAdvance:frame.shortAdvance||null,
    // Estimate from our confirmed damage events; never queried enemy immunity.
    targetImmunity:age(tick,s.lastHit)<10?20-age(tick,s.lastHit):0,
    hopCharge:a.charge,hopVelocityY:a.vy,targetLoading:Boolean(o.targetLoading)}
}
function originalPlan(result,frame,tick){
  const d=result.decision,c=neutral()
  const motion={FORWARD:[1,0],BACKWARD:[-1,0],LEFT:[0,-1],RIGHT:[0,1],
    FORWARD_LEFT:[1,-1],FORWARD_RIGHT:[1,1],BACKWARD_LEFT:[-1,-1],BACKWARD_RIGHT:[-1,1],HOLD:[0,0]}[d.motion]
  ;[c.forward,c.side]=motion
  Object.assign(c,{sprint:d.sprint,jump:d.jump,sneak:d.sneak,attack:d.attack,shield:d.shield,
    aimAway:d.faceAway,offhand:d.offhand.toLowerCase(),slot:d.weapon==='SWORD'?0:7,
    critical:['FALL_CRIT'].includes(d.technique),decidedTick:tick,
    technique:d.technique,phase:result.phase,kind:result.phase==='COUNTER'?'legacy86-counter':'legacy86'})
  // In 8.6 a ranged proposal alone is not permission to use a ranged item:
  // OffhandRangedSupport gates it. Apply the public synchronization below.
  if(['BOW','CROSSBOW'].includes(d.weapon))c.shield=frame.self.shieldAvailable
  const owners=Object.fromEntries(['movement','sprint','jump','look','sneak','mainhand','attack','shield','offhand'].map(k=>[k,'legacy86']))
  return {mode:'LEGACY86',owners,command:c,original:result}
}
function createBrain({runtime=createLegacyRuntime(),planner=null,onError=()=>{}}={}){
  const ready=runtime.request({command:'reset',seed:123})
  let current=null
  const send=(row)=>runtime.request(row).catch(error=>{onError(error);throw error})
  function outcome(s,id,damage,critical){
    const p=s.pending.get(id);if(!p)return
    s.pending.delete(id)
    if(p.original)void send({command:'outcome',id,damage,critical}).catch(()=>{})
    if(damage>0)s.lastHit=p.tick
    if(p.counter&&damage>0){s.counterAt=p.tick;s.spentBlock=s.lastBlock}
  }
  function isDecisionCurrent(s,p){return p.baseStateVersion===(s.decisionVersion||0)}
  function commitDecision(s,p){
    if(!isDecisionCurrent(s,p))return false
    for(const key of decisionFields)s[key]=p.statePatch[key]
    s.decisionVersion=(s.decisionVersion||0)+1
    if(p.command.attack)p.command.attackId=s.nextId++
    p.committedStateVersion=s.decisionVersion
    return true
  }
  return {ready,runtime,
    createState,isDecisionCurrent,commitDecision,
    async reset(s,seed){current=s;s.threatClock.reset();await send({command:'reset',seed})},
    receipt(s,e,tick){
      if(e.type==='self_state')s.shieldUntil=tick+e.shieldCooldown
      if(e.type==='shield_disabled'){s.shieldUntil=tick+e.cooldownTicks;s.breakAt=tick}
      if(e.type==='blocked_melee'){s.lastBlock=tick;s.blockId=e.blockId;if(e.shieldDisabled){s.breakAt=tick;s.shieldUntil=Math.max(s.shieldUntil,tick+100)}}
      if(e.type==='damage'&&!e.cancelled){
        if(e.victim===s.fighter&&e.amount>0)s.lastDamage=tick
        if(e.attacker===s.fighter&&e.victim===s.opponent&&e.melee)
          outcome(s,e.attackId,e.amount,e.nativeCritical)
      }
      if(e.type==='attack_packet'&&e.willAttack===false)outcome(s,e.attackId,0,false)
    },
    async decide(s,frame,probe,tick,{preview=false,isCurrent=null,transactional=false}={}){
      if(current!==s)throw Error('8.6 runtime bout not reset')
      // Only real observation processing may age live attack acknowledgments.
      // A preview is a proposal, never a writer of the live controller state.
      if(!preview)for(const [id,p]of s.pending)if(tick-p.tick>=3)outcome(s,id,0,false)
      const liveState=s,baseStateVersion=s.decisionVersion||0
      s=decisionDraft(s)
      frame.targetRecentHitTicks=age(tick,s.lastHit)
      frame.allowJumpResetForecast=s.swordOnly&&!s.wasHop&&!frame.self.shieldAvailable
      // An already legal, fully charged ground contact needs the original
      // strike decision now; it does not need another collision-route search.
      // Shield, airborne and possible jump-reset observations retain the full
      // threat path. This changes scheduling, never grants an attack itself.
      const directContact=immediateGroundContact(s,frame,tick)
      const computed=directContact?{airPlan:{valid:false,threat:false,reason:'live-ground-contact'},
        spacing:null,shortAdvance:null}:planner?await planner.evaluate(frame,probe):null
      if(computed?.superseded||isCurrent&&!isCurrent())return null
      if(frame.observation.targetGrounded&&!s.targetWasGrounded)s.targetLandAt=tick
      s.targetWasGrounded=frame.observation.targetGrounded
      frame.airPlan=computed?computed.airPlan:s.threatClock.update(frame,probe,s.opponent)
      // A late-ascent or descending jump cannot become an early-ascent
      // interrupt merely because a delayed packet changed the velocity fit.
      if(frame.observation.targetGrounded)s.airPastInterrupt=false
      else if(frame.airPlan.risingTail||frame.targetVelocity.y<=0)s.airPastInterrupt=true
      if(s.airPastInterrupt&&frame.observation.targetAirborne)frame.airPlan.risingTail=true
      // Keep avoidance active through the observed landing. A single safe
      // stale sample must not cancel a dodge immediately before the crit.
      if(s.airDefense&&frame.observation.targetAirborne&&frame.airPlan.valid&&!frame.airPlan.threat){
        frame.airPlan.threat=true
        frame.airPlan.action=frame.airPlan.route?.safe?'dodge':'no-guaranteed-route'
        frame.airPlan.holdReason='await-observed-landing'
      }
      // A delayed velocity update cannot reopen an interrupt after its safe
      // ascent window. Keep the action consistent with the latched phase;
      // merely setting risingTail while leaving action=interrupt bypasses
      // the safe-dodge arbitration below.
      if(s.airPastInterrupt&&frame.airPlan.action==='interrupt'){
        frame.airPlan.action=frame.airPlan.route?.safe?'dodge':'no-guaranteed-route'
        frame.airPlan.holdReason='interrupt-window-already-ended'
      }
      s.airDefense=frame.airPlan.threat&&!frame.observation.targetGrounded
      frame.shortAdvance=frame.airPlan.threat?null:computed?computed.shortAdvance:planShortAdvance(frame,probe)
      const input=publicInput(s,frame,tick,!preview)
      if(preview)input.command='preview'
      const started=performance.now(),result=await send(input)
      if(isCurrent&&!isCurrent()||baseStateVersion!==(liveState.decisionVersion||0))return null
      const p=originalPlan(result,frame,tick),c=p.command,o=frame.observation
      const baseCommand=structuredClone(c)
      p.originalCommand=baseCommand
      p.runtimeMs=performance.now()-started;p.airPlan=frame.airPlan
      p.selectedBranch='original86:'+result.phase
      if(result.counterHopActive)s.hadHop=true
      if(s.hadHop&&!result.counterHopActive&&frame.self.ground)s.swordOnly=true
      s.wasHop=result.counterHopActive
      s.closeFight=closeFightIntent(s,frame,tick)
      p.contactTiming={directContact,reach:o.reach,opponentAgeMs:frame.latency?.observationAgeMs??null}
      if(s.swordOnly&&!s.wasHop&&!frame.self.shieldAvailable)c.slot=0
      if(result.hasPendingAttack)c.attack=false
      if(s.swordOnly&&!s.wasHop&&(!frame.self.shieldAvailable||s.closeFight)&&(!c.shield||s.closeFight)&&!c.ranged&&!o.arrowThreat&&(!frame.airPlan.threat||s.closeFight)){
        c.slot=0
        if(o.visible&&o.reach<=3&&o.targetShieldFacing&&o.targetShieldRaised){
          if(!s.stun&&tick-s.lastStunAt>=6){s.stun={id:++s.stunSerial,stage:'double',at:tick};s.lastStunAt=tick}
          if(s.stun?.stage==='double'){
            c.slot=7;c.attack=true;c.critical=false;c.kind='legacy86-stun';c.stunId=s.stun.id
            c.doubleAttack=true;c.jump=Boolean(s.closeFight);c.aimAway=false;c.shield=false;c.ranged=null
            p.selectedBranch='sword-contact-stun-double'
          }
        }else if(s.stun?.stage==='return'||s.stun&&tick-s.stun.at>3){s.stun=null;c.slot=0}
      }
      const trappedContact=resolveContact(frame,s.wasHop)
      const safeAirEvasion=Boolean(frame.airPlan.threat&&frame.airPlan.action==='dodge'&&frame.airPlan.route?.safe)
      if(!s.wasHop&&!s.closeFight&&frame.airPlan.threat&&c.kind!=='legacy86-stun'
          &&result.phase==='AIR_INTERRUPT'&&frame.airPlan.action!=='interrupt'){
        c.attack=c.doubleAttack=false
      }
      const originalPrecisionStrike=c.attack&&(['ACTIVE_STRIKE','COMBO_EDGE'].includes(result.phase)
        ||directContact&&frame.self.ground&&o.targetGrounded)
      if(!s.closeFight&&c.attack&&frame.self.ground&&o.targetGrounded
          &&['PRESSURE_STRIKE','ACTIVE_STRIKE','COMBO_EDGE','ENTRY_HIT','LAND_PUNISH'].includes(result.phase)){
        c.attackRole='spacing';c.requestedReachBand=[2.90,3]
      }
      if(!s.wasHop&&!s.closeFight&&!frame.self.shieldAvailable&&!c.shield&&!c.ranged&&!o.arrowThreat&&o.visible&&!trappedContact&&!originalPrecisionStrike){
        const air=frame.airPlan,advancing=['ACTIVE_ADVANCE','COMBO_TRACK'].includes(result.phase)&&frame.shortAdvance?.available
        const movement=advancing?frame.shortAdvance:air.threat&&air.route?air.route:!o.targetAirborne
          ?computed?computed.spacing:planSpacing(frame,probe):null
        const heading=movement?.heading
        if(heading&&(!air.threat||air.action!=='interrupt'||!c.attack)){
          c.worldHeading=heading;c.aimAway=false;c.sprint=movement.sprint
          if(air.threat)c.airDodgeUrgent=true
          p.selectedBranch=advancing?'original86-precision-advance':air.threat?'air-threat-route':'ground-sword-spacing'
          if(advancing)c.precisionApproach=true
          else if(!air.threat){p.spacingPlan=movement;c.spacingUrgent=movement.imminent}
          if(safeAirEvasion){c.attack=false;c.jump=false}
        }
      }
      // Restore protection before any lower-priority stun/spacing command.
      if(frame.self.shieldAvailable&&!s.closeFight&&frame.airPlan.threat&&!o.arrowThreat){
        Object.assign(c,{shield:true,attack:false,doubleAttack:false,jump:false,sprint:false,
          ranged:null,offhand:'shield',slot:frame.self.held,worldHeading:null,aimAway:false})
        p.selectedBranch='guard-air-threat'
      }else if(!o.arrowThreat&&!frame.airPlan.threat&&result.phase==='ORBIT_BURST'){
        if(!s.orbitGoal||s.lastPhase!=='ORBIT_BURST')s.orbitGoal=orbitGoal(o.targetYaw??0,result.movementAction===4)
        c.worldHeading=orbitHeading(frame.self,frame.seen,s.orbitGoal)
        c.sprint=true;c.aimAway=false;p.selectedBranch='original86-orbit-route'
      }
      if(safeAirEvasion&&(frame.airPlan.risingTail||frame.airPlan.jumpResetPossible)&&!c.shield&&!trappedContact&&!s.closeFight){
        c.attack=c.doubleAttack=false;c.jump=false
        if(!frame.airPlan.route){c.forward=c.side=0;c.worldHeading=null;c.sprint=false}
        p.selectedBranch=frame.airPlan.route?'evade-punishment-window':'no-safe-punishment-route'
      }
      if(trappedContact&&!s.closeFight){
        // One coherent contact command: retain the original attack/jump choice
        // rather than mixing its attack timing with an impossible retreat.
        Object.assign(c,baseCommand,{slot:0,shield:false,offhand:'shield',ranged:null,
          worldHeading:null,aimAway:false,keepLook:false})
        delete c.arrowYaw
        if(!o.targetShieldFacing&&frame.self.charge>=.9){c.attack=true;c.critical=Boolean(frame.self.critical)}
        p.selectedBranch='contact-escape-unavailable'
      }
      if(s.closeFight){
        if(c.kind!=='legacy86-stun')Object.assign(c,closeFightCommand(s,frame,tick))
        delete c.arrowYaw
        p.selectedBranch=c.kind==='legacy86-stun'?'close-sword-stun-double':c.intent
        p.closeFight={...s.closeFight}
      }
      // GUARD_CLOSE can also emit the original back-opening strike. A
      // phase-name-only ORBIT_BACK gate missed these attacks at the shield's
      // side plane. Require the same confirmed rear for every shield opening.
      if(c.attack&&!['legacy86-stun','legacy86-counter'].includes(c.kind)&&o.targetShieldRaised
          &&!confirmedRear(frame.self,o.sentPosition,frame.seen,o.targetYaw)){
        c.attack=c.doubleAttack=false
        if(frame.self.shieldAvailable){
          Object.assign(c,{shield:true,offhand:'shield',ranged:null,forward:0,side:0,
            sprint:false,jump:false,worldHeading:null,aimAway:false})
        }
        p.selectedBranch='shield-opening-not-confirmed'
      }
      s.lastPhase=result.phase
      if(o.arrowThreat){
        const canShield=frame.self.shielding||frame.self.shieldAvailable
          &&o.arrowThreat.time>=(o.offhandShieldReady?5:6)
        Object.assign(c,{attack:false,doubleAttack:false,ranged:null,jump:false,
          slot:frame.self.held,worldHeading:null,aimAway:false,keepLook:!canShield,
          shield:canShield,offhand:'shield',forward:0,side:canShield?0:o.arrowThreat.side||0,
          sprint:false,arrowYaw:canShield?o.arrowThreat.yaw:undefined})
        p.selectedBranch=canShield?'guard-arrow':'dodge-arrow'
      }
      const ranged=syncRanged(s,frame,c,{emergency:Boolean(frame.airPlan.threat||s.closeFight),mode:result.phase==='COUNTER'?'COUNTER':'LEGACY86'})
      if(ranged){Object.assign(c,ranged);p.selectedBranch='sync-ranged:'+ranged.rangedReason}
      // Sword ownership begins at the hop boundary, even if an offhand sync
      // arrived before the first axe->sword slot packet was emitted. Loading
      // cannot freeze the previous axe in that transition frame.
      if(result.counterHopActive){
        c.slot=0;c.doubleAttack=false
        if(frame.self.held!==0&&c.ranged){
          c.ranged=null;c.rangedRelease=false;c.offhand='shield'
          if(s.rangedSync){s.rangedSync.ranged=null;s.rangedSync.rangedPhase=null}
          p.selectedBranch='counter-hop-equip-sword-before-offhand-sync'
        }
      }
      if(!o.visible||o.reach>3)c.attack=c.doubleAttack=false
      // One successful strike is not a new low-charge attack opportunity in
      // the very next tick. Preserve explicit stun pairs and real counters.
      if(c.attack&&!['legacy86-stun','legacy86-counter'].includes(c.kind)
          &&age(tick,s.lastAttempt)<3&&frame.self.charge<.2)c.attack=c.doubleAttack=false
      if(s.pending.size)c.attack=c.doubleAttack=false
      p.baseStateVersion=baseStateVersion
      p.statePatch=Object.fromEntries(decisionFields.map(k=>[k,s[k]]))
      p.commandChanges=Object.fromEntries(Object.keys(c).filter(k=>JSON.stringify(c[k])!==JSON.stringify(baseCommand[k]))
        .map(k=>[k,{original:baseCommand[k]??null,resolved:c[k]??null}]))
      if(!transactional&&!commitDecision(liveState,p))return null
      return p
    },
    applied(s,c,actual,tick){
      if(actual.switched&&actual.held===7)void runtime.callback('axeEquipped',tick).catch(onError)
      if(actual.controls.jump&&!s.jumpHeld)void runtime.callback('jumpInputSubmitted',tick).catch(onError)
      s.jumpHeld=actual.controls.jump
      if(actual.attacked){
        s.lastAttempt=tick
        for(const attempt of actual.attacks||[{id:actual.executedAttackId}]){
          const original=!['legacy86-stun','legacy86-close'].includes(c.kind)
          s.pending.set(attempt.id,{tick,original,counter:c.kind==='legacy86-counter'&&tick<s.shieldUntil})
          if(original)void send({command:'attempt',id:attempt.id,tick,phase:c.phase,counter:c.kind==='legacy86-counter'&&tick<s.shieldUntil}).catch(()=>{})
        }
        if(c.kind==='legacy86-stun'&&s.stun)s.stun.stage='return'
        if(s.closeFight&&c.kind==='legacy86-close'){
          s.closeFight.firstHitDone=true;s.closeFight.afterStunAt=null
        }
        if(s.closeFight&&c.kind==='legacy86-stun')s.closeFight.afterStunAt=tick
      }
    },
    rangedApplied,close:()=>runtime.close(),publicInput,originalPlan}
}
module.exports={createBrain,createState,publicInput,originalPlan}
