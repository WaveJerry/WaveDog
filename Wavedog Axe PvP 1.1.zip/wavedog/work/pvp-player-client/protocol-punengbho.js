'use strict'
const fs = require('node:fs'), path = require('node:path'), net = require('node:net')
const crypto = require('node:crypto')
const mineflayer = require('mineflayer'), { Vec3 } = require('vec3')
const hybridEnabled=process.env.PUNENGBHO_CONTROL_MODE==='hybrid'
const legacyEnabled=process.env.PUNENGBHO_CONTROL_MODE==='legacy86'
const highRateMode=process.env.PUNENGBHO_HIGH_RATE_MODE||'off'
if(!['off','shadow','control'].includes(highRateMode)||hybridEnabled&&highRateMode!=='off')
  throw Error('High-rate whole-model path requires pure control mode')
if(legacyEnabled&&highRateMode!=='control')throw Error('Direct 8.6 requires its explicit high-rate control profile')
const {monoMs}=require('./protocol-high-rate-loop')
const {monitorEventLoopDelay}=require('node:perf_hooks')
const eventLoopDelay=monitorEventLoopDelay({resolution:10});eventLoopDelay.enable()
let realtimeScheduling=false
if(legacyEnabled){
  const os=require('node:os')
  try{os.setPriority(0,os.constants.priority.PRIORITY_HIGH);realtimeScheduling=true}catch{}
}
const controlRegime=legacyEnabled?'original86-single-controller-with-public-threat-prediction'
  :hybridEnabled?'pilot-mechanical-shield-neural-melee':'pure-model-all-input'
const routePlanner=legacyEnabled?require('./protocol-legacy86-planner').createRoutePlanner({
  onError:error=>{log('route-planner-error',{error:String(error)});modelReady=false;if(session?.active){session.invalid=true;bot?.clearControlStates()}}
}):null
const brain = legacyEnabled?require('./protocol-legacy86-brain').createBrain({planner:routePlanner,onError:error=>{
  log('legacy86-runtime-error',{error:String(error)});modelReady=false
  if(session?.active){session.invalid=true;bot?.clearControlStates()}
}}):require(hybridEnabled?'./protocol-pilot-hybrid-brain':'./protocol-pure-brain')
const mechanicalEnabled=hybridEnabled||legacyEnabled
const {createFrameClock}=require('./protocol-frame-clock')
const {createDecisionDispatch}=require('./protocol-decision-dispatch')
const {recoverPositionCorrection}=require('./protocol-correction-recovery')
const {observeRanged,projectileShooterId}=require('./protocol-ranged-observation')
const {observeBowUse,noteBowShot}=mechanicalEnabled?require('./protocol-pilot-bow-observation'):{}
const {executeCommand}=require(legacyEnabled?'./protocol-legacy86-executor':hybridEnabled?'./protocol-pilot-hybrid-executor':'./protocol-pure-executor')
const {attackCharge}=require('./protocol-attack-charge')
const {createPilotChargeObserver}=require('./protocol-pilot-charge')
const {createOpeningControlTracker}=require('./opening-control-feedback')
const {requestOffhandSwap}=require('./protocol-offhand-swap')
const {createPublicHealthTracker}=require('./protocol-public-health')
const {nearestHitPointExact:nearestHitPoint,currentViewPacket,immediateLook}=require('./protocol-mechanical-math')
const {damageFeedback,swingFeedback,hungerFeedback}=require('./attack-reward')
const {forecast,forecastFloor,observeMotion}=require('./protocol-airborne-guard')
const { publicArrowThreat } = require('./wavedog-arrow-predictor')
const { bowSpeed, plannedBowDrawMs, solvePitch, leadTarget } = require('./ballistic-aim')
const {solveRangedAim}=mechanicalEnabled?require('./protocol-ranged-aim'):{}
const root = path.resolve(__dirname, '../..')
const runtime = path.join(root, 'work/wavedog-punengbho/runtime')
const playerName='WaveDog'
fs.mkdirSync(runtime, { recursive: true })
const tokenFile = 'D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PunengbhoProtocolCore/client-token.txt'
const channel = 'punengbho:control'
let controlToken=fs.existsSync(tokenFile)?fs.readFileSync(tokenFile,'utf8').trim():null
// Reuse the existing WaveDog login; the independent model identity stays
// Punengbho so historical trajectories and optimizer state remain separate.
const credential = path.join(root,'work/wavedog-protocol/runtime/auth.json')
if (!fs.existsSync(credential)) fs.writeFileSync(credential,
  JSON.stringify({ password: crypto.randomBytes(20).toString('hex') }))
const password = JSON.parse(fs.readFileSync(credential)).password
const journal=require('./protocol-async-journal').createAsyncJournal({onError:error=>{
  console.error('Journal persistence failed:',error.code||error.name)
  modelReady=false;if(session?.active){session.invalid=true;bot?.clearControlStates()}
}})
const log = (type, row = {}) => journal.append(path.join(runtime, 'client-events.jsonl'),
  JSON.stringify({ at: new Date().toISOString(), type, ...row }) + '\n')
const rangedLearning=mechanicalEnabled?require('./protocol-pilot-ranged-learning').createRangedLearning({root,runtime,log}):null
let rangedCalibration=rangedLearning?.profile()||null
let bot, socket, publicHealth, modelReady = false, policySha, session, tick = 0, requestId = 0
let modelBuffer = '', latest, use = null, switching = false, lastSwing = -1000
let authAt = 0, shieldUntil = 0, lastHeartbeat = 0, closing = false
let nativeSelf = null, lastAttackTick = -1000, lastSentPosition=null
let weaponEpoch=0
let highRateAnchorTick=null,motionRevision=0,highRateFrame=null,modelConfig=null
const refinementPending=new Map()
let legacyFrame=null,legacyPending=0,legacyRevision=0,legacyEpoch=0,legacyLastEffect=null
let legacyAnalyzedKey=null
let legacyProbe=null,legacyProbeKey=null,legacyCollisionRevision=0,lastLegacyCapture=null
const legacyBlocks=legacyEnabled?require('./protocol-legacy86-collision-cache').createCollisionCache({
  blockAt:(x,y,z)=>bot.blockAt(new Vec3(x,y,z),false)
}):null
const legacyMotion=legacyEnabled?new(require('./protocol-high-rate-motion').PublicMotionMonitor)():null
let legacyPacketTimes=[],legacyPeakPacketRate=0
const legacyOutput=legacyEnabled?require('./protocol-legacy86-output-gate').createOutputGate():null
const legacyStats={cycles:0,decisions:0,coalesced:0,applied:0,stale:0,missedDeadlines:0,heldFrames:0,decisionMs:[]}
const legacyLoop=legacyEnabled?require('./protocol-high-rate-loop').createHighRateLoop({hz:500,
  onCycle:analysis=>{legacyStats.cycles=analysis.cycles;legacyStats.missedDeadlines=analysis.missedDeadlines;
    legacyStats.monitorHz=analysis.measuredHz;legacyStats.monitorDeliveries=analysis.deliveries;
    legacyStats.monitorTargetHz=analysis.targetHz;legacyStats.monitorMaxIntervalMs=analysis.maxIntervalMs;
    legacyStats.monitorMaxLatenessMs=analysis.maxLatenessMs;legacyStats.monitorRecentMisses=analysis.recentMisses;
    void legacyFastCycle(analysis)},
  onError:error=>log('legacy86-loop-error',{error:String(error)})}):null
const highRate=highRateMode==='off'||legacyEnabled?null:require('./protocol-high-rate-controller').createHighRateController({
  control:highRateMode==='control',
  context:analysis=>session?.active&&modelReady&&highRateAnchorTick===tick&&highRateFrame?.tick===tick
    &&analysis?.physicalTick===tick?{matchId:session.id,tick}:null,
  infer:token=>new Promise((resolve,reject)=>{
    const target=bot.players[session.opponent]?.entity,frame=publicFrame(target,true)
    const req={...highRateFrame.request,command:'refine',requestId:++requestId,
      self:frame.self,seen:frame.seen,publicActionContext:frame.observation,
      publicTerrain:frame.publicTerrain,publicMotionAnalysis:token.analysis,
      controlRevision:token.revision,observationRevision:token.observationRevision}
    const timeout=setTimeout(()=>{refinementPending.delete(req.requestId);reject(Error('Refinement response timed out'))},100)
    refinementPending.set(req.requestId,{resolve,reject,timeout,weaponEpoch})
    if(!model(req)){clearTimeout(timeout);refinementPending.delete(req.requestId);resolve(null)}
  }),
  apply:(command,evidence)=>{
    if(!session?.active||command.baseTick!==tick||evidence.analysis.physicalTick!==tick)return
    const target=bot.players[session.opponent]?.entity,frame=publicFrame(target,true)
    const planned=brain.plan(session.state,frame.observation,command),actual=execute(planned,frame,target)
    const row=session.frames.at(-1)
    if(row)(row.subtickActions??=[]).push({atMs:monoMs(),revision:evidence.revision,
      sourceRevision:evidence.analysis.revision,command,actual,ppoEligible:false})
  },
  onTrace:row=>{
    if(row.type==='model-refinement'&&session?.active){
      const frame=session.frames.at(-1)
      if(frame)(frame.subtickDecisions??=[]).push(row)
    }
  },
  onError:error=>{log('high-rate-error',{error:String(error)});if(session?.active)session.invalid=true}
})
const requestContexts = new Map()
const chargeObserver=createPilotChargeObserver()
let chargeDiagnostic=null
const bowCancellation=mechanicalEnabled?require('./protocol-pilot-use').createBowCancellation({
  getBot:()=>bot,getTick:()=>tick,getNative:()=>nativeSelf,isSwitching:()=>switching,
  swapItem:item=>swapOffhandItem(item),
  onEvent:(phase,row)=>log('bow-cancel-'+phase,{matchId:session?.id,...row})
}):null
const sourceSha256 = Object.fromEntries(['protocol-punengbho.js','protocol-pure-brain.js',
  'protocol-high-rate-loop.js','protocol-high-rate-controller.js','protocol-high-rate-worker.js','protocol-high-rate-motion.js','protocol-precision-wait.js','protocol-async-journal.js',
  'protocol-pure-executor.js','protocol-decision-dispatch.js','protocol-correction-recovery.js','protocol-attack-charge.js','protocol-pilot-charge.js','opening-control-feedback.js','protocol-offhand-swap.js','protocol-public-health.js','protocol-frame-clock.js','protocol-ranged-observation.js','protocol-frame-store.js','attack-reward.js','protocol-mechanical-math.js','protocol-airborne-guard.js','wavedog-arrow-predictor.js','ballistic-aim.js',
  ...(hybridEnabled?['protocol-pilot-hybrid-brain.js','protocol-pilot-hybrid-executor.js','protocol-pilot-mechanical-brain.js','protocol-pilot-mechanical-executor.js','protocol-ranged-aim.js','protocol-pilot-ranged-learning.js','protocol-pilot-use.js','protocol-pilot-bow-observation.js']:[]),
  ...(legacyEnabled?['protocol-legacy86-planner.js','protocol-legacy86-planner-worker.js','protocol-legacy86-collision-cache.js','protocol-legacy86-output-gate.js','protocol-legacy86-brain.js','protocol-legacy86-runtime.js','protocol-legacy86-threat.js',
    'protocol-legacy86-executor.js','protocol-legacy86-route.js','protocol-legacy86-ranged.js','protocol-pilot-mechanical-executor.js','protocol-ranged-aim.js',
    'protocol-pilot-ranged-learning.js','protocol-pilot-use.js','protocol-pilot-bow-observation.js']:[])]
  .map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,name))).digest('hex')]))
const controllerCode=crypto.createHash('sha256').update(JSON.stringify(sourceSha256)).digest('hex')
const awaitingTraining = new Map(), execution = new Map()
const frameClock=createFrameClock(physics)
const decisionDispatch=createDecisionDispatch(settleDecisionFrame)
function model (row) {
  if (!socket || socket.destroyed || !modelReady) return false
  socket.write(JSON.stringify(row) + '\n'); return true
}
function plugin (row) {
  if (!bot?._client || bot._client.state !== 'play' || !controlToken) return
  bot._client.write('custom_payload', { channel,
    data: Buffer.from(JSON.stringify({ ...row, token: controlToken })) })
}
function modelConnect () {
  socket = net.connect(18776, '127.0.0.1'); modelBuffer = ''
  socket.setNoDelay(true)
  socket.setEncoding('utf8')
  socket.on('data', data => {
    modelBuffer += data
    for (let n; (n = modelBuffer.indexOf('\n')) >= 0;) {
      const line = modelBuffer.slice(0,n); modelBuffer = modelBuffer.slice(n+1)
      try { onModel(JSON.parse(line)) } catch (e) { log('model-message-error', { error: String(e) }) }
    }
  })
  socket.on('error', e => log('model-connection-error', { error: e.code }))
  socket.on('close', () => {
    if(!legacyEnabled)modelReady = false
    latest = null
    if (!legacyEnabled&&session?.active) { session.invalid = true; log('model-disconnect-during-bout', { matchId: session.id }) }
    if (!closing) setTimeout(modelConnect, 2000)
  })
}
function onModel (row) {
  if(legacyEnabled){
    // Qwen may review persisted teacher trajectories, but no neural action or
    // PPO receipt may own a control channel in this direct-logic mode.
    if(row.event==='review_saved'){plugin({type:'reviewed',matchId:row.matchId});log('qwen-review-saved',row)}
    return
  }
  if(row.event==='refined_action'||row.event==='refinement_rejected'){
    const pending=refinementPending.get(row.requestId)
    if(pending){clearTimeout(pending.timeout);refinementPending.delete(row.requestId)
      pending.resolve(row.event==='refined_action'?{...row,observedWeaponEpoch:pending.weaponEpoch}:null)}
    return
  }
  if (row.event === 'transport_ready' || row.event === 'ready') {
    modelReady = row.modelReady !== false
    model({ command: 'model_status', requestId: 'Punengbho-connect' })
  }
  if (row.event === 'model_status') {
    modelReady = row.ready; policySha = row.checkpointSha256
    modelConfig=row.config
    if(highRate&&!(modelConfig?.wholeFightControlVersion===1&&modelConfig.sameTickRefinementVersion===1
        &&modelConfig.publicMotionInputs===32&&modelConfig.behaviorPriorVersion===0
        &&modelConfig.trainingStage==='behavior-cloning')){
      modelReady=false;log('high-rate-checkpoint-rejected',{reason:'Requires trained whole-fight BC checkpoint'})
    }
    fs.writeFileSync(path.join(runtime, 'model-status.json'), JSON.stringify(row, null, 2))
  }
  if (row.fighter === 'Punengbho' && row.model === 'DUAL-GRU-GTRXL') {
    const context=requestContexts.get(row.requestId);requestContexts.delete(row.requestId)
    if (session?.active && context?.matchId===session.id && row.opponent === session.opponent
        && row.decidedTick === context.tick && row.decidedTick >= session.startTick) {
      row.responseMs=performance.now()-context.requestedAt
      row.observedWeaponEpoch=context.weaponEpoch
      if (!latest || row.decidedTick > latest.decidedTick) latest = row
      policySha = row.checkpointSha256
      highRateAnchorTick=row.decidedTick
      session.inferences++
      decisionDispatch.reply(row, session.id, tick)
    }
  }
  if (row.fighter === 'Punengbho' && ['trained','trained_partial','training_error','evaluation_saved'].includes(row.event)) {
    const old = awaitingTraining.get(row.round)
    if (!old) return
    // Persist the training receipt before reopening the next-match gate.
    fs.writeFileSync(path.join(runtime, old.id + '-training.json'), JSON.stringify(row, null, 2))
    if(row.event==='evaluation_saved'){
      log('frozen-evaluation-saved',{matchId:old.id,...row})
    } else if (row.event === 'training_error') {
      plugin({ type: 'learning_error', matchId: old.id, reason: row.error })
    } else if(row.quarantined) {
      plugin({type:'learning_error',matchId:old.id,reason:'Trajectory saved; PPO update rejected: '+row.reasons.join(', ')})
    } else {
      const manifest = JSON.parse(fs.readFileSync(path.join(root, 'work/wavedog-punengbho/model/checkpoint.json')))
      policySha = manifest.sha256
      plugin({ type: 'merged', matchId: old.id, sha256: policySha, persisted:true })
    }
    // A quarantined PPO trajectory still deserves analysis of why it failed.
    if(row.event!=='training_error')model({command:'review',matchId:old.id,fighter:'Punengbho',
      opponent:old.opponent,outcome:old.outcome,frames:old.frames})
    log('training-receipt', { matchId: old.id, ...row })
    awaitingTraining.delete(row.round)
  }
  if (row.event === 'review_saved') {
    plugin({ type: 'reviewed', matchId: row.matchId }); log('qwen-review-saved', row)
  }
  if (['error','service_error','training_error','model_not_ready'].includes(row.event)) {
    log('model-error', row)
    if (row.event === 'service_error' || row.event === 'model_not_ready') modelReady = false
  }
}
function stopUse (releaseBow=false) {
  if(bowCancellation?.pending()){
    bowCancellation.poll();use=null;return
  }
  if(mechanicalEnabled){
    const kind=use?.kind,result=require('./protocol-pilot-use').endUse(bot,use,releaseBow,()=>bowCancellation.begin())
    if(session?.active&&kind==='bow')log('bow-use-ended',{matchId:session.id,tick,releaseBow,...result})
  }
  else if (use || bot.usingHeldItem) bot.deactivateItem()
  use = null
}
function swapOffhandItem(item){
  switching=true
  const currentBot=bot
  let swap
  try{swap=requestOffhandSwap(currentBot,item)}catch(error){switching=false;throw error}
  swap.completion.catch(e=>log('inventory-error',{error:String(e)}))
    .finally(()=>{switching=false})
  if(swap.ready){switching=false;return true}
  return false
}
function offhand (wanted) {
  if(bowCancellation&&!bowCancellation.poll())return false
  if (switching) return false
  const current = bot.inventory.slots[45]
  if (current?.name === wanted) return true
  if (!switching) {
    const item = bot.inventory.items().find(i => i.name === wanted)
    if (!item) return false
    stopUse()
    if(bowCancellation?.pending())return false
    return swapOffhandItem(item)
  }
  return false
}
function loaded (item) {
  if (!item) return false
  const data = item.componentMap?.get('charged_projectiles')?.data
  const projectiles = Array.isArray(data) ? data : data?.projectiles
  if (projectiles?.some(p => (p.itemCount ?? p.count ?? 0) > 0)) return true
  const c = item.components?.find(c => c.type === 'charged_projectiles' || c.type === 'minecraft:charged_projectiles')
  return Boolean(c?.data?.projectiles?.length || c?.data?.items?.length
    || item.nbt?.value?.Charged?.value || item.nbt?.value?.ChargedProjectiles?.value?.value?.length)
}
function ownLoaded () { return bot.inventory.slots.some(i => i?.name === 'crossbow' && loaded(i)) }
function charge (slot = bot.quickBarSlot) {
  chargeDiagnostic=chargeObserver.read({tick,lastSwing,slot,nativeSelf})
  return chargeDiagnostic.value
}
function clearPath (a, b) {
  const delta = new Vec3(b.x-a.x,b.y-a.y,b.z-a.z), length = delta.norm()
  return length < .001 || !bot.world.raycast(new Vec3(a.x,a.y,a.z),delta.scaled(1/length),length)
}
function eyeBox (eye, feet, height = 1.8) {
  return Math.hypot(Math.max(0,Math.abs(eye.x-feet.x)-.3),
    Math.max(0,feet.y-eye.y,eye.y-feet.y-height),Math.max(0,Math.abs(eye.z-feet.z)-.3))
}
function wall (x,z) {
  const p = bot.entity.position, hit = bot.world.raycast(p.offset(0,.9,0),new Vec3(x,0,z),8)
  return hit?.intersect ? p.offset(0,.9,0).distanceTo(hit.intersect) : 8
}
function observeVisibleBow(target){
  if(!mechanicalEnabled||!session||!bot?.entity||!target)return {}
  const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0),p=target.position
  const visible=bot.entity.position.distanceTo(p)<64
    &&(clearPath(eye,p.offset(0,1.3,0))||clearPath(eye,p.offset(0,.6,0)))
  const flags=Number(target.metadata?.[8]||0)
  return observeBowUse(session,{visible,using:Boolean(flags&1),
    activeItem:target.equipment?.[flags&2?1:0]},tick)
}
function publicFrame (target,refining=false) {
  const e = bot.entity, p = e.position, v = e.velocity, eye = p.offset(0,e.eyeHeight || 1.62,0)
  const flags = Number(target?.metadata?.[8] || 0)
  const targetItem = flags & 2 ? target?.equipment?.[1] : target?.equipment?.[0]
  const using = Boolean(flags & 1), isShield = using && targetItem?.name === 'shield'
  const tp = target?.position, visible = Boolean(target && p.distanceTo(tp) < 64
    && (clearPath(eye,tp.offset(0,1.3,0)) || clearPath(eye,tp.offset(0,.6,0))))
  const targetFloor=visible?bot.world.raycast(tp.offset(0,.1,0),new Vec3(0,-1,0),16):null
  const motion=refining?session.targetMotion:visible?observeMotion(session.targetMotion,{x:tp.x,y:tp.y,z:tp.z,
    grounded:target.publicGrounded,floorY:targetFloor?.intersect?.y},tick):null
  if(motion&&!refining)session.targetMotion=motion
  const motionEstimate=legacyMotion?.body(legacyMotion.bodies.opponent,monoMs())
  if(motion&&tp&&motionEstimate?.velocityKnown&&Math.hypot(motionEstimate.observed.x-tp.x,
      motionEstimate.observed.y-tp.y,motionEstimate.observed.z-tp.z)<.001){
    Object.assign(motion,{vx:motionEstimate.velocity.x,vy:motion.grounded?0:motionEstimate.velocity.y,
      vz:motionEstimate.velocity.z,velocitySource:'public-packet-arrival-interval'})
  }
  const targetVelocity=motion?{x:motion.vx,y:motion.vy,z:motion.vz}:{x:0,y:0,z:0}
  if (isShield && !session.targetShieldAt) session.targetShieldAt = tick
  if (!isShield) session.targetShieldAt = 0
  const effective = isShield && tick-session.targetShieldAt >= 5
  const targetForward = target ? new Vec3(-Math.sin(target.yaw),0,-Math.cos(target.yaw)) : new Vec3(0,0,0)
  const towardSelf = tp ? p.minus(tp) : new Vec3(0,0,0)
  const facing = Boolean(effective && targetForward.dot(towardSelf) > 0)
  const arrows = Object.values(bot.entities).filter(a => /^(arrow|spectral_arrow)$/.test(a.name || '')
    && a.position.distanceTo(p)<32 && clearPath(eye,a.position)).map(a => ({ id:a.id,
    x:a.position.x,y:a.position.y,z:a.position.z,vx:a.velocity?.x||0,vy:a.velocity?.y||0,vz:a.velocity?.z||0,
    shooterId:a.publicShooterId }))
  const own = nativeSelf && tick-nativeSelf.receivedTick<=3 ? nativeSelf : null
  // moveSlotItem briefly holds the replaced stack on the inventory cursor.
  // That is not a shield break and must not transfer the base combat state.
  const hasShield=bot.inventory.slots.some(i=>i?.name==='shield')
    ||bot.inventory.selectedItem?.name==='shield'||Boolean(switching&&session.hasShield)
  if(!switching)session.hasShield=hasShield
  const self = { x:p.x,y:p.y,z:p.z,eyeY:eye.y,vx:v.x,vy:v.y,vz:v.z,
    ground:e.onGround, critical:!e.onGround && lastSentPosition?.falling===true && !e.isInWater && !e.isInLava,
    charge:charge(),chargeObservation:chargeDiagnostic, health:bot.health,food:bot.food,
    sprint:bot.getControlState('sprint'),attackAgeTicks:tick-lastAttackTick,
    weaponAgeTicks:session.lastWeaponSwitchTick===undefined?1000:tick-session.lastWeaponSwitchTick,
    wireFalling:lastSentPosition?.falling??false,wireGround:lastSentPosition?.onGround??null,
    fallDistance:own?.fallDistance,
    shieldAvailable:(own ? own.shieldCooldown===0 : tick>=shieldUntil) && hasShield&&(!legacyEnabled||tick>=shieldUntil),
    shielding:Boolean(own?.shielding && own.using && own.activeItem==='SHIELD'
      && own.useTicks>=5 && use?.kind==='shield' && tick-use.tick>=5),
    arrows:bot.inventory.items().filter(i=>i.name==='arrow').reduce((s,i)=>s+i.count,0),
    crossbowLoaded:ownLoaded(),hasBow:bot.inventory.slots.some(i=>i?.name==='bow'),
    hasCrossbow:bot.inventory.slots.some(i=>i?.name==='crossbow'),
    using:own ? own.using : Boolean(use),useTicks:own ? own.useTicks : use?tick-use.tick:0,held:bot.quickBarSlot,
    ...(mechanicalEnabled?{inventoryObservation:{hasShield,switching,
      cursor:bot.inventory.selectedItem?.name||null,
      items:bot.inventory.slots.flatMap((i,slot)=>i&&['shield','bow','crossbow'].includes(i.name)
        ?[{slot,name:i.name,count:i.count,loaded:i.name==='crossbow'?loaded(i):null}]:[])}}:{}) }
  const seen = visible ? { visible:true,x:tp.x,y:tp.y,z:tp.z,yaw:180-target.yaw*180/Math.PI,
    shield:effective,shieldRaised:isShield,held:(target.equipment?.[0]?.name||'UNKNOWN').toUpperCase(),using,
    swing:session.swingAt||0,arrows } : { visible:false,arrows }
  const rangedObserved=observeRanged(session,{tick,visible,using,activeItem:targetItem,
    mainhand:target?.equipment?.[0],offhand:target?.equipment?.[1],fired:session.targetFired},loaded)
  if(!refining)session.targetFired=false
  const {targetBow,targetLoading}=rangedObserved
  const threat = publicArrowThreat(arrows,{...self,entityId:e.id,yaw:e.yaw,ceilingClear:!bot.blockAt(p.offset(0,2.8,0))?.boundingBox?.includes('block')},wall,clearPath)
  if (threat) {
    const a = arrows.find(a=>a.id===threat.id)
    threat.yaw = Math.atan2(-(a.x-p.x),-(a.z-p.z))
  }
  const floor = bot.world.raycast(p.offset(0,.1,0),new Vec3(0,-1,0),8)
  const terrain = { selfY:p.y,groundY:floor?.intersect?.y ?? p.y,
    walls:[wall(-1,0),wall(1,0),wall(0,-1),wall(0,1)] }
  const reach = visible ? eyeBox(eye,tp,target.height || 1.8) : Infinity
  const otherReach = visible ? eyeBox(tp.offset(0,1.62,0),p,e.height || 1.8) : Infinity
  const distance = visible ? p.distanceTo(tp) : Infinity
  if(visible)seen.publicHealth=publicHealth?.observe(session.opponent,true,distance)||null
  let airEnvelope=null
  if(visible&&motion&&!motion.grounded){
    const body={x:tp.x,y:tp.y,z:tp.z,vx:motion.vx,vy:motion.vy,vz:motion.vz,
      eye:target.eyeHeight||1.62,halfX:(target.width||.6)/2,halfZ:(target.width||.6)/2,
      height:target.height||1.8,grounded:false}
    const steering=.0196*1.3 // Original sprint-capable bound; opponent food is private.
    const floor=forecastFloor(body,steering,bot.game.minY??-64,(x,y,z)=>{
      const block=legacyBlocks?legacyBlocks.get(x,y,z):bot.blockAt(new Vec3(x,y,z),false)
      return block?.shapes?.length?y+Math.max(...block.shapes.map(shape=>shape[4])):null
    })
    const weapon=target.equipment?.[0]?.name||''
    airEnvelope=forecast({x:p.x,y:p.y,z:p.z,vx:v.x,vy:v.y,vz:v.z,eye:eye.y-p.y,
      halfX:(e.width||.6)/2,halfZ:(e.width||.6)/2,height:e.height||1.8,grounded:e.onGround},
      body,floor,steering,/_(axe|sword)$/.test(weapon),true,1,weapon.endsWith('_axe')?1:1.6)
    // Critical readiness is a possible bound only, never hidden enemy CD.
  }
  const separation=visible?Math.hypot(tp.x-p.x,tp.z-p.z):null
  const receding=visible&&session.lastSeparation!=null&&separation>session.lastSeparation+.01
  if(!refining)session.lastSeparation=separation
  const targetMotion=visible&&motion?{source:'public-position-samples',matchId:session.id,
    opponent:session.opponent,sampleTick:motion.tick,vx:motion.vx,vy:motion.vy,vz:motion.vz,
    grounded:motion.grounded}:null
  const towardDistance=visible?Math.hypot(towardSelf.x,towardSelf.z):0
  const approachSpeed=visible&&motion&&towardDistance>.1
    ?(motion.vx*towardSelf.x+motion.vz*towardSelf.z)/towardDistance:0
  const ownClosing=visible&&towardDistance>.1
    ?-(v.x*towardSelf.x+v.z*towardSelf.z)/towardDistance:0
  const approachTicks=visible?Math.max(0,otherReach-3)/Math.max(.32,approachSpeed+ownClosing):0
  return { self,seen,publicTerrain:terrain,targetVelocity,targetMotion,nativeSelf:own,
    targetFloorY:targetFloor?.intersect?.y??(bot.game.minY??-64),
    usingKind:use?.kind,offhand:bot.inventory.slots[45]?.name||'empty',swingAt:session.swingAt,
    observation:{ tick,ground:e.onGround,
    health:self.health,self:{x:p.x,z:p.z},selfVelocity:{x:v.x,y:v.y,z:v.z},sentPosition:lastSentPosition,
    target:visible?{x:tp.x,z:tp.z}:null,targetYaw:target?.yaw,
    targetFacingDot:visible?targetForward.dot(towardSelf)/Math.max(.001,Math.hypot(towardSelf.x,towardSelf.z)):null,
    targetGrounded:motion?.grounded??false,targetVelocity,
    targetAirborne:visible&&Boolean(motion&&!motion.grounded),airEnvelope,
    targetCriticalPossible:visible&&Boolean(motion&&!motion.grounded&&motion.vy<=.08),
    targetCriticalThreat:Boolean(airEnvelope?.valid&&airEnvelope.criticalTick>=0),
    targetAirborneThreat:Boolean(airEnvelope?.valid?airEnvelope.meleeTick>=0:visible&&motion&&!motion.grounded),
    visible,distance,reach,otherReach,charge:self.charge,held:self.held,critical:self.critical,
    mutualOutOfReach:visible&&reach>3&&otherReach>3,
    shieldReady:self.shieldAvailable,shieldEffective:self.shielding,
    shieldRaised:Boolean(use?.kind==='shield'&&self.using),
    targetShieldFacing:facing,targetShieldRaised:isShield,targetSwingRecent:tick-(session.swingAt||-1000)<=1,
    targetApproaching:approachSpeed>.06,targetApproachSpeed:approachSpeed,targetApproachTicks:approachTicks,
    offhandShieldReady:bot.inventory.slots[45]?.name==='shield'&&!switching,
    wallMargin:Math.min(...terrain.walls),receding,arrowThreat:threat,
    loaded:self.crossbowLoaded,arrows:self.arrows,targetRanged:targetBow||targetLoading||session.targetKnownLoaded,
    rangedEvent:session.targetRangedEvent||0,
    ...rangedObserved,...(mechanicalEnabled?observeVisibleBow(target):{}) } }
}
function look (yaw,pitch=0) {
  if(legacyEnabled&&Math.abs(Math.atan2(Math.sin(yaw-bot.entity.yaw),Math.cos(yaw-bot.entity.yaw)))<1e-9
      &&Math.abs(pitch-bot.entity.pitch)<1e-9)return
  immediateLook(bot,yaw,pitch)
}
function aim (target, ranged, velocity) {
  if (!target) return
  const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
  const point=ranged?target.position.offset(0,Math.min(1.3,(target.height||1.8)*.7),0)
    :nearestHitPoint(eye,target)
  const speed=ranged==='bow'?bowSpeed((tick-(use?.tick??tick))*50):3.15
  // Landing prediction must not aim through the observed floor. This is the
  // target's public block surface, not its hidden input or movement intention.
  const targetFloor=ranged?bot.world.raycast(target.position.offset(0,.1,0),new Vec3(0,-1,0),16):null
  const floorY=targetFloor?.intersect?.y
  if(mechanicalEnabled&&ranged&&Number.isFinite(floorY)){
    const v=bot.entity.velocity
    const inherited=ranged==='bow'?{x:v.x,y:bot.entity.onGround?0:v.y,z:v.z}:{x:0,y:0,z:0}
    const solution=solveRangedAim({eye:{x:eye.x,y:eye.y-.1,z:eye.z},inherited,
      feet:target.position,motion:velocity,airborne:session.targetMotion?.grounded===false,
      floorY,height:target.height||1.8,speed,profile:rangedCalibration})
    if(solution){
      session.lastRangedAim={tick,weapon:ranged,...solution}
      const d=solution.direction
      look(Math.atan2(-d.x,-d.z),Math.atan2(d.y,Math.hypot(d.x,d.z)));return
    }
  }
  const at=ranged?leadTarget(eye,point,velocity,speed,{airborne:Math.abs(velocity.y)>.08,
    floorY:Number.isFinite(floorY)?floorY+point.y-target.position.y:undefined}):point
  const dx=at.x-eye.x,dz=at.z-eye.z,dy=at.y-eye.y,h=Math.hypot(dx,dz)
  look(Math.atan2(-dx,-dz),ranged?solvePitch(h,dy,speed):Math.atan2(dy,h))
}
// Only this function emits combat controls. It never waits for a model response.
function execute (planned, frame, target) {
  const actual=executeCommand({bot,planned,frame,target,tick,session,charge,look,aim,clearPath,exactBoxAim:true,
    getSentPosition:()=>lastSentPosition,
    offhand,stopUse,getUse:()=>use,setUse:value=>{use=value},plugin,
    shieldUntil,lastAttackTick,weaponEpoch,bowDrawMs:plannedBowDrawMs,ownLoaded,
    offhandLoaded:()=>loaded(bot.inventory.slots[45]),
    canHit:entity=>{const eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
      return clearPath(eye,nearestHitPoint(eye,entity))},
    onSwitch:()=>{lastSwing=tick;weaponEpoch++;session.lastWeaponSwitchTick=tick
      if(legacyEnabled)legacyRevision++
      chargeObserver.reset({tick,slot:bot.quickBarSlot,serverTick:nativeSelf?.serverTick})},
    onAttack:attackId=>{lastSwing=lastAttackTick=tick
      if(legacyEnabled)legacyRevision++
      chargeObserver.reset({tick,slot:bot.quickBarSlot,attackId,serverTick:nativeSelf?.serverTick})}})
  if(!legacyEnabled&&planned.command.decidedTick!==undefined&&planned.command.event!=='refined_action'){
    const decidedTick=planned.command.decidedTick,heads=execution.get(decidedTick)||new Set()
    for(let i=0;i<9;i++)if(!actual.ignoredHeads.includes(i))heads.add(i)
    execution.set(decidedTick,heads)
    if(heads.size)session.lastExecutedDecision=decidedTick
    else if(hybridEnabled)session.lastExecutedDecision=null
    model({command:'executed',fighter:'Punengbho',decidedTick,
      ignoredHeads:Array.from({length:9},(_,i)=>i).filter(i=>!heads.has(i))})
    if(actual.attacked)model({command:'native_step',fighter:'Punengbho',decidedTick,
      reward:swingFeedback(actual.attackCharge,true)})
  }
  else if(hybridEnabled)session.lastExecutedDecision=null
  brain.applied(session.state,planned.command,legacyEnabled?actual:actual.attacked,tick)
  brain.rangedApplied(session.state,planned.command,actual.rangedResult,tick)
  session.lastAppliedCommand=planned.command
  return {...actual,offhandBusy:switching}
}

function legacyRecord(planned,frame,target,preview=false){
  if(!brain.isDecisionCurrent(session.state,planned)){
    legacyStats.stale++
    if(!preview)legacyHeldFrame(session.frames.at(-1),'superseded-controller-state')
    return
  }
  const key=JSON.stringify([tick,planned.command])
  if(preview&&key===legacyLastEffect)return
  const c=planned.command,canAttack=!session.state.pending?.size&&lastAttackTick<tick
  const air=planned.airPlan
  const airDefense=air?{valid:air.valid,threat:air.threat,action:air.action,risingTail:air.risingTail,
    jumpResetPossible:air.jumpResetPossible,route:air.route,timing:air.timing,criticalTicks:air.criticalTicks}:null
  // Physical observation state advances once even when navigation is held.
  // A read-only preview commits only when its actual command is accepted.
  if(!preview&&!brain.commitDecision(session.state,planned))return
  const now=monoMs(),outboundPackets=legacyPacketTimes.filter(at=>at>=now-1000).length
  if(!legacyOutput.permit({...c,attack:c.attack&&canAttack,doubleAttack:c.doubleAttack&&canAttack},now,
    {physical:!preview,outboundPackets})){
      if(!preview){
        const row=session.frames.at(-1)
        if(row)row.heldProposal={selectedBranch:planned.selectedBranch,command:planned.command,
          originalCommand:planned.originalCommand,commandChanges:planned.commandChanges,airDefense}
        legacyHeldFrame(row,'output-coalesced')
      }
      return
    }
  if(preview&&!brain.commitDecision(session.state,planned))return
  legacyLastEffect=key
  const actual=execute(planned,frame,target),row=session.frames.at(-1)
  legacyStats.applied++
  const event={atMs:monoMs(),command:planned.command,mode:planned.original.phase,selectedBranch:planned.selectedBranch,
    owners:actual.owners,originalCommand:planned.originalCommand,commandChanges:planned.commandChanges,
    stateVersion:planned.committedStateVersion,actualPackets:actual.packets,executed:actual.controls,
    attackPacket:actual.attacked,attacks:actual.attacks,attackGeometry:actual.attackGeometry,
    attackSuppressedReason:actual.attackSuppressedReason,held:actual.held,
    offhand:actual.offhand,rangedResult:actual.rangedResult,ppoEligible:false,
    spacingPlan:planned.spacingPlan,contactTiming:planned.contactTiming,closeFight:planned.closeFight,airDefense,
    executionObservation:{reach:frame.observation.reach,opponent:frame.seen,
      self:{x:frame.self.x,y:frame.self.y,z:frame.self.z,vx:frame.self.vx,vz:frame.self.vz},
      latency:frame.latency,revision:legacyRevision}}
  if(row){
    if(preview)(row.subtickActions??=[]).push(event)
    else {Object.assign(row,event,{decisionStatus:'fresh',airPlan:planned.airPlan,runtimeMs:planned.runtimeMs})
      journal.append(session.file,JSON.stringify(row)+'\n')}
  }
  session.lastAppliedCommand={...planned.command}
  session.lastAppliedControls={...actual.controls}
}
function legacyHeldFrame(row,reason){
  if(!row||row.decisionStatus)return
  row.decisionStatus=reason;row.owner='legacy86-held-input';row.attackPacket=false
  row.command=session.lastAppliedCommand?{...session.lastAppliedCommand,attack:false,doubleAttack:false}:null
  row.executed={...session.lastAppliedControls};legacyStats.heldFrames++
  journal.append(session.file,JSON.stringify(row)+'\n')
}
function legacyTiming(frame,ageMs=0,observedHeading=null){
  const ping=bot.players?.[bot.username]?.ping,known=Number.isFinite(ping)&&ping>=0
  const recent=legacyStats.decisionMs.slice(-250).sort((a,b)=>a-b)
  const estimate=legacyMotion?.body(legacyMotion.bodies.opponent,monoMs())
  frame.motionUncertainty=estimate?.uncertainty??.04
  frame.latency={rttMs:known?ping:null,oneWayMs:known?ping/2:25,serverQueueMs:50,
    decisionMs:Math.max(4,recent[Math.floor(recent.length*.95)]||0),
    observationAgeMs:Math.max(ageMs,estimate?.fresh?estimate.ageMs:0),
    source:known?'public-player-list-ping':'unknown-rtt-conservative-default'}
  const e=bot.entity,f=Number(bot.getControlState('forward'))-Number(bot.getControlState('back'))
  const l=Number(bot.getControlState('left'))-Number(bot.getControlState('right'))
  const x=-Math.sin(e.yaw)*f-Math.cos(e.yaw)*l,z=-Math.cos(e.yaw)*f+Math.sin(e.yaw)*l,n=Math.max(1,Math.hypot(x,z))
  // Preview controls have not advanced physics. Feeding each new proposal
  // back into the same observed delay window made the route alternate.
  frame.previousHeading=observedHeading||{x:x/n,z:z/n}
  return frame
}
function legacyQuickFrame(analysis){
  const base=legacyFrame.frame,target=bot.players[session.opponent]?.entity
  if(!target||!analysis.available)return null
  const e=bot.entity,p=e.position,tp=target.position,flags=Number(target.metadata?.[8]||0)
  const item=target.equipment?.[flags&2?1:0],shieldRaised=Boolean(flags&1)&&item?.name==='shield'
  if(shieldRaised&&!session.targetShieldAt)session.targetShieldAt=tick
  if(!shieldRaised)session.targetShieldAt=0
  const effective=shieldRaised&&tick-session.targetShieldAt>=5
  const eye=p.offset(0,e.eyeHeight||1.62,0),reach=eyeBox(eye,tp,target.height||1.8)
  const otherReach=eyeBox(tp.offset(0,1.62,0),p,e.height||1.8)
  const v=analysis.opponent.velocityKnown?analysis.opponent.velocity:base.targetVelocity
  const visible=analysis.opponent.visible&&clearPath(eye,nearestHitPoint(eye,target))
  const forward={x:-Math.sin(target.yaw),z:-Math.cos(target.yaw)}
  const facingDot=(forward.x*(p.x-tp.x)+forward.z*(p.z-tp.z))/Math.max(.001,Math.hypot(tp.x-p.x,tp.z-p.z))
  const ranged=observeRanged(session,{tick,visible,using:Boolean(flags&1),activeItem:item,
    mainhand:target.equipment?.[0],offhand:target.equipment?.[1],fired:session.targetFired},loaded)
  session.targetFired=false
  const self={...base.self,x:p.x,y:p.y,z:p.z,eyeY:eye.y,vx:e.velocity.x,vy:e.velocity.y,vz:e.velocity.z,
    ground:e.onGround,held:bot.quickBarSlot,charge:charge(),crossbowLoaded:ownLoaded(),
    critical:!e.onGround&&lastSentPosition?.falling===true&&!e.isInWater&&!e.isInLava,
    shieldAvailable:tick>=shieldUntil&&base.self.inventoryObservation.hasShield}
  const own=nativeSelf&&tick-nativeSelf.receivedTick<=3?nativeSelf:null
  self.using=own?own.using:Boolean(use);self.useTicks=own?own.useTicks:use?tick-use.tick:0
  self.shielding=Boolean(own?.shielding&&own.using&&own.activeItem==='SHIELD'&&own.useTicks>=5
    &&use?.kind==='shield'&&tick-use.tick>=5)
  const seen={...base.seen,visible,x:tp.x,y:tp.y,z:tp.z,shield:effective,shieldRaised,
    held:(target.equipment?.[0]?.name||'UNKNOWN').toUpperCase()}
  const arrows=Object.values(bot.entities).filter(a=>/^(arrow|spectral_arrow)$/.test(a.name||'')
    &&a.position.distanceTo(p)<32&&clearPath(eye,a.position)).map(a=>({id:a.id,
      x:a.position.x,y:a.position.y,z:a.position.z,vx:a.velocity?.x||0,vy:a.velocity?.y||0,vz:a.velocity?.z||0,
      shooterId:a.publicShooterId}))
  const arrowThreat=publicArrowThreat(arrows,{...self,entityId:e.id,yaw:e.yaw},wall,clearPath)
  if(arrowThreat){const arrow=arrows.find(a=>a.id===arrowThreat.id)
    arrowThreat.yaw=Math.atan2(-(arrow.x-p.x),-(arrow.z-p.z))}
  const frame={...base,self,seen,targetVelocity:v,offhand:bot.inventory.slots[45]?.name||'empty',usingKind:use?.kind,
    targetMotion:{...base.targetMotion,vx:v.x,vy:v.y,vz:v.z,sampleTick:target.lastPublicPositionTick??base.targetMotion?.sampleTick},
    observation:{...base.observation,tick,visible,reach,otherReach,distance:p.distanceTo(tp),
      target:{x:tp.x,z:tp.z},targetFacingDot:facingDot,charge:self.charge,held:self.held,ground:self.ground,
      shieldReady:self.shieldAvailable,critical:self.critical,targetShieldFacing:effective&&facingDot>0,
      targetShieldRaised:shieldRaised,targetGrounded:target.publicGrounded??base.observation.targetGrounded,
      targetAirborne:!(target.publicGrounded??base.observation.targetGrounded),targetVelocity:v,
      targetApproaching:v.x*(p.x-tp.x)+v.z*(p.z-tp.z)>.06,
      targetSwingRecent:tick-(session.swingAt??-1000)<=1,arrowThreat,
      loaded:self.crossbowLoaded,arrows:self.arrows,offhandShieldReady:bot.inventory.slots[45]?.name==='shield'&&!switching,
      shieldEffective:self.shielding,mutualOutOfReach:reach>3&&otherReach>3,...ranged,...observeVisibleBow(target)}}
  return {frame:legacyTiming(frame,analysis.opponent.ageMs,base.previousHeading),target}
}
async function legacyFastCycle(analysis){
  if(!session?.active||!modelReady||!legacyFrame||legacyFrame.tick!==tick||!analysis.available)return
  if(legacyPending||legacyFrame.committing){legacyStats.coalesced++;return}
  // Monitoring stays at 500Hz. Re-running the same expensive tactical search
  // on an unchanged snapshot only queues stale replies and misses real input.
  const key=tick+':'+legacyRevision
  if(key===legacyAnalyzedKey){legacyStats.coalesced++;return}
  legacyAnalyzedKey=key
  legacyPending++
  const ownSession=session,epoch=legacyEpoch,sourceRevision=legacyRevision,at=performance.now(),physical=tick
  try{
    const live=legacyQuickFrame(analysis);if(!live)return
    const planned=await brain.decide(session.state,live.frame,legacyFrame.probe,tick,{preview:true,transactional:true,
      isCurrent:()=>epoch===legacyEpoch&&ownSession===session&&session.active&&physical===tick&&sourceRevision===legacyRevision})
    legacyStats.decisions++
    if(!planned||epoch!==legacyEpoch||ownSession!==session||!session.active||physical!==tick||sourceRevision!==legacyRevision){legacyStats.stale++;return}
    legacyStats.decisionMs.push(performance.now()-at)
    if(legacyStats.decisionMs.length>5000)legacyStats.decisionMs.shift()
    legacyRecord(planned,live.frame,live.target,true)
  }catch(error){log('legacy86-fast-error',{error:String(error)});session.invalid=true;bot.clearControlStates()}
  finally{legacyPending--}
}
async function legacyPhysics(){
  const ownSession=session,epoch=legacyEpoch,physical=tick
  try{
    const captured=performance.now(),captureGapMs=lastLegacyCapture==null?null:captured-lastLegacyCapture
    lastLegacyCapture=captured
    const target=bot.players[session.opponent]?.entity,frame=legacyTiming(publicFrame(target))
    frame.routeCache=new Map()
    const current={tick,frame,probe:null,committing:true};legacyFrame=current
    const sample={matchId:session.id,revision:++legacyRevision,atMs:monoMs(),tick,source:'physics',
      self:{position:{x:frame.self.x,y:frame.self.y,z:frame.self.z},sourceTick:tick,
        grounded:frame.self.ground,eyeHeight:frame.self.eyeY-frame.self.y}}
    legacyMotion.ingest(sample);legacyLoop.sample(sample)
    const row={tick,capturedAt:Date.now(),captureGapMs,observationMs:performance.now()-captured,
      self:frame.self,seen:frame.seen,publicTerrain:frame.publicTerrain,
      observation:frame.observation,nativeSelf:frame.nativeSelf,controllerCode,controlRegime,
      owner:'legacy86',ppoEligible:false,nativeDealt:0,nativeReceived:0}
    session.frames.push(row)
    await session.controllerReady
    if(epoch!==legacyEpoch||ownSession!==session||!session.active)return
    // Every physical observation is retained. During catch-up, calculate only
    // the newest frame instead of doing costly searches for expired frames.
    if(tick!==physical){legacyHeldFrame(row,'catch-up-observation');return}
    const p=bot.entity.position,probeKey=[Math.floor(p.x),Math.floor(p.y),Math.floor(p.z),legacyCollisionRevision].join(',')
    if(probeKey!==legacyProbeKey){
      legacyProbe=require('./protocol-legacy86-route').createRouteProbe({origin:p,
        blockAt:(x,y,z)=>legacyBlocks.get(x,y,z)})
      legacyProbeKey=probeKey
    }
    const probe=legacyProbe
    current.probe=probe
    const began=performance.now()
    const planned=await brain.decide(session.state,frame,probe,physical,{transactional:true,
      isCurrent:()=>epoch===legacyEpoch&&ownSession===session&&session.active&&physical===tick})
    current.committing=false
    if(epoch!==legacyEpoch||ownSession!==session||!session.active)return
    if(!planned||tick!==physical){legacyStats.stale++;legacyHeldFrame(row,'decision-after-deadline');return}
    legacyStats.decisionMs.push(performance.now()-began)
    if(legacyStats.decisionMs.length>5000)legacyStats.decisionMs.shift()
    row.decisionLatencyMs=performance.now()-began
    legacyRecord(planned,frame,target)
  }catch(error){log('legacy86-frame-error',{error:String(error)});session.invalid=true;bot.clearControlStates();stopUse()}
}

function physics () {
  if(!session?.active||bot.health<=0){bot.clearControlStates();if(use)stopUse();return}
  if(legacyEnabled){void legacyPhysics();return}
  try {
    const target=bot.players[session.opponent]?.entity
    const observedAt=performance.now()
    const frame=publicFrame(target)
    if(highRate){
      highRate.sample({matchId:session.id,revision:++motionRevision,atMs:monoMs(),tick,source:'physics',
        self:{position:{x:frame.self.x,y:frame.self.y,z:frame.self.z},sourceTick:tick,
          grounded:frame.self.ground,eyeHeight:frame.self.eyeY-frame.self.y}})
    }
    // Mechanical synchronization acts on this physical observation without
    // waiting for inference. The network still observes every frame for handoff.
    const presetPlan=hybridEnabled?brain.plan(session.state,frame.observation,latest):null
    const observationMs=performance.now()-observedAt
    const request={command:'act',fighter:'Punengbho',opponent:session.opponent,matchId:session.id,
      requestId:++requestId,tick,trainingScope:hybridEnabled?'hybrid_owned_heads':'pure_model_all_input',controlRegime,style:'MIXED',
      observedOpponentSwingAge:session.swingAt?Math.min(20,tick-session.swingAt):-1,
      observedOpponentMotion:frame.targetMotion,
      // The same causal snapshot is recorded and consumed by the policy.
      // Previously the airborne forecast was logged but never sent to it.
      publicActionContext:frame.observation,
      yaw:180-bot.entity.yaw*180/Math.PI,pitch:-bot.entity.pitch*180/Math.PI,
      self:frame.self,seen:frame.seen,publicTerrain:{...frame.publicTerrain,episodeTick:tick-session.startTick}}
    if(highRate){request.publicMotionAnalysis=highRate.analyze();highRateFrame={tick,request}}
    requestContexts.set(request.requestId,{matchId:session.id,tick,weaponEpoch,requestedAt:performance.now()})
    for(const [id,context]of requestContexts)if(tick-context.tick>20)requestContexts.delete(id)
    // Persist the causal observation immediately in memory. The reply may
    // arrive before the next physics step; do not deliberately delay it a tick.
    const row={tick,capturedAt:Date.now(),self:frame.self,seen:frame.seen,publicTerrain:frame.publicTerrain,
      observedOpponentMotion:frame.targetMotion,observation:frame.observation,nativeSelf:frame.nativeSelf,
      controllerCode,owner:'dual',controlRegime,nativeDealt:0,nativeReceived:0,
      // Native damage can arrive while inference is pending. These are the
      // actual held controls, not a claim that the next model action ran.
      command:session.lastAppliedCommand||null,
      executed:Object.fromEntries(['forward','back','left','right','sprint','jump','sneak'].map(k=>[k,bot.getControlState(k)]))}
    session.frames.push(row)
    decisionDispatch.open({tick,matchId:session.id,requestId:request.requestId,
      frame,target,row,observationMs,presetPlan,requestedAt:performance.now()})
    model(request)
    if(presetPlan&&brain.immediate(presetPlan))decisionDispatch.deadline(latest)
  }catch(e){log('frame-error',{matchId:session.id,error:e.stack});session.invalid=true;bot.clearControlStates();stopUse()}
}

function settleDecisionFrame(pending, action, dispatchReason) {
  if (!session || pending.matchId !== session.id) return
  const {frame,target,row,observationMs}=pending
  try {
    if(dispatchReason==='bout-ended'||dispatchReason==='forced-move'){
      const neutral=require('./protocol-pure-brain').plan(session.state,frame.observation,null)
      Object.assign(row,{mode:'NEURAL',owners:neutral.owners,command:neutral.command,actualPackets:[],executed:{},
        ignoredHeads:Array.from({length:9},(_,i)=>i),policySha,attackPacket:false,
        attackSuppressedReason:dispatchReason+'-before-response',dispatchReason})
      journal.append(session.file,JSON.stringify(row)+'\n')
      return
    }
    if(tick!==pending.tick)throw Error('Decision deadline crossed physical frame')
    const planningAt=performance.now()
    const planned=pending.presetPlan?brain.refreshNeuralPlan(pending.presetPlan,frame.observation,action)
      :brain.plan(session.state,frame.observation,action)
    const planningMs=performance.now()-planningAt
    const actual=execute(planned,frame,target)
    Object.assign(row,{mode:planned.mode,owners:actual.owners,
      command:planned.command,actualPackets:actual.packets,executed:actual.controls,executionMs:actual.executionMs,
      executedView:actual.executedView,relativeViewRefreshed:actual.relativeViewRefreshed,
      timings:{observationMs,planningMs,executionMs:actual.executionMs,
        modelResponseMs:action?.responseMs,modelActionAgeTicks:action?tick-action.decidedTick:null,
        observationToExecutionMs:performance.now()-pending.requestedAt},dispatchReason,
      offhand:actual.offhand,offhandBusy:actual.offhandBusy,rangedResult:actual.rangedResult,
      rangedAim:session.lastRangedAim?.tick===tick?session.lastRangedAim:null,
      opponentRangedEvent:frame.observation.rangedEvent,
      modelTick:action?.decidedTick,modelAction:action||null,ignoredHeads:actual.ignoredHeads,policySha,attackPacket:actual.attacked,shieldRequested:actual.shieldRequested,
      attackHeld:actual.attackHeld,attackItemName:actual.attackItemName,attackId:actual.executedAttackId,
      attackSuppressedReason:actual.attackSuppressedReason,weaponEpoch,
      attackCharge:actual.attackCharge,attackGeometry:actual.attackGeometry})
    const openingFeedback=session.openingControl.observe(row)
    if(openingFeedback){
      row.learningFeedback=[openingFeedback]
      model({command:'native_step',fighter:'Punengbho',decidedTick:openingFeedback.decidedTick,reward:openingFeedback.reward})
      log('control-loss-feedback',{matchId:session.id,...openingFeedback})
    }
    if(Number.isSafeInteger(session.lastExecutedDecision)&&session.lastFood!==undefined)
      model({command:'native_step',fighter:'Punengbho',decidedTick:session.lastExecutedDecision,
        reward:hungerFeedback(session.lastFood,frame.self.food)})
    session.lastFood=frame.self.food
    journal.append(session.file,JSON.stringify(row)+'\n')
    if(session.state.transitions.length){for(const change of session.state.transitions.splice(0))log('handoff',{matchId:session.id,...change})}
  }catch(e){log('frame-error',{matchId:session.id,error:e.stack});session.invalid=true;bot.clearControlStates();stopUse()}
}
async function finishBout(old,row){
  if(old.finalizing||old.outcome)return
  old.finalizing=true
  try{
    await Promise.all([old.file,path.join(runtime,old.id+'-packets.jsonl'),
      path.join(runtime,old.id+'-corrections.jsonl')].map(file=>journal.flush(file)))
    const saved=await require('./protocol-frame-store').saveCompletedFrames(old.file,old.frames)
    if(!saved.canonical)log('completed-frames-sidecar',{matchId:old.id,...saved})
    old.outcome={winner:row.winner,reason:row.reason,invalid:Boolean(old.invalid)}
    fs.writeFileSync(path.join(runtime,old.id+'-report.json'),JSON.stringify({
      matchId:old.id,opponent:old.opponent,frames:old.frames.length,inferences:old.inferences,
      outcome:old.outcome,policySha,controlRegime,completedFrames:saved.path},null,2))
    if(legacyEnabled&&row.hadFrames&&old.frames.length){
      const evaluations=path.join(root,'work/wavedog-punengbho/model/evaluations')
      fs.mkdirSync(evaluations,{recursive:true})
      const file=path.join(evaluations,old.id+'.json.gz')
      const compressed=await require('node:util').promisify(require('node:zlib').gzip)(JSON.stringify({matchId:old.id,controlRegime,
        ppoEligible:false,trainingSkipped:true,frames:old.frames,outcome:old.outcome}))
      await fs.promises.writeFile(file,compressed)
      fs.writeFileSync(path.join(runtime,old.id+'-training.json'),JSON.stringify({event:'evaluation_saved',
        fighter:'Punengbho',trainingSkipped:true,checkpointSha256:policySha,file,controlRegime}))
      model({command:'review',matchId:old.id,fighter:'Punengbho',opponent:old.opponent,
        outcome:old.outcome,frames:old.frames})
      log('direct-logic-trajectories-saved',{matchId:old.id,trainingSkipped:true,file})
    }else if(row.hadFrames&&old.frames.length&&modelReady){
      awaitingTraining.set(old.round,old)
      model({command:row.winner&&!old.invalid?'finish':'partial',fighter:'Punengbho',
        opponent:old.opponent,matchId:old.id,round:old.round,win:row.winner==='Punengbho',health:bot.health})
    }else if(row.hadFrames)plugin({type:'learning_error',matchId:old.id,reason:'No valid frames or model offline'})
    log('end',{matchId:old.id,...old.outcome})
    rangedLearning?.completed(old.opponent,old.invalid)
  }catch(error){
    log('bout-finalize-error',{matchId:old.id,error:String(error)})
    plugin({type:'learning_error',matchId:old.id,reason:'Frame persistence failed; raw log retained'})
  }finally{old.finalizing=false}
}
function onPlugin (row) {
  // Protocol player name and persistent learner identity are independent.
  row={...row};for(const key of ['attacker','victim','winner'])if(row[key]===playerName)row[key]='Punengbho'
  if(row.type==='heartbeat_ack'&&!row.active&&!row.preparing&&session?.active&&row.matchId===session.id){
    session.invalid=true;session.active=false;decisionDispatch.cancel()
    if(legacyEnabled){legacyEpoch++;legacyFrame=null;legacyLastEffect=null}
    bot.clearControlStates();stopUse()
    void finishBout(session,{winner:'',reason:'server-idle-recovery',hadFrames:true})
  }
  // Recover an interrupted end callback at idle without losing the in-memory
  // rollout or restarting the learner. Preparation never has recorded frames.
  if(row.type==='heartbeat_ack'&&!row.active&&!row.preparing&&session
      &&!session.active&&session.frames.length&&!session.outcome&&!session.finalizing)
    void finishBout(session,{winner:'',reason:'recovered-end-save',hadFrames:true})
  if(row.type==='prepare'){
    if(legacyEnabled){legacyEpoch++;legacyFrame=null;legacyLastEffect=null;legacyAnalyzedKey=null;legacyRevision=0;legacyLoop.reset(row.matchId);legacyMotion.reset(row.matchId);legacyOutput.reset();legacyStats.decisionMs=[]}
    highRate?.reset(row.matchId);highRateAnchorTick=null;highRateFrame=null;motionRevision=0
    rangedCalibration=rangedLearning?.profile()||null
    chargeObserver.clear();chargeDiagnostic=null
    decisionDispatch.cancel()
    bot.clearControlStates();stopUse();latest=null;nativeSelf=null;execution.clear();requestContexts.clear()
    session={id:row.matchId,opponent:row.opponent,round:Date.now(),active:false,
    state:brain.createState(row.opponent,'Punengbho'),frames:[],inferences:0,attackOwners:new Map(),attackedDecisions:new Set(),
      openingControl:createOpeningControlTracker('Punengbho',row.opponent),
      file:path.join(runtime,row.matchId+'-frames.jsonl')}
    if(legacyEnabled)session.controllerReady=brain.reset(session.state,session.round)
    shieldUntil=0;lastSwing=lastAttackTick=tick-30
    log('prepare',{matchId:row.matchId,opponent:row.opponent,policySha,controllerCode,sourceSha256})
  }
  if(row.type==='start'&&session?.id===row.matchId){
    session.active=true;session.startTick=tick;latest=null
    publicHealth?.beginMatch(session.id)
    if(!legacyEnabled)model({command:'reset',fighter:'Punengbho',opponent:session.opponent,matchId:session.id,role:'current',learning:true})
    log('start',{matchId:session.id,policySha})
  }
  if(!session||row.matchId!==session.id)return
  if(legacyEnabled&&['self_state','shield_disabled','blocked_melee','damage','attack_packet'].includes(row.type))legacyRevision++
  chargeObserver.receipt(row)
  if(row.type==='self_state'){
    nativeSelf={...row,receivedTick:tick};shieldUntil=tick+row.shieldCooldown
    bowCancellation?.poll()
  }
  if(row.type==='shield_disabled') {shieldUntil=tick+row.cooldownTicks;stopUse()}
  if(row.type==='blocked_melee'&&row.shieldDisabled)shieldUntil=Math.max(shieldUntil,tick+100)
  brain.receipt(session.state,row,tick)
  if(['damage','blocked_melee','shield_disabled','attack_packet'].includes(row.type)){
    log('native',{matchId:session.id,...row})
    if(row.type==='damage'&&!row.cancelled){
      const f=session.frames.at(-1)
      if(f){if(row.attacker==='Punengbho')f.nativeDealt+=row.amount;else f.nativeReceived+=row.amount
        ;(f.nativeEvents||=([])).push(row)}
      if(f)session.openingControl.damage(row,f,session.lastExecutedDecision)
      const a=session.attackOwners.get(row.attackId)
      if(a?.kind==='neural'&&row.attacker==='Punengbho'&&row.victim===session.opponent&&row.melee)
        model({command:'native_step',fighter:'Punengbho',decidedTick:a.decidedTick,
          reward:damageFeedback({...row,source:'MELEE',native_critical:row.nativeCritical},undefined,a.attackReach)})
      else if(row.attacker==='Punengbho'&&row.victim===session.opponent&&!row.melee
          &&Number.isSafeInteger(session.lastExecutedDecision))
        // A delayed projectile result is a reward at its observed time, never
        // claimed as a specific melee attack or an invented projectile intent.
        model({command:'native_step',fighter:'Punengbho',decidedTick:session.lastExecutedDecision,reward:row.amount/20})
      else if(row.victim==='Punengbho'&&Number.isSafeInteger(session.lastExecutedDecision))
        model({command:'native_step',fighter:'Punengbho',decidedTick:session.lastExecutedDecision,reward:-row.amount/20})
    }
  }
  if(row.type==='end'){
    if(legacyEnabled){legacyEpoch++;legacyFrame=null;legacyLastEffect=null}
    decisionDispatch.cancel()
    session.active=false;bot.clearControlStates();stopUse()
    void finishBout(session,row)
  }
}
function connect () {
  let reconnectDelay=4000
  lastSentPosition=null
  bowCancellation?.reset();switching=false
  bot=mineflayer.createBot({host:'127.0.0.1',port:25566,username:playerName,auth:'offline',version:'1.21.1',hideErrors:true})
  publicHealth=createPublicHealthTracker(bot._client,()=>tick)
  const wire=bot._client,write=wire.write
  let incomingCorrection=null
  wire.prependListener('position',packet=>{
    const p=bot.entity?.position
    incomingCorrection={packet,before:p?{x:p.x,y:p.y,z:p.z}:null}
  })
  const recorded=new Set(['look','position','position_look','flying','use_entity','arm_animation',
    'entity_action','block_dig','use_item','held_item_slot','window_click'])
  wire.write=function(name,data){
    if(legacyEnabled){
      const now=monoMs();legacyPacketTimes.push(now)
      while(legacyPacketTimes.length&&legacyPacketTimes[0]<now-1000)legacyPacketTimes.shift()
      legacyPeakPacketRate=Math.max(legacyPeakPacketRate,legacyPacketTimes.length)
    }
    if(session?.active)data=currentViewPacket(name,data,bot.entity)
    if(session?.active&&recorded.has(name))journal.append(path.join(runtime,session.id+'-packets.jsonl'),
      JSON.stringify({tick,name,data},(_,v)=>typeof v==='bigint'?v.toString():v)+'\n')
    const result=write.call(this,name,data)
    if(['position','position_look'].includes(name)&&[data.x,data.y,data.z].every(Number.isFinite)){
      const ground=data.onGround??data.flags?.onGround
      const falling=Boolean(lastSentPosition&&tick-lastSentPosition.tick<=2&&!ground&&data.y<lastSentPosition.y-.00001)
      lastSentPosition={x:data.x,y:data.y,z:data.z,onGround:ground,falling,tick}
    }else if(name==='flying'&&lastSentPosition){
      lastSentPosition={...lastSentPosition,onGround:data.onGround??data.flags?.onGround,falling:false,tick}
    }
    frameClock.movementWritten(name)
    return result
  }
  bot.once('spawn',()=>{
    bot._client.registerChannel(channel,null,true)
    const simulate=bot.physics.simulatePlayer.bind(bot.physics)
    bot.physics.simulatePlayer=(state,world)=>{
      frameClock.beforeSimulation()
      decisionDispatch.deadline(latest)
      if(use||bot.usingHeldItem){state.control={...state.control,sprint:false,
        forward:Number(state.control.forward)*.2,back:Number(state.control.back)*.2,
        left:Number(state.control.left)*.2,right:Number(state.control.right)*.2}}
      return simulate(state,world)
    }
    log('spawn',{protocol:bot.version,entityId:bot.entity.id})
    fs.writeFileSync(path.join(runtime,'client-ready.json'),JSON.stringify({pid:process.pid,protocol:bot.version,playerName,modelIdentity:'Punengbho',at:new Date().toISOString(),controllerCode,sourceSha256,controlRegime,highRateMode,
      ...(legacyEnabled?{legacyRuntime:{pid:brain.runtime.pid,classSha256:brain.runtime.classSha256,
        jarSha256:brain.runtime.sha,tacticsSha256:brain.runtime.modelSha}}:{})}))
  })
  bot.on('forcedMove',()=>{
    if(legacyEnabled){legacyEpoch++;legacyFrame=null;legacyLastEffect=null}
    if(session?.active){
      const p=bot.entity.position
      journal.append(path.join(runtime,session.id+'-corrections.jsonl'),JSON.stringify({
        tick,...incomingCorrection,after:{x:p.x,y:p.y,z:p.z},
        heldControls:Object.fromEntries(['forward','back','left','right','sprint','jump','sneak'].map(k=>[k,bot.getControlState(k)])),
        cancelledPending:decisionDispatch.hasPending(),releasesStaleInput:true})+'\n')
    }
    recoverPositionCorrection({dispatch:decisionDispatch,frameClock,requestContexts,
      clearControls:()=>bot.clearControlStates(),stopUse,
      // Mineflayer has already acknowledged the corrected position on wire.
      // Keep that factual position; deleting it hid valid post-correction
      // geometry until another movement packet, sometimes for many frames.
      invalidate:()=>{latest=null;if(lastSentPosition)lastSentPosition={...lastSentPosition,falling:false}}})
  })
  bot._client.on('custom_payload',packet=>{
    if(packet.channel!==channel)return
    try{onPlugin(JSON.parse(packet.data.toString('utf8')))}catch(e){
      if(session?.active)session.invalid=true
      log('plugin-message-error',{matchId:session?.id,error:e.stack})
    }
  })
  bot.on('physicsTick',()=>{tick++;frameClock.physicsTick()})
  if(legacyEnabled){
    const collisionChanged=()=>{legacyProbe=null;legacyProbeKey=null;legacyCollisionRevision++;legacyRevision++}
    bot.on('blockUpdate',(previous,next)=>{if(next?.position)legacyBlocks.invalidate(next.position);else legacyBlocks.clear();collisionChanged()})
    for(const name of ['chunkColumnLoad','chunkColumnUnload','respawn'])bot.on(name,()=>{legacyBlocks.clear();collisionChanged()})
  }
  bot._client.on('set_cooldown',packet=>{
    if(packet.itemID===bot.registry.itemsByName.shield?.id&&packet.cooldownTicks>0){
      shieldUntil=tick+packet.cooldownTicks;if(use?.kind==='shield')stopUse()
    }
  })
  bot._client.on('animation',packet=>{
    if(session&&[0,3].includes(packet.animation)&&packet.entityId===bot.players[session.opponent]?.entity?.id){
      session.swingAt=tick;if(legacyEnabled)legacyRevision++}
  })
  for(const name of ['entityUpdate','entityEquip'])bot.on(name,entity=>{
    if(mechanicalEnabled&&session?.active&&entity.id===bot.players[session.opponent]?.entity?.id){
      observeVisibleBow(entity)
      if(legacyEnabled)legacyRevision++
    }
  })
  for(const name of ['rel_entity_move','entity_move_look','entity_teleport','entity_look','sync_entity_position'])
    bot._client.on(name,packet=>{
      queueMicrotask(()=>{
        const entity=bot.entities[packet.entityId]
        if(!entity)return
        if(typeof packet.onGround==='boolean')entity.publicGrounded=packet.onGround
        if(name==='entity_look')return // Rotation alone is not a new position observation.
        entity.lastPublicPositionTick=tick
        if((!highRate&&!legacyLoop)||!session?.active||!bot.entity||entity.id!==bot.players[session.opponent]?.entity?.id)return
        const p=entity.position,eye=bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0)
        const visible=bot.entity.position.distanceTo(p)<64
          &&(clearPath(eye,p.offset(0,1.3,0))||clearPath(eye,p.offset(0,.6,0)))
        const sample={matchId:session.id,revision:legacyEnabled?++legacyRevision:++motionRevision,atMs:monoMs(),tick,source:'packet',
          opponent:{position:{x:p.x,y:p.y,z:p.z},visible,grounded:entity.publicGrounded,
            half:(entity.width||.6)/2,height:entity.height||1.8,discontinuity:name==='entity_teleport'}}
        if(legacyEnabled){
          legacyMotion.ingest(sample);legacyLoop.sample(sample)
          // A real position packet can make contact legal between monitor
          // deliveries. Run the same versioned decision path immediately;
          // the 500 Hz clock remains active and cannot duplicate this revision.
          const reach=eyeBox(eye,p,entity.height||1.8)
          if(reach<=3)void legacyFastCycle(legacyMotion.analyze(monoMs()))
        }else highRate.sample(sample)
      })
    })
  // For the negotiated protocol, public objectData is the shooter entity ID.
  // Mineflayer does
  // not retain it, so preserve it from the same packet every player receives.
  bot._client.on('spawn_entity',packet=>{
    // Our listener can run before Mineflayer's entity listener. Read the
    // populated entity after all listeners for this public packet complete.
    queueMicrotask(()=>{
    const entity=bot.entities[packet.entityId]
    if(!entity||!/^(arrow|spectral_arrow)$/.test(entity.name||''))return
    entity.publicShooterId=projectileShooterId(packet.objectData)
    const opponent=session&&bot.players[session.opponent]?.entity
    const shotVisible=!mechanicalEnabled||Boolean(bot.entity&&clearPath(
      bot.entity.position.offset(0,bot.entity.eyeHeight||1.62,0),entity.position))
    if(mechanicalEnabled&&session?.active&&shotVisible)log('visible-projectile',{matchId:session.id,tick,
      entityId:entity.id,shooterId:entity.publicShooterId,own:entity.publicShooterId===bot.entity.id,
      opponent:entity.publicShooterId===opponent?.id})
    if(opponent&&shotVisible&&(entity.publicShooterId===opponent.id
        ||!mechanicalEnabled&&entity.publicShooterId==null&&entity.position.distanceTo(opponent.position)<2)){
      if(mechanicalEnabled)noteBowShot(session,tick)
      session.targetFired=true;session.targetRangedEvent=(session.targetRangedEvent||0)+1
      if(legacyEnabled)legacyRevision++
    }
    })
  })
  bot.on('messagestr',message=>{
    if(Date.now()-authAt<1500)return
    if(/\/register/i.test(message)){authAt=Date.now();bot.chat('/register '+password+' '+password)}
    else if(/\/login/i.test(message)){authAt=Date.now();bot.chat('/login '+password)}
    // Never journal authentication chat or credentials.
  })
  bot.on('kicked',reason=>{
    const message=JSON.stringify(reason).replaceAll(password,'[redacted]')
    if(/too many packets|exceeded_packet_rate|sending.*packets/i.test(message))reconnectDelay=30000
    log('kicked',{reason:message,reconnectDelay})
  })
  bot.on('error',e=>log('client-error',{error:e.code||e.message}))
  bot.on('end',reason=>{
    log('disconnected',{reason});use=null;nativeSelf=null;latest=null
    if(session?.active){
      session.invalid=true;session.active=false;decisionDispatch.cancel()
      if(legacyEnabled){legacyEpoch++;legacyFrame=null;legacyLastEffect=null}
      void finishBout(session,{winner:'',reason:'client-disconnected',hadFrames:true})
    }
    if(!closing)setTimeout(connect,reconnectDelay)
  })
}
if(legacyEnabled)brain.ready.then(()=>{modelReady=true;policySha=brain.runtime.sha
  fs.writeFileSync(path.join(runtime,'model-status.json'),JSON.stringify({ready:true,controlRegime,
    checkpointSha256:policySha,teacherTacticsSha256:brain.runtime.modelSha,neuralWeightsLoaded:false}))
}).catch(error=>log('legacy86-start-error',{error:String(error)}))
modelConnect();connect()
setInterval(()=>{
  if(!bot?.entity)return
  const status={tick,shieldUntil,use,
    active:session?.active,matchId:session?.id,mode:session?.state?.mode,controllerCode,controlRegime,nativeSelf,
    ...(legacyEnabled?{legacyStats:{...legacyStats,decisionMs:undefined},outputGate:legacyOutput.counts,
      outboundPacketsLastSecond:legacyPacketTimes.filter(at=>at>=monoMs()-1000).length,
      peakOutboundPacketsPerSecond:legacyPeakPacketRate,planner:routePlanner.stats,collisionCache:legacyBlocks.stats}:{}),
    performance:{realtimeScheduling,eventLoopP99Ms:eventLoopDelay.percentile(99)/1e6,eventLoopMaxMs:eventLoopDelay.max/1e6,
      journal:journal.stats},
    inventory:bot.inventory.slots.flatMap((i,slot)=>i?[{slot,name:i.name}]:[])}
  eventLoopDelay.reset()
  void fs.promises.writeFile(path.join(runtime,'client-state.json'),JSON.stringify(status)).catch(error=>log('state-write-error',{error:String(error)}))
  plugin({type:'heartbeat',modelReady:Boolean(modelReady&&policySha),policySha:policySha||'unknown'})
  if(Date.now()-lastHeartbeat>10000){lastHeartbeat=Date.now();model({command:'model_status',requestId:'Punengbho-periodic'})}
},1000)
function shutdown(){closing=true;void highRate?.close();void legacyLoop?.close();void routePlanner?.close();if(legacyEnabled)void brain.close();bot?.clearControlStates();socket?.end();bot?.quit('WaveDog controller shutdown');void journal.flush().finally(()=>setTimeout(()=>process.exit(),100));setTimeout(()=>process.exit(),3000).unref()}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown)
