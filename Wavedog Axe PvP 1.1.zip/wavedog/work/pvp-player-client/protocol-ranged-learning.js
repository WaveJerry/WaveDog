'use strict'
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process')
function createRangedLearning({root,runtime,log,spawnProcess=spawn}){
  let busy=false
  return {
    profile(){
      const file=path.join(runtime,'ranged-calibration.json')
      if(!fs.existsSync(file))return null
      const value=JSON.parse(fs.readFileSync(file))
      if(value.schema!=='public-motion-lead-calibration-v1'||value.futureObservationsInLiveInput!==false)
        throw Error('Invalid ranged prediction profile')
      return value
    },
    completed(opponent,invalid){
      if(invalid||busy||!opponent||/probe|wavedogson|nbot/i.test(opponent))return false
      busy=true
      const child=spawnProcess(process.env.WAVEDOG_PYTHON||'python',
        [path.join(root,'work/wavedog-protocol/fit-ranged-calibration.py'),'--publish-runtime'],
        {cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']})
      let output='',error=''
      child.stdout.on('data',d=>{output=(output+d).slice(-16000)})
      child.stderr.on('data',d=>{error=(error+d).slice(-2000)})
      child.on('error',e=>{busy=false;log('ranged-calibration-error',{error:String(e)})})
      child.on('close',code=>{
        busy=false
        if(code!==0){log('ranged-calibration-not-published',{code,error});return}
        try{const r=JSON.parse(output.trim().split('\n').at(-1))
          log('ranged-calibration-saved',{bouts:r.bouts,samples:r.samples,acceptedBuckets:r.acceptedBuckets,
            applyFromNextBout:true,liveArrowAccuracyVerified:false})
        }catch(e){log('ranged-calibration-error',{error:String(e)})}
      })
      return true
    }
  }
}
module.exports={createRangedLearning}
