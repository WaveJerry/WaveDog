'use strict'
const assert=require('node:assert/strict')
const {Vec3}=require('vec3')
const mc=require('minecraft-data')('1.21.1')
const Block=require('prismarine-block')('1.21.1')
const {createCriticalEntryPredictor,controlsAt}=require('./protocol-pilot-critical-entry')
const {Physics,PlayerState}=require('prismarine-physics')
function fixture({distance=1.5,velocity=0,wall=false,ceiling=false}={}){
  const bot={version:'1.21.1',registry:mc,jumpTicks:0,jumpQueued:false,inventory:{slots:[]},
    entity:{position:new Vec3(0,0,0),velocity:new Vec3(0,-.0784,0),onGround:true,
      yaw:0,pitch:0,eyeHeight:1.62,effects:{},attributes:{}},
    world:{raycast:()=>null},blockAt(p){
      const q=p.floored(),solid=q.y<0||ceiling&&q.y>=2||wall&&q.z<=-1
      const b=Block.fromStateId(solid?mc.blocksByName.stone.minStateId:0,0)
      b.position=q;return b
    }}
  const target={position:new Vec3(0,0,-distance),width:.6,height:1.8}
  const o={tick:10,held:0,ground:true,visible:true,charge:.12,reach:Math.max(0,distance-.3),
    targetGrounded:true,targetVelocity:{x:0,y:0,z:-velocity}}
  return {bot,o,target,predictor:createCriticalEntryPredictor(bot)}
}
let x=fixture(),p=x.predictor.predict(x.o,x.target)
assert(p.eligible,'nearby stationary opponent has a charged descending opener')
assert(p.route.prepTicks<=2&&p.hitInTicks<=16)
assert(p.predictedCharge>.9&&p.worstReach<=2.8)
assert.equal(x.bot.entity.position.y,0,'look-ahead never moves the live entity')
assert.equal(x.bot.jumpQueued,false,'look-ahead never queues a live jump')
const timings=[p.predictionMs]
const attributes={'minecraft:generic.movement_speed':{value:.1,modifiers:[]},
  'minecraft:movement_speed':{value:.1,modifiers:[]},'generic.movementSpeed':{value:.1,modifiers:[]}}
x.bot.entity.attributes=structuredClone(attributes)
x.predictor.predict(x.o,x.target)
assert.deepEqual(x.bot.entity.attributes,attributes,'forecast sprint modifiers cannot alter live attributes')
for(const distance of [1.2,1.8,2.4]){
  x=fixture({distance});p=x.predictor.predict(x.o,x.target);timings.push(p.predictionMs)
  assert(p.eligible,'close opener remains feasible '+distance)
}
x=fixture({distance:4.5});assert(!x.predictor.predict(x.o,x.target).eligible,'far counter contact cancels before takeoff')
x=fixture({distance:3,velocity:.45});assert(!x.predictor.predict(x.o,x.target).eligible,'escaping target is not chased by a blind jump')
x=fixture({ceiling:true});assert(!x.predictor.predict(x.o,x.target).eligible,'low ceiling cannot invent a critical window')
x=fixture();assert(!x.predictor.predict({...x.o,targetShieldRaised:true},x.target).eligible,'static shield is not a forced break')
const route={startTick:10,yaw:0,prepTicks:1,driveTicks:4}
assert(!controlsAt(route,0,true).jump)
assert(controlsAt(route,1,true).jump&&controlsAt(route,1,true).sprint)
assert(!controlsAt(route,5,false).forward&&!controlsAt(route,5,false).jump,'short hop releases drive, never edits velocity')
for(const distance of [1.2,1.8,2.4]){
  const live=fixture({distance}),world={getBlock:q=>live.bot.blockAt(q)},engine=Physics(mc,world)
  let selected=null,attacked=false,seenAir=false
  for(let elapsed=0;elapsed<16;elapsed++){
    const b=live.bot,position=b.entity.position,eye=position.offset(0,1.62,0)
    const dx=Math.max(0,Math.abs(eye.x-live.target.position.x)-.3)
    const dz=Math.max(0,Math.abs(eye.z-live.target.position.z)-.3)
    const dy=Math.max(0,eye.y-live.target.position.y-1.8,live.target.position.y-eye.y)
    const o={...live.o,tick:10+elapsed,ground:b.entity.onGround,
      charge:Math.min(1,.12+elapsed/12.5),reach:Math.hypot(dx,dy,dz)}
    if(seenAir&&!o.ground&&b.entity.velocity.y<0&&o.charge>.9&&o.reach<=3){attacked=true;break}
    const candidate=live.predictor.predict(o,live.target,selected)
    assert(candidate.eligible,'selected opener survives causal replanning '+distance+' tick '+elapsed)
    selected=candidate.route
    const step=new PlayerState(b,controlsAt(selected,o.tick-selected.startTick,o.ground))
    step.attributes=structuredClone(b.entity.attributes);step.yaw=selected.yaw
    engine.simulatePlayer(step,world).apply(b);seenAir||=!b.entity.onGround
  }
  assert(attacked,'chosen route actually reaches a charged falling contact in vanilla simulation')
}
console.log('CRITICAL_ENTRY_PHYSICS_PASS',JSON.stringify({predictionMs:timings}))
module.exports={fixture}
