'use strict'
// Packet adapter for learned inputs. No counter, retreat, range-maintaining,
// automatic shield, automatic bow release, weapon or dodge controller.
function modelRelativeView(eye,target,yawOffset,pitchOffset,exactBoxAim=false){
  const p=target.position,half=(target.width||.6)/2,height=target.height||1.8,epsilon=.0001
  const point=exactBoxAim?require('./protocol-mechanical-math').nearestHitPointExact(eye,target):{x:Math.max(p.x-half+epsilon,Math.min(p.x+half-epsilon,eye.x)),
    y:Math.max(p.y+epsilon,Math.min(p.y+height-epsilon,eye.y)),
    z:Math.max(p.z-half+epsilon,Math.min(p.z+half-epsilon,eye.z))}
  const dx=point.x-eye.x,dy=point.y-eye.y,dz=point.z-eye.z
  // Re-evaluate the chosen target-relative primitive against the latest
  // received public position. The network still chooses every view offset.
  return {yaw:Math.atan2(-dx,-dz)-yawOffset*Math.PI/180,
    pitch:Math.max(-Math.PI/2,Math.min(Math.PI/2,Math.atan2(dy,Math.hypot(dx,dz))-pitchOffset*Math.PI/180))}
}
function rayTargetPoint(eye,target,yaw,pitch){
  const p=target.position,h=(target.width||.6)/2
  const dir=[-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)]
  const mins=[p.x-h,p.y,p.z-h],maxs=[p.x+h,p.y+(target.height||1.8),p.z+h]
  const start=[eye.x,eye.y,eye.z];let near=0,far=3
  for(let i=0;i<3;i++){
    if(Math.abs(dir[i])<1e-10){if(start[i]<mins[i]||start[i]>maxs[i])return null;continue}
    const a=(mins[i]-start[i])/dir[i],b=(maxs[i]-start[i])/dir[i]
    near=Math.max(near,Math.min(a,b));far=Math.min(far,Math.max(a,b))
    if(far<near)return null
  }
  return {x:eye.x+dir[0]*near,y:eye.y+dir[1]*near,z:eye.z+dir[2]*near}
}
function executeCommand(ctx){
  const executionStarted=performance.now()
  const {bot,planned,frame,target,tick,session,look,aim,offhand,stopUse,getUse,setUse,plugin,onSwitch,onAttack}=ctx
  const c=planned.command,owners={...planned.owners},packets=[],rangedResult={},ignore=new Set([8])
  const client=bot._client,write=client.write
  client.write=function(n,d){packets.push(n);return write.call(this,n,d)}
  let attacked=false,switched=false,rejected=null,executedAttackId=null,attackHeld=null,attackItemName=null,attackCharge=null,relativeViewRefreshed=false,attackGeometry=null
  try{
    const fresh=owners.attack==='neural'
    const staleWeapon=Number.isSafeInteger(c.observedWeaponEpoch)&&c.observedWeaponEpoch!==ctx.weaponEpoch
    if(staleWeapon){owners.mainhand='stale-weapon-observation';ignore.add(5)}
    const repeated=session.attackedDecisions.has(c.decidedTick)
    const stale=c.decidedTick<=ctx.lastAttackTick
    const doAttack=Boolean(c.attack&&!repeated&&!stale&&!staleWeapon&&fresh)
    const heldOffhand=bot.inventory.slots[45]?.name
    const useItem=c.slot===1?'bow':c.slot===4?'crossbow':
      ['bow','crossbow'].includes(heldOffhand)?heldOffhand:null
    const wanted=fresh&&!c.release?(c.shield&&tick>=ctx.shieldUntil?'shield':c.use?useItem:null):null
    if([1,4].includes(c.slot)&&!(c.use&&wanted===useItem))ignore.add(5)
    let current=getUse()
    // A model cancelling its shield request must really release it on wire;
    // otherwise the client starts running while the server still uses shield.
    if(!fresh||c.release||doAttack||current&&current.kind!==wanted)stopUse()
    if(fresh&&!staleWeapon&&[0,7].includes(c.slot)&&bot.quickBarSlot!==c.slot){
      stopUse();bot.setQuickBarSlot(c.slot);onSwitch();switched=true
    }
    if(fresh&&c.pureAimVersion===2&&frame.seen.visible&&target
        &&Number.isFinite(c.aimYawOffset)&&Number.isFinite(c.aimPitchOffset)){
      const p=bot.entity.position,eye={x:p.x,y:p.y+(bot.entity.eyeHeight||1.62),z:p.z}
      const view=modelRelativeView(eye,target,c.aimYawOffset,c.aimPitchOffset,ctx.exactBoxAim)
      look(view.yaw,view.pitch);relativeViewRefreshed=true
    }
    else if(fresh&&Number.isFinite(c.yaw)&&Number.isFinite(c.pitch))look((180-c.yaw)*Math.PI/180,-c.pitch*Math.PI/180)
    else ignore.add(6),ignore.add(7)
    for(const [key,value]of Object.entries({forward:c.forward>.5,back:c.forward<-.5,
      left:c.side<-.5,right:c.side>.5,jump:Boolean(c.jump),sneak:Boolean(c.sneak)}))bot.setControlState(key,value)
    current=getUse()
    if(wanted&&current&&current.kind!==wanted){stopUse();current=null}
    const using=Boolean(current||wanted)
    // Vanilla clears server sprint on a successful sprint strike; Mineflayer's
    // attack() only writes use_entity and leaves its local control bit set.
    // Refresh the wire state on the NEXT selected command. Never force a new
    // sprint if the model now wants a critical, item use or ordinary movement.
    if(session.sprintNeedsRearm){bot.setControlState('sprint',false);session.sprintNeedsRearm=false}
    bot.setControlState('sprint',Boolean(c.sprint&&c.forward>.5&&!using&&bot.food>6))
    if(Boolean(c.sprint)!==bot.getControlState('sprint'))ignore.add(1)
    if(wanted&&!doAttack){
      if(offhand(wanted)){
        current=getUse()
        if(current&&frame.nativeSelf&&tick-current.tick>=2&&frame.nativeSelf.receivedTick>current.tick&&!frame.nativeSelf.using){stopUse();current=null}
        if(!current){
          const firing=wanted==='crossbow'&&ctx.ownLoaded()
          bot.activateItem(true);setUse(firing?null:{kind:wanted,tick})
          if(firing){bot.usingHeldItem=false;rangedResult.fireSent=true}else rangedResult.useStarted=true
        }
      }else{ignore.add(4);if([1,4].includes(c.slot))ignore.add(5);owners.offhand='inventory-pending'}
    }
    if(c.attack){
      if(staleWeapon){rejected='stale-weapon-observation';owners.attack=rejected;ignore.add(4)}
      else if(repeated||stale){rejected=repeated?'cached-already-executed':'stale-before-last-attack';owners.attack=rejected;ignore.add(4)}
      else if(doAttack){
        const oldYaw=bot.entity.yaw,oldPitch=bot.entity.pitch
        try{
        if(c.flightLook&&target&&frame.seen.visible)aim(target,null,frame.targetVelocity)
        const p=bot.entity.position,eye={x:p.x,y:p.y+(bot.entity.eyeHeight||1.62),z:p.z}
        const hit=target&&frame.seen.visible&&rayTargetPoint(eye,target,bot.entity.yaw,bot.entity.pitch)
        const sent=ctx.getSentPosition?.()
        const wireEye=sent?{x:sent.x,y:sent.y+(bot.entity.eyeHeight||1.62),z:sent.z}:null
        const wireHit=wireEye&&target&&frame.seen.visible?rayTargetPoint(wireEye,target,bot.entity.yaw,bot.entity.pitch):null
        if(hit&&wireHit&&(!ctx.clearPath||ctx.clearPath(eye,hit)&&ctx.clearPath(wireEye,wireHit))){
          // Snapshot the actual public geometry used by the packet adapter.
          // The causal policy observation can be older than a target movement
          // received while inference was running. Never relabel that old state.
          attackGeometry={eye:{...eye},hit:{...hit},
            target:{x:target.position.x,y:target.position.y,z:target.position.z,
              width:target.width||.6,height:target.height||1.8},
            rayDistance:Math.hypot(hit.x-eye.x,hit.y-eye.y,hit.z-eye.z),
            wireEye,wireHit,wireRayDistance:wireHit?Math.hypot(wireHit.x-wireEye.x,wireHit.y-wireEye.y,wireHit.z-wireEye.z):null,
            observedReach:frame.observation.reach,source:'execution-public-box-and-sent-position-v1'}
          stopUse();const id=session.state.nextId++
          plugin({type:'attack_intent',matchId:session.id,attackId:id,kind:'neural',target:session.opponent})
          attackHeld=bot.quickBarSlot;attackItemName=bot.heldItem?.name||null
          attackCharge=ctx.charge?ctx.charge():null
          bot.attack(target);onAttack(id);attacked=true;executedAttackId=id;session.attackedDecisions.add(c.decidedTick)
          session.sprintNeedsRearm=bot.getControlState('sprint')
          ignore.delete(8) // Both choosing and declining a turn-back are real attack choices.
          session.attackOwners.set(id,{tick,kind:'neural',decidedTick:c.decidedTick,
            attackReach:frame.observation.reach})
        }else{rejected=!hit?'outside-range-or-aim':!wireEye?'unconfirmed-sent-position':
          !wireHit?'outside-sent-range-or-aim':'blocked-line-of-sight';owners.attack=rejected;ignore.add(4)}
        }finally{
          if(c.flightLook){look(oldYaw,oldPitch);ignore.delete(8)}
        }
      }
    }
    if(!fresh)for(let i=0;i<9;i++)ignore.add(i)
    return {owners,packets,attacked,switched,rejected,executedAttackId,attackHeld,attackItemName,attackCharge,attackGeometry,
      attackSuppressedReason:rejected,executionMs:performance.now()-executionStarted,ignoredHeads:[...ignore],
      shieldRequested:Boolean(c.shield),controls:Object.fromEntries(['forward','back','left','right','sprint','jump','sneak'].map(k=>[k,bot.getControlState(k)])),
      held:bot.quickBarSlot,using:getUse()?.kind||null,offhand:bot.inventory.slots[45]?.name||null,rangedResult,
      relativeViewRefreshed,executedView:{yaw:(180-bot.entity.yaw*180/Math.PI),pitch:-bot.entity.pitch*180/Math.PI}}
  }finally{client.write=write}
}
module.exports={executeCommand,rayTargetPoint,modelRelativeView}
