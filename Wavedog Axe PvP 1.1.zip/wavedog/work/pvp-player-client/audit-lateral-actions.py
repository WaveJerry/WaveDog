"""Count executed lateral movement during ordinary selfplay and visible arrows."""
from pathlib import Path
from collections import Counter
import gzip
import json
import sys

root = Path(__file__).resolve().parent / "new-learning/selfplay/frame-bouts"
limit = int(sys.argv[1]) if len(sys.argv) > 1 else 30
files = sorted(root.glob("*.json.gz"), key=lambda p: p.stat().st_mtime)[-limit:]
totals = Counter()
for file in files:
    try:
        bout = json.loads(gzip.decompress(file.read_bytes()))
    except (OSError, json.JSONDecodeError):
        continue
    for fighter in bout.get("fighters", {}).values():
        frames = {row.get("frame"): row for row in fighter.get("frames", [])}
        for action in fighter.get("actions", []):
            frame = frames.get(action.get("frame"))
            if not frame:
                continue
            seen = frame.get("seen", {})
            own = frame.get("self", {})
            dx = own.get("x", 0) - seen.get("x", 0)
            dz = own.get("z", 0) - seen.get("z", 0)
            distance = (dx * dx + dz * dz) ** .5
            arrow = bool(seen.get("arrows"))
            region = "arrow-visible" if arrow else "far" if distance >= 4.5 else "close"
            executed = action.get("executed", {})
            selected = action.get("selected", {})
            totals[(region, "actions")] += 1
            totals[(region, "lateralSelected")] += abs(selected.get("side", 0)) > .5
            totals[(region, "lateralExecuted")] += bool(executed.get("left") or executed.get("right"))
            totals[(region, "jumpExecuted")] += bool(executed.get("jump"))
            totals[(region, "forwardExecuted")] += bool(executed.get("forward"))
print(json.dumps({"bouts": len(files), "regions": {
    region: {key: totals[(region, key)] for key in
        ("actions", "lateralSelected", "lateralExecuted", "jumpExecuted", "forwardExecuted")}
    for region in ("close", "far", "arrow-visible")}}, ensure_ascii=False))
