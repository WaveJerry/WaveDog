'use strict'
const assert=require('node:assert/strict')
const {createBrain,createState}=require('./protocol-legacy86-brain')
const {frame,probe}=require('./test-legacy86-control')
const baseResult={phase:'AIR_INTERRUPT',counterHopActive:false,hasPendingAttack:false,
  decision:{motion:'FORWARD',sprint:true,jump:true,sneak:false,attack:true,shield:false,
    faceAway:false,offhand:'SHIELD',weapon:'SWORD',technique:'AXE_EARLY'}}
const runtime={ready:Promise.resolve(),request:async row=>row.command==='reset'?{reset:true}:structuredClone(baseResult),close:async()=>{}}
const air={valid:true,threat:true,action:'no-guaranteed-route',risingTail:true,jumpResetPossible:false,
  criticalTicks:[0],envelope:[{radius:.1}],route:{heading:{x:-1,z:0},sprint:true,safe:false,clearance:0}}
let nextAir=air
const planner={evaluate:async()=>({airPlan:structuredClone(nextAir),spacing:null})}
async function run(){
  const b=createBrain({runtime,planner}),s=createState('enemy');s.swordOnly=true
  await b.reset(s,123)
  const close=()=>frame({seen:{x:1.5,y:.7},targetVelocity:{x:-.1,y:-.1,z:0},self:{ground:false,critical:true,vy:-.1,charge:1},
    observation:{tick:100,reach:1.2,otherReach:1.2,targetAirborne:true,targetGrounded:false}})
  const before={version:s.decisionVersion,airDefense:s.airDefense,airPastInterrupt:s.airPastInterrupt,nextId:s.nextId}
  const preview=await b.decide(s,close(),probe,100,{preview:true,transactional:true})
  assert.equal(s.airDefense,before.airDefense,'read-only preview cannot latch live air defense')
  assert.equal(s.airPastInterrupt,before.airPastInterrupt,'read-only preview cannot veto later live interrupts')
  assert.equal(s.nextId,before.nextId,'unexecuted preview cannot consume attack IDs')
  assert.equal(s.decisionVersion,before.version)
  assert(preview.command.attack&&preview.command.critical,'point-blank contact must retain an available falling critical')
  assert(preview.command.jump,'failed escape cannot erase the original contact jump choice')
  assert.equal(preview.command.worldHeading,null,'do not attach a contradictory flee heading to contact damage')
  const current=await b.decide(s,close(),probe,100,{transactional:true})
  assert(b.commitDecision(s,current))
  assert(s.airDefense&&s.airPastInterrupt)
  assert(!b.commitDecision(s,preview),'an older preview must not overwrite accepted controller state')
  assert.equal(s.decisionVersion,1)
  const edge=await b.decide(s,frame({self:{ground:false,critical:true,vy:-.1},seen:{x:3.29,y:.7},targetVelocity:{x:-.1,y:-.1,z:0},
    observation:{tick:101,reach:2.99,targetAirborne:true,targetGrounded:false}}),probe,101,{transactional:true})
  assert.notEqual(edge.selectedBranch,'contact-escape-unavailable',
    'a conservative uncertainty envelope at the range boundary must not declare close combat')
  assert(edge.command.attack,'an unsafe escape cannot veto the original legal edge interrupt')
  assert.equal(b.publicInput(s,{...close(),airPlan:structuredClone(air)},101,false).senses.wallEscapeAvailable,false,
    'a known-unsafe route must not be reported to the original controller as an available escape')
  assert.equal(s.decisionVersion,1,'a rejected edge proposal must remain isolated too')
  nextAir={...air,action:'interrupt',risingTail:false,route:{...air.route,safe:true}}
  const late=await b.decide(s,close(),probe,101,{transactional:true})
  assert.equal(late.airPlan.action,'dodge','late velocity must not reopen an expired interrupt window')
  assert(late.command.attack&&late.command.jump&&late.selectedBranch==='close-sword-dps',
    'the user-requested committed point-blank DPS episode must not switch back to retreat before leaving reach')
  nextAir={...air,threat:false,action:'spacing'}
  const unsafeHold=await b.decide(s,close(),probe,102,{transactional:true})
  assert.equal(unsafeHold.airPlan.action,'no-guaranteed-route',
    'a retained airborne defense cannot turn an unsafe route into a successful dodge')
  assert(unsafeHold.command.attack,'an unsafe held route cannot veto the contact reply')
  // A rejected proposal cannot spend an offhand synchronization event either.
  nextAir={valid:false,threat:false,action:'spacing',criticalTicks:[],envelope:[],route:null}
  const rangedBefore=structuredClone(s.rangedSync)
  const shot=await b.decide(s,frame({seen:{x:8},observation:{tick:103,reach:7.7,
    targetShotEvent:1,targetShotTick:103,loaded:true,arrows:5}}),probe,103,{preview:true,transactional:true})
  assert.equal(shot.command.ranged,'fire-crossbow')
  assert.deepEqual(s.rangedSync,rangedBefore,'uncommitted preview cannot consume or start a ranged cycle')
  const landing=await b.decide(s,frame({observation:{tick:104}}),probe,104,{transactional:true})
  assert(b.commitDecision(s,landing))
  assert(!s.airDefense&&!s.airPastInterrupt,'observed landing clears the committed airborne phase')
  assert(!b.commitDecision(s,shot),'a stale ranged preview cannot resurrect use after landing')
  await b.close();console.log('PREVIEW_STATE_ISOLATION_AND_NO_ESCAPE_CONTACT_PASS')
}
run().catch(error=>{console.error(error);process.exitCode=1})
