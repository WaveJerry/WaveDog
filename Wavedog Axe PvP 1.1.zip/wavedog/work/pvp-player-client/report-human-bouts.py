"""Write a readable index for actual human-versus-GRU bouts."""
from collections import Counter
from datetime import datetime
from pathlib import Path
import json


STORE = Path(__file__).resolve().parent / 'new-learning' / 'selfplay'
OUTPUT = STORE / 'HUMAN-BOUTS.md'


def rows(name):
    path = STORE / name
    if not path.exists():
        return []
    result = []
    with path.open(encoding='utf-8') as stream:
        for line in stream:
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return result


def timestamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def main():
    bouts = rows('human-challenges.jsonl')
    archives = {row['matchId']: row for row in rows('human-native-events.jsonl')}
    reviewed = {row.get('matchId') for row in rows('shared-lessons.jsonl')
                if row.get('source') == 'human-challenge-Qwen'}
    invalid = {row.get('matchId') for row in rows('quality-flags.jsonl')
               if row.get('status') == 'mechanics-invalid'}
    lines = ['# 真人对局记录', '',
             '数据来源：主服原生裁判逐事件日志、真人挑战结果和 GRU 更新回执。'
             '命中指未取消且实际造成大于 0 伤害的原生事件；暴击候选不计作已确认暴击。', '',
             '| 局 | 时间（北京时间） | 分身 | 胜者 | 时长 | 双方有效近战命中 | 双方破盾 | 双方箭伤 | GRU | Qwen | 机制验收 |',
             '| --- | --- | --- | --- | ---: | --- | --- | --- | --- | --- | --- |']
    for report in bouts:
        archive = archives.get(report['matchId'])
        events = archive.get('events', []) if archive else []
        bot, human = report['bot'], report['opponent']
        melee = Counter(e.get('attacker') for e in events if e.get('type') == 'damage'
                        and e.get('source') == 'MELEE' and not e.get('cancelled') and e.get('amount', 0) > 0)
        breaks = Counter(e.get('attacker') for e in events if e.get('type') == 'shield_disable'
                         and not e.get('cancelled'))
        arrows = Counter(e.get('attacker') for e in events if e.get('type') == 'damage'
                         and e.get('source') == 'ARROW' and not e.get('cancelled') and e.get('amount', 0) > 0)
        seconds = '—'
        if events and events[0].get('type') == 'start' and events[-1].get('type') == 'end':
            seconds = f"{(timestamp(events[-1]['at']) - timestamp(events[0]['at'])).total_seconds():.1f}s"
        local = timestamp(report['at']).astimezone().strftime('%m-%d %H:%M:%S')
        updates = report.get('training') or {}
        trained = (str(updates.get('gradient_updates_after', 0) - updates.get('gradient_updates_before', 0))
                   if updates.get('event') == 'trained' else '部分/无')
        qwen = '已复盘' if report['matchId'] in reviewed else '待复盘'
        quality = '无效：盾速异常' if report['matchId'] in invalid else '待完整验收'
        number = report['matchId'].rsplit(':', 1)[-1]
        lines.append(f"| {number} | {local} | {bot} | {report['winner']} | {seconds} | "
                     f"{melee[bot]}/{melee[human]} | {breaks[bot]}/{breaks[human]} | "
                     f"{arrows[bot]}/{arrows[human]} | {trained} 次更新 | {qwen} | {quality} |")
    lines.extend(['', '斜杠左侧为分身，右侧为真人。逐事件记录在 `human-native-events.jsonl`；'
                  '每局的原始胜负、GRU 回执在 `human-challenges.jsonl`。', ''])
    OUTPUT.write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'bouts': len(bouts), 'archived': len(archives),
                      'reviewed': sum(x['matchId'] in reviewed for x in bouts),
                      'report': str(OUTPUT)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
