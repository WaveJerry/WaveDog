const assert=require('node:assert/strict')
const {solveRangedAim,learnedLead}=require('./protocol-ranged-aim')
function trial(extra={}){
  const c={eye:{x:0,y:1.52,z:0},feet:{x:0,y:0,z:20},motion:{x:.2,y:0,z:0},floorY:0,speed:3, ...extra}
  const result=solveRangedAim(c);assert(result)
  let p={...c.eye},v=Object.fromEntries(['x','y','z'].map(k=>[k,result.direction[k]*c.speed+(c.inherited?.[k]||0)]))
  for(let t=0;t<Math.floor(result.flightTicks);t++){
    for(const k of ['x','y','z'])p[k]+=v[k]
    for(const k of ['x','z'])v[k]*=.99
    v.y=v.y*.99-.05
  }
  const fraction=result.flightTicks-Math.floor(result.flightTicks)
  for(const k of ['x','y','z'])p[k]+=fraction*v[k]
  assert(Math.abs(p.x-(c.feet.x+c.motion.x*result.flightTicks))<.001)
  assert(Math.abs(p.z-(c.feet.z+c.motion.z*result.flightTicks))<.001)
  if(!c.airborne)assert(Math.abs(p.y-(c.feet.y+.99))<.001)
  return {p,result}
}
trial()
trial({inherited:{x:.25,y:0,z:-.1},speed:3})
trial({speed:3.15,motion:{x:-.25,y:0,z:.1}})
const falling=trial({feet:{x:0,y:1,z:24},motion:{x:.15,y:-.4,z:0},airborne:true})
assert(Math.abs(falling.p.y-.99)<.001,'falling target lands on public floor')
const apex=trial({feet:{x:0,y:1.2,z:24},motion:{x:.1,y:0,z:0},airborne:true})
assert(apex.p.y<2.19,'airborne apex must not be mistaken for standing still')
assert.equal(solveRangedAim({eye:{x:0,y:0,z:0}}),null,'unknown geometry cannot fabricate a solution')
assert.equal(learnedLead({buckets:{'ground:medium':{lead:1.4,accepted:false}}},false,6),1)
assert.equal(learnedLead({buckets:{'ground:medium':{lead:1.4,accepted:true}}},false,6),1.4)
console.log('RANGED_INTERCEPT_INHERITANCE_LANDING_AND_CALIBRATION_PASS')
