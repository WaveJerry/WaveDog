const assert=require('node:assert/strict')
const {createState,receipt,plan,applied,rangedApplied}=require('./protocol-pilot-mechanical-brain')
const {orbitGoal,orbitHeading,headingKeys}=require('./protocol-mechanical-math')
const obs=(over={})=>({tick:10,ground:true,visible:true,distance:3,reach:2.7,
  health:20,self:{x:0,z:2},sentPosition:{x:0,z:2},target:{x:0,z:0},targetYaw:0,
  shieldReady:true,shieldEffective:true,offhandShieldReady:true,targetShieldFacing:false,
  targetFacingDot:1,openingDraw:1,charge:1,held:7,wallMargin:8,...over})
const neural={decidedTick:10,forward:1,side:1,sprint:true,jump:true,attack:true,slot:0}
const waiting=createState()
receipt(waiting,{type:'blocked_melee',blockId:98},10)
receipt(waiting,{type:'shield_disabled',cooldownTicks:100},10)
const issued=plan(waiting,obs({shieldReady:false}),neural)
assert.equal(issued.command.afterAttackSlot,undefined,'next weapon belongs to the model')
applied(waiting,issued.command,true,10)
const beforeNativeHit=plan(waiting,obs({tick:11,shieldReady:false,held:0}),null)
assert.equal(beforeNativeHit.mode,'NEURAL','actual counter packet hands off before damage acknowledgement')
assert.equal(beforeNativeHit.command.slot,null,'no mechanical weapon choice while waiting for a fresh model reply')
assert.equal(beforeNativeHit.command.attack,false,'waiting must not duplicate the counter')
receipt(waiting,{type:'damage',attacker:'WaveDog',victim:'opponent',attackId:issued.command.attackId,amount:2},11)
assert.equal(waiting.mode,'NEURAL','native hit records outcome without resurrecting escape')
let s=createState(), p=plan(s,obs({targetShieldFacing:true}),neural)
assert.equal(p.mode,'GUARD');assert.equal(p.command.attack,false);assert.equal(p.command.jump,false)
receipt(s,{type:'blocked_melee',blockId:5},10)
p=plan(s,obs(),neural);assert.equal(p.command.kind,'counter');const id=p.command.attackId
receipt(s,{type:'damage',attackId:id+1,amount:5},10)
assert.equal(s.mode,'COUNTER','unrelated damage never claims counter')
receipt(s,{type:'shield_disabled',cooldownTicks:100},10)
receipt(s,{type:'damage',attacker:'WaveDog',victim:'opponent',attackId:id,amount:5},10)
assert.equal(s.mode,'COUNTER','intent without actual packet cannot claim damage')
receipt(s,{type:'attack_packet',attackId:id,willAttack:true},10)
receipt(s,{type:'damage',attacker:'WaveDog',victim:'opponent',attackId:id,amount:5},10)
assert.equal(s.mode,'NEURAL')
p=plan(s,obs({tick:11,shieldReady:false,held:0}),{...neural,decidedTick:11,jump:false})
assert.equal(p.command.slot,0);assert.equal(p.command.jump,false);assert(!p.command.aimAway)
const blockedTakeoff=createState();blockedTakeoff.mode='ESCAPE';blockedTakeoff.escapeAt=10
let delayed=plan(blockedTakeoff,obs({tick:11,shieldReady:false,held:7}),null)
assert.equal(delayed.mode,'NEURAL','obsolete escape state cannot execute a mechanical hop')
assert.equal(delayed.command.slot,null);assert.equal(delayed.command.jump,false)
delayed=plan(blockedTakeoff,obs({tick:16,shieldReady:false,held:0}),{...neural,decidedTick:16})
assert.equal(delayed.mode,'NEURAL','blocked takeoff cannot create an indefinite mechanical wait')
p=plan(s,obs({tick:12,shieldReady:false,ground:false,mutualOutOfReach:true}),{...neural,decidedTick:12})
assert.equal(p.mode,'NEURAL');assert.equal(p.owners.movement,'neural');assert.equal(p.command.forward,1)
assert.equal(p.command.slot,0,'no forced axe at early handoff')
p=plan(s,obs({tick:20,shieldReady:false}),neural)
assert.equal(p.command.forward,0,'expired movement goes neutral');assert.equal(p.command.attack,false)
p=plan(s,obs({tick:111,shieldEffective:false,reach:7.7,distance:8,mutualOutOfReach:true}),null);assert.equal(p.mode,'SHIELD_RETURN')
p=plan(s,obs({tick:116,reach:7.7,distance:8,mutualOutOfReach:true}),null);assert.equal(p.mode,'GUARD')
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,targetShieldFacing:true}),neural)
assert.equal(p.command.kind,'neural');assert.equal(p.command.slot,0)
assert.equal(p.owners.mainhand,'neural','an enemy shield cannot force the main-hand weapon')
assert.equal(p.owners.attack,'neural','shield breaking belongs to the learned action')
assert.equal(p.owners.movement,'neural')
applied(s,p.command,true)
p=plan(s,obs({tick:11,shieldReady:false,targetShieldFacing:true}),{...neural,attack:false,decidedTick:11})
assert.equal(p.command.attack,false,'an enemy shield cannot force an attack')
assert.equal(p.command.slot,0,'an enemy shield cannot force an axe switch')
const escape=createState();escape.mode='ESCAPE';escape.escapeAt=10
const beforeShield=plan(escape,obs({shieldReady:false,targetShieldFacing:true}),{...neural,attack:false})
assert.equal(beforeShield.command.slot,0,'next sword selection comes from the supplied model action')
assert.equal(beforeShield.owners.mainhand,'neural')
assert.equal(beforeShield.command.attack,false,'escape cannot inject a forced shield break')
s=createState();p=plan(s,obs({distance:12,reach:11,arrows:5}),null)
assert.equal(p.command.ranged,null,'never autonomous reload')
p=plan(s,obs({tick:11,distance:12,reach:11,arrows:5,targetLoading:true}),null)
assert.equal(p.command.ranged,'load-crossbow')
receipt(s,{type:'blocked_melee',blockId:9},12)
p=plan(s,obs({tick:12,arrows:5,targetLoading:true}),null)
assert.equal(p.command.kind,'counter');assert.equal(p.command.ranged,null,'reload cannot swallow counter')
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,arrowThreat:{time:2,side:-1,jump:true}}),neural)
assert.equal(p.command.attack,false);assert.equal(p.owners.movement,'mechanical-arrow')
assert.equal(p.mode,'NEURAL','arrow overlay leaves base state intact')
s=createState();s.mode='ESCAPE';s.escapeAt=1
p=plan(s,obs({tick:9,shieldReady:false}),{...neural,decidedTick:9})
assert.equal(p.mode,'NEURAL','blocked takeoff has no fixed-distance retreat fallback')

// Regression: the real failed bout swapped to the crossbow at t, then swapped
// back at t+1 before its async equip ever emitted a use packet.
s=createState()
for(let t=10;t<14;t++){
  p=plan(s,obs({tick:t,distance:12,reach:11,loaded:true,targetShotEvent:1,targetShotTick:10}),null)
  assert.equal(p.command.ranged,'fire-crossbow','keep intent while inventory swap awaits acknowledgement')
  assert.equal(p.command.shield,false)
  rangedApplied(s,p.command,{},t)
}
rangedApplied(s,p.command,{fireSent:true},13)
for(let t=14;t<60;t++){
  p=plan(s,obs({tick:t,distance:12,reach:11,loaded:true,targetShotEvent:1,targetShotTick:10}),null)
  assert.equal(p.command.ranged,null,'one confirmed shot cannot repeat on stale loaded metadata')
  assert.equal(p.command.shield,true,'restore guard after actual use packet')
}
p=plan(s,obs({tick:61,distance:12,reach:11,loaded:true,targetKnownLoaded:true,targetRanged:true}),null)
assert.equal(p.command.ranged,null,'holding a loaded opponent crossbow is not a fresh fire event')
p=plan(s,obs({tick:62,distance:12,reach:11,loaded:true,targetShotEvent:2,targetShotTick:62}),null)
assert.equal(p.command.ranged,'fire-crossbow','fresh public ranged event can authorize a new response')
p=plan(s,obs({tick:63,loaded:true,targetShotEvent:2,targetShotTick:62,arrowThreat:{time:6,side:1}}),null)
assert.equal(p.command.ranged,null);assert.equal(p.command.shield,true)

s=createState()
const orbitObs=obs({distance:.8,reach:.5,targetShieldFacing:true,targetYaw:0,targetFacingDot:1,
  self:{x:0,z:-1},sentPosition:{x:0,z:-1},target:{x:0,z:0},targetGrounded:true,orbitDraw:0,orbitSide:-1})
p=plan(s,orbitObs,neural)
assert(p.command.worldHeading);assert.equal(p.command.orbit,true);assert.equal(p.command.shield,false)
assert.equal(p.command.jump,false)
const goal=orbitGoal(0,true),heading=orbitHeading(orbitObs.self,orbitObs.target,goal)
assert(Math.abs(goal.x-.175)<1e-9);assert(Math.abs(goal.z-.3031088913245535)<1e-9)
assert.deepEqual(p.command.worldHeading,heading)
assert.deepEqual(headingKeys({x:0,z:-1},0),{forward:1,side:0})
assert.deepEqual(headingKeys({x:-1,z:0},0),{forward:0,side:-1})
assert.deepEqual(headingKeys({x:1,z:0},0),{forward:0,side:1})
applied(s,p.command,false,10)
receipt(s,{type:'damage',victim:'WaveDog',attacker:'opponent',melee:true,amount:2,cancelled:false},10)
p=plan(s,obs({tick:11,targetShieldFacing:false,targetCriticalThreat:false,ground:false}),neural)
assert.equal(p.command.kind,'orbit-reply','original orbit wound reply also works after knockback lifts the body')
assert.equal(p.command.attack,true);assert.equal(p.command.shield,false)
applied(s,p.command,true,11)
p=plan(s,obs({tick:12,targetShieldFacing:false}),neural)
assert.equal(p.command.attack,false,'exactly one orbit retaliation');assert.equal(p.command.shield,true)

s=createState();p=plan(s,orbitObs,null);applied(s,p.command,false,10)
p=plan(s,obs({tick:11,targetFacingDot:-.2,targetShieldFacing:false}),null)
assert.equal(p.command.kind,'orbit-rear','actual rear opening ends the original orbit with a hit')
// An observed shot at a ranged gap authorizes synchronization; impossible
// neural swings and main-hand choices cannot interrupt the mechanical reply.
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,held:0,distance:7,reach:6.7,
  loaded:true,targetShotEvent:1,targetShotTick:10}),{...neural,slot:7})
assert.equal(p.command.ranged,'fire-crossbow')
assert.equal(p.command.slot,0)
assert.equal(p.command.attack,false)
assert.equal(p.owners.attack,'mechanical-ranged')
assert.equal(p.owners.mainhand,'mechanical-ranged')
assert.equal(p.owners.movement,'neural','ranged use does not replace learned movement')
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,held:0,distance:7,reach:6.7,
  targetLoading:true,loaded:false,arrows:5,rangedEvent:1}),{...neural,slot:7})
const rangedId=p.command.rangedId
assert.equal(p.command.ranged,'load-crossbow')
p=plan(s,obs({tick:11,shieldReady:false,held:0,distance:7,reach:6.7,
  targetLoading:true,loaded:false,arrows:5,rangedEvent:1}),{...neural,decidedTick:11,slot:7})
assert.equal(p.command.rangedId,rangedId,'out-of-reach neural attack must not restart the load')
assert.equal(p.command.ranged,'load-crossbow')
p=plan(s,obs({tick:12,shieldReady:false,held:0,distance:2.8,reach:2.5,
  targetLoading:true,loaded:false,rangedEvent:1}),{...neural,decidedTick:12})
assert.equal(p.command.ranged,null,'an executable close melee decision preempts ranged use')
assert.equal(p.command.attack,true)

// Original close-range mirrors must not disappear behind a six-block gate.
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,held:0,distance:2.6,reach:2.3,
  targetLoading:true,loaded:false,arrows:5}),{...neural,attack:false})
assert.equal(p.command.ranged,'load-crossbow')
p=plan(s,obs({tick:11,shieldReady:false,held:0,distance:2.6,reach:2.3,
  targetLoading:true,loaded:false,arrows:5}),{...neural,decidedTick:11,attack:true})
assert.equal(p.command.ranged,null,'legal learned melee still preempts a close mirror')
assert(p.command.attack)
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,distance:3,reach:2.7,targetBow:true,arrows:5}),null)
assert.equal(p.command.ranged,'bow')
rangedApplied(s,p.command,{useStarted:true},10)
p=plan(s,obs({tick:11,shieldReady:false,distance:3,reach:2.7,targetBow:true,arrows:5}),null)
assert(!p.command.rangedRelease,'drawing alone cannot authorize a synchronized release')
p=plan(s,obs({tick:12,shieldReady:false,distance:3,reach:2.7,targetBow:false,arrows:5,
  targetShotEvent:1,targetShotTick:12}),null)
assert.equal(p.command.ranged,'bow')
assert(p.command.rangedRelease,'keep the bow for the shot frame, then release after aiming')
rangedApplied(s,p.command,{bowReleased:true},12)
p=plan(s,obs({tick:13,shieldReady:false,distance:3,reach:2.7,targetBow:false,arrows:5,
  targetShotEvent:1,targetShotTick:12}),null)
assert.equal(p.command.ranged,null,'one bow shot cannot be replayed')
s=createState();s.mode='NEURAL';s.shieldUntil=100
p=plan(s,obs({shieldReady:false,distance:8,reach:7.7,targetBow:true,arrows:5}),null)
rangedApplied(s,p.command,{useStarted:true},10)
p=plan(s,obs({tick:11,shieldReady:false,distance:8,reach:7.7,targetBow:true,arrows:5,
  targetShotEvent:1,targetShotTick:11,offhandShieldReady:false,arrowThreat:{time:3,side:-1}}),null)
assert.equal(p.command.ranged,'bow','a side dodge must not silently release/cancel the matching bow reply')
assert(p.command.rangedRelease&&p.command.keepLook)
assert.equal(p.command.side,-1)
assert.equal(p.owners.movement,'mechanical-arrow')
rangedApplied(s,p.command,{bowReleased:true},11)
assert.equal(s.spentShotEvent,1,'bow reply consumes the same public shot event as a crossbow reply')
s=createState();s.shieldUntil=100
receipt(s,{type:'blocked_melee',blockId:88},10)
p=plan(s,obs({shieldReady:false}),null)
assert.equal(p.command.kind,'counter')
assert.equal(p.command.slot,7,'the counter itself still uses the axe')
assert.equal(p.command.afterAttackSlot,undefined)
s=createState();s.mode='ESCAPE';s.shieldUntil=100;s.airborne=true
p=plan(s,obs({shieldReady:false,ground:false,critical:true,charge:.92,held:0}),null)
assert.equal(p.mode,'NEURAL')
assert.equal(p.command.attack,false,'obsolete escape state cannot inject an airborne strike')
s.pending=null
p=plan(s,obs({shieldReady:false,ground:false,critical:true,charge:.8,held:0}),null)
assert.equal(p.command.attack,false,'low-charge damage must not be mislabeled as a critical')
assert.equal(p.command.escapeAttackStatus,undefined)
for(const kind of ['escape-critical','escape-edge']){
  const handed=createState();handed.mode='ESCAPE';handed.shieldUntil=100
  handed.pending={id:42,kind,tick:10,packet:false}
  applied(handed,{kind,attackId:42},false,10)
  assert.equal(handed.mode,'ESCAPE','suppressed strike cannot hand off as an executed strike')
  handed.pending={id:43,kind,tick:11,packet:false}
  applied(handed,{kind,attackId:43},true,11)
  assert.equal(handed.mode,'ESCAPE','obsolete escape callbacks cannot claim a neural handoff')
  assert.equal(handed.pending.packet,false,'obsolete callback cannot invent a native outcome')
  const next=plan(handed,obs({tick:12,shieldReady:false}),{...neural,decidedTick:12})
  assert.equal(next.owners.movement,'neural')
}
console.log('PROTOCOL_WAVEDOG_CONTROL_BOUNDARIES_PASS')

// A loaded opening crossbow is never an autonomous anti-rush weapon.
s=createState()
const rush=obs({distance:6,reach:5.7,targetApproaching:true,targetApproachTicks:9,
  targetShieldRaised:false,targetShieldFacing:false,loaded:true,rangedEvent:0})
for(const over of [{},{distance:8},{targetLoading:true,rangedEvent:1},
  {targetBow:true,rangedEvent:2},{targetKnownLoaded:true},
  {targetApproachTicks:2},{targetApproaching:false},{targetAirborneThreat:true},
  {arrowThreat:{time:6,yaw:0}}]){
  p=plan(createState(),{...rush,...over},null)
  assert.notEqual(p.command.ranged,'fire-crossbow',JSON.stringify(over))
}
s=createState();receipt(s,{type:'blocked_melee',blockId:1},10)
p=plan(s,{...rush,distance:3,reach:2.7},null)
assert.equal(p.command.kind,'counter');assert(!p.command.ranged)
p=plan(createState(),{...rush,targetShotEvent:1,targetShotTick:1},null)
assert(!p.command.ranged,'an old shot cannot trigger a delayed surprise crossbow shot')
console.log('CROSSBOW_ONLY_SYNCHRONIZES_ACTUAL_SHOTS_PASS')

// Live failure: shield return kept a sword during the airborne guard, then
// borrowed its full charge for a same-frame switch-to-axe counter (0.393 dmg).
s=createState();s.mode='NEURAL'
p=plan(s,obs({held:0,shieldEffective:false,shieldRaised:false,targetAirborneThreat:true}),neural)
assert.equal(p.mode,'NEURAL','shield recovery cannot interrupt unsafe close combat')
assert.equal(p.command.slot,0,'current neural weapon remains model-owned')
assert.equal(p.owners.movement,'neural')
for(const effective of [false,true]){
  s=createState();s.mode='SHIELD_RETURN'
  p=plan(s,obs({held:0,shieldRaised:true,shieldEffective:effective,targetAirborneThreat:true}),null)
  assert.equal(p.command.slot,0,'do not interrupt an already raised shield, including warm-up')
  assert(p.command.shield&&!p.command.attack)
}
s=createState();receipt(s,{type:'blocked_melee',blockId:99},10)
p=plan(s,obs({held:0,charge:1,shieldRaised:true}),null)
assert.equal(p.command.attack,false,'sword charge cannot qualify an axe counter')
assert.equal(s.pending,null,'a weapon preparation frame creates no phantom counter')
p=plan(s,obs({tick:11,held:7,charge:.05}),null)
assert.equal(p.command.attack,false,'wait for real axe charge, not the previous sword')
p=plan(s,obs({tick:12,held:7,charge:.75}),null)
assert.equal(p.command.kind,'counter','a still-fresh block and actual axe charge can counter')
assert.equal(p.command.attack,true)
console.log('SHIELD_RECOVERY_REAL_AXE_CHARGE_PASS')
