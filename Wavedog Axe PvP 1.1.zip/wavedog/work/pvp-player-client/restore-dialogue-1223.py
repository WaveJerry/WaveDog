"""Restore the 2026-11-12 12:23 pre-hybrid GRU/Qwen snapshot.

Run only after the selfplay referee reports desired=0 active=0 and the
Minecraft server has stopped. This script retains a byte-for-byte copy of
the current model, logs, sources, classes and installed referee before edits.
"""

from __future__ import annotations

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import json
import shutil


ROOT = Path(__file__).resolve().parents[2]
PLAYER = ROOT / "work/pvp-player-client"
LAB = ROOT / "work/pvp-neural-lab"
SERVER = Path("D:/Walt Disney/Minecraft-1.21.1-Server")
SNAP = PLAYER / "new-learning/backups/before-hybrid-wavedog-20261112-122357"
EDGE = PLAYER / "new-learning/backups/before-edge-research-20261112-121004"
SHIELD = PLAYER / "new-learning/backups/before-shield-sync-fix-20261112-114024"
GATE = PLAYER / "new-learning/backups/deploy-retention-20261112-132529/WaveDogSelfPlayGate.jar"


def digest(path: Path) -> str:
    h = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def checked_copy(source: Path, dest: Path, expected: str | None = None) -> dict:
    if not source.is_file():
        raise FileNotFoundError(source)
    before = digest(source)
    if expected is not None and before.lower() != expected.lower():
        raise ValueError(f"source hash mismatch: {source}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    if digest(dest) != before:
        raise IOError(f"copy verification failed: {dest}")
    return {"source": str(source), "destination": str(dest), "sha256": before,
            "bytes": dest.stat().st_size}


def main() -> None:
    manifest = json.loads((SNAP / "manifest.json").read_text(encoding="utf-8"))
    for row in manifest:
        source = SNAP / row["path"]
        if source.stat().st_size != row["length"] or digest(source) != row["sha256"]:
            raise ValueError(f"invalid sealed snapshot: {source}")
    if digest(GATE) != "be57b1b8d6349551fe62de0a9c28a3f521463de49e59300462742161fb8d42e4":
        raise ValueError("target referee JAR changed")

    archive = PLAYER / "new-learning/backups" / ("before-dialogue-1223-restore-" +
        datetime.now().strftime("%Y%m%d-%H%M%S"))
    if archive.exists():
        raise FileExistsError(archive)
    archive.mkdir()
    saved = []
    for folder in (PLAYER / "new-learning/models", PLAYER / "new-learning/selfplay"):
        for file in sorted(folder.rglob("*")):
            if file.is_file():
                saved.append(checked_copy(file, archive / file.relative_to(PLAYER)))
    for file in (PLAYER / "selfplay.js", PLAYER / "tactical-outcomes.js",
                 PLAYER / "native-feedback.js", PLAYER / "durable-memory.js",
                 LAB / "src/local/wavedog/lab/RecurrentPpoCombat.java",
                 SERVER / "plugins/WaveDogSelfPlayGate.jar"):
        saved.append(checked_copy(file, archive / "current" / file.name))
    for folder in (PLAYER / "bridge-classes", LAB / "classes"):
        for file in sorted(folder.rglob("*.class")):
            saved.append(checked_copy(file, archive / "classes" / folder.name /
                                      file.relative_to(folder)))
    (archive / "manifest.json").write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8")

    installed = []
    for row in manifest:
        source = SNAP / row["path"]
        dest = ROOT / row["path"]
        installed.append(checked_copy(source, dest, row["sha256"]))
    older = {
        "human-challenges.jsonl": EDGE / "selfplay/human-challenges.jsonl",
        "human-native-events.jsonl": EDGE / "selfplay/human-native-events.jsonl",
        "human-frames.jsonl": SHIELD / "human-frames.jsonl",
        "qwen-errors.jsonl": SHIELD / "qwen-errors.jsonl",
        "training.jsonl": SHIELD / "training.jsonl",
    }
    for name, source in older.items():
        installed.append(checked_copy(source, PLAYER / "new-learning/selfplay" / name))
    installed.append(checked_copy(GATE, SERVER / "plugins/WaveDogSelfPlayGate.jar"))
    (archive / "restore-result.json").write_text(json.dumps({
        "target": "2026-11-12 12:23:57 before hybrid WaveDog",
        "saved": str(archive), "installed": installed,
        "note": "12:23 snapshot has exact core/model/Qwen data; adjacent earlier snapshots supply missing append-only human/training logs. The native referee bouts log remains intact."
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"archive": str(archive), "files_restored": len(installed)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
