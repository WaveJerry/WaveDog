const assert = require('node:assert/strict')
const { analyzeTactics } = require('./tactical-outcomes')
const { counterRetreatFeedback } = require('./counter-retreat-feedback')

const at = milliseconds => new Date(1794430000000 + milliseconds).toISOString()
const frame = (milliseconds, range, use = null) => ({ at: at(milliseconds),
  self: { x: 0, y: 221, z: 0, activeUseSlot: use },
  seen: { x: 0, y: 221, z: range, vy: 0 } })
const events = [
  { sequence: 1, at: at(0), tick: 10, type: 'damage', source: 'MELEE',
    attacker: 'Human', victim: 'Bot', amount: 0, victim_blocking: true, shield_modifier: -9 },
  { sequence: 2, at: at(500), tick: 20, type: 'damage', source: 'MELEE',
    attacker: 'Bot', victim: 'Human', amount: 2 },
  { sequence: 3, at: at(1800), tick: 46, type: 'arrow_launch', shooter: 'Bot' },
  { sequence: 4, at: at(2000), tick: 50, type: 'damage', source: 'ARROW',
    attacker: 'Bot', victim: 'Human', amount: 3 }
]
const frames = [frame(0,2.9),frame(500,2.9),frame(1000,3.7),frame(1800,5)]
const success = analyzeTactics('Bot','Human',events,frames)
assert.equal(success.counterHits,1)
assert.equal(success.counterEscapes,1)
assert.equal(success.edgeCounterEscapes,1)
assert.equal(success.counterEscapeArrows,1)
assert.equal(success.counterOutcomes[0].blockAt, at(0))
assert.equal(success.counterOutcomes[0].progressAt, at(1000))
assert.equal(success.counterOutcomes[0].outAt, at(1000))
assert.deepEqual(counterRetreatFeedback(success).map(x => x.kind),
  ['edge-block','counter-separation-progress','safe-counter-exit'])
assert.equal(success.arrowLaunches,1)
assert.equal(success.arrowHits,1)
assert.equal(success.edgeHits,1)
assert.equal(success.safeEdgeHits,1)
assert.equal(success.safeHitExits,1)
assert.equal(success.postExitArrows,1)
assert.equal(success.fastPostExitArrows,1)
assert.equal(success.postExitReentryHits,0)
const punished = analyzeTactics('Bot','Human',[
  ...events,{ sequence: 5, at: at(1200), tick: 34, type: 'damage', source: 'MELEE',
    attacker: 'Human', victim: 'Bot', amount: 2 }
], [...frames,frame(1200,3.4,4)])
assert.equal(punished.counterEscapes,0)
assert.equal(punished.counterPunished,1)
assert.equal(punished.counterOutcomes[0].punishAt, at(1200))
assert.equal(counterRetreatFeedback(punished).at(-1).kind, 'counter-punished')
assert.equal(punished.rangedPunished,1)
assert.equal(punished.safeHitExits,0)
const jumpOnly = analyzeTactics('Bot','Human',events,
  [frame(0,2.9),frame(500,2.9),{ ...frame(1000,2.9), self: {
    ...frame(1000,2.9).self, y: 223 } },frame(1800,3)])
assert.equal(jumpOnly.counterEscapes,0)
assert.equal(jumpOnly.counterOutcomes[0].progressAt, null)
assert.equal(jumpOnly.safeHitExits,0)
const countered = analyzeTactics('Bot','Human',[
  { sequence: 11, at: at(0), tick: 10, type: 'damage', source: 'MELEE',
    attacker: 'Bot', victim: 'Human', amount: 0, victim_blocking: true,
    shield_modifier: -8 },
  { sequence: 12, at: at(500), tick: 20, type: 'damage', source: 'MELEE',
    attacker: 'Human', victim: 'Bot', amount: 3 }
], [frame(0,3),frame(500,2.9)])
assert.equal(countered.edgeBlockedAttacks,1)
assert.equal(countered.edgeCounterPunished,1)
assert.equal(countered.spacingOutcomes[0].reward,-.06)
const axeBreak = analyzeTactics('Bot','Human',[
  { sequence: 11, at: at(0), tick: 10, type: 'damage', source: 'MELEE',
    attacker: 'Bot', victim: 'Human', amount: 0, victim_blocking: true,
    shield_modifier: -8 },
  { sequence: 13, at: at(0), tick: 11, type: 'shield_disable',
    attacker: 'Bot', victim: 'Human' }
], [frame(0,3)])
assert.equal(axeBreak.edgeBlockedAttacks,0)
const rangedExchange = analyzeTactics('Bot','Human',[
  ...events,{ sequence: 6, at: at(1900), tick: 48, type: 'arrow_launch', shooter: 'Human' }
], frames)
assert.equal(rangedExchange.rangedExchange,1)
const sprintEdge = analyzeTactics('Bot','Human',[
  { sequence: 30, at: at(0), tick: 30, type: 'damage', source: 'MELEE',
    attacker: 'Bot', victim: 'Human', amount: 3, attacker_sprinting: true }
], [frame(0,2.95)])
assert.equal(sprintEdge.sprintEdgeHits,1)
assert.equal(sprintEdge.sprintEdgeSafeHits,1)
assert.equal(analyzeTactics('Bot','Human',[
  { sequence: 30, at: at(0), tick: 30, type: 'damage', source: 'MELEE',
    attacker: 'Bot', victim: 'Human', amount: 3, attacker_sprinting: false }
], [frame(0,2.95)]).sprintEdgeHits,0)
const edgeEvents=[
  {sequence:40,at:at(0),tick:10,type:'damage',source:'MELEE',attacker:'Human',victim:'Bot',amount:2},
  {sequence:41,at:at(500),tick:20,type:'damage',source:'MELEE',attacker:'Bot',victim:'Human',amount:3}
]
const edgeActions=[{at:at(480),executed:{attackPackets:1,attackReach:2.9995,
  attackDistance:3.4,attackRadialVelocity:-.1}}]
const edgeFrames=[frame(0,3),frame(500,3.4)]
let exact=analyzeTactics('Bot','Human',edgeEvents,edgeFrames,edgeActions)
assert.equal(exact.legalEdgeHits,1);assert.equal(exact.nearLimitHits,1)
assert.equal(exact.retreatingEdgeHits,1);assert.equal(exact.retreatEdgeBreaks,1)
assert.equal(exact.spacingOutcomes.find(x=>x.kind==='safe-edge-hit').verifiedAttackReach,2.9995)
exact=analyzeTactics('Bot','Human',[...edgeEvents,{sequence:42,at:at(500),tick:20,
  type:'damage',source:'MELEE',attacker:'Human',victim:'Bot',amount:6}],edgeFrames,edgeActions)
assert.equal(exact.retreatEdgeBreaks,0,'same-tick losing exchange is not a safe interruption')
assert.equal(exact.safeEdgeHits,0)
exact=analyzeTactics('Bot','Human',edgeEvents,edgeFrames,[{...edgeActions[0],
  executed:{...edgeActions[0].executed,attackRadialVelocity:.1}}])
assert.equal(exact.advancingEdgeHits,1);assert.equal(exact.retreatEdgeBreaks,0)
assert.equal(analyzeTactics('Bot','Human',[],edgeFrames,edgeActions).legalEdgeHits,0,
  'retreating or swinging at the boundary alone earns no edge outcome')
console.log('tactical outcomes OK')
