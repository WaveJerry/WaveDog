const assert = require('node:assert/strict')
const { schedule } = require('./curriculum')

const styles = ['AGGRESSIVE','DEFENSIVE','RANGED','FLANK','GROUND_COMBO','MIXED']
const focuses = ['FREE','CHARGE','SHIELD','AXE_BREAK','CRITICAL','SPRINT_KB','ESCAPE',
  'SYNC','FLANK','COMBO','BOW','CROSSBOW','DODGE','WALL','LATENCY','OPPONENT']

const allPairs = new Set()
for (let arena = 0; arena < 15; arena++) {
  const a = schedule(arena * 2, 1, styles, focuses, null, 413)
  const b = schedule(arena * 2 + 1, 1, styles, focuses, null, 413)
  assert.notEqual(a.style, b.style)
  assert.equal(a.matchup, b.matchup)
  allPairs.add(a.matchup)
}
assert.equal(allPairs.size, 15)
for (let fighter = 0; fighter < 60; fighter++) {
  const rounds = Array.from({ length: 60 }, (_, index) =>
    schedule(fighter, index + 1, styles, focuses, 'AXE_BREAK', 413))
  assert.deepEqual(new Set(rounds.map(x => x.style)), new Set(styles))
  assert.deepEqual(new Set(rounds.filter(x => x.curriculumSource === 'coverage-cycle')
    .map(x => x.focus)), new Set(focuses))
  assert.equal(rounds.filter(x => x.curriculumSource === 'shared-Qwen-experiment').length, 40)
  for (const row of rounds) assert.equal(styles.includes(row.style) && focuses.includes(row.focus), true)
}
assert.equal(schedule(0, 4, styles, focuses, null).curriculumSource, 'coverage-cycle')
console.log('CURRICULUM_COVERAGE_PASS fighters=60 bouts=60 pairings=15 focuses=16')
