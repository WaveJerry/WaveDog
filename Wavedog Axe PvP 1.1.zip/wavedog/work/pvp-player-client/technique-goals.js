// A training goal is a testable hypothesis for one temporary clone. It does
// not issue movement or attack commands and does not claim a move was learned.
const techniques = {
  CHARGE: [
    ['MELEE', '高蓄力斧击与必要轻击：比较原生伤害、空挥和后续换血'],
    ['MELEE', '地面连招：命中后按实际距离和蓄力决定是否续刀，连不上就停'] ],
  SHIELD: [
    ['STANDOFF', '有效举盾压近并防跳劈：只按原生挡刀和受伤验收'],
    ['STANDOFF', '盾挡反击后及时回盾，检查0.25秒生效窗与对手回击'] ],
  AXE_BREAK: [
    ['STANDOFF', '斧头打有效盾尝试原生破盾，再检验后续命中'],
    ['STANDOFF', '面对举盾对手，比较绕侧命中与正面斧破盾的实际收益'] ],
  CRITICAL: [
    ['MELEE', '从射程外选择落点，尽量完成整次疾跑跳入距；下落攻击前松疾跑，以实际水平行程、原生暴击和净换血验收'],
    ['MELEE', '近距选落点正常暴击，防对手迎击、躲开和有效盾挡'],
    ['MELEE', '被击飞后仅在真实下落窗口寻找惩罚暴击，比较受伤与回击'] ],
  SPRINT_KB: [
    ['MELEE', '合法极限距离疾跑先手命中，检查原生疾跑、水平出距和后续收益'],
    ['MELEE', 'W-tap 后续击退与持续控距：看真实命中和相对位移'],
    ['MELEE', '对方下落跳入时边缘疾跑迎击，核对是否先命中及吃到多少伤害'] ],
  ESCAPE: [
    ['STANDOFF', '边缘盾挡后斧反命中并一次跑跳出距，守住换血优势'],
    ['MELEE', '满距离转身疾跑跳离开对手，真实出距后停跑并重新选择弓弩或再入'],
    ['RANGED', '首次出距后决定射箭、装弩或重新接近，核对真发箭与伤害'],
    ['MELEE', '被盾反后立即评估换伤或脱离，避免无目的后退'],
    ['MELEE', '被连续命中时沿安全方向后撤到对方合法射程外，中止连招止损；核对真实出距、后续挨打次数和净换血'] ],
  SYNC: [
    ['MELEE', 'jump reset：只用看得见的对手挥手、靠近和自身受击线索，在可能受击前后合法起跳；比较水平击退、脱连和换血，不要连续乱跳或假定零击退'],
    ['MELEE', '对手跳劈时以走位、有效盾或先手刀应对，比较原生损益'],
    ['MELEE', '匹配对手高度和攻击节奏，避免单方面吃暴击'] ],
  FLANK: [
    ['STANDOFF', '短促绕盾改变相对位置，以实际侧面命中而非转头验收'],
    ['STANDOFF', '绕反：转盾跟防或抓对手绕侧松盾窗口反击'] ],
  COMBO: [
    ['MELEE', '正常入距时蓄力足够就在合法三格边缘先手出刀；仅为真实下落暴击才延后'],
    ['MELEE', '对手无有效盾时从斧切剑连续合法命中；贴脸时尝试连续原生暴击，并比较回击与净换血'],
    ['MELEE', '极限控距的先手命中与后续连招，出距后停止空挥'],
    ['MELEE', '对方剑连击时举盾、控距或反击，防止低DPS换血'] ],
  BOW: [
    ['RANGED', '拉距时短促拉弓射箭并防对手突进换血，以真发箭和箭伤验收'],
    ['RANGED', '弓箭互射并按可见弹道侧移，记录出箭、受箭与距离'] ],
  CROSSBOW: [
    ['RANGED', '安全距离移动装弩，已装弩留到有效射击窗口，防对手冲脸'],
    ['RANGED', '盾反脱离后用副手已装弩射击，再决定重装或回近战'] ],
  DODGE: [
    ['RANGED', '看见来箭后侧移或侧跳离开弹道，比较实际中箭与位置'],
    ['RANGED', '对手持已装弩突进时选择盾挡、侧跳或迎击，按伤害验收'] ],
  WALL: [
    ['MELEE', '控距时避免背靠墙并争取让对手受地形限制，按真实位置与伤害验收'] ],
  LATENCY: [
    ['STANDOFF', '考虑公开观测延迟，检验盾生效、出刀包和原生命中是否同序'] ],
  OPPONENT: [
    ['MELEE', '遇到不同对手后总结其盾、暴击和剑斧节奏，下一回合换可测策略'] ],
  FREE: [
    ['MELEE', '自由探索新变式，按原生命中、净换血与胜负留优去劣'] ]
}

// Translate each written practice method into related, already learned focus
// channels. The first channel remains the actual bout focus; the rest are
// weak hints, not scripted actions. Both GRU and Transformer receive them.
const methodCues = {
  CHARGE: [['COMBO'], ['COMBO', 'SPRINT_KB']],
  SHIELD: [['SPRINT_KB', 'FLANK'], ['CHARGE', 'SYNC']],
  AXE_BREAK: [['SHIELD', 'COMBO'], ['FLANK', 'SHIELD']],
  CRITICAL: [['SPRINT_KB', 'COMBO'], ['DODGE', 'SHIELD'], ['SYNC', 'COMBO']],
  SPRINT_KB: [['CHARGE', 'COMBO'], ['COMBO', 'ESCAPE'], ['SYNC', 'CRITICAL']],
  ESCAPE: [['SHIELD', 'SPRINT_KB'], ['SPRINT_KB', 'BOW'],
    ['CROSSBOW', 'DODGE'], ['SYNC', 'COMBO'], ['COMBO', 'SPRINT_KB']],
  SYNC: [['SPRINT_KB', 'COMBO'], ['SHIELD', 'DODGE'], ['CHARGE', 'CRITICAL']],
  FLANK: [['SHIELD', 'SPRINT_KB'], ['SHIELD', 'CHARGE']],
  COMBO: [['CHARGE', 'SPRINT_KB'], ['CHARGE', 'CRITICAL'],
    ['SPRINT_KB', 'ESCAPE'], ['SHIELD', 'SYNC']],
  BOW: [['ESCAPE', 'DODGE'], ['DODGE', 'CROSSBOW']],
  CROSSBOW: [['ESCAPE', 'DODGE'], ['SHIELD', 'ESCAPE']],
  DODGE: [['BOW', 'SPRINT_KB'], ['CROSSBOW', 'SHIELD']],
  WALL: [['ESCAPE', 'FLANK']],
  LATENCY: [['SHIELD', 'CHARGE']],
  OPPONENT: [['SHIELD', 'CRITICAL']],
  FREE: [[]]
}

function techniqueGoal (focus, fighterIndex, bout) {
  const choices = techniques[focus] || techniques.FREE
  const variant = (Math.floor((bout - 1) / 3) + Math.floor(fighterIndex / 2)) % choices.length
  const [stage, goal] = choices[variant]
  return { stage, goal, techniqueCues: methodCues[focus]?.[variant] || [] }
}

module.exports = { techniques, methodCues, techniqueGoal }
