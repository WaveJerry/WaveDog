const assert = require('node:assert/strict')
const { jumpOutcomes, shieldOutcomes } = require('./combat-outcome-feedback')
const at = ms => new Date(1794480000000 + ms).toISOString()
const session = {
  name: 'NBot01', opponent: 'NBot02',
  jumpEpisodes: [
    { at: at(0), frame: 1, decidedFrame: 1 },
    { at: at(2000), frame: 21, decidedFrame: 21 },
    { at: at(4000), frame: 41, decidedFrame: 41 }
  ],
  frameHistory: [
    { at: at(0), frame: 1, self: { ground: false } },
    { at: at(600), frame: 8, self: { ground: true } },
    { at: at(2000), frame: 21, self: { ground: false } },
    { at: at(2600), frame: 28, self: { ground: true } },
    { at: at(4000), frame: 41, self: { ground: false } },
    { at: at(4600), frame: 48, self: { ground: true } }
  ],
  actionHistory: [
    { at: at(5000), frame: 51, decidedFrame: 51,
      selected: { shield: true }, ignoredHeads: [],
      executed: { using: true, offhand: 'shield' } },
    { at: at(5300), frame: 57, decidedFrame: 57,
      selected: { shield: true }, ignoredHeads: [],
      executed: { using: true, offhand: 'shield' } },
    { at: at(5400), frame: 59, decidedFrame: 59,
      selected: { shield: false }, ignoredHeads: [],
      executed: { using: false, offhand: 'shield' } }
  ]
}
const events = [
  { at: at(350), type: 'damage', attacker: 'NBot01', victim: 'NBot02',
    source: 'MELEE', amount: 7, attacker_fall_distance: .6,
    attacker_on_ground: false, attacker_sprinting: false },
  { at: at(2100), type: 'damage', attacker: 'NBot02', victim: 'NBot01',
    source: 'MELEE', amount: 6 },
  { at: at(5280), type: 'damage', attacker: 'NBot02', victim: 'NBot01',
    source: 'MELEE', amount: 0, victim_blocking: true, shield_modifier: -4 }
]
const jumps = jumpOutcomes(session, events)
assert.equal(jumps[0].kind, 'falling-hit')
assert.ok(jumps[0].reward > 0)
assert.equal(jumps[1].kind, 'possible-jump-reset')
assert.equal(jumps[1].reward, 0)
assert.equal(jumps[2].kind, 'empty-jump')
assert.ok(jumps[2].reward < 0)
const shield = shieldOutcomes(session, events)
assert.equal(shield.length, 1)
assert.equal(shield[0].kind, 'native-block')
assert.equal(shield[0].durationMs, 400)
assert.ok(shield[0].reward > 0)
console.log('COMBAT_OUTCOME_FEEDBACK_PASS')
