const assert = require('node:assert/strict')
const { chargedOpportunity } = require('./attack-opportunity')
const at = new Date('2026-11-13T10:00:00Z').toISOString()
const frame = { self: { x: 0, y: 0, z: 0, charge: .95, health: 20,
  shielding: false, activeUseSlot: null, opponentSwingAge: null },
seen: { x: 2.7, y: 0, z: 0, shield: false } }
const action = { at, selected: { attack: false, shield: false },
  executed: { attackPackets: 0 } }
assert(chargedOpportunity(frame, action))
assert(!chargedOpportunity(frame, action, Date.parse(at) - 100), 'rate limit')
assert(!chargedOpportunity({ ...frame, self: { ...frame.self, charge: .5 } }, action))
assert(!chargedOpportunity({ ...frame, self: { ...frame.self, opponentSwingAge: 1 } }, action))
assert(!chargedOpportunity({ ...frame, seen: { ...frame.seen, shield: true } }, action))
assert(!chargedOpportunity(frame, { ...action, selected: { attack: true } }))
console.log('ATTACK_OPPORTUNITY_PASS')
