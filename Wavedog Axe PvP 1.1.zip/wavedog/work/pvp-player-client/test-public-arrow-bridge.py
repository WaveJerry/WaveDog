"""Check that visible protocol arrows reach the GRU observation bridge."""
from pathlib import Path
import json
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classpath = ';'.join(map(str, [base / 'bridge-classes',
    base.parent / 'pvp-neural-lab/classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
rows = [
    {'command': 'reset', 'fighter': 'NBot01', 'opponent': 'NBot02', 'learning': False},
    {'command': 'act', 'fighter': 'NBot01', 'opponent': 'NBot02', 'requestId': 1,
     'tick': 10, 'yaw': 0, 'pitch': 0, 'focus': 'FREE', 'style': 'AGGRESSIVE',
     'self': {'x': 1058, 'y': 221, 'z': 960, 'eyeY': 222.62, 'ground': True,
              'charge': 1, 'health': 20, 'shieldAvailable': True, 'held': 7},
     'seen': {'visible': True, 'x': 1058, 'y': 221, 'z': 962,
              'yaw': 180, 'held': 'DIAMOND_AXE', 'arrows': [
                  {'x': 1059, 'y': 222, 'z': 961, 'vx': -.2, 'vy': -.1, 'vz': -.3}]}}
]
run = subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp', classpath,
    'local.wavedog.lab.ProtocolPlayerBridge',
    str(base / 'new-learning/models')],
    input='\n'.join(json.dumps(row) for row in rows) + '\n',
    text=True, capture_output=True, check=True, timeout=30)
response = [json.loads(line) for line in run.stdout.splitlines()]
assert not any(row.get('event') == 'error' for row in response), response
assert next(row for row in response if row.get('requestId') == 1)['observedArrows'] == 1
print('PUBLIC_ARROW_BRIDGE_PASS')
