const assert = require('node:assert/strict')
const { analyzeCriticalTactics, analyzeLandingChoices } = require('./critical-tactics')

const at = ms => new Date(1794430000000 + ms).toISOString()
const frame = (ms, d, ground, vy, enemyY = 221, enemyVy = 0) => ({
  at: at(ms), self: { x: 0, y: 221, z: 0, ground, vy },
  seen: { x: 0, y: enemyY, z: d, vy: enemyVy }
})
const hit = (ms, tick, attacker = 'Bot', victim = 'Human', amount = 4,
  critical = true) => ({ at: at(ms), tick, type: 'damage', source: 'MELEE',
  attacker, victim, amount, native_critical: critical })

const jumpFrames = [frame(0, 4.4, true, 0), frame(350, 3.6, false, .2),
  frame(700, 2.8, false, -.2)]
let result = analyzeCriticalTactics('Bot', 'Human', [hit(700, 14)], jumpFrames)
assert.equal(result.nativeCriticalHits, 1)
assert.equal(result.jumpInCriticalHits, 1)
assert.deepEqual(result.criticalOutcomes.map(x => x.kind),
  ['native-critical-hit', 'jump-in-critical-hit'])

result = analyzeCriticalTactics('Bot', 'Human', [hit(700, 14)],
  [frame(0, 2.8, true, 0), frame(700, 2.6, false, -.2)])
assert.equal(result.nativeCriticalHits, 1)
assert.equal(result.jumpInCriticalHits, 0) // ordinary close-range critical

result = analyzeCriticalTactics('Bot', 'Human', [hit(700, 14, 'Bot', 'Human', 4, false)], jumpFrames)
assert.equal(result.nativeCriticalHits, 0) // falling pose cannot replace Paper receipt

const defenceFrames = [frame(0, 4.2, true, 0),
  frame(700, 2.7, true, 0, 222, -.2)]
result = analyzeCriticalTactics('Bot', 'Human', [
  { ...hit(700, 14, 'Human', 'Bot', 0), victim_blocking: true, shield_modifier: -7 }
], defenceFrames)
assert.equal(result.nativeCriticalShieldBlocks, 1)
assert.equal(result.jumpInShieldBlocks, 1)

result = analyzeCriticalTactics('Bot', 'Human', [
  { ...hit(700, 14, 'Human', 'Bot', 0, false), victim_blocking: true,
    shield_modifier: -7, attacker_fall_distance: .6,
    attacker_on_ground: false, attacker_sprinting: false, native_attack_charge: .98 }
], defenceFrames)
assert.equal(result.nativeCriticalShieldBlocks, 0)
assert.equal(result.shieldedCriticalEligibleAttacks, 1)

result = analyzeCriticalTactics('Bot', 'Human', [hit(700, 14)], defenceFrames)
assert.equal(result.fallingThreatFirstHits, 1)
result = analyzeCriticalTactics('Bot', 'Human', [hit(700, 14), hit(950, 19, 'Human', 'Bot')],
  defenceFrames)
assert.equal(result.fallingThreatFirstHits, 0)
const landing = analyzeLandingChoices('Bot', 'Human', [
  { at: at(0), decidedFrame: 1, ignoredHeads: [], selected: { forward: 1 },
    executed: { jump: true, sprint: true, forward: true } },
  { at: at(350), decidedFrame: 2, ignoredHeads: [], executed: { jump: false } }
], [frame(0, 4.4, true, 0), frame(100, 3.9, false, .2),
  frame(500, 2.8, false, -.2), frame(700, 2.6, true, 0)],
[{ ...hit(500, 12), attacker_sprinting: false }])
assert.equal(landing.landingAttempts, 1)
assert.equal(landing.landedInReach, 1)
assert.equal(landing.landingCriticalHits, 1)
assert.equal(landing.sprintJumpEntries, 1)
assert.equal(landing.sprintJumpCriticalHits, 1)
assert.equal(landing.longRunJumpEntries, 0)
assert.equal(landing.landingOutcomes[0].decidedFrame, 1)
assert(landing.landingOutcomes[0].reward > 0)
const movingFrame = (ms, ownZ, distance, ground, vy) => {
  const row = frame(ms, distance, ground, vy)
  row.self.z = ownZ; row.seen.z = ownZ + distance
  return row
}
const longJump = analyzeLandingChoices('Bot', 'Human', [
  { at: at(0), decidedFrame: 4, ignoredHeads: [], selected: { forward: 1 },
    executed: { jump: true, sprint: true, forward: true } },
  { at: at(350), decidedFrame: 5, ignoredHeads: [], executed: { jump: false } }
], [movingFrame(0, 0, 6, true, 0), movingFrame(100, 1.2, 4.8, false, .2),
  movingFrame(500, 2.5, 3.0, false, -.2), movingFrame(700, 3.1, 2.7, true, 0)],
[{ ...hit(500, 12), attacker_sprinting: false }])
assert.equal(longJump.longRunJumpEntries, 1)
assert.equal(longJump.longRunJumpCriticalHits, 1)
assert.equal(longJump.landingOutcomes[0].horizontalTravel, 3.1)
const unexecuted = analyzeLandingChoices('Bot', 'Human', [
  { at: at(0), decidedFrame: 1, ignoredHeads: [2], executed: { jump: true } }
], [frame(0, 4.4, true, 0), frame(100, 3.9, false, .2),
  frame(700, 2.6, true, 0)], [hit(500, 12)])
assert.equal(unexecuted.landingAttempts, 0)
console.log('critical tactics OK')
