'use strict'

// Vanilla number-key swap while hovering the offhand inventory slot. Unlike
// three cursor clicks this leaves the selected main-hand weapon untouched.
function requestOffhandSwap (bot, item) {
  const hotbar = item.slot - 36
  const recentDig = bot.lastDigTime != null && Date.now() - bot.lastDigTime < 500
  const fast = !bot.currentWindow && !bot.inventory.selectedItem && !recentDig
    && hotbar >= 0 && hotbar < 9 && hotbar !== bot.quickBarSlot
  const completion = fast ? bot.clickWindow(45, hotbar, 2) : bot.equip(item, 'off-hand')
  // clickWindow predicts the normal inventory operation synchronously. Use may
  // follow in the same ordered packet stream; native state still confirms it.
  return { completion, ready: fast && bot.inventory.slots[45]?.name === item.name,
    method: fast ? 'number-swap' : 'cursor-equip' }
}

module.exports = { requestOffhandSwap }
