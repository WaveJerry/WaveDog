const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { SingleLaneState } = require('./single-lane-state')

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'pvp-lane-'))
const file = path.join(directory, 'state.json')
try {
  const lane = new SingleLaneState(file, 3)
  for (let arena = 1; arena <= 3; arena++) {
    assert.equal(lane.complete({ arena, bout: 100 + arena,
      matchId: `match-${arena}`, at: new Date().toISOString(),
      winner: 'NBot01', reason: 'death', training: [{ event: 'trained' }],
      fighters: {}, tactics: {} }), arena === 3)
    assert.equal(new SingleLaneState(file, 3).value.nextArena, arena % 3 + 1)
  }
  assert.throws(() => lane.complete({ arena: 1 }), /Cannot advance/)
  lane.reviewed()
  assert.deepEqual(new SingleLaneState(file, 3).value,
    { format: 1, cycle: 2, nextArena: 1, completed: [] })
  assert.throws(() => lane.reviewed(), /incomplete/)
  console.log('SINGLE_LANE_STATE_PASS')
} finally {
  for (const name of fs.readdirSync(directory)) fs.unlinkSync(path.join(directory, name))
  fs.rmdirSync(directory)
}
