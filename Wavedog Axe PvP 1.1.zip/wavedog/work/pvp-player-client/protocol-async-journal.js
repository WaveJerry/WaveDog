'use strict'
const fs=require('node:fs')
// One ordered queue per file. A slow disk never blocks a network callback;
// flush(file) is the durability barrier before replacing a bout's append log.
function createAsyncJournal({io=fs.promises,onError=()=>{}}={}){
  const files=new Map(),stats={queuedBytes:0,peakQueuedBytes:0,batches:0}
  let failed=null
  function state(file){
    if(!files.has(file))files.set(file,{rows:[],bytes:0,running:null,scheduled:null})
    return files.get(file)
  }
  async function drain(file,s){
    while(s.rows.length){
      const rows=s.rows.splice(0),bytes=s.bytes;s.bytes=0
      try{await io.appendFile(file,rows.join(''));stats.batches++}
      catch(error){failed=error;onError(error);throw error}
      finally{stats.queuedBytes-=bytes}
    }
  }
  function start(file,s){
    if(s.running)return s.running
    if(s.scheduled){clearImmediate(s.scheduled);s.scheduled=null}
    const running=drain(file,s)
    s.running=running
    running.finally(()=>{s.running=null;if(s.rows.length)schedule(file,s)}).catch(()=>{})
    return running
  }
  function schedule(file,s){
    if(!s.scheduled&&!s.running)s.scheduled=setImmediate(()=>{s.scheduled=null;void start(file,s).catch(()=>{})})
  }
  return {
    append(file,text){
      if(failed)throw failed
      const s=state(file),bytes=Buffer.byteLength(text)
      s.rows.push(text);s.bytes+=bytes;stats.queuedBytes+=bytes
      stats.peakQueuedBytes=Math.max(stats.peakQueuedBytes,stats.queuedBytes)
      // Do not silently discard training data on a failed/stalled disk.
      if(stats.queuedBytes>32*1024*1024)throw Error('Journal backlog exceeds 32 MiB; persistence stalled')
      schedule(file,s)
    },
    async flush(file){
      if(failed)throw failed
      if(file){const s=files.get(file);if(s)while(s.rows.length||s.running)await (s.running||start(file,s))}
      else for(const name of files.keys())await this.flush(name)
      if(failed)throw failed
    },
    get stats(){return {...stats,files:files.size,failed:failed?String(failed):null}}
  }
}
module.exports={createAsyncJournal}
