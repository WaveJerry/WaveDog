const assert = require('node:assert/strict')
const { EDGE_PRIORITY, edgePriorityPlan, edgePriorityReward } = require('./edge-priority')
const plan = { focus: 'CRITICAL', style: 'AGGRESSIVE' }
assert.equal(Array.from({ length: 4 }, (_, i) => edgePriorityPlan(plan, i, 1))
  .filter(p => p.focus === 'SPRINT_KB').length, 3)
const budget = { remaining: EDGE_PRIORITY.extraBudget }
const good = { kind: 'safe-edge-hit', reward: .02, verifiedAttackReach: 2.999 }
assert(Math.abs(edgePriorityReward(good, budget) - .12) < 1e-12)
for (const bad of [
  { ...good, verifiedAttackReach: 3.01 },
  { ...good, verifiedAttackReach: undefined,verifiedAttackDistance:2.999 },
  { ...good, kind: 'opponent-safe-edge-hit', reward: -.03 },
  { ...good, kind: 'punish-critical' }
]) assert.equal(edgePriorityReward(bad, budget), bad.reward)
for (let i = 0; i < 50; i++) edgePriorityReward(good, budget)
assert.equal(budget.remaining, 0)
assert.equal(edgePriorityReward(good, budget), good.reward)
console.log('EDGE_PRIORITY_PASS: 75% curriculum, verified hits only, x6 auxiliary reward, bounded budget')
