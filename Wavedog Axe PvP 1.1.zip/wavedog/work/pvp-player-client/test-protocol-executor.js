'use strict'
const assert = require('node:assert/strict')
const { executeCommand } = require('./protocol-wavedog-executor')
const { createState, plan, receipt, applied } = require('./protocol-wavedog-brain')
const { nearestHitPoint,currentViewPacket,immediateLook } = require('./protocol-mechanical-math')
function fixture (over = {}) {
  const wire = [], controls = {}, inventory = { slots: [] }
  inventory.slots[45] = { name: 'shield' }
  let use = null
  const bot = { inventory, quickBarSlot: 7, food: 20,
    get heldItem () { return { name: this.quickBarSlot === 0 ? 'diamond_sword' : 'diamond_axe' } },
    entity: { yaw: 0,pitch:0, onGround: true, velocity: { y: 0 }, position: { x: 0, z: 0 } },
    _client: { write: (name, data) => wire.push({ name, data }) },
    setControlState (key, value) {
      if (key === 'sprint' && Boolean(controls[key]) !== value)
        this._client.write('entity_action', { actionId: value ? 3 : 4 })
      controls[key] = value
    },
    getControlState: key => Boolean(controls[key]),
    setQuickBarSlot (slot) { this.quickBarSlot = slot; this._client.write('held_item_slot', { slot }) },
    activateItem () { this._client.write('use_item', { hand: 1 }) },
    attack () { this._client.write('use_entity', { mouse: 1 }) }
  }
  const command = { forward: 1, side: 0, sprint: true, jump: false, slot: 7,
    attack: false, shield: false, kind: 'neural', decidedTick: 9, ...over }
  const ctx = { bot, wire, tick: 10, lastAttackTick: -1000, shieldUntil: 0,
    target: { position: { x: 0, z: -2.5 } }, charge: () => 1,
    session: { id: 'test', opponent: 'opponent', state: createState(),
      attackedDecisions: new Set(), attackOwners: new Map() },
    frame: { seen: { visible: true }, observation: { reach: 2.2, distance: 2.5 }, targetVelocity: {} },
    planned: { command, owners: { movement: 'neural', sprint: 'neural', jump: 'neural',
      mainhand: 'neural', attack: 'neural' } },
    getUse: () => use, setUse: value => { use = value },
    stopUse () { if (use) bot._client.write('block_dig', { status: 5 }); use = null },
    offhand: name => inventory.slots[45]?.name === name,
    plugin: row => bot._client.write('custom_payload', row),
    onSwitch: () => {}, onAttack: () => {}, ownLoaded: () => false, bowDrawMs: () => 700,
    look (yaw,pitch=0) { bot.entity.yaw = yaw;bot.entity.pitch=pitch; bot._client.write('look', { yaw,pitch }) },
    aim () { bot.entity.yaw = bot.entity.pitch=0; bot._client.write('look', { yaw: 0,pitch:0 }) }
  }
  return ctx
}
let x = fixture({ attack: true })
x.bot.entity.onGround = false; x.bot.entity.velocity.y = -.2
let out = executeCommand(x)
assert(out.attacked)
let hit = x.wire.findIndex(p => p.name === 'use_entity')
const lastSprint=x.wire.slice(0,hit).filter(p=>p.name==='entity_action').at(-1)
assert.equal(lastSprint.data.actionId, 4, 'stop sprint reaches the wire before the critical attack')
assert(out.ignoredHeads.includes(1), 'overridden sprint is not PPO-owned')
const outsideWire=fixture({attack:true})
outsideWire.target={position:{x:0,y:0,z:3.2},width:.6,height:1.8}
outsideWire.frame.self={y:0,eyeY:1.62}
outsideWire.frame.observation.sentPosition={x:0,y:0,z:-.2}
const rejectedWire=executeCommand(outsideWire)
assert.equal(rejectedWire.attacked,false,'client prediction cannot extend actual server reach')
assert.equal(rejectedWire.attackSuppressedReason,'illegal-sent-reach-suppressed')
out = executeCommand(x)
assert(!out.attacked, 'cached decisions cannot double click')
x.planned.command.decidedTick = 10; x.lastAttackTick = 10
out = executeCommand(x)
assert(!out.attacked, 'new response based on pre-hit observation cannot double click either')
assert.equal(out.owners.attack, 'stale-before-last-attack')
x.planned.command.decidedTick = 11; x.tick = 12; x.charge = () => .2
out = executeCommand(x)
assert(out.attacked, 'fresh learned early hit remains possible; no fixed cooldown lock')

// Reproduce the real one-frame feedback race: the model chose to switch to
// sword, then an older hold-axe reply arrived before it saw the new sword.
x = fixture({ attack: true, slot: 7, observedWeaponEpoch: 4 })
x.bot.quickBarSlot=0; x.weaponEpoch=5
out=executeCommand(x)
assert.equal(x.bot.quickBarSlot,0,'old hold-axe reply must not undo a new sword switch')
assert(!out.attacked,'old axe charge cannot authorize an attack with the new sword')
assert(out.controls.forward,'weapon invalidation must not create a movement vacuum')
assert.equal(out.owners.mainhand,'stale-weapon-observation')
assert(out.ignoredHeads.includes(4)&&out.ignoredHeads.includes(5),'discarded hand choices must not receive PPO credit')
assert(!out.ignoredHeads.includes(0),'valid movement remains model-owned')
x.planned.command.observedWeaponEpoch=5
out=executeCommand(x)
assert.equal(x.bot.quickBarSlot,7,'a fresh intentional sword-to-axe switch remains allowed')
assert(out.attacked,'fresh quick-switch attack remains model-owned and available')
x=fixture({attack:true,slot:7,kind:'counter',observedWeaponEpoch:4})
x.weaponEpoch=5
out=executeCommand(x)
assert(out.attacked,'mechanical counter priority is unchanged')
x=fixture({attack:true,slot:7,kind:'counter'});x.bot.quickBarSlot=0
out=executeCommand(x)
assert(!out.attacked,'execution rechecks the real held axe, even if the planner was stale')
assert.equal(out.attackSuppressedReason,'counter-axe-not-ready')
assert(!x.wire.some(p=>p.name==='use_entity'))
x=fixture({attack:true,slot:7,kind:'counter'});x.charge=()=>.1
out=executeCommand(x)
assert(!out.attacked,'an undercharged real axe cannot borrow another weapon charge')

x = fixture({ attack: true, aimAway: true, critical: true, kind: 'escape-critical', slot: 0 })
x.bot.entity.onGround = false; x.bot.entity.velocity.y = -.2
out = executeCommand(x)
assert(out.attacked); assert.equal(x.bot.entity.yaw, Math.PI)
assert(out.controls.forward && out.controls.sprint, 'turn-back strike restores retreat direction and speed')
assert.equal(x.wire.filter(p => p.name === 'use_entity').length, 1)

x = fixture({ shield: true, attack: false, sprint: false })
x.setUse({ kind: 'shield', tick: 5 })
x.frame.nativeSelf = { receivedTick: 9, using: false }
out = executeCommand(x)
assert.equal(x.wire.filter(p => p.name === 'use_item').length, 1, 'unacknowledged shield is retried')
assert(x.wire.some(p => p.name === 'block_dig'))
assert.equal(x.getUse().tick, 10)
x = fixture({ shield: true, attack: false, sprint: false })
x.offhand = () => false
out = executeCommand(x)
assert(out.controls.forward, 'pending inventory swap does not freeze movement')

x=fixture({ranged:'bow',offhand:'bow',attack:false,shield:false})
x.bot.inventory.slots[45]={name:'bow'};x.setUse({kind:'bow',tick:-100})
out=executeCommand(x)
assert(!out.rangedResult.bowReleased,'elapsed draw time must not cause an unsolicited bow shot')
x.planned.command.rangedRelease=true
out=executeCommand(x)
assert(out.rangedResult.bowReleased)
assert(x.wire.findLastIndex(p=>p.name==='look')<x.wire.findLastIndex(p=>p.name==='block_dig'),
  'current prediction must reach the wire before synchronized bow release')
x=fixture({ranged:'bow',offhand:'bow',rangedRelease:true,keepLook:true,forward:0,side:-1})
x.bot.inventory.slots[45]={name:'bow'};x.setUse({kind:'bow',tick:1})
x.bot.entity.yaw=1.2;x.bot.entity.pitch=.3
out=executeCommand(x)
assert(out.rangedResult.bowReleased&&out.controls.left&&!out.controls.forward)
assert.equal(x.bot.entity.yaw,1.2);assert.equal(x.bot.entity.pitch,.3)
assert.deepEqual(x.wire.filter(p=>['look','block_dig'].includes(p.name)).map(p=>p.name),['look','block_dig','look'])

x = fixture({ attack: true, kind: 'counter' })
out = executeCommand(x)
assert.equal(out.attackItemName,'diamond_axe')
assert.equal(out.attackHeld,7)
const counterSwap=fixture({attack:true,kind:'counter',afterAttackSlot:0})
counterSwap.shieldUntil=20
const counterSwapResult=executeCommand(counterSwap)
assert.equal(counterSwapResult.attackItemName,'diamond_axe','attack is recorded before switching to escape sword')
assert.equal(counterSwapResult.heldItemName,'diamond_sword','end-of-frame weapon is recorded separately')
assert(out.attacked && x.getUse().kind === 'shield', 'unbroken counter re-raises in the same command')
assert(x.wire.findIndex(p => p.name === 'use_item') > x.wire.findIndex(p => p.name === 'use_entity'))
x = fixture({ keepLook: true, forward: 0, side: -1, kind: 'dodge' })
x.bot.entity.yaw = 1.7
executeCommand(x)
assert.equal(x.bot.entity.yaw, 1.7, 'side dodge uses the view from its trajectory prediction')

const obs = { tick: 10, ground: true, shieldReady: true, shieldEffective: true,
  health:20,self:{x:0,z:2},sentPosition:{x:0,z:2},target:{x:0,z:0},targetYaw:0,
  offhandShieldReady: true, visible: true, reach: 2.7, distance: 3,
  charge: 1, held: 7, wallMargin: 8, targetShieldFacing: false, targetFacingDot: -.9 }
let s = createState('opponent'), p = plan(s, obs, null)
assert.equal(p.command.kind, 'orbit-rear', 'rear opening works without a previous orbit')
receipt(s, { type: 'attack_packet', attackId: p.command.attackId, willAttack: true }, 10)
receipt(s, { type: 'damage', attackId: p.command.attackId, attacker: 'WaveDog', victim: 'someone-else', amount: 5 }, 10)
assert(s.pending, 'a matching ID on the wrong victim is never a confirmed hit')
receipt(s, { type: 'damage', attackId: p.command.attackId, attacker: 'WaveDog', victim: 'opponent', amount: 5 }, 10)
assert.equal(s.pending, null)
s = createState()
receipt(s, { type: 'blocked_melee', blockId: 8 }, 10)
p = plan(s, { ...obs, arrowThreat: { time: 6, yaw: 2 } }, null)
assert.equal(p.command.attack, false)
applied(s, p.command, false, 10)
assert.equal(s.mode, 'GUARD'); assert(s.blocked, 'cancelled counter keeps its real block opportunity')
p = plan(s, { ...obs, tick: 11 }, null)
assert.equal(p.command.kind, 'counter')
s = createState(); s.mode = 'ESCAPE'; s.escapeAt = 10; s.airborne = true; s.shieldUntil = 100
p = plan(s, { ...obs, ground: false, shieldReady: false, critical: true,
  arrowThreat: { time: 1, side: 1 }, offhandShieldReady: false }, null)
applied(s, p.command, false, 10)
assert(!s.exitHit, 'arrow-cancelled escape hit does not consume the flight attack')
assert.equal(p.command.keepLook, true)
const eye={x:0,y:1.62,z:0},target={position:{x:2,y:0,z:2},width:.6,height:1.8}
const point=nearestHitPoint(eye,target)
assert(Math.abs(point.x-1.7001)<1e-9&&Math.abs(point.z-1.7001)<1e-9)
assert.equal(point.y,eye.y,'level nearest hit keeps the eye-height ray')
assert(nearestHitPoint({...eye,y:4},target).y<1.8,'above-target aim lies inside the top face')
assert(nearestHitPoint({...eye,y:-1},target).y>0,'below-target aim lies inside the bottom face')
assert(nearestHitPoint(eye,{position:{x:0,y:0,z:0},width:.6,height:1.8}).y<1.62,
  'overlapping eyes have a finite fallback target')
const oldView={x:1,y:2,z:3,yaw:120.6001,pitch:0,onGround:true}
const exact=currentViewPacket('position_look',oldView,{yaw:1.0376771,pitch:.001})
assert.equal(exact.x,oldView.x);assert.equal(exact.onGround,oldView.onGround)
assert.equal(exact.yaw,(Math.PI-1.0376771)*180/Math.PI)
assert.equal(oldView.yaw,120.6001,'normalizing view does not mutate the physics position packet')
assert.equal(currentViewPacket('position',oldView,{yaw:1,pitch:0}),oldView)
x=fixture({attack:true});x.canHit=()=>false
out=executeCommand(x)
assert(!out.attacked);assert.equal(out.owners.attack,'blocked-line-of-sight')
assert(out.ignoredHeads.includes(4),'blocked hits are not credited as executed PPO attacks')
assert(!x.wire.some(p=>p.name==='use_entity'),'visible body elsewhere does not allow a strike through a solid block')
x=fixture({attack:true,keepLook:true,forward:1,side:-1})
x.bot.entity.yaw=1.0376771;x.bot.entity.pitch=.317123
out=executeCommand(x)
assert(out.attacked&&Number.isFinite(out.executionMs))
assert.equal(x.bot.entity.yaw,1.0376771);assert.equal(x.bot.entity.pitch,.317123)
const turns=x.wire.filter(p=>['look','use_entity'].includes(p.name))
assert.deepEqual(turns.map(p=>p.name),['look','use_entity','look'],
  'turn, attack and exact restoration complete before the synchronous call returns')
assert.deepEqual(turns.at(-1).data,{yaw:1.0376771,pitch:.317123})
assert(out.controls.forward&&out.controls.left&&!out.controls.back,'temporary aim never rewrites movement keys')
x=fixture({attack:true,keepLook:true});x.bot.entity.yaw=1.2;x.bot.entity.pitch=-.31
x.bot.attack=()=>{throw Error('write failed')}
assert.throws(()=>executeCommand(x),/write failed/)
assert.equal(x.bot.entity.yaw,1.2);assert.equal(x.bot.entity.pitch,-.31)
x=fixture();x.bot.look=()=>{} // real force-look is local-only before the adapter writes
immediateLook(x.bot,1.234567,.321)
assert.equal(x.wire.at(-1).name,'look')
assert.equal(x.wire.at(-1).data.pitch,-.321*180/Math.PI)
assert.equal(x.bot.entity.yaw,1.234567)
x=fixture({ranged:'load-crossbow',offhand:'crossbow',slot:0,attack:true})
x.frame.observation.reach=5
x.bot.inventory.slots[45]={name:'crossbow'}
x.setUse({kind:'crossbow',tick:8})
out=executeCommand(x)
assert(!out.attacked&&!out.switched)
assert.equal(x.getUse().tick,8,'impossible swing and neural slot cannot interrupt the mechanical load')
assert(!x.wire.some(p=>p.name==='block_dig'||p.name==='held_item_slot'))
assert(out.ignoredHeads.includes(4)&&out.ignoredHeads.includes(5))
x=fixture({ranged:'load-crossbow',offhand:'crossbow',attack:true})
x.bot.inventory.slots[45]={name:'crossbow'}
x.setUse({kind:'crossbow',tick:8})
out=executeCommand(x)
assert(out.attacked,'legal melee cancels an existing use and attacks in the same frame')
assert(x.wire.findIndex(p=>p.name==='block_dig')<x.wire.findIndex(p=>p.name==='use_entity'))
assert(!x.wire.some(p=>p.name==='use_item'))
x=fixture({kind:'counter',attack:true,afterAttackSlot:0})
x.shieldUntil=100
let attackSlot
x.bot.attack=()=>{attackSlot=x.bot.quickBarSlot;x.bot._client.write('use_entity',{})}
out=executeCommand(x)
assert.equal(attackSlot,7)
assert.equal(x.bot.quickBarSlot,0)
assert(x.wire.findIndex(p=>p.name==='held_item_slot')>x.wire.findIndex(p=>p.name==='use_entity'),
  'prepare the sword after the actual axe strike, without spending an extra frame')
const {attackCharge}=require('./protocol-attack-charge')
assert(Math.abs(attackCharge({tick:12,lastSwing:0,slot:0,nativeSelf:
  {held:0,receivedTick:11,charge:.88}})-.92)<1e-6)
assert.equal(attackCharge({tick:12,lastSwing:12,slot:0,nativeSelf:
  {held:0,receivedTick:11,charge:1}}),.04,'a just-switched stack cannot reuse old full charge')
x=fixture({attack:true,critical:true,kind:'escape-critical',slot:0,aimAway:true})
x.charge=()=>.92;x.bot.entity.onGround=false;x.bot.entity.velocity.y=-.3
out=executeCommand(x)
assert(out.attacked,'a native 0.88 sample is a legal half-tick 0.92 window')
assert.equal(x.bot.entity.yaw,Math.PI)
console.log('PROTOCOL_EXECUTOR_PACKET_ORDER_AND_OWNERSHIP_PASS')
