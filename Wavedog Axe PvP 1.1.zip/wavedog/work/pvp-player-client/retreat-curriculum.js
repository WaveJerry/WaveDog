/** Research allocation changes the matchup and focus, never the Bot's inputs. */
function counterRetreatPlan (plan, fighterIndex, bout) {
  const pairIndex = Math.floor(fighterIndex / 2)
  if (bout % 5 === 3) {
    const rangedSide = (Math.floor(bout / 5) + pairIndex) % 2
    const ranged = fighterIndex % 2 === rangedSide
    const bow = (Math.floor(bout / 5) + pairIndex) % 2 === 0
    return { ...plan,
      style: ranged ? 'RANGED' : 'AGGRESSIVE',
      focus: ranged ? (bow ? 'BOW' : 'CROSSBOW') : 'DODGE',
      matchup: 'RANGED vs AGGRESSIVE',
      goal: ranged
        ? '相距较远时边移动边决定装弩或拉弓；防突进，在安全出距后重装。以真发箭、箭伤和近战损益验收'
        : '对手拉弓装弩时选择合理突进；看见真实箭矢时练侧移或侧跳避开弹道，并防近战换血',
      curriculumSource: 'ranged-tempo-research' }
  }
  if (bout % 5 === 2 && pairIndex % 2 === 0) {
    const jumper = fighterIndex % 2 === (Math.floor(bout / 5) + pairIndex) % 2
    return { ...plan, focus: jumper ? 'CRITICAL' : 'SPRINT_KB',
      goal: jumper
        ? '射程外满疾跑选落点跳入，攻击前松疾跑；按起跳输入、实际落点、原生暴击与换血分开验收'
        : '以合法边缘疾跑先手刀应对跳入暴击；核对原生命中、实际水平位移与受伤',
      curriculumSource: 'critical-entry-research' }
  }
  if (bout % 5 === 4 && pairIndex % 2 === 1) {
    const sword = fighterIndex % 2 === (Math.floor(bout / 5) + pairIndex) % 2
    return { ...plan, focus: sword ? 'COMBO' : 'SYNC',
      goal: sword
        ? '无有效盾时切剑打真实连续命中和暴击，比较DPS与对方回击'
        : '应对贴身剑连击：控距、举盾、跳跃重置或反击，以实际换血验收',
      curriculumSource: 'sword-tempo-research' }
  }
  if (bout % 5 !== 0 || pairIndex % 2 !== 0) return plan
  const defensiveSide = (Math.floor(bout / 5) + pairIndex) % 2
  const variant = (Math.floor(bout / 5) + Math.floor(pairIndex / 2)) % 3
  const defender = variant === 1 || fighterIndex % 2 === defensiveSide
  const counterpart = variant === 2 ? 'MIXED' : 'AGGRESSIVE'
  return { ...plan,
    style: defender ? 'DEFENSIVE' : counterpart,
    focus: defender ? 'ESCAPE' : variant === 2 ? 'SYNC' : 'CRITICAL',
    matchup: variant === 1 ? 'DEFENSIVE vs DEFENSIVE'
      : `${counterpart} vs DEFENSIVE`,
    goal: defender
      ? '公开观察对手来刀，在合法边缘真实挡刀、反击命中后水平出距并避免被追击换血'
      : variant === 2
        ? '中性打法保持合法控距，依对手盾反后撤结果选择追击、回盾或重新入距'
        : '用合法边缘疾跑攻击、绕盾、选落点跳劈和持续跟进检验对手盾反后撤；分开统计真命中、出距及净换血',
    curriculumSource: 'counter-retreat-research' }
}

module.exports = { counterRetreatPlan }
