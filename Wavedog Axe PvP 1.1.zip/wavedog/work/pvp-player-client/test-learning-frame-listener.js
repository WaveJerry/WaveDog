const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const { installLearningFrames } = require('./learning-frame-listener')
const bots = ['NBot01', 'NBot02', 'NBot03', 'NBot04'].map(username =>
  Object.assign(new EventEmitter(), { username }))
const sessions = new Map(bots.map(b => [b.username,
  { name: b.username, clientFrame: 0, framesSeen: 0, requests: 0 }]))
const observed = []
const dependencies = { sessions,
  recordFighterFrame: (session, bot) => {
    assert.equal(session.name, bot.username)
    observed.push([session.name, session.clientFrame])
  }, requestAction: session => { session.requests++ } }
let clock = 0
for (const bot of bots) {
  bot.on('physicsTick', () => clock++)
  installLearningFrames(bot, dependencies)
  installLearningFrames(bot, dependencies)
}
for (let frame = 0; frame < 60; frame++) for (const bot of bots) bot.emit('physicsTick')
for (const session of sessions.values()) {
  assert.equal(session.clientFrame, 60)
  assert.equal(session.framesSeen, 60)
  assert.equal(session.requests, 60)
}
assert.equal(clock, 240)
assert.equal(observed.length, 240)
sessions.delete('NBot02')
bots[1].emit('physicsTick')
assert.equal(observed.length, 240, 'no observation or action after session ends')
sessions.set('NBot02', { name: 'NBot02', clientFrame: 0, framesSeen: 0, requests: 0 })
bots[1].emit('physicsTick')
assert.equal(sessions.get('NBot02').clientFrame, 1, 'a new bout gets a fresh counter')
console.log(JSON.stringify({ event: 'FOUR_BOT_FRAME_ISOLATION_PASS', framesPerBot: 60,
  duplicateInstallSafe: true, unrelatedListenersPreserved: true }))
