const assert=require('node:assert/strict')
const {edgePlan}=require('./probe-edge-controller')
const position={x:0,y:0,z:0},target={position:{x:0,y:0,z:3.299},width:.6,height:1.8}
const ctx={position,sentPosition:position,target,tick:100,lastAttack:80,lastWeaponTick:70}
let p=edgePlan(ctx);assert(p.attack&&p.edgeWindow);assert(p.reach>2.998&&p.reach<=3)
p=edgePlan({...ctx,target:{...target,position:{x:0,y:0,z:3.301}}});assert(!p.attack)
p=edgePlan({...ctx,sentPosition:{x:0,y:0,z:-.1}});assert(!p.attack,'unsent local progress cannot manufacture range')
p=edgePlan({...ctx,lastAttack:98});assert(!p.attack,'ordinary damage attacks respect the weapon charge')
p=edgePlan({...ctx,target:{...target,position:{x:0,y:0,z:4.5}}});assert(p.forward===1&&p.sprint&&!p.jump)
p=edgePlan({...ctx,target:{...target,position:{x:0,y:0,z:1.8}}});assert(p.attack&&p.forward===-1&&!p.sprint)
console.log('TEST_OPPONENT_EDGE_RANGE_PASS')
