"""Compare native shield-counter retreat evidence before and after a curriculum switch."""
from pathlib import Path
import argparse
import json

base = Path(__file__).resolve().parent / "new-learning/selfplay"
parser = argparse.ArgumentParser()
parser.add_argument("--since", required=True, help="UTC ISO timestamp of deployment")
parser.add_argument("--baseline", type=int, default=150)
args = parser.parse_args()

rounds = [json.loads(line) for line in (base / "rounds.jsonl").read_text(encoding="utf-8").splitlines()
          if line.strip()]
before = [row for row in rounds if row.get("at", "") < args.since][-args.baseline:]
after = [row for row in rounds if row.get("at", "") >= args.since]


def summary(rows):
    keys = ("blockedMelee", "counterHits", "counterProgress", "counterPunished",
            "counterEscapes", "edgeCounterHits", "edgeCounterEscapes", "safeHitExits")
    totals = {key: 0 for key in keys}
    focused = 0
    both_trained = 0
    frames_archived = 0
    for row in rows:
        if any(f.get("curriculumSource") == "counter-retreat-research"
               for f in row.get("fighters", {}).values()):
            focused += 1
        if len(row.get("training", [])) == 2 and not row.get("trainingError"):
            both_trained += 1
        if row.get("frameArchive", {}).get("sha256"):
            frames_archived += 1
        for tactic in row.get("tactics", {}).values():
            for key in keys:
                totals[key] += tactic.get(key, 0) or 0
    return {"bouts": len(rows), "focusedBouts": focused,
            "bothGruUpdated": both_trained, "framesArchived": frames_archived,
            "tactics": totals}


print(json.dumps({"since": args.since, "baseline": summary(before),
                  "after": summary(after)}, ensure_ascii=False, indent=2))
