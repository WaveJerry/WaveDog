'use strict'
// Exact ordinary protocol inputs of the existing teacher. No combat control.
const fs=require('node:fs'),path=require('node:path')
const {Vec3}=require('vec3')
const {nearestHitPoint}=require('./protocol-mechanical-math')
function loaded(item){
  const data=item?.componentMap?.get('charged_projectiles')?.data
  const projectiles=Array.isArray(data)?data:data?.projectiles
  if(projectiles?.some(p=>(p.itemCount??p.count??0)>0))return true
  const c=item?.components?.find(c=>c.type==='charged_projectiles'||c.type==='minecraft:charged_projectiles')
  return Boolean(c?.data?.projectiles?.length||c?.data?.items?.length
    ||item?.nbt?.value?.Charged?.value||item?.nbt?.value?.ChargedProjectiles?.value?.value?.length)
}
function createProbeRecorder(bot){
  let current=null,currentFile=null,lastAttack=-1000,lastSwitch=-1000,sent=null
  const started=new Set()
  function clear(a,b){const d=b.minus(a),n=d.norm();return n<.001||!bot.world.raycast(a,d.scaled(1/n),n)}
  return {
    packet(name,data,tick){
      if(name==='held_item_slot')lastSwitch=tick
      if(name==='use_entity'&&data.mouse===1)lastAttack=tick
      if(['position','position_look'].includes(name)){
        const ground=data.onGround??data.flags?.onGround
        sent={x:data.x,y:data.y,z:data.z,ground,falling:Boolean(sent&&!ground&&data.y<sent.y-.00001)}
      }
      if(current&&['use_entity','held_item_slot','entity_action','arm_animation'].includes(name))
        current.packets.push({name,data})
    },
    begin(cmd,target,tick){
      if(current)throw Error('Previous demonstration frame was not synchronously closed')
      current=null
      if(!cmd.active||!cmd.demonstrationFile||!cmd.matchId||!target||!bot.entity)return
      const file=path.resolve(cmd.demonstrationFile)
      const root=path.resolve(__dirname,'../../outputs/punengbho-rebuild-20261117')+path.sep
      if(!file.startsWith(root))throw Error('Demonstration path must remain inside the rebuild directory')
      const e=bot.entity,p=e.position,v=e.velocity,eye=p.offset(0,e.eyeHeight||1.62,0),tp=target.position
      const visible=p.distanceTo(tp)<64&&(clear(eye,tp.offset(0,1.3,0))||clear(eye,tp.offset(0,.6,0)))
      const flags=Number(target.metadata?.[8]||0),using=Boolean(flags&1)
      const active=(flags&2)?target.equipment?.[1]:target.equipment?.[0]
      const slot=bot.quickBarSlot,cooldown=slot===0?12.5:20
      const inventory=bot.inventory?.slots?.filter(Boolean)||[]
      const floor=bot.world.raycast(p.offset(0,.1,0),new Vec3(0,-1,0),8)
      const wall=(dx,dz)=>{const from=p.offset(0,.9,0),hit=bot.world.raycast(from,new Vec3(dx,0,dz),8);return hit?.intersect?from.distanceTo(hit.intersect):8}
      const request={command:'act',fighter:bot.username,opponent:cmd.target,matchId:cmd.matchId,tick,
        requestId:tick,yaw:180-e.yaw*180/Math.PI,pitch:-e.pitch*180/Math.PI,
        focus:'FREE',style:'MIXED',trainingScope:'pure_model_all_input',
        self:{x:p.x,y:p.y,z:p.z,eyeY:eye.y,vx:v.x,vy:v.y,vz:v.z,ground:e.onGround,
          charge:Math.min(1,(tick-Math.max(lastAttack,lastSwitch)+.5)/cooldown),health:bot.health,food:bot.food,
          held:slot,sprint:bot.getControlState('sprint'),critical:!e.onGround&&Boolean(sent?.falling),
          attackAgeTicks:tick-lastAttack,weaponAgeTicks:tick-lastSwitch,
          wireFalling:sent?.falling??false,wireGround:sent?.ground??null,
          shieldAvailable:bot.inventory?.slots?.[45]?.name==='shield'&&tick>=(cmd.shieldDisabledUntil??-1),
          shielding:false,using:false,useTicks:0,
          arrows:inventory.filter(i=>i.name==='arrow').reduce((n,i)=>n+i.count,0),
          crossbowLoaded:inventory.some(i=>i.name==='crossbow'&&loaded(i)),
          hasBow:inventory.some(i=>i.name==='bow'),hasCrossbow:inventory.some(i=>i.name==='crossbow')},
        seen:visible?{visible:true,x:tp.x,y:tp.y,z:tp.z,yaw:180-target.yaw*180/Math.PI,
          shield:using&&active?.name==='shield',using,held:(target.equipment?.[0]?.name||'UNKNOWN').toUpperCase(),swing:0,arrows:[]}:{visible:false,arrows:[]},
        publicTerrain:{selfY:p.y,groundY:floor?.intersect?.y??p.y,walls:[wall(-1,0),wall(1,0),wall(0,-1),wall(0,1)]}}
      if(!started.has(file)){fs.mkdirSync(path.dirname(file),{recursive:true});
        fs.appendFileSync(file,JSON.stringify({type:'start',schema:'exact-protocol-demonstration-v2',
          synchronousFrameFinalization:true,
          ppoEligible:false,fighter:bot.username,opponent:cmd.target,matchId:cmd.matchId,mode:cmd.mode,
          closeJumpVersion:cmd.closeJumpVersion??1,
          tacticalCurriculumVersion:cmd.tacticalCurriculumVersion??1,
          requestedStartDistance:cmd.requestedStartDistance??null,
          actualTeacherStartDistance:p.distanceTo(tp)})+'\n');started.add(file)}
      current={type:'frame',at:Date.now(),tick,publicRequest:request,packets:[],
        reach:visible?eye.distanceTo(new Vec3(...Object.values(nearestHitPoint(eye,target)))):null}
      currentFile=file
    },
    end(){
      if(!current)return
      const row=current,e=bot.entity
      row.executed=Object.fromEntries(['forward','back','left','right','jump','sprint','sneak'].map(k=>[k,bot.getControlState(k)]))
      row.held=bot.quickBarSlot;row.heldItemName=bot.heldItem?.name??null
      row.attackPacket=row.packets.some(p=>p.name==='use_entity'&&p.data.mouse===1)
      row.executedView={yaw:180-e.yaw*180/Math.PI,pitch:-e.pitch*180/Math.PI}
      fs.appendFileSync(currentFile,JSON.stringify(row)+'\n')
      current=null;currentFile=null
    }
  }
}
module.exports={createProbeRecorder}
