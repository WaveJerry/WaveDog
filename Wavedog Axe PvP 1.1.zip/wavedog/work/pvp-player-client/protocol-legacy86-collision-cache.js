'use strict'
// Public block shapes only. Invalidate on block/chunk updates and world changes;
// never treat an unloaded/unknown block as free space.
function createCollisionCache({blockAt,maxCells=65536}={}){
  const cells=new Map(),stats={hits:0,misses:0,invalidations:0}
  return {
    get(x,y,z){
      const key=x+','+y+','+z
      if(cells.has(key)){stats.hits++;return cells.get(key)}
      stats.misses++
      const block=blockAt(x,y,z),value=block?{shapes:block.shapes||[]}:null
      if(cells.size>=maxCells)cells.clear()
      cells.set(key,value);return value
    },
    invalidate(position){cells.delete(Math.floor(position.x)+','+Math.floor(position.y)+','+Math.floor(position.z));stats.invalidations++},
    clear(){cells.clear();stats.invalidations++},
    get stats(){return {...stats,cells:cells.size}}
  }
}
module.exports={createCollisionCache}
