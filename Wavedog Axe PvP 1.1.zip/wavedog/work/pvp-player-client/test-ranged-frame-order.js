'use strict'
const assert=require('node:assert/strict')
const {createFrameClock}=require('./protocol-frame-clock')
const {observeRanged}=require('./protocol-ranged-observation')
const {createState,plan}=require('./protocol-wavedog-brain')
async function main(){
  const packets=[],clock=createFrameClock(()=>packets.push('attack'))
  clock.beforeSimulation();clock.physicsTick();packets.push('position');clock.movementWritten('position')
  await Promise.resolve();assert.deepEqual(packets,['position','attack'])
  clock.beforeSimulation();clock.physicsTick();clock.beforeSimulation()
  clock.physicsTick();packets.push('position');clock.movementWritten('position')
  await Promise.resolve();assert.deepEqual(packets,['position','attack','attack','position','attack'])
  clock.beforeSimulation();clock.physicsTick();await Promise.resolve()
  assert.equal(packets.filter(x=>x==='attack').length,4,'idle and catch-up frames run once each')
  assert.equal(packets.filter(x=>x==='position').length,2,'the adapter creates no movement packets')
  const loaded=i=>Boolean(i?.charged),empty={name:'crossbow'},ready={...empty,charged:true}
  const state={targetKnownLoaded:true}
  let o=observeRanged(state,{tick:10,visible:true,using:true,activeItem:empty,mainhand:empty},loaded)
  assert(o.targetLoading&&!o.targetKnownLoaded,'new public empty-crossbow use invalidates an old loaded memory')
  for(let tick=11;tick<40;tick++)observeRanged(state,{tick,visible:true,using:true,activeItem:empty,mainhand:empty},loaded)
  o=observeRanged(state,{tick:40,visible:true,using:false,activeItem:empty,mainhand:empty},loaded)
  assert(!o.targetKnownLoaded,'thirty observed ticks do not prove a cancelled load succeeded')
  assert.equal(o.targetLoadResult,'unconfirmed')
  o=observeRanged(state,{tick:41,visible:true,using:false,mainhand:ready},loaded)
  assert(o.targetKnownLoaded)
  o=observeRanged(state,{tick:42,visible:true,using:false,mainhand:ready,fired:true},loaded)
  assert(!o.targetKnownLoaded,'the arrow event outranks stale charged equipment for that frame')
  o=observeRanged(state,{tick:43,visible:true,using:true,activeItem:empty,mainhand:empty},loaded)
  assert(o.targetLoading&&!o.targetKnownLoaded)
  // Real failure: t8036 started a second load; old knownLoaded stayed true.
  const s=createState(),p=plan(s,{tick:8038,health:20,ground:true,shieldReady:false,
    visible:true,reach:8,distance:8.6,charge:1,held:7,arrows:4,...o},null)
  assert.equal(p.command.ranged,'load-crossbow')
  const cancelled=plan(s,{tick:8039,health:20,ground:true,shieldReady:false,
    visible:true,reach:8,distance:8.6,charge:1,held:7,arrows:4,...o,
    arrowThreat:{time:1,side:-1}},null)
  assert(!cancelled.command.ranged&&cancelled.owners.movement==='mechanical-arrow')
  console.log('RANGED_PUBLIC_CYCLE_AND_PHYSICAL_PACKET_ORDER_PASS')
}
main().catch(e=>{console.error(e);process.exitCode=1})
