'use strict'
const {solveRangedAim}=require('./protocol-ranged-aim')
const {segmentHitsBox}=require('./wavedog-arrow-predictor')
// Public, conservative counterpart of original cannotDodgeOutgoing(). This
// is a finite forecast, never a guarantee or a read of the opponent's keys.
function loadingReplyWindow({eye,feet,motion,grounded,floorY,height=1.8,profile,clearPath,shieldRaised=false}){
  if(shieldRaised||!clearPath||!Number.isFinite(floorY)||typeof grounded!=='boolean')return {eligible:false,reason:'unknown-or-shielded'}
  const shot=solveRangedAim({eye,feet,motion,airborne:!grounded,floorY,height,speed:3.15,profile})
  if(!shot||shot.flightTicks>4)return {eligible:false,reason:'flight-too-long'}
  const horizon=5,paths=[]
  for(let k=0;k<9;k++)for(const jump of grounded?[false,true]:[false]){
    const angle=k*Math.PI/4,accel=k===8?0:.13
    let p={...feet},v={...motion},onGround=grounded,hit=false,arrow={...eye},av={
      x:shot.direction.x*3.15,y:shot.direction.y*3.15,z:shot.direction.z*3.15}
    // Allow one tick of reaction before the outgoing packet is observed.
    for(let tick=0;tick<=horizon;tick++){
      if(jump&&tick===0){v.y=.42;onGround=false}
      v.x=(v.x+Math.cos(angle)*accel)*(onGround?.546:.91)
      v.z=(v.z+Math.sin(angle)*accel)*(onGround?.546:.91)
      const next={x:p.x+v.x,y:onGround?p.y:p.y+v.y,z:p.z+v.z}
      if(!onGround){v.y=(v.y-.08)*.98;if(next.y<=floorY){next.y=floorY;onGround=true;v.y=0}}
      if(tick>0){
        const end={x:arrow.x+av.x,y:arrow.y+av.y,z:arrow.z+av.z}
        if(!clearPath(arrow,end))return {eligible:false,reason:'blocked-flight'}
        // Relative segment covers target movement during the same tick.
        const relativeEnd={x:end.x-(next.x-p.x),y:end.y-(next.y-p.y),z:end.z-(next.z-p.z)}
        if(segmentHitsBox(arrow,relativeEnd,p,.52,-.2,Math.min(height,1.5)+.2)){hit=true;break}
        arrow=end;av.x*=.99;av.y=av.y*.99-.05;av.z*=.99
      }
      p=next
    }
    paths.push(hit)
    if(!hit)return {eligible:false,reason:'public-evasion-found',flightTicks:shot.flightTicks,checkedPaths:paths.length}
  }
  return {eligible:true,reason:'short-flight-public-evasion-envelope',flightTicks:shot.flightTicks,
    checkedPaths:paths.length,horizonTicks:horizon,guaranteedHit:false}
}
module.exports={loadingReplyWindow}
