// Ordinary Minecraft 1.21.1 network players, independent GRU actors and
// per-fighter Qwen contexts. Native Paper deaths decide whether PPO trains.
const mineflayer = require('mineflayer')
const mcData = require('minecraft-data')('1.21.1')
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const childProcess = require('node:child_process')
const { promisify } = require('node:util')
const { Vec3 } = require('vec3')
const { RaycastIterator } = require('prismarine-world').iterators
const { schedule: scheduleCurriculum } = require('./curriculum')
const { selectPlayerExperience, selectMeasuredLessons } = require('./durable-memory')
const { NativeEventStream, mergeTimeline } = require('./native-feedback')
const { bowSpeed, plannedBowDrawMs, solvePitch, leadTarget } = require('./ballistic-aim')
const { analyzeTactics } = require('./tactical-outcomes')

const execFile = promisify(childProcess.execFile)
const base = __dirname
const server = path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server')
const store = path.join(base, 'new-learning', 'selfplay')
const checkpoint = path.join(base, 'new-learning', 'models')
const readyFile = path.join(base, 'new-learning', 'selfplay-ready.json')
const token = fs.readFileSync(path.join(server, 'plugins', 'WaveDogSelfPlayGate', 'selfplay-token.txt'), 'utf8').trim()
const serverRunId = crypto.createHash('sha256').update(token).digest('hex').slice(0, 12)
const count = Number(process.argv.find(a => a.startsWith('--bots='))?.split('=')[1] || 2)
const rangedValidation = process.env.WAVEDOG_VALIDATION_RANGED === '1'
const debugCrossbow = process.env.WAVEDOG_DEBUG_CROSSBOW === '1'
if (!Number.isInteger(count) || count < 2 || count > 60 || count % 2) throw Error('--bots must be even 2..60')
const arenaCount = count / 2
const names = Array.from({ length: count }, (_, i) => `NBot${String(i + 1).padStart(2, '0')}`)
const authPath = path.join(base, '.auth-selfplay.json')
const credentials = fs.existsSync(authPath) ? JSON.parse(fs.readFileSync(authPath, 'utf8')) : {}
for (const name of names) credentials[name] ||= crypto.randomBytes(18).toString('hex')
fs.writeFileSync(authPath, JSON.stringify(credentials), { mode: 0o600 })
fs.mkdirSync(store, { recursive: true })

const focusNames = new Set(['FREE','CHARGE','SHIELD','AXE_BREAK','CRITICAL','SPRINT_KB','ESCAPE','SYNC','FLANK','COMBO','BOW','CROSSBOW','DODGE','WALL','LATENCY','OPPONENT'])
const styleNames = new Set(['AGGRESSIVE','DEFENSIVE','FLANK','GROUND_COMBO','RANGED','MIXED'])
const focusSchema = { type: 'string', enum: [...focusNames] }
const coachSchema = { type: 'object', properties: {
  focus: focusSchema, style: { type: 'string', enum: [...styleNames] },
  reason: { type: 'string', maxLength: 120 } },
required: ['focus','style','reason'], additionalProperties: false }
const reviewSchema = { type: 'object', properties: {
  focusA: focusSchema, focusB: focusSchema, lesson: { type: 'string', maxLength: 120 } },
required: ['focusA','focusB','lesson'], additionalProperties: false }
const batchReviewSchema = { type: 'object', properties: {
  focus: focusSchema, lesson: { type: 'string', maxLength: 90 } },
required: ['focus','lesson'], additionalProperties: false }
const REVIEW_BATCH_SIZE = 4
const styleRotation = ['AGGRESSIVE','DEFENSIVE','RANGED','FLANK','GROUND_COMBO','MIXED']
const focusRotation = [...focusNames]
function curriculumFor (fighter, bout) {
  const index = names.indexOf(fighter)
  if (rangedValidation && validationOrigin === null) validationOrigin = bout
  const validationBout = bout - validationOrigin + 1
  if (rangedValidation && validationBout <= 4) return { style: 'RANGED',
    focus: (validationBout + index) % 2 ? 'BOW' : 'CROSSBOW',
    scheduledFocus: 'VALIDATION', curriculumSource: 'ranged-validation' }
  const qwen = sharedLessons.filter(row => row.lessonSource === 'measured-after-Qwen'
    && focusNames.has(row.focus) && row.focus !== 'FREE')
    .sort((a,b) => String(b.boutAt || b.at || '').localeCompare(String(a.boutAt || a.at || '')))[0]
  const plan = scheduleCurriculum(index, bout, styleRotation, focusRotation, qwen?.focus)
  if (researchOpeners.delete(fighter)) {
    // One opening comparison only. Later bouts return to measured Qwen advice
    // and the full coverage cycle; no combat inputs are scripted here.
    const opening = [
      ['ESCAPE','DEFENSIVE'], ['AXE_BREAK','AGGRESSIVE'],
      ['BOW','RANGED'], ['CROSSBOW','RANGED']][index % 4]
    return { ...plan, focus: opening[0], style: opening[1],
      curriculumSource: 'research-opening' }
  }
  return plan
}
const humanTrialsPath = path.join(base, 'new-learning', 'human-trial-results.jsonl')
const humanTrials = fs.existsSync(humanTrialsPath) ? fs.readFileSync(humanTrialsPath, 'utf8').split(/\r?\n/)
  .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  .filter(row => row.reason === 'death').slice(-4) : []
const bots = new Map(), readyBots = new Set(), sessions = new Map(), pairs = new Map(), contexts = new Map()
let activeChallenge = null
let validationOrigin = null
const finishWaiters = new Map()
let bridge, bridgeReady = false, bridgeBuffer = '', nextRequestId = 0, desired = 0, stopping = false
let qwenActive = 0
const qwenQueue = []
const sharedLessonsPath = path.join(store, 'shared-lessons.jsonl')
const roundsPath = path.join(store, 'rounds.jsonl')
const challengesPath = path.join(store, 'human-challenges.jsonl')
const humanEventsPath = path.join(store, 'human-native-events.jsonl')
const humanFramesPath = path.join(store, 'human-frames.jsonl')
const nativeEvents = new NativeEventStream(path.join(server, 'plugins', 'WaveDogSelfPlayGate', 'bouts.jsonl'))
async function takeNativeBout (arena, bout) {
  for (let attempt = 0; attempt < 20; attempt++) {
    const record = nativeEvents.takeRecord(arena, bout)
    if (record) return record
    await new Promise(resolve => setTimeout(resolve, 100))
  }
  return null
}
const coachPath = path.join(store, 'coach-contexts.jsonl')
const playerExperiencePath = path.join(store, 'player-experience.jsonl')
const qwenErrorsPath = path.join(store, 'qwen-errors.jsonl')
const qualityFlagsPath = path.join(store, 'quality-flags.jsonl')
const researchOpeners = new Set(names)
const researchHistory = fs.existsSync(roundsPath)
  ? fs.readFileSync(roundsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { return [JSON.parse(line)] } catch { return [] }
  }).filter(row => row.reason === 'death' && Object.values(row.tactics || {})
    .some(t => Number.isInteger(t?.edgeCounterEscapes))).slice(-24) : []
function researchFocusChoices () {
  const evidence = researchEvidence()
  if (evidence.bouts < 8 || evidence.edgeCounterEscapes === 0
      || evidence.counterEscapeArrows === 0 || evidence.edgeCounterPunished > 0)
    return ['ESCAPE','SHIELD','BOW','CROSSBOW']
  if (evidence.rangedExchange === 0) return ['BOW','CROSSBOW','DODGE','ESCAPE']
  return [...focusNames]
}
function researchEvidence () {
  const recent = researchHistory.slice(-24)
  const count = key => recent.reduce((sum, row) => sum + Object.values(row.tactics || {})
    .reduce((n,t) => n + (t[key] || 0),0),0)
  return { bouts: recent.length,
    edgeHits: count('edgeHits'), safeEdgeHits: count('safeEdgeHits'),
    safeHitExits: count('safeHitExits'), edgeCounterEscapes: count('edgeCounterEscapes'),
    counterEscapeArrows: count('counterEscapeArrows'),
    edgeCounterPunished: count('edgeCounterPunished'),
    rangedExchange: count('rangedExchange') }
}
const invalidMatchIds = new Set(fs.existsSync(qualityFlagsPath)
  ? fs.readFileSync(qualityFlagsPath, 'utf8').split(/\r?\n/).flatMap(line => {
    try { const row = JSON.parse(line); return row.status === 'mechanics-invalid' ? [row.matchId] : [] }
    catch { return [] }
  }) : [])
const allSharedLessons = fs.existsSync(sharedLessonsPath) ? fs.readFileSync(sharedLessonsPath, 'utf8').split(/\r?\n/)
  .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } }) : []
const sharedLessons = allSharedLessons.filter(row => !invalidMatchIds.has(row.matchId))
let experienceReadIndex = 0, lessonReadIndex = 0
const latestContexts = fs.existsSync(coachPath) ? fs.readFileSync(coachPath, 'utf8').split(/\r?\n/)
  .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } }) : []
for (const row of latestContexts) if (names.includes(row.fighter) && focusNames.has(row.focus)) contexts.set(row.fighter, row)
function reviewKey (row) {
  if (row.matchId) return row.matchId
  const at = String(row.at || '')
  const era = at < '2026-11-11T09:13:52' ? 'before-1713'
    : at < '2026-11-11T09:54:20' ? '1713-to-1754' : 'after-1754'
  return `${era}:${row.arena}:${row.bout}`
}
const reviewedKeys = new Set(allSharedLessons.map(reviewKey))
const humanReviewedKeys = new Set(allSharedLessons.filter(row => row.source === 'human-challenge-Qwen').map(reviewKey))
const humanQueuedReviews = new Set()
const queuedReviews = new Set(), pendingReviews = []
const historicalRoundBacklog = [], historicalHumanBacklog = []
let batchReviewsActive = 0, reviewRetryAfter = 0
let reviewBatchLimit = REVIEW_BATCH_SIZE

function now () { return new Date().toISOString() }
function append (file, row) { fs.appendFileSync(file, JSON.stringify({ at: now(), ...row }) + '\n') }
function playerExperience (limit = 8) {
  if (!fs.existsSync(playerExperiencePath)) return []
  const rows = fs.readFileSync(playerExperiencePath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  return selectPlayerExperience(rows, experienceReadIndex++, limit)
}
function recentLessons (limit) {
  return selectMeasuredLessons([...sharedLessons].sort((a,b) =>
    String(a.boutAt || a.at || '').localeCompare(String(b.boutAt || b.at || ''))),
  lessonReadIndex++, limit)
}
function orderedMemory () {
  const experience = playerExperience(6)
  const lessons = recentLessons(2)
  const playerRows = fs.existsSync(playerExperiencePath)
    ? fs.readFileSync(playerExperiencePath, 'utf8').split(/\r?\n/).flatMap(line => {
      try { return [JSON.parse(line)] } catch { return [] }
    }) : []
  const rows = [...experience.map(text => {
    const row = [...playerRows].reverse().find(x => x.text?.trim().slice(0, 160) === text)
    return { at: row?.at || '', source: 'player', text: text.slice(0,120) }
  }), ...lessons.map(text => {
    const row = [...sharedLessons].reverse().find(x => x.lesson?.trim().slice(0, 120) === text)
    return { at: row?.boutAt || row?.at || '', source: 'measured', text }
  })]
  return rows.sort((a, b) => a.at.localeCompare(b.at))
}
function log (event, data = {}) { console.log(JSON.stringify({ at: now(), event, ...data })) }
function sendBridge (value) { if (!bridge?.stdin.writable) throw Error('GRU bridge is offline'); bridge.stdin.write(JSON.stringify(value) + '\n') }
async function rcon (command) {
  const args = [path.join(base, '..', '..', 'outputs', 'MC-Public', 'rcon_local.py'), ...command.split(' ')]
  const { stdout } = await execFile('python', args, { cwd: base, windowsHide: true, timeout: 20000 })
  return stdout.trim()
}
function scheduleQwen (task, priority = false) {
  return new Promise((resolve, reject) => {
    if (priority) qwenQueue.unshift({ task, resolve, reject })
    else qwenQueue.push({ task, resolve, reject })
    pumpQwen()
  })
}
function pumpQwen () {
  while (qwenActive < 1 && qwenQueue.length) {
    const item = qwenQueue.shift(); qwenActive++
    item.task().then(item.resolve, item.reject).finally(() => { qwenActive--; pumpQwen() })
  }
}
async function inferQwen (messages, maxTokens = 128, schema = null) {
  const body = { model: 'wavedog-tactics', temperature: 0.25, max_tokens: maxTokens,
    messages, response_format: { type: 'json_object', ...(schema ? { schema } : {}) } }
  const response = await fetch('http://127.0.0.1:18765/v1/chat/completions', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    signal: AbortSignal.timeout(150000) })
  if (!response.ok) throw Error(`Qwen HTTP ${response.status}: ${(await response.text()).slice(0,300)}`)
  const data = await response.json()
  const raw = data.choices[0].message.content
  try { return JSON.parse(raw) }
  catch (error) { throw Error(`Qwen JSON parse: ${String(error)}; raw=${raw.slice(0,500)}`) }
}
const coachSystem = 'You are one fighter-specific PvP coach for a Minecraft Java 1.21.1 GRU64 bot. The shared memory is a time-ordered selection from one global, append-only history; never reverse causal order or claim omitted history was forgotten. Choose one testable focus from FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT. Close melee is already useful; prioritize testing legal edge hits and decisions after leaving melee range: short retreat that keeps a hit advantage, safe re-entry, bow shot, loaded crossbow, or responding to a rush. Judge by native hits, replies, actual horizontal separation and arrows launched, not weapon selections. Train from many angles and preserve every useful move by revisiting all styles and measured skills. Test opening crossbow load from 24-block separation during the first five seconds, but choose whether to reload after each exchange from actual safety and rush distance. Low health calls for active survival and effective counterplay, not passive stalling. An early finishing hit is useful only when public evidence supports it; never read hidden opponent health. Test axe shield breaks, jump reset and arrow dodges from actual native evidence. These are hypotheses, not fixed scripts. Preserve valid prior bouts, and do not claim Qwen weights changed. Return compact JSON {"focus":"...","style":"...","reason":"specific measurable hypothesis"}.'
async function coachFighter (fighter, opponent) {
  const previous = contexts.get(fighter)
  const index = names.indexOf(fighter)
  const suggestedStyle = styleRotation[(Math.floor(index/2)+(index%2))%styleRotation.length]
  try {
    const answer = await scheduleQwen(() => inferQwen([
      { role: 'system', content: coachSystem },
      { role: 'user', content: JSON.stringify({ fighter, opponent, suggestedStyle,
        previousFocus: previous?.focus || 'FREE', previousStyle: previous?.style || suggestedStyle,
        previousReason: previous?.reason || '', ownRecent: previous?.ownRecent || [],
        chronologicalMemory: orderedMemory(),
        recentResearchEvidence: researchEvidence(),
        recentValidatedHumanTrials: humanTrials,
        trainingAgenda: '近身互殴已有成果。先研究合法射程边缘盾挡反击后命中、水平出距与弓弩互射；还要避免自己在敌方举盾时白送反击。看真实挡刀、原生命中、禁盾、水平位移、反击和发箭计数；开出研究机会后根据证据自主选下一目标，继续轮换其他招式。',
        question: 'What weakness or strength should this fighter test next against this named opponent?' }) }
    ], 160, coachSchema))
    if (!focusNames.has(answer.focus)) throw Error(`Invalid focus ${answer.focus}`)
    const context = { fighter, opponent, focus: answer.focus,
      style: suggestedStyle,
      reason: String(answer.reason || '').slice(0, 160),
      ownRecent: previous?.ownRecent || [], source: 'Qwen2.5-1.5B-Instruct' }
    contexts.set(fighter, context); append(coachPath, context)
    return context
  } catch (error) {
    append(qwenErrorsPath, { phase: 'fighter', fighter, opponent, error: String(error) })
    throw error
  }
}
async function reviewPair (pair, report) {
  const a = contexts.get(pair.a), b = contexts.get(pair.b)
  const both = [a, b]
  for (const context of both) {
    const own = report.fighters[context.fighter]
    context.ownRecent = [...(context.ownRecent || []), { bout: report.bout, opponent: own.opponent,
      win: report.winner === context.fighter, attacks: own.attacks, misses: own.misses,
      rejected: own.rejected, bowChoices: own.bowChoices, crossbowChoices: own.crossbowChoices,
      ammoConsumed: own.ammoConsumed }].slice(-4)
  }
  if (report.reason !== 'death') return true
  try {
    const answer = await scheduleQwen(() => inferQwen([
      { role: 'system', content: 'You are the shared PvP research brain. Two independent fighter contexts return after one native Minecraft 1.21.1 bout. Use the measured winner, attacks, misses and ammunition. Give one concrete, testable lesson grounded in those counts and a next focus for each fighter. Rotate across aggressive pressure versus shield-counter escape, defensive spacing, flanking, ground combos, ranged tempo, charged attacks and necessary light hits. For close combat consider a real axe shield break and jump reset near an observed hit; both need native evidence. Do not repeat a previous lesson, invent special stun frames or hidden inputs, or claim Qwen weights changed. Return only JSON {"focusA":"AXE_BREAK","focusB":"SYNC","lesson":"specific measured hypothesis"}. Valid focus values: FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT.' },
      { role: 'user', content: JSON.stringify({ a, b, completedBout: {
        arena: report.arena, bout: report.bout, winner: report.winner, reason: report.reason,
        fighters: report.fighters },
        sharedRecent: recentLessons(5),
        playerSavedExperience: playerExperience(),
        trainingAgenda: '检查控距连招、惩罚暴击、盾反后撤弓弩、斧击破盾、jump reset；只根据本局可见行为和原生伤害结果提出下一次实验。' }) }
    ], 160, reviewSchema), true)
    if (!focusNames.has(answer.focusA) || !focusNames.has(answer.focusB))
      throw Error(`Invalid shared focus: ${JSON.stringify(answer).slice(0,350)}`)
    const lesson = String(answer.lesson || '').slice(0, 220)
    const row = { arena: pair.arena, bout: pair.bout, fighters: [pair.a, pair.b],
      focusA: answer.focusA, focusB: answer.focusB, lesson,
      source: 'Qwen2.5-1.5B-Instruct' }
    sharedLessons.push(row); append(sharedLessonsPath, row)
    for (const [context, focus] of [[a, answer.focusA], [b, answer.focusB]]) {
      context.focus = focus; context.reason = lesson
      append(coachPath, context)
    }
    log('shared_qwen_review', { arena: pair.arena, bout: pair.bout, focusA: a.focus, focusB: b.focus, lesson })
    return true
  } catch (error) {
    append(qwenErrorsPath, { phase: 'shared_review', arena: pair.arena, bout: pair.bout, error: String(error) })
    log('shared_qwen_error', { arena: pair.arena, bout: pair.bout, error: String(error) })
    return false
  }
}
async function replayMissingReviews () {
  if (!fs.existsSync(roundsPath)) return
  const oldRounds = fs.readFileSync(roundsPath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  const missing = oldRounds.filter(report => report.training?.length && !report.trainingError
    && !reviewedKeys.has(reviewKey(report)))
  historicalRoundBacklog.push(...missing.slice(0,-4))
  for (const report of missing.slice(-4)) enqueueReview(report)
  log('review_recovery', { pending: pendingReviews.length,
    historicalBacklog: historicalRoundBacklog.length, reviewed: reviewedKeys.size })
}
function replayMissingHumanReviews () {
  if (!fs.existsSync(challengesPath)) return
  const reports = fs.readFileSync(challengesPath, 'utf8').split(/\r?\n/)
    .flatMap(line => { try { return [JSON.parse(line)] } catch { return [] } })
  const missing = reports.filter(report => !invalidMatchIds.has(reviewKey(report))
    && !humanReviewedKeys.has(reviewKey(report))).reverse()
  historicalHumanBacklog.push(...missing.slice(2))
  for (const report of missing.slice(0,2)) reviewHumanChallenge(report,true)
  log('human_review_recovery', { total: reports.length, reviewed: humanReviewedKeys.size,
    queued: humanQueuedReviews.size, historicalBacklog: historicalHumanBacklog.length })
}
setInterval(() => {
  if (pairs.size || activeChallenge || qwenActive || qwenQueue.length
      || pendingReviews.length || batchReviewsActive) return
  if (historicalHumanBacklog.length) reviewHumanChallenge(historicalHumanBacklog.shift(),true)
  else for (const report of historicalRoundBacklog.splice(0,4)) enqueueReview(report)
}, 60000)
function enqueueReview (report) {
  const key = reviewKey(report)
  if (!report.training?.length || report.trainingError || reviewedKeys.has(key) || queuedReviews.has(key)) return
  queuedReviews.add(key); pendingReviews.push(report)
  if (pendingReviews.length >= REVIEW_BATCH_SIZE) flushReviewBatches()
}
function flushReviewBatches (force = false) {
  if (Date.now() < reviewRetryAfter) return
  while (batchReviewsActive < 1 && pendingReviews.length
      && (force || pendingReviews.length >= reviewBatchLimit)) {
    const batch = pendingReviews.splice(0, reviewBatchLimit)
      .sort((a, b) => String(a.at).localeCompare(String(b.at)))
    batchReviewsActive++
    const bouts = batch.map(report => [report.at, reviewKey(report), report.arena, report.bout, report.reason, report.winner,
      ...Object.entries(report.fighters).map(([name, x]) => [name,
        x.style || 'UNKNOWN', x.focus, x.attacks, x.misses,
        x.bowChoices, x.crossbowChoices, x.ammoConsumed]), report.native
          ? [report.native.meleeHits, report.native.shieldBreaks,
            report.native.breakFollowupHits, report.native.shieldCounterHits,
            report.native.arrowLaunches, report.native.arrowHits,
            report.native.plausibleCriticalHits] : null,
        report.tactics ? Object.entries(report.tactics).map(([name,t]) => [name,
          t.counterHits,t.counterEscapes,t.counterPunished,t.arrowLaunches,
          t.arrowHits,t.rangedPunished,t.landingThreatHits,
          t.edgeHits,t.safeEdgeHits,t.safeHitExits,t.postExitArrows,
          t.postExitReentryHits,t.edgeCounterEscapes,t.counterEscapeArrows,
          t.edgeCounterPunished,t.rangedExchange]) : null])
    const timeline = mergeTimeline(orderedMemory(), bouts,
      batch.flatMap(report => (report.native?.trace || [])
        .map(event => ({ at: event[0], kind: 'native_event', matchId: reviewKey(report),
          sequence: event[1], event: event.slice(2) }))))
    const researchChoices = researchFocusChoices()
    scheduleQwen(() => inferQwen([
      { role: 'system', content: '你是共享 Qwen PvP 教练。globalTimeline 按全服时间排序，M=持久经验，E=原生事件，B=对局结束。B含[时间,ID,场,局,原因,胜者,双方动作计数,原生摘要,战术计数]。战术计数末九项依次为边缘命中、安全边缘命中、命中后安全出距、出距后发箭、出距后再命中、边缘盾反出距、盾反出距后发箭、边缘进攻遭反击、双方互射。近身互殴已有成果，眼下重点是边缘盾挡反击后命中并真正脱离，以及避免在敌方有效举盾时白送反击；出距后根据真实距离选择弓弩互射或安全再入。以原生事件和水平位移为证，不把武器选择当发箭。多种招式仍须轮换；这些是研究问题，不是固定动作脚本。只输出JSON {"focus":"...","lesson":"..."}，lesson不超过35字。' },
      { role: 'user', content: JSON.stringify({ globalTimeline: timeline.map(row =>
        row.kind === 'memory' ? ['M',row.at,row.source,row.text]
          : row.kind === 'native_event' ? ['E',row.at,row.matchId,row.sequence,...row.event]
            : ['B',...row.bout]),
        question: '比较边缘盾反命中后出距、出距后真实发箭与双方互射、边缘进攻遭反击。若某链条持续为零，请优先选仍缺失的实验焦点；有证据后再扩展其他方向。不要重复已有近身 COMBO 结论。' }) }
    ], 100, { ...batchReviewSchema, properties: {
      ...batchReviewSchema.properties, focus: { type: 'string', enum: researchChoices }
    } }), true).then(answer => {
      if (!researchChoices.includes(answer.focus)
          || typeof answer.lesson !== 'string' || !answer.lesson.trim())
        throw Error('Invalid Qwen batch review')
      const counts = batch.reduce((n, report) => {
        for (const x of Object.values(report.fighters)) {
          n.attackPackets += x.attacks || 0; n.crosshairMisses += x.misses || 0
          n.ranged += (x.bowChoices || 0) + (x.crossbowChoices || 0)
          n.arrows += x.ammoConsumed || 0
        }
        if (report.native) {
          n.nativeBouts++
          n.meleeHits += report.native.meleeHits
          n.shieldBreaks += report.native.shieldBreaks
          n.breakFollowupHits += report.native.breakFollowupHits
          n.arrowLaunches += report.native.arrowLaunches
          n.arrowHits += report.native.arrowHits
        }
        if (Object.values(report.tactics || {}).some(t => Number.isInteger(t?.edgeCounterEscapes))) {
          n.tacticBouts++
          for (const t of Object.values(report.tactics)) {
            n.edgeCounterEscapes += t.edgeCounterEscapes || 0
            n.counterEscapeArrows += t.counterEscapeArrows || 0
            n.edgeCounterPunished += t.edgeCounterPunished || 0
            n.rangedExchange += t.rangedExchange || 0
          }
        }
        return n
      }, { attackPackets: 0, crosshairMisses: 0, ranged: 0, arrows: 0,
        nativeBouts: 0, meleeHits: 0, shieldBreaks: 0, breakFollowupHits: 0,
        arrowLaunches: 0, arrowHits: 0, tacticBouts: 0,
        edgeCounterEscapes: 0, counterEscapeArrows: 0,
        edgeCounterPunished: 0, rangedExchange: 0 })
      const suggested = answer.lesson.trim().slice(0,90)
      const measured = counts.nativeBouts
        ? `原生${counts.nativeBouts}局：命中${counts.meleeHits}、破盾${counts.shieldBreaks}后5秒跟进${counts.breakFollowupHits}、发箭${counts.arrowLaunches}命中${counts.arrowHits}`
        : `样本${batch.length}局仅有客户端选择计数，尚无可归属的原生战术事件`
      const tactical = counts.tacticBouts
        ? `；战术${counts.tacticBouts}局边缘盾反出距${counts.edgeCounterEscapes}、出距箭${counts.counterEscapeArrows}、遭反击${counts.edgeCounterPunished}、互射${counts.rangedExchange}`
        : '；旧局无新战术观测'
      const lesson = `${measured}${tactical}；待测${answer.focus}`
      for (const report of batch) {
        const key = reviewKey(report)
        const row = { at: now(), boutAt: report.at, arena: report.arena, bout: report.bout,
          matchId: key,
          fighters: Object.keys(report.fighters), focus: answer.focus, lesson,
          batchSize: batch.length, nativeCounts: counts, qwenSuggestion: suggested,
          lessonSource: 'measured-after-Qwen',
          source: 'Qwen2.5-1.5B-Instruct-batch' }
        sharedLessons.push(row); append(sharedLessonsPath, row)
        reviewedKeys.add(key); queuedReviews.delete(key)
      }
      log('shared_qwen_batch', { count: batch.length, focus: answer.focus, lesson, nativeCounts: counts })
    }).catch(error => {
      append(qwenErrorsPath, { phase: 'shared_batch', bouts: batch.map(x => `${x.arena}:${x.bout}`), error: String(error) })
      pendingReviews.unshift(...batch)
      if (String(error).includes('Qwen HTTP 400') && batch.length > 1)
        reviewBatchLimit = Math.max(1, Math.floor(batch.length/2))
      reviewRetryAfter = Date.now() + (batch.length === 1 ? 60000 : 10000)
      log('shared_qwen_batch_error', { count: batch.length, error: String(error) })
      setTimeout(flushReviewBatches, 10000)
    }).finally(() => { batchReviewsActive--; flushReviewBatches() })
  }
}
setInterval(() => flushReviewBatches(true), 60000)

function startBridge () {
  const cp = [path.join(base, 'original-44kk-bridge-classes'), path.join(base, '..', 'pvp-neural-lab', 'classes'),
    path.join(server, 'versions', '1.21.1', 'paper-1.21.1.jar'),
    path.join(server, 'libraries', 'com', 'google', 'code', 'gson', 'gson', '2.10.1', 'gson-2.10.1.jar')].join(path.delimiter)
  bridge = childProcess.spawn(path.join(server, 'runtime', 'java21', 'bin', 'java.exe'),
    ['-cp', cp, 'local.wavedog.lab.ProtocolPlayerBridge', checkpoint],
    { cwd: base, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  bridge.stdout.on('data', chunk => {
    bridgeBuffer += chunk.toString('utf8')
    for (let at; (at = bridgeBuffer.indexOf('\n')) >= 0;) {
      const line = bridgeBuffer.slice(0, at).trim(); bridgeBuffer = bridgeBuffer.slice(at + 1)
      if (!line) continue
      try { handleBridge(JSON.parse(line)) } catch (error) { log('bridge_parse_error', { error: String(error) }) }
    }
  })
  bridge.stderr.on('data', chunk => log('bridge_stderr', { message: chunk.toString('utf8').slice(0, 300) }))
  bridge.on('exit', code => { bridgeReady = false; fs.rmSync(readyFile, { force: true }); log('bridge_exit', { code }) })
}
function handleBridge (result) {
  if (result.event === 'ready') { bridgeReady = true; log('gru_ready', result); return }
  if (result.model === 'GRU64-PPO') {
    const session = sessions.get(result.fighter)
    if (session && session.opponent === result.opponent && session.pendingId === result.requestId) {
      session.pendingId = null
      const beforeAttacks = session.attacks, beforeMisses = session.misses
      const ignoredHeads = applyDecision(session, result)
      session.modelResponses++
      {
        const bot = bots.get(session.name)
        const actionRow = { at: now(), matchId: session.kind === 'human-challenge'
          ? `${serverRunId}:challenge:${session.bout}` : `${serverRunId}:${session.arena}:${session.bout}`,
          kind: 'action', fighter: session.name, opponent: session.opponent,
          frame: session.clientFrame, decidedFrame: result.decidedTick,
          requestId: result.requestId,
          selected: { forward: result.forward, side: result.side,
            sprint: result.sprint, jump: result.jump, sneak: result.sneak,
            shield: result.shield, attack: result.attack, slot: result.slot,
            use: result.use, release: result.release }, ignoredHeads,
          executed: { forward: bot.getControlState('forward'),
            back: bot.getControlState('back'), left: bot.getControlState('left'),
            right: bot.getControlState('right'), sprint: bot.getControlState('sprint'),
            jump: bot.getControlState('jump'), sneak: bot.getControlState('sneak'),
            mainSlot: bot.quickBarSlot, offhand: bot.inventory.slots[45]?.name || '',
            using: bot.usingHeldItem, attackPackets: session.attacks-beforeAttacks,
            swingWithoutTarget: session.misses-beforeMisses } }
        if (session.kind === 'human-challenge') append(humanFramesPath, actionRow)
        session.actionHistory.push(actionRow)
      }
      sendBridge({ command: 'executed', fighter: result.fighter,
        decidedTick: result.decidedTick, ignoredHeads })
    } else if (session && session.opponent === result.opponent) {
      // A timed-out decision was never executed. Exclude all its heads from PPO.
      sendBridge({ command: 'executed', fighter: result.fighter,
        decidedTick: result.decidedTick, ignoredHeads: [0,1,2,3,4,5,6,7,8] })
    }
    return
  }
  if (result.event === 'trained' || result.event === 'trained_partial') {
    const waiter = finishWaiters.get(result.fighter)
    if (waiter) { finishWaiters.delete(result.fighter); waiter.resolve(result) }
    append(path.join(store, 'training.jsonl'), result)
    return
  }
  if (result.event === 'error') log('gru_error', result)
}
function finishFighter (session, winner) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { finishWaiters.delete(session.name); reject(Error('PPO finish timeout')) }, 60000)
    finishWaiters.set(session.name, { resolve: value => { clearTimeout(timeout); resolve(value) } })
    sendBridge({ command: 'finish', fighter: session.name, round: session.bout,
      win: winner === session.name, health: winner === session.name ? Math.max(0, session.lastHealth) : 0 })
  })
}
function partialFighter (session) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { finishWaiters.delete(session.name); reject(Error('PPO partial timeout')) }, 60000)
    finishWaiters.set(session.name, { resolve: value => { clearTimeout(timeout); resolve(value) } })
    sendBridge({ command: 'partial', fighter: session.name, round: session.bout })
  })
}
function slotFor (bot) { return bot.quickBarSlot }
function crossbowLoaded (bot) {
  const crossbow = bot.inventory.slots[45]?.name === 'crossbow'
    ? bot.inventory.slots[45] : bot.inventory.slots[40]
  if (crossbow?.name !== 'crossbow') return false
  const data = crossbow.componentMap?.get('charged_projectiles')?.data
  const projectiles = Array.isArray(data) ? data : data?.projectiles
  return Array.isArray(projectiles) && projectiles.some(item => (item?.itemCount ?? item?.count ?? 0) > 0)
}
function requestOffhand (session, bot, wanted) {
  if (bot.inventory.slots[45]?.name === wanted) return true
  if (session.offhandSwapPending) return false
  const item = bot.inventory.slots.find((entry, index) =>
    index >= 9 && index <= 44 && entry?.name === wanted)
  if (!item) { log('offhand_item_missing', { fighter: session.name, wanted }); return false }
  if (bot.usingHeldItem) stopUse(session, bot)
  session.offhandSwapAttempts++
  session.offhandSwapPending = wanted
  session.offhandSwapPromise = bot.equip(item, 'off-hand').then(() => {
    if (bot.inventory.slots[45]?.name !== wanted) {
      session.offhandSwapErrors++
      log('offhand_swap_unconfirmed', { fighter: session.name, wanted,
        actual: bot.inventory.slots[45]?.name || 'empty' })
    } else session.offhandSwapConfirmed++
  }).catch(error => { session.offhandSwapErrors++
    log('offhand_swap_error', { fighter: session.name,
      wanted, error: String(error) }) }).finally(() => {
      session.offhandSwapPending = null; session.offhandSwapPromise = null
    })
  return false
}
function stopUse (session, bot) {
  if (bot.usingHeldItem) bot.deactivateItem()
  else if (session.activeUseHand) {
    // Mineflayer can clear its local use flag before the server observes a
    // release. Send the ordinary client release packet for the logical use.
    bot._client.write('block_dig', { status: 5,
      location: new Vec3(0,0,0), face: 0, sequence: 0 })
  }
  session.activeUseHand = null
  session.activeUseSlot = null
}
function opponentUseState (entity) {
  // Living-entity hand flags and equipment are ordinary client-visible packets.
  const flags = Number(entity.metadata?.[8] || 0)
  const using = Boolean(flags & 1)
  const offhand = Boolean(flags & 2)
  const active = entity.equipment?.[offhand ? 1 : 0]
  return { using, shielding: using && active?.name === 'shield',
    activeItem: active?.name || '' }
}
const opponentShieldRaisedAt = new Map()
function observedEffectiveShield (entity) {
  const state = opponentUseState(entity)
  if (!state.shielding) { opponentShieldRaisedAt.delete(entity.id); return false }
  if (!opponentShieldRaisedAt.has(entity.id)) opponentShieldRaisedAt.set(entity.id, Date.now())
  return Date.now()-opponentShieldRaisedAt.get(entity.id) >= 250
}
function opponentShieldFacing (bot, target) {
  if (!observedEffectiveShield(target)) return false
  const dx = bot.entity.position.x-target.position.x
  const dz = bot.entity.position.z-target.position.z
  const distance = Math.max(.01,Math.hypot(dx,dz))
  return (-Math.sin(target.yaw)*dx-Math.cos(target.yaw)*dz)/distance > 0
}
function ownAttackCharge (session, slot, time = Date.now()) {
  return Math.min(1, (time-session.lastSwing)/(slot === 0 ? 625 : 1000))
}
function installVanillaUseMovement (bot) {
  const simulate = bot.physics.simulatePlayer.bind(bot.physics)
  bot.physics.simulatePlayer = (state, world) => {
    if (bot.usingHeldItem) {
      state.control = { ...state.control,
        forward: Number(state.control.forward)*.2, back: Number(state.control.back)*.2,
        left: Number(state.control.left)*.2, right: Number(state.control.right)*.2,
        sprint: false }
    }
    return simulate(state, world)
  }
  const setControl = bot.setControlState.bind(bot)
  bot.setControlState = (control, enabled) => {
    if (control === 'sprint' && enabled && bot.usingHeldItem) return
    setControl(control, enabled)
  }
}
function targetUnderCrosshair (bot, target) {
  const reach = 3.0
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight, 0)
  const yaw = bot.entity.yaw, pitch = bot.entity.pitch
  const direction = new Vec3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch))
  const block = bot.world.raycast(eye, direction, reach)
  const iterator = new RaycastIterator(eye, direction, Math.min(reach, block ? eye.distanceTo(block.intersect) : reach))
  let picked = null, distance = reach
  for (const entity of Object.values(bot.entities)) {
    if (entity.id === bot.entity.id || !entity.position || !entity.width || !entity.height) continue
    if (entity.position.distanceTo(bot.entity.position) > reach + entity.width) continue
    const half = entity.width / 2
    const hit = iterator.intersect([[-half, 0, -half, half, entity.height, half]], entity.position)
    if (hit && eye.distanceTo(hit.pos) < distance) { picked = entity; distance = eye.distanceTo(hit.pos) }
  }
  return picked?.id === target.id
}
function aimAtVisibleOpponent (bot, target, rangedSlot = null, drawMs = 0) {
  const eye = bot.entity.position.offset(0, bot.entity.eyeHeight - (rangedSlot ? .1 : 0), 0)
  const point = target.position.offset(0, Math.min(1.3, target.height * 0.7), 0)
  const distance = Math.hypot(point.x-eye.x, point.z-eye.z)
  const speed = rangedSlot === 1
    ? bowSpeed(Math.max(drawMs, plannedBowDrawMs(distance))) : rangedSlot === 4 ? 3.15 : 0
  const aim = rangedSlot ? leadTarget(eye, point, target.velocity, speed) : point
  const dx = aim.x-eye.x, dy = aim.y-eye.y, dz = aim.z-eye.z
  const horizontal = Math.hypot(dx,dz)
  const yaw = Math.atan2(-dx, -dz)
  const pitch = rangedSlot ? solvePitch(horizontal, dy, speed) : Math.atan2(dy, horizontal)
  const delta = Math.atan2(Math.sin(yaw-bot.entity.yaw), Math.cos(yaw-bot.entity.yaw))
  bot.look(yaw, pitch, true)
  return Math.abs(delta)*180/Math.PI
}
function applyDecision (session, decision) {
  const bot = bots.get(session.name), target = bot.players[session.opponent]?.entity
  if (!bot.entity || !target) return [0,1,2,3,4,5,6,7,8]
  const ignoredHeads = [6,7] // Camera is directly aimed at the public target.
  session.decisions++
  if (bot.health < 6) {
    session.lowHealthDecisions++
    if (decision.attack) session.lowHealthAttackChoices++
    if (decision.shield) session.lowHealthShieldChoices++
    if (decision.use && [1,4].includes(Number(decision.slot))) session.lowHealthRangedChoices++
    if (Number(decision.forward) > .5) session.lowHealthAdvanceChoices++
    if (Number(decision.forward) < -.5) session.lowHealthRetreatChoices++
  }
  const slot = Number(decision.slot)
  const range = bot.entity.position.distanceTo(target.position)
  const useMs = Date.now() - session.useStarted
  if (session.activeUseHand === 'off' && session.activeUseSlot === -1
      && (!decision.shield || Date.now() < session.shieldDisabledUntil))
    stopUse(session, bot)
  const rangedSlot = session.activeUseHand === 'off' && [1,4].includes(session.activeUseSlot)
    ? session.activeUseSlot : decision.use && [1,4].includes(slot) ? slot : null
  // A normal client can turn its camera directly toward a visible opponent.
  // The named opponent is a public entity, not a hidden native combat state.
  const correction = aimAtVisibleOpponent(bot, target, rangedSlot, useMs)
  session.aimDegrees += correction
  if (correction > 18) session.largeTurns++
  const forward = Number(decision.forward), side = Number(decision.side)
  bot.setControlState('forward', forward > .5); bot.setControlState('back', forward < -.5)
  bot.setControlState('left', side < -.5); bot.setControlState('right', side > .5)
  // Using any item applies native slowdown; an active shield must not retain sprint.
  bot.setControlState('sprint', Boolean(decision.sprint) && !decision.shield && !bot.usingHeldItem)
  bot.setControlState('sneak', Boolean(decision.sneak))
  bot.setControlState('jump', Boolean(decision.jump))
  if (session.activeUseHand === 'off' && bot.usingHeldItem && session.activeUseSlot === 4) {
    if (!crossbowLoaded(bot) && range > 6 && useMs < 1800) {
      session.crossbowHoldTicks++
      return [...ignoredHeads,4,5]
    }
    stopUse(session, bot)
    // Let the release packet reach the server before a separate learned use
    // decision can fire an already loaded crossbow. Reusing in this callback
    // repeatedly cancelled the release/fire boundary.
    return [...ignoredHeads,4,5]
  }
  if (session.activeUseHand === 'off' && bot.usingHeldItem && session.activeUseSlot === 1) {
    if (useMs < plannedBowDrawMs(range)) {
      session.bowHoldTicks++
      return [...ignoredHeads,4,5]
    }
    stopUse(session, bot)
    session.bowReleaseRequests++
    return [...ignoredHeads,4,5]
  }
  if (slot === 1) session.bowChoices++
  if (slot === 4) session.crossbowChoices++
  if ((slot === 1 || slot === 4) && decision.use) session.rangedUseChoices++
  if ([0,7].includes(slot) && bot.quickBarSlot !== slot) {
    if (bot.usingHeldItem) stopUse(session, bot)
    bot.setQuickBarSlot(slot)
  }
  if (decision.shield && Date.now() >= session.shieldDisabledUntil) {
    if (!requestOffhand(session, bot, 'shield')) return [...ignoredHeads,4,5]
    if (!bot.usingHeldItem) {
      bot.setControlState('sprint', false)
      bot.activateItem(true); session.activeUseHand = 'off'; session.activeUseSlot = -1
      session.useStarted = Date.now()
    }
  } else if (decision.use && [1,4].includes(slot)) {
    const wanted = slot === 1 ? 'bow' : 'crossbow'
    if (!requestOffhand(session, bot, wanted)) return [...ignoredHeads,4,5]
    if (!bot.usingHeldItem) {
      if (slot === 4 && crossbowLoaded(bot)) session.crossbowFireRequests++
      bot.activateItem(true); session.activeUseHand = 'off'; session.activeUseSlot = slot
      session.useStarted = Date.now()
      if (slot === 4) session.crossbowLoadAttempts++
    } else if (slot === 4 && session.activeUseSlot === 4 && crossbowLoaded(bot))
      stopUse(session, bot)
  }
  if (decision.release && bot.usingHeldItem) stopUse(session, bot)
  if (decision.attack) {
    const mainSlot = slotFor(bot)
    const charge = ownAttackCharge(session, mainSlot)
    const distance = bot.entity.position.distanceTo(target.position)
    const shieldBreak = mainSlot === 7 && distance <= 3 && opponentShieldFacing(bot, target)
    const urgentLight = bot.health < 6 && distance <= 2.5 && charge >= .55
    if (charge < .85 && !shieldBreak && !urgentLight) session.lowChargeChoices++
    if (bot.usingHeldItem) stopUse(session, bot)
    if (!bot.entity.onGround && bot.entity.velocity.y < -.08 && charge >= .9) {
      // Mineflayer emits stop_sprinting immediately before the attack packet.
      bot.setControlState('sprint', false)
      session.critWindowAttempts++
    }
    session.lastAttackAttempt = Date.now()
    aimAtVisibleOpponent(bot, target)
    session.cameraFineAim++
    if (targetUnderCrosshair(bot, target)) {
      bot.attack(target); session.attacks++
      if (charge < .85) session.lightAttacks++
      session.chargeSum += charge
    }
    else { bot.swingArm(); session.misses++ }
    session.lastSwing = Date.now()
  }
  return ignoredHeads
}
function requestAction (session) {
  const bot = bots.get(session.name), target = bot.players[session.opponent]?.entity
  if (!bridgeReady || !bot.entity || !target || bot.health <= 0) return
  const time = Date.now()
  session.minHealth = Math.min(session.minHealth, bot.health)
  if (session.pendingId && time-session.pendingAt < 500) return
  session.lastRequest = time
  const own = bot.entity
  const distance = own.position.distanceTo(target.position)
  session.distanceSamples++
  session.distanceSum += distance
  if (distance <= 3) session.reachSamples++
  if (distance > 5) session.farSamples++
  const self = { x: own.position.x, y: own.position.y, z: own.position.z,
    eyeY: own.position.y+own.eyeHeight, vx: own.velocity.x, vy: own.velocity.y, vz: own.velocity.z,
    ground: own.onGround, critical: !own.onGround && own.velocity.y < -.08,
    charge: ownAttackCharge(session, slotFor(bot), time),
    health: bot.health, shieldAvailable: time >= session.shieldDisabledUntil,
    shielding: bot.usingHeldItem && session.activeUseHand === 'off' && session.activeUseSlot === -1
      && time-session.useStarted >= 250,
    arrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n,item) => n+item.count,0),
    crossbowLoaded: crossbowLoaded(bot), using: bot.usingHeldItem,
    useTicks: bot.usingHeldItem ? Math.round((time-session.useStarted)/50) : 0,
    held: slotFor(bot) }
  if (self.crossbowLoaded) session.crossbowLoadedObservations++
  const targetUse = opponentUseState(target)
  const effectiveShield = observedEffectiveShield(target)
  if (targetUse.shielding) session.opponentShieldObservations++
  const seen = { visible: target.position.distanceTo(own.position) < 64,
    x: target.position.x, y: target.position.y, z: target.position.z,
    yaw: 180-target.yaw*180/Math.PI, shield: effectiveShield,
    held: target.heldItem?.name?.toUpperCase() || 'UNKNOWN',
    using: targetUse.using, swing: session.opponentSwing }
  const requestId = ++nextRequestId
  session.modelRequests++
  session.currentArrows = self.arrows
  session.pendingId = requestId; session.pendingAt = time
  sendBridge({ command: 'act', fighter: session.name, opponent: session.opponent,
    requestId, tick: session.clientFrame,
    yaw: 180-own.yaw*180/Math.PI, pitch: -own.pitch*180/Math.PI,
    observedOpponentHurts: session.visibleOpponentHurt,
    self, seen, focus: session.focus,
    style: session.style })
}
function recordFighterFrame (session, bot) {
  const own = bot.entity, target = bot.players[session.opponent]?.entity
  if (!own || !target) return
  const time = Date.now(), targetUse = opponentUseState(target)
  const frameRow = { at: now(), matchId: session.kind === 'human-challenge'
    ? `${serverRunId}:challenge:${session.bout}` : `${serverRunId}:${session.arena}:${session.bout}`,
    kind: 'frame', fighter: session.name, opponent: session.opponent,
    frame: session.clientFrame, serverAgeAnchor: bot.time.age,
    self: { x: own.position.x, y: own.position.y, z: own.position.z,
      vx: own.velocity.x, vy: own.velocity.y, vz: own.velocity.z,
      ground: own.onGround, health: bot.health,
      charge: ownAttackCharge(session, slotFor(bot), time),
      shieldAvailable: time >= session.shieldDisabledUntil,
      shielding: bot.usingHeldItem && session.activeUseSlot === -1
        && time-session.useStarted >= 250,
      held: slotFor(bot), offhand: bot.inventory.slots[45]?.name || '',
      activeUseSlot: bot.usingHeldItem ? session.activeUseSlot : null,
      crossbowLoaded: crossbowLoaded(bot),
      arrows: bot.inventory.items().filter(item => item.name === 'arrow').reduce((n,item) => n+item.count,0) },
    seen: { x: target.position.x, y: target.position.y, z: target.position.z,
      yaw: 180-target.yaw*180/Math.PI, shield: observedEffectiveShield(target),
      held: target.heldItem?.name || '', using: targetUse.using,
      vy: target.velocity.y,
      swing: session.opponentSwing } }
  if (session.kind === 'human-challenge') append(humanFramesPath, frameRow)
  session.frameHistory.push(frameRow)
}
function humanEventWindows (session, events) {
  const frames = session.frameHistory, actions = session.actionHistory
  if (!frames.length || !events?.length) return []
  const salient = events.filter(e => e.type === 'shield_disable' || e.type === 'arrow_launch'
    || (e.type === 'damage' && !e.cancelled && e.amount > 0))
  const selected = salient.length <= 8 ? salient : [...salient.slice(0,4), ...salient.slice(-4)]
  return selected.map(event => {
    const at = Date.parse(event.at)
    const frame = frames.reduce((best, row) => Math.abs(Date.parse(row.at)-at) < Math.abs(Date.parse(best.at)-at)
      ? row : best, frames[0])
    const action = [...actions].reverse().find(row => Date.parse(row.at) <= at
      && at-Date.parse(row.at) < 500)
    return { at: event.at, type: event.type,
      attacker: event.attacker || event.shooter || '', victim: event.victim || '',
      amount: event.type === 'damage' ? event.amount : null,
      frame: frame.frame, frameGapMs: Math.abs(Date.parse(frame.at)-at),
      distance: Math.hypot(frame.self.x-frame.seen.x, frame.self.y-frame.seen.y,
        frame.self.z-frame.seen.z),
      selfHealth: frame.self.health, selfCharge: frame.self.charge,
      selfY: frame.self.y, selfVy: frame.self.vy,
      targetY: frame.seen.y, targetVy: frame.seen.vy, targetYaw: frame.seen.yaw,
      selfShield: frame.self.shielding, targetShield: frame.seen.shield,
      mainSlot: frame.self.held, offhand: frame.self.offhand,
      action: action?.selected || null, executed: action?.executed || null }
  })
}
function applyNativeStepFeedback (events, fighters) {
  if (!events?.length) return 0
  const byName = new Map(fighters.filter(Boolean).map(session => [session.name, session]))
  const launches = events.filter(e => e.type === 'arrow_launch')
  let applied = 0
  const reward = (name, at, value) => {
    const session = byName.get(name)
    if (!session) return
    const action = [...session.actionHistory].reverse().find(row =>
      Date.parse(row.at) <= Date.parse(at) && Date.parse(at)-Date.parse(row.at) <= 1200)
    if (!action) return
    sendBridge({ command: 'native_step', fighter: name,
      decidedTick: action.decidedFrame, reward: Math.max(-1,Math.min(1,value)) })
    applied++
  }
  for (const event of events) {
    if (event.cancelled) continue
    if (event.type === 'damage' && event.amount > 0) {
      let attributionAt = event.at
      if (event.source === 'ARROW') {
        const launch = [...launches].reverse().find(row => row.shooter === event.attacker
          && row.tick <= event.tick && event.tick-row.tick <= 80)
        if (launch) attributionAt = launch.at
      }
      reward(event.attacker, attributionAt, event.amount/20)
      reward(event.victim, event.at, -event.amount/20)
    } else if (event.type === 'shield_disable') {
      reward(event.attacker, event.at, .04)
      reward(event.victim, event.at, -.04)
    } else if (event.type === 'damage' && event.victim_blocking && event.shield_modifier < 0) {
      reward(event.victim, event.at, .015)
      reward(event.attacker, event.at, -.015)
    }
  }
  return applied
}
function applyTacticalStepFeedback (session, tactics) {
  let applied = 0
  for (const result of tactics?.counterOutcomes || []) {
    const at = Date.parse(result.at)
    const action = [...session.actionHistory].reverse().find(row =>
      Date.parse(row.at) <= at && at-Date.parse(row.at) <= 1200)
    if (!action) continue
    const value = result.escaped ? .08 : result.punished ? -.03 : 0
    if (!value) continue
    sendBridge({ command: 'native_step', fighter: session.name,
      decidedTick: action.decidedFrame, reward: value })
    applied++
  }
  for (const result of tactics?.spacingOutcomes || []) {
    const at = Date.parse(result.at)
    const action = [...session.actionHistory].reverse().find(row =>
      Date.parse(row.at) <= at && at-Date.parse(row.at) <= 500)
    if (!action) continue
    sendBridge({ command: 'native_step', fighter: session.name,
      decidedTick: action.decidedFrame, reward: result.reward })
    applied++
  }
  return applied
}
function beginFighter (name, arena, bout, opponent, kind = 'selfplay') {
  const bot = bots.get(name)
  const curriculum = curriculumFor(name, bout)
  const context = contexts.get(name)
  if (context) { context.focus = curriculum.focus; context.style = curriculum.style
    context.curriculumSource = curriculum.curriculumSource; append(coachPath, context) }
  const session = { name, arena, bout, opponent, kind, started: Date.now(), lastSwing: Date.now()-1000,
    focus: curriculum.focus, style: curriculum.style,
    scheduledFocus: curriculum.scheduledFocus,
    curriculumSource: curriculum.curriculumSource,
    lastAttackAttempt: 0, lastRequest: 0, pendingId: null, pendingAt: 0, lastHealth: 20,
    clientFrame: 0, framesSeen: 0, modelRequests: 0, modelResponses: 0,
    frameHistory: [], actionHistory: [],
    minHealth: 20, lowHealthDecisions: 0, lowHealthAttackChoices: 0,
    lowHealthShieldChoices: 0, lowHealthRangedChoices: 0,
    lowHealthAdvanceChoices: 0, lowHealthRetreatChoices: 0,
    visibleOpponentHurt: 0, visibleOpponentHurtWhileLow: 0,
    shieldDisabledUntil: 0, useStarted: Date.now(), activeUseHand: null,
    offhandSwapPending: null, offhandSwapPromise: null,
    offhandSwapAttempts: 0, offhandSwapConfirmed: 0, offhandSwapErrors: 0,
    activeUseSlot: null, opponentSwing: 0,
    decisions: 0, attacks: 0, misses: 0, cameraFineAim: 0,
    aimDegrees: 0, largeTurns: 0, distanceSamples: 0,
    distanceSum: 0, reachSamples: 0, farSamples: 0,
    suppressedLowCharge: 0, lowChargeChoices: 0, lightAttacks: 0, chargeSum: 0,
    critWindowAttempts: 0, opponentShieldObservations: 0,
    bowChoices: 0, crossbowChoices: 0, rangedUseChoices: 0,
    bowHoldTicks: 0, bowReleaseRequests: 0, crossbowHoldTicks: 0,
    crossbowLoadAttempts: 0,
    crossbowFireRequests: 0,
    crossbowLoadedObservations: 0, startArrows: 5, currentArrows: 5 }
  sessions.set(name, session)
  sendBridge({ command: 'reset', fighter: name, opponent, learning: true })
  bot.clearControlStates()
  log('fighter_start', { name, opponent, arena, bout, kind, focus: session.focus,
    style: session.style })
}

async function finishHumanChallenge (challenge, winner, reason) {
  if (challenge.ending) return
  challenge.ending = true
  const session = sessions.get(challenge.bot)
  if (!session || session.kind !== 'human-challenge' || session.bout !== challenge.id) {
    log('human_challenge_missing_session', { id: challenge.id, bot: challenge.bot })
    return
  }
  const bot = bots.get(challenge.bot)
  bot.clearControlStates()
  if (bot.usingHeldItem) bot.deactivateItem()
  if (session.offhandSwapPromise) await session.offhandSwapPromise
  sessions.delete(challenge.bot)
  const matchId = `${serverRunId}:challenge:${challenge.id}`
  let native = null, training = null, trainingError = null, frameWindows = []
  let nativeFeedbackSent = 0, tactics = null
  try {
    const record = await takeNativeBout(challenge.arena, -challenge.id)
    native = record?.summary || null
    frameWindows = humanEventWindows(session, record?.events)
    tactics = record ? analyzeTactics(session.name, session.opponent,
      record.events, session.frameHistory) : null
    nativeFeedbackSent = applyNativeStepFeedback(record?.events, [session])
    nativeFeedbackSent += applyTacticalStepFeedback(session, tactics)
    append(humanEventsPath, { matchId, arena: challenge.arena, bout: -challenge.id,
      bot: challenge.bot, opponent: session.opponent, observed: Boolean(record),
      events: record?.events || [] })
  }
  catch (error) { log('native_feedback_error', { challenge: challenge.id, error: String(error) }) }
  try {
    if (session.decisions > 0 && reason === 'death' && [challenge.bot, session.opponent].includes(winner))
      training = await finishFighter(session, winner)
    else if (session.decisions > 0) training = await partialFighter(session)
    else sendBridge({ command: 'reset', fighter: session.name, opponent: '', learning: false })
  } catch (error) { trainingError = String(error); log('human_challenge_training_error', { id: challenge.id, error: trainingError }) }
  const report = { at: now(), matchId,
    arena: challenge.arena, bout: -challenge.id, kind: 'human-challenge',
    bot: challenge.bot, opponent: session.opponent, winner, reason, native,
    frameWindows, nativeFeedbackSent, tactics,
    focus: session.focus, style: session.style, decisions: session.decisions,
    framesSeen: session.framesSeen, modelRequests: session.modelRequests,
    modelResponses: session.modelResponses,
    attackPackets: session.attacks, crosshairMisses: session.misses,
    bowChoices: session.bowChoices, crossbowChoices: session.crossbowChoices,
    ammoConsumed: Math.max(0,session.startArrows-session.currentArrows),
    offhandSwapAttempts: session.offhandSwapAttempts,
    offhandSwapConfirmed: session.offhandSwapConfirmed,
    offhandSwapErrors: session.offhandSwapErrors,
    training, trainingError }
  append(challengesPath, report)
  const context = contexts.get(challenge.bot)
  if (context) {
    context.ownRecent = [...(context.ownRecent || []), { at: report.at,
      matchId: report.matchId, opponent: session.opponent, win: winner === challenge.bot,
      attackPackets: report.attackPackets, native: native ? {
        meleeHits: native.meleeHits, shieldBreaks: native.shieldBreaks,
        arrowHits: native.arrowHits } : null }].slice(-4)
    append(coachPath, context)
  }
  reviewHumanChallenge(report)
  log('human_challenge_end', { id: challenge.id, winner, reason,
    trained: Boolean(training), native: Boolean(native) })
}

function reviewHumanChallenge (report) {
  const key = reviewKey(report)
  if (invalidMatchIds.has(key)) return
  if (humanReviewedKeys.has(key) || humanQueuedReviews.has(key)) return
  humanQueuedReviews.add(key)
  const brief = [report.at, report.matchId, report.arena, report.bout, report.winner,
    [report.bot, report.style, report.focus, report.attackPackets,
      report.crosshairMisses, report.bowChoices, report.crossbowChoices,
      report.ammoConsumed, report.framesSeen, report.modelRequests, report.modelResponses], report.native
      ? Object.fromEntries(Object.entries(report.native).filter(([key]) => key !== 'trace')) : null]
  const timeline = mergeTimeline(orderedMemory(), [brief], (report.native?.trace || [])
    .map(event => ({ at: event[0], kind: 'native_event', matchId: report.matchId,
      sequence: event[1], event: event.slice(2) })))
  scheduleQwen(() => inferQwen([
    { role: 'system', content: '你是全服共享 Qwen PvP 教练。全局时间线有原生事件，frameWindows 是附近客户端物理帧的公开观察、GRU 所选动作与实际执行动作。frameGapMs 大时不可推断严格因果；样本窗口不代表整局。只有原生伤害、禁盾和胜负是真实结果；客户端准星未偏不能证明命中，暴击候选不能冒充已确认暴击。依据这一局具体动作和结果指出一项可复测失误，兼顾所有打法。不读取隐藏信息，不把 Qwen 建议当已学会。只返回JSON {"focus":"...","lesson":"..."}，focus 从 FREE,CHARGE,SHIELD,AXE_BREAK,CRITICAL,SPRINT_KB,ESCAPE,SYNC,FLANK,COMBO,BOW,CROSSBOW,DODGE,WALL,LATENCY,OPPONENT 选择。' },
    { role: 'user', content: JSON.stringify({ globalTimeline: timeline,
      frameWindows: report.frameWindows || [], tactics: report.tactics || null,
      question: '请核对分身在射程边缘打盾前的选择、被真人盾反后的合法换伤机会、真人回头下落跳劈时的反应，以及脱离后弓弩的真实效益。只依据 frameWindows、tactics 和原生事件给一项具体可复测问题；不把一次挡刀还击当作完整脱离。' }) }
  ], 100, batchReviewSchema), true).then(answer => {
    if (!focusNames.has(answer.focus) || !answer.lesson?.trim()) throw Error('Invalid human challenge review')
    const measured = report.native
      ? `真人局原生命中${report.native.meleeHits}、破盾${report.native.shieldBreaks}、箭伤${report.native.arrowHits}`
      : '真人局原生事件尚未归属，保留待核查'
    const row = { at: now(), matchId: report.matchId, fighters: [report.bot, report.opponent],
      focus: answer.focus, lesson: `${measured}；待测${answer.focus}`,
      qwenSuggestion: String(answer.lesson).slice(0,90),
      lessonSource: 'measured-after-Qwen', source: 'human-challenge-Qwen' }
    sharedLessons.push(row); append(sharedLessonsPath, row)
    humanReviewedKeys.add(key); humanQueuedReviews.delete(key)
    log('human_challenge_review', { matchId: report.matchId, focus: answer.focus })
  }).catch(error => {
    humanQueuedReviews.delete(key)
    append(qwenErrorsPath, { phase: 'human_challenge', matchId: report.matchId, error: String(error) })
    log('human_challenge_review_error', { matchId: report.matchId, error: String(error) })
    setTimeout(() => reviewHumanChallenge(report), 60000)
  })
}
async function endPair (pair, winner, reason) {
  if (pair.ending) return
  pair.ending = true
  const fighters = [pair.a, pair.b].map(name => sessions.get(name))
  for (const session of fighters) {
    if (!session) continue
    const bot = bots.get(session.name)
    bot.clearControlStates(); if (bot.usingHeldItem) bot.deactivateItem()
    if (session.offhandSwapPromise) await session.offhandSwapPromise
    sessions.delete(session.name)
  }
  let native = null, nativeFeedbackSent = 0, tactics = {}
  try {
    const record = await takeNativeBout(pair.arena, pair.bout)
    native = record?.summary || null
    nativeFeedbackSent = applyNativeStepFeedback(record?.events, fighters)
    if (record) for (const session of fighters.filter(Boolean))
      tactics[session.name] = analyzeTactics(session.name, session.opponent,
        record.events, session.frameHistory)
    for (const session of fighters.filter(Boolean))
      nativeFeedbackSent += applyTacticalStepFeedback(session, tactics[session.name])
  }
  catch (error) { log('native_feedback_error', { arena: pair.arena, bout: pair.bout, error: String(error) }) }
  const report = { at: now(), arena: pair.arena, bout: pair.bout,
    matchId: `${serverRunId}:${pair.arena}:${pair.bout}`, winner, reason,
    native, nativeFeedbackSent, tactics,
    fighters: Object.fromEntries(fighters.filter(Boolean).map(s => [s.name, {
      opponent: s.opponent, decisions: s.decisions, framesSeen: s.framesSeen,
      modelRequests: s.modelRequests, modelResponses: s.modelResponses,
      attacks: s.attacks, misses: s.misses,
      cameraFineAim: s.cameraFineAim, bowChoices: s.bowChoices, crossbowChoices: s.crossbowChoices,
      meanDistance: s.distanceSamples ? Math.round(100*s.distanceSum/s.distanceSamples)/100 : null,
      reachFraction: s.distanceSamples ? Math.round(1000*s.reachSamples/s.distanceSamples)/1000 : 0,
      farFraction: s.distanceSamples ? Math.round(1000*s.farSamples/s.distanceSamples)/1000 : 0,
      largeTurns: s.largeTurns,
      suppressedLowCharge: s.suppressedLowCharge,
      lowChargeChoices: s.lowChargeChoices,
      lightAttacks: s.lightAttacks,
      meanAttackCharge: s.attacks ? Math.round(1000*s.chargeSum/s.attacks)/1000 : null,
      critWindowAttempts: s.critWindowAttempts,
      opponentShieldObservations: s.opponentShieldObservations,
      minHealth: Math.round(100*s.minHealth)/100,
      lowHealthDecisions: s.lowHealthDecisions,
      lowHealthAttackChoices: s.lowHealthAttackChoices,
      lowHealthShieldChoices: s.lowHealthShieldChoices,
      lowHealthRangedChoices: s.lowHealthRangedChoices,
      lowHealthAdvanceChoices: s.lowHealthAdvanceChoices,
      lowHealthRetreatChoices: s.lowHealthRetreatChoices,
      visibleOpponentHurt: s.visibleOpponentHurt,
      visibleOpponentHurtWhileLow: s.visibleOpponentHurtWhileLow,
      rangedUseChoices: s.rangedUseChoices,
      bowHoldTicks: s.bowHoldTicks, bowReleaseRequests: s.bowReleaseRequests,
      crossbowHoldTicks: s.crossbowHoldTicks,
      crossbowLoadAttempts: s.crossbowLoadAttempts,
      crossbowFireRequests: s.crossbowFireRequests,
      crossbowLoadedObservations: s.crossbowLoadedObservations,
      offhandSwapAttempts: s.offhandSwapAttempts,
      offhandSwapConfirmed: s.offhandSwapConfirmed,
      offhandSwapErrors: s.offhandSwapErrors,
      ammoConsumed: Math.max(0,s.startArrows-s.currentArrows),
      focus: s.focus, style: s.style, scheduledFocus: s.scheduledFocus,
      curriculumSource: s.curriculumSource }])), training: [] }
  if (reason === 'death' && [pair.a,pair.b].includes(winner) && fighters.every(s => s && s.decisions > 0)) {
    try { for (const session of fighters) report.training.push(await finishFighter(session, winner)) }
    catch (error) { report.trainingError = String(error); log('training_error', { arena: pair.arena, bout: pair.bout, error: String(error) }) }
  } else if (fighters.every(s => s && s.decisions > 0)) {
    try { for (const session of fighters) report.training.push(await partialFighter(session)) }
    catch (error) { report.trainingError = String(error); log('partial_training_error', { arena: pair.arena, bout: pair.bout, error: String(error) }) }
  } else {
    for (const session of fighters.filter(Boolean)) sendBridge({ command: 'reset', fighter: session.name,
      opponent: '', learning: false })
  }
  append(roundsPath, report)
  if (reason === 'death' && Object.values(tactics)
    .some(t => Number.isInteger(t?.edgeCounterEscapes))) {
    researchHistory.push(report)
    if (researchHistory.length > 24) researchHistory.shift()
  }
  log('bout_end', { arena: pair.arena, bout: pair.bout, winner, reason,
    trained: report.training.length, attacks: fighters.map(s => s?.attacks || 0) })
  for (const [name, own] of Object.entries(report.reason === 'death' && !report.trainingError ? report.fighters : {})) {
    const context = contexts.get(name)
    if (!context) continue
    context.ownRecent = [...(context.ownRecent || []), { bout: report.bout,
      opponent: own.opponent, win: winner === name, attacks: own.attacks,
      misses: own.misses, bowChoices: own.bowChoices,
      crossbowChoices: own.crossbowChoices, ammoConsumed: own.ammoConsumed }].slice(-4)
    append(coachPath, context)
  }
  enqueueReview(report)
  pairs.delete(pair.arena)
  if (!stopping && desired >= pair.arena) nextArena(pair.arena)
}
async function nextArena (arena) {
  for (let attempt = 0; attempt < 180 && !stopping; attempt++) {
    try {
      const result = await rcon(`selfplay next ${arena}`)
      if (result.startsWith('Started') || result.includes('Already active')) return
      if (result.includes('outside active count')) return
      if (attempt % 5 === 0) log('next_waiting', { arena, attempt, result })
    } catch (error) { if (attempt % 5 === 0) log('next_error', { arena, attempt, error: String(error) }) }
    await new Promise(resolve => setTimeout(resolve, 2000))
  }
  log('arena_stalled', { arena })
  if (!stopping && desired >= arena) setTimeout(() => nextArena(arena), 5000)
}
function onSparMessage (name, message) {
  const challengeStart = message.match(/WCHALLENGE_START:(\d+):(\d+):([^:]+):([^\s]+)/)
  if (challengeStart && challengeStart[4] === token) {
    const id = Number(challengeStart[1]), arena = Number(challengeStart[2])
    const opponent = challengeStart[3]
    const challenge = { id, arena, bot: name, opponent, ending: false }
    activeChallenge = challenge
    const activate = (attempt = 0) => {
      if (activeChallenge !== challenge || challenge.ending) return
      if (pairs.has(arena) || sessions.has(name)) {
        if (attempt < 240) setTimeout(() => activate(attempt+1), 250)
        else log('human_challenge_activation_timeout', { id, arena, bot: name })
        return
      }
      beginFighter(name, arena, id, opponent, 'human-challenge')
      log('human_challenge_start', { id, arena, bot: name, opponent })
    }
    activate()
    return true
  }
  const challengeEnd = message.match(/WCHALLENGE_END:(\d+):([^:]+):([^:]+):([^\s]+)/)
  if (challengeEnd && challengeEnd[4] === token) {
    const id = Number(challengeEnd[1]), challenge = activeChallenge
    if (challenge && challenge.id === id && challenge.bot === name) {
      activeChallenge = null
      finishHumanChallenge(challenge, challengeEnd[2], challengeEnd[3])
        .catch(error => log('human_challenge_end_error', { id, error: String(error) }))
    }
    return true
  }
  const start = message.match(/WSPAR_START:(\d+):(\d+):([^:]+):([^\s]+)/)
  if (start && start[4] === token) {
    const arena = Number(start[1]), bout = Number(start[2]), opponent = start[3]
    let pair = pairs.get(arena)
    if (!pair || pair.bout !== bout) {
      pair = { arena, bout, a: `NBot${String((arena-1)*2+1).padStart(2,'0')}`,
        b: `NBot${String((arena-1)*2+2).padStart(2,'0')}`, ending: false }
      pairs.set(arena, pair)
    }
    beginFighter(name, arena, bout, opponent)
    return true
  }
  const end = message.match(/WSPAR_END:(\d+):(\d+):([^:]+):([^:]+):([^\s]+)/)
  if (end && end[5] === token) {
    const arena = Number(end[1]), bout = Number(end[2]), pair = pairs.get(arena)
    if (pair && pair.bout === bout) endPair(pair, end[3], end[4]).catch(error => log('pair_end_error', { arena, error: String(error) }))
    return true
  }
  return false
}
function createBot (name) {
  const bot = mineflayer.createBot({ host: '127.0.0.1', port: 25566,
    username: name, version: '1.21.1', auth: 'offline', keepAlive: true,
    checkTimeoutInterval: 120000 })
  bots.set(name, bot)
  let movementInstalled = false
  let crossbowProbeInstalled = false
  bot.on('messagestr', message => {
    if (onSparMessage(name, message)) return
    if (/register|注册/i.test(message) && !/already|已注册/i.test(message)) bot.chat(`/register ${credentials[name]} ${credentials[name]}`)
    else if (/\/login|登录|log in/i.test(message)) bot.chat(`/login ${credentials[name]}`)
  })
  bot.on('health', () => {
    const session = sessions.get(name)
    if (!session) return
    const received = Math.max(0,session.lastHealth-bot.health)
    session.lastHealth = bot.health
    if (received > 0) {
      if (session.kind === 'human-challenge') append(humanFramesPath,
        { matchId: `${serverRunId}:challenge:${session.bout}`, kind: 'feedback',
          fighter: name, frame: session.clientFrame, received, health: bot.health })
    }
  })
  bot.on('entityHurt', entity => {
    const session = sessions.get(name)
    if (!session || entity?.username !== session.opponent) return
    session.visibleOpponentHurt++
    const desperate = bot.health < 6
    if (desperate) session.visibleOpponentHurtWhileLow++
    // A normal client sees the hurt animation. Reward it modestly; native deaths
    // still decide the bout and the exact hidden damage never enters observations.
    if (session.kind === 'human-challenge') append(humanFramesPath,
      { matchId: `${serverRunId}:challenge:${session.bout}`, kind: 'feedback',
        fighter: name, frame: session.clientFrame, visibleOpponentHurt: true,
        rewardProxy: desperate ? 1 : .5 })
  })
  bot.on('entitySwingArm', entity => {
    const session = sessions.get(name)
    if (session && entity?.username === session.opponent) session.opponentSwing++
  })
  bot.on('physicsTick', () => {
    const session = sessions.get(name)
    if (!session) return
    session.clientFrame++; session.framesSeen++
    recordFighterFrame(session, bot)
    requestAction(session)
  })
  bot._client.on('set_cooldown', packet => {
    const session = sessions.get(name)
    if (session && packet.itemID === mcData.itemsByName.shield.id
        && (packet.cooldownTicks ?? packet.cooldown ?? 0) > 0) {
      session.shieldDisabledUntil = Date.now()+50*(packet.cooldownTicks ?? packet.cooldown)
    }
  })
  bot.on('kicked', reason => log('bot_kicked', { name, reason: String(reason).slice(0,220) }))
  bot.on('error', error => log('bot_error', { name, error: String(error).slice(0,220) }))
  bot.on('end', reason => {
    if (activeChallenge?.bot === name) {
      const challenge = activeChallenge; activeChallenge = null
      finishHumanChallenge(challenge, 'NONE', 'disconnect')
        .catch(error => log('human_challenge_end_error', { id: challenge.id, error: String(error) }))
    }
    readyBots.delete(name)
    log('bot_end', { name, reason: String(reason) })
    if (!stopping) setTimeout(() => {
      if (!stopping && bots.get(name) === bot) createBot(name)
    }, 3000 + Math.floor(Math.random()*3000))
  })
  bot.on('spawn', () => {
    if (!movementInstalled) { installVanillaUseMovement(bot); movementInstalled = true }
    if (debugCrossbow && !crossbowProbeInstalled) {
      crossbowProbeInstalled = true
      bot.inventory.on('updateSlot', (slot, oldItem, item) => {
        if (slot !== 40 || item?.name !== 'crossbow') return
        const component = item.componentMap?.get('charged_projectiles')
        log('crossbow_component', { name, slot,
          types: item.components?.map(value => value.type),
          data: JSON.stringify(component?.data ?? null).slice(0,500) })
      })
    }
    readyBots.add(name)
    log('bot_spawn', { name })
  })
}
async function initialize () {
  startBridge()
  replayMissingReviews().catch(error => log('review_recovery_error', { error: String(error) }))
  replayMissingHumanReviews()
  for (const name of names) { createBot(name); await new Promise(resolve => setTimeout(resolve, 500)) }
  while (!bridgeReady) await new Promise(resolve => setTimeout(resolve, 1000))
  log('bots_created', { count, connected: readyBots.size })
  const focusCycle = [
    ['AXE_BREAK','SYNC'], ['SHIELD','CROSSBOW'], ['BOW','DODGE'],
    ['FLANK','COMBO'], ['CRITICAL','ESCAPE'], ['SPRINT_KB','CHARGE']
  ]
  for (let arena = 1; arena <= arenaCount; arena++) {
    const a = names[(arena-1)*2], b = names[(arena-1)*2+1]
    const needsCoach = []
    for (const [fighter, opponent] of [[a,b],[b,a]]) {
      const previous = contexts.get(fighter)
      if (!previous || previous.source !== 'Qwen2.5-1.5B-Instruct')
        needsCoach.push([fighter, opponent])
      const index = names.indexOf(fighter)
      const style = styleRotation[(Math.floor(index/2)+(index%2))%styleRotation.length]
      const focus = focusCycle[(arena-1)%focusCycle.length][fighter === a ? 0 : 1]
      const context = { fighter, opponent, focus, style,
        reason: 'Balanced native PvP curriculum: spacing combo, real punish critical, shield-counter retreat with bow/crossbow, axe shield break and observed-hit jump reset.',
        ownRecent: previous?.ownRecent || [], source: 'curriculum-seed' }
      contexts.set(fighter, context); append(coachPath, context)
    }
    for (const [fighter, opponent] of needsCoach)
      coachFighter(fighter,opponent).catch(error =>
        log('coach_error', { fighter, error: String(error) }))
    desired = arena
    fs.writeFileSync(readyFile, JSON.stringify({ at: now(), bots: count, bridgeReady,
      qwenContexts: contexts.size, desired: arenaCount }))
    const result = await rcon(`selfplay start ${arena}`)
    log('arena_enabled', { arena, result })
    if (!result.includes('started=1')) nextArena(arena)
  }
  desired = arenaCount
}
const readinessTimer = setInterval(() => {
  if (stopping || !bridgeReady) { fs.rmSync(readyFile,{force:true}); return }
  fs.writeFileSync(readyFile, JSON.stringify({ at: now(), bots: count, bridgeReady,
    qwenContexts: contexts.size, desired: arenaCount, activePairs: pairs.size,
    qwenQueue: qwenQueue.length, qwenActive }))
}, 1000)
process.on('SIGINT', () => { stopping = true; clearInterval(readinessTimer);
  fs.rmSync(readyFile,{force:true}); for (const bot of bots.values()) bot.quit();
  if (bridge?.stdin.writable) sendBridge({ command: 'close' }); process.exit(0) })
log('selfplay_boot', { bots: count, arenas: arenaCount, checkpoint: path.join(checkpoint,'recurrent-ppo.json') })
initialize().catch(error => { log('selfplay_init_error', { error: String(error) }); process.exitCode = 1 })
