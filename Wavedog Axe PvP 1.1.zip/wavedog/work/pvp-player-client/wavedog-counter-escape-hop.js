// Protocol-player port of CounterEscapeHop.java from counter-escape-ground.
// The source uses server ticks; this client uses the corresponding 150 ms
// (three 50 ms ticks) takeoff deadline and public on-ground observations.
function create () {
  return { counterAt: -Infinity, submittedAt: -Infinity,
    active: false, spent: false, airborne: false,
    criticalSubmitted: false, exitAccepted: false }
}
function arm (hop, at) {
  if (at <= hop.counterAt) return
  Object.assign(hop, { counterAt: at, submittedAt: -Infinity,
    active: true, spent: false, airborne: false,
    criticalSubmitted: false, exitAccepted: false })
}
function observe (hop, at, onGround) {
  if (!hop.active) return
  if (!onGround) {
    hop.airborne = true
    hop.spent = true
  } else if (hop.airborne) {
    hop.active = false
  } else if (hop.submittedAt > -Infinity && at - hop.submittedAt > 150
      || hop.submittedAt === -Infinity && at - hop.counterAt > 150) {
    hop.active = false
    hop.spent = true
  }
}
function submitJump (hop, at) {
  if (!hop.active || hop.spent || at < hop.counterAt) return false
  hop.submittedAt = at
  hop.spent = true
  return true
}
function criticalAvailable (hop, nativeWindow, velocityY) {
  return hop.active && hop.airborne && !hop.criticalSubmitted
    && !hop.exitAccepted && nativeWindow
    && Number.isFinite(velocityY) && velocityY < 0
}
function acceptExit (hop) { hop.exitAccepted = true }
function blocked (hop) { hop.active = false; hop.spent = true }
module.exports = { create, arm, observe, submitJump,
  criticalAvailable, acceptExit, blocked }
