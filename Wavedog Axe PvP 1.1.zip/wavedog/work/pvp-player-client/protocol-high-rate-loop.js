'use strict'
const {Worker,MessageChannel}=require('node:worker_threads')
const monoMs=()=>Number(process.hrtime.bigint())/1e6
function createHighRateLoop({hz=500,maxAgeMs=100,onCycle,onError=()=>{}}={}){
  if(!Number.isFinite(hz)||hz<=0||hz>1000)throw Error('Invalid control frequency')
  const {port1,port2}=new MessageChannel(),signal=new SharedArrayBuffer(8),wake=new Int32Array(signal)
  const worker=new Worker(require.resolve('./protocol-high-rate-worker'),
    {workerData:{port:port2,signal,hz,maxAgeMs},transferList:[port2]})
  let matchId=null,closed=false,lastSerial=0
  const send=m=>{if(closed)return false;port1.postMessage(m);Atomics.add(wake,0,1);Atomics.notify(wake,0);return true}
  port1.on('message',r=>{Atomics.store(wake,1,r.serial);if(!closed&&r.matchId===matchId&&r.serial>lastSerial){
    lastSerial=r.serial;onCycle?.({...r,deliveryMs:Math.max(0,monoMs()-r.analyzedAtMs)})}})
  worker.on('error',onError)
  return {
    reset(id){matchId=id;lastSerial=0;Atomics.store(wake,1,0);send({command:'reset',matchId:id})},
    sample(sample){return sample.matchId===matchId&&send({command:'sample',sample})},
    async close(){
      if(closed)return
      const exited=new Promise(resolve=>worker.once('exit',resolve))
      send({command:'stop'});closed=true;port1.close()
      // Allow the worker to close its native timer before using a forced exit.
      const limit=setTimeout(()=>worker.terminate(),1000)
      try{await exited}finally{clearTimeout(limit)}
    },
    worker
  }
}

// Each 2ms cycle checks the latest model-selected command. This gate selects
// no movement/attack itself. A command revision can execute ONCE; unchanged
// controls remain held, rather than spamming 500 attacks/slot/use packets.
function createHighRateControlGate({maxActionAgeMs=50,apply}){
  let matchId=null,epoch=0,latest=null,executed=null,lastRevision=-1,appliedRevision=-1
  let lastEffect=null,lastSourceRevision=null
  const effect=c=>JSON.stringify(['forward','side','sprint','jump','sneak','attack','shield','use','release',
    'slot','yaw','pitch','flightLook','pureAimVersion','aimYawOffset','aimPitchOffset',
    'decidedTick','baseTick','observedWeaponEpoch'].map(k=>c[k]??null))
  const counts={checks:0,applied:0,unchanged:0,held:0,stale:0,missing:0}
  return {
    reset(id){matchId=id;epoch++;latest=null;executed=null;lastRevision=-1;appliedRevision=-1;lastEffect=null;lastSourceRevision=null;return epoch},
    publish(action){
      if(action.matchId!==matchId||action.epoch!==epoch||!Number.isSafeInteger(action.revision)
          ||action.revision<=lastRevision||!Number.isFinite(action.atMs)
          ||!Number.isSafeInteger(action.observationRevision))return false
      latest=action;lastRevision=action.revision;return true
    },
    check(analysis,nowMs){
      counts.checks++
      if(!latest||!analysis.available||analysis.matchId!==matchId){counts.missing++;return 'missing'}
      if(nowMs<latest.atMs||nowMs-latest.atMs>maxActionAgeMs
          ||latest.observationRevision!==analysis.revision){counts.stale++;return 'stale'}
      if(latest.revision<=appliedRevision){counts.unchanged++;return 'unchanged'}
      // Consume before calling the executor: no re-entrant duplicate strike.
      const action=latest;appliedRevision=action.revision
      const currentEffect=effect(action.command)
      if(currentEffect===lastEffect&&action.observationRevision===lastSourceRevision){
        counts.held++;return 'held'
      }
      lastEffect=currentEffect;lastSourceRevision=action.observationRevision
      apply(action.command,{matchId,epoch,revision:action.revision,analysis,previous:executed})
      executed=action;counts.applied++;return 'applied'
    },
    get counts(){return {...counts}}
  }
}
module.exports={createHighRateLoop,createHighRateControlGate,monoMs}
