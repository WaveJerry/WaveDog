'use strict'
const {workerData,receiveMessageOnPort}=require('node:worker_threads')
const {PublicMotionMonitor}=require('./protocol-high-rate-motion')
const {port,signal,hz,maxAgeMs}=workerData, wake=new Int32Array(signal)
const precisionWait=require('./protocol-precision-wait').createPrecisionWait(wake)
const timerBackend=precisionWait.backend
const now=()=>Number(process.hrtime.bigint())/1e6
// Compile the real motion/forecast paths before a bout's clock starts. These
// disposable observations never enter a match, model, reward or trace.
const warmup=new PublicMotionMonitor({maxAgeMs})
warmup.reset('worker-warmup')
for(let i=0;i<1200;i++){
  const at=i*50
  warmup.ingest({matchId:'worker-warmup',revision:i,atMs:at,tick:i,source:'packet',
    self:{position:{x:i*.01,y:0,z:0},sourceTick:i,grounded:true},
    opponent:{position:{x:3.3+i*.02,y:i%3*.1,z:.2},sourceTick:i,visible:true,grounded:i%3===0}})
  warmup.analyze(at+2)
}
const monitor=new PublicMotionMonitor({maxAgeMs}),period=1000/hz
let running=true,next=now()+period,serial=0,cycles=0,missed=0,lastCycle=null,startedAt=now(),lastPosted=0,deliveries=0
let maxIntervalMs=0,maxLatenessMs=0,recentMisses=[]
try{while(running){
  const wakeVersion=Atomics.load(wake,0)
  let message
  while((message=receiveMessageOnPort(port))){
    const m=message.message
    if(m.command==='stop'){running=false;break}
    if(m.command==='reset'){monitor.reset(m.matchId);next=now()+period;serial=0;cycles=0;missed=0;lastCycle=null;lastPosted=0;deliveries=0;startedAt=now();maxIntervalMs=0;maxLatenessMs=0;recentMisses=[]}
    if(m.command==='sample')monitor.ingest(m.sample)
  }
  if(!running)break
  const at=now()
  if(at>=next){
    const late=at-next,skipped=Math.floor(late/period)
    maxLatenessMs=Math.max(maxLatenessMs,late)
    if(lastCycle!==null)maxIntervalMs=Math.max(maxIntervalMs,at-lastCycle)
    if(skipped){recentMisses.push({cycle:cycles+1,intervalMs:lastCycle===null?null:at-lastCycle,latenessMs:late,skipped});if(recentMisses.length>16)recentMisses.shift()}
    missed+=skipped;next+=(skipped+1)*period
    const started=now(),analysis=monitor.analyze(at)
    serial++;cycles++
    // Compute every scheduled cycle. If the game thread is busy, overwrite
    // the notification with the next fresh result instead of queuing hundreds
    // of obsolete callbacks for it to replay after the stall.
    if(Atomics.load(wake,1)>=lastPosted){
      deliveries++
      port.postMessage({type:'cycle',timerBackend,serial,cycles,deliveries,missedDeadlines:missed,
      measuredHz:cycles*1000/Math.max(period,at-startedAt),
      targetHz:hz,maxIntervalMs,maxLatenessMs,recentMisses,
      intervalMs:lastCycle==null?null:at-lastCycle,latenessMs:late,
      computeMs:now()-started,...analysis})
      lastPosted=serial
    }
    lastCycle=at
  }
  // Sleep off the game/client thread. On Windows, updates are drained by the
  // next <=2ms timer cycle. Do not replay missed cycles after a process stall.
  precisionWait.wait(Math.max(0,next-now()),wakeVersion)
}}finally{precisionWait.close();port.close()}
