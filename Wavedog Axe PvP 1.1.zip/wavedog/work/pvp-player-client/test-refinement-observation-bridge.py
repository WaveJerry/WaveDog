"""Offline: packet refinements must not advance Java observation history."""
from pathlib import Path
import json, subprocess

root=Path(__file__).resolve().parents[2]
server=Path('D:/Walt Disney/Minecraft-1.21.1-Server')
classpath=';'.join(map(str,[root/'work/pvp-player-client/bridge-classes',root/'work/pvp-neural-lab/classes',
    server/'versions/1.21.1/paper-1.21.1.jar',server/'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
folder=root/'outputs/full-model-86-20261118/observation-bridge-fixture'
reset={'command':'reset','fighter':'fixture','opponent':'fixture-other','learning':False}
def frame(tick,request_id,refine=False,x=1061.3):
    return {'command':'act','fighter':'fixture','opponent':'fixture-other','requestId':request_id,
        'tick':tick,'observationRefinement':refine,'yaw':-90,'pitch':0,'style':'MIXED','focus':'FREE',
        'self':{'x':1058,'y':221,'z':960,'eyeY':222.62,'ground':True,'charge':1,'health':20,'held':0},
        'seen':{'visible':True,'x':x,'y':221,'z':960,'held':'DIAMOND_AXE','arrows':[]}}
def run(rows):
    p=subprocess.run([str(server/'runtime/java21/bin/java.exe'),'-cp',classpath,
        'local.wavedog.lab.ProtocolPlayerBridge',str(folder),'--observe-only'],
        input='\n'.join(map(json.dumps,rows))+'\n',capture_output=True,text=True,encoding='utf-8',check=True,timeout=30)
    values=[json.loads(s) for s in p.stdout.splitlines()]
    assert not any(s.get('event')=='error' for s in values),values
    return {s['requestId']:s['observation'] for s in values if s.get('model')=='DUAL-OBS'}
baseline=run([reset,frame(10,1),frame(11,1002)])
refined=run([reset,frame(10,1)]+[frame(10,i+2,True,1061.3-i*.0001) for i in range(500)]+[frame(11,1002)])
assert baseline[1]==refined[1]
assert baseline[1]==refined[2], 'unchanged observation must use the same pre-tick history'
assert baseline[1002]==refined[1002], '500 refinements must not alter next physical frame history'
print('REFINEMENT_OBSERVATION_HISTORY_PARITY_PASS 500')
