'use strict'
// Extracted unchanged from the actually loaded, latest Punengbho ranged
// synchronization block. No movement/controller code is imported or executed.
const SOURCE_SHA = '60cbc887476b3e097b75499e6bcd462b27f4cd40672bc1cfe742e9ffb9dc5e90'
function createRangedState(){return {mode:'LEGACY86',ranged:null,rangedAt:0,rangedPhase:null,
  rangedSerial:0,spentShotEvent:0,rangedUseAt:0,spentBowCycle:0,spentLoadCycle:0,
  loadingReply:null,nextRanged:0,orbitReblock:false,blocked:null}}
function syncRanged(owner,frame,command,{emergency=false,mode='LEGACY86'}={}){
  const s=owner.rangedSync??=createRangedState(),o=frame.observation,t=o.tick
  s.mode=mode;s.blocked=owner.lastBlock>owner.spentBlock?{tick:owner.lastBlock}:null
  const c={...command},owners={},shieldReady=Boolean(frame.self.shieldAvailable)
  if(emergency){s.ranged=null;s.rangedPhase=null;s.loadingReply=null;return null}
  // Ranged is an offhand overlay, never a movement command or an early return.
  const legalStrike = c.attack && o.visible && o.reach <= 3
  // A usable shield handles opposing bows. Do not drop it to mirror a draw;
  // if it recovers during our draw, cancel that bow instead of releasing it.
  // A disabled/inaccessible shield still permits the existing bow mirror.
  if(shieldReady&&s.ranged==='bow'){s.ranged=null;s.rangedPhase=null}
  const mirrorBowShot=s.ranged==='bow'&&(o.targetShotEvent||0)>(s.rangedShotEvent||0)
    &&t-(o.targetShotTick??-1000)>=0&&t-o.targetShotTick<=3
  const arrowShield=shieldReady&&o.offhandShieldReady
    &&(o.shieldEffective||o.arrowThreat?.time>=5)
  const bowDodgeReply=mirrorBowShot&&o.arrowThreat&&!arrowShield
  const crossbowDodgeReply=o.loaded&&(o.targetShotEvent||0)>s.spentShotEvent
    &&t-(o.targetShotTick??-1000)>=0&&t-o.targetShotTick<=3&&o.arrowThreat&&!arrowShield
  const urgent = legalStrike || ['COUNTER','SHIELD_RETURN'].includes(s.mode)
    || Boolean(s.orbitReblock&&shieldReady)
    || Boolean(s.blocked && t - s.blocked.tick < 7) || o.arrowThreat&&!bowDodgeReply&&!crossbowDodgeReply
  // A fresh public load authorizes one loaded shot, one reload and (only if
  // still unshielded when that reload completes) one follow-up. Equipment
  // acknowledgements advance this sequence, never elapsed load time alone.
  const unshielded=!o.targetShieldRaised&&!o.targetShieldFacing
  const loadingReply=o.loaded&&o.targetLoading&&unshielded&&Number.isSafeInteger(o.targetLoadCycle)
    &&o.targetLoadCycle>s.spentLoadCycle
  // Mirroring a public ranged action is legal at close range too. The former
  // blanket six-block cutoff silently disabled the original close bow mirror
  // and repeatedly cancelled crossbow loading when either player approached.
  // Real melee/arrow emergencies still preempt within this same command.
  const safe = o.visible && !urgent
  if (!safe) {s.ranged=null;s.rangedPhase=null;s.loadingReply=null}
  if(s.loadingReply&&t>s.loadingReply.until)s.loadingReply=null
  if(s.loadingReply?.phase==='await-spent'&&!o.loaded)s.loadingReply.phase='reload'
  if(s.ranged==='fire-crossbow'&&!o.loaded){s.ranged=null;s.rangedPhase=null}
  if(s.rangedSource==='loading-reply-first'&&s.rangedPhase==='prepare'&&!loadingReply){
    s.ranged=null;s.rangedPhase=null
  }
  if(s.rangedSource==='loading-reply-followup'&&s.rangedPhase==='prepare'
      &&(!s.loadingReply||!unshielded)){
    s.ranged=null;s.rangedPhase=null;s.loadingReply=null
  }
  // A stop-use packet can precede charged equipment by one or two ticks.
  // Only preserve an ALREADY running mirrored load; this never starts one.
  const loadConfirmationPending=o.visible&&o.targetLoadResult==='unconfirmed'
    &&t-o.targetLoadEndedAt>=0&&t-o.targetLoadEndedAt<=2
  const sequenceReload=s.loadingReply&&['reload','await-loaded'].includes(s.loadingReply.phase)
  if(s.ranged==='load-crossbow'&&!sequenceReload&&!o.targetLoading&&!o.targetKnownLoaded&&!loadConfirmationPending){s.ranged=null;s.rangedPhase=null}
  if(s.ranged==='bow'&&!o.targetBow&&!mirrorBowShot){s.ranged=null;s.rangedPhase=null}
  if(s.rangedPhase==='verify-fire') {
    if(!o.loaded||t-s.rangedUseAt>=8){
      // Only an observed spent bolt allows our promised reload. If loaded
      // metadata never changes, stop rather than shooting the same event twice.
      if(s.loadingReply?.phase==='await-spent'&&o.loaded)s.loadingReply=null
      const reload=s.loadingReply?.phase==='reload'
      s.ranged=null;s.rangedPhase=null;s.nextRanged=reload?t:Math.max(s.nextRanged,t+15)
    }
  }
  if(s.rangedPhase==='verify-load'&&o.loaded){
    const follow=s.rangedSource==='loading-reply-reload'&&s.loadingReply?.phase==='await-loaded'
    if(follow)s.loadingReply.phase='followup'
    s.ranged=null;s.rangedPhase=null;s.nextRanged=follow?t:t+15
  }
  // Shield warm-up already counts as raising a shield. Do not park a shot
  // authorization until it drops later; this opportunity is checked now.
  if(s.loadingReply?.phase==='followup'&&!unshielded)s.loadingReply=null
  if(s.ranged&&t-s.rangedAt>45){s.ranged=null;s.rangedPhase=null;s.nextRanged=t+15}
  if (safe && !s.ranged && t >= s.nextRanged) {
    s.rangedSource=null
    if (o.loaded && (o.targetShotEvent || 0) > s.spentShotEvent
        && t - (o.targetShotTick ?? -1000) >= 0 && t - o.targetShotTick <= 3) {
      s.ranged = 'fire-crossbow';s.rangedSource='ranged-sync'
    }
    else if(s.loadingReply?.phase==='followup'&&o.loaded&&unshielded){
      s.ranged='fire-crossbow';s.rangedSource='loading-reply-followup'
    }
    else if(s.loadingReply?.phase==='reload'&&!o.loaded&&o.arrows>0){
      s.ranged='load-crossbow';s.rangedSource='loading-reply-reload'
    }
    else if(loadingReply){s.ranged='fire-crossbow';s.rangedSource='loading-reply-first';s.rangedLoadCycle=o.targetLoadCycle}
    else if (!o.loaded && o.arrows > 0 && o.targetLoading)
      s.ranged = 'load-crossbow'
    else if (!shieldReady && o.arrows > 0 && o.targetBow
        &&(!Number.isSafeInteger(o.targetBowCycle)||o.targetBowCycle>s.spentBowCycle)) s.ranged = 'bow'
    if (s.ranged) {
      if(s.ranged!=='fire-crossbow'&&s.rangedSource!=='loading-reply-reload')s.rangedSource='ranged-sync'
      s.rangedAt=t;s.rangedPhase='prepare';s.rangedSerial++;s.rangedShotEvent=o.targetShotEvent||0
      s.rangedBowCycle=o.targetBowCycle
    }
  }
  if (s.ranged&&!s.rangedPhase.startsWith('verify')) {
    c.shield = false; c.offhand = s.ranged === 'bow' ? 'bow' : 'crossbow'
    c.ranged=s.ranged;c.rangedId=s.rangedSerial
    c.rangedRelease=s.ranged==='bow'&&mirrorBowShot
    if(c.rangedRelease)s.rangedShotEvent=o.targetShotEvent
    // A main-hand slot update also interrupts offhand use in vanilla. Only
    // the ranged overlay owns these two channels until it ends/preempts.
    c.slot = o.held; c.attack = false
    owners.mainhand = owners.attack = 'mechanical-ranged'
    owners.offhand=owners.shield='mechanical-ranged'
    c.rangedReason=s.rangedSource||'ranged-sync'
    if(s.ranged==='load-crossbow'&&o.loaded){c.ranged=null;s.ranged=null;s.rangedPhase=null}
  }
  return c.ranged?{ranged:c.ranged,rangedId:c.rangedId,rangedRelease:c.rangedRelease,
    rangedReason:c.rangedReason,slot:c.slot,attack:false,shield:false,offhand:c.offhand}:null
}
function rangedApplied(owner,command,result,tick) {
  const s=owner.rangedSync;if(!s)return
  if(!command.ranged||command.rangedId!==s.rangedSerial)return
  if(result.fireRejected){s.ranged=null;s.rangedPhase=null;s.loadingReply=null;return}
  if(result.fireSent) {
    s.rangedPhase='verify-fire';s.rangedUseAt=tick
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
    if(s.rangedSource==='loading-reply-first'){
      s.spentLoadCycle=Math.max(s.spentLoadCycle,s.rangedLoadCycle||0)
      s.loadingReply={cycle:s.rangedLoadCycle,phase:'await-spent',until:tick+80}
    }else s.loadingReply=null // any real shot after reload spends the follow-up
  } else if(result.loadReleased) {
    s.rangedPhase='verify-load';s.rangedUseAt=tick
    if(s.rangedSource==='loading-reply-reload'&&s.loadingReply)s.loadingReply.phase='await-loaded'
  }
  else if(result.bowReleased) {
    s.spentShotEvent=Math.max(s.spentShotEvent,s.rangedShotEvent||0)
    if(Number.isSafeInteger(s.rangedBowCycle))s.spentBowCycle=Math.max(s.spentBowCycle,s.rangedBowCycle)
    // A fresh observed draw may start next frame. The consumed cycle, rather
    // than an eight-tick cooldown, prevents reusing stale pre-release metadata.
    s.ranged=null;s.rangedPhase=null;s.nextRanged=tick+1
  }
  else if(result.useStarted)s.rangedPhase='using'
}
module.exports={syncRanged,rangedApplied,createRangedState,SOURCE_SHA}
