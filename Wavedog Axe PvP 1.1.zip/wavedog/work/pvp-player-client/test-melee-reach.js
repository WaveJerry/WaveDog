const assert = require('node:assert/strict')
const { targetBoxWithinReach,targetBoxDistance } = require('./melee-reach')

const bot = { entity: { position: { x: 0, y: 0, z: 0 }, eyeHeight: 1.62 } }
const target = x => ({ position: { x, y: 0, z: 0 }, width: .6, height: 1.8 })

assert(targetBoxWithinReach(bot, target(2.9)))
assert(targetBoxWithinReach(bot, target(3.29)),
  'hitbox edge remains legal beyond three blocks centre distance')
assert(!targetBoxWithinReach(bot, target(3.31)))
assert(!targetBoxWithinReach(bot, { ...target(2), position: { x: 2, y: -4, z: 0 } }),
  'vertical separation must not count as melee reach')
assert(!targetBoxWithinReach(bot, { ...target(2), width: undefined }))
assert(Math.abs(targetBoxDistance(bot,target(3.299))-2.999)<1e-12)
assert(targetBoxWithinReach(bot,target(3.3)),'exactly 3 blocks is not an extended reach')
assert(!targetBoxWithinReach(bot,target(3.30001)))
assert.equal(targetBoxDistance(bot,{...target(2),width:undefined}),Infinity)
console.log('MELEE_REACH_PASS')
