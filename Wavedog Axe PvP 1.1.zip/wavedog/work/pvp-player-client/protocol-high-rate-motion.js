'use strict'

const SCHEMA = 'public-motion-v1'
const FEATURE_COUNT = 32
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))
const finitePoint = p => p && ['x','y','z'].every(k => Number.isFinite(p[k]))
const dist = (eye, p, half, height) => Math.hypot(
  Math.max(0, Math.abs(eye.x-p.x)-half),
  Math.max(0, p.y-eye.y, eye.y-p.y-height),
  Math.max(0, Math.abs(eye.z-p.z)-half))

// Uses public position samples only. No attack thresholds or controller live
// here. Prediction is explicitly separate from the latest measured position.
class PublicMotionMonitor {
  constructor ({ tickMs=50, maxAgeMs=100 } = {}) {
    if (!(tickMs>0) || !(maxAgeMs>0)) throw Error('Invalid motion timing')
    this.tickMs=tickMs; this.maxAgeMs=maxAgeMs; this.reset(null)
  }
  reset (matchId) {
    this.matchId=matchId; this.revision=-1; this.lastAt=-Infinity
    this.bodies={}; this.physicalTick=null
  }
  ingest (s) {
    if (!this.matchId || s.matchId!==this.matchId || !Number.isSafeInteger(s.revision)
        || s.revision<=this.revision || !Number.isFinite(s.atMs) || s.atMs<this.lastAt) return false
    if (!['physics','packet'].includes(s.source)) throw Error('Samples need a real observation source')
    for (const key of ['self','opponent']) if (s[key]) {
      const b=s[key], prior=this.bodies[key]
      if (!finitePoint(b.position)) throw Error('Invalid public position')
      const at={...b,position:{...b.position},atMs:s.atMs,source:s.source,
        physicalTick:s.tick,velocity:{x:0,y:0,z:0},acceleration:{x:0,y:0,z:0},
        velocityKnown:false,velocityAgeMs:null,velocityAtMs:null,velocitySource:null}
      // Explicit velocities must name their phase and unit. Mineflayer's own
      // post-drag velocity cannot be subtracted from remote position deltas.
      if (b.velocity) {
        if (!finitePoint(b.velocity) || b.velocityPhase!=='displacement'
            || b.velocityUnit!=='blocks-per-tick') throw Error('Ambiguous velocity phase/unit')
        at.velocity={...b.velocity}; at.velocityKnown=true; at.velocityAgeMs=0
        at.velocityAtMs=s.atMs; at.velocitySource='public-displacement'
      }
      const base=prior?.derivativeBase || prior
      const dt=base ? s.atMs-base.atMs : 0
      const sourceTicks=Number.isSafeInteger(b.sourceTick)&&Number.isSafeInteger(base?.sourceTick)
        ? b.sourceTick-base.sourceTick : null
      const ticks=sourceTicks>0 ? sourceTicks : dt/this.tickMs
      if (!at.velocityKnown && base && dt>=this.tickMs*.5 && dt<=250 && ticks>0) {
        const v=Object.fromEntries(['x','y','z'].map(k=>[k,(b.position[k]-base.position[k])/ticks]))
        // Corrections/teleports are new observations, never huge momentum.
        if (Math.hypot(v.x,v.y,v.z)<=4 && !b.discontinuity) {
          at.velocity=v; at.velocityKnown=true; at.velocityAgeMs=0
          at.velocityAtMs=s.atMs; at.velocitySource=sourceTicks>0?'public-source-ticks':'public-arrival-interval'
          if (base.velocityKnown) for (const k of ['x','y','z'])
            at.acceleration[k]=clamp((v[k]-base.velocity[k])/ticks,-1,1)
        }
      } else if (!at.velocityKnown && prior && dt<this.tickMs*.5 && !b.discontinuity) {
        at.velocity={...prior.velocity};at.velocityKnown=prior.velocityKnown
        at.velocityAtMs=prior.velocityAtMs;at.velocitySource=prior.velocitySource
        at.derivativeBase=base
      }
      if (b.discontinuity) {at.velocityKnown=false;at.velocity={x:0,y:0,z:0};delete at.derivativeBase}
      if (at.velocityKnown) at.velocityAgeMs=s.atMs-at.velocityAtMs
      this.bodies[key]=at
    }
    this.revision=s.revision;this.lastAt=s.atMs;this.physicalTick=s.tick
    return true
  }
  body (b, nowMs, futureMs=0) {
    if (!b) return null
    const age=Math.max(0,nowMs-b.atMs),velocityAge=b.velocityAtMs==null?Infinity:Math.max(0,nowMs-b.velocityAtMs)
    const fresh=age<=this.maxAgeMs, velocityKnown=b.velocityKnown && velocityAge<=this.maxAgeMs
    const t=clamp(age+futureMs,0,this.maxAgeMs)/this.tickMs
    const p={...b.position}
    if (velocityKnown && b.visible!==false) for(const k of ['x','y','z'])
      p[k]+=b.velocity[k]*t
    // A linear forecast is not a collision/gravity simulator. Report an
    // expanding bound rather than presenting sub-tick extrapolation as truth.
    const uncertainty=1/4096 + (velocityKnown ? .02 : .35)*t + .06*t*t
      + (velocityKnown ? Math.hypot(...Object.values(b.velocity))*.15 : 0)
    return {observed:{...b.position},predicted:p,ageMs:age,velocityAgeMs:Number.isFinite(velocityAge)?velocityAge:null,
      fresh,velocityKnown,velocity:velocityKnown?{...b.velocity}:{x:0,y:0,z:0},
      acceleration:{...b.acceleration},uncertainty,visible:b.visible!==false,
      grounded:b.grounded??null,eyeHeight:b.eyeHeight??1.62,half:b.half??.3,height:b.height??1.8,
      source:b.source,velocitySource:b.velocitySource}
  }
  analyze (nowMs) {
    if (!Number.isFinite(nowMs) || nowMs<this.lastAt) throw Error('Analysis clock predates observation')
    const a=this.body(this.bodies.self,nowMs),b=this.body(this.bodies.opponent,nowMs)
    const available=Boolean(a&&b&&a.fresh&&b.fresh&&b.visible)
    const out={schema:SCHEMA,matchId:this.matchId,revision:this.revision,analyzedAtMs:nowMs,
      physicalTick:this.physicalTick,sourceAtMs:Number.isFinite(this.lastAt)?this.lastAt:null,
      predictionOnly:true,available,self:a,opponent:b,features:Array(FEATURE_COUNT).fill(0)}
    if (!available) return out
    const eye={...a.predicted,y:a.predicted.y+a.eyeHeight}
    const dx=b.predicted.x-a.predicted.x,dz=b.predicted.z-a.predicted.z,r=Math.hypot(dx,dz)
    const ux=r>1e-9?dx/r:0,uz=r>1e-9?dz/r:0
    const rv={x:b.velocity.x-a.velocity.x,y:b.velocity.y-a.velocity.y,z:b.velocity.z-a.velocity.z}
    const closing=-(rv.x*ux+rv.z*uz),side=rv.x*(-uz)+rv.z*ux
    const reach=dist(eye,b.predicted,b.half,b.height)
    const observedReach=dist({...a.observed,y:a.observed.y+a.eyeHeight},b.observed,b.half,b.height)
    const future=[2,10,25,50].map(ms=>{
      const x=this.body(this.bodies.self,nowMs,ms),y=this.body(this.bodies.opponent,nowMs,ms)
      return dist({...x.predicted,y:x.predicted.y+x.eyeHeight},y.predicted,y.half,y.height)
    })
    out.reach={observed:observedReach,predicted:reach,futureMs:[2,10,25,50],future,
      uncertainty:a.uncertainty+b.uncertainty}
    out.relative={...rv,closingPerTick:closing,lateralPerTick:side}
    out.features=[1,Number(a.velocityKnown),Number(b.velocityKnown),
      ...['x','y','z'].map(k=>a.velocity[k]),...['x','y','z'].map(k=>b.velocity[k]),
      rv.x,rv.y,rv.z,closing,side,dx/8,(b.predicted.y-a.predicted.y)/4,dz/8,
      (reach-3)/3,(observedReach-3)/3,...future.map(v=>(v-3)/3),
      a.ageMs/100,b.ageMs/100,out.reach.uncertainty,
      b.acceleration.x,b.acceleration.y,b.acceleration.z,
      Number(a.grounded===true),Number(b.grounded===true),Number(b.velocitySource==='public-source-ticks')]
      .map(v=>clamp(v,-8,8))
    if(out.features.length!==FEATURE_COUNT||!out.features.every(Number.isFinite))throw Error('Motion feature schema mismatch')
    return out
  }
}
module.exports={PublicMotionMonitor,SCHEMA,FEATURE_COUNT}
