"""Prove a valid episode changes a separate checkpoint and a reset does not."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
source = base / 'new-learning/models/recurrent-ppo.json'
folder = base / 'new-learning/learning-test'
folder.mkdir(parents=True, exist_ok=True)
target = folder / 'recurrent-ppo.json'
shutil.copy2(source, target)
classpath = ';'.join(map(str, [base / 'bridge-classes', base.parent / 'pvp-neural-lab/classes',
                            server / 'versions/1.21.1/paper-1.21.1.jar',
                            server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
before = hashlib.sha256(target.read_bytes()).hexdigest()
state_before = json.loads(target.read_text(encoding='utf-8'))
rows = [{'command': 'reset', 'opponent': 'WaveJerry', 'learning': True}]
for tick in range(1, 49):
    rows.append({'command': 'act', 'requestId': tick, 'opponent': 'WaveJerry', 'tick': tick,
                 'yaw': 0, 'pitch': 0, 'focus': 'CHARGE',
                 'self': {'x': 1058.5, 'y': 221, 'z': 960.5, 'eyeY': 222.62,
                          'ground': True, 'charge': min(1, tick / 20), 'health': 20,
                          'shieldAvailable': True, 'held': 7},
                 'seen': {'visible': True, 'x': 1058.5, 'y': 221,
                          'z': 962.4, 'held': 'DIAMOND_AXE', 'yaw': 180}})
    rows.append({'command': 'executed', 'decidedTick': tick,
                 'ignoredHeads': [4, 6, 7] if tick % 4 == 0 else [6, 7]})
    if tick == 24:
        rows.append({'command': 'feedback', 'received': 2.61})
        rows.append({'command': 'native_step', 'decidedTick': 24, 'reward': 0.13})
rows.append({'command': 'finish', 'round': 999, 'win': True, 'health': 10})
result = subprocess.run([str(server / 'runtime/java21/bin/java.exe'), '-cp', classpath,
                         'local.wavedog.lab.ProtocolPlayerBridge', str(folder)],
                        input='\n'.join(json.dumps(row) for row in rows)+'\n', text=True,
                        capture_output=True, timeout=60, check=True)
output = [json.loads(line) for line in result.stdout.splitlines()]
trained = next(row for row in output if row.get('event') == 'trained')
after = hashlib.sha256(target.read_bytes()).hexdigest()
state_after = json.loads(target.read_text(encoding='utf-8'))
assert before != after
assert state_after['updates'] > state_before['updates']
assert state_after['episodes'] == state_before['episodes'] + 1
assert trained['gradient_updates_after'] == state_after['updates']
assert trained['native_feedback_applied'] == 1
print(json.dumps({'event': 'learning_bridge_pass', 'updates_before': state_before['updates'],
                  'updates_after': state_after['updates'], 'episodes_after': state_after['episodes'],
                  'checkpoint_changed': before != after}))
