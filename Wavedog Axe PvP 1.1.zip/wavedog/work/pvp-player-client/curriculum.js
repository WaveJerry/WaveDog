function shuffle (values, seed) {
  const result = [...values]
  let state = (seed | 0) || 0x41c64e6d
  for (let i = result.length - 1; i > 0; i--) {
    state ^= state << 13; state ^= state >>> 17; state ^= state << 5
    const j = (state >>> 0) % (i + 1)
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

/** One shared curriculum deals temporary, varied tasks to every bout clone. */
function schedule (fighterIndex, bout, styles, focuses, qwenFocus, runSeed = 0) {
  if (!Number.isInteger(fighterIndex) || fighterIndex < 0 || !Number.isInteger(bout) || bout < 1)
    throw Error('Invalid curriculum position')
  if (styles.length < 2 || !focuses.length) throw Error('Curriculum needs style and focus choices')
  const pairs = []
  for (let a = 0; a < styles.length; a++)
    for (let b = a + 1; b < styles.length; b++) pairs.push([styles[a], styles[b]])
  const epoch = Math.floor((bout - 1) / pairs.length)
  const order = shuffle(pairs.map((_, i) => i), runSeed ^ ((epoch + 1) * 0x9e3779b1))
  const pairing = pairs[order[((bout - 1) % pairs.length + Math.floor(fighterIndex / 2)) % pairs.length]]
  const side = (fighterIndex % 2) ^ ((runSeed + bout + epoch) & 1)
  const style = pairing[side]
  // Qwen proposes two of every three temporary goals; the remaining third
  // cycles through every focus so a blind spot is not forgotten forever.
  const cycleIndex = Math.floor((bout - 1) / 3)
  const scheduledFocus = focuses[(cycleIndex + fighterIndex) % focuses.length]
  const useQwen = bout % 3 !== 1 && qwenFocus && qwenFocus !== 'FREE'
  return { style, focus: useQwen ? qwenFocus : scheduledFocus,
    scheduledFocus, matchup: pairing.join(' vs '),
    curriculumSource: useQwen ? 'shared-Qwen-experiment' : 'coverage-cycle' }
}

module.exports = { schedule }
