'use strict'
const { headingKeys,confirmedRear,nearestHitPoint,nearestBoxPoint } = require('./protocol-mechanical-math')
const {modelRelativeView}=require('./protocol-pure-executor')

// The sole command executor, also exercised against a packet-recording client
// in regression tests. Dependencies perform normal client inputs, never server
// movement, damage, reach or cooldown changes.
function executeCommand (ctx) {
  const executionStarted = performance.now()
  const { bot, planned, frame, target, tick, session, charge, look, aim,
    offhand, stopUse, getUse, setUse, plugin, onSwitch, onAttack } = ctx
  const c = planned.command, owners = { ...planned.owners }, packets = []
  const geometryPoint=ctx.exactBoxAim?nearestBoxPoint:nearestHitPoint
  const reactiveReply=['orbit-reply','guard-reply'].includes(c.kind)
  const usingFlags=Number(target?.metadata?.[8]||0)
  const activeItem=usingFlags&2?target?.equipment?.[1]:target?.equipment?.[0]
  const liveShieldKnown=target?.metadata?.[8]!==undefined&&Array.isArray(target?.equipment)
  const replyShieldRaised=liveShieldKnown?Boolean(usingFlags&1)&&activeItem?.name==='shield'
    :Boolean(frame.observation.targetShieldRaised||frame.observation.targetShieldFacing)
  const rearKind=ctx.legacyRearOnly||c.kind==='orbit-rear'
    ||c.kind==='guard-opening'&&Boolean(frame.observation.targetShieldRaised)
    ||ctx.legacyShieldRearGate&&replyShieldRaised
  const rearAllowed=!(rearKind||reactiveReply&&replyShieldRaised)||confirmedRear(bot.entity.position,
    ctx.getSentPosition?.()||frame.observation.sentPosition,target?.position,target?.yaw)
  // Recheck immediately before execution. A rejected opening keeps the shield
  // up and never produces an attack intent or a claimed PPO attack.
  const key = c.decidedTick
  // A reply may be only one tick old yet refer to the weapon BEFORE our last
  // switch. Applying its old "hold axe" choice after a sword switch creates
  // an endless axe/sword oscillation and repeatedly resets vanilla charge.
  // Reject just the invalid hand/attack portion; the model keeps movement.
  const staleWeapon = c.kind === 'neural' && Number.isSafeInteger(c.observedWeaponEpoch)
    && c.observedWeaponEpoch !== ctx.weaponEpoch
  if (staleWeapon) owners.mainhand = 'stale-weapon-observation'
  const repeated = c.kind === 'neural' && session.attackedDecisions.has(key)
  const stale = c.kind === 'neural' && key <= ctx.lastAttackTick
  const hitVisible = !c.attack || !target || !ctx.canHit || ctx.canHit(target)
  const sent=ctx.getSentPosition?.()||frame.observation.sentPosition,own=frame.self
  let sentReach=null
  if(target&&own&&[sent?.x,sent?.y,sent?.z,own.eyeY,own.y].every(Number.isFinite)){
    const eye={x:sent.x,y:sent.y+own.eyeY-own.y,z:sent.z},point=geometryPoint(eye,target)
    sentReach=Math.hypot(point.x-eye.x,point.y-eye.y,point.z-eye.z)
  }
  let attackSuppressedReason = !c.attack ? null
    : staleWeapon ? 'stale-weapon-observation'
    : !rearAllowed ? 'rear-not-confirmed-on-wire'
    : !target || !frame.seen.visible ? 'target-not-visible'
    : !(frame.observation.reach <= 3) ? 'illegal-reach-suppressed'
    : sentReach!==null&&sentReach>3 ? 'illegal-sent-reach-suppressed'
    : !hitVisible ? 'blocked-line-of-sight'
    : c.kind === 'counter' && (bot.quickBarSlot !== 7 || c.slot !== 7
        || charge() < .7 && !(frame.observation.targetShieldFacing===true&&replyShieldRaised))
      ? 'counter-axe-not-ready'
    : repeated ? 'cached-already-executed'
    : stale ? 'stale-before-last-attack' : null
  let attackGeometry=null
  if(c.attack&&ctx.getSentPosition){
    const pos=bot.entity.position,eye={x:pos.x,y:pos.y+(bot.entity.eyeHeight||1.62),z:pos.z}
    const wireEye=sent?{x:sent.x,y:sent.y+(bot.entity.eyeHeight||1.62),z:sent.z}:null
    const hit=target&&geometryPoint(eye,target),wireHit=wireEye&&target&&geometryPoint(wireEye,target)
    const reach=hit?Math.hypot(hit.x-eye.x,hit.y-eye.y,hit.z-eye.z):Infinity
    const wireReach=wireHit?Math.hypot(wireHit.x-wireEye.x,wireHit.y-wireEye.y,wireHit.z-wireEye.z):Infinity
    if(!attackSuppressedReason){
      if(!wireEye)attackSuppressedReason='unconfirmed-sent-position'
      else if(reach>3||wireReach>3)attackSuppressedReason='execution-range-changed'
      else if(ctx.clearPath&&(!ctx.clearPath(eye,hit)||!ctx.clearPath(wireEye,wireHit)))attackSuppressedReason='blocked-line-of-sight'
    }
    if(hit&&wireHit)attackGeometry={eye,wireEye,hit,wireHit,rayDistance:reach,wireRayDistance:wireReach,
      target:{...target.position,width:target.width||.6,height:target.height||1.8},source:'execution-public-box-and-sent-position-v1'}
  }
  if(c.attack&&c.critical&&ctx.getSentPosition&&!frame.self.critical)
    attackSuppressedReason='not-wire-confirmed-falling'
  const attackAllowed = c.attack && !attackSuppressedReason
  const client = bot._client, write = client.write
  client.write = function (name, data) { packets.push(name); return write.call(this, name, data) }
  let attacked = false, switched = false, executedAttackId = null, attackHeld = null, attackItemName = null, attackCharge=null
  const rangedResult = {}
  try {
    const desired = c.shield || c.attack&&!rearAllowed ? 'shield' : c.ranged ? c.offhand : null
    let use = getUse()
    if (use && (use.kind !== desired || attackAllowed
        || tick < ctx.shieldUntil && use.kind === 'shield')) stopUse()
    // Protect the use session even if a caller supplies an old neural slot.
    // A legal urgent attack can still cancel and switch in this same command.
    const rangedOwnsHand = Boolean(c.ranged && !attackAllowed)
    if (rangedOwnsHand) owners.mainhand = 'mechanical-ranged'
    if (!staleWeapon && !rangedOwnsHand && [0, 7].includes(c.slot) && bot.quickBarSlot !== c.slot) {
      // Changing the active stack can end item use on the server.
      if (getUse()) stopUse()
      bot.setQuickBarSlot(c.slot); onSwitch(); switched = true
    }
    const yaw = target ? Math.atan2(-(target.position.x - bot.entity.position.x),
      -(target.position.z - bot.entity.position.z)) : bot.entity.yaw
    const runAway = c.aimAway || planned.mode!=='NEURAL'&&c.forward < 0 && c.sprint && c.jump
    const modelLook=owners.look==='neural'
    if (runAway) look(yaw + Math.PI, 0)
    else if (Number.isFinite(c.arrowYaw)) look(c.arrowYaw, 0)
    else if(modelLook&&c.pureAimVersion===2&&target&&frame.seen.visible
        &&Number.isFinite(c.aimYawOffset)&&Number.isFinite(c.aimPitchOffset)){
      const p=bot.entity.position,view=modelRelativeView({x:p.x,y:p.y+(bot.entity.eyeHeight||1.62),z:p.z},target,c.aimYawOffset,c.aimPitchOffset,ctx.exactBoxAim)
      look(view.yaw,view.pitch)
    }
    else if(modelLook&&Number.isFinite(c.yaw)&&Number.isFinite(c.pitch))look((180-c.yaw)*Math.PI/180,-c.pitch*Math.PI/180)
    else if (frame.seen.visible && !c.keepLook)
      aim(target, c.ranged === 'bow' ? 'bow' : c.ranged ? 'crossbow' : null, frame.targetVelocity)
    const movement = c.worldHeading ? headingKeys(c.worldHeading, bot.entity.yaw) : c
    bot.setControlState('forward', Boolean(runAway || movement.forward > .5))
    bot.setControlState('back', Boolean(!runAway && movement.forward < -.5))
    bot.setControlState('left', movement.side < -.5)
    bot.setControlState('right', movement.side > .5)
    bot.setControlState('sneak', (owners.sneak==='neural'||ctx.legacySneak)&&Boolean(c.sneak))
    bot.setControlState('jump', Boolean(c.jump))
    if(session.sprintNeedsRearm){bot.setControlState('sprint',false);session.sprintNeedsRearm=false}
    bot.setControlState('sprint', Boolean(c.sprint && (runAway || movement.forward > .5)
      && !desired && !getUse() && bot.food > 6))

    use = getUse()
    // Failed early use during the last cooldown tick must not latch forever.
    if (use && frame.nativeSelf && tick - use.tick >= (use.kind==='shield'?(ctx.shieldReceiptGraceTicks??2):2)
        && frame.nativeSelf.receivedTick > use.tick && !frame.nativeSelf.using) {
      stopUse(); use = null
    }
    if (desired && !attackAllowed && offhand(desired)) {
      const loadedNow=desired==='crossbow'&&(ctx.offhandLoaded?ctx.offhandLoaded():ctx.ownLoaded())
      if(c.ranged==='load-crossbow'&&loadedNow){
        // Re-read the actual offhand AFTER its inventory swap. Right-clicking
        // a now-loaded crossbow would fire, although the planner chose LOAD.
        if(use)stopUse()
        rangedResult.loadReleased=true;rangedResult.loadAlreadyConfirmed=true
      }else if(c.ranged==='fire-crossbow'&&!loadedNow){
        // A lost charge acknowledgment must not turn FIRE into a new load.
        rangedResult.fireRejected='offhand-crossbow-not-loaded'
      }else if (!use) {
        bot.setControlState('sprint', false)
        const firing=c.ranged==='fire-crossbow',savedYaw=bot.entity.yaw,savedPitch=bot.entity.pitch
        try{
          if(firing)aim(target,'crossbow',frame.targetVelocity)
          bot.activateItem(true); setUse({ kind: desired, tick })
        }finally{if(firing&&(modelLook||c.keepLook||runAway))look(savedYaw,savedPitch)}
        rangedResult.useStarted = true
        if (c.ranged === 'fire-crossbow') {
          setUse(null); bot.usingHeldItem = false; rangedResult.fireSent = true
        }
      } else if (desired === 'bow' && c.rangedRelease) {
        // Aim above has already used this frame's public trajectory. Release
        // on the opponent's confirmed shot, not an unrelated distance timer.
        const savedYaw=bot.entity.yaw,savedPitch=bot.entity.pitch
        try{
          aim(target,'bow',frame.targetVelocity)
          stopUse(true); rangedResult.bowReleased = true
        }finally{if(modelLook||c.keepLook||runAway)look(savedYaw,savedPitch)}
      } else if (desired === 'crossbow' && (loadedNow || tick - use.tick >= 26)) {
        stopUse(); rangedResult.loadReleased = true
      }
    }
    if (attackAllowed) {
      if (!c.critical || charge() > .9) {
        stopUse()
        if (c.kind !== 'neural' && (c.critical || !ctx.legacySprintKnockback && !bot.entity.onGround && bot.entity.velocity.y < 0))
          bot.setControlState('sprint', false)
        const savedYaw = bot.entity.yaw, savedPitch = bot.entity.pitch
        try {
          aim(target, null, frame.targetVelocity)
          const id = c.attackId ?? session.state.nextId++
          plugin({ type: 'attack_intent', matchId: session.id, attackId: id,
            kind: c.kind, target: session.opponent })
          attackHeld = bot.quickBarSlot; attackItemName = bot.heldItem?.name || null
          attackCharge=charge()
          bot.attack(target); onAttack(id); attacked = true; executedAttackId = id
          session.attackOwners.set(id, { tick, kind: c.kind, decidedTick: key,
            attackReach: frame.observation.reach })
          if (c.kind === 'neural') session.attackedDecisions.add(key)
        } finally {
          // One synchronous packet sequence. Restore the exact running view,
          // including a dodge's pitch; never recompute it from a moving target.
          if (runAway || c.keepLook) look(savedYaw, savedPitch)
        }
        // A sprint hit stops vanilla sprinting. Re-arm from the next command.
        bot.setControlState('sprint', false)
        if (runAway && c.sprint && bot.food > 6) bot.setControlState('sprint', true)
        // Original unbroken-shield counter restores its shield immediately.
        if (['counter','orbit-reply','guard-reply'].includes(c.kind) && tick >= ctx.shieldUntil && offhand('shield')) {
          bot.activateItem(true); setUse({ kind: 'shield', tick })
        }
      } else attackSuppressedReason = 'critical-undercharged-after-switch'
    }
    if (c.attack && !attacked) owners.attack = attackSuppressedReason || 'not-executed'

    const useNow = getUse()
    const ignore = new Set([8])
    if(owners.sneak!=='neural')ignore.add(3)
    if(owners.look!=='neural'||rangedResult.fireSent||rangedResult.bowReleased){ignore.add(6);ignore.add(7)}
    if (owners.movement !== 'neural' || runAway || c.worldHeading) ignore.add(0)
    if (owners.sprint !== 'neural' || Boolean(c.sprint) !== bot.getControlState('sprint')) ignore.add(1)
    if (owners.jump !== 'neural') ignore.add(2)
    if (owners.attack !== 'neural') ignore.add(4)
    if (owners.mainhand !== 'neural') ignore.add(5)
    return { owners, packets, attacked, switched, executedAttackId, attackHeld, attackItemName,attackCharge,attackGeometry,
      heldItemName: bot.heldItem?.name || null, executionMs: performance.now() - executionStarted,
      ignoredHeads: [...ignore],
      shieldRequested: desired === 'shield',
      controls: Object.fromEntries(['forward', 'back', 'left', 'right', 'sprint', 'jump', 'sneak']
        .map(k => [k, bot.getControlState(k)])), held: bot.quickBarSlot,
      using: useNow?.kind || null, offhand: bot.inventory.slots[45]?.name || null,
      rangedResult, attackSuppressedReason }
  } finally { client.write = write }
}
module.exports = { executeCommand }
