const fs = require('node:fs')

const TYPES = new Set(['start', 'opening_release', 'damage', 'shield_disable', 'arrow_launch', 'end'])

/** Read only events written after this controller starts. The judge remains the source of truth. */
class NativeEventStream {
  constructor (file) {
    this.file = file
    this.offset = fs.existsSync(file) ? fs.statSync(file).size : 0
    this.partial = ''
    this.sequence = 0
    this.bouts = new Map()
  }

  poll () {
    if (!fs.existsSync(this.file)) return
    const size = fs.statSync(this.file).size
    if (size < this.offset) { this.offset = 0; this.partial = ''; this.bouts.clear() }
    if (size === this.offset) return
    const fd = fs.openSync(this.file, 'r')
    try {
      while (this.offset < size) {
        const buffer = Buffer.allocUnsafe(Math.min(65536, size - this.offset))
        const count = fs.readSync(fd, buffer, 0, buffer.length, this.offset)
        if (!count) break
        this.offset += count
        const lines = (this.partial + buffer.toString('utf8', 0, count)).split(/\r?\n/)
        this.partial = lines.pop()
        for (const line of lines) {
          let row
          try { row = JSON.parse(line) } catch { continue }
          if (!TYPES.has(row.type) || !Number.isInteger(row.arena) || !Number.isInteger(row.bout)) continue
          const key = `${row.arena}:${row.bout}`
          if (row.type === 'start') this.bouts.set(key, [])
          const events = this.bouts.get(key)
          if (events) events.push({ ...row, sequence: ++this.sequence })
        }
      }
    } finally { fs.closeSync(fd) }
  }

  take (arena, bout) {
    return this.takeRecord(arena, bout)?.summary || null
  }

  takeRecord (arena, bout) {
    this.poll()
    const key = `${arena}:${bout}`
    const events = this.bouts.get(key) || []
    if (!events.length || events.at(-1).type !== 'end') return null
    this.bouts.delete(key)
    return { summary: summarizeNativeBout(events), events }
  }
}

function summarizeNativeBout (events) {
  if (!events.length) return null
  const damage = events.filter(e => e.type === 'damage' && !e.cancelled)
  const melee = damage.filter(e => e.source === 'MELEE')
  const hits = melee.filter(e => e.amount > 0)
  const arrows = damage.filter(e => e.source === 'ARROW' && e.amount > 0)
  const breaks = events.filter(e => e.type === 'shield_disable' && !e.cancelled)
  const blocks = melee.filter(e => e.victim_blocking && e.shield_modifier < 0)
  const follows = breaks.filter(e => hits.some(h => h.attacker === e.attacker && h.victim === e.victim
    && h.tick > e.tick && h.tick <= e.tick + 100))
  const counters = blocks.filter(e => hits.some(h => h.attacker === e.victim && h.victim === e.attacker
    && h.tick > e.tick && h.tick <= e.tick + 40))
  const counterArrows = blocks.filter(e => arrows.some(h => h.attacker === e.victim && h.victim === e.attacker
    && h.tick > e.tick && h.tick <= e.tick + 100))
  const candidates = hits.filter(e => e.attacker_fall_distance > 0 && !e.attacker_on_ground
    && !e.attacker_sprinting && e.native_attack_charge > .9)
  const confirmedCriticals = hits.filter(e => e.native_critical === true)
  const swordHits = hits.filter(e => e.weapon === 'DIAMOND_SWORD')
  const axeHits = hits.filter(e => e.weapon === 'DIAMOND_AXE')
  const swordCriticalCandidates = candidates.filter(e => e.weapon === 'DIAMOND_SWORD')
  const swordCriticalPairs = swordCriticalCandidates.filter(e => swordCriticalCandidates.some(previous =>
    previous !== e && previous.attacker === e.attacker && previous.victim === e.victim
    && previous.tick < e.tick && e.tick - previous.tick <= 40))
  const salient = events.filter(e => e.type === 'start' || e.type === 'end' || e.type === 'shield_disable'
    || e.type === 'arrow_launch' || (e.type === 'damage' && (e.source === 'ARROW'
      || e.victim_blocking || e.attacker_fall_distance > 0)))
  // Keep chronological endpoints and evenly spaced native evidence in a bounded Qwen prompt.
  const selected = salient.length <= 6 ? salient : [salient[0], ...Array.from({ length: 4 }, (_, i) =>
    salient[Math.floor((i + 1) * (salient.length - 1) / 5)]), salient.at(-1)]
  return {
    observed: true,
    meleeHits: hits.length,
    blockedMelee: blocks.length,
    shieldBreaks: breaks.length,
    breakFollowupHits: follows.length,
    shieldCounterHits: counters.length,
    blockThenArrowHits: counterArrows.length,
    arrowLaunches: events.filter(e => e.type === 'arrow_launch').length,
    arrowHits: arrows.length,
    plausibleCriticalHits: candidates.length,
    nativeCriticalHits: confirmedCriticals.length,
    swordHits: swordHits.length,
    axeHits: axeHits.length,
    swordCriticalCandidates: swordCriticalCandidates.length,
    swordCriticalPairs: swordCriticalPairs.length,
    chargedMeleeHits: hits.filter(e => e.native_attack_charge >= .85).length,
    lightMeleeHits: hits.filter(e => e.native_attack_charge < .85).length,
    // A shield counter followed by an arrow does not establish that the bot escaped.
    // A launched arrow that misses does not establish a successful side dodge.
    trace: selected.map(e => [e.at, e.sequence, e.arena, e.bout, e.type,
      e.attacker || e.shooter || '', e.victim || '',
      e.type === 'damage' ? e.source : e.type === 'arrow_launch' ? e.held : '',
      e.type === 'damage' ? Math.round(100 * e.amount) / 100 : ''])
  }
}

function mergeTimeline (memory, bouts, nativeEvents) {
  return [
    ...memory.map(row => ({ at: row.at, kind: 'memory', source: row.source, text: row.text })),
    ...nativeEvents,
    ...bouts.map(row => ({ at: row[0], kind: 'bout_end', bout: row }))
  ].sort((a, b) => a.at.localeCompare(b.at)
    || (a.kind === 'native_event' ? 0 : 1) - (b.kind === 'native_event' ? 0 : 1)
    || (a.sequence || 0) - (b.sequence || 0))
}

module.exports = { NativeEventStream, summarizeNativeBout, mergeTimeline }
