'use strict'
const mechanical=require('./protocol-pilot-mechanical-brain')
const pure=require('./protocol-pure-brain')
function refreshNeuralPlan(planned,o,action){
  if(immediate(planned))return planned
  const next=pure.plan(null,o,action),c=next.command
  c.blockedModelHeads=[...(c.shield||c.use||c.release?[4]:[]),
    ...(c.slot!=null&&![0,7].includes(c.slot)?[5]:[])]
  c.slot=[0,7].includes(c.slot)?c.slot:o.held
  c.shield=c.use=c.release=false;c.offhand='shield';c.ranged=null
  next.owners.shield=next.owners.offhand='mechanical'
  return next
}
function immediate(p){return p.mode!=='NEURAL'||Boolean(p.command.ranged)
  ||['mechanical-arrow','mechanical-airborne-guard'].includes(p.owners.movement)}
module.exports={...mechanical,createState:(opponent,fighter='Punengbho')=>mechanical.createState(opponent,fighter),
  refreshNeuralPlan,immediate}
