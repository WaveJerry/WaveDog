const assert = require('node:assert/strict')
const { bowSpeed, plannedBowDrawMs, flightHeight, solvePitch, leadTarget } = require('./ballistic-aim')

assert.ok(bowSpeed(1000) >= 2.99)
assert.ok(bowSpeed(400) < 1.1)
assert.equal(plannedBowDrawMs(24), 1000)
assert.equal(plannedBowDrawMs(3), 200)
for (const [range, dy, speed] of [[8,-.2,3],[16,-.2,3],[24,-.2,3],[20,-.2,3.15]]) {
  const pitch = solvePitch(range,dy,speed)
  const actual = flightHeight(range,speed,pitch)
  assert.ok(Math.abs(actual-dy)<.15, `ballistic solution missed range ${range}: ${actual}`)
  assert.ok(actual > flightHeight(range,speed,Math.atan2(dy,range))+.05,
    `no meaningful drop compensation at range ${range}`)
}
const led = leadTarget({x:0,y:0,z:0},{x:0,y:1,z:20},{x:.2,y:0,z:0},3)
assert.ok(led.x > 0 && led.x < 2.5)
const airborne = leadTarget({x:0,y:222,z:0},{x:0,y:224,z:12},
  {x:0,y:.25,z:0},3,{airborne:true,floorY:222.3})
assert.ok(airborne.y < 224.5 && airborne.y >= 222.3)
const landing = leadTarget({x:0,y:222.62,z:0},{x:0,y:223.3,z:18},
  {x:.2,y:-.4,z:0},3,{airborne:true,floorY:222.26})
assert.equal(landing.y,222.26,'descending lead stops at the public landing surface')
assert.equal(leadTarget({x:0,y:222,z:0},{x:0,y:224,z:12},
  {x:0,y:.25,z:0},3).y,224)
console.log('ballistic aim OK')
