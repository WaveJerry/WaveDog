'use strict'
const assert=require('node:assert/strict')
const {loadingReplyWindow}=require('./protocol-pilot-load-reply')
const brain=require('./protocol-pilot-hybrid-brain')
const args={eye:{x:0,y:1.52,z:0},feet:{x:0,y:0,z:-3},motion:{x:0,y:0,z:0},grounded:true,floorY:0,clearPath:()=>true}
assert(loadingReplyWindow(args).eligible)
assert(!loadingReplyWindow({...args,feet:{x:0,y:0,z:-8}}).eligible)
assert(!loadingReplyWindow({...args,clearPath:()=>false}).eligible)
assert(!loadingReplyWindow({...args,shieldRaised:true}).eligible)
assert(!loadingReplyWindow({...args,grounded:undefined}).eligible)
assert.equal(loadingReplyWindow(args).guaranteedHit,false)
const state=()=>{const s=brain.createState('target','Punengbho');s.mode='NEURAL';s.shieldUntil=100;return s}
const obs=(extra={})=>({tick:10,held:0,ground:true,visible:true,health:20,charge:1,distance:3,reach:2.7,
  shieldReady:false,loaded:true,arrows:10,targetLoading:true,targetLoadCycle:1,
  loadingReplyWindow:{eligible:true},targetShieldFacing:false,targetShieldRaised:false,...extra})
let s=state(),p=brain.plan(s,obs(),null)
assert.equal(p.command.ranged,'fire-crossbow');assert.equal(p.command.rangedReason,'loading-reply-first')
brain.rangedApplied(s,p.command,{fireSent:true},10)
p=brain.plan(s,obs({tick:11}),null)
assert(!p.command.ranged,'late charged inventory must not repeat the first bolt')
p=brain.plan(s,obs({tick:12,loaded:false}),null)
assert.equal(p.command.ranged,'load-crossbow','confirmed spent bolt resumes the visible ongoing load without arbitrary delay')
s=state();p=brain.plan(s,obs(),null)
p=brain.plan(s,obs({tick:11,targetShieldRaised:true}),null)
assert(!p.command.ranged,'a delayed hand swap cannot fire after the opponent starts raising a shield')
for(const extra of [{targetLoading:false},{targetLoadCycle:0},{targetShieldRaised:true},
 {visible:false},{arrowThreat:{time:1,side:-1}}])
 assert.notEqual(brain.plan(state(),obs(extra),null).command.ranged,'fire-crossbow')
// Consuming a load cycle is independent of a later real shot event.
s=state();p=brain.plan(s,obs(),null);brain.rangedApplied(s,p.command,{fireSent:true},10)
brain.plan(s,obs({tick:12,loaded:false}),null)
p=brain.plan(s,obs({tick:13,loaded:true,targetLoading:false,targetKnownLoaded:true}),null)
brain.rangedApplied(s,p.command,{loadReleased:true},13)
brain.plan(s,obs({tick:14,loaded:true,targetLoading:false,targetKnownLoaded:true}),null)
p=brain.plan(s,obs({tick:30,targetLoading:false,targetShotEvent:1,targetShotTick:30}),null)
assert.equal(p.command.ranged,'fire-crossbow','normal actual-shot synchronization remains available')
// A real spent-bolt acknowledgement permits reload even after the opponent
// has finished/cancelled their own load. There is no 15-tick artificial pause.
s=state();p=brain.plan(s,obs(),null);brain.rangedApplied(s,p.command,{fireSent:true},10)
p=brain.plan(s,obs({tick:11,loaded:false,targetLoading:false,targetKnownLoaded:false}),null)
assert.equal(p.command.ranged,'load-crossbow')
assert.equal(p.command.rangedReason,'loading-reply-reload')
brain.rangedApplied(s,p.command,{useStarted:true},11)
for(let tick=12;tick<37;tick++){
 p=brain.plan(s,obs({tick,loaded:false,targetLoading:false,targetKnownLoaded:false}),null)
 assert.equal(p.command.ranged,'load-crossbow','keep our actual load continuous')
}
brain.rangedApplied(s,p.command,{loadReleased:true},36)
p=brain.plan(s,obs({tick:37,loaded:false,targetLoading:false}),null)
assert(!p.command.ranged,'release timing alone is not a loaded-bolt acknowledgement')
p=brain.plan(s,obs({tick:38,loaded:true,targetLoading:false}),null)
assert.equal(p.command.ranged,'fire-crossbow','unshielded opponent is punished on confirmed load completion')
assert.equal(p.command.rangedReason,'loading-reply-followup')
brain.rangedApplied(s,p.command,{fireSent:true},38)
for(let tick=39;tick<80;tick++){
 p=brain.plan(s,obs({tick,loaded:true,targetLoading:false}),null)
 assert(!p.command.ranged,'stale charged equipment cannot repeat the follow-up')
}
assert.equal(s.loadingReply,null)
for(const shield of ['targetShieldRaised','targetShieldFacing']){
 s=state();p=brain.plan(s,obs(),null);brain.rangedApplied(s,p.command,{fireSent:true},10)
 p=brain.plan(s,obs({tick:11,loaded:false}),null)
 brain.rangedApplied(s,p.command,{loadReleased:true},36)
 p=brain.plan(s,obs({tick:37,loaded:true,targetLoading:false,[shield]:true}),null)
 assert(!p.command.ranged,'shield raising cancels the extra shot, including warm-up')
 p=brain.plan(s,obs({tick:60,loaded:true,targetLoading:false}),null)
 assert(!p.command.ranged,'cancelled opportunity cannot fire later when the shield drops')
}
s=state();p=brain.plan(s,obs(),null);brain.rangedApplied(s,p.command,{fireSent:true},10)
p=brain.plan(s,obs({tick:11,loaded:false,arrows:0,targetLoading:false}),null)
assert(!p.command.ranged,'an empty quiver cannot begin the promised reload')
s=state();p=brain.plan(s,obs(),null);brain.rangedApplied(s,p.command,{fireSent:true},10)
p=brain.plan(s,obs({tick:11,loaded:false,targetLoading:false,arrowThreat:{time:1,side:-1}}),null)
assert(!p.command.ranged);assert.equal(s.loadingReply,null,'emergency preemption cancels the sequence')
console.log('LOADING_REPLY_SHOOT_RELOAD_CONFIRMED_UNSHIELDED_FOLLOWUP_PASS')
