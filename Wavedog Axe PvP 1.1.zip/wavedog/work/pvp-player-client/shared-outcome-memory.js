const fs = require('node:fs')

function brief (report) {
  const fighters = report.fighters
    ? Object.entries(report.fighters).map(([name, row]) =>
      `${name}:${row.style || '?'}:${row.focus || '?'}`).join('/')
    : `${report.bot || '?'}:${report.style || '?'}:${report.focus || '?'} vs ${report.opponent || '?'}`
  const native = report.native
    ? `原生命中${report.native.meleeHits ?? '?'}破盾${report.native.shieldBreaks ?? '?'}发箭${report.native.arrowLaunches ?? '?'}箭伤${report.native.arrowHits ?? '?'}`
    : '原生结果待归属'
  return `${report.matchId || `${report.arena}:${report.bout}`} ${fighters} 胜者${report.winner || '无'} ${report.reason || ''} ${native}`
}

class SharedOutcomeMemory {
  constructor (files, limit = 16) {
    this.limit = limit
    this.rows = files.flatMap(file => fs.existsSync(file)
      ? fs.readFileSync(file, 'utf8').split(/\r?\n/).flatMap(line => {
        try { return [JSON.parse(line)] } catch { return [] }
      }).slice(-limit) : [])
      .sort((a,b) => String(a.at).localeCompare(String(b.at))).slice(-limit)
  }
  add (report) {
    this.rows.push(report)
    this.rows.sort((a,b) => String(a.at).localeCompare(String(b.at)))
    this.rows = this.rows.slice(-this.limit)
  }
  latest (count = 2) {
    return this.rows.slice(-count).map(report => ({
      at: report.at, source: 'completed-bout-fact-not-Qwen-conclusion',
      text: brief(report) }))
  }
}

module.exports = { SharedOutcomeMemory, brief }
