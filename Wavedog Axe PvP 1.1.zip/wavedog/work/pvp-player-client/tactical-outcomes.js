const { analyzeCriticalTactics } = require('./critical-tactics')
const { analyzeDamageTempo } = require('./damage-tempo')
const { analyzeExchanges } = require('./exchange-outcomes')

function nearestFrame (frames, at, toleranceMs = 150) {
  const target = Date.parse(at)
  let best = null, gap = Infinity
  for (const frame of frames) {
    const delta = Math.abs(Date.parse(frame.at)-target)
    if (delta < gap) { best = frame; gap = delta }
  }
  return gap <= toleranceMs ? best : null
}

function distance (frame) {
  // Horizontal separation is the relevant measure for leaving melee range.
  // Jump height alone must never be counted as a successful escape.
  return Math.hypot(frame.self.x-frame.seen.x, frame.self.z-frame.seen.z)
}

function analyzeTactics (fighter, opponent, events, frames, actions = []) {
  const valid = events.filter(e => !e.cancelled)
  const hits = valid.filter(e => e.type === 'damage' && e.amount > 0)
  const arrows = valid.filter(e => e.type === 'arrow_launch' && e.shooter === fighter)
  const blocks = valid.filter(e => e.type === 'damage' && e.source === 'MELEE'
    && e.victim === fighter && e.attacker === opponent && e.victim_blocking
    && e.shield_modifier < 0)
  let counterHits = 0, counterEscapes = 0, counterPunished = 0
  let counterProgress = 0
  let edgeCounterHits = 0, edgeCounterEscapes = 0, counterEscapeArrows = 0
  const counterOutcomes = [], counted = new Set()
  for (const block of blocks) {
    const counter = hits.find(e => e.source === 'MELEE' && e.attacker === fighter
      && e.victim === opponent && e.tick > block.tick && e.tick <= block.tick+40)
    if (!counter) continue
    if (counted.has(counter.sequence)) continue
    counted.add(counter.sequence)
    counterHits++
    const blockFrame = nearestFrame(frames, block.at)
    const edgeBlock = blockFrame && distance(blockFrame) >= 2.8
      && distance(blockFrame) <= 3.35
    const before = nearestFrame(frames, counter.at)
    if (!before || distance(before) > 3.1) continue
    const punishedEvent = hits.find(e => e.attacker === opponent && e.victim === fighter
      && e.tick > counter.tick && e.tick <= counter.tick+40)
    const counterAt = Date.parse(counter.at)
    const punishAt = punishedEvent ? Date.parse(punishedEvent.at) : Infinity
    const progress = frames.find(frame => Date.parse(frame.at) > counterAt
      && Date.parse(frame.at)-counterAt <= 1500
      && Date.parse(frame.at) < punishAt
      && distance(frame) >= Math.max(3.2, distance(before)+.4))
    if (progress) counterProgress++
    const out = frames.find(frame => Date.parse(frame.at) > Date.parse(counter.at)
      && Date.parse(frame.at)-Date.parse(counter.at) <= 2000 && distance(frame) >= 3.6)
    const punished = Boolean(punishedEvent)
    if (out && !punished) counterEscapes++
    if (punished) counterPunished++
    if (edgeBlock) edgeCounterHits++
    if (edgeBlock && out && !punished) edgeCounterEscapes++
    const arrow = out && !punished && arrows.find(e => Date.parse(e.at) > Date.parse(out.at)
      && Date.parse(e.at)-Date.parse(out.at) <= 4000
      && nearestFrame(frames, e.at) && distance(nearestFrame(frames, e.at)) >= 3.6)
    if (arrow) counterEscapeArrows++
    counterOutcomes.push({ at: counter.at, blockAt: block.at,
      escaped: Boolean(out && !punished), punished,
      edgeBlock: Boolean(edgeBlock), progressAt: progress?.at || null,
      outAt: out?.at || null, punishAt: punishedEvent?.at || null,
      arrowAt: arrow?.at || null })
  }
  const opponentArrows = valid.filter(e => e.type === 'arrow_launch' && e.shooter === opponent)
  const rangedExchange = arrows.some(e => opponentArrows.some(o =>
    Math.abs(Date.parse(o.at)-Date.parse(e.at)) <= 4000)) ? 1 : 0
  const arrowHits = hits.filter(e => e.source === 'ARROW' && e.attacker === fighter)
  const ownMelee = hits.filter(e => e.source === 'MELEE' && e.attacker === fighter
    && e.victim === opponent)
  let edgeHits = 0, safeEdgeHits = 0, sprintEdgeHits = 0,
    sprintEdgeSafeHits = 0, safeHitExits = 0
  let opponentEdgeHits = 0, opponentSafeEdgeHits = 0
  let postExitArrows = 0, fastPostExitArrows = 0, postExitReentryHits = 0
  const spacingOutcomes = []
  let edgeBlockedAttacks = 0, edgeCounterPunished = 0
  for (const block of valid.filter(e => e.type === 'damage' && e.source === 'MELEE'
    && e.attacker === fighter && e.victim === opponent && e.victim_blocking
    && e.shield_modifier < 0)) {
    const frame = nearestFrame(frames, block.at)
    if (!frame || distance(frame) < 2.8 || distance(frame) > 3.35) continue
    const shieldDisabled = valid.some(e => e.type === 'shield_disable'
      && e.attacker === fighter && e.victim === opponent
      && Math.abs(e.tick-block.tick) <= 1)
    if (shieldDisabled) continue
    edgeBlockedAttacks++
    const punished = hits.some(e => e.attacker === opponent && e.victim === fighter
      && e.tick > block.tick && e.tick <= block.tick+40)
    if (punished) {
      edgeCounterPunished++
      spacingOutcomes.push({ at: block.at, kind: 'edge-shield-countered', reward: -.06 })
    }
  }
  let lastExitAt = -Infinity
  let legalEdgeHits=0, nearLimitHits=0, advancingEdgeHits=0, retreatingEdgeHits=0, retreatEdgeBreaks=0
  for (const hit of ownMelee) {
    const frame = nearestFrame(frames, hit.at)
    if (!frame) continue
    const range = distance(frame)
    const answered = hits.some(e => e.attacker === opponent && e.victim === fighter
      && e.tick >= hit.tick && e.tick <= hit.tick+20)
    const attack = [...actions].reverse().find(row => row.executed?.attackPackets > 0
      && Date.parse(row.at) <= Date.parse(hit.at)
      && Date.parse(hit.at) - Date.parse(row.at) <= 150)
    const attackReach=attack?.executed?.attackReach
    const legalEdge=Number.isFinite(attackReach)&&attackReach>=2.7&&attackReach<=3
    if(legalEdge){
      legalEdgeHits++
      if(attackReach>=2.999)nearLimitHits++
      const radial=attack.executed.attackRadialVelocity
      if(Number.isFinite(radial)&&radial>.03)advancingEdgeHits++
      if(Number.isFinite(radial)&&radial<-.03){
        retreatingEdgeHits++
        const wasHit=hits.some(e=>e.attacker===opponent&&e.victim===fighter
          &&e.tick<hit.tick&&e.tick>=hit.tick-20)
        if(wasHit&&!answered){
          retreatEdgeBreaks++
          spacingOutcomes.push({at:hit.at,kind:'retreat-edge-break',reward:.025,
            verifiedAttackReach:attackReach,decidedFrame:attack.decidedFrame})
        }
      }
    }
    if (legalEdge || range >= 2.8 && range <= 3.35) {
      edgeHits++
      if (hit.attacker_sprinting === true) {
        sprintEdgeHits++
        if (!answered) sprintEdgeSafeHits++
      }
      if (!answered) {
        safeEdgeHits++
        // Only the real executed attack receipt can unlock the larger edge
        // bonus. A nearby/future sampled position is insufficient evidence.
        spacingOutcomes.push({ at: hit.at, kind: 'safe-edge-hit', reward: .02,
          verifiedAttackDistance: attack?.executed?.attackDistance,
          verifiedAttackReach: attackReach,decidedFrame:attack?.decidedFrame })
      }
    }
    if (range > 3.2 || Date.parse(hit.at)-lastExitAt < 2000) continue
    const out = frames.find(row => Date.parse(row.at) > Date.parse(hit.at)
      && Date.parse(row.at)-Date.parse(hit.at) <= 1500 && distance(row) >= 3.6)
    if (!out) continue
    lastExitAt = Date.parse(out.at)
    const punishedDuringExit = hits.some(e => e.attacker === opponent && e.victim === fighter
      && e.tick > hit.tick && e.tick <= hit.tick+40)
    if (punishedDuringExit) continue
    safeHitExits++
    spacingOutcomes.push({ at: out.at, kind: 'safe-hit-exit', reward: .04 })
    const after = Date.parse(out.at)
    const postExitArrow = arrows.find(e => Date.parse(e.at) > after
      && Date.parse(e.at) <= after+4000
      && nearestFrame(frames, e.at) && distance(nearestFrame(frames, e.at)) >= 3.6)
    if (postExitArrow) {
      postExitArrows++
      const fast = Date.parse(postExitArrow.at)-after <= 1000
      if (fast) fastPostExitArrows++
      spacingOutcomes.push({ at: postExitArrow.at, kind: fast ? 'fast-post-exit-arrow'
        : 'post-exit-arrow', reward: fast ? .05 : .025 })
    }
    const reentry = ownMelee.find(e => Date.parse(e.at) > after
      && Date.parse(e.at) <= after+4000)
    if (reentry) {
      postExitReentryHits++
      spacingOutcomes.push({ at: reentry.at, kind: 'post-exit-reentry-hit', reward: .025 })
    }
  }
  for (const hit of hits.filter(e => e.source === 'MELEE'
      && e.attacker === opponent && e.victim === fighter)) {
    const frame = nearestFrame(frames, hit.at)
    if (!frame || distance(frame) < 2.8 || distance(frame) > 3.35) continue
    opponentEdgeHits++
    const answered = ownMelee.some(e => e.tick > hit.tick && e.tick <= hit.tick+20)
    if (!answered) {
      opponentSafeEdgeHits++
      spacingOutcomes.push({ at: hit.at, kind: 'opponent-safe-edge-hit', reward: -.03 })
    }
  }
  let rangedPunished = 0, landingThreatHits = 0
  for (const event of hits.filter(e => e.attacker === opponent && e.victim === fighter)) {
    const frame = nearestFrame(frames, event.at)
    if (frame && [1,4].includes(frame.self.activeUseSlot)) rangedPunished++
    if (frame && frame.seen.y > frame.self.y+.25 && frame.seen.vy < -.05)
      landingThreatHits++
  }
  return { blockedMelee: blocks.length, counterHits, counterProgress, counterEscapes,
    counterPunished, edgeCounterHits, edgeCounterEscapes, counterEscapeArrows,
    edgeBlockedAttacks, edgeCounterPunished, rangedExchange,
    arrowLaunches: arrows.length, arrowHits: arrowHits.length,
    rangedPunished, landingThreatHits, counterOutcomes,
    edgeHits, safeEdgeHits, opponentEdgeHits, opponentSafeEdgeHits,
    legalEdgeHits,nearLimitHits,advancingEdgeHits,retreatingEdgeHits,retreatEdgeBreaks,
    sprintEdgeHits, sprintEdgeSafeHits,
    safeHitExits, postExitArrows, fastPostExitArrows,
    postExitReentryHits,
    spacingOutcomes, ...analyzeCriticalTactics(fighter, opponent, events, frames),
    ...analyzeDamageTempo(fighter, opponent, events, actions, frames),
    ...analyzeExchanges(fighter, opponent, events) }
}

module.exports = { analyzeTactics }
