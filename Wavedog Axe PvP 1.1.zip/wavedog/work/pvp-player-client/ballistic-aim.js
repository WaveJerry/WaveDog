// Minecraft 1.21.1 arrow flight approximation, in blocks per game tick.
const DRAG = .99
const GRAVITY = .05

function bowSpeed (drawMs) {
  const heldTicks = Math.max(0, Number(drawMs) / 50)
  const fraction = Math.min(1, (Math.pow(heldTicks / 20, 2) + 2 * heldTicks / 20) / 3)
  return 3 * fraction
}

function plannedBowDrawMs (range) {
  return range > 12 ? 1000 : range > 7 ? 700 : range > 4 ? 400 : 200
}

function flightHeight (horizontal, speed, pitch) {
  let x = 0, y = 0, vx = speed * Math.cos(pitch), vy = speed * Math.sin(pitch)
  for (let tick = 0; tick < 80; tick++) {
    const oldX = x, oldY = y
    x += vx; y += vy
    if (x >= horizontal) {
      const fraction = (horizontal - oldX) / Math.max(1e-9, x - oldX)
      return oldY + fraction * (y - oldY)
    }
    vx *= DRAG
    vy = vy * DRAG - GRAVITY
  }
  return null
}

function solvePitch (horizontal, vertical, speed) {
  if (!Number.isFinite(horizontal) || !Number.isFinite(vertical) || !Number.isFinite(speed)
      || horizontal <= 0 || speed <= .05) return Math.atan2(vertical, Math.max(.01, horizontal))
  let best = 0, error = Infinity
  // The lower trajectory is preferable when two angles reach the same point.
  for (let degree = -15; degree <= 65; degree += .5) {
    const pitch = degree * Math.PI / 180
    const y = flightHeight(horizontal, speed, pitch)
    if (y === null) continue
    const score = Math.abs(y - vertical) + Math.max(0, degree - 35) * .001
    if (score < error) { best = pitch; error = score }
  }
  return best
}

function leadTarget (source, target, velocity, speed, options = {}) {
  const dx = target.x - source.x, dz = target.z - source.z
  const range = Math.hypot(dx, dz)
  const ticks = Math.min(15, range / Math.max(.5, speed))
  const vx = Math.max(-.3, Math.min(.3, Number(velocity?.x) || 0))
  const vz = Math.max(-.3, Math.min(.3, Number(velocity?.z) || 0))
  const vy = Math.max(-.9, Math.min(.9, Number(velocity?.y) || 0))
  const airborneY = target.y + vy * ticks - .04 * ticks * (ticks + 1)
  const y = options.airborne
    ? Math.max(Number.isFinite(options.floorY) ? options.floorY : -Infinity, airborneY)
    : target.y
  return { x: target.x + Math.max(-2.5, Math.min(2.5, vx * ticks * .65)),
    y, z: target.z + Math.max(-2.5, Math.min(2.5, vz * ticks * .65)) }
}

module.exports = { bowSpeed, plannedBowDrawMs, flightHeight, solvePitch, leadTarget }
