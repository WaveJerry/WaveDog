'use strict'
const assert=require('node:assert/strict')
const {executeCommand}=require('./protocol-pure-executor')
const {plan,createState}=require('./protocol-pure-brain')
function fixture(extra={}){
  const wire=[],controls={};let use=null
  const bot={quickBarSlot:0,food:20,inventory:{slots:[]},
    entity:{position:{x:0,y:0,z:0},yaw:0,pitch:0,eyeHeight:1.62},
    get heldItem(){return {name:this.quickBarSlot===0?'diamond_sword':'diamond_axe'}},
    _client:{write:(name,data)=>wire.push({name,data})},
    setControlState(k,v){controls[k]=v},getControlState:k=>Boolean(controls[k]),
    setQuickBarSlot(slot){this.quickBarSlot=slot;this._client.write('held_item_slot',{slot})},
    attack(){this._client.write('use_entity',{})},activateItem(){this._client.write('use_item',{})}}
  const c={decidedTick:9,slot:0,forward:1,side:0,sprint:true,attack:true,
    shield:false,use:false,release:false,yaw:180,pitch:0,...extra}
  const ctx={bot,wire,tick:10,weaponEpoch:1,lastAttackTick:-1000,shieldUntil:0,
    session:{id:'pure-test',opponent:'target',state:{nextId:1},attackedDecisions:new Set(),attackOwners:new Map()},
    planned:plan(createState(),{tick:10},c),
    target:{position:{x:0,y:0,z:-2.8},width:.6,height:1.8},
    frame:{seen:{visible:true},observation:{reach:2.5}},
    getUse:()=>use,setUse:v=>{use=v},
    stopUse(){if(use)bot._client.write('block_dig',{status:5});use=null},
    offhand:()=>true,ownLoaded:()=>false,clearPath:()=>true,
    getSentPosition:()=>({...bot.entity.position}),
    plugin:row=>bot._client.write('custom_payload',row),
    onSwitch(){ctx.weaponEpoch++},onAttack(){ctx.lastAttackTick=ctx.tick},
    look(yaw,pitch){bot.entity.yaw=yaw;bot.entity.pitch=pitch;bot._client.write('look',{yaw,pitch})},
    aim(){ctx.look(0,0)}}
  return ctx
}
let x=fixture({observedWeaponEpoch:0,slot:7}),r=executeCommand(x)
assert.equal(x.bot.quickBarSlot,0)
assert.equal(r.attacked,false)
assert(r.controls.forward&&r.controls.sprint)
assert(r.ignoredHeads.includes(4)&&r.ignoredHeads.includes(5))
assert(!r.ignoredHeads.includes(0))
x.planned.command.observedWeaponEpoch=1
r=executeCommand(x)
assert(r.attacked)
assert.equal(r.attackHeld,7)
assert.equal(r.attackItemName,'diamond_axe')
assert.equal(r.executedAttackId,1)
assert.equal(x.session.attackOwners.get(1).decidedTick,9)
assert(!executeCommand(x).attacked)
assert.equal(x.wire.filter(p=>p.name==='use_entity').length,1)
// Cancelling the learned shield really releases it before movement.
x=fixture({attack:false,shield:false});x.setUse({kind:'shield',tick:5})
r=executeCommand(x)
assert(x.wire.some(p=>p.name==='block_dig'))
assert.equal(x.getUse(),null)
assert(r.controls.sprint)
// Learned item use is sustained until the model releases or cancels it.
x=fixture({attack:false,use:true,slot:4});x.setUse({kind:'crossbow',tick:5})
r=executeCommand(x)
assert.equal(x.getUse().kind,'crossbow')
assert(!x.wire.some(p=>p.name==='block_dig'))
x.planned.command.release=true
executeCommand(x)
assert.equal(x.getUse(),null)
// No automatic hit, slot choice, jump or sprint cancellation is introduced.
x=fixture({attack:false,slot:0});r=executeCommand(x)
assert(!r.attacked);assert.equal(x.bot.quickBarSlot,0)
x=fixture({attack:true,sprint:true});x.bot.entity.onGround=false
r=executeCommand(x);assert(r.attacked&&r.controls.sprint,'pure model retains responsibility for critical sprint timing')
assert(!r.ignoredHeads.includes(8),'PPO observes both restoration choices, not only positive examples')
x=fixture({attack:true,slot:4});r=executeCommand(x)
assert(r.attacked&&r.ignoredHeads.includes(5),'unused offhand slot is not credited as a main-hand switch')
// A learned turn-back attack restores the exact view and emits just one hit.
x=fixture({attack:true,flightLook:true,yaw:0,pitch:10})
r=executeCommand(x)
assert(r.attacked);assert.equal(x.bot.entity.yaw,Math.PI)
assert.equal(x.bot.entity.pitch,-10*Math.PI/180)
x=fixture({attack:true});x.target.position.z=-3.5
r=executeCommand(x);assert(!r.attacked)
assert.equal(r.rejected,'outside-range-or-aim')
console.log('PURE_EXECUTOR_PASS: stale weapon, actual attack receipts, shield release, ranged use, all-input ownership, turn-back, reach')
// A target-relative action must not become an old absolute aim when the
// opponent moves between the model request and ordinary packet execution.
x=fixture({pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0,yaw:180,pitch:0})
x.target.position.x=1.1;x.target.position.z=-2.5
r=executeCommand(x)
assert(r.attacked&&r.relativeViewRefreshed,'refresh the selected relative view on the latest public box')
assert.equal(x.wire.filter(p=>p.name==='use_entity').length,1)
x=fixture({pureAimVersion:2,aimYawOffset:180,aimPitchOffset:0})
r=executeCommand(x)
assert(!r.attacked&&r.relativeViewRefreshed,'a learned turn away remains a turn away')
x=fixture({pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0,attack:false})
r=executeCommand(x);assert(!r.attacked,'refreshing aim cannot invent a strike')
x=fixture({pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0})
x.target.position.z=-3.5
r=executeCommand(x);assert(!r.attacked,'view refresh cannot extend reach')
x=fixture({pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0,attack:false})
x.frame.seen.visible=false
r=executeCommand(x);assert(!r.relativeViewRefreshed,'unobserved target coordinates cannot refresh view')
console.log('RELATIVE_MODEL_VIEW_CURRENT_PUBLIC_STATE_PASS')
// Existing model primitives already separate running orientation and a
// deliberately selected momentary attack look. Verify real packet order,
// restoration, ground movement and reach; do not invent a movement controller.
for(const offset of [-180,-90,90,180]){
  x=fixture({pureAimVersion:2,aimYawOffset:offset,aimPitchOffset:0,
    forward:1,side:0,sprint:true,flightLook:true,attack:true})
  r=executeCommand(x)
  assert(r.attacked&&r.controls.forward&&r.controls.sprint)
  assert(!r.controls.back&&!r.controls.left&&!r.controls.right)
  const events=x.wire.filter(p=>['look','use_entity'].includes(p.name))
  assert.deepEqual(events.map(p=>p.name),['look','look','use_entity','look'])
  assert(Math.abs(events[0].data.yaw-events.at(-1).data.yaw)<1e-12,
    'turn-back strike restores the exact learned running heading')
  assert.equal(events[1].data.yaw,0,'attack view targets the current visible collision box')
  assert(!r.ignoredHeads.includes(8),'actual model-selected look/restore is credited')
}
x=fixture({pureAimVersion:2,aimYawOffset:180,aimPitchOffset:0,flightLook:true,attack:false})
r=executeCommand(x);assert(!r.attacked&&r.controls.sprint,'a movement look cannot invent an attack')
x=fixture({pureAimVersion:2,aimYawOffset:180,aimPitchOffset:0,flightLook:true,attack:true})
x.target.position.z=-3.5
r=executeCommand(x);assert(!r.attacked&&Math.abs(x.bot.entity.yaw+Math.PI)<1e-12,
  'turn-back does not extend reach and restores heading even on a rejected attack')
console.log('DIRECTIONAL_SPRINT_TURN_BACK_PACKET_ORDER_PASS')
// The next model command must re-establish its chosen sprint on the wire,
// since server attack handling clears it without changing Mineflayer's bit.
x=fixture({sprint:true,attack:true})
const originalControl=x.bot.setControlState.bind(x.bot)
x.bot.setControlState=(key,value)=>{
  const previous=x.bot.getControlState(key);originalControl(key,value)
  if(key==='sprint'&&previous!==value)x.bot._client.write('entity_action',{sprint:value})
}
r=executeCommand(x);assert(r.attacked&&x.session.sprintNeedsRearm)
x.tick=11;x.planned.command.decidedTick=11
const priorPackets=x.wire.length
r=executeCommand(x)
assert(r.attacked)
const nextWire=x.wire.slice(priorPackets)
assert.deepEqual(nextWire.filter(p=>p.name==='entity_action').map(p=>p.data.sprint),[false,true])
assert(nextWire.findIndex(p=>p.name==='entity_action'&&p.data.sprint)<nextWire.findIndex(p=>p.name==='use_entity'))
x.tick=12;x.planned.command.decidedTick=12;x.planned.command.sprint=false
const cut=x.wire.length
r=executeCommand(x)
assert(r.attacked&&!r.controls.sprint&&!x.session.sprintNeedsRearm)
assert(!x.wire.slice(cut).some(p=>p.name==='entity_action'&&p.data.sprint),
  'the model can release sprint for a critical without adapter interference')
console.log('MODEL_SELECTED_SPRINT_REARM_AFTER_ATTACK_PASS')
// Geometry is a copy of the execution-time public box, not a reinterpretation
// of the causal request snapshot or a reason to generate another attack.
x=fixture({pureAimVersion:2,aimYawOffset:0,aimPitchOffset:0})
x.frame.observation.reach=3.16
x.getSentPosition=()=>({x:0,y:0,z:0})
r=executeCommand(x)
assert(r.attacked&&r.attackGeometry.rayDistance<=3&&r.attackGeometry.wireRayDistance<=3)
assert.equal(r.attackGeometry.observedReach,3.16)
assert.equal(x.frame.observation.reach,3.16,'do not rewrite the training observation')
x.target.position.z=-8
assert.equal(r.attackGeometry.target.z,-2.8,'execution audit must not retain mutable entity references')
x=fixture({attack:false});r=executeCommand(x)
assert.equal(r.attackGeometry,null)
console.log('EXECUTION_TIME_PUBLIC_ATTACK_GEOMETRY_PASS')
x=fixture({attack:true});x.getSentPosition=()=>null
r=executeCommand(x);assert(!r.attacked);assert.equal(r.rejected,'unconfirmed-sent-position')
assert(r.controls.forward,'missing attack geometry must not stop the chosen movement')
x=fixture({attack:true});x.getSentPosition=()=>({x:0,y:0,z:1})
r=executeCommand(x);assert(!r.attacked);assert.equal(r.rejected,'outside-sent-range-or-aim')
assert(!x.wire.some(p=>p.name==='use_entity'),'local prediction cannot extend the sent-position reach')
x=fixture({attack:true});x.getSentPosition=()=>({x:0,y:0,z:0})
r=executeCommand(x);assert(r.attacked,'an acknowledged corrected position remains valid for legal attack')
console.log('ATTACK_REQUIRES_LOCAL_AND_ACKNOWLEDGED_POSITION_REACH_PASS')
