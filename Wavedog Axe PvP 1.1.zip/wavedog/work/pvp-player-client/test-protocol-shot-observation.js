'use strict'
const assert=require('node:assert/strict')
const {observeRanged,projectileShooterId}=require('./protocol-ranged-observation')
assert.equal(projectileShooterId(1655),1655,'real server player/arrow ID pair must match without subtracting one')
assert.equal(projectileShooterId(0),null)
const state={}, crossbow={name:'crossbow',loaded:false}
let o=observeRanged(state,{tick:10,visible:true,using:true,activeItem:crossbow,
  mainhand:crossbow},i=>Boolean(i?.loaded))
assert.equal(o.rangedEvent,1)
assert.equal(o.targetShotEvent,0,'starting a load is not an enemy shot')
o=observeRanged(state,{tick:11,visible:true,using:false,activeItem:crossbow,
  mainhand:{...crossbow,loaded:true}},i=>Boolean(i?.loaded))
assert(o.targetKnownLoaded)
assert.equal(o.targetShotEvent,0,'completed loading is not an enemy shot')
o=observeRanged(state,{tick:12,visible:true,using:false,fired:true,
  mainhand:crossbow},i=>Boolean(i?.loaded))
assert.equal(o.targetShotEvent,1)
assert.equal(o.targetShotTick,12)
o=observeRanged(state,{tick:13,visible:true,using:false,mainhand:crossbow},i=>Boolean(i?.loaded))
assert.equal(o.targetShotEvent,1,'one public projectile event remains one shot')
console.log('PUBLIC_LOADING_AND_SHOT_EVENTS_SEPARATE_PASS')
