'use strict'
const {Worker}=require('node:worker_threads')
// Full collision/trajectory search lives off the game event loop. One in-flight
// job plus one latest observation bounds work; superseded plans never execute.
function createRoutePlanner({onError=()=>{}}={}){
  const worker=new Worker(require.resolve('./protocol-legacy86-planner-worker'))
  let serial=0,active=null,latest=null,closed=false,failed=null,sentKey=null
  const stats={completed:0,superseded:0,maxComputeMs:0,maxRoundtripMs:0,maxPrepareMs:0,maxSubmitMs:0}
  function send(job){
    active=job;job.started=performance.now()
    const snapshot=job.probe.snapshot()
    stats.maxPrepareMs=Math.max(stats.maxPrepareMs,performance.now()-job.started)
    const frame={...job.frame,routeCache:undefined}
    const message={id:job.id,frame,snapshotKey:snapshot.key,origin:snapshot.origin,radius:snapshot.radius}
    if(sentKey!==snapshot.key){message.snapshot=snapshot;sentKey=snapshot.key}
    worker.postMessage(message)
    stats.maxSubmitMs=Math.max(stats.maxSubmitMs,performance.now()-job.started)
  }
  function fail(error){
    failed=error;active?.reject(error);latest?.reject(error);active=latest=null
    if(!closed)onError(error)
  }
  worker.on('error',fail)
  worker.on('exit',code=>{if(!closed)fail(Error('Planner worker exited: '+code))})
  worker.on('message',result=>{
    if(!active||result.id!==active.id)return
    const job=active;active=null
    stats.completed++;stats.maxComputeMs=Math.max(stats.maxComputeMs,result.computeMs||0)
    stats.maxRoundtripMs=Math.max(stats.maxRoundtripMs,performance.now()-job.started)
    if(result.error){const e=Error(result.error);job.reject(e);fail(e);return}
    job.resolve(result)
    if(latest){const next=latest;latest=null;send(next)}
  })
  return {
    evaluate(frame,probe){
      return new Promise((resolve,reject)=>{
        if(closed||failed){reject(failed||Error('Planner closed'));return}
        const job={id:++serial,frame,probe,resolve,reject}
        if(active){
          if(latest){stats.superseded++;latest.resolve({superseded:true})}
          latest=job
        }else send(job)
      })
    },
    get stats(){return {...stats,inFlight:Boolean(active),queued:Boolean(latest)}},
    async close(){closed=true;fail(Error('Planner closed'));await worker.terminate()}
  }
}
module.exports={createRoutePlanner}
