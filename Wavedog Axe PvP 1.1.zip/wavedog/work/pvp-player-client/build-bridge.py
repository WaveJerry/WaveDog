"""Compile the ordinary-player GRU bridge against the validated 1.21.1 runtime."""
from pathlib import Path
import os
import subprocess

base = Path(__file__).resolve().parent
server = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
sources = sorted((base / 'bridge-src/local/wavedog/lab').glob('*.java'))
classes = base / 'bridge-classes'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, [base.parent / 'pvp-neural-lab/classes',
    server / 'versions/1.21.1/paper-1.21.1.jar',
    server / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
subprocess.run([str(server / 'runtime/java21/bin/javac.exe'), '-proc:none',
    '-encoding', 'UTF-8', '--release', '21', '-cp', classpath,
    '-d', str(classes), *map(str, sources)], check=True)
print(f'Compiled {len(sources)} GRU bridge sources to {classes}')
