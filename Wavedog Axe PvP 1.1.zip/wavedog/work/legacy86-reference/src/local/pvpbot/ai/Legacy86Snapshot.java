package local.pvpbot.ai;

import java.io.*;
import java.lang.reflect.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import sun.misc.Unsafe;

/** Copy only decision state. Frozen TinyQNetwork weights are read-only in
 * predict(); copies must never train/save the reference. Random is copied too,
 * so a 500 Hz preview cannot consume future committed random choices. */
final class Legacy86Snapshot {
    static final Unsafe ALLOC;
    static final Map<Class<?>,List<Field>> FIELDS=new ConcurrentHashMap<>();
    static final Field RANDOM_SEED,RANDOM_GAUSSIAN,RANDOM_HAS_GAUSSIAN;
    static {try {Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);ALLOC=(Unsafe)f.get(null);}
        catch(Exception e){throw new ExceptionInInitializerError(e);}}
    static {try {
        RANDOM_SEED=Random.class.getDeclaredField("seed");RANDOM_SEED.setAccessible(true);
        RANDOM_GAUSSIAN=Random.class.getDeclaredField("nextNextGaussian");RANDOM_GAUSSIAN.setAccessible(true);
        RANDOM_HAS_GAUSSIAN=Random.class.getDeclaredField("haveNextNextGaussian");RANDOM_HAS_GAUSSIAN.setAccessible(true);
    }catch(Exception e){throw new ExceptionInInitializerError(e);}}
    static List<Field> fields(Class<?> type){return FIELDS.computeIfAbsent(type,k->{
        var out=new ArrayList<Field>();
        for(Class<?> c=k;c!=Object.class;c=c.getSuperclass())for(Field f:c.getDeclaredFields()){
            if(Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);out.add(f);
        }return out;
    });}
    static Object copy(Object value,IdentityHashMap<Object,Object> seen)throws Exception{
        if(value==null)return null;
        Class<?> t=value.getClass();
        if(t.isEnum()||value instanceof String||value instanceof Number||value instanceof Boolean
            ||value instanceof Character||value instanceof Path||value instanceof TinyQNetwork)return value;
        if(seen.containsKey(value))return seen.get(value);
        if(value instanceof Random random){
            Random clone=new Random(0);
            ((AtomicLong)RANDOM_SEED.get(clone)).set(((AtomicLong)RANDOM_SEED.get(random)).get());
            RANDOM_GAUSSIAN.setDouble(clone,RANDOM_GAUSSIAN.getDouble(random));
            RANDOM_HAS_GAUSSIAN.setBoolean(clone,RANDOM_HAS_GAUSSIAN.getBoolean(random));
            seen.put(value,clone);return clone;
        }
        if(t.isArray()){
            int n=Array.getLength(value);Object clone=Array.newInstance(t.componentType(),n);seen.put(value,clone);
            if(t.componentType().isPrimitive())System.arraycopy(value,0,clone,0,n);
            else for(int i=0;i<n;i++)Array.set(clone,i,copy(Array.get(value,i),seen));return clone;
        }
        if(value instanceof List<?> list){var clone=new ArrayList<Object>();seen.put(value,clone);
            for(Object element:list)clone.add(copy(element,seen));return clone;}
        if(t.isRecord()){
            var parts=t.getRecordComponents();var types=new Class<?>[parts.length];var args=new Object[parts.length];
            for(int i=0;i<parts.length;i++){types[i]=parts[i].getType();var method=parts[i].getAccessor();method.setAccessible(true);args[i]=copy(method.invoke(value),seen);}
            var ctor=t.getDeclaredConstructor(types);ctor.setAccessible(true);Object clone=ctor.newInstance(args);seen.put(value,clone);return clone;
        }
        if(!t.getName().startsWith("local.pvpbot.ai."))throw new IllegalArgumentException("Unknown mutable decision state: "+t);
        Object clone=ALLOC.allocateInstance(t);seen.put(value,clone);
        for(Field f:fields(t)){
            // A frozen reference never appends replay; sharing the empty ring
            // avoids allocating 2048 unused slots for each read-only preview.
            Object old=f.get(value);
            if(value instanceof ConstrainedTactics&&f.getName().equals("replay"))f.set(clone,old);
            else f.set(clone,copy(old,seen));
        }
        return clone;
    }
    static InitialCombatController controller()throws Exception {
        return (InitialCombatController)copy(Legacy86Reference.controller,new IdentityHashMap<>());
    }
}
