package local.pvpbot.ai;

import com.google.gson.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Offline oracle. Original controller and predictors come from the frozen JAR.
 * No Bukkit server, socket, player, item use or attack execution is created.
 * Input is explicit original CombatView/Senses, not invented server telemetry.
 */
public final class Legacy86Reference {
    static final Gson JSON = new GsonBuilder().serializeSpecialFloatingPointValues().create();
    static InitialCombatController controller;
    static ConstrainedTactics tactics;
    static CounterEscapeHop hop = new CounterEscapeHop();
    static long lastTick = Long.MIN_VALUE;
    static long seed;
    static Path tacticalModel;
    static double num(JsonObject o,String k,double d) {
        return o.has(k)&&!o.get(k).isJsonNull()?o.get(k).getAsDouble():d;
    }
    static boolean bool(JsonObject o,String k,boolean d) {
        return o.has(k)&&!o.get(k).isJsonNull()?o.get(k).getAsBoolean():d;
    }
    static String str(JsonObject o,String k,String d) {
        return o.has(k)&&!o.get(k).isJsonNull()?o.get(k).getAsString():d;
    }
    static Object decode(JsonElement e,Class<?> type) throws Exception {
        if(e==null||e.isJsonNull()) {
            if(type.isPrimitive())throw new IllegalArgumentException("Null primitive: "+type);
            return null;
        }
        if(type==boolean.class)return e.getAsBoolean();
        if(type==double.class)return e.getAsDouble();
        if(type==float.class)return e.getAsFloat();
        if(type==long.class)return e.getAsLong();
        if(type==int.class)return e.getAsInt();
        if(type.isEnum())return Enum.valueOf((Class)type,e.getAsString());
        if(type==double[].class)return JSON.fromJson(e,double[].class);
        if(type==boolean[].class)return JSON.fromJson(e,boolean[].class);
        if(type.isRecord()) {
            var parts=type.getRecordComponents();var types=new Class<?>[parts.length];var args=new Object[parts.length];
            var row=e.getAsJsonObject();
            for(int i=0;i<parts.length;i++) {
                types[i]=parts[i].getType();
                if(!row.has(parts[i].getName()))throw new IllegalArgumentException("Missing record field: "+type.getSimpleName()+"."+parts[i].getName());
                args[i]=decode(row.get(parts[i].getName()),types[i]);
            }
            var ctor=type.getDeclaredConstructor(types);ctor.setAccessible(true);return ctor.newInstance(args);
        }
        throw new IllegalArgumentException("Unsupported input type "+type);
    }
    static NeuralLearner.Senses senses(JsonObject row) throws Exception {
        var s=new NeuralLearner.Senses();
        for(var entry:row.entrySet()) {
            var field=NeuralLearner.Senses.class.getDeclaredField(entry.getKey());
            field.setAccessible(true);field.set(s,decode(entry.getValue(),field.getType()));
        }
        return s;
    }
    static void reset(long nextSeed) {
        seed=nextSeed;controller=new InitialCombatController(seed,0);
        tactics=new ConstrainedTactics(tacticalModel,seed+91000L);
        tactics.freeze();controller.setTactics(tactics);controller.reset();
        hop.reset();lastTick=Long.MIN_VALUE;
    }
    static Object invoke(Object owner,String name,JsonArray args) throws Exception {
        var methods=Arrays.stream(owner.getClass().getDeclaredMethods())
            .filter(m->m.getName().equals(name)&&m.getParameterCount()==args.size()).toList();
        if(methods.size()!=1)throw new IllegalArgumentException("Ambiguous/unknown method "+name);
        var m=methods.getFirst();m.setAccessible(true);var values=new Object[args.size()];
        for(int i=0;i<values.length;i++)values[i]=decode(args.get(i),m.getParameterTypes()[i]);
        return m.invoke(owner,values);
    }
    static Map<String,Object> hopStatus() {
        var out=new LinkedHashMap<String,Object>();out.put("active",hop.active());out.put("airborne",hop.wasAirborne());
        out.put("allowsJump",hop.allowsJump());out.put("exitAccepted",hop.exitAccepted());
        var critical=new ArrayList<Boolean>();
        for(boolean ready:new boolean[]{false,true})for(double vy:new double[]{Double.NaN,-.4,-.001,0,.4})
            critical.add(hop.criticalAvailable(ready,vy));
        out.put("critical",critical);return out;
    }
    static Map<String,Object> step(JsonObject req) throws Exception {
        var view=(CombatView)decode(req.get("view"),CombatView.class);
        if(view.tick()<=lastTick)throw new IllegalArgumentException("Repeated/out-of-order physics tick");
        var s=senses(req.getAsJsonObject("senses"));lastTick=view.tick();
        controller.combatObservation(bool(req,"targetGrounded",false),(int)num(req,"targetImmunity",20),20);
        if(req.has("hopCharge"))controller.hopCriticalObservation((float)num(req,"hopCharge",0),num(req,"hopVelocityY",0));
        var decision=controller.decide(view,s);
        var out=new LinkedHashMap<String,Object>();out.put("decision",decision);out.put("phase",controller.phaseName());
        out.put("movementAction",controller.movementAction());out.put("sprintKnockback",controller.sprintKnockbackInput());
        out.put("counterHopActive",controller.counterHopActive());
        if(req.has("groundGeometry")) {
            var g=req.getAsJsonObject("groundGeometry");
            var own=(PrecisionFootwork.Body)decode(g.get("own"),PrecisionFootwork.Body.class);
            var target=(PrecisionFootwork.Body)decode(g.get("target"),PrecisionFootwork.Body.class);
            var probes=g.getAsJsonArray("clear");
            var h=controller.groundHeading(own,target,bool(g,"sprint",true),num(g,"minX",0),num(g,"maxX",0),
                num(g,"minZ",0),num(g,"maxZ",0),(x,z)-> {
                    for(var p:probes) {
                        var q=p.getAsJsonObject();
                        if(Math.hypot(x-num(q,"x",0),z-num(q,"z",0))<1e-6)return bool(q,"clear",false);
                    }
                    throw new IllegalArgumentException("Missing actual route probe "+x+","+z);
                },view,s);
            out.put("groundHeading",h);out.put("groundSprint",controller.groundSprint());
        }
        return out;
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=1)throw new IllegalArgumentException("Frozen tactical checkpoint required");
        tacticalModel=Path.of(args[0]);if(!Files.isRegularFile(tacticalModel))throw new FileNotFoundException(args[0]);
        reset(123);
        try(var input=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8))) {
            for(String line;(line=input.readLine())!=null;) {
                try {
                    var r=JsonParser.parseString(line).getAsJsonObject();String cmd=str(r,"command","step");
                    Object value=switch(cmd) {
                        case "reset" -> {reset((long)num(r,"seed",123));yield Map.of("reset",true,"seed",seed);}
                        case "step" -> step(r);
                        case "controller-call" -> {var result=invoke(controller,str(r,"method",""),r.getAsJsonArray("args"));yield result==null?Map.of("ok",true):result;}
                        case "hop-call" -> {invoke(hop,str(r,"method",""),r.getAsJsonArray("args"));yield hopStatus();}
                        case "hop-status" -> hopStatus();
                        default -> throw new IllegalArgumentException("Unknown command: "+cmd);
                    };
                    System.out.println(JSON.toJson(Map.of("ok",true,"result",value)));
                }catch(Throwable e) {
                    while(e instanceof InvocationTargetException&&e.getCause()!=null)e=e.getCause();
                    System.out.println(JSON.toJson(Map.of("ok",false,"error",e.toString())));
                }
            }
        }
    }
}
