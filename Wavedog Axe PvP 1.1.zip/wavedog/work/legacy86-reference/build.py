"""Build an offline oracle against byte-verified original 8.6, never live plugins."""
from pathlib import Path
import hashlib, json, os, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
FROZEN = ROOT / 'outputs/legacy86-hop-neural-20261118/reference'
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')
ORIGINAL = ROOT / 'outputs/WaveDog-Works/WaveDog-盾斧pvp无敌版-含皮肤-test1-8.6-20261110-155759/plugins/PvPArenaAI.jar'
JAR = FROZEN / 'PvPArenaAI.jar'
GSON = SERVER / 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

assert sha(JAR) == sha(ORIGINAL), 'Reference must be byte-identical to original'
with zipfile.ZipFile(JAR) as z:
    assert z.testzip() is None
classes = BASE / 'classes'
classes.mkdir(exist_ok=True)
classpath = os.pathsep.join(map(str, [JAR, GSON]))
subprocess.run([str(SERVER/'runtime/java21/bin/javac.exe'), '-proc:none', '--release', '21',
    '-encoding', 'UTF-8', '-cp', classpath, '-d', str(classes),
    str(BASE/'src/local/pvpbot/ai/Legacy86Reference.java'),
    str(BASE/'src/local/pvpbot/ai/Legacy86Runtime.java'),
    str(BASE/'src/local/pvpbot/ai/Legacy86Snapshot.java')], check=True)
run = {'java': str(SERVER/'runtime/java21/bin/java.exe'),
       'classpath': os.pathsep.join(map(str,[classes,JAR,GSON])),
       'class': 'local.pvpbot.ai.Legacy86Reference',
       'model': str(FROZEN/'test1.nn.tactics-v5.nn'),
       'originalJarSha256': sha(JAR), 'modelSha256': sha(FROZEN/'test1.nn.tactics-v5.nn'),
       'originalClassesRecompiled': False, 'offlineOnly': True}
(BASE/'launch.json').write_text(json.dumps(run,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(run,ensure_ascii=False))
