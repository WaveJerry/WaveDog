import assert from 'node:assert/strict'
import {meleeEntryContext,meleeTechniqueGoal} from './fresh-melee-progress.js'
const frame=tick=>({tick,matchId:'pressure',opponent:'target',focus:'FREE',
  self:{x:0,y:0,z:0,eyeY:1.62,health:4,charge:.3,ground:true,shieldAvailable:false,using:false,shielding:false,held:7},
  seen:{visible:true,x:0,y:0,z:3.5-.1*tick,shield:true,held:'DIAMOND_AXE'},
  publicTerrain:{walls:[8,8,8,8]}})
const prev=frame(1),cur=frame(2)
let context=meleeEntryContext(prev,cur)
assert(context.shieldRushThreat&&context.shieldRushRetreatWindow)
assert.equal(meleeTechniqueGoal(cur,context).focus,'ESCAPE')
for(const other of [
  {...cur,self:{...cur.self,shieldAvailable:true,shielding:true}},
  {...cur,publicTerrain:{walls:[8,8,.5,8]}},
  {...cur,self:{...cur.self,health:20,charge:1}},
  {...cur,seen:{...cur.seen,z:3.7}},
  {...cur,seen:{...cur.seen,shield:false}}
]){
  assert(!meleeEntryContext(prev,other).shieldRushRetreatWindow,'no unconditional retreat')
}
context=meleeEntryContext(prev,{...cur,matchId:'different'})
assert(!context.shieldRushRetreatWindow,'a different match cannot inherit a rush')
console.log('SHIELD_PRESSURE_PUBLIC_CUE_PASS')
