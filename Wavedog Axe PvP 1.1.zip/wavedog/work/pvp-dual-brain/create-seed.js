import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './dual-policy.js'
import { importLastGru } from './import-last-gru.js'
import { SharedAdam, loadDualCheckpoint,
  saveDualCheckpoint } from './optimizer-checkpoint.js'

await tf.setBackend('cpu')
await tf.ready()
const here = path.dirname(fileURLToPath(import.meta.url))
const oldFolder = process.argv[2]
  ? path.resolve(process.argv[2])
  : path.resolve(here, '../pvp-player-client/new-learning/models/last_gru')
const manifestPath = process.argv[3]
  ? path.resolve(process.argv[3])
  : path.resolve(here, 'models/seed-last-gru/checkpoint.json')
if (fs.existsSync(manifestPath))
  throw Error(`Seed already exists: ${manifestPath}`)
const model = new DualPolicy()
const adam = new SharedAdam(model.params)
try {
  const source = importLastGru(model, adam,
    path.join(oldFolder, 'recurrent-ppo.json'),
    path.join(oldFolder, 'manifest.json'))
  const counters = { source: oldFolder, sourceSha256: source.sourceSha256,
    inheritedGruUpdates: source.updates, inheritedGruEpisodes: source.episodes,
    inheritedGruSamples: source.samples, dualUpdates: 0, dualEpisodes: 0 }
  const saved = saveDualCheckpoint(manifestPath, model, adam, counters)
  const loaded = loadDualCheckpoint(manifestPath)
  try {
    if (loaded.manifest.sha256 !== saved.sha256
        || loaded.adam.steps !== source.optimizerSteps
        || loaded.counters.inheritedGruUpdates !== source.updates)
      throw Error('Seed verification failed')
  } finally {
    loaded.adam.dispose()
    loaded.model.dispose()
  }
  console.log(JSON.stringify({ result: 'DUAL_SEED_CREATED', ...saved,
    inheritedGruUpdates: source.updates, dualUpdates: 0 }))
} finally {
  adam.dispose()
  model.dispose()
}
