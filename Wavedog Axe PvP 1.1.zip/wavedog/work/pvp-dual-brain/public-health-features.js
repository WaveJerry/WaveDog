export const PUBLIC_HEALTH_CHANNELS = 5
export function publicHealthFeatures (request) {
  const h = request.seen?.publicHealth, s = request.self, t = request.seen
  if (!h || !s || !t?.visible || h.source !== 'public-below-name-scoreboard'
      || h.objective !== 'wd_hearts' || h.roundedUp !== true
      || h.opponent !== request.opponent || h.matchId !== request.matchId
      || !Number.isSafeInteger(h.observedTick) || h.observedTick > request.tick
      || !Number.isSafeInteger(h.healthUpper) || h.healthUpper < 0 || h.healthUpper > 80
      || h.healthLowerExclusive !== Math.max(0, h.healthUpper - 1)
      || ![s.x, s.y, s.z, t.x, t.y, t.z].every(Number.isFinite)
      || Math.hypot(s.x-t.x, s.y-t.y, s.z-t.z) > 10)
    return Array(PUBLIC_HEALTH_CHANNELS).fill(0)
  const absorption = h.absorptionKnown === true && Number.isFinite(h.absorptionUpper)
    && h.absorptionUpper >= 0 && h.absorptionUpper <= 40
  return [1, h.healthUpper / 20, h.healthLowerExclusive / 20,
    absorption ? 1 : 0, absorption ? h.absorptionUpper / 20 : 0]
}
