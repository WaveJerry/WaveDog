import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { advance, disposeState, imitationUpdate, validateDataset } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 2, ff: 32, interval: 2, memory: 4 })
const unrelated = [...model.fastHeads[0].w.dataSync()]
const fastBefore = [...model.fast.candidate.w.dataSync()]
const slowBefore = [...model.slowBlocks[0].ffOut.w.dataSync()]
const optimizer = new SharedAdam([model.fast, model.slowToken, ...model.slowBlocks,
  model.fastHeads[4], model.fastHeads[5], model.slowHeads[4], model.slowHeads[5],
  model.gateIn, model.gateOut].flatMap(layer => layer.params), { learningRate: .0001 })
const observation = Array.from({ length: OBS_SIZE }, (_, i) => Math.sin(i + 1) * .1)
const segment = Array.from({ length: 4 }, (_, tick) => ({ tick,
  observation: observation.map(value => value + tick * .01), labels: tick === 3 ? { 5: 1 } : {} }))
let state = model.initialState()
for (const frame of segment) {
  const output = advance(model, state, frame.observation, true); state = output.state
  frame.reference = { logits: output.logits, value: output.value }
}
disposeState(state)
const initial = model.initialState()
const update = imitationUpdate(model, optimizer, segment, initial, { 5: 1 })
disposeState(initial)
assert(Number.isFinite(update.loss) && update.gradientNorm > 0)
assert(model.fast.candidate.w.dataSync().some((v, i) => v !== fastBefore[i]), 'GRU must receive gradients')
assert(model.slowBlocks[0].ffOut.w.dataSync().some((v, i) => v !== slowBefore[i]), 'Transformer must receive gradients')
assert.deepEqual([...model.fastHeads[0].w.dataSync()], unrelated, 'unknown human action heads have no direct supervised update')
const trace = (source, split, matchId) => ({ source, split, matchId, frames: segment })
const dataset = { schema: 'public-human-imitation-v1', ppoEligible: false,
  trajectories: [trace('a', 'train', 'm1'), trace('b', 'validation', 'm2')] }
assert.deepEqual(validateDataset(dataset), { train: { 5: 1 }, validation: { 5: 1 } })
assert.throws(() => validateDataset({ ...dataset, trajectories: [trace('a', 'train', 'same'), trace('b', 'validation', 'same')] }), /leakage/)
assert.throws(() => validateDataset({ ...dataset, ppoEligible: true }), /non-PPO/)
assert.throws(() => validateDataset({ ...dataset, trajectories: [
  { ...trace('1794720829881-23128-view-a', 'train', 'observer-a'), fighter: 'A', opponent: 'B' },
  { ...trace('1794720829881-23128-view-b', 'validation', 'observer-b'), fighter: 'B', opponent: 'A' }
] }), /leakage/, 'observer UUID must not defeat whole-match holdout')
optimizer.dispose(); model.dispose()
console.log(JSON.stringify({ result: 'HUMAN_IMITATION_PASS', gradientsToBothBranches: true,
  unrelatedHeadUnchanged: true, wholeMatchLeakageRejected: true, offPolicyPPORejected: true }))
