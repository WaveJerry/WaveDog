import assert from 'node:assert/strict'
import {decode}from './pure-actions.js'
const req={self:{x:0,y:0,z:0,eyeY:1.62,held:0},seen:{visible:true,x:0,y:0,z:-3},
  yaw:140,pitch:85}
const actions=[1,1,0,0,2,1,6,3,0]
let result=decode(req,actions,{pureAimVersion:2})
const angle=x=>((x+540)%360)-180
assert(Math.abs(angle(result.yaw-180))<1e-9)
assert(Math.abs(result.pitch)<1e-9)
assert.equal(result.slot,0)
assert.equal(result.aimYawOffset,0)
assert.equal(result.aimPitchOffset,0)
const repeated=decode({...req,yaw:result.yaw,pitch:result.pitch},actions,{pureAimVersion:2})
assert.equal(repeated.yaw,result.yaw,'selected view never integrates into endless turning')
assert.equal(repeated.pitch,result.pitch)
const away=decode(req,[...actions.slice(0,6),0,3,0],{pureAimVersion:2})
assert(Math.abs(angle(away.yaw))<1e-9,'the network can still choose to face away for sprint retreat')
const previous=decode(req,actions,{pureAimVersion:1})
assert.equal(previous.yaw,140,'legacy checkpoints keep their existing action semantics')
assert.equal(previous.pitch,85)
assert.equal(previous.aimYawOffset,undefined)
const invisible=decode({...req,seen:{visible:false}},actions,{pureAimVersion:2})
assert.equal(invisible.yaw,140,'no target coordinates are used without visibility')
assert.equal(invisible.pitch,85)
assert.equal(invisible.aimYawOffset,undefined)
assert(!result.flightLook)
console.log('PURE_RELATIVE_VIEW_PASS: explicit learned view choice, stable repeated direction, retreat, invisible and legacy behavior')
