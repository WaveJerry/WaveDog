"""Causal execution metrics; no movement/attack overrides or invented rewards."""
from pathlib import Path
import argparse,json
ROOT=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser();p.add_argument('matches',nargs='+');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
results=[]
for match in a.matches:
    frames=[json.loads(x)for x in (ROOT/'work/wavedog-punengbho/runtime'/f'{match}-frames.jsonl').read_text().splitlines()]
    packets={f['attackId']:f for f in frames if f.get('attackPacket')}
    events=[e for f in frames for e in f.get('nativeEvents',[])if not e.get('cancelled')and e.get('amount',0)>0 and e.get('melee')]
    dealt=[e for e in events if e.get('attacker')=='Punengbho']
    taken=[e for e in events if e.get('victim')=='Punengbho']
    attack_audit=[];longest=chain=0;last=-1000
    for e in dealt:
        f=packets.get(e.get('attackId'))
        if not f:continue
        crit=bool(e.get('nativeCritical')and f.get('attackHeld')==0)
        chain=chain+1 if crit and e['serverTick']-last<=18 else int(crit)
        if crit:last=e['serverTick']
        longest=max(longest,chain)
        own=f['self'];reach=f['observation']['reach']
        edge=own['ground']and 2.7<=reach<=3 and f['executed']['sprint']
        attack_audit.append({'attackId':e['attackId'],'tick':f['tick'],'serverTick':e['serverTick'],
            'weapon':f['attackHeld'],'reach':reach,'charge':f.get('attackCharge'),
            'sprintAtExecution':f['executed']['sprint'],'nativeCritical':bool(e.get('nativeCritical')),
            'groundedSprintEdgeHit':bool(edge),
            'receivedMeleeWithin20ServerTicks':sum(x['amount']for x in taken if 0<x['serverTick']-e['serverTick']<=20)})
    results.append({'match':match,'frames':len(frames),'actualAttackPackets':len(packets),
        'lowChargeAttackPackets':sum(f.get('attackCharge',1)<.4 for f in packets.values()),
        'confirmedSwordCriticals':sum(e.get('nativeCritical',False)and packets.get(e.get('attackId'),{}).get('attackHeld')==0 for e in dealt),
        'longestConfirmedSwordCriticalChain':longest,
        'confirmedGroundedSprintEdgeHits':sum(x['groundedSprintEdgeHit']for x in attack_audit),
        'nativeDamageDealt':sum(e['amount']for e in dealt),'nativeDamageTaken':sum(e['amount']for e in taken),
        'attackAudit':attack_audit})
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_text(json.dumps({'definition':'Edge: actual grounded sprint hit at eye-to-hitbox reach 2.7..3.0; chain: consecutive true sword critical damage within 18 server ticks',
    'metricsAreNotProofOfMastery':True,'bouts':results},indent=2))
for r in results:print(json.dumps({k:v for k,v in r.items()if k!='attackAudit'}))
