"""Validate immutable execution-time public geometry; preserve legacy evidence."""
import math

def attack_reach(packet):
    geometry = packet.get('attackGeometry')
    if geometry is None:
        return packet.get('observation', {}).get('reach', math.inf)
    if geometry.get('source') != 'execution-public-box-and-sent-position-v1':
        return math.inf
    try:
        target = geometry['target']
        width, height = target['width'], target['height']
        values = [target[k] for k in ['x','y','z']] + [width,height]
        if not all(math.isfinite(v) for v in values) or width <= 0 or height <= 0:
            return math.inf
        local = None
        for eye_key, hit_key, distance_key in [('eye','hit','rayDistance'),
                ('wireEye','wireHit','wireRayDistance')]:
            eye, hit = geometry[eye_key], geometry[hit_key]
            if not all(math.isfinite(p[k]) for p in [eye,hit] for k in ['x','y','z']):
                return math.inf
            distance = math.dist([eye[k] for k in ['x','y','z']], [hit[k] for k in ['x','y','z']])
            if not math.isfinite(geometry[distance_key]) or distance > 3.00001 or abs(distance-geometry[distance_key]) > 1e-6:
                return math.inf
            if not (target['x']-width/2-1e-6 <= hit['x'] <= target['x']+width/2+1e-6
                    and target['z']-width/2-1e-6 <= hit['z'] <= target['z']+width/2+1e-6
                    and target['y']-1e-6 <= hit['y'] <= target['y']+height+1e-6):
                return math.inf
            if eye_key == 'eye':
                local = distance
        return local
    except (KeyError, TypeError, ValueError):
        return math.inf
