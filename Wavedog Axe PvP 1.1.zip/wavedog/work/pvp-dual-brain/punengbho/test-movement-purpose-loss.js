import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {movementPurposeLoss}from './movement-purpose-loss.js'
const widths=[9,2,2,2,5,5,13,7,2]
const rows=[{frame:{publicSpatialFeatures:[1,.01,1,1,1,.35,0,.4],publicRequest:{self:{held:7},seen:{visible:true}}}}]
await tf.setBackend('cpu');await tf.ready()
const loss=(move,yaw)=>tf.tidy(()=>{const logits=widths.map((n,h)=>tf.tensor2d([Array.from({length:n},(_,i)=>i===(h===0?move:h===6?yaw:0)?8:-8)]));return movementPurposeLoss(rows,logits,3).dataSync()[0]})
assert(loss(2,6)>2.9,'facing the target while reversing into a wall still has a cost')
assert(loss(1,0)>5.9,'back-facing forward sprint into wall violates both purposes')
assert(loss(1,6)<1e-4,'facing and moving away from the rear wall is permitted')
assert(loss(0,6)<1e-4,'facing hold with no travel into wall is permitted')
assert(loss(4,11)>2.9,'at a +90 degree view, right strafe moves toward the rear wall')
assert(loss(3,11)<1e-4,'at a +90 degree view, left strafe moves away from the rear wall')
assert(loss(3,1)>2.9,'at a -90 degree view, left strafe moves toward the rear wall')
assert(loss(4,1)<1e-4,'at a -90 degree view, right strafe moves away from the rear wall')
const frame={publicSpatialFeatures:[1,1,1,1,1,.35,0,.4],labels:{4:0},actions:[1,1,0,0,0,1,0,3,0],
 publicRequest:{self:{held:0,ground:true},seen:{visible:true},publicActionContext:{targetCriticalThreat:true,targetAirborne:true}}}
tf.tidy(()=>{
 const logits=widths.map((n,h)=>tf.tensor2d([Array.from({length:n},(_,i)=>i===(h===0?1:h===6?0:0)?8:-8)]))
 assert.equal(movementPurposeLoss([{frame}],logits,3),null,'do not punish a demonstrated forecast escape turn')
 const blocked={...frame,publicSpatialFeatures:[1,.01,1,1,1,.35,0,.4]}
 assert(movementPurposeLoss([{frame:blocked}],logits,3).dataSync()[0]>2.9,'forecast escape still cannot run into a wall')
 const ordinary={...frame,publicRequest:{...frame.publicRequest,publicActionContext:{targetCriticalThreat:false,targetAirborne:true}}}
 assert(movementPurposeLoss([{frame:ordinary}],logits,3).dataSync()[0]>2.9,'ordinary back-facing near contact is still penalized')
 const recovery={...ordinary,expertReason:'axe-spacing-committed-recovery',labels:{4:0,5:0},
   publicRequest:{...ordinary.publicRequest,self:{held:7,ground:true,charge:.3}}}
 assert.equal(movementPurposeLoss([{frame:recovery}],logits,3),null,'committed axe recovery cannot be trained to face both directions')
 const recoveryWall={...recovery,publicSpatialFeatures:blocked.publicSpatialFeatures}
 assert(movementPurposeLoss([{frame:recoveryWall}],logits,3).dataSync()[0]>2.9,'recovery must still avoid blocked retreat')
 const intercept={...recovery,expertReason:'urgent-legal-interrupt-before-full-charge',labels:{4:2,5:0}}
 assert(movementPurposeLoss([{frame:intercept}],logits,3).dataSync()[0]>2.9,'a pursuer in reach requires facing for interception')
 const sideWall={...frame,publicSpatialFeatures:[1,1,1,.02,1,.5,0,.5]}
 const command=(move,yaw)=>widths.map((n,h)=>tf.tensor2d([Array.from({length:n},(_,i)=>i===(h===0?move:h===6?yaw:0)?8:-8)]))
 assert(movementPurposeLoss([{frame:sideWall}],command(3,0),3).dataSync()[0]>2.9,'turning around reverses strafe into the right wall')
 assert(movementPurposeLoss([{frame:sideWall}],command(3,6),3).dataSync()[0]<1e-4,'facing left strafe is away from the right wall')
 const frontWall={...frame,publicSpatialFeatures:[1,1,.02,1,1,.5,0,.5]}
 assert(movementPurposeLoss([{frame:frontWall}],command(1,6),3).dataSync()[0]>2.9,'forward collision is learned as well as rear collision')
 const overconfident=widths.map((n,h)=>tf.tensor2d([Array.from({length:n},(_,i)=>i===(h===0?1:0)?40:0)]))
 const move=tf.variable(overconfident[0]),view=tf.variable(overconfident[6]);overconfident[0]=move;overconfident[6]=view
 const g=tf.variableGrads(()=>movementPurposeLoss([{frame:blocked}],overconfident,1),[move,view])
 assert(Number.isFinite(g.value.dataSync()[0]))
 assert(g.grads[move.name].dataSync().some(v=>Math.abs(v)>.01),'40-logit collision still gives a corrective move gradient')
 assert(g.grads[view.name].dataSync().some(v=>Math.abs(v)>.01),'40-logit collision still gives a corrective view gradient')
 move.dispose();view.dispose()
})
console.log('PURPOSE_LOSS_PENALIZES_BACKPEDAL_AND_BACK_FACING_PASS')
