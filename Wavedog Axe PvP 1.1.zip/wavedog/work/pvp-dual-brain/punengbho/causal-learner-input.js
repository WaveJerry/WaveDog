import assert from 'node:assert/strict'
import {publicThreatFeatures}from '../public-threat-features.js'
import {publicSpatialFeatures}from '../public-spatial-features.js'

// Reconstruct only the public request that accompanied this recorded tick.
// Native damage/critical receipts and later frames are never input features.
export function learnerRequest(row,metadata={}){
  return {tick:row.tick,matchId:metadata.matchId??row.observedOpponentMotion?.matchId,
    opponent:metadata.opponent??row.observedOpponentMotion?.opponent,
    self:row.self,seen:row.seen,publicTerrain:row.publicTerrain,
    observedOpponentMotion:row.observedOpponentMotion,publicActionContext:row.observation}
}
export function recordedPolicyFeatures(frame,request){
  assert.equal(frame.decidedTick,request.tick,'Observation and model input must be the same tick')
  // Keep the ACTUAL transport inputs, rather than recomputing a new input
  // silently if a raw log was aligned to the wrong bout or tick.
  for(const[name,expected]of [['publicThreatFeatures',publicThreatFeatures(request)],
                             ['publicSpatialFeatures',publicSpatialFeatures(request)]]){
    if(frame[name]!==undefined){
      assert(frame[name].every(Number.isFinite),'Nonfinite recorded input: '+name)
      // JSON transport canonicalizes -0 to 0; compare that exact wire form.
      assert.equal(JSON.stringify(frame[name]),JSON.stringify(expected),'Causal input mismatch: '+name)
    }
  }
  return {publicHealthFeatures:frame.publicHealthFeatures,
    ...(frame.publicSpatialFeatures!==undefined?{publicSpatialFeatures:frame.publicSpatialFeatures}:{}),
    ...(frame.publicThreatFeatures!==undefined?{publicThreatFeatures:frame.publicThreatFeatures}:{})}
}
