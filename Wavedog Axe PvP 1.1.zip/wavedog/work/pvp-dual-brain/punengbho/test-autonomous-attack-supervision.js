import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS} from '../fresh-policy.js'
import {autonomousAttackTargets, autonomousAttackLoss} from './autonomous-attack-supervision.js'
await tf.setBackend('cpu'); await tf.ready()
tf.tidy(() => {
  const frame = (label, changed = {}) => {
    const actions = Array(9).fill(0)
    for (const [h, a] of Object.entries(changed)) actions[h] = a
    return {lesson: 'ground', frame: {actions, labels: label === undefined ? {} : {4: label}}}
  }
  const rows = [frame(2), frame(2, {1: 1}), frame(2, {2: 1}),
    frame(2, {5: 1}), frame(0, {5: 1}), frame(undefined)]
  const logits = ACTION_WIDTHS.map(width => tf.tensor2d(
    rows.map(() => Array.from({length: width}, (_, a) => a === 0 ? 1 : 0))))
  const targets = autonomousAttackTargets(rows, logits, {ground: 2})
  assert.deepEqual(targets.map(t => t.weight), [2, 0, 0, 0, 2, 0],
    'positive attack requires all three parents; unlabeled and mismatched attacks are excluded')
  const attack = tf.variable(logits[4])
  try {
    const {value, grads} = tf.variableGrads(() => tf.add(
      autonomousAttackLoss(attack, targets, 0, .5),
      autonomousAttackLoss(attack, targets, 2, .5)), [attack])
    assert(Number.isFinite(value.dataSync()[0]))
    const g = grads[attack.name].arraySync()
    assert(g[0][2] < 0 && g[0][0] > 0, 'compatible positive must increase attack probability')
    assert(g[4][0] < 0 && g[4][2] > 0, 'wait must retain the opposite gradient')
    for (const i of [1, 2, 3, 5]) assert(g[i].every(x => x === 0), 'excluded rows have zero gradient')
    assert.equal(autonomousAttackLoss(attack, targets, 2, 0), null)
    assert.equal(autonomousAttackLoss(attack, targets.map(t => ({...t, weight: 0})), 2, 1), null)
  } finally { attack.dispose() }
})
assert.equal(tf.memory().numTensors, 0)
console.log('AUTONOMOUS_ATTACK_SUPERVISION_PASS')
