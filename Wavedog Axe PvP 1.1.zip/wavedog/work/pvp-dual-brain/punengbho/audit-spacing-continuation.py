"""Additional descriptive diagnostics; never replaces native skill acceptance."""
from pathlib import Path
import argparse,json,math
from execution_geometry import attack_reach

def audit(frames,fighter):
    attacks={f['attackId']:f for f in frames if f.get('attackPacket') and f.get('attackId') is not None}
    events={}
    for f in frames:
        for e in f.get('nativeEvents',[]):
            key=(e.get('serverTick'),e.get('attackId'),e.get('attacker'),e.get('victim'),e.get('amount'))
            if not e.get('cancelled') and e.get('amount',0)>0:events[key]=(f,e)
    hits=[]
    for f,e in events.values():
        p=attacks.get(e.get('attackId'))
        if e.get('attacker')==fighter and e.get('melee') and p:
            hits.append((p,e))
    hits.sort(key=lambda pair:pair[1]['serverTick'])
    horizontal=lambda f:math.hypot(f['seen']['x']-f['self']['x'],f['seen']['z']-f['self']['z'])
    first=hits[0]if hits else None
    jumps=[]
    for f in frames:
        if not(f['self'].get('ground') and f.get('executed',{}).get('jump')):continue
        interruptions=[{'tick':q['tick'],'serverTick':e['serverTick'],'damage':e['amount']}
            for q,e in events.values()if e.get('victim')==fighter and e.get('melee')
            and 0<q['tick']-f['tick']<=6 and q['self'].get('vy',0)>.03]
        jumps.append({'tick':f['tick'],'horizontal':horizontal(f),
            'targetShield':bool(f['seen'].get('shield')),'receivedDamageWhileRising':interruptions})
    rows=[{'tick':p['tick'],'serverTick':e['serverTick'],'weapon':'axe'if p.get('attackHeld')==7 else 'sword',
        'reach':attack_reach(p),'observedReach':p['observation']['reach'],'horizontal':horizontal(p),'damage':e['amount'],
        'critical':bool(e.get('nativeCritical')),'ground':bool(p['self'].get('ground')),
        'sprint':bool(p.get('executed',{}).get('sprint'))}for p,e in hits]
    return {'nativeLinkedHits':rows,'firstHit':rows[0]if first else None,
        'groundedAxeEdgeHits':sum(r['weapon']=='axe'and r['ground']and r['sprint']and 2.85<=r['reach']<=3 for r in rows),
        'groundJumpAttempts':jumps,'distantJumpAttempts':sum(j['horizontal']>=3 for j in jumps),
        'jumpAttemptsWithRisingDamage':sum(bool(j['receivedDamageWhileRising'])for j in jumps),
        'nativeSwordCriticals':sum(r['weapon']=='sword'and r['critical']for r in rows),
        'descriptiveOnly':True,'fullTacticalMastery':False}

def axe_spacing_contract(summary,frames):
    if summary['opponentMode']not in ['edge-control','edge-mixed']:
        raise ValueError('Axe opening contract requires a spaced ground opponent')
    result=audit(frames,summary['fighter'])
    checks={'validBout':not summary.get('outcome',{}).get('invalid'),
        'spacedStart':summary['actualFirstFrameDistance']>=3.5,
        'firstNativeMeleeHitUsesAxe':bool(result['firstHit'])and result['firstHit']['weapon']=='axe',
        'nativeGroundedSprintAxeEdgeHit':result['groundedAxeEdgeHits']>=1}
    return {'schema':'axe-opening-spacing-microtask-v1','checks':checks,
        'passed':all(checks.values()),'diagnostics':result,
        'mustAlsoPassOriginalMeleeAndEquipmentContracts':True,'fullTacticalMastery':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('matches',nargs='+');p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists():raise RuntimeError('Preserve earlier diagnostics')
    rows=[]
    for match in a.matches:
        file=Path('work/wavedog-punengbho/runtime')/(match+'-frames.jsonl')
        frames=[json.loads(line)for line in file.read_text().splitlines()]
        rows.append({'matchId':match,'checkpointSha256':frames[0].get('policySha'),**audit(frames,'Punengbho')})
    a.out.write_text(json.dumps(rows,indent=2))
    print(json.dumps([{k:v for k,v in row.items()if k not in ['nativeLinkedHits','groundJumpAttempts']}for row in rows]))
