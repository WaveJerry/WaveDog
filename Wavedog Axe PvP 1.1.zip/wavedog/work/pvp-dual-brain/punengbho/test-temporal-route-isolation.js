import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
await tf.setBackend('cpu');await tf.ready()
const m=new DualPolicy({fast:8,slow:16,heads:2,layers:2,ff:24,interval:2,memory:4,publicThreatInputs:12,
 spatialMovementVersion:1,spatialMovementHeads:[0,1,6,5,4,2],spatialControlSplitHeads:[0,2,5],
 spatialTemporalFusionVersion:1,spatialTemporalRouteSplit:1})
const s=[1,.1,.8,.1,.8,.4,.2,.4],t=[1,0,.2,.3,.1,1,1,.25,1,.5,.3,0]
tf.tidy(()=>{for(const [i,h]of m.spatialTemporalHeads.entries()){
 const out=m.spatialTemporalOut[i],w=tf.randomNormal(out.w.shape,0,.1,'float32',h+7)
 out.w.assign(h===6?tf.mul(w,tf.tensor1d(Array.from({length:13},(_,i)=>Number(i===0||i===12)))):w)
}})
const capture=()=>tf.tidy(()=>m.step(tf.ones([1,OBS_SIZE]),null,null,null,s,t).logits.map(x=>[...x.dataSync()]))
const a=capture()
tf.tidy(()=>m.spatialTemporalRouteIn.b.assign(tf.add(m.spatialTemporalRouteIn.b,.5)))
const b=capture()
for(const h of [1,2,3,4,5,7,8])assert.deepEqual(a[h],b[h],'route adaptation cannot change combat head '+h)
for(let i=1;i<12;i++)assert.equal(a[6][i],b[6][i],'fine aim remains inherited')
assert.notDeepEqual(a[0],b[0],'movement learns from its isolated representation')
assert.notEqual(a[6][0],b[6][0],'coarse turning learns from its isolated representation')
m.dispose()
console.log('TEMPORAL_ROUTE_ISOLATION_PASS: movement adapts, combat and fine-aim raw logits exactly preserved')
