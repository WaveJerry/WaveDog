"""Rebase on current PPO; teach causal weapon transitions and first-contact timing."""
from pathlib import Path
from collections import Counter
import argparse, gzip, hashlib, json, os, shutil, subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
parser=argparse.ArgumentParser()
parser.add_argument('--weapon-labels',choices=['hold','absolute'],default='absolute')
args=parser.parse_args()
DEST=BASE/('opener-cadence' if args.weapon_labels=='hold' else 'opener-cadence-absolute')
DEST.mkdir(exist_ok=False)
LIVE=ROOT/'work/wavedog-punengbho/model'
manifest=json.loads((LIVE/'checkpoint.json').read_text())
payload=(LIVE/manifest['binary']).read_bytes()
assert hashlib.sha256(payload).hexdigest()==manifest['sha256']
(DEST/'source').mkdir()
shutil.copy2(LIVE/'checkpoint.json',DEST/'source/checkpoint.json')
(DEST/'source'/manifest['binary']).write_bytes(payload)
data=json.loads((BASE/'refinement/whole-exchanges.json').read_text())
stats={}
for trace in data['trajectories']:
    raw=(Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts')/trace['source']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==trace['sourceSha256']
    rows=[json.loads(line) for line in gzip.decompress(raw).decode().splitlines()]
    assert rows[-1]['type']=='end' and rows[-1]['droppedGlobal']==0
    observed={r['tick']:r for r in rows if r['type']=='frame'}
    jumped=set();previous=None
    for r in rows:
        if r['type']=='frame':previous=r
        elif r['type']=='action-event' and r.get('event')=='jump' and previous and previous['self']['ground']:
            jumped.add(previous['tick'])
    for f in trace['frames']:
        f['labels']={h:a for h,a in f['labels'].items() if h in ['1','2','4']}
        r=observed.get(f['tick']);n=observed.get(f['tick']+1)
        x=f['observation']
        if f['tick'] in jumped and f['publicRequest']['self']['ground']:
            f['labels']['2']=1
            f['labelEvidence'].append('ordered-native-jump-with-grounded-observation')
        if r and n:
            held=r['self']['main']['type'];next_held=n['self']['main']['type']
            melee=['DIAMOND_AXE','DIAMOND_SWORD']
            if held in melee and next_held in melee:
                # Attack and a subsequent switch can occur in the same native
                # tick. Preserve the evidenced attacking weapon on attack rows;
                # do not pretend the later slot was used for that earlier hit.
                if f['labels'].get('4')==2:
                    f['labels']['5']=f['attackWeaponAction']
                else:
                    f['labels']['5']=melee.index(next_held) if held!=next_held or args.weapon_labels=='absolute' else 4
                f['labelEvidence'].append('consecutive-native-melee-weapon-choice')
        f['operatorGroundedEdgeOpening']=bool(x[2]>.5 and x[1]>=.75 and x[31]>.5
            and -.4<=x[97]<=0 and x[23]<.5 and f.get('analysisPhase')=='boundary-contact'
            and not f.get('context',{}).get('fallingMeleeThreat'))
        split=trace['split'];counter=stats.setdefault(split,Counter())
        if '5' in f['labels']:counter['weapon-'+str(f['labels']['5'])]+=1
        if f['operatorGroundedEdgeOpening']:counter['ground-edge-'+str(f['labels'].get('4'))]+=1
        if '2' in f['labels']:counter['jump-'+str(f['labels']['2'])]+=1
data['learningPurpose']='Causal native weapon transitions and retained absolute weapon; grounded edge first hits and real critical cadence; no runtime locks'
(DEST/'whole-exchanges.json').write_text(json.dumps(data),encoding='utf8')
(DEST/'data-receipt.json').write_text(json.dumps({'sourceSha256':manifest['sha256'],'stats':stats,
    'wholeBoutSplitPreserved':True,'fixedCombatRoute':False,'runtimeForcedWeapons':False},indent=2))
env=os.environ.copy()
env.update(IMITATION_HEADS_ONLY='1',IMITATION_CONTEXT_ONLY='0',IMITATION_CONTEXT_HEADS='[2,4,5]',
    IMITATION_CALIBRATED_HEADS='[2,4,5]',IMITATION_DISTRIBUTION_VERSION='3',IMITATION_WEAPON_CONDITIONING='2',
    IMITATION_LR='0.0008',IMITATION_CONTEXT_RATE='1',IMITATION_EPOCHS='2',
    IMITATION_FREQUENCY_HEADS='[1,2,4,5]',IMITATION_EXCHANGE_BALANCE='1',
    IMITATION_HEAD_WEIGHTS='{"5":3,"4":2}',IMITATION_ADAPTED_ANCHOR='0.03',
    IMITATION_ADAPTED_HEADS='[1,2,4,5]')
print(json.dumps({'stage':'prepared','sourceSha256':manifest['sha256'],'stats':stats}),flush=True)
with (DEST/'training.log').open('wb')as log:
    subprocess.run([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/human-imitation.js'),
        str(DEST/'source/checkpoint.json'),str(DEST/'whole-exchanges.json'),str(DEST/'trained')],
        cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
r=json.loads((DEST/'trained/receipt.json').read_text())
print(json.dumps({'stage':'trained','checks':r['checks'],'offlineChecksPassed':r['offlineChecksPassed'],
    'sha256':r['saved']['sha256'],'before':r['before']['validation']['labels'],
    'after':r['after']['validation']['labels']}),flush=True)
