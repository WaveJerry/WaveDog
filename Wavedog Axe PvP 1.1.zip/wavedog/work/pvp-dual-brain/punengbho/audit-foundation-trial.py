"""Read-only basic skill acceptance using actual model packets and native events."""
from pathlib import Path
from datetime import datetime
import argparse,json,math
from execution_geometry import attack_reach

def audit(summary,frames):
    fighter=summary['fighter'];packets={r['attackId']:r for r in frames if r.get('attackPacket') and r.get('attackId') is not None}
    damage=[];seen=set()
    for r in frames:
        for e in r.get('nativeEvents',[]):
            key=(e.get('serverTick'),e.get('attackId'),e.get('attacker'),e.get('victim'),e.get('amount'))
            if key in seen:continue
            seen.add(key)
            if e.get('attacker')==fighter and e.get('melee') and not e.get('cancelled') and e.get('amount',0)>0:
                p=packets.get(e.get('attackId'))
                if p is not None:damage.append((p,e))
    sword_crits=[(p,e) for p,e in damage if p.get('attackHeld')==0 and e.get('nativeCritical')]
    grounded_edge=[(p,e)for p,e in damage if p.get('attackHeld')in[0,7] and p['self']['ground']
        and p.get('executed',{}).get('sprint') and 2.85<=attack_reach(p)<=3]
    axe_shields=[p for p in packets.values()if p.get('attackHeld')==7 and p['seen'].get('shield')]
    # Opponent set_cooldown is referee evidence only, never a policy input.
    breaks=[]
    for receipt in summary.get('opponentShieldDisableReceipts',[]):
        if receipt.get('cooldownTicks',0)<1 or receipt.get('matchId')!=summary['matchId']:continue
        at=datetime.fromisoformat(receipt['at'].replace('Z','+00:00')).timestamp()*1000
        linked=[p for p in axe_shields if -100<=at-p['capturedAt']<=600]
        if not linked:continue
        p=max(linked,key=lambda p:p['tick'])
        continuation=[(q,e)for q,e in damage if q.get('attackHeld')==0 and 0<q['tick']-p['tick']<=30]
        if continuation:breaks.append({'axeTick':p['tick'],'cooldownTicks':receipt['cooldownTicks'],
            'firstSwordDamageTick':min(q['tick']for q,e in continuation)})
    chain=best=0;previous=-1000
    for p,e in sorted(damage,key=lambda row:row[1]['serverTick']):
        if p.get('attackHeld')==0 and e.get('nativeCritical'):
            chain=chain+1 if e['serverTick']-previous<=16 else 1
            best=max(best,chain);previous=e['serverTick']
        else:chain=0
    own_unshielded=bool(frames) and all(not r['self'].get('shieldAvailable') and not r['self'].get('shielding') for r in frames)
    model_owned=all(r.get('owners',{}).get('mainhand') in ['neural','neutral-expired','stale-weapon-observation']for r in frames)
    shield_latencies=[];pending=None
    for r in frames:
        o=r['observation'];s=r['self'];t=r['seen']
        legal=t.get('visible') and o.get('reach',math.inf)<=3 and t.get('shield')
        if not legal:pending=None;continue
        if pending is None:pending=r['tick']
        if r.get('attackPacket') and r.get('attackHeld')==7:
            shield_latencies.append(r['tick']-pending);pending=None
    mode=summary['opponentMode']
    checks={'validBout':not summary.get('outcome',{}).get('invalid'),
        'modelOwnsWeapon':model_owned,'learnerHasNoShield':own_unshielded,
        'noModelAttackOutsideLocalReach':all(attack_reach(p)<=3.00001 for p in packets.values()),
        'noSneaking':not any(r.get('executed',{}).get('sneak')for r in frames)}
    if mode=='critical':checks.update(closeStart=summary['actualFirstFrameDistance']<=1.55,
        threeNativeSwordCriticals=len(sword_crits)>=3,twoConsecutiveNativeSwordCriticals=best>=2)
    elif mode in ['combo-shield','shield','shield-cycle']:
        checks.update(nativeShieldBreakThenSwordDamage=bool(breaks),
            legalPublicShieldResponseWithinTwoTicks=any(n<=2 for n in shield_latencies))
    elif mode in ['edge-control','edge-mixed']:
        checks['nativeGroundedSprintEdgeDamage']=bool(grounded_edge)
    else:raise ValueError('No basic acceptance contract for '+mode)
    return {'schema':'model-foundation-live-acceptance-v1','matchId':summary['matchId'],'mode':mode,
        'checks':checks,'passed':all(checks.values()),'nativeSwordCriticals':len(sword_crits),
        'longestNativeSwordCriticalChain':best,'nativeGroundedSprintEdgeHits':len(grounded_edge),
        'axeShieldPackets':len(axe_shields),'verifiedShieldBreakSwordSequences':breaks,
        'shieldResponseTicks':shield_latencies,'rawFramesPreserved':True,'fullTacticalMastery':False,
        'singleTrialOnly':True,'mainWaveDogPromotionAuthorized':False,
        'reachEvidence':'execution-local-and-wire-geometry-when-recorded-legacy-observation-otherwise',
        'reachLimitUnchanged':3}

def audit_carried_kit(summary,frames):
    """Separate equipment regression scenario; keep all existing skill floors."""
    if summary['opponentMode']not in ['critical','combo-shield','shield','shield-cycle','edge-control','edge-mixed']:
        raise ValueError('No carried-kit melee contract for this mode')
    result=audit(summary,frames)
    # The original contract still requires NO shield equipment. This separate
    # scenario requires the opposite, and verifies it stayed unused on wire.
    del result['checks']['learnerHasNoShield']
    result['checks']['learnerCarriesShieldBowCrossbow']=bool(frames)and all(
        r['self'].get('shieldAvailable')and r['self'].get('hasBow')and r['self'].get('hasCrossbow')
        and r['self'].get('arrows',0)>0 for r in frames)
    result['checks']['noShieldOrRangedUseDuringMelee']=all(
        not r['self'].get('shielding')and not r['self'].get('using')
        and not r.get('command',{}).get('shield')and not r.get('command',{}).get('use')
        and not any(n in ['use_item','block_place']for n in r.get('actualPackets',[]))for r in frames)
    result['checks']['modelKeepsMeleeWeapon']=all(r['self'].get('held')in[0,7]for r in frames)
    result.update(schema='model-carried-kit-melee-acceptance-v1',passed=all(result['checks'].values()),
        originalShieldlessContractUnchanged=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('summary',type=Path);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--carried-kit',action='store_true');a=p.parse_args()
    if a.out.exists():raise RuntimeError('Preserve existing acceptance report')
    s=json.loads(a.summary.read_text());frames=[json.loads(x)for x in Path(s['frameFile']).read_text().splitlines()]
    r=(audit_carried_kit if a.carried_kit else audit)(s,frames)
    a.out.write_text(json.dumps(r,indent=2));print(json.dumps(r))
