import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import crypto from 'node:crypto'
import {validateDataset}from '../human-imitation.js'
import {preservedDaggerBouts,daggerBoutSplit}from './dagger-splits.js'
import {directionalMovementSupervision}from './directional-movement-supervision.js'
import {retreatPurposeSupervision}from './retreat-purpose-supervision.js'
import {learnerRequest,recordedPolicyFeatures}from './causal-learner-input.js'
const root=path.resolve('outputs/punengbho-rebuild-20261117')
const dest=path.join(root,process.argv[2]||'dagger-round1')
const tail=process.argv.slice(3),delayIndex=tail.indexOf('--label-delay')
const purposeIndex=tail.indexOf('--retreat-purpose'),purpose=purposeIndex>=0
if(purpose)tail.splice(purposeIndex,1)
const labelDelay=delayIndex<0?1:Number(tail.splice(delayIndex,2)[1])
const directionalIndex=tail.indexOf('--directional-movement'),directional=directionalIndex>=0
if(directional)tail.splice(directionalIndex,1)
if(![0,1,2].includes(labelDelay))throw Error('Label delay must be 0, 1 or 2 ticks')
const expertIndex=tail.indexOf('--expert')
const expertName=expertIndex<0?'critical':tail.splice(expertIndex,2)[1]
if(!['critical','joint-melee'].includes(expertName))throw Error('Unknown offline expert')
const lessonIndex=tail.indexOf('--lesson')
const explicitLesson=lessonIndex<0?null:tail.splice(lessonIndex,2)[1]
if(explicitLesson!==null&&!['close-critical','joint-state-transitions','shield-state-transitions'].includes(explicitLesson))
  throw Error('Unknown DAgger lesson')
const {criticalExpert,observeLearnerInput,sourceSha256}=await import(expertName==='critical'?'./critical-expert.cjs':'./joint-melee-expert.cjs')
const preserveIndex=tail.indexOf('--preserve-splits')
const preserveFile=preserveIndex<0?null:path.resolve(tail.splice(preserveIndex,2)[1])
const preserved=preservedDaggerBouts(preserveFile?JSON.parse(fs.readFileSync(preserveFile)):null)
const baseIndex=tail.indexOf('--base')
const baseDataset=baseIndex<0?path.join(root,'demonstrations/dataset.json'):path.resolve(tail[baseIndex+1])
const matches=baseIndex<0?tail:[...tail.slice(0,baseIndex),...tail.slice(baseIndex+2)]
if(matches.length<2)throw Error('Require separate complete learner bouts for train and holdout')
if(fs.existsSync(dest)&&fs.readdirSync(dest).some(n=>n!=='source'))throw Error('Preserve existing round')
const dataset=JSON.parse(fs.readFileSync(baseDataset))
const live=path.resolve('work/wavedog-punengbho/model'),manifest=JSON.parse(fs.readFileSync(path.join(live,'checkpoint.json')))
const rollouts=fs.readdirSync(path.join(live,'rollouts')).filter(n=>n.endsWith('.json.gz')).sort().reverse()
const audit=[]
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180],pitches=[-30,-10,-3,0,3,10,30]
const nearest=(v,bins)=>bins.reduce((best,x,i)=>Math.abs(x-v)<Math.abs(bins[best]-v)?i:best,0)
function closestAngles(r){
  const s=r.self,t=r.seen,px=Math.max(t.x-.3+.0001,Math.min(t.x+.3-.0001,s.x)),
    pz=Math.max(t.z-.3+.0001,Math.min(t.z+.3-.0001,s.z)),
    py=Math.max(t.y+.0001,Math.min(t.y+1.8-.0001,s.eyeY))
  return [Math.atan2(-(px-s.x),pz-s.z)*180/Math.PI,
    -Math.atan2(py-s.eyeY,Math.hypot(px-s.x,pz-s.z))*180/Math.PI]
}
for(const [index,match]of matches.entries()){
  if(dataset.trajectories.some(t=>t.sourceKind==='dagger-expert-relabel'&&t.matchId===match))
    throw Error('Duplicate DAgger bout in base '+match)
  const rawPath=path.resolve('work/wavedog-punengbho/runtime',match+'-frames.jsonl')
  const bytes=fs.readFileSync(rawPath),raw=bytes.toString().trim().split('\n').map(JSON.parse)
  const byTick=new Map(raw.map(f=>[f.tick,f]))
  let rollout,rolloutFile
  const evaluation=path.join(live,'evaluations',match+'.json.gz')
  if(fs.existsSync(evaluation)){
    rollout=JSON.parse(zlib.gunzipSync(fs.readFileSync(evaluation)));rolloutFile=evaluation
  }
  for(const name of rollout?[]:rollouts){
    const r=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(live,'rollouts',name))))
    if(r.episode?.some(f=>byTick.has(f.decidedTick)&&f.checkpointSha256===raw.find(x=>x.policySha)?.policySha)){
      rollout=r;rolloutFile=name;break
    }
  }
  if(!rollout)throw Error('No exact policy rollout for '+match)
  const history={},frames=[],adviceByTick=new Map()
  for(const r of raw){
    const request=learnerRequest(r,{matchId:match})
    const advice=criticalExpert(request,history)
    const moving=directional?directionalMovementSupervision(advice,request):advice
    adviceByTick.set(r.tick,purpose?retreatPurposeSupervision(moving,request):moving)
    observeLearnerInput(history,request,{...r.executed,attackPacket:r.attackPacket,
      held:r.attackHeld??r.executedHeld})
  }
  for(const f of rollout.episode){
    const r=byTick.get(f.decidedTick)
    if(!r)throw Error('Cannot align observation to learner tick')
    const request=learnerRequest(r,{matchId:match})
    const future=byTick.get(f.decidedTick+labelDelay),advice=future?adviceByTick.get(future.tick):null
    const labels={...(advice?.labels||{})},actions=[...(advice?.actions||Array(9).fill(0))]
    // Only labels may use the actual later execution state. The recurrent
    // input remains the exact stored causal observation at decidedTick.
    if(future&&r.seen.visible&&future.seen.visible&&Object.keys(labels).length){
      const before=closestAngles(request),after=closestAngles(future)
      // Relative-view v2 is recomputed against the latest visible target by
      // the packet adapter. Adding future-minus-past aim would compensate
      // twice and teach an unintended miss. Legacy absolute views retain it.
      const relative=r.command?.pureAimVersion===2||r.modelAction?.pureAimVersion===2
      labels[6]=nearest((((relative?0:after[0]-before[0])+(advice.viewYawOffsetDegrees??0)+540)%360)-180,turns)
      labels[7]=nearest((relative?0:after[1]-before[1])+(advice.viewPitchOffsetDegrees??0),pitches)
      for(const[h,a]of Object.entries(labels)){
        if(f.legalMasks[h][a]===false){delete labels[h];actions[h]=0}
        else actions[h]=a
      }
    }
    frames.push({tick:f.decidedTick,observation:f.observation,context:f.context,
      ...recordedPolicyFeatures(f,request),legalMasks:f.legalMasks,
      labels,actions,publicRequest:request,supervisionTargetTick:future?.tick??null,
      labelDelayTicks:labelDelay,futureStateInObservation:false,
      supervisionWeight:1,ppoEligible:false,
      labelEvidence:['offline-expert-on-actual-learner-state'],
      actualLearnerActions:f.actions,expertReason:advice?.reason||'no-complete-future-label',
      ...(advice?.movementTeaching?{movementTeaching:advice.movementTeaching}:{})})
  }
  const rawSha256=crypto.createHash('sha256').update(bytes).digest('hex')
  const prior=preserved.get(match)
  const split=daggerBoutSplit(prior,rawSha256,index===matches.length-1?'validation':'train')
  const shieldFraction=raw.filter(r=>r.seen?.shield).length/raw.length
  dataset.trajectories.push({source:match+'-dagger',sourceKind:'dagger-expert-relabel',
    sourceSha256:rawSha256,expertSourceSha256:sourceSha256,
    matchId:match,fighter:'Punengbho',opponent:raw.find(r=>r.observedOpponentMotion)?.observedOpponentMotion.opponent||'unknown',split,
    lesson:explicitLesson||prior?.lesson||(expertName==='joint-melee'?(shieldFraction>.35?'shield-state-transitions':'joint-state-transitions'):'close-critical'),
    observationsFromLearner:true,frames})
  audit.push({match,rolloutFile,split,frames:frames.length,labelDelayTicks:labelDelay,
    expertAttacks:frames.filter(f=>f.labels[4]===2).length,
    expertJumps:frames.filter(f=>f.labels[2]===1).length,sourcePolicySha256:raw.find(f=>f.policySha)?.policySha,
    originalSplitPreserved:prior?split===prior.split:null})
}
dataset.datasetMethod='DAgger aggregation: original exact demos plus expert relabels on learner states'
const counts=validateDataset(dataset)
fs.mkdirSync(path.join(dest,'source'),{recursive:true})
const frozen=path.join(dest,'source','checkpoint.json')
if(fs.existsSync(frozen)&&JSON.parse(fs.readFileSync(frozen)).sha256!==manifest.sha256)
  throw Error('Incomplete round preserved a different source checkpoint')
for(const n of ['checkpoint.json',manifest.binary]){
  const target=path.join(dest,'source',n)
  if(!fs.existsSync(target))fs.copyFileSync(path.join(live,n),target)
}
fs.writeFileSync(path.join(dest,'dataset.json'),JSON.stringify(dataset))
fs.writeFileSync(path.join(dest,'dataset-audit.json'),JSON.stringify({audit,counts,expertSourceSha256:sourceSha256,
  sourceSha256:manifest.sha256,preservedSplitsFrom:preserveFile,teacherLabelsAreExecutedActions:false,ppoEligible:false},null,2))
console.log(JSON.stringify({dest,audit,counts,sourceSha256:manifest.sha256}))
