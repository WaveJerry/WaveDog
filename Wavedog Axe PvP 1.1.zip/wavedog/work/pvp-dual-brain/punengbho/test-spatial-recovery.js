import assert from 'node:assert/strict'
import {publicSpatialFeatures as geometry}from '../public-spatial-features.js'
import {retreatPurposeSupervision as teach}from './retreat-purpose-supervision.js'
const q=(x,z,walls)=>({self:{x:0,y:0,z:0,held:7,charge:.5,eyeY:1.62},seen:{visible:true,x,y:0,z},publicTerrain:{walls}})
const cases=[[0,3.4,[8,8,.5,8]],[3.4,0,[.5,8,8,8]],[0,-3.4,[8,8,8,.5]],[-3.4,0,[8,.5,8,8]]]
const base=geometry(q(...cases[0]))
for(const c of cases)assert.deepEqual(geometry(q(...c)),base,'enemy-relative geometry is invariant across four spawn directions')
const a={labels:{0:1,1:1,4:0,5:0,6:0},actions:[1,1,0,0,0,0,0,3,0],reason:'axe-spacing-committed-recovery'}
let r=teach(a,q(0,3.3,[8,8,8,8]))
assert.equal(r.labels[6],6);assert.equal(r.labels[0],2,'nearby threat uses face-on spacing, not backwards-facing forward sprint')
r=teach(a,q(...cases[0]));assert.equal(r.labels[0],0);assert.equal(r.labels[6],6)
const ready=q(0,4.5,[8,8,.5,8]);ready.self.charge=1
r=teach(a,ready);assert.equal(r.labels[0],1);assert.equal(r.labels[6],6,'charged axe leaves wall and reengages')
assert.equal(r.labels[4],a.labels[4]);assert.equal(r.labels[5],a.labels[5],'locomotion teaching cannot invent attacks or weapons')
console.log('SPATIAL_ROTATION_NEAR_FACING_AND_BLOCKED_ESCAPE_PASS')
