"""Exact successful teacher inputs versus an ordinary shield-changing player.

Both are temporary script probes; neither is the model or the main WaveDog.
Records only evidence available to ordinary protocol clients. Shield cooldown
is confirmed; native critical flags are explicitly unavailable in this source.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,runpy,shutil,subprocess,time,uuid
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
p=argparse.ArgumentParser();p.add_argument('--offset',type=int,default=0);p.add_argument('--seconds',type=int,default=12)
p.add_argument('--distance',type=float,default=1.5)
p.add_argument('--teacher-carries-unused-shield',action='store_true')
p.add_argument('--teacher-carries-unused-ranged',action='store_true')
p.add_argument('--defender-starts-with-crossbow',action='store_true');a=p.parse_args()
if not 1<=a.distance<=3.3 or not 5<=a.seconds<=20:raise ValueError('Bounded third-cage exercise required')
if 'desired=0 'not in command('selfplay status'):raise RuntimeError('Preserve ongoing selfplay')
players=command('list')
if any(name in players for name in ['WaveDogSon','WDShieldTrial']):raise RuntimeError('Existing test players preserved')
# This isolated cage can contain gear from earlier deaths. Picked-up duplicate
# weapons must not silently change the demonstrated action vocabulary.
command('kill @e[type=minecraft:item,x=1122.5,y=221,z=960.5,distance=..16]')
stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S');match=str(uuid.uuid4())
dest=BASE/f'shield-teaching-{stamp}';dest.mkdir()
teacher_dir=dest/'teacher';teacher_dir.mkdir()
defender_dir=BASE/'shield-demo-defender-runtime';defender_dir.mkdir(exist_ok=True)
shutil.copy2(ROOT/'work/wavedog-protocol/runtime/probe-auth.json',teacher_dir/'probe-auth.json')
feedback=dest/'defender-public-feedback.jsonl';raw=dest/'teacher-raw.jsonl'
actors=[];streams=[]
def order(folder,target,mode,active,record=False):
    row={'target':target,'mode':mode,'active':active,'matchId':match,'requestedStartDistance':a.distance,
         'shieldCycleOffset':a.offset}
    if record:row['prepareSlot']=7
    elif a.defender_starts_with_crossbow:row['prepareSlot']=4
    if record:row['demonstrationFile']=str(raw)
    tmp=folder/'probe-command.tmp';tmp.write_text(json.dumps(row));os.replace(tmp,folder/'probe-command.json')
def spawn(name,folder,record=False):
    env=os.environ.copy();env.update(WAVEDOG_PROBE_NAME=name,WAVEDOG_PROBE_RUNTIME=str(folder))
    if not record:env['WAVEDOG_PROBE_FEEDBACK']=str(feedback)
    out=(dest/(name+'.out.log')).open('wb');err=(dest/(name+'.err.log')).open('wb');streams.extend([out,err])
    proc=subprocess.Popen([shutil.which('node'),str(ROOT/'work/pvp-player-client/protocol-wavedog-probe.js')],
        cwd=ROOT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    actors.append(proc)
    deadline=time.monotonic()+40
    while name not in command('list'):
        if proc.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Probe login failed: '+name)
        time.sleep(.25)
    command('authme forcelogin '+name);time.sleep(.5)
    command('gamemode survival '+name)
    command('clear '+name)
    command('effect clear '+name)
    command(f'effect give {name} minecraft:instant_health 1 10 true')
    command(f'effect give {name} minecraft:saturation 1 10 true')
    for slot,item in [('head','helmet'),('chest','chestplate'),('legs','leggings'),('feet','boots')]:
        command(f'item replace entity {name} armor.{slot} with minecraft:diamond_{item}')
    command(f'item replace entity {name} hotbar.0 with minecraft:diamond_sword')
    command(f'item replace entity {name} hotbar.7 with minecraft:diamond_axe')
    command(f'item replace entity {name} weapon.offhand with '+
        ('minecraft:air'if record and not a.teacher_carries_unused_shield else'minecraft:shield'))
    if record and a.teacher_carries_unused_ranged:
        command(f'item replace entity {name} hotbar.1 with minecraft:bow')
        command(f'item replace entity {name} hotbar.4 with minecraft:crossbow[charged_projectiles=[{{id:"minecraft:arrow",count:1}}]]')
        command(f'item replace entity {name} hotbar.8 with minecraft:arrow 5')
    if not record and a.defender_starts_with_crossbow:
        command(f'item replace entity {name} hotbar.4 with minecraft:crossbow[charged_projectiles=[{{id:"minecraft:arrow",count:1}}]]')
try:
    order(teacher_dir,'WDShieldTrial','critical-switch',False,True)
    order(defender_dir,'WaveDogSon','shield-cycle',False)
    spawn('WaveDogSon',teacher_dir,True);spawn('WDShieldTrial',defender_dir)
    command('tp WaveDogSon 1122.5 221 960.5 -90 0')
    defender_yaw=-90 if a.defender_starts_with_crossbow else 90
    command(f'tp WDShieldTrial {1122.5+a.distance} 221 960.5 {defender_yaw} 0')
    time.sleep(.5)
    if not a.defender_starts_with_crossbow:order(defender_dir,'WaveDogSon','shield-cycle',True)
    order(teacher_dir,'WDShieldTrial','critical-switch',True,True)
    if a.defender_starts_with_crossbow:
        # A bounded demonstration of responding to a close player who is
        # holding a crossbow before turning to melee; not a fair win-rate test.
        time.sleep(.15);order(defender_dir,'WaveDogSon','shield-cycle',True)
    print(json.dumps({'stage':'script-demonstration','matchId':match,'offset':a.offset,'modelControlsReplaced':False}),flush=True)
    deadline=time.monotonic()+a.seconds
    while time.monotonic()<deadline:
        if any(p.poll()is not None for p in actors):raise RuntimeError('Ordinary probe disconnected')
        time.sleep(.25)
    order(teacher_dir,'WDShieldTrial','critical-switch',False,True);order(defender_dir,'WaveDogSon','shield-cycle',False)
    rows=[json.loads(s)for s in raw.read_text().splitlines()]
    for row in rows:
        if row.get('type')!='frame':continue
        expected={0:'diamond_sword',7:'diamond_axe'}.get(row.get('held'))
        if expected is None or row.get('heldItemName')!=expected:
            raise RuntimeError('Unrepresentable teacher weapon slot; raw retained outside dataset')
    evidence=[json.loads(s)for s in feedback.read_text().splitlines()]
    cooldowns=[e for e in evidence if e.get('matchId')==match and e.get('type')=='shield-cooldown' and e.get('cooldownTicks',0)>0]
    hits=[r for r in rows if r.get('attackPacket')]
    axe=[r for r in hits if r.get('held')==7]
    chains=[]
    for e in cooldowns:
        matching=[r for r in axe if -100<=e['capturedAt']-r['at']<=600]
        if not matching:continue
        hit=max(matching,key=lambda r:r['at'])
        sword=[r for r in hits if r.get('held')==0 and 0<r['at']-hit['at']<=1500]
        if sword:chains.append({'axeTick':hit['tick'],'cooldownTicks':e['cooldownTicks'],'nextSwordTick':sword[0]['tick']})
    if not chains:raise RuntimeError('No verified axe/cooldown/sword packet sequence; raw evidence retained outside dataset')
    with raw.open('a',encoding='utf-8')as f:f.write(json.dumps({'type':'end','complete':True,'matchId':match,
        'nativeFeedbackFrames':str(feedback),'feedbackEvidence':'ordinary-defender-client-health-and-shield-cooldown',
        'nativeCriticalEvidenceAvailable':False,'outcome':{'reason':'bounded-teaching-window-ended'},
        'shieldBreakSwordPacketSequences':chains})+'\n')
    target=BASE/'demonstrations'/f'{stamp}-critical-switch.jsonl';shutil.copy2(raw,target)
    result={'matchId':match,'exactDemonstration':str(target),'confirmedShieldBreaks':len(cooldowns),
        'teacherCarriesUnusedShield':a.teacher_carries_unused_shield,
        'teacherCarriesUnusedRanged':a.teacher_carries_unused_ranged,
        'defenderStartsWithCrossbow':a.defender_starts_with_crossbow,
        'competitiveWinRateTrial':False,
        'axePackets':len(axe),'swordPackets':sum(r.get('held')==0 for r in hits),'verifiedSequences':chains,
        'nativeCriticals':'unavailable-from-this-client-only-source','modelLearningClaimed':False}
    (dest/'receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
finally:
    order(teacher_dir,'WDShieldTrial','critical-switch',False,True);order(defender_dir,'WaveDogSon','shield-cycle',False)
    for proc in actors:
        if proc.poll()is None:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for stream in streams:stream.close()
