import * as tf from '@tensorflow/tfjs'
import {OBS_SIZE,biasedActionLogits,maskActionLogits} from '../fresh-policy.js'
import {legalMasks,decode} from './pure-actions.js'
import {chooseAction} from './action-selection.js'
import {publicHealthFeatures} from '../public-health-features.js'
import {publicSpatialFeatures} from '../public-spatial-features.js'
import {publicThreatFeatures} from '../public-threat-features.js'
import {publicMotionFeatures} from '../public-motion-features.js'
import {conditionCombatObservation} from '../combat-observation.js'
import {conditionTechniqueObservation} from '../technique-conditioning.js'
import {meleeEntryContext,meleeTechniqueGoal} from '../fresh-melee-progress.js'

export function refinementRejection(actor,req){
  const config=actor?.policy?.model.config
  if(!actor||actor.matchId!==req.matchId||actor.opponent!==req.opponent)return 'changed-bout'
  if(config?.wholeFightControlVersion!==1||config.sameTickRefinementVersion!==1||config.publicMotionInputs!==32
      ||config.behaviorPriorVersion!==0)return 'checkpoint-not-trained-for-refinement'
  // Until event-level PPO replay exists, every real refinement is an immutable
  // BC evaluation, preserved with its input/action rather than fake PPO ticks.
  if(config.trainingStage!=='behavior-cloning')return 'subtick-ppo-replay-not-enabled'
  if(req.tick!==actor.lastObservedTick||!actor.state?.slow)return 'physical-anchor-changed'
  if(!Number.isSafeInteger(req.controlRevision)||req.controlRevision<=(actor.lastRefinementRevision??-1))return 'old-control-revision'
  if(req.publicMotionAnalysis?.revision!==req.observationRevision
      ||publicMotionFeatures(req)[0]!==1)return 'stale-motion-source'
  return null
}
export function refinePublicAction(actor,req,publicObservation){
  const reason=refinementRejection(actor,req)
  if(reason)throw Error(reason)
  if(!Array.isArray(publicObservation)||publicObservation.length!==OBS_SIZE)throw Error('Public observation shape mismatch')
  const model=actor.policy.model,config=model.config
  const context={...meleeEntryContext(actor.previousPublic,req,actor.previousContext),
    distributionVersion:config.distributionVersion||1,behaviorPriorVersion:config.behaviorPriorVersion,
    weaponConditionedAttack:config.weaponConditionedAttack||0,
    actionConditionedAttack:config.actionConditionedAttack||0,
    ...(config.distributionVersion>=3?{calibratedHeads:config.calibratedHeads||[2,5]}:{})}
  const {focus,techniqueCues}=meleeTechniqueGoal(req,context)
  const observation=conditionCombatObservation(conditionTechniqueObservation(publicObservation,focus,techniqueCues,
    req.arenaBounds?{self:req.self,bounds:req.arenaBounds}:null,
    req.publicTerrain?{...req.publicTerrain,selfY:req.self?.y}:null),req,config)
  const health=publicHealthFeatures(req),spatial=publicSpatialFeatures(req),threat=publicThreatFeatures(req),motion=publicMotionFeatures(req)
  const masks=legalMasks(req,config),started=performance.now()
  const result=tf.tidy(()=>{
    const output=model.refine(tf.tensor2d([observation]),actor.state,masks,health,spatial,threat,motion)
    const logits=biasedActionLogits(output.logits,observation,context)
    const probabilities=maskActionLogits(logits,masks).map(h=>[...tf.softmax(h).dataSync()])
    const actions=probabilities.map(p=>chooseAction(p,true))
    if([1,2].includes(context.weaponConditionedAttack)||context.actionConditionedAttack===1){
      const conditional=maskActionLogits(biasedActionLogits(output.logits,observation,context,actions,model,health),masks)
      probabilities[4]=[...tf.softmax(conditional[4]).dataSync()];actions[4]=chooseAction(probabilities[4],true)
    }
    return {actions,probabilities}
  })
  actor.lastRefinementRevision=req.controlRevision
  return {...decode(req,result.actions,config),event:'refined_action',matchId:req.matchId,
    controlRevision:req.controlRevision,observationRevision:req.observationRevision,
    baseTick:actor.lastObservedTick,checkpointSha256:actor.policy.manifest.sha256,
    refinementTiming:{policyMs:performance.now()-started},recurrentMemoryAdvanced:false,
    ppoEligible:false,actions:result.actions,probabilities:result.probabilities,
    inputEvidence:{observation,publicHealthFeatures:health,publicSpatialFeatures:spatial,
      publicThreatFeatures:threat,publicMotionFeatures:motion,context,legalMasks:masks}}
}
