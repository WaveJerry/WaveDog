import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'
import { advance, disposeState } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const [source, candidate, destination, ...rollouts] = process.argv.slice(2)
if (!rollouts.length) throw Error('Need independent previously recorded PPO rollouts')
const left = loadDualCheckpoint(source), right = loadDualCheckpoint(candidate)
left.adam.dispose(); right.adam.dispose()
const report = { sourceSha256: left.manifest.sha256, candidateSha256: right.manifest.sha256,
  rollouts: [], heads: {}, modelWeightsChanged: false, livePvpImprovementVerified: false }
try {
  for (const file of rollouts) {
    const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    let beforeState = left.model.initialState(), afterState = right.model.initialState()
    try {
      for (const frame of rollout.episode) {
        const before = advance(left.model, beforeState, frame.observation, true); beforeState = before.state
        const after = advance(right.model, afterState, frame.observation, true); afterState = after.state
        const probabilities = [before, after].map(result => tf.tidy(() => {
          const logits = result.logits.map(values => tf.tensor2d([values]))
          return maskActionLogits(biasedActionLogits(logits, frame.observation, frame.context, frame.actions), frame.legalMasks)
            .map(head => [...tf.softmax(head).dataSync()])
        }))
        for (let h = 0; h < probabilities[0].length; h++) {
          if (!frame.executedHeads[h]) continue
          const p = probabilities[0][h], q = probabilities[1][h]
          const kl = Math.max(0, p.reduce((sum, value, i) => sum + (value ? value * Math.log(value / Math.max(1e-30, q[i])) : 0), 0))
          const item = report.heads[h] ||= { frames: 0, klSum: 0, maxKL: 0, argmaxChanges: 0 }
          item.frames++; item.klSum += kl; item.maxKL = Math.max(item.maxKL, kl)
          item.argmaxChanges += p.indexOf(Math.max(...p)) !== q.indexOf(Math.max(...q)) ? 1 : 0
        }
      }
    } finally { disposeState(beforeState); disposeState(afterState) }
    report.rollouts.push({ path: file, rolloutSeq: rollout.rolloutSeq, frames: rollout.episode.length })
    console.log(JSON.stringify({ auditedRollout: rollout.rolloutSeq, frames: rollout.episode.length }))
  }
  for (const item of Object.values(report.heads)) { item.meanKL = item.klSum / item.frames; delete item.klSum }
  report.retentionPassed = [0, 1, 2, 3, 6, 7, 8].every(head => !report.heads[head] || report.heads[head].meanKL < .02)
  fs.writeFileSync(destination, JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report))
} finally { left.model.dispose(); right.model.dispose() }
