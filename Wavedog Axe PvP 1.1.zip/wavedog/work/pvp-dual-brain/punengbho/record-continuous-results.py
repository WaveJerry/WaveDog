"""Keep a bounded live acceptance report; never turn a skill hit into a win claim."""
from pathlib import Path
from importlib.machinery import SourceFileLoader
from datetime import datetime,timezone
import json

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
LIVE=ROOT/'outputs/punengbho-integration-20261117'
candidate=json.loads((BASE/'continuous-close-install/checkpoint.json').read_text())
audit=SourceFileLoader('continuous_live_audit',str(Path(__file__).with_name('audit-foundation-trial.py'))).load_module()
matches={'989ff8f0-b41e-48df-8902-c4af9fefd1fb','cc128c85-7d45-4ee7-b161-8a9f22c17643',
         'a9173b6b-eac3-4790-92d1-bb2da1cfd599','c4284436-3144-459a-9b86-108be4ffc15d'}
trials=[]
for file in sorted(LIVE.glob('live-*/summary.json')):
    s=json.loads(file.read_text())
    if s['matchId']not in matches:continue
    frames=[json.loads(x)for x in Path(s['frameFile']).read_text().splitlines()]
    policies={r['policySha']for r in frames if r.get('policySha')}
    assert policies=={candidate['sha256']},'Trial belongs to a different policy'
    r=(audit.audit if s['meleeOnlyScenario']else audit.audit_carried_kit)(s,frames)
    target=file.parent/'foundation-audit.json'
    if target.exists():assert json.loads(target.read_text())==r,'Preserve original acceptance evidence'
    else:target.write_text(json.dumps(r,indent=2))
    trials.append({'summary':str(file),'acceptance':str(target),'matchId':s['matchId'],
        'mode':s['opponentMode'],'meleeOnly':s['meleeOnlyScenario'],'won':s['outcome']['winner']=='Punengbho',
        'damageDealt':s['nativeDamage'],'damageReceived':s['receivedDamage'],
        'passed':r['passed'],'failedChecks':[k for k,v in r['checks'].items()if not v],
        'swordCriticals':r['nativeSwordCriticals'],'longestChain':r['longestNativeSwordCriticalChain'],
        'groundedSprintEdgeHits':r['nativeGroundedSprintEdgeHits'],
        'shieldResponseTicks':r['shieldResponseTicks'],
        'verifiedShieldBreakSwordSequences':r['verifiedShieldBreakSwordSequences']})
assert {t['matchId']for t in trials}==matches,'Missing live trial'
main=json.loads((ROOT/'work/pvp-8.6-dual-fresh/model/checkpoint.json').read_text())
assert main['sha256']=='f156a08a7afc4c917172a77486ba0580f01ff052217965e6e93430b0347585ca'
result={'at':datetime.now(timezone.utc).isoformat(),'candidateSha256':candidate['sha256'],
    'deploymentTarget':'WaveDog_Punengbho','mainWaveDogModified':False,'mainMinecraftRestarted':False,
    'mainWaveDogSha256':main['sha256'],'trials':trials,'allBasicScenariosPassed':all(t['passed']for t in trials),
    'tacticalMasteryVerified':False,'ppoUpdatedDuringAcceptance':False,
    'mechanicalPrecisionWorkStarted':False,'nextDataset':'continuous-close-live-dagger/dataset.json',
    'nextFocus':['recover grounded sprint edge interruption','stabilize close critical continuation after knockback'],
    'nextDatasetIsCounterfactualSupervisionNotExecutedPpo':True}
target=BASE/'continuous-close-live-report.json'
if target.exists():raise RuntimeError('Preserve previous live report')
target.write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
