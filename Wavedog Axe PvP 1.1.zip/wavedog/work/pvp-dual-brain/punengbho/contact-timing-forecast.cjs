'use strict'
// Offline teaching only. Native own velocity is post-drag; public opponent
// velocity is displacement per sample tick. Do not subtract the two as though
// they were the same phase of the physics step. This is a local forecast, not
// a guarantee of the opponent's future inputs or of a hit/knockback outcome.
const {eyeReach}=require('../../pvp-player-client/probe-edge-controller')
function contactArrival(request,{horizon=80}={}){
 const s=request.self,t=request.seen,o=request.publicActionContext,v=o?.targetVelocity
 if(!s||!t?.visible||!v||![s.x,s.y,s.z,s.eyeY,t.x,t.y,t.z,v.x,v.y,v.z].every(Number.isFinite))
  return {valid:false,ticks:null,reason:'unknown-public-motion'}
 let p={x:s.x,y:s.y,z:s.z},q={x:t.x,y:t.y,z:t.z},vx=s.vx||0,vz=s.vz||0
 const height=s.eyeY-s.y,ground=s.ground===true,accel=ground?(s.food<=6?.1:.13):.026,
  drag=ground?.546:.91
 const reach=()=>Math.min(eyeReach(p,height,{position:q,width:.6,height:1.8}),
  eyeReach(q,1.62,{position:p,width:.6,height:1.8}))
 if(reach()<=3)return {valid:true,ticks:0,reason:'already-contactable'}
 for(let tick=1;tick<=horizon;tick++){
  const dx=q.x-p.x,dz=q.z-p.z,d=Math.hypot(dx,dz)
  if(d>.001){vx+=dx/d*accel;vz+=dz/d*accel}
  p.x+=vx;p.z+=vz;vx*=drag;vz*=drag
  q.x+=v.x;q.z+=v.z
  // Airborne vertical forecasts already live in the public threat input.
  // Do not extrapolate y upward forever and call a horizontal rush remote.
  if(reach()<=3)return {valid:true,ticks:tick,reason:'observed-motion-and-normal-approach'}
 }
 return {valid:true,ticks:Infinity,reason:'no-contact-in-local-horizon'}
}
function distantAxePreparation(request){
 const f=contactArrival(request)
 // Infinity is not an observed future engagement. Unknown/no-contact cases
 // keep the default sword rather than manufacturing a distant axe opener.
 return f.valid&&Number.isFinite(f.ticks)&&f.ticks>20
}
module.exports={contactArrival,distantAxePreparation}
