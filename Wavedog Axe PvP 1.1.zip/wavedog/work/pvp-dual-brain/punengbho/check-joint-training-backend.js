// Offline numerical/backend check. Does not save or install a model.
import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {deployedImitationLogits,disposeState} from '../human-imitation.js'
const [source,dataset,runtime,dest]=process.argv.slice(2)
assert(source&&dataset&&runtime&&dest&&!fs.existsSync(dest))
const native=process.argv.includes('--native')
if(native)await import(pathToFileURL(path.resolve(runtime,'node_modules/@tensorflow/tfjs-node/dist/index.js')))
else{
 const wasm=await import(pathToFileURL(path.resolve(runtime,'node_modules/@tensorflow/tfjs-backend-wasm/dist/tf-backend-wasm.node.js')))
 wasm.setThreadsCount(1)
 wasm.setWasmPaths(path.resolve(runtime,'node_modules/@tensorflow/tfjs-backend-wasm/dist')+path.sep)
}
const data=JSON.parse(fs.readFileSync(dataset)),segment=data.trajectories.find(t=>t.split==='train'&&t.frames.length>=24).frames.slice(0,24)
const results=[]
for(const backend of ['cpu',native?'tensorflow':'wasm']){
 await tf.setBackend(backend);await tf.ready()
 const loaded=loadDualCheckpoint(source),model=loaded.model,initial=model.initialState(),started=performance.now()
 try{
  const result=tf.tidy(()=>{
   const {value,grads}=tf.variableGrads(()=>{
    let state=initial;const terms=[]
    for(const f of segment){
     const out=model.step(tf.tensor2d([f.observation]),state,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures);state=out.state
     const logits=deployedImitationLogits(model,out.logits,f)
     for(const[h,a]of Object.entries(f.labels))terms.push(tf.neg(tf.logSoftmax(logits[h]).slice([0,a],[1,1]).reshape([])))
    }
    return tf.mean(tf.stack(terms))
   },model.params)
   const gradientNorm=Math.sqrt(tf.addN(Object.values(grads).map(g=>tf.sum(tf.square(g)))).dataSync()[0])
   const groups={}
   for(const p of model.params){
    const name=p.name.replace(/^dual\d+\./,'').split('.')[0],g=grads[p.name]
    if(g)groups[name]=(groups[name]||0)+tf.sum(tf.abs(g)).dataSync()[0]
   }
   return {backend,loss:value.dataSync()[0],gradientNorm,groups,elapsedMs:performance.now()-started}
  })
  assert(Number.isFinite(result.loss)&&Number.isFinite(result.gradientNorm)&&result.gradientNorm>0)
  for(const g of ['fast','slow-0','slow-1','slow-2','slow-3','gate-in'])assert(result.groups[g]>0,'No gradient: '+g)
  results.push(result)
 }finally{disposeState(initial);loaded.adam.dispose();model.dispose()}
}
const relative=(a,b)=>Math.abs(a-b)/Math.max(1,Math.abs(a),Math.abs(b))
assert(relative(results[0].loss,results[1].loss)<1e-4,'Backend loss mismatch')
assert(relative(results[0].gradientNorm,results[1].gradientNorm)<1e-3,'Backend gradient mismatch')
const report={passed:true,results,liveStateMutated:false,weightCheckpointWritten:false}
fs.writeFileSync(dest,JSON.stringify(report,null,2));console.log(JSON.stringify(report))
