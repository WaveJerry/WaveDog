// Sparse native-event imitation. Human records are never passed off as PPO.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { pathToFileURL } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE } from './fresh-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'

export function stateTensors (state) {
  return [...new Set([state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])].filter(Boolean))]
}
export function disposeState (state, retained = null) {
  const keep = new Set(retained ? stateTensors(retained) : [])
  for (const tensor of stateTensors(state)) if (!keep.has(tensor)) tensor.dispose()
}
export function advance (model, state, observation, capture = false) {
  const out = tf.tidy(() => {
    const output = model.step(tf.tensor2d([observation], [1, OBS_SIZE]), state)
    return { state: output.state, ...(capture ? {
      logits: output.logits.map(head => [...head.dataSync()]),
      value: output.value.dataSync()[0], gate: [...output.gate.dataSync()]
    } : {}) }
  })
  disposeState(state, out.state)
  return out
}
const logSoftmax = values => {
  const largest = Math.max(...values)
  const normalizer = largest + Math.log(values.reduce((sum, value) => sum + Math.exp(value - largest), 0))
  return values.map(value => value - normalizer)
}
export function validateDataset (dataset) {
  if (dataset.schema !== 'public-human-imitation-v1' || dataset.ppoEligible !== false)
    throw Error('Only explicitly non-PPO human demonstrations accepted')
  if (!dataset.trajectories?.length) throw Error('Full ordered trajectories required')
  const splitByMatch = new Map(), sources = new Set()
  const counts = { train: {}, validation: {} }
  for (const trace of dataset.trajectories) {
    if (!['train', 'validation'].includes(trace.split) || !trace.matchId || sources.has(trace.source))
      throw Error('Invalid or repeated source')
    sources.add(trace.source)
    // Recorder IDs include observer UUIDs. Pair both perspectives by run/tick
    // and unordered participants, so a second view cannot leak into training.
    const encounter = trace.source.match(/^(\d+-\d+)-/)
    const matchKey = encounter && trace.fighter && trace.opponent
      ? encounter[1] + ':' + [trace.fighter, trace.opponent].sort().join(':') : trace.matchId
    if (splitByMatch.has(matchKey) && splitByMatch.get(matchKey) !== trace.split)
      throw Error('Whole-match train/validation leakage')
    splitByMatch.set(matchKey, trace.split)
    let previous = -Infinity
    for (const frame of trace.frames) {
      if (!Number.isSafeInteger(frame.tick) || frame.tick <= previous
          || frame.observation.length !== OBS_SIZE || !frame.observation.every(Number.isFinite))
        throw Error('Invalid causal observation sequence')
      previous = frame.tick
      for (const [head, action] of Object.entries(frame.labels)) {
        if (!(head === '4' && action === 2 || head === '5' && [0, 1].includes(action)))
          throw Error('Unsupported or fabricated human label')
        counts[trace.split][head] = (counts[trace.split][head] || 0) + 1
      }
    }
  }
  if (!Object.keys(counts.train).length || !Object.keys(counts.validation).length)
    throw Error('Need separate training and validation evidence')
  return counts
}
function distributionKL (before, after) {
  const p = logSoftmax(before), q = logSoftmax(after)
  return Math.max(0, p.reduce((sum, value, i) => sum + Math.exp(value) * (value - q[i]), 0))
}
export function imitationLoss (model, segment, initialState, weights) {
  let state = initialState
  const supervised = [], anchors = []
  for (const frame of segment) {
    const output = model.step(tf.tensor2d([frame.observation], [1, OBS_SIZE]), state)
    state = output.state
    for (const [key, action] of Object.entries(frame.labels)) {
      const head = Number(key)
      supervised.push(tf.mul(weights[key], tf.neg(tf.sum(tf.mul(
        tf.oneHot([action], output.logits[head].shape[1]), tf.logSoftmax(output.logits[head]))))))
    }
    // Anchor every real frame, including heads whose human intent is unknown.
    // A frozen reference supplies distributions, never invented button labels.
    for (const [head, logits] of output.logits.entries()) {
      const reference = tf.tensor2d([frame.reference.logits[head]])
      const logP = tf.logSoftmax(reference)
      const kl = tf.sum(tf.mul(tf.exp(logP), tf.sub(logP, tf.logSoftmax(logits))))
      anchors.push(tf.mul(head in frame.labels ? .15 : 2, kl))
    }
    anchors.push(tf.mul(.05, tf.square(tf.sub(tf.squeeze(output.value), frame.reference.value))))
  }
  return tf.add(supervised.length ? tf.mean(tf.stack(supervised)) : tf.scalar(0),
    tf.mean(tf.stack(anchors)))
}
export function imitationUpdate (model, optimizer, segment, initialState, weights) {
  return tf.tidy(() => {
    const { value, grads } = tf.variableGrads(
      () => imitationLoss(model, segment, initialState, weights), optimizer.parameters)
    const gradientNorm = Math.sqrt(tf.addN(Object.values(grads).map(g => tf.sum(tf.square(g)))).dataSync()[0])
    if (!Number.isFinite(value.dataSync()[0]) || !Number.isFinite(gradientNorm))
      throw Error('Non-finite imitation loss/gradient')
    const scale = Math.min(1, 1 / Math.max(gradientNorm, 1e-12))
    optimizer.applyGradients(Object.fromEntries(Object.entries(grads).map(([key, grad]) => [key, tf.mul(grad, scale)])))
    return { loss: value.dataSync()[0], gradientNorm }
  })
}
const parameterGroup = variable => variable.name.replace(/^dual\d+\./, '').split('.')[0]
function parameterAudit (model, baseline) {
  const groups = {}
  for (let i = 0; i < model.params.length; i++) {
    const name = parameterGroup(model.params[i]), left = baseline.params[i].dataSync(), right = model.params[i].dataSync()
    const item = groups[name] ||= { parameters: 0, changed: 0, squaredDelta: 0, maxAbsDelta: 0 }
    for (let j = 0; j < left.length; j++) {
      const delta = right[j] - left[j]
      item.parameters++; if (delta !== 0) item.changed++
      item.squaredDelta += delta * delta
      item.maxAbsDelta = Math.max(item.maxAbsDelta, Math.abs(delta))
    }
  }
  for (const item of Object.values(groups)) {
    item.rmsDelta = Math.sqrt(item.squaredDelta / item.parameters); delete item.squaredDelta
  }
  return groups
}
function accumulate (stats, frame, result, reference = null) {
  for (const [head, action] of Object.entries(frame.labels)) {
    const logP = logSoftmax(result.logits[head])
    const key = `${head}:${action}`
    const item = stats.labels[key] ||= { count: 0, nll: 0, probability: 0, correct: 0 }
    item.count++; item.nll -= logP[action]; item.probability += Math.exp(logP[action])
    item.correct += logP.indexOf(Math.max(...logP)) === action ? 1 : 0
  }
  if (reference) for (let head = 0; head < result.logits.length; head++) {
    const kl = distributionKL(reference.logits[head], result.logits[head])
    const item = stats.drift[head] ||= { frames: 0, sum: 0, max: 0 }
    item.frames++; item.sum += kl; item.max = Math.max(item.max, kl)
  }
}
function finishStats (stats) {
  let nll = 0, count = 0
  for (const item of Object.values(stats.labels)) {
    nll += item.nll; count += item.count
    item.nll /= item.count; item.probability /= item.count; item.accuracy = item.correct / item.count
    delete item.correct
  }
  stats.meanNll = count ? nll / count : null
  for (const item of Object.values(stats.drift)) { item.mean = item.sum / item.frames; delete item.sum }
  return stats
}
async function main () {
  const [sourceArg, datasetArg, destinationArg] = process.argv.slice(2)
  if (!sourceArg || !datasetArg || !destinationArg) throw Error('Usage: human-imitation.js SOURCE DATASET NEW_FOLDER')
  const source = path.resolve(sourceArg), destination = path.resolve(destinationArg)
  if (destination === path.dirname(source) || fs.existsSync(path.join(destination, 'checkpoint.json')))
    throw Error('Candidate destination must be new and isolated from source')
  const datasetBytes = fs.readFileSync(datasetArg), dataset = JSON.parse(datasetBytes)
  const counts = validateDataset(dataset)
  fs.mkdirSync(destination, { recursive: true })
  const log = row => {
    const line = JSON.stringify({ at: new Date().toISOString(), ...row })
    fs.appendFileSync(path.join(destination, 'training-events.jsonl'), line + '\n'); console.log(line)
  }
  await tf.setBackend('cpu'); await tf.ready()
  const candidate = loadDualCheckpoint(source), reference = loadDualCheckpoint(source)
  const { model } = candidate
  const trainable = [model.fast, model.slowToken, ...model.slowBlocks,
    model.fastHeads[4], model.fastHeads[5], model.slowHeads[4], model.slowHeads[5],
    model.gateIn, model.gateOut].flatMap(layer => layer.params)
  const optimizer = new SharedAdam(trainable, { learningRate: Number(process.env.IMITATION_LR || .000003) })
  const beforeStats = { train: { labels: {}, drift: {} }, validation: { labels: {}, drift: {} } }
  const afterStats = structuredClone(beforeStats)
  const weights = Object.fromEntries(Object.entries(counts.train).map(([head, count]) =>
    [head, Object.values(counts.train).reduce((a, b) => a + b, 0) / (Object.keys(counts.train).length * count)]))
  const updates = [], sourceHash = candidate.manifest.sha256
  try {
    // The reference sees every tick, retaining whole-bout recurrent memory.
    // Both perspectives of the held-out match remain outside gradient updates.
    for (const trace of dataset.trajectories) {
      let state = reference.model.initialState()
      try {
        for (const frame of trace.frames) {
          const output = advance(reference.model, state, frame.observation, true); state = output.state
          frame.reference = { logits: output.logits, value: output.value, gate: output.gate }
          accumulate(beforeStats[trace.split], frame, output)
        }
      } finally { disposeState(state) }
      log({ stage: 'baseline-replay', source: trace.source, frames: trace.frames.length, split: trace.split })
    }
    for (const trace of dataset.trajectories.filter(trace => trace.split === 'train')) {
      let state = model.initialState()
      try {
        for (let start = 0; start < trace.frames.length; start += 16) {
          const part = trace.frames.slice(start, start + 16)
          const labeled = part.some(frame => Object.keys(frame.labels).length)
          if (labeled || start % 128 === 0) {
            const update = imitationUpdate(model, optimizer, part, state, weights)
            updates.push({ source: trace.source, start, end: start + part.length,
              labels: part.reduce((sum, frame) => sum + Object.keys(frame.labels).length, 0), ...update })
          }
          for (const frame of part) state = advance(model, state, frame.observation).state
        }
      } finally { disposeState(state) }
      log({ stage: 'imitation-training', source: trace.source, updates: updates.length })
    }
    for (const trace of dataset.trajectories) {
      let state = model.initialState()
      try {
        for (const frame of trace.frames) {
          const output = advance(model, state, frame.observation, true); state = output.state
          accumulate(afterStats[trace.split], frame, output, frame.reference)
        }
      } finally { disposeState(state) }
      log({ stage: 'candidate-replay', source: trace.source, frames: trace.frames.length })
    }
    for (const stats of [beforeStats, afterStats]) for (const split of ['train', 'validation']) finishStats(stats[split])
    const audit = parameterAudit(model, reference.model)
    const changedFast = audit.fast?.changed > 0
    const changedSlow = Object.entries(audit).some(([name, item]) => name.startsWith('slow-') && item.changed > 0)
    const validationImproved = afterStats.validation.meanNll < beforeStats.validation.meanNll
    const unrelatedHeads = [0, 1, 2, 3, 6, 7, 8]
    const driftOK = unrelatedHeads.every(head => afterStats.validation.drift[head].mean < .02)
    const counters = { ...candidate.counters,
      humanImitationUpdates: (candidate.counters.humanImitationUpdates || 0) + updates.length,
      humanImitationNativeLabels: (candidate.counters.humanImitationNativeLabels || 0)
        + Object.values(counts.train).reduce((a, b) => a + b, 0),
      humanImitationSourceSha256: sourceHash }
    // Keep original PPO Adam moments/counter. Imitation uses its own optimizer.
    const saved = saveDualCheckpoint(path.join(destination, 'checkpoint.json'), model, candidate.adam, counters)
    const receipt = { schema: 'human-imitation-receipt-v1', at: new Date().toISOString(), source,
      sourceSha256: sourceHash, datasetSha256: crypto.createHash('sha256').update(datasetBytes).digest('hex'),
      saved, counts, before: beforeStats, after: afterStats, parameterAudit: audit,
      updates, imitationOptimizer: { learningRate: optimizer.learningRate, steps: optimizer.steps,
        separateFromPPO: true },
      ppoCountersPreserved: candidate.counters.dualUpdates === counters.dualUpdates,
      checks: { changedFast, changedSlow, validationImproved, unrelatedHeadDriftOK: driftOK },
      offlineChecksPassed: changedFast && changedSlow && validationImproved && driftOK,
      livePvpImprovementVerified: false, sourceCheckpointOverwritten: false }
    fs.writeFileSync(path.join(destination, 'receipt.json'), JSON.stringify(receipt, null, 2))
    log({ stage: 'complete', checkpoint: saved.manifest, checks: receipt.checks,
      validationBefore: beforeStats.validation.meanNll, validationAfter: afterStats.validation.meanNll,
      ppoUpdates: counters.dualUpdates, humanImitationUpdates: updates.length })
  } finally {
    optimizer.dispose(); candidate.adam.dispose(); reference.adam.dispose()
    model.dispose(); reference.model.dispose()
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href)
  main().catch(error => { console.error(error.stack || error); process.exitCode = 1 })
