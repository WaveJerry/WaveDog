// Keep complete-bout holdouts fixed when an offline curriculum is relabelled.
export function preservedDaggerBouts(dataset){
  const byMatch=new Map()
  for(const trace of dataset?.trajectories||[]){
    if(trace.sourceKind!=='dagger-expert-relabel')continue
    if(!trace.matchId||!['train','validation'].includes(trace.split))
      throw Error('Invalid preserved DAgger bout')
    const old=byMatch.get(trace.matchId)
    if(old&&(old.split!==trace.split||old.sourceSha256!==trace.sourceSha256))
      throw Error('Conflicting preserved DAgger bout '+trace.matchId)
    byMatch.set(trace.matchId,trace)
  }
  return byMatch
}

export function daggerBoutSplit(prior,sourceSha256,fallback){
  if(!['train','validation'].includes(fallback))throw Error('Invalid fallback split')
  if(prior&&prior.sourceSha256!==sourceSha256)
    throw Error('Preserved DAgger raw trajectory changed '+prior.matchId)
  return prior?.split??fallback
}
