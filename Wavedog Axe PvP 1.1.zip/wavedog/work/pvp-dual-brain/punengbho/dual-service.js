// Loopback transport for the exact WaveDog 8.6 plugin. One total policy serves
// all temporary fighter states; Qwen receives the ordered public bout afterward.
import net from 'node:net'
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import readline from 'node:readline'
import { reviewProtocolFrames } from './protocol-review.js'

const checkpoint = path.resolve(process.argv[2] || '')
if (!fs.existsSync(checkpoint)) throw Error('Fresh dual checkpoint is required')
const store = path.join(path.dirname(checkpoint), 'coach')
fs.mkdirSync(store, { recursive: true })
const playerCards = path.join(store,'player-experience.jsonl')
const bridge = spawn(process.execPath, [new URL('./fresh-actor.js', import.meta.url).pathname.replace(/^\/(?=[A-Z]:)/, ''), checkpoint],
  { cwd: path.dirname(new URL(import.meta.url).pathname.replace(/^\/(?=[A-Z]:)/, '')),
    stdio: ['pipe', 'pipe', 'inherit'], windowsHide: true })
const clients = new Set()
let ready = false
const append = (name, data) => fs.appendFileSync(path.join(store, name), JSON.stringify(data) + '\n')
const send = row => { const line = JSON.stringify(row) + '\n'; for (const client of clients) client.write(line) }
readline.createInterface({ input: bridge.stdout }).on('line', line => {
  let row
  try { row = JSON.parse(line) } catch { return }
  if (row.event === 'ready') ready = true
  if (row.event === 'trained' || row.event === 'trained_partial') append('training.jsonl', row)
  if (row.event === 'inference_queue') append('inference-queue.jsonl', { at: new Date().toISOString(), ...row })
  send(row)
})
bridge.on('exit', (code, signal) => {
  ready = false
  send({ event: 'service_error', reason: `dual bridge exit ${code}; signal=${signal || 'none'}` })
  process.exitCode = 1
})
bridge.on('error', error => {
  ready = false
  send({ event: 'service_error', reason: `dual bridge error: ${error.message}` })
})

let reviewing = Promise.resolve()
async function review (row) {
  const stamp = new Date().toISOString()
  append('bouts.jsonl', { ...row, receivedAt: stamp })
  const frames = Array.isArray(row.frames) ? row.frames : []
  // Preserve every raw frame above; compress the whole ordered bout for the
  // local Qwen context, including early phases and rare damage windows.
  const width = Math.max(12, Math.ceil(frames.length / 32))
  const selected = []
  for (let i = 0; i < frames.length; i += width) {
    const part = frames.slice(i, i + width)
    const ranges = part.filter(f => f.seen?.visible).map(f =>
      Math.hypot((f.seen.x ?? 0) - (f.self.x ?? 0),
        (f.seen.y ?? 0) - (f.self.y ?? 0),
        (f.seen.z ?? 0) - (f.self.z ?? 0)))
    selected.push({ ticks: [part[0].tick, part.at(-1).tick],
      dualFrames: part.filter(f => f.owner === 'dual').length,
      visibleFrames: ranges.length,
      rangeMin: ranges.length ? Math.round(Math.min(...ranges) * 10) / 10 : null,
      rangeMax: ranges.length ? Math.round(Math.max(...ranges) * 10) / 10 : null,
      shieldAvailable: part.filter(f => f.self?.shieldAvailable).length,
      shieldRaised: part.filter(f => f.self?.shielding).length,
      shieldRequested: part.filter(f => f.shieldRequested).length,
      attackPackets: part.filter(f => f.attackPacket).length,
      dealt: Math.round(part.reduce((sum, f) => sum + (f.nativeDealt || 0), 0) * 10) / 10,
      received: Math.round(part.reduce((sum, f) => sum + (f.nativeReceived || 0), 0) * 10) / 10 })
  }
  const lessons = fs.existsSync(path.join(store, 'shared-lessons.jsonl'))
    ? fs.readFileSync(path.join(store, 'shared-lessons.jsonl'), 'utf8').trim().split('\n').slice(-8)
        .map(line => { try { return JSON.parse(line) } catch { return null } }).filter(Boolean) : []
  // Resolve against the known checkpoint, not the service's working directory.
  const cardPaths = [playerCards]
  const cards = [...new Set(cardPaths.flatMap(file => fs.existsSync(file)
    ? fs.readFileSync(file, 'utf8').trim().split('\n').slice(-12)
        .map(line => { try { return JSON.parse(line).text } catch { return null } }).filter(Boolean) : []))]
  const teachingPath = path.join(store, 'operator-critical-defense.json')
  const teaching = fs.existsSync(teachingPath)
    ? JSON.parse(fs.readFileSync(teachingPath, 'utf8')) : null
  try {
    if (frames.some(frame => frame.actualPackets && frame.owners)) {
      const answer = await reviewProtocolFrames(row, append, lessons, cards, teaching)
      append('shared-lessons.jsonl', { at:stamp,matchId:row.matchId,focus:answer.focus,lesson:answer.lesson })
      send({event:'review_saved',matchId:row.matchId,focus:answer.focus})
      return
    }
    const response = await fetch('http://127.0.0.1:18765/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(150000), body: JSON.stringify({ model: 'wavedog-tactics',
        temperature: .3, max_tokens: 512, chat_template_kwargs: { enable_thinking: false },
        response_format: { type: 'json_object', schema: { type:'object',
          properties:{focus:{type:'string',enum:['CRITICAL','COMBO','SHIELD','FREE']},lesson:{type:'string',maxLength:150}},
          required:['focus','lesson'],additionalProperties:false } },
        messages: [
          { role: 'system', content: '你是本地 Qwen 盾斧教练。只分析按时间排序的公开帧与原生结果，不读隐藏对手血量。机械段与神经段分开归因。学习重点包括极限距离控距、打断进攻、惩罚暴击、对手及时举盾后的变招、钻石剑连续真实暴击和地面 W-tap 连招，保留其他有效打法。普通近战的移动与出刀由模型自主选择，不附加本轮的接近前突规则。最高训练优先级：在真实合法射程边界用疾跑击退刀打断对手平 A 起手，不给后续跳劈机会；边界控距先于等待惩罚暴击。对手进入纵深近身后，再重点考虑真实下落惩罚暴击、钻石剑连续暴击和地面连击。以实际抢先命中、打断后是否避开后续连击和净换血验收，不能把挥刀动画当作成功打断。蓄力足够且刚进入合法攻击范围时，优先争取第一瞬间的真实命中，避免入距后长期空等；延后出刀须服务于真实暴击、有效盾防御等具体选择。普通出刀倾向高蓄力，必要轻击保留，射程外不能空挥。地面接近不覆盖空中动作，真实下落暴击出刀前短暂松疾跑；武器切换考虑蓄力损失。不要把尝试当作命中，不要声称模型已学会。输出 JSON：{"focus":"CRITICAL|COMBO|SHIELD|FREE","lesson":"可检验的一句话"}。' },
          { role: 'user', content: JSON.stringify({ outcome: row.outcome,
            fighter: row.fighter, opponent: row.opponent, frames: selected,
            previousLessons: lessons, playerExperience: cards,
            priorityTeaching: teaching }) }
        ] }) })
    if (!response.ok) throw Error(`Qwen HTTP ${response.status}: ${(await response.text()).slice(0,200)}`)
    const payload = await response.json()
    const answer = JSON.parse(payload.choices[0].message.content)
    if (!['CRITICAL', 'COMBO', 'SHIELD', 'FREE'].includes(answer.focus)
        || typeof answer.lesson !== 'string' || !answer.lesson.trim())
      throw Error('Invalid Qwen review')
    append('shared-lessons.jsonl', { at: stamp, matchId: row.matchId,
      focus: answer.focus, lesson: answer.lesson.slice(0, 160) })
    send({ event: 'review_saved', matchId: row.matchId, focus: answer.focus })
  } catch (error) {
    append('review-errors.jsonl', { at: stamp, matchId: row.matchId,
      error: String(error) })
  }
}

const server = net.createServer(socket => {
  socket.setNoDelay(true); socket.setEncoding('utf8'); clients.add(socket)
  const modelReady = ready && bridge.exitCode === null && !bridge.killed && bridge.stdin.writable
  socket.write(JSON.stringify({ event: 'transport_ready', modelReady }) + '\n')
  if (modelReady) socket.write(JSON.stringify({ event: 'ready', model: 'DUAL-GRU-GTRXL' }) + '\n')
  let buffer = ''
  socket.on('data', chunk => {
    buffer += chunk
    if (buffer.length > 4_000_000) { socket.destroy(); return }
    for (let at; (at = buffer.indexOf('\n')) >= 0;) {
      const line = buffer.slice(0, at); buffer = buffer.slice(at + 1)
      if (!line.trim()) continue
      let row
      try { row = JSON.parse(line) } catch { socket.write('{"event":"bad_json"}\n'); continue }
      if (row.command === 'review') {
        reviewing = reviewing.then(() => review(row)).catch(() => {})
      } else if (ready && bridge.exitCode === null && !bridge.killed && bridge.stdin.writable)
        bridge.stdin.write(line + '\n')
      else socket.write('{"event":"model_not_ready"}\n')
    }
  })
  socket.on('close', () => clients.delete(socket))
  socket.on('error', () => clients.delete(socket))
})
server.listen(18776, '127.0.0.1', () => process.stdout.write('PUNENGBHO_SERVICE_LISTENING 127.0.0.1:18776\n'))
