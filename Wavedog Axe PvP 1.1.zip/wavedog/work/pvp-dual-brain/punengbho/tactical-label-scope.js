// User-directed curriculum changes only. Actual teacher actions stay factual.
export function scopeLegacyTacticalLabels(frame,trace){
  const labels={...frame.labels},omitted={...(frame.omittedOutOfScopeTeacherLabels||{})}
  if(trace.tacticalCurriculumVersion>=3)return {...frame,labels,omittedOutOfScopeTeacherLabels:omitted}
  const s=frame.publicRequest.self,t=frame.publicRequest.seen
  if(!t?.visible)return {...frame,labels,omittedOutOfScopeTeacherLabels:omitted}
  const horizontal=Math.hypot(t.x-s.x,t.z-s.z)
  const omit=h=>{if(labels[h]!==undefined){omitted[h]=labels[h];delete labels[h]}}
  // A fixed-weapon ground specialist is evidence for spacing, not a teacher
  // for weapon choice or jumping once an opponent has pushed into close range.
  if(trace.mode==='edge-control'&&horizontal<2.05){
    omit(0);omit(1);omit(2);omit(4);omit(5)
  }
  // Old close-combat teachers jumped from too far away and stayed with a
  // sword during spaced single-hit exchanges. Keep evidence, drop obsolete
  // preferences; new state-labelled bouts supply the replacement targets.
  if(horizontal>=2.05){
    // A continuous-critical specialist pursues at this distance; retaining
    // its movement target would contradict the new axe spacing curriculum
    // even after dropping its jump/weapon labels.
    if(['critical','critical-switch'].includes(trace.mode)){omit(0);omit(1)}
    if(labels[2]===1)omit(2)
    if(labels[5]===1)omit(5)
    if(t.shield||t.shieldRaised){omit(0);omit(1);omit(4);omit(5)}
  }
  return {...frame,labels,actions:[...frame.actions],omittedOutOfScopeTeacherLabels:omitted}
}
