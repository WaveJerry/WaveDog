// Offline supervision/auditing only; never imported by the actor or executor.
// A legal outer-edge strike is one joint decision, not an attack label pasted
// over retreat, a jump, or a weapon change that resets the usable charge.
import {eyeReach} from '../../pvp-player-client/probe-edge-controller.js'

export function outerEdgeSprintTarget(frame){
 const r=frame.publicRequest,s=r?.self,t=r?.seen,p=r?.publicActionContext?.sentPosition,l=frame.labels
 if(!s?.ground||!t?.visible||!p||!l||t.shield||t.shieldRaised||!(s.charge>.9)
   ||![s.x,s.y,s.z,s.eyeY,t.x,t.y,t.z,p.x,p.y,p.z].every(Number.isFinite)
   ||l[4]!==2||l[1]!==1||l[2]!==0||![1,5,6].includes(l[0])||l[6]!==6
   ||!((s.held===7&&l[5]===0)||(s.held===0&&l[5]===1)))return null
 const target={position:t,width:.6,height:1.8},height=s.eyeY-s.y,
  local=eyeReach(s,height,target),wire=eyeReach(p,height,target)
 // User's explicit skill band is 2.99–3.00, not a looser 2.95 window. Both
 // positions must qualify; an out-of-reach sent position is never ignored.
 if(Math.min(local,wire)<2.99||Math.max(local,wire)>3)return null
 return {kind:'outer-edge-sprint-strike',localReach:local,wireReach:wire,
  withinLastCentimetre:Math.min(local,wire)>=2.99,
  heads:{0:l[0],1:1,2:0,4:2,5:l[5],6:6}}
}

export function outerEdgeSprintDecision(target,actions){
 return Boolean(target&&[1,5,6].includes(actions[0])&&actions[1]===1&&actions[2]===0
  &&actions[4]===2&&actions[5]===target.heads[5]&&actions[6]===6)
}
