'use strict'
// Offline DAgger oracle for the verified sword-critical microtask only.
// Never imported by the live actor/executor. It uses current public state and
// the learner's REAL previous inputs, not a fictional sequence of expert hits.
const crypto=require('node:crypto'),fs=require('node:fs')
const sourceSha256=crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex')
function criticalExpert(request,history={}){
  const s=request.self,t=request.seen,tick=request.tick
  if(!s||!t?.visible||![s.x,s.y,s.z,s.eyeY,t.x,t.y,t.z,tick].every(Number.isFinite))
    return {labels:{},reason:'incomplete-public-state',sourceSha256}
  const dx=t.x-s.x,dy=t.y-s.y,dz=t.z-s.z
  const distance=Math.hypot(dx,dy,dz),horizontal=Math.hypot(dx,dz)
  const px=Math.max(t.x-.3,Math.min(t.x+.3,s.x)),pz=Math.max(t.z-.3,Math.min(t.z+.3,s.z))
  const py=Math.max(t.y,Math.min(t.y+1.8,s.eyeY))
  const reach=Math.hypot(px-s.x,py-s.eyeY,pz-s.z)
  // Unknown state cannot justify a positive attack label. Shielded opponents
  // are outside this microtask; no claim about a general shield-breaking expert.
  if(t.shield)return {labels:{},reason:'outside-unshielded-microtask',sourceSha256}
  const attack=s.held===0&&s.ground===false&&s.wireFalling===true&&reach<=3
    &&s.attackAgeTicks>=13&&s.weaponAgeTicks>=12
  const jump=s.ground===true&&horizontal<2.45
  const labels={0:horizontal>2.5?1:0,1:Number(horizontal>2.5&&!attack),3:0,
    4:attack?2:0,5:1,6:6,7:3,8:0}
  if(s.ground===true)labels[2]=Number(jump)
  const actions=Array(9).fill(0)
  for(const[h,a]of Object.entries(labels))actions[h]=a
  return {labels,actions,reach,sourceSha256,reason:attack?'verified-descending-sword-window':'prepare-or-wait',
    teacherScope:'unshielded-sword-critical',counterfactual:true,ppoEligible:false}
}
function observeLearnerInput(history,request,executed){
  if(request.self?.ground===true&&executed?.jump)history.lastGroundJumpTick=request.tick
}
module.exports={criticalExpert,observeLearnerInput,sourceSha256}
