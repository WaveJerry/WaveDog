import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {publicThreatFeatures} from '../public-threat-features.js'
import {validateDataset} from '../human-imitation.js'
const [source,dest]=process.argv.slice(2)
if(!source||!dest||fs.existsSync(dest))throw Error('Require a new dataset destination')
const data=JSON.parse(fs.readFileSync(source)),counts={}
for(const t of data.trajectories){
  const c=counts[t.split]||={frames:0,known:0,envelope:0,critical:0}
  for(const f of t.frames){
    f.publicThreatFeatures=publicThreatFeatures(f.publicRequest)
    c.frames++;c.known+=f.publicThreatFeatures[0];c.envelope+=f.publicThreatFeatures[5];c.critical+=f.publicThreatFeatures[6]
  }
}
data.policyObservationConfig={...data.policyObservationConfig,publicThreatInputs:12}
validateDataset(data)
fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,JSON.stringify(data))
const receipt={source:path.resolve(source),sourceSha256:crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  counts,rawObservationAndLabelsUnchanged:true,wholeBoutSplitsPreserved:true,causalInputsOnly:true,ppoEligible:false}
fs.writeFileSync(dest+'.audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt))
