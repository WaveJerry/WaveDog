import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE,ACTION_WIDTHS} from '../fresh-policy.js'
import {SharedAdam} from '../fresh-optimizer-checkpoint.js'
import {advance,captureDeployedImitation,imitationUpdate,disposeState} from '../human-imitation.js'
await tf.setBackend('cpu');await tf.ready()
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:32,interval:2,memory:4,
  distributionVersion:2,behaviorPriorVersion:0,publicMotionInputs:32,trainingStage:'behavior-cloning'})
const optimizer=new SharedAdam(model.params,{learningRate:.0001})
const masks=ACTION_WIDTHS.map(n=>Array(n).fill(true))
let state=model.initialState()
const frames=[]
for(let t=0;t<3;t++){
  const frame={observation:Array.from({length:OBS_SIZE},(_,i)=>Math.sin(i+t)*.1),legalMasks:masks,
    publicMotionFeatures:Array.from({length:32},(_,i)=>i===0?1:.05*Math.cos(i+t)),
    labels:Object.fromEntries(ACTION_WIDTHS.map((n,h)=>[h,(t+h)%n])),context:{},
    actions:ACTION_WIDTHS.map((n,h)=>(t+h)%n)}
  const out=advance(model,state,frame.observation,true,masks,null,null,null,frame.publicMotionFeatures)
  state=out.state;frame.reference=captureDeployedImitation(model,out,frame);frames.push(frame)
}
disposeState(state)
const groups={gru:model.fast.params,gtrxl:model.slowBlocks.flatMap(b=>b.params),
  gate:[...model.gateIn.params,...model.gateOut.params],motion:[model.publicMotionProjection],
  ...Object.fromEntries(model.fastHeads.map((h,i)=>['fast-head-'+i,h.params])),
  ...Object.fromEntries(model.slowHeads.map((h,i)=>['slow-head-'+i,h.params]))}
const before=new Map(model.params.map(p=>[p.name,[...p.dataSync()]]))
state=model.initialState()
try{
  const result=imitationUpdate(model,optimizer,frames,state,Object.fromEntries(ACTION_WIDTHS.map((_,i)=>[i,1])))
  assert(Number.isFinite(result.loss)&&result.gradientNorm>0)
  const changed=Object.fromEntries(Object.entries(groups).map(([name,ps])=>[name,
    ps.some(p=>[...p.dataSync()].some((v,i)=>v!==before.get(p.name)[i]))]))
  for(const [name,updated]of Object.entries(changed))assert(updated,'Full-network update missing '+name)
  console.log(JSON.stringify({passed:true,syntheticFixtureOnly:true,skillLearned:false,
    fullNetworkUpdate:true,changed,loss:result.loss}))
}finally{disposeState(state);optimizer.dispose();model.dispose()}
