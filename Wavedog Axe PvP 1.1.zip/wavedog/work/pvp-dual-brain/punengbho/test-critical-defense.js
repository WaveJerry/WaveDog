import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { meleeEntryContext } from './fresh-melee-progress.js'
import { curriculumLogitBias, biasedActionLogits, ACTION_WIDTHS, OBS_SIZE } from './fresh-policy.js'
import { criticalExploiterAction } from './human-critical-exploiter.js'

const base = { tick: 10, matchId: 'one', opponent: 'B', focus: 'SPRINT_KB',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62, health: 20, ground: true, charge: 1, vy: 0 },
  seen: { visible: true, x: 0, y: 1.18, z: 3.1, shield: false } }
const current = { ...base, tick: 11, seen: { ...base.seen, y: 1.02 } }
const danger = meleeEntryContext(base, current)
assert(danger.fallingMeleeThreat)
assert.equal(danger.opponentVerticalPhase, 'falling')
assert(!danger.ownFallingWindow)
const rising = meleeEntryContext(base, { ...current, seen: { ...current.seen, y: 1.4 } })
assert.equal(rising.opponentVerticalPhase, 'rising')
assert(!rising.fallingMeleeThreat)
assert(!meleeEntryContext(base, { ...current, matchId: 'other' }, danger).fallingMeleeThreat)
assert(!meleeEntryContext(base, { ...current, tick: 17 }, danger).fallingMeleeThreat)
assert(!meleeEntryContext(base, { ...current, seen: { ...current.seen, visible: false } }, danger).fallingMeleeThreat)
assert(!meleeEntryContext(base, { ...current, seen: { ...current.seen, z: 8 } }).fallingMeleeThreat)
assert.deepEqual(meleeEntryContext(base, { ...current, seen: { ...current.seen,
  ground: true, critical: false, charge: 0, vy: 999, sprint: false, health: 1 } }), danger,
  'never read hidden enemy attack charge, ground, fall distance, health or sprint')
const sample = { source: 'public-position-samples', matchId: 'one', opponent: 'B',
  sampleTick: 10, vx: 0, vy: -.16, vz: -.1, grounded: false }
const repeated = { ...base, tick: 11, observedOpponentMotion: sample }
assert.equal(meleeEntryContext(base, repeated).opponentVerticalPhase, 'falling',
  'repeated entity positions must not erase a fresh public falling sample')
assert(meleeEntryContext(base, repeated).fallingMeleeThreat)
assert.equal(meleeEntryContext(base, { ...repeated,
  observedOpponentMotion: { ...sample, vy: .2 } }).opponentVerticalPhase, 'rising')
assert.equal(meleeEntryContext(base, { ...repeated,
  observedOpponentMotion: { ...sample, grounded: true } }).opponentVerticalPhase, 'level-or-apex')
const repeatedFallback = meleeEntryContext(base, { ...base, tick: 11 })
for (const invalid of [{ ...sample, sampleTick: 7 }, { ...sample, sampleTick: 12 },
  { ...sample, matchId: 'other' }, { ...sample, opponent: 'C' },
  { ...sample, source: 'server-private-state' }, { ...sample, vy: NaN },
  { ...sample, vy: 999 }, { ...sample, vx: Infinity }, { ...sample, grounded: undefined }])
  assert.deepEqual(meleeEntryContext(base, { ...repeated, observedOpponentMotion: invalid }),
    repeatedFallback, 'stale, future, cross-bout or invalid samples fall back to public positions')
const hurt = { ...base, tick: 11, self: { ...base.self, health: 16 },
  seen: { ...base.seen, y: 0, z: 3 } }
const hurtContext = meleeEntryContext(base, hurt)
const leaving = { ...hurt, tick: 12, seen: { ...hurt.seen, z: 3.2 },
  self: { ...hurt.self, ground: false, vy: -.12 } }
const closing = meleeEntryContext(hurt, leaving, hurtContext)
assert(closing.punishmentWindowClosing)
assert(closing.ownFallingWindow, 'a real own falling window remains an available punishment')
assert(!meleeEntryContext(hurt, { ...leaving, seen: { ...leaving.seen, z: 2.8 } }, hurtContext).punishmentWindowClosing)
assert(!meleeEntryContext(hurt, { ...leaving, matchId: 'other' }, hurtContext).punishmentWindowClosing)
const trial = meleeEntryContext(base, { ...hurt, focus: 'SYNC' })
assert(trial.jumpResetTrial)
assert(!meleeEntryContext(base, { ...hurt, focus: 'SYNC', self: { ...hurt.self, ground: false } }).jumpResetTrial)
const swordFirst = { ...hurt, seen: { ...hurt.seen, z: 2.3, held: 'DIAMOND_SWORD' } }
const swordSecond = { ...swordFirst, tick: 15, self: { ...hurt.self, health: 12 } }
const pressure = meleeEntryContext(swordFirst, swordSecond, meleeEntryContext(base,swordFirst))
assert(pressure.swordComboPressure)
assert(meleeEntryContext(base, { ...current, seen: { ...current.seen,
  z: 2.2, held: 'DIAMOND_SWORD' } }).swordComboPressure,
  'a visible close sword descent can be considered before already eating two hits')
assert(!meleeEntryContext(swordFirst, { ...swordSecond, seen: { ...swordSecond.seen, z: 3.2 } },
  meleeEntryContext(base,swordFirst)).swordComboPressure, 'do not force a sword at edge range')

const x = Array(OBS_SIZE).fill(0)
x[31] = 1; x[1] = 1; x[2] = 1; x[97] = -.05
const before = curriculumLogitBias(x, { entryCurriculum: 4 })
const now = curriculumLogitBias(x, danger)
assert.equal(before[4][2] - now[4][2], 24, 'remove only the dominant blind full-charge hit cue in contested descent')
for (const head of [0, 1, 2, 3, 5, 6, 7, 8]) assert.deepEqual(now[head], before[head],
  'no mechanical retreat, sprint, jump, weapon or fixed-distance controller')
assert.deepEqual(curriculumLogitBias(x, rising), before, 'retain ordinary and rising interception distribution')
assert.deepEqual(curriculumLogitBias(x, { ...danger, entryCurriculum: 4 }), before,
  'historical PPO behavior remains exact even with unused extra context keys')
assert.deepEqual(curriculumLogitBias(x, { ...danger, ownFallingWindow: true }), before,
  'do not categorically remove punishment criticals')
const raw = ACTION_WIDTHS.map(width => tf.zeros([1, width]))
const acting = biasedActionLogits(raw, x, danger)
const replay = biasedActionLogits(raw, x, JSON.parse(JSON.stringify(danger)))
acting.forEach((head, index) => assert.deepEqual([...head.dataSync()], [...replay[index].dataSync()]))
assert([...tf.softmax(acting[4]).dataSync()].every(p => p > 0 && p < 1))
tf.dispose([...raw, ...acting, ...replay])

const scriptRequest = { ...base, tick: 20, matchId: 'script', yaw: 0, pitch: 0,
  self: { ...base.self, ground: false, vy: -.15, held: 7 } }
const strike = criticalExploiterAction(scriptRequest)
assert(strike.action.attack && !strike.action.sprint && !strike.action.jump)
assert(!strike.action.shield && !strike.action.use && !strike.action.sneak)
assert(!criticalExploiterAction({ ...scriptRequest, seen: { ...scriptRequest.seen, z: 5 } }).action.attack)
assert(!criticalExploiterAction({ ...scriptRequest, self: { ...scriptRequest.self, charge: .3 } }).action.attack)
assert(!criticalExploiterAction({ ...scriptRequest, self: { ...scriptRequest.self, vy: .2 } }).action.attack)
const retreat = criticalExploiterAction({ ...scriptRequest, tick: 21 }, strike.state)
assert.equal(retreat.action.forward, -1)
assert(!retreat.action.attack, 'no repeated fast clicks before cooldown')
assert.deepEqual(criticalExploiterAction({ ...scriptRequest,
  seen: { ...scriptRequest.seen, health: 1, critical: true, charge: 1 } }), strike,
  'exploiter has the same public information boundary')
console.log('CRITICAL_DEFENSE_PASS: public phases, conditional choices, exact old/new PPO replay, isolated fair exploiter')
