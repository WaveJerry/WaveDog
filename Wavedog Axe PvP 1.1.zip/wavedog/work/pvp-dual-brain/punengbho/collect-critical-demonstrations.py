"""Sequential ordinary-player teaching bouts; each runner checks arena/idle state."""
from pathlib import Path
import subprocess,sys
runner=Path(__file__).with_name('run-main-trial.py')
distances=[float(s)for s in sys.argv[1:]]or[1.5,1.2,1.5]
if any(not 1<=distance<=1.5 for distance in distances):
    raise ValueError('Critical practice must start 1 to 1.5 blocks apart; use edge-control for distance practice')
for distance in distances:
    subprocess.run([sys.executable,str(runner),'--mode','critical','--seconds','25',
        '--melee-only','--start-distance',str(distance),'--record-teacher'],check=True)
