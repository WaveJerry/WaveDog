'use strict'
const assert=require('node:assert/strict')
const {contactArrival,distantAxePreparation}=require('./contact-timing-forecast.cjs')
const make=(distance,{own=0,target=0,rotate=false}={})=>({tick:10,
 self:{x:0,y:0,z:0,eyeY:1.62,ground:true,food:20,vx:rotate?own:0,vz:rotate?0:own},
 seen:{visible:true,x:rotate?distance:0,y:0,z:rotate?0:distance},
 publicActionContext:{targetVelocity:{x:rotate?target:0,y:0,z:rotate?0:target}}})
assert.equal(contactArrival(make(3)).ticks,0)
assert(contactArrival(make(4)).ticks<20)
assert(!distantAxePreparation(make(4)),'current nearby gap cannot justify a fresh axe switch')
assert(distantAxePreparation(make(12)))
const standing=contactArrival(make(10)).ticks,approaching=contactArrival(make(10,{target:-.28})).ticks
assert(approaching<standing,'opponent momentum changes arrival before a distance threshold changes')
assert(!distantAxePreparation(make(10,{target:-.28})))
assert(contactArrival(make(10,{own:-.2})).ticks>contactArrival(make(10,{own:.2})).ticks,
 'own existing velocity is retained through turning/acceleration')
for(const distance of [4,8,12])assert.equal(contactArrival(make(distance)).ticks,
 contactArrival(make(distance,{rotate:true})).ticks,'rotation cannot change arrival timing')
const edge=[]
for(let d=8;d<10;d+=.01){const r=make(d);if([20,21].includes(contactArrival(r).ticks))edge.push(r)}
assert(edge.some(r=>contactArrival(r).ticks===20)&&edge.some(r=>contactArrival(r).ticks===21))
for(const r of edge)assert.equal(distantAxePreparation(r),contactArrival(r).ticks>20,
 'exactly one second is still sword; only strictly longer permits preparation')
const missing=make(12);delete missing.publicActionContext.targetVelocity
assert(!distantAxePreparation(missing),'missing motion cannot become an assumed distant opener')
assert(!distantAxePreparation(make(12,{target:1})),'no predicted contact is different from a known remote engagement')
console.log('SWORD_DEFAULT_CONTACT_TIME_BOTH_VELOCITIES_STRICT_ONE_SECOND_PASS')
