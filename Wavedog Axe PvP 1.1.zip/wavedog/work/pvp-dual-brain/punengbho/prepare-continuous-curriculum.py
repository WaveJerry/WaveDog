"""Rebuild offline labels while retaining every original complete-bout holdout."""
from pathlib import Path
import argparse,json,subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
PRIOR=BASE/'carried-kit-joint-dagger/dataset.json'
DEMOS=BASE/'continuous-close-demonstrations-complete'
AGGREGATE=BASE/'continuous-close-dagger'
previous=json.loads(PRIOR.read_text())
p=argparse.ArgumentParser();p.add_argument('--audit-only',action='store_true');args=p.parse_args()
if not args.audit_only and (DEMOS.exists() or AGGREGATE.exists()):raise RuntimeError('Preserve prior curriculum builds')

def run(script,args,log):
    with log.open('w',encoding='utf8')as output:
        subprocess.run(['E:/node/node.exe',str(ROOT/'work/pvp-dual-brain/punengbho'/script),*args],
            cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)

if not args.audit_only:run('prepare-rebuild-demonstrations.js',[
    '--out',str(DEMOS),'--preserve-splits',str(PRIOR),
    '--checkpoint',str(BASE/'carried-kit-install/checkpoint.json'),
    '--scope-critical-to-close','--omit-legacy-close-jump-waits'],BASE/'continuous-close-demos-build.log')

matches=[t['matchId']for t in previous['trajectories']if t.get('sourceKind')=='dagger-expert-relabel']
# The final new complete bout is held out; all existing splits take precedence.
matches+=['62a426da-5e7d-41a9-9066-2c6a58efec13','23933a2a-eb47-4ee2-8534-7f606737b781',
          'bf9ca7fa-d305-4c2e-9da8-8490d1cb3845','a84d07ab-c850-47bd-8481-d3003cdf15d4']
if not args.audit_only:run('prepare-dagger-dataset.js',['continuous-close-dagger','--expert','joint-melee',
    '--preserve-splits',str(PRIOR),'--base',str(DEMOS/'dataset.json'),*matches],BASE/'continuous-close-dagger-build.log')
data=json.loads((AGGREGATE/'dataset.json').read_text())
assert data['ppoEligible'] is False,'Offline dataset cannot be PPO'
by_source={t['source']:t for t in data['trajectories']}
assert len(by_source)==len(data['trajectories']),'Duplicate trajectory'
for old in previous['trajectories']:
    new=by_source[old['source']]
    assert old['split']==new['split'],'Holdout leakage'
    assert old['sourceSha256']==new['sourceSha256'],'Raw evidence changed'
    assert len(old['frames'])==len(new['frames']),'Ordered bout truncated'
    for a,b in zip(old['frames'],new['frames']):
        assert a['observation']==b['observation'],'Causal input changed'
        assert a['legalMasks']==b['legalMasks'],'Action semantics changed'
        assert a.get('publicHealthFeatures')==b.get('publicHealthFeatures'),'Public input changed'
        assert b.get('ppoEligible',data['ppoEligible']) is False,'Offline supervision cannot be PPO'
run('test-dagger-alignment.js',[str(AGGREGATE/'dataset.json')],BASE/'continuous-close-causal-audit.log')
report={'originalBoutsPreserved':len(previous['trajectories']),
    'totalBouts':len(data['trajectories']),'wholeBoutSplitsUnchanged':True,
    'rawEvidenceUnchanged':True,'causalInputsUnchanged':True,'ppoEligible':False,
    'omittedLegacyCloseJumpWaitLabels':sum(2 in f.get('omittedOutOfScopeTeacherLabels',{})
        or '2' in f.get('omittedOutOfScopeTeacherLabels',{})for t in data['trajectories']
        if t['sourceKind']=='exact-script-demonstration'for f in t['frames']),
    'relabelledDaggerBouts':len(matches),'dataset':str(AGGREGATE/'dataset.json')}
(AGGREGATE/'preservation-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
