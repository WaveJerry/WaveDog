// Teacher holdout and replay of recorded live observations; no simulated wins.
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation}from '../human-imitation.js'
const folder=path.resolve(process.argv[2]),root=path.resolve('.')
const receipt=JSON.parse(fs.readFileSync(path.join(folder,'receipt.json')))
await tf.setBackend('cpu');await tf.ready()
const results=[]
for(const source of [receipt.source,path.join(folder,'checkpoint.json')]){
  const loaded=loadDualCheckpoint(source),groups={}
  try{for(const seq of [2040,2041]){
    const file=path.join(root,`work/wavedog-punengbho/model/rollouts/rollout-${String(seq).padStart(12,'0')}.json.gz`)
    const trace=JSON.parse(zlib.gunzipSync(fs.readFileSync(file))).episode
    let state=loaded.model.initialState()
    try{for(const frame of trace){
      const raw=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures);state=raw.state
      const out=captureDeployedImitation(loaded.model,raw,frame)
      const x=frame.observation,weapon=x[12]<.25?1:0,key=(weapon?'sword':'axe')+(x[1]<.4?'-low':'-ready')
      const g=groups[key]||={frames:0,switch:0,attack:0}
      const softmax=values=>{const m=Math.max(...values),e=values.map(v=>Math.exp(v-m)),s=e.reduce((a,b)=>a+b);return e.map(v=>v/s)}
      const hand=softmax(out.logits[5]);g.frames++;g.switch+=hand[1-weapon];g.attack+=softmax(out.logits[4])[2]
    }}finally{disposeState(state)}
  }}finally{loaded.adam.dispose();loaded.model.dispose()}
  for(const g of Object.values(groups)){g.switch/=g.frames;g.attack/=g.frames}
  results.push({source,sha256:loaded.manifest.sha256,groups})
}
const before=receipt.before.validation.labels,after=receipt.after.validation.labels
const checks={standardOfflineChecks:receipt.offlineChecksPassed}
for(const key of ['4:2','4:0','2:1','5:0','5:1'])if(before[key]&&after[key])
  checks[key+'-not-regressed']=after[key].nll<=before[key].nll+.03
checks.groundedQuietRetained=after['2:0'].probability>=.85
const report={passed:Object.values(checks).every(Boolean),checks,results,
  livePvpImprovementVerified:false,groundedEdgeSkillVerified:false,
  note:'Recorded-state distribution diagnostics only; not counterfactual combat or proof of tactics'}
fs.writeFileSync(path.join(folder,'cadence-checks.json'),JSON.stringify(report,null,2))
console.log(JSON.stringify(report))
if(!report.passed)process.exitCode=1
