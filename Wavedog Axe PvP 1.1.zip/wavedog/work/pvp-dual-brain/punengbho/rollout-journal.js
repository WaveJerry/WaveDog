import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'

const FILE = /^rollout-(\d{12})\.json\.gz$/
const nameFor = sequence => `rollout-${String(sequence).padStart(12, '0')}.json.gz`

/** Completed PPO trajectories are written atomically before entering the worker. */
export class RolloutJournal {
  constructor (directory, committedSequence = 0) {
    this.directory = path.resolve(directory)
    fs.mkdirSync(this.directory, { recursive: true })
    const sequences = fs.readdirSync(this.directory).flatMap(name => {
      const match = FILE.exec(name)
      return match ? [Number(match[1])] : []
    })
    this.nextSequence = Math.max(committedSequence, ...sequences)
  }

  append (message) {
    if (!Array.isArray(message.episode) || !message.episode.length)
      throw Error('Cannot journal an empty PPO rollout')
    const rolloutSeq = this.nextSequence + 1
    const row = { ...message, rolloutSeq }
    const destination = path.join(this.directory, nameFor(rolloutSeq))
    const temporary = `${destination}.${process.pid}.tmp`
    fs.writeFileSync(temporary, zlib.gzipSync(Buffer.from(JSON.stringify(row))))
    fs.renameSync(temporary, destination)
    this.nextSequence = rolloutSeq
    return row
  }

  pending (committedSequence = 0) {
    return fs.readdirSync(this.directory).flatMap(name => {
      const match = FILE.exec(name)
      return match && Number(match[1]) > committedSequence
        ? [{ name, sequence: Number(match[1]) }] : []
    }).sort((a, b) => a.sequence - b.sequence).map(({ name, sequence }) => {
      const file = path.join(this.directory, name)
      const row = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8'))
      if (row.rolloutSeq !== sequence || !Array.isArray(row.episode)
          || !row.episode.length || !row.fighter)
        throw Error(`Invalid PPO journal entry: ${name}`)
      return row
    })
  }
}
