// Offline loss weighting only. No predicted/held-out policy actions are used.
export function responseSupervisionWeight(frame,head,strength=1){
  const r=frame.publicRequest,s=r?.self,o=r?.publicActionContext,l=frame.labels
  if(!s||strength===1)return 1
  const forecast=s.ground===true&&o?.targetAirborne&&o?.targetCriticalThreat&&l[4]===0
  if(forecast&&[0,1,2,4,6].includes(head))return strength
  if(frame.expertReason==='sword-last-legal-contact-before-separation'&&[1,4,5].includes(head))return strength
  if(s.attackAgeTicks<4&&l[4]===0&&head===4)return strength
  return 1
}
