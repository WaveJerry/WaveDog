"""Rebuild scoped tactical supervision without altering raw bouts or holdouts."""
from pathlib import Path
import argparse,json,subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
p=argparse.ArgumentParser()
p.add_argument('--name',default='spacing-foundation-v3')
p.add_argument('--prior',type=Path,default=BASE/'continuous-close-live-dagger/dataset.json')
p.add_argument('--matches',nargs='*',default=[])
p.add_argument('--new-lesson',choices=['joint-state-transitions','shield-state-transitions'])
p.add_argument('--directional-movement',action='store_true',help='Offline direction/sprint/turn-back supervision only')
p.add_argument('--label-delay',type=int,choices=[0,1,2],default=1,
    help='Execution horizon for counterfactual expert labels; response dispatch uses 0')
args=p.parse_args()
PRIOR=args.prior
DEMOS=BASE/(args.name+'-demonstrations')
AGGREGATE=BASE/args.name
previous=json.loads(PRIOR.read_text())
if DEMOS.exists() or AGGREGATE.exists():raise RuntimeError('Preserve prior curriculum builds')

def run(script,arguments,log):
    with log.open('w',encoding='utf8')as output:
        subprocess.run(['E:/node/node.exe',str(ROOT/'work/pvp-dual-brain/punengbho'/script),*arguments],
            cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)

run('prepare-rebuild-demonstrations.js',[
    '--out',str(DEMOS),'--preserve-splits',str(PRIOR),
    '--checkpoint',str(BASE/'continuous-close-install/checkpoint.json'),
    '--scope-critical-to-close','--omit-legacy-close-jump-waits','--scope-spacing-curriculum'],
    BASE/(args.name+'-demos-build.log'))
matches=[t['matchId']for t in previous['trajectories']if t.get('sourceKind')=='dagger-expert-relabel']
matches+=args.matches
if len(set(matches))!=len(matches):raise RuntimeError('Duplicate input bout')
run('prepare-dagger-dataset.js',[args.name,'--expert','joint-melee',
    '--label-delay',str(args.label_delay),
    '--preserve-splits',str(PRIOR),'--base',str(DEMOS/'dataset.json'),
    *(['--directional-movement']if args.directional_movement else []),*matches],
    BASE/(args.name+'-dagger-build.log'))
data=json.loads((AGGREGATE/'dataset.json').read_text())
if args.directional_movement:
    # Keep actual demonstration actions factual. The old test opponent's
    # backwards walking is no longer the requested tactical travel style;
    # omit those movement labels rather than rewriting its real history.
    for trace in data['trajectories']:
        if trace.get('sourceKind')=='dagger-expert-relabel':continue
        for frame in trace['frames']:
            if frame['labels'].get('0')!=2:continue
            request=frame.get('publicRequest',{});s=request.get('self',{});t=request.get('seen',{})
            if not t.get('visible'):continue
            if ((t['x']-s['x'])**2+(t['z']-s['z'])**2)**.5<2.05:continue
            omitted=frame.setdefault('omittedOutOfScopeTeacherLabels',{})
            for h in ['0','1','6','7','8']:
                if h in frame['labels']:omitted[h]=frame['labels'].pop(h)
            frame['directionalTravelSupervision']='legacy-backpedal-labels-omitted-original-actions-preserved'
if args.new_lesson:
    for trace in data['trajectories']:
        if trace['matchId']in args.matches and trace['sourceKind']=='dagger-expert-relabel':
            trace['lesson']=args.new_lesson
assert data['ppoEligible'] is False
by_source={t['source']:t for t in data['trajectories']}
assert len(by_source)==len(data['trajectories'])
for old in previous['trajectories']:
    new=by_source[old['source']]
    assert old['split']==new['split'],'Holdout leakage'
    assert old['sourceSha256']==new['sourceSha256'],'Raw evidence changed'
    assert len(old['frames'])==len(new['frames']),'Ordered bout truncated'
    for a,b in zip(old['frames'],new['frames']):
        assert a['observation']==b['observation'],'Causal input changed'
        assert a['legalMasks']==b['legalMasks'],'Action semantics changed'
        assert a.get('publicHealthFeatures')==b.get('publicHealthFeatures')
# The same match supplies two viewpoints. Keep the complete bout together.
# A preexisting learner holdout always wins over a new demo's stratification.
prior_splits={}
for t in previous['trajectories']:prior_splits.setdefault(t['matchId'],set()).add(t['split'])
quarantined={m for m,splits in prior_splits.items()if len(splits)>1}
prior_quarantine=PRIOR.parent/'quarantined-cross-view-bouts.json'
if prior_quarantine.exists():
    quarantined.update(t['matchId']for t in json.loads(prior_quarantine.read_text())['trajectories'])
prior_by_match={m:next(iter(splits))for m,splits in prior_splits.items()if m not in quarantined}
groups={}
for t in data['trajectories']:groups.setdefault(t['matchId'],[]).append(t)
for match,traces in groups.items():
    if match in quarantined:continue
    split=prior_by_match.get(match) or ('validation' if any(t['split']=='validation'for t in traces) else 'train')
    for t in traces:t['split']=split
for old in previous['trajectories']:assert by_source[old['source']]['split']==old['split']
excluded=[t for t in data['trajectories']if t['matchId']in quarantined]
data['trajectories']=[t for t in data['trajectories']if t['matchId']not in quarantined]
(AGGREGATE/'quarantined-cross-view-bouts.json').write_text(json.dumps({
    'reason':'Preexisting opposite viewpoints crossed training and validation; raw evidence preserved, excluded from this experiment.',
    'trajectories':excluded},separators=(',',':')))
(AGGREGATE/'dataset.json').write_text(json.dumps(data,separators=(',',':')))
run('test-dagger-alignment.js',[str(AGGREGATE/'dataset.json')],BASE/(args.name+'-causal-audit.log'))
report={'originalRawTrajectoriesPreserved':len(previous['trajectories']),
    'quarantinedPriorMatchIds':sorted(quarantined),'quarantinedTrajectories':len(excluded),
    'totalTrajectories':len(data['trajectories']),'wholeMatchSplitsConsistent':True,
    'rawEvidenceUnchanged':True,'causalInputsUnchanged':True,'ppoEligible':False,
    'relabelledDaggerBouts':len(matches),'dataset':str(AGGREGATE/'dataset.json')}
(AGGREGATE/'preservation-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
