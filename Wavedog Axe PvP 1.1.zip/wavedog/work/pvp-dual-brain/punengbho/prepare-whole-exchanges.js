import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath}from 'node:url'
import * as tf from '@tensorflow/tfjs'
import {legalMasks}from './pure-actions.js'
import {publicHealthFeatures}from '../public-health-features.js'
import {addPublicHealthInput,addActionContextInput,addAttackContextOutput}from '../migrate-public-health.js'
import {loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..')
const base=path.join(root,'outputs/punengbho-integration-20261117')
const source=path.join(base,'before/model/checkpoint.json')
const destination=path.join(base,'initial/checkpoint.json')
if(fs.existsSync(destination))throw Error('Do not overwrite an existing training seed')
const dataset=JSON.parse(fs.readFileSync(path.join(root,'outputs/sword-learning-next-20261116/joint-expert-sequences-v1/live-context.json')))
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180],pitches=[-30,-10,-3,0,3,10,30]
let lookLabels=0,sprintLabels=0
const nearest=(v,bins)=>bins.reduce((best,x,i)=>Math.abs(x-v)<Math.abs(bins[best]-v)?i:best,0)
for(const trace of dataset.trajectories)for(let i=0;i<trace.frames.length;i++){
  const f=trace.frames[i],n=trace.frames[i+1]
  f.legalMasks=legalMasks(f.publicRequest)
  f.publicHealthFeatures=publicHealthFeatures(f.publicRequest)
  if(f.labelEvidence.includes('native-confirmed-sword-critical')){f.labels['1']=0;sprintLabels++}
  // The target is the next observed camera movement; inputs remain strictly
  // the current public frame. Never infer unrecorded movement key presses.
  if(n?.tick===f.tick+1&&f.publicRequest.seen?.visible&&n.publicRequest.seen?.visible){
    const yaw=((n.publicRequest.yaw-f.publicRequest.yaw+540)%360)-180
    const pitch=n.publicRequest.pitch-f.publicRequest.pitch
    for(const [h,value,bins]of [[6,yaw,turns],[7,pitch,pitches]]){
      const a=nearest(value,bins)
      if(Number.isFinite(value)&&Math.abs(value-bins[a])<=.5){
        f.labels[h]=a;lookLabels++
        if(!f.labelEvidence.includes('consecutive-public-view-delta-within-quantization-tolerance'))
          f.labelEvidence.push('consecutive-public-view-delta-within-quantization-tolerance')
      }
    }
  }
}
dataset.learningPurpose='Whole causal exchanges: entry hit, sustained sword criticals, sprint timing, weapon transitions, camera and defensive waits'
dataset.controlRegime='pure-model-all-input'
fs.writeFileSync(path.join(base,'whole-exchanges.json'),JSON.stringify(dataset))
await tf.setBackend('cpu');await tf.ready()
let loaded=loadDualCheckpoint(source),items=[loaded]
for(const migrate of [addPublicHealthInput,addActionContextInput,addAttackContextOutput]){
  loaded=migrate({...loaded,manifest:items[0].manifest});items.push(loaded)
}
const saved=saveDualCheckpoint(destination,loaded.model,loaded.adam,loaded.counters)
for(const item of items){item.adam.dispose();item.model.dispose()}
fs.writeFileSync(path.join(base,'data-receipt.json'),JSON.stringify({wholeBouts:dataset.trajectories.length,
  humanTrainValidationSplitPreserved:true,legalMasks:'pure-all-input',lookLabels,sprintLabels,
  continuousMemory:true,ppoEligible:false,saved},null,2))
console.log(JSON.stringify({lookLabels,sprintLabels,saved}))
