from pathlib import Path
from datetime import datetime, timezone
import json, os, shutil, subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
if (BASE/'trained/checkpoint.json').exists():raise RuntimeError('Preserve the previous candidate')
environment=os.environ.copy()
environment.update(IMITATION_HEADS_ONLY='0',IMITATION_CONTEXT_ONLY='0',
    IMITATION_CONTEXT_HEADS='[2,4,5]',IMITATION_CALIBRATED_HEADS='[2,4,5]',
    IMITATION_DISTRIBUTION_VERSION='3',IMITATION_WEAPON_CONDITIONING='2',
    IMITATION_LR='0.00015',IMITATION_CONTEXT_RATE='2',IMITATION_BACKBONE_RATE='0.01',
    IMITATION_EPOCHS='2',IMITATION_FREQUENCY_HEADS='[4,6,7]',
    IMITATION_EXCHANGE_BALANCE='1',IMITATION_ADAPTED_ANCHOR='0.2',
    IMITATION_ADAPTED_HEADS='[1,2,4,5,6,7]')
state=json.loads((BASE/'state.json').read_text())
state.update(trainingRunning=True,trainingStartedAt=datetime.now(timezone.utc).isoformat(),
    learningUnit='whole ordered expert bouts; joint GRU/GTrXL/gate training, then full-bout PPO',
    automaticForcedCombatActions=False)
(BASE/'state.json').write_text(json.dumps(state,indent=2))
try:
    with (BASE/'training.log').open('wb')as log:
        subprocess.run([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/human-imitation.js'),
            str(BASE/'initial/checkpoint.json'),str(BASE/'whole-exchanges.json'),str(BASE/'trained')],
            cwd=ROOT,env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
    receipt=json.loads((BASE/'trained/receipt.json').read_text())
    state.update(offlineChecksPassed=receipt['offlineChecksPassed'],checks=receipt['checks'],
        candidateSha256=receipt['saved']['sha256'],trainingStatus='finished-offline')
except Exception as error:
    state.update(trainingStatus='failed',error=str(error));raise
finally:
    state['trainingRunning']=False
    (BASE/'state.json').write_text(json.dumps(state,indent=2))
print(json.dumps(state))
