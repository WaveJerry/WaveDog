"""Read-only event-aligned exposure review; does not prove a counterfactual dodge."""
from pathlib import Path
import argparse, json, math


def snapshot(frame):
    s, t, o = frame['self'], frame['seen'], frame['observation']
    c = frame.get('command') or {}
    angle = math.radians(c.get('aimYawOffset', 0))
    radial = c.get('forward', 0)*math.cos(angle)-c.get('side', 0)*math.sin(angle)
    return dict(tick=frame['tick'], distance=o.get('distance'), reach=o.get('reach'),
        held=s['held'], charge=s['charge'], attackAge=s.get('attackAgeTicks'),
        ground=s['ground'], targetVY=o.get('targetVelocity', {}).get('y'),
        criticalThreat=o.get('targetCriticalThreat'), criticalPossible=o.get('targetCriticalPossible'),
        forecastCriticalTick=(o.get('airEnvelope') or {}).get('criticalTick'),
        radialIntent=radial, side=c.get('side'), attackIntent=c.get('attack'),
        attackPacket=frame.get('attackPacket'), attackCharge=frame.get('attackCharge'),
        sprintIntent=c.get('sprint'), sprintExecuted=frame.get('executed', {}).get('sprint'),
        commandAge=frame.get('timings', {}).get('modelActionAgeTicks'))


def audit(trial):
    summary=trial['summary']
    frames=[json.loads(line) for line in Path(summary['frameFile']).read_text().splitlines()]
    packets={f.get('attackId'):f for f in frames if f.get('attackPacket')}
    events={}
    for f in frames:
        for e in f.get('nativeEvents', []):
            if e.get('cancelled') or not e.get('melee') or e.get('amount', 0)<=0: continue
            key=tuple(e.get(k) for k in ('serverTick','attackId','attacker','victim','amount'))
            events.setdefault(key, (f,e))  # Keep the first received timestamp.
    own=sorted([(f,e) for f,e in events.values() if e['attacker']==summary['fighter']],
        key=lambda pair:pair[1]['serverTick'])
    received=[(f,e) for f,e in events.values() if e['victim']==summary['fighter']]
    criticals=[]
    for f,e in received:
        if not e.get('nativeCritical'): continue
        previous=[(q,d) for q,d in own if 0<e['serverTick']-d['serverTick']<=20]
        hit,damage=previous[-1] if previous else (None,None)
        packet=packets.get(damage.get('attackId')) if damage else None
        start=packet['tick'] if packet else f['tick']-12
        window=[snapshot(q) for q in frames if start<=q['tick']<=f['tick']]
        early=[q for q in window if q['criticalThreat'] and q['tick']<f['tick']]
        retreat=[q for q in window if q['radialIntent']<-.25]
        criticals.append(dict(event=e,receivedAtTick=f['tick'],previousOwnDamage=damage,
            previousOwnAttackTick=packet['tick'] if packet else None,
            previousOwnWeapon=packet.get('attackHeld') if packet else None,
            firstForecastThreatTick=early[0]['tick'] if early else None,
            firstRetreatIntentTick=retreat[0]['tick'] if retreat else None,
            forecastThreatFramesWithoutRetreat=sum(q['radialIntent']>=-.25 for q in early),
            nearZeroChargeAxePackets=sum(q['attackPacket'] and q['held']==7 and
                (q['attackCharge'] if q['attackCharge'] is not None else 1)<.2 for q in window),
            window=window))
    ground_packets=[f for f in frames if f.get('attackPacket') and f['self']['ground']]
    sprint_conflicts=[f['tick'] for f in ground_packets if (f.get('command') or {}).get('sprint')
        and not f.get('executed', {}).get('sprint')]
    return dict(matchId=trial['matchId'], mode=trial['mode'], side=trial['side'],nearWall=trial['nearWall'],
        receivedHits=len(received), receivedCriticals=len(criticals), criticals=criticals,
        groundAttackSprintIntentWithoutExecutionTicks=sprint_conflicts,
        ownDamage=sum(e['amount'] for _,e in own), receivedDamage=sum(e['amount'] for _,e in received),
        descriptiveOnly=True, eventReceiptMayLagServerContact=True,
        previousOwnHitDoesNotProvePunishmentIntent=True, guaranteedAvoidance=False)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--suite',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists():raise RuntimeError('Preserve prior review')
    suite=json.loads(a.suite.read_text());rows=[audit(t) for t in suite['trials']]
    a.out.write_text(json.dumps(dict(checkpointSha256=suite['checkpointSha256'],trials=rows),indent=2))
    print(json.dumps([dict(matchId=r['matchId'],mode=r['mode'],side=r['side'],
        receivedCriticals=r['receivedCriticals'],sprintConflicts=len(r['groundAttackSprintIntentWithoutExecutionTicks']),
        criticalWindows=[{k:v for k,v in c.items() if k not in ['window','event','previousOwnDamage']} for c in r['criticals']]) for r in rows]))
