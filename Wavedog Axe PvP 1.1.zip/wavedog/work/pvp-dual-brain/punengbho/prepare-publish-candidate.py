"""Stage a trained policy (or freeze current weights) without mutating live state."""
from pathlib import Path
import argparse,hashlib,json,shutil
from whole_bout_splits import require_whole_bout_splits
ROOT=Path(__file__).resolve().parents[3]
LIVE=ROOT/'work/wavedog-punengbho/model'
p=argparse.ArgumentParser();p.add_argument('--trained',type=Path);p.add_argument('--out',type=Path,required=True)
p.add_argument('--reviewed-evaluation-dataset',type=Path,
    help='Allow an independently corrected validation set only when every training input/target is identical')
p.add_argument('--freeze-current',action='store_true');a=p.parse_args()
if bool(a.trained)==a.freeze_current:raise ValueError('Choose trained policy or current-weight freeze')
current=json.loads((LIVE/'checkpoint.json').read_text())
candidate=json.loads((a.trained/'checkpoint.json').read_text())if a.trained else json.loads(json.dumps(current))
if a.trained:
    receipt=json.loads((a.trained/'receipt.json').read_text())
    evaluation_dataset=Path(receipt['dataset'])
    validation_review=None
    if a.reviewed_evaluation_dataset:
        original=json.loads(evaluation_dataset.read_text(encoding='utf-8'))
        reviewed=json.loads(a.reviewed_evaluation_dataset.read_text(encoding='utf-8'))
        require_whole_bout_splits(original);require_whole_bout_splits(reviewed)
        fields=['tick','observation','context','publicHealthFeatures','publicSpatialFeatures',
            'publicThreatFeatures','legalMasks','labels','actions','publicRequest','expertReason','supervisionWeight']
        def training_payload(data):
            return [(t['source'],t['matchId'],t.get('lesson'),t.get('sourceKind'),
                [{k:f.get(k) for k in fields} for f in t['frames']])
                for t in data['trajectories'] if t['split']=='train']
        if training_payload(original)!=training_payload(reviewed):
            raise RuntimeError('Validation correction changed training inputs or targets; retraining required')
        def input_payload(data):
            return [(t['source'],t['matchId'],t['split'],
                [{k:f.get(k) for k in fields if k not in ['labels','actions','expertReason']}
                    for f in t['frames']]) for t in data['trajectories']]
        if input_payload(original)!=input_payload(reviewed):
            raise RuntimeError('Validation correction may only change labels, not input, split or episode')
        validation_review={'trainingInputsAndTargetsIdentical':True,'validationInputsAndSplitsIdentical':True,
            'dataset':str(a.reviewed_evaluation_dataset.resolve()),
            'sha256':hashlib.sha256(a.reviewed_evaluation_dataset.read_bytes()).hexdigest()}
        evaluation_dataset=a.reviewed_evaluation_dataset
    if receipt.get('schema')=='supervised-current-state-correction-v1':
        require_whole_bout_splits(json.loads(Path(receipt['dataset']).read_text()))
        dataset_sha=hashlib.sha256(Path(receipt['dataset']).read_bytes()).hexdigest()
        if receipt.get('datasetSha256')!=dataset_sha or receipt.get('baselineDatasetSha256')!=dataset_sha:
            raise RuntimeError('Correction baseline must use the same unchanged dataset')
        if receipt.get('baselineReferenceSha256')!=current['sha256']:
            raise RuntimeError('Correction baseline must use the current live reference')
    if not receipt['offlineChecksPassed']or not receipt.get('allBackbonesTrained'):
        raise RuntimeError('Training checks failed; no publication')
    if candidate['config'].get('publicThreatInputs'):
        if not receipt.get('causalThreatFeaturesUsed'):
            raise RuntimeError('Public forecast training inputs were not verified')
        if not json.loads((a.trained/'autonomous-audit.json').read_text(encoding='utf-8')).get('causalThreatFeaturesUsed'):
            raise RuntimeError('Public forecast autonomous evaluation inputs were not verified')
    if receipt.get('spatialOnly'):
        spatial=json.loads((a.trained/'spatial-audit.json').read_text())
        if not spatial.get('passed') or not spatial.get('originalCombatParametersUnchanged'):
            raise RuntimeError('Spatial preservation checks failed')
        # A refinement can follow a real joint backbone update. Its exact
        # frozen-weight assertion concerns that stage's input checkpoint;
        # full-pipeline skill retention below still compares to LIVE weights.
        spatial_reference=receipt['sourceSha256'] if receipt.get('frozenBackbonesUnchanged') else current['sha256']
        if spatial.get('candidateSha256')!=candidate['sha256'] or spatial.get('referenceSha256')!=spatial_reference:
            raise RuntimeError('Spatial audit belongs to different weights')
        if spatial.get('datasetSha256')!=hashlib.sha256(Path(receipt['dataset']).read_bytes()).hexdigest():
            raise RuntimeError('Spatial audit used a different dataset')
    if candidate['config'].get('actionConditionedAttack')==1:
        joint_file=a.trained/'autonomous-audit.json'
        if not joint_file.exists():raise RuntimeError('Policy-selected parent action audit required')
        joint=json.loads(joint_file.read_text())
        if not joint.get('passed') or not joint.get('usesPolicySelectedParents'):
            raise RuntimeError('Autonomous conditional action checks failed')
        if joint.get('candidateSha256')!=candidate['sha256'] or joint.get('referenceSha256')!=current['sha256']:
            raise RuntimeError('Conditional action audit belongs to different weights')
        if joint.get('datasetSha256')!=hashlib.sha256(evaluation_dataset.read_bytes()).hexdigest():
            raise RuntimeError('Conditional action audit used a different dataset')
    source=json.loads(Path(receipt['source']).read_text())
    reference=json.loads(Path(receipt.get('referenceCheckpoint',receipt['source'])).read_text())
    if reference['sha256']!=current['sha256']:raise RuntimeError('New live learning must be preserved/rebased')
    if source['sha256']!=reference['sha256']:
        # A second curriculum stage may continue an unpublished BC candidate.
        # Its checks must compare with the still-live original, and its first
        # stage must demonstrably descend from that exact original checkpoint.
        parent=json.loads(Path(receipt['source']).with_name('receipt.json').read_text())
        if parent.get('referenceSha256',parent['sourceSha256'])!=reference['sha256']:
            raise RuntimeError('Unverified curriculum source chain')
        if receipt.get('referenceSha256')!=reference['sha256']:
            raise RuntimeError('Candidate was not evaluated against live reference')
    for key in ['dualUpdates','lastRolloutSeq']:
        if current['counters'][key]!=candidate['counters'][key]:raise RuntimeError('Learning cursor differs')
candidate['config']['trainingStage']='behavior-cloning'
if a.trained:
    # Earlier BC receipts counted this session's steps, not a cumulative
    # lifetime total. Preserve both figures explicitly without changing bytes.
    session_steps=receipt.get('imitationStepsSinceReference',receipt['best']['steps'])
    candidate['counters']['lastImitationSessionSteps']=session_steps
    candidate['counters']['humanImitationUpdates']=current['counters'].get('humanImitationUpdates',0)+session_steps
    candidate['counters']['behaviorCloningSteps']=current['counters'].get('behaviorCloningSteps',0)+session_steps
a.out.mkdir(exist_ok=False,parents=True);(a.out/'source').mkdir()
for name in ['checkpoint.json',current['binary']]:shutil.copy2(LIVE/name,a.out/'source'/name)
folder=a.trained or LIVE
payload=(folder/candidate['binary']).read_bytes()
assert hashlib.sha256(payload).hexdigest()==candidate['sha256']
(a.out/candidate['binary']).write_bytes(payload)
(a.out/'checkpoint.json').write_text(json.dumps(candidate))
(a.out/'receipt.json').write_text(json.dumps({'offlineChecksPassed':True,'sourceSha256':current['sha256'],
  'originalReceipt':str(a.trained/'receipt.json')if a.trained else None,
  'validationReview':validation_review if a.trained else None,
  'weightBytesChanged':candidate['sha256']!=current['sha256'],'frozenEvaluation':True,
  'fullTacticalMasteryVerified':False},indent=2))
print(json.dumps({'candidate':str(a.out/'checkpoint.json'),'sha256':candidate['sha256'],'frozen':True}))
