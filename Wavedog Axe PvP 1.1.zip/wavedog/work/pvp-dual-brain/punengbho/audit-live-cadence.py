"""Inspect recorded execution and supervision; never issue combat inputs."""
from pathlib import Path
from collections import Counter
import json, gzip

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'outputs/punengbho-integration-20261117'
result = {'bouts': []}
result['rolloutDistributions'] = []
for seq in [2040,2041]:
    rows = json.load(gzip.open(ROOT/'work/wavedog-punengbho/model/rollouts'/f'rollout-{seq:012d}.json.gz'))['episode']
    groups = {}
    for f in rows:
        x=f['observation']; held=1 if x[12]<.25 else 0
        p=f['oldHeadProbabilities']
        key=('sword' if held==1 else 'axe')+(' low' if x[1]<.4 else ' charged')
        g=groups.setdefault(key,{'frames':0,'switchProbability':0,'attackProbability':0,'sprintProbability':0})
        g['frames']+=1;g['switchProbability']+=p[5][1-held]
        g['attackProbability']+=p[4][2];g['sprintProbability']+=p[1][1]
    for g in groups.values():
        for k in ['switchProbability','attackProbability','sprintProbability']:g[k]/=g['frames']
    result['rolloutDistributions'].append({'seq':seq,'groups':groups})
for match in ['d2fb7c65-3ce1-47a3-a2eb-e569203014c3', 'bbb0507e-5671-4611-9b9f-cec62fbac796']:
    frames = [json.loads(s) for s in (ROOT/'work/wavedog-punengbho/runtime'/f'{match}-frames.jsonl').read_text().splitlines()]
    attacks, switches, events = [], [], []
    previous = None
    for f in frames:
        if previous and f['self']['held'] != previous['self']['held']:
            switches.append({'tick': f['tick'], 'from': previous['self']['held'], 'to': f['self']['held'],
                'oldCharge': previous['self']['charge'], 'reach': f['observation']['reach'],
                'command': previous['command'].get('slot'), 'epoch': f['weaponEpoch']})
        if f.get('attackPacket'):
            attacks.append({'tick': f['tick'], 'held': f['attackHeld'], 'charge': f['attackCharge'],
                'reach': f['observation']['reach'], 'vy': f['self']['vy'],
                'ground': f['self']['ground'], 'sprint': f['executed']['sprint'],
                'nativeSelf': f.get('nativeSelf'), 'dealt': f.get('nativeDealt')})
        for e in f.get('nativeEvents', []):
            if e.get('attacker') == 'Punengbho' and not e.get('cancelled'):
                events.append(e)
        previous = f
    result['bouts'].append({'match': match, 'frames': len(frames), 'switches': switches,
        'attacks': attacks, 'damageEvents': events,
        'selectedSlotCounts': dict(Counter(f['command'].get('slot') for f in frames)),
        'readyGroundedAxeEdgeAttacks': sum(a['held']==7 and a['ground'] and a['reach']>=2.6 and a['charge']>=.75 for a in attacks)})
dataset = json.loads((BASE/'refinement/whole-exchanges.json').read_text())
result['dataset'] = []
for split in ['train', 'validation']:
    counts = Counter(); transitions = Counter(); total = 0
    for t in dataset['trajectories']:
        if t['split'] != split: continue
        for f in t['frames']:
            total += 1
            a = f['labels'].get('5')
            if a is not None:
                held = f['publicRequest']['self']['held']
                transitions[f'{held}->{a}'] += 1
                counts[str(a)] += 1
    result['dataset'].append({'split': split, 'frames': total,
        'weaponLabelCounts': dict(counts), 'observedHeldToLabel': dict(transitions)})
result['sources'] = [{'fighter': t.get('fighter'), 'opponent': t.get('opponent'),
    'source': t['source'], 'split': t['split'], 'frames': len(t['frames']),
    'firstFrame': {k:v for k,v in t['frames'][0].items() if k not in ['reference','observation']},
    'expertSwitches': sum(a['publicRequest']['self']['held'] != b['publicRequest']['self']['held']
        for a,b in zip(t['frames'],t['frames'][1:]))} for t in dataset['trajectories']]
dest=BASE/'live-cadence-audit.json'
dest.write_text(json.dumps(result, indent=2), encoding='utf8')
for b in result['bouts']:
    print(json.dumps({'match':b['match'], 'switches':len(b['switches']),
        'attackCadence':[{k:v for k,v in a.items() if k not in ['nativeSelf']} for a in b['attacks']],
        'readyGroundedAxeEdgeAttacks':b['readyGroundedAxeEdgeAttacks']}))
print(json.dumps(result['dataset']))
print(json.dumps([{k:v for k,v in t.items() if k != 'firstFrame'} for t in result['sources']]))
print(json.dumps(result['sources'][0]['firstFrame']))
print(json.dumps(result['rolloutDistributions']))
