import fs from 'node:fs'
import path from 'node:path'
import {localReview}from './protocol-review.js'
const base=path.resolve('outputs/punengbho-integration-20261117')
const teaching=JSON.parse(fs.readFileSync(path.join(base,'teaching.json')))
const ref=JSON.parse(fs.readFileSync('outputs/sword-learning-next-20261116/joint-expert-sequences-v1/wasplan-six-crit-reference.json'))
const answer=await localReview([{role:'system',content:'你是独立纯神经PVP模型的训练教练。用户给的是可因局面组合取舍的理念，不是固定动作线路。按示范逐帧理解前因后果，给一个可验证训练目标；不能声称已经学会。只输出规定JSON。'},
  {role:'user',content:JSON.stringify({teaching,
    source:ref.source,fields:['tick','held','charge','ground','vy','target_dx','target_dy','target_dz','shield','native_labels'],
    frames:ref.frames.map(f=>{const {self:s,seen:t}=f.publicRequest;return [f.tick,s.held,s.charge,s.ground,s.vy,t.x-s.x,t.y-s.y,t.z-s.z,t.shield,f.labels]}),
    verifiedResults:ref.nativeCriticalEvidence,tickGaps:ref.tickGaps})}])
const receipt={at:new Date().toISOString(),source:'operator-understanding-plus-native-expert-example',
  sourceSha256:ref.sourceSha256,reviewedFrames:ref.frames.length,fullReferenceCoverage:true,
  modelMasteryClaimed:false,...answer}
fs.writeFileSync(path.join(base,'qwen-teaching-review.json'),JSON.stringify(receipt,null,2))
console.log(JSON.stringify(receipt))
