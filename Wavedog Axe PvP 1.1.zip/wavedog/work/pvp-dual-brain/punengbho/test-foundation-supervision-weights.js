import assert from 'node:assert/strict'
import {foundationSupervisionWeights} from './foundation-supervision-weights.js'
const frame=a=>({labels:{2:a,5:a}})
const train={lesson:'close',split:'train',frames:[...Array.from({length:100},()=>frame(0)),frame(1)]}
const validation={lesson:'close',split:'validation',frames:Array.from({length:1000},()=>frame(1))}
const a=foundationSupervisionWeights({trajectories:[train]}),b=foundationSupervisionWeights({trajectories:[train,validation]})
assert.deepEqual(a,b,'validation labels must not tune training weights')
assert(a.weights.close[2][1]>a.weights.close[2][0]*9,'rare actual jump receives useful supervision')
assert(Math.abs((100*a.weights.close[2][0]+a.weights.close[2][1])/101-1)<1e-12)
assert.deepEqual(train.frames[0].labels,{2:0,5:0},'balancing never changes actual labels')
assert.equal(foundationSupervisionWeights({trajectories:[train]},new Set([4])).weights.close[2],undefined)
console.log('FOUNDATION_TRAIN_ONLY_CLASS_BALANCING_PASS')
const sprintTrain={lesson:'movement',split:'train',frames:[
  ...Array.from({length:400},()=>({labels:{1:1,4:0}})),
  ...Array.from({length:100},()=>({labels:{1:0,4:2}}))]}
const sprintValid={lesson:'movement',split:'validation',frames:[{labels:{1:1,4:0}}]}
const sprintWeights=foundationSupervisionWeights({trajectories:[sprintTrain]},new Set([1,4]),new Set([1]))
assert.deepEqual(sprintWeights,foundationSupervisionWeights({trajectories:[sprintTrain,sprintValid]},
  new Set([1,4]),new Set([1])),'validation cannot set class weights')
assert.equal(sprintWeights.weights.movement[1][0]*100,sprintWeights.weights.movement[1][1]*400,
  'sprint and release each contribute equal training mass')
assert.deepEqual(sprintWeights.weights.movement[4],
  foundationSupervisionWeights({trajectories:[sprintTrain]},new Set([1,4])).weights.movement[4],
  'selecting sprint balancing cannot reweight attack labels')
console.log('SELECTED_SPRINT_TRAIN_ONLY_BALANCING_PASS')
