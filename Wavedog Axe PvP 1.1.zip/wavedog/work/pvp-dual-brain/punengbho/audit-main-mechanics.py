"""Read-only audit of real WaveDog journals; no live control or inferred keys."""
from pathlib import Path
from collections import Counter
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
LIVE=ROOT/'work/wavedog-protocol/runtime'
rows=[]
for report in sorted(LIVE.glob('*-report.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:8]:
    result=json.loads(report.read_text());file=Path(result['completedFrames'])
    if not file.exists():continue
    frames=[json.loads(x)for x in file.read_text().splitlines()]
    hits={f.get('attackId'):f for f in frames if f.get('attackPacket')}
    damage=[e for f in frames for e in f.get('nativeEvents',[])if e.get('attacker')=='WaveDog'
        and not e.get('cancelled')and e.get('amount',0)>0]
    escape=[f for f in frames if f.get('mode')=='ESCAPE']
    neural=[f for f in frames if f.get('mode')=='NEURAL']
    rows.append({'match':result['matchId'],'opponent':result['opponent'],'outcome':result['outcome'],
        'modes':dict(Counter(f['mode']for f in frames)),
        'escapeWindowStatuses':dict(Counter(f['command'].get('escapeAttackStatus')for f in escape)),
        'actualEscapeAttacks':[{'tick':f['tick'],'kind':f['command'].get('kind'),'held':f.get('attackHeld'),
            'packets':f.get('actualPackets'),'executed':f.get('executed')}for f in escape if f.get('attackPacket')],
        'neuralAttackRequests':sum(bool(f['command'].get('attack'))for f in neural),
        'neuralActualAttackPackets':sum(bool(f.get('attackPacket'))for f in neural),
        'neuralMainhandOwners':dict(Counter(f['owners'].get('mainhand')for f in neural)),
        'neuralMovementOwners':dict(Counter(f['owners'].get('movement')for f in neural)),
        'neuralRequestedSprintChanged':sum(bool(f['command'].get('sprint'))!=bool(f['executed'].get('sprint'))for f in neural),
        'rangedReasons':dict(Counter(f['command'].get('rangedReason')for f in frames if f['command'].get('ranged'))),
        'nativeEscapeCriticals':sum(e.get('nativeCritical',False)and hits.get(e.get('attackId'),{}).get('command',{}).get('kind')=='escape-critical'for e in damage),
        'nativeSwordCriticals':sum(e.get('nativeCritical',False)and hits.get(e.get('attackId'),{}).get('attackHeld')==0 for e in damage)})
source=ROOT/'work/pvp-player-client'
ready=json.loads((LIVE/'client-ready.json').read_text())
hashes={name:hashlib.sha256((source/name).read_bytes()).hexdigest()==sha for name,sha in ready['sourceSha256'].items()}
out={'readOnly':True,'mainServerModified':False,'runtimeSourceAgreement':hashes,'bouts':rows,
  'limits':['Per-frame summaries contain packet names; use the separate ordered packets.jsonl journal for sprint-stop ordering',
    'Neural sprint changes are candidates for ownership review, not automatic proof every change is wrong',
    'No runtime comparison to original fake-player implementation has yet been performed']}
dest=ROOT/'outputs/punengbho-rebuild-20261117/main-mechanical-audit.json'
dest.write_text(json.dumps(out,indent=2))
print(json.dumps({'mainServerModified':False,'bouts':len(rows),'runtimeSourceAgreement':all(hashes.values()),
    'escapeFrames':sum(r['modes'].get('ESCAPE',0)for r in rows),
    'nativeEscapeCriticals':sum(r['nativeEscapeCriticals']for r in rows),
    'neuralRequestedSprintChanged':sum(r['neuralRequestedSprintChanged']for r in rows)}))
