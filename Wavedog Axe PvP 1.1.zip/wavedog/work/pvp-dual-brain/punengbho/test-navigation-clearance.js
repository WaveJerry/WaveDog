import assert from 'node:assert/strict'
import {publicSpatialFeatures}from '../public-spatial-features.js'
const base={tick:10,self:{x:0,y:0,z:0},seen:{visible:true,x:0,y:0,z:3},publicTerrain:{walls:[8,8,8,8]}}
const legacy=publicSpatialFeatures(base)
const navigation={version:1,tick:10,origin:{x:0,y:0,z:0},toward:{x:0,z:1},routes:{
 away:{clearance:.2},toward:{clearance:4},right:{clearance:2},left:{clearance:3}}}
const req={...base,publicTerrain:{...base.publicTerrain,navigation}}
assert.deepEqual(publicSpatialFeatures(req).slice(1,5),[.2/8,4/8,2/8,3/8])
for(const altered of [{...navigation,tick:9},{...navigation,origin:{x:1,y:0,z:0}},
 {...navigation,toward:{x:1,z:0}},{...navigation,routes:{...navigation.routes,left:{clearance:NaN}}}])
 assert.deepEqual(publicSpatialFeatures({...req,publicTerrain:{...req.publicTerrain,navigation:altered}}),legacy)
assert.deepEqual(publicSpatialFeatures(req).slice(5),legacy.slice(5),'navigation does not change combat reach or opponent velocity')
console.log('SAME_FRAME_BODY_ROUTE_INPUT_AND_LEGACY_GEOMETRY_PASS')
