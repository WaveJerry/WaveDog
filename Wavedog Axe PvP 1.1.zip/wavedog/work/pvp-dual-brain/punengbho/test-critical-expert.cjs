const assert=require('node:assert/strict')
const {criticalExpert,observeLearnerInput}=require('./critical-expert.cjs')
const req={tick:100,self:{x:0,y:0,z:0,eyeY:1.62,held:0,ground:false,wireFalling:true,
  attackAgeTicks:14,weaponAgeTicks:30},seen:{visible:true,x:0,y:0,z:2.9,shield:false}}
const run=(self={},seen={})=>criticalExpert({...req,self:{...req.self,...self},seen:{...req.seen,...seen}})
assert.equal(run().labels[4],2)
assert.equal(run().labels[1],0,'the offline teacher releases sprint for its critical')
assert.equal(run({attackAgeTicks:2}).labels[4],0,'real previous attack controls cooldown')
assert.equal(run({weaponAgeTicks:2}).labels[4],0)
assert.equal(run({ground:true}).labels[4],0)
assert.equal(run({wireFalling:false}).labels[4],0,'predicted fall alone is insufficient')
assert.equal(run({}, {z:3.31}).labels[4],0)
assert.deepEqual(run({}, {shield:true}).labels,{})
assert.deepEqual(run({}, {visible:false}).labels,{})
const history={}
const grounded={...req,self:{...req.self,ground:true},seen:{...req.seen,z:1.5}}
assert.equal(criticalExpert(grounded,history).labels[2],1)
// Merely querying the expert must not reset attack or jump history.
criticalExpert(grounded,history);assert.deepEqual(history,{})
observeLearnerInput(history,grounded,{jump:true})
assert.equal(criticalExpert({...grounded,tick:101},history).labels[2],1,'no artificial rest before the next legal close jump')
assert.equal(criticalExpert({...grounded,tick:115},history).labels[2],1)
assert.equal(criticalExpert({...grounded,seen:{...grounded.seen,z:3.2}},history).labels[2],0,
  'distant approach stays grounded even though continuous close jumping is available')
console.log('OFFLINE_DAGGER_EXPERT_PASS')
