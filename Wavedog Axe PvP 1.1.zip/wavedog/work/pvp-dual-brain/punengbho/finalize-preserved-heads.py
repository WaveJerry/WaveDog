"""Attach complete independent checks to a parameter-preserving ablation."""
from pathlib import Path
import hashlib
import json
import sys

folder = Path(sys.argv[1])
p = folder / 'receipt.json'
r = json.loads(p.read_text(encoding='utf-8'))
m = json.loads((folder / 'checkpoint.json').read_text(encoding='utf-8'))
a = json.loads((folder / 'autonomous-audit.json').read_text(encoding='utf-8'))
assert r['schema'] == 'preserved-context-heads-bc-v1' and r['independentAuditPending']
assert r['retainedUnselectedParametersExact'] and r['frozenBackbonesUnchanged']
assert hashlib.sha256((folder / m['binary']).read_bytes()).hexdigest() == m['sha256']
assert hashlib.sha256(Path(r['dataset']).read_bytes()).hexdigest() == r['datasetSha256']
assert a['candidateSha256'] == m['sha256'] and a['referenceSha256'] == r['referenceSha256']
assert a['datasetSha256'] == r['datasetSha256'] and a['passed'] and all(a['checks'].values())
assert a['usesPolicySelectedParents'] and a['causalThreatFeaturesUsed']
assert any(k.startswith('groundContact:') for k in a['checks'])
assert any(k.startswith('responseWindow:') for k in a['checks'])
(folder / 'pre-audit-receipt.json').write_bytes(p.read_bytes())
r.update(offlineChecksPassed=True, independentAuditPending=False,
         validationKind='independent-autonomous-ground-and-response-windows', checks=a['checks'], baseline=a['baseline'])
r['best']['validation'] = a['candidate']
p.write_text(json.dumps(r, indent=2), encoding='utf-8')
print(json.dumps({'validated': True, 'sha256': m['sha256'], 'optimizationStepsHere': 0}))
