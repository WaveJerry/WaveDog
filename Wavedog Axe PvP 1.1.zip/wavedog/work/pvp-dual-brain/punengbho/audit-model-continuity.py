"""Describe observed weapon churn, critical opportunities and sprint retreat.
Public recorded states are diagnostics, never proof of a server hit or labels.
"""
from pathlib import Path
import argparse, json, math

def wire_reach(frame):
    sent = frame['observation'].get('sentPosition')
    if not sent:
        return math.inf
    target = frame['seen']
    eye = sent['y'] + frame['self'].get('eyeY', frame['self']['y'] + 1.62) - frame['self']['y']
    return math.sqrt(max(0, abs(sent['x']-target['x'])-.3)**2 +
        max(0, abs(sent['z']-target['z'])-.3)**2 +
        max(target['y']-eye, 0, eye-target['y']-1.8)**2)

def audit(frames):
    switches = []; opportunities = []; retreats = []; close_axe_choices = []
    close = False
    for index, f in enumerate(frames):
        s, t, o = f['self'], f['seen'], f['observation']
        c, executed = f.get('command') or {}, f.get('executed') or {}
        if index and s['held'] != frames[index-1]['self']['held']:
            switches.append({'tick': f['tick'], 'from': frames[index-1]['self']['held'], 'to': s['held']})
        if not t.get('visible'):
            close = False
            continue
        horizontal = math.hypot(s['x']-t['x'], s['z']-t['z'])
        reachable = o.get('reach', math.inf) <= 3 and wire_reach(f) <= 3
        if not reachable:
            close = False
        elif horizontal < 2.05:
            close = True
        shield = t.get('shield') or t.get('shieldRaised')
        if close and not shield and c.get('slot') == 7:
            close_axe_choices.append(f['tick'])
        if s['held'] == 0 and not s.get('ground') and s.get('wireFalling') and s['charge'] > .9 and reachable and not shield:
            opportunities.append({'tick': f['tick'], 'modelAttack': c.get('attack'),
                'modelSprint': c.get('sprint'), 'packetSent': bool(f.get('attackPacket')),
                'suppressed': f.get('attackSuppressedReason')})
        away = math.cos(math.radians(c.get('aimYawOffset', 0))) < -.5
        if s['held'] == 7 and s['charge'] < .9 and away and executed.get('forward') and executed.get('sprint'):
            next_frame = frames[index+1] if index+1 < len(frames) else None
            outward = None
            if next_frame and horizontal > 0:
                n = next_frame['self']
                outward = -((n['x']-s['x'])*(t['x']-s['x']) + (n['z']-s['z'])*(t['z']-s['z'])) / horizontal
            retreats.append({'tick': f['tick'], 'ground': s.get('ground'), 'outwardDisplacement': outward})
    return {'weaponSwitchCount': len(switches), 'weaponSwitches': switches,
        'recordedChargedFallingSwordOpportunities': opportunities,
        'opportunityCount': len(opportunities),
        'opportunitiesWithAttackPacket': sum(r['packetSent'] for r in opportunities),
        'unshieldedCloseAxeChoiceCount': len(close_axe_choices),
        'unshieldedCloseAxeChoiceTicks': close_axe_choices,
        'chargingAxeForwardSprintAwayFrames': retreats,
        'chargingAxeForwardSprintAwayCount': len(retreats),
        'publicStateDiagnosticOnly': True, 'nativeCriticalEvidenceRequired': True,
        'movementCanIncludeKnockback': True, 'fullTacticalMastery': False}

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--suite', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.out.exists():
        raise RuntimeError('Preserve existing evidence')
    suite = json.loads(a.suite.read_text())
    trials = []
    for trial in suite['trials']:
        frames = [json.loads(line) for line in Path(trial['summary']['frameFile']).read_text().splitlines()]
        result = {'matchId': trial['matchId'], 'mode': trial['mode'], **audit(frames)}
        trials.append(result)
        print(json.dumps({k: v for k, v in result.items() if k in ['matchId', 'mode', 'weaponSwitchCount',
            'opportunityCount', 'opportunitiesWithAttackPacket', 'unshieldedCloseAxeChoiceCount',
            'chargingAxeForwardSprintAwayCount']}))
    a.out.write_text(json.dumps({'checkpointSha256': suite['checkpointSha256'], 'trials': trials}, indent=2))
