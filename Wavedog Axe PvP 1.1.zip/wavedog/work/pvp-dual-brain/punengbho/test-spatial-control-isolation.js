import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
await tf.setBackend('cpu');await tf.ready()
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:32,
  spatialMovementVersion:1,spatialMovementHeads:[0,1,6,5,4,2],spatialControlSplitHeads:[0,2,5]})
try{
  // Nonzero outputs make representation interference visible in this test.
  tf.tidy(()=>model.spatialMovementOut.forEach((p,i)=>p.w.assign(tf.fill(p.w.shape,(i+1)*.01))))
  const input=tf.ones([3,OBS_SIZE]),spatial=tf.ones([3,8])
  const capture=()=>tf.tidy(()=>model.spatialMovementResidualBatch(input,spatial).map(t=>t.arraySync()))
  const before=capture()
  const params=[...model.spatialControlIn.params,...model.spatialMovementOut
    .filter((p,i)=>[0,2,5].includes(model.spatialMovementHeads[i])).flatMap(p=>p.params)]
  const optimizer=tf.train.sgd(.03)
  optimizer.minimize(()=>tf.tidy(()=>tf.addN(model.spatialMovementResidualBatch(input,spatial)
    .filter((p,i)=>[0,2,5].includes(model.spatialMovementHeads[i])).map(p=>tf.mean(tf.square(p))))),false,params)
  const after=capture()
  for(const[i,h]of model.spatialMovementHeads.entries()){
    if([0,2,5].includes(h))assert.notDeepEqual(after[i],before[i])
    else assert.deepEqual(after[i],before[i],'preserved head '+h+' changed')
  }
  const single=tf.tidy(()=>model.spatialMovementResidual(tf.ones([1,OBS_SIZE]),Array(8).fill(1)).map(t=>t.arraySync()[0]))
  for(let i=0;i<single.length;i++)assert.deepEqual(single[i],after[i][0],'batch and runtime projections differ')
  input.dispose();spatial.dispose();optimizer.dispose()
  console.log('SPLIT_SPATIAL_CONTROL_GRADIENT_ISOLATION_AND_BATCH_PARITY_PASS')
}finally{model.dispose()}
