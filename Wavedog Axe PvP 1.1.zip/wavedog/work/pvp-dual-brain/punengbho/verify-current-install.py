from pathlib import Path
import hashlib,json,runpy
from datetime import datetime,timezone
from importlib.machinery import SourceFileLoader
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
LIVE=ROOT/'work/wavedog-punengbho'
audit=SourceFileLoader('pure_status',str(Path(__file__).with_name('integration-status.py'))).load_module()
row=audit.status(18776)
manifest=json.loads((LIVE/'model/checkpoint.json').read_text())
ready=json.loads((LIVE/'runtime/client-ready.json').read_text())
process=json.loads((LIVE/'runtime/client-process.json').read_text())
assert ready['pid']==process['pid'],'Client has not spawned yet; preserve its retrying process'
for name,digest in ready['sourceSha256'].items():
    assert hashlib.sha256((ROOT/'work/pvp-player-client'/name).read_bytes()).hexdigest()==digest,name
for name,digest in row['runtimeSourceSha256'].items():
    assert hashlib.sha256((ROOT/'work/pvp-dual-brain/punengbho'/name).read_bytes()).hexdigest()==digest,name
assert row['checkpointSha256']==manifest['sha256']
assert row['config']==manifest['config']
assert row['controlRegime']=='pure-model-all-input'
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
status=command('wavedog_punengbho status')
assert '协议玩家=true'in status and '模型=true'in status,status
receipt={'at':datetime.now(timezone.utc).isoformat(),'installed':True,'checkpointSha256':row['checkpointSha256'],
    'client':ready,'runtimeSourceSha256':row['runtimeSourceSha256'],'config':row['config'],
    'oldRuntimeReplaced':True,'allInputsModelOwned':True,'mainMinecraftRestarted':False,
    'allTacticsMastered':False,'lateLoginVerified':True}
file=BASE/('install-trained-'+manifest['sha256'][:12]+'-receipt.json')
file.write_text(json.dumps(receipt,indent=2))
print(json.dumps({'verified':True,'sha256':manifest['sha256'],'controllerCode':ready['controllerCode']}))
