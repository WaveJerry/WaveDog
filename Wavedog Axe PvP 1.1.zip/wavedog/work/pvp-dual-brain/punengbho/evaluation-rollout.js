import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import zlib from 'node:zlib'
// Separate directory: these are genuine learner observations/actions, retained
// for analysis/DAgger. They must never enter PPO recovery as pending rollouts.
export function saveEvaluationRollout(checkpointPath,episode,metadata){
  if(!episode.length||!/^[-a-zA-Z0-9]+$/.test(metadata.matchId))throw Error('Invalid evaluation bout')
  const dir=path.join(path.dirname(checkpointPath),'evaluations');fs.mkdirSync(dir,{recursive:true})
  const file=path.join(dir,metadata.matchId+'.json.gz')
  const payload=zlib.gzipSync(JSON.stringify({schema:'frozen-policy-evaluation-v1',
    ppoEligible:false,...metadata,episode}))
  // Exclusive creation protects evidence from accidental duplicate finish.
  fs.writeFileSync(file,payload,{flag:'wx'})
  return {file,sha256:crypto.createHash('sha256').update(payload).digest('hex')}
}
