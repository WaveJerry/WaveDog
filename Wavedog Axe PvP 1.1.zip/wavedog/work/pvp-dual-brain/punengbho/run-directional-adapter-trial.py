"""Visible cage-3 packet-adapter test with two ordinary probes; no learned policy claim."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,runpy,shutil,subprocess,time,uuid,math
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
players=command('list')
if any(n in players for n in ['WaveDogSon','WDShieldTrial']):raise RuntimeError('Existing probes preserved')
if 'desired=0 'not in command('selfplay status'):raise RuntimeError('Preserve ongoing selfplay')
state=json.loads((ROOT/'work/wavedog-punengbho/runtime/client-state.json').read_text())
if state.get('active'):raise RuntimeError('Pilot is already fighting; preserve bout')
dest=BASE/('directional-adapter-live-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S'));dest.mkdir()
folders={n:dest/n for n in ['WaveDogSon','WDShieldTrial']}
procs=[];streams=[]
def blue(text):
 command('tellraw WaveJerry '+json.dumps({'text':'[第三竞技场 · 执行层测试] '+text,'color':'aqua'},ensure_ascii=True))
def order(name,active=False,match='',offset=180):
 folder=folders[name];row={'target':'WDShieldTrial'if name=='WaveDogSon'else'WaveDogSon',
  'mode':'adapter-directional-input'if name=='WaveDogSon'else'adapter-stationary',
  'active':active,'matchId':match,'directionalYaw':offset,'prepareSlot':0}
 tmp=folder/'probe-command.tmp';tmp.write_text(json.dumps(row));os.replace(tmp,folder/'probe-command.json')
try:
 for name,folder in folders.items():
  folder.mkdir()
  prior=ROOT/('work/wavedog-protocol/runtime/probe-auth.json'if name=='WaveDogSon'
    else'outputs/punengbho-rebuild-20261117/shield-demo-defender-runtime/probe-auth.json')
  shutil.copy2(prior,folder/'probe-auth.json');order(name)
  env=os.environ.copy();env.update(WAVEDOG_PROBE_NAME=name,WAVEDOG_PROBE_RUNTIME=str(folder),
    WAVEDOG_PROBE_FEEDBACK=str(folder/'public-feedback.jsonl'))
  out=(folder/'out.log').open('wb');err=(folder/'err.log').open('wb');streams.extend([out,err])
  proc=subprocess.Popen(['E:/node/node.exe',str(ROOT/'work/pvp-player-client/protocol-wavedog-probe.js')],
    cwd=ROOT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW);procs.append(proc)
  deadline=time.monotonic()+40
  while name not in command('list'):
   if proc.poll()is not None or time.monotonic()>deadline:raise RuntimeError('Probe login failed: '+name)
   time.sleep(.25)
  command('authme forcelogin '+name);command('gamemode survival '+name)
  command('clear '+name);command('effect clear '+name)
  command(f'item replace entity {name} hotbar.0 with minecraft:diamond_sword')
  for slot,item in [('head','helmet'),('chest','chestplate'),('legs','leggings'),('feet','boots')]:
   command(f'item replace entity {name} armor.{slot} with minecraft:diamond_{item}')
 results=[]
 for offset,title in [(180,'背身疾跑中回头击打，再恢复跑路朝向'),(-90,'侧向转身疾跑中回头击打，再恢复行进朝向')]:
  match=str(uuid.uuid4())
  for name in folders:
   order(name);command(f'effect give {name} minecraft:instant_health 1 10 true')
   command(f'effect give {name} minecraft:saturation 1 10 true')
  command('tp WaveDogSon 1122.5 221 960.5 -90 0');command('tp WDShieldTrial 1123.7 221 960.5 90 0')
  blue(title+'；这是普通协议测试员，尚不是模型学会。')
  time.sleep(2)
  order('WDShieldTrial',True,match,offset);order('WaveDogSon',True,match,offset)
  time.sleep(2.2)
  for name in folders:order(name)
  rows=[json.loads(s)for s in (folders['WaveDogSon']/'directional-input-frames.jsonl').read_text().splitlines()]
  rows=[r for r in rows if r['matchId']==match]
  feedback=[json.loads(s)for s in (folders['WDShieldTrial']/'public-feedback.jsonl').read_text().splitlines()]
  health=[r['health']for r in feedback if r.get('matchId')==match and 'health'in r]
  hits=[r for r in rows if r['actual']['attacked']]
  checks={'ordinaryClientDamage':bool(health)and min(health)<max(health),
    'actualAttackPacket':bool(hits),'headingRestored':all(abs(r['packets'][0]['data']['yaw']-r['packets'][-1]['data']['yaw'])<1e-6 for r in hits),
    'forwardSprintNoBackStrafe':all(r['actual']['controls']['forward']and r['actual']['controls']['sprint']
      and not any(r['actual']['controls'][k]for k in ['back','left','right'])for r in rows if r['elapsed']<28),
    'movedUnderNormalPhysics':bool(rows)and math.hypot(rows[-1]['position']['x']-rows[0]['position']['x'],rows[-1]['position']['z']-rows[0]['position']['z'])>1,
    'postHitSprintRearmed':any(any(p['name']=='entity_action'and p['data'].get('actionId')in[3,'start_sprinting']for p in r['packets'])
      for r in rows if any(r['tick']==h['tick']+1 for h in hits))}
  result={'matchId':match,'offset':offset,'checks':checks,'passed':all(checks.values()),
    'nativeHealthLoss':max(health)-min(health)if health else None,'frames':len(rows),'modelLearningClaimed':False}
  results.append(result);print(json.dumps(result),flush=True)
  blue(('通过：'if result['passed']else'未通过：')+title+'。实际伤害 '+str(result['nativeHealthLoss'])+'；模型是否学会需另测。')
 (dest/'receipt.json').write_text(json.dumps({'trials':results,'passed':all(r['passed']for r in results),
   'source':'ordinary-client-inputs-and-defender-health','mainServerRestarted':False,'modelLearningClaimed':False},indent=2))
 print(json.dumps({'resultDirectory':str(dest)}),flush=True)
finally:
 for name,folder in folders.items():
  if folder.exists():order(name)
 for proc in procs:
  if proc.poll()is None:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 for stream in streams:stream.close()
