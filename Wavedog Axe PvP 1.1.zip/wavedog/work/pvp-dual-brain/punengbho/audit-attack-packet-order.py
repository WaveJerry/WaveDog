"""Replay ordered client packets and bind them to native attack IDs/damage."""
from pathlib import Path
import argparse,json
ROOT=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser();p.add_argument('--brain',choices=['main','pure'],default='pure');p.add_argument('--out',type=Path,required=True)
p.add_argument('matches',nargs='+');a=p.parse_args()
runtime=ROOT/('work/wavedog-protocol/runtime'if a.brain=='main'else'work/wavedog-punengbho/runtime')
results=[]
for match in a.matches:
    frames=[json.loads(x)for x in (runtime/f'{match}-frames.jsonl').read_text().splitlines()]
    packets=[json.loads(x)for x in (runtime/f'{match}-packets.jsonl').read_text().splitlines()]
    attack_frames={f['tick']:f for f in frames if f.get('attackPacket')}
    events={e['attackId']:e for f in frames for e in f.get('nativeEvents',[])if e.get('attackId',-1)>=0 and e.get('type')=='damage'}
    sprint=None;motion=None;look=None;attacks=[]
    for index,row in enumerate(packets):
        name=row['name'];data=row['data']
        if name=='entity_action':
            if data.get('actionId')in[3,'start_sprinting']:sprint=True
            if data.get('actionId')in[4,'stop_sprinting']:sprint=False
        if name in['look','position_look']:look=data
        if name in['position','position_look']:
            previous=motion
            motion={**data,'tick':row['tick'],'descending':bool(previous and data['y']<previous['y']-1e-7),
                'ground':data.get('onGround',data.get('flags',{}).get('onGround'))}
        if name=='use_entity'and data.get('mouse')==1:
            f=attack_frames.get(row['tick'])
            e=events.get(f.get('attackId'))if f else None
            after=[x for x in packets[index+1:index+6]if x['tick']==row['tick']]
            attacks.append({'tick':row['tick'],'attackId':f.get('attackId')if f else None,
                'kind':f.get('command',{}).get('kind','neural')if f else None,
                'charge':f.get('attackCharge',f.get('self',{}).get('charge'))if f else None,
                'sprintOnWire':sprint,'lastMovement':motion,'lastLookBeforeAttack':look,
                'packetsAfterAttackSameTick':after,'nativeDamage':e.get('amount')if e else None,
                'nativeCritical':e.get('nativeCritical')if e else None,
                'sprintAtAttackMatchesEndOfCommand':sprint==f['executed']['sprint']if f and sprint is not None else None})
    results.append({'match':match,'brain':a.brain,'actualAttackPackets':len(attacks),
        'frameAttackPackets':len(attack_frames),'attacks':attacks})
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_text(json.dumps({'completeOrderedPacketReplay':True,'bouts':results},indent=2))
for r in results:print(json.dumps({'match':r['match'],'attacks':r['actualAttackPackets'],
    'nativeCrits':sum(bool(x['nativeCritical'])for x in r['attacks']),
    'sprintingDamageHits':sum(x['sprintOnWire']is True and x['nativeDamage']is not None for x in r['attacks']),
    'sprintChangedAfterAttack':sum(x['sprintAtAttackMatchesEndOfCommand']is False for x in r['attacks']),
    'postAttackSprintChangeAloneIsNotBugEvidence':True}))
