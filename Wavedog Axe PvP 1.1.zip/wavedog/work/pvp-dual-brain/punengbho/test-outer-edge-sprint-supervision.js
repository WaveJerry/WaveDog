import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS}from '../fresh-policy.js'
import {outerEdgeSprintTarget,outerEdgeSprintDecision}from './outer-edge-sprint-supervision.js'
import {combatFlowPurposeLoss}from './combat-flow-purpose-loss.js'
import {recordActionFlow,actionFlowChecks}from './action-flow-audit.js'
await tf.setBackend('cpu');await tf.ready()
const fixture=distance=>({tick:1,labels:{0:5,1:1,2:0,4:2,5:0,6:6},
 actions:[5,1,0,0,2,0,6,3,0],publicRequest:{
  self:{x:0,y:0,z:0,eyeY:1.62,ground:true,charge:1,held:7},
  seen:{visible:true,x:0,y:0,z:distance+.3,shield:false},
  publicActionContext:{sentPosition:{x:0,y:0,z:0}}}})
const near=fixture(2.999),target=outerEdgeSprintTarget(near)
assert(target?.withinLastCentimetre)
assert(outerEdgeSprintDecision(target,near.actions))
for(const [head,value]of [[0,2],[1,0],[2,1],[4,0],[5,1],[6,0]]){
 const bad=[...near.actions];bad[head]=value
 assert(!outerEdgeSprintDecision(target,bad),'incomplete edge/sprint/attack combination accepted')
}
assert.equal(outerEdgeSprintTarget(fixture(3.001)),null,'outside range cannot become a strike target')
assert.equal(outerEdgeSprintTarget(fixture(2.8)),null,'ordinary deeper contact is not extreme edge contact')
assert.equal(outerEdgeSprintTarget(fixture(2.98)),null,'2.95 to 2.99 is below the user-specified skill band')
assert.equal(outerEdgeSprintTarget({...near,labels:{...near.labels,4:0}}),null,'avoidance is not overwritten by forced attack')
const stale=fixture(2.999);stale.publicRequest.publicActionContext.sentPosition.z=-.1
assert.equal(outerEdgeSprintTarget(stale),null,'out-of-reach sent position cannot be ignored')
const noCharge=fixture(2.999);noCharge.publicRequest.self.charge=.9
assert.equal(outerEdgeSprintTarget(noCharge),null,'weak hit cannot be called reliable sprint knockback')
const shield=fixture(2.999);shield.publicRequest.seen.shield=true
assert.equal(outerEdgeSprintTarget(shield),null,'edge shield is not an instruction to force a break')
const heads=ACTION_WIDTHS.map(width=>tf.variable(tf.zeros([1,width])))
try{
 const {value,grads}=tf.variableGrads(()=>tf.tidy(()=>combatFlowPurposeLoss([{frame:near}],heads,1)),heads)
 assert(Number.isFinite(value.dataSync()[0]))
 for(const h of [0,1,2,4,5,6]){
  const g=grads[heads[h].name].arraySync()[0],want=target.heads[h]
  assert(g[want]<0,`edge joint action head ${h} does not learn`)
 }
 value.dispose();Object.values(grads).forEach(g=>g.dispose())
}finally{heads.forEach(h=>h.dispose())}
const stats={};recordActionFlow(stats,{},near,near.actions)
const bad=[...near.actions];bad[1]=0;recordActionFlow(stats,{},near,bad)
assert.deepEqual(stats.outerEdgeSprintStrike,{count:2,correct:1})
assert.deepEqual(stats.lastCentimetreSprintStrike,{count:2,correct:1})
const checks=actionFlowChecks({outerEdgeSprintStrike:{count:10,correct:4}},
 {outerEdgeSprintStrike:{count:10,correct:8}})
assert.equal(checks.outerEdgeSprintStrikeJointDecision,false,'8/10 is below the new joint-skill acceptance floor')
console.log('OUTER_EDGE_SPRINT_STRIKE_JOINT_GRADIENT_LEGALITY_AND_RELEASE_GATES_PASS')
