// Evaluate an existing stored rollout against a checkpoint; no optimizer steps.
import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'

const checkpoint = process.argv[2]
const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(process.argv[3])))
const loaded = loadDualCheckpoint(checkpoint)
loaded.adam.dispose()
const records = []
let state = null
const tensors = value => value ? [value.fast, value.slow, ...value.pending,
  ...value.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])].filter(Boolean) : []
try {
  for (const frame of rollout.episode) {
    const before = state
    const evaluated = tf.tidy(() => {
      const output = loaded.model.step(tf.tensor2d([frame.observation]), state)
      const biased = biasedActionLogits(output.logits, frame.observation, frame.context)
      const probabilities = maskActionLogits(biased, frame.legalMasks).map(head => [...tf.softmax(head).dataSync()])
      return { state: output.state, probabilities,
        weaponLogits: [...output.logits[5].dataSync()] }
    })
    state = evaluated.state
    const retained = new Set(tensors(state))
    for (const tensor of new Set(tensors(before))) if (!retained.has(tensor)) tensor.dispose()
    if (frame.executedHeads[5]) records.push({ tick: frame.decidedTick,
      charge: frame.observation[1], gapToReach: frame.observation[97],
      heldSlot: frame.observation[12], swordPressure: frame.context.swordComboPressure,
      selectedWeapon: frame.actions[5], swordProbability: evaluated.probabilities[5][1],
      weaponLogits: evaluated.weaponLogits })
  }
  const probabilities = records.map(row => row.swordProbability)
  const result = { at: new Date().toISOString(), checkpoint,
    rolloutSeq: rollout.rolloutSeq, fighter: rollout.fighter,
    frames: rollout.episode.length, executedWeaponFrames: records.length,
    sampledSwordFrames: records.filter(row => row.selectedWeapon === 1).length,
    swordProbabilityMin: Math.min(...probabilities), swordProbabilityMax: Math.max(...probabilities),
    swordProbabilityMean: probabilities.reduce((a, b) => a + b, 0) / probabilities.length,
    examples: records.filter(row => row.charge < .6 && row.gapToReach < -.3).slice(0, 6),
    weightsChanged: false }
  if (process.argv[4]) fs.writeFileSync(process.argv[4], JSON.stringify(result, null, 2))
  console.log(JSON.stringify(result))
} finally {
  for (const tensor of new Set(tensors(state))) tensor.dispose()
  loaded.model.dispose()
}
