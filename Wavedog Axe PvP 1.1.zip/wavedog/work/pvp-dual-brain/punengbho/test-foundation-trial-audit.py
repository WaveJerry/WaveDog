import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('audit-foundation-trial.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def frame(tick,held,critical=False):
    return {'tick':tick,'attackId':tick,'attackPacket':True,'attackHeld':held,'capturedAt':tick*50,
        'self':{'shieldAvailable':False,'shielding':False,'ground':not critical},'seen':{'visible':True,'shield':held==7},
        'owners':{'mainhand':'neural'},'executed':{'sprint':False,'sneak':False},'observation':{'reach':1.5},
        'nativeEvents':[{'serverTick':tick,'attackId':tick,'attacker':'Punengbho','victim':'WaveDogSon',
            'melee':True,'amount':2,'nativeCritical':critical}]}
s={'fighter':'Punengbho','matchId':'test','opponentMode':'shield','outcome':{},'opponentShieldDisableReceipts':[]}
frames=[frame(10,7),frame(24,0,True)]
assert not m.audit(s,frames)['passed'],'axe packets alone cannot prove a shield break'
s['opponentShieldDisableReceipts']=[{'matchId':'other','at':'1970-01-01T00:00:00.550Z','cooldownTicks':100}]
assert not m.audit(s,frames)['passed'],'other bouts cannot supply the cooldown'
s['opponentShieldDisableReceipts'][0]['matchId']='test'
assert m.audit(s,frames)['passed']
frames[-1]['nativeEvents'][0]['attacker']='WaveDogSon'
assert not m.audit(s,frames)['passed'],'opponent damage cannot be counted as sword continuation'
print('FOUNDATION_ACTUAL_SHIELD_BREAK_AND_MODEL_DAMAGE_ATTRIBUTION_PASS')

# Identical skill evidence must pass the ordinary stripped-kit contract and
# fail the carried-kit contract until equipment is actually present.
s['opponentMode']='critical';s['actualFirstFrameDistance']=1.5
frames=[frame(t,0,True)for t in [10,24,38]]
assert m.audit(s,frames)['passed']
assert not m.audit_carried_kit(s,frames)['passed']
for f in frames:
    f['self'].update(shieldAvailable=True,hasBow=True,hasCrossbow=True,arrows=5,held=0)
    f['actualPackets']=[]
assert m.audit_carried_kit(s,frames)['passed']
assert not m.audit(s,frames)['passed'],'the original no-shield contract must remain unchanged'
frames[0]['actualPackets']=['use_item']
assert not m.audit_carried_kit(s,frames)['passed'],'using equipment cannot count as unused-kit melee'
frames[0]['actualPackets']=[];frames[1]['self']['hasCrossbow']=False
assert not m.audit_carried_kit(s,frames)['passed'],'partial kits do not verify the requested regression scenario'
print('CARRIED_KIT_REQUIRES_REAL_EQUIPMENT_AND_UNCHANGED_MELEE_SKILL_FLOORS_PASS')
