import * as tf from '@tensorflow/tfjs'
// Counterbalance avoidance with demonstrated legal grounded attack windows.
// This is a training loss, not an online instruction to press forward/attack.
export function groundStrikePurposeLoss(rows,logits,weight){
 if(!(weight>0))return null
 const mask=rows.map(({frame:f})=>Number(Boolean(f.publicRequest?.self?.ground
   &&f.labels[4]===2&&f.labels[1]===1&&[1,5,6].includes(f.actions[0])&&!f.publicRequest?.seen?.shield)))
 const count=mask.reduce((a,b)=>a+b,0);if(!count)return null
 const p=logits.map(h=>tf.logSoftmax(h)),col=(h,a)=>p[h].slice([0,a],[rows.length,1]).reshape([rows.length])
 const move=tf.logSumExp(tf.gather(p[0],[1,5,6],1),1)
 const weapon=tf.sum(tf.mul(p[5],tf.oneHot(rows.map(r=>r.frame.labels[5]??0),p[5].shape[1])),1)
 const logSuccess=tf.add(tf.add(move,weapon),tf.add(col(4,2),col(1,1)))
 return tf.mul(weight,tf.div(tf.sum(tf.mul(tf.tensor1d(mask),tf.neg(logSuccess))),count))
}
