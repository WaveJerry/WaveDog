import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy}from '../fresh-policy.js'
import {SharedAdam,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
const dest=path.resolve('outputs/punengbho-rebuild-20261117'),live=path.resolve('work/wavedog-punengbho/model')
if(fs.existsSync(path.join(dest,'initial/checkpoint.json')))throw Error('Fresh seed already exists; do not rerandomize')
const prior=JSON.parse(fs.readFileSync(path.join(live,'checkpoint.json')))
const bytes=fs.readFileSync(path.join(live,prior.binary))
if(crypto.createHash('sha256').update(bytes).digest('hex')!==prior.sha256)throw Error('Live snapshot changed')
fs.mkdirSync(path.join(dest,'previous-live'),{recursive:true})
for(const name of ['checkpoint.json',prior.binary])fs.copyFileSync(path.join(live,name),path.join(dest,'previous-live',name))
await tf.setBackend('cpu');await tf.ready()
const config={fast:64,slow:256,heads:8,layers:4,ff:1024,interval:8,memory:32,
  publicHealthInputs:5,distributionVersion:2,pureAimVersion:2,
  combatObservationVersion:2,actionConditionedAttack:1,trainingStage:'behavior-cloning',
  generation:'punengbho-clean-20261117'}
const model=new DualPolicy(config,'learned'),adam=new SharedAdam(model.params,{learningRate:.00003})
const counters={source:'fresh-random-initialization',dualUpdates:0,dualEpisodes:0,lastRolloutSeq:0,
  rolloutFrames:0,trainedFrames:0,humanImitationUpdates:0,generation:config.generation}
const saved=saveDualCheckpoint(path.join(dest,'initial/checkpoint.json'),model,adam,counters)
const receipt={freshRandomInitialization:true,inheritedWeights:false,priorSha256:prior.sha256,
  priorPpoUpdatesPreservedInInactiveArchive:prior.counters.dualUpdates,parameters:model.parameterCount(),
  config,saved,installed:false,allTacticsMastered:false}
fs.writeFileSync(path.join(dest,'initial/receipt.json'),JSON.stringify(receipt,null,2))
adam.dispose();model.dispose();console.log(JSON.stringify(receipt))
