// Evaluate both sides of a conditional decision. An always-jump policy has
// perfect positive recall; preserving its near-zero positive NLL alone would
// forbid learning NOT to jump during grounded distance control.
const keys={attack:['4:0','4:2'],jump:['2:0','2:1'],weapon:['5:0','5:1'],
  move:['0:0','0:1','0:2','0:3','0:4','0:5','0:6','0:7','0:8'],sprint:['1:0','1:1']}
export function balancedNll(stats,names){
  const rows=names.map(k=>stats.labels[k]).filter(Boolean)
  return rows.length?rows.reduce((n,r)=>n+r.nll,0)/rows.length:0
}
export function skillScore(stats){
  return stats.meanNll+Object.values(keys).reduce((n,group)=>n+balancedNll(stats,group),0)
}
export function skillChecks(before,after){
  const checks={heldOutLossImproved:after.meanNll<before.meanNll}
  for(const[lesson,old]of Object.entries(before.byLesson)){
    const next=after.byLesson[lesson]
    checks['lessonPreserved:'+lesson]=next.meanNll<=old.meanNll*1.05
    for(const[group,names]of Object.entries(keys)){
      if(!names.some(k=>old.labels[k]))continue
      // A small absolute log-loss budget avoids treating 99.99% vs 99% as
      // catastrophic forgetting. Separate per-class recall checks remain.
      checks[lesson+':'+group+'BalancedNll']=balancedNll(next,names)<=balancedNll(old,names)*1.05+.05
      for(const name of names){
        const b=old.labels[name],a=next.labels[name]
        if(!b||b.count<2)continue
        // Preserve actual decisions, not an incumbent's overconfidence. New
        // weapon affordances must also reach usable held-out decision recall.
        const floor=group==='weapon'?.8:group==='jump'?.6:0
        const required=Math.max(floor,Math.min(.8,b.accuracy*.9))
        checks[lesson+':'+name+'Recall']=a.accuracy>=required
      }
    }
  }
  return checks
}
