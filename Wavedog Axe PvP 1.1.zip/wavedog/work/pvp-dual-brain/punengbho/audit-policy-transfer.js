// Read-only sequential evaluation of saved PPO observations. No game inputs,
// gradients, checkpoint publication or trainer messages are produced.
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'

const [destination, checkpoint, ...files] = process.argv.slice(2)
if (!destination || !checkpoint || !files.length)
  throw Error('Usage: audit-policy-transfer.js output.json checkpoint.json rollout.json.gz ...')
await tf.setBackend('cpu'); await tf.ready()
const loaded = loadDualCheckpoint(checkpoint)
loaded.adam.dispose()
const stateTensors = state => state ? [state.fast, state.slow, ...state.pending,
  ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])].filter(Boolean) : []
const dispose = (state, next = null) => {
  const retained = new Set(stateTensors(next))
  for (const t of new Set(stateTensors(state))) if (!retained.has(t)) t.dispose()
}
const report = { at: new Date().toISOString(), checkpoint: path.resolve(checkpoint),
  sha256: loaded.manifest.sha256, counters: loaded.counters,
  weightsChanged: false, gameCommandsSent: false,
  counterfactualWinRateMeasured: false, rollouts: [] }

function add (groups, name, result, frame) {
  const group = groups[name] ||= { frames: 0, swordProbability: 0,
    rawSwordProbability: 0, jumpProbability: 0, rawJumpProbability: 0,
    attackProbability: 0, rawAttackProbability: 0, forwardProbability: 0,
    sprintProbability: 0, meanGate: 0, sampledSword: 0, sampledJump: 0,
    sampledAttack: 0, swordArgmax: 0, jumpArgmax: 0, attackArgmax: 0 }
  group.frames++
  const p = result.probabilities, raw = result.raw
  group.swordProbability += p[5][1]; group.rawSwordProbability += raw[5][1]
  group.jumpProbability += p[2][1]; group.rawJumpProbability += raw[2][1]
  group.attackProbability += p[4][2]; group.rawAttackProbability += raw[4][2]
  group.forwardProbability += p[0][1] + p[0][5] + p[0][6]
  group.sprintProbability += p[1][1]
  group.meanGate += result.gate.reduce((a, b) => a + b, 0) / result.gate.length
  group.sampledSword += frame.actions[5] === 1 ? 1 : 0
  group.sampledJump += frame.actions[2] === 1 ? 1 : 0
  group.sampledAttack += frame.actions[4] === 2 ? 1 : 0
  group.swordArgmax += p[5][1] >= Math.max(...p[5]) ? 1 : 0
  group.jumpArgmax += p[2][1] >= p[2][0] ? 1 : 0
  group.attackArgmax += p[4][2] >= Math.max(...p[4]) ? 1 : 0
}

try {
  for (const file of files) {
    const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    let state = null
    const groups = {}
    try {
      for (const frame of rollout.episode) {
        const previous = state
        const result = tf.tidy(() => {
          const output = loaded.model.step(tf.tensor2d([frame.observation]), state)
          const biased = biasedActionLogits(output.logits, frame.observation,
            frame.context, frame.actions)
          return { state: output.state,
            raw: maskActionLogits(output.logits, frame.legalMasks)
              .map(head => [...tf.softmax(head).dataSync()]),
            probabilities: maskActionLogits(biased, frame.legalMasks)
              .map(head => [...tf.softmax(head).dataSync()]),
            gate: [...output.gate.dataSync()] }
        })
        state = result.state; dispose(previous, state)
        if (!frame.executedHeads[0]) continue
        add(groups, 'modelMovement', result, frame)
        if (frame.observation[2] > .5) add(groups, 'modelGrounded', result, frame)
        if (frame.observation[97] <= 0 && frame.observation[23] < .5) {
          add(groups, 'unshieldedOpponentInReach', result, frame)
          if (frame.observation[1] >= .85)
            add(groups, 'chargedUnshieldedOpponentInReach', result, frame)
        }
        if (frame.context?.swordDpsWindow) add(groups, 'swordDpsWindow', result, frame)
        if (frame.context?.jumpResetTrial) add(groups, 'jumpResetTrial', result, frame)
      }
    } finally { dispose(state) }
    for (const group of Object.values(groups))
      for (const key of Object.keys(group))
        if (key.endsWith('Probability') || key === 'meanGate') group[key] /= group.frames
    const item = { rolloutSeq: rollout.rolloutSeq, fighter: rollout.fighter,
      frames: rollout.episode.length, groups }
    report.rollouts.push(item)
    console.log(JSON.stringify({ evaluated: rollout.rolloutSeq,
      sha256: report.sha256, modelFrames: groups.modelMovement?.frames || 0 }))
  }
  fs.mkdirSync(path.dirname(path.resolve(destination)), { recursive: true })
  fs.writeFileSync(destination, JSON.stringify(report, null, 2))
  console.log(JSON.stringify({ saved: path.resolve(destination), sha256: report.sha256,
    weightsChanged: false, gameCommandsSent: false }))
} finally { loaded.model.dispose() }
