import assert from 'node:assert/strict'
import {balancedLessonWeights}from './foundation-supervision-weights.js'
const data={trajectories:[{split:'train',lesson:'a',frames:Array(20).fill({})},
  {split:'train',lesson:'b',frames:Array(5).fill({})},
  {split:'validation',lesson:'b',frames:Array(1000).fill({})}]}
const weights=balancedLessonWeights(data)
assert.equal(weights.a*20,weights.b*5)
assert.equal(weights.a*20+weights.b*5,25)
assert.deepEqual(weights,balancedLessonWeights({...data,trajectories:data.trajectories.slice(0,2)}))
console.log('LESSON_BALANCE_TRAIN_ONLY_EQUAL_MASS_PASS')
