import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
const [source,candidate,datasetFile,outFile]=process.argv.slice(2)
assert(source&&candidate&&datasetFile&&outFile&&!fs.existsSync(outFile))
await tf.setBackend('cpu');await tf.ready()
const a=loadDualCheckpoint(source),b=loadDualCheckpoint(candidate),data=JSON.parse(fs.readFileSync(datasetFile))
const stats={},originalParameters=a.model.params.length
const forwards=[0,1,-1,0,0,1,1,-1,-1],sides=[0,0,0,-1,1,-1,1,-1,1],turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
let checked=0,maxDelta=0,maxCachedDelta=0,maxPreservedSpatialDelta=0
const trainingReceipt=JSON.parse(fs.readFileSync(path.join(path.dirname(candidate),'receipt.json')))
const targetedHeads=trainingReceipt.trainedOutputHeads||b.model.spatialMovementHeads
const preservedSpatialHeads=(a.model.spatialMovementHeads||[]).filter(h=>!targetedHeads.includes(h))
const group=(name,who,good)=>{const r=stats[name]||={baseline:{count:0,correct:0},candidate:{count:0,correct:0}};r[who].count++;r[who].correct+=Number(good)}
try{
  for(let i=0;i<originalParameters;i++){
    const name=a.model.params[i].name
    if(!name.includes('.spatial-movement-')
        ||trainingReceipt.spatialTemporalOnly&&!name.includes('.spatial-movement-temporal-')
        ||trainingReceipt.temporalOutputOnly&&!targetedHeads.some(h=>name.includes(`.spatial-movement-temporal-out-${h}.`))
          &&!(trainingReceipt.trainTemporalRouteInput&&name.includes('.spatial-movement-temporal-route-in.')))
      assert.deepEqual(a.model.params[i].dataSync(),b.model.params[i].dataSync(),'Existing combat weights cannot change')
    if(trainingReceipt.coarseTemporalYaw&&name.includes('.spatial-movement-temporal-out-6.')){
      const old=a.model.params[i].dataSync(),next=b.model.params[i].dataSync()
      for(let j=0;j<old.length;j++)if(j%13!==0&&j%13!==12)assert.equal(next[j],old[j],'Fine aim corrections must remain unchanged')
    }
  }
  for(const trace of data.trajectories.filter(t=>t.split==='validation')){
    let sa=a.model.initialState(),sb=b.model.initialState()
    try{for(const f of trace.frames){
      const l=advance(a.model,sa,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);sa=l.state
      const r=advance(b.model,sb,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);sb=r.state
      for(const h of [2,3,4,5,7,8].filter(h=>!b.model.spatialMovementHeads.includes(h)))for(let j=0;j<l.logits[h].length;j++)maxDelta=Math.max(maxDelta,Math.abs(l.logits[h][j]-r.logits[h][j]))
      for(const h of preservedSpatialHeads)for(let j=0;j<l.logits[h].length;j++)
        maxPreservedSpatialDelta=Math.max(maxPreservedSpatialDelta,Math.abs(l.logits[h][j]-r.logits[h][j]))
      const residual=tf.tidy(()=>{const x=b.model.projectPolicyInputs(tf.tensor2d([f.observation]),f.publicHealthFeatures,f.publicThreatFeatures);return b.model.spatialMovementResidual(x,f.publicSpatialFeatures,f.publicThreatFeatures,r.state).map(h=>[...h.dataSync()])})
      const oldResidual=a.model.spatialMovementIn?tf.tidy(()=>{const x=a.model.projectPolicyInputs(tf.tensor2d([f.observation]),f.publicHealthFeatures,f.publicThreatFeatures);return a.model.spatialMovementResidual(x,f.publicSpatialFeatures,f.publicThreatFeatures,l.state).map(h=>[...h.dataSync()])}):null
      for(const[i,h]of b.model.spatialMovementHeads.entries())for(let j=0;j<l.logits[h].length;j++){
        if(f.legalMasks?.[h]?.[j]===false)continue
        const oldIndex=a.model.spatialMovementHeads?.indexOf(h)??-1
        maxCachedDelta=Math.max(maxCachedDelta,Math.abs(l.logits[h][j]-(oldIndex>=0?oldResidual[oldIndex][j]:0)+residual[i][j]-r.logits[h][j]))
      }
      const choices=[['baseline',captureAutonomousImitation(a.model,l,f).actions],['candidate',captureAutonomousImitation(b.model,r,f).actions]]
      const g=f.publicSpatialFeatures
      for(const[who,c]of choices){
        const angle=turns[c[6]]*Math.PI/180,radial=forwards[c[0]]*Math.cos(angle)-sides[c[0]]*Math.sin(angle),
          right=forwards[c[0]]*Math.sin(angle)+sides[c[0]]*Math.cos(angle),away=radial<-.25
        if(g[0]&&f.publicRequest?.self?.ground){
          // Stored channel 3 is protocol-right clearance; channel 4 is left.
          const blocked=radial<-.25&&g[1]*8<.9||radial>.25&&g[2]*8<.65
            ||right>.25&&g[3]*8<.65||right<-.25&&g[4]*8<.65
          group('groundPlannedObstacleAvoidance',who,!blocked)
        }
        if(g[0]&&g[1]*8<.9)group('blockedEscapeNotRetreating',who,!away)
        if(g[0]&&g[5]*8<=3.45&&!f.publicRequest?.seen?.shield)group('nearThreatFacing',who,Math.abs(c[6]-6)<=2)
        if(f.movementPurposeReason?.startsWith('purpose-'))group(f.movementPurposeReason,who,[0,1,6].every(h=>f.labels[h]===undefined||c[h]===f.labels[h]))
        if(f.movementPurposeReason?.startsWith('ground-control-'))group(f.movementPurposeReason,who,[0,1,2,6].every(h=>f.labels[h]===undefined||c[h]===f.labels[h]))
      }
      checked++
    }}finally{disposeState(sa);disposeState(sb)}
  }
  assert.equal(maxDelta,0,'Original raw combat logits changed')
  assert.equal(maxPreservedSpatialDelta,0,'Preserved spatial attack/sprint/view logits changed')
  assert(maxCachedDelta<1e-5,'Cached and deployed movement differ')
  const checks=Object.fromEntries(['blockedEscapeNotRetreating','nearThreatFacing','groundPlannedObstacleAvoidance']
    .map(k=>[k,stats[k]?.candidate.count>0&&stats[k].candidate.count===stats[k].baseline.count
      &&stats[k].candidate.correct>=stats[k].baseline.correct]))
  const result={checkedFrames:checked,originalCombatParametersUnchanged:true,untargetedRawLogitsUnchanged:true,
    preservationScope:'source-to-refinement-only; full-pipeline retention requires autonomous live-reference audit',
    causalThreatFeaturesUsed:b.model.config.publicThreatInputs===12,
    causalRecurrentFusionUsed:b.model.config.spatialTemporalFusionVersion===1,
    inheritedSpatialWeightsUnchanged:trainingReceipt.spatialTemporalOnly===true,
    fineAimWeightsUnchanged:trainingReceipt.coarseTemporalYaw===true,
    trainedHeads:b.model.spatialMovementHeads,maxCachedDelta,maxPreservedSpatialDelta,preservedSpatialHeads,stats,
    checks,passed:Object.values(checks).every(Boolean),
    datasetSha256:crypto.createHash('sha256').update(fs.readFileSync(datasetFile)).digest('hex'),
    candidateSha256:b.manifest.sha256,referenceSha256:a.manifest.sha256,liveImprovementVerified:false}
  fs.writeFileSync(outFile,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
}finally{a.adam.dispose();a.model.dispose();b.adam.dispose();b.model.dispose()}
