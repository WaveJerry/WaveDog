import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy}from '../fresh-policy.js'
import {SharedAdam,loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
const [source,datasetFile,dest]=process.argv.slice(2)
const temporal=process.argv.includes('--spatial-temporal')
const route=process.argv.includes('--spatial-temporal-route')
assert(source&&datasetFile&&dest&&!fs.existsSync(dest))
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source),parent=JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json')))
assert(route?loaded.model.spatialTemporalIn&&!loaded.model.spatialTemporalRouteIn:
  temporal?loaded.model.publicThreatProjection&&!loaded.model.spatialTemporalIn:!loaded.model.publicThreatProjection)
const model=new DualPolicy({...loaded.model.config,publicThreatInputs:12,...(temporal?{spatialTemporalFusionVersion:1}:{}),
  ...(route?{spatialTemporalRouteSplit:1}:{})},loaded.model.gateMode)
const adam=new SharedAdam(model.params,loaded.manifest.optimizer);adam.steps=loaded.adam.steps
const key=p=>p.name.split('.').slice(1).join('.')
const indexes=new Map(loaded.model.params.map((p,i)=>[key(p),i]))
let retained=0,checked=0,maxDelta=0
try{
  for(const[i,p]of model.params.entries()){
    const j=indexes.get(key(p));if(j===undefined)continue
    p.assign(loaded.model.params[j]);retained++
    for(const group of ['first','second']){adam[group][i].dispose();adam[group][i]=loaded.adam[group][j].clone()}
  }
  assert.equal(retained,loaded.model.params.length)
  if(route){model.spatialTemporalRouteIn.w.assign(model.spatialTemporalIn.w);model.spatialTemporalRouteIn.b.assign(model.spatialTemporalIn.b)}
  const data=JSON.parse(fs.readFileSync(datasetFile))
  for(const t of data.trajectories.filter(t=>t.split==='validation').slice(-4)){
    let a=loaded.model.initialState(),b=model.initialState()
    try{for(const f of t.frames.slice(0,48)){
      const x=advance(loaded.model,a,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);a=x.state
      const y=advance(model,b,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);b=y.state
      const left=captureAutonomousImitation(loaded.model,x,f),right=captureAutonomousImitation(model,y,f)
      assert.deepEqual(left.actions,right.actions)
      for(let h=0;h<left.logits.length;h++)for(let j=0;j<left.logits[h].length;j++)
        maxDelta=Math.max(maxDelta,Math.abs(left.logits[h][j]-right.logits[h][j]))
      checked++
    }}finally{disposeState(a);disposeState(b)}
  }
  assert.equal(maxDelta,0)
  fs.mkdirSync(dest,{recursive:true})
  const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,adam,loaded.counters)
  const reloaded=loadDualCheckpoint(saved.manifest)
  try{for(let i=0;i<model.params.length;i++)assert.deepEqual(model.params[i].dataSync(),reloaded.model.params[i].dataSync())}
  finally{reloaded.adam.dispose();reloaded.model.dispose()}
  const receipt={schema:route?'identical-temporal-route-extension-v1':temporal?'zero-spatial-temporal-extension-v1':'zero-public-threat-extension-v1',source:path.resolve(source),sourceSha256:loaded.manifest.sha256,
    referenceCheckpoint:parent.referenceCheckpoint,referenceSha256:parent.referenceSha256,dataset:path.resolve(datasetFile),
    functionPreserved:true,existingActiveWeightsPreserved:true,ppoOptimizerPreserved:true,retainedParameterTensors:retained,
    checkedFrames:checked,maxOutputDelta:maxDelta,imitationStepsSinceReference:parent.imitationStepsSinceReference||0,
    checkpointRoundTripVerified:true,trainedBackbonesInAncestor:parent.allBackbonesTrained===true||parent.trainedBackbonesInAncestor===true,
    noOnlineCombatRuleAdded:true,saved}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt))
}finally{adam.dispose();model.dispose();loaded.adam.dispose();loaded.model.dispose()}
