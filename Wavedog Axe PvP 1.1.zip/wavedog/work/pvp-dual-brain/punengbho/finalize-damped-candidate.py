"""Attach passed independent validation to a frozen, uniformly damped update."""
from pathlib import Path
import json,hashlib,sys
folder=Path(sys.argv[1]);p=folder/'receipt.json';r=json.loads(p.read_text(encoding='utf-8'))
assert r['schema']=='uniform-damped-joint-bc-v1' and r['allBackbonesTrained']
a=json.loads((folder/'autonomous-audit.json').read_text(encoding='utf-8'))
m=json.loads((folder/'checkpoint.json').read_text(encoding='utf-8'))
assert a['candidateSha256']==m['sha256'] and a['referenceSha256']==r['referenceSha256']
assert hashlib.sha256((folder/m['binary']).read_bytes()).hexdigest()==m['sha256']
assert hashlib.sha256(Path(a['dataset']).read_bytes()).hexdigest()==a['datasetSha256']
assert hashlib.sha256(Path(r['dataset']).read_bytes()).hexdigest()==r['datasetSha256']
assert a['causalThreatFeaturesUsed'] and a['usesPolicySelectedParents'] and a['passed']
assert all(a['checks'].values())
assert r['independentAuditPending']
(folder/'pre-audit-receipt.json').write_bytes(p.read_bytes())
r.update(offlineChecksPassed=True,independentAuditPending=False,checks=a['checks'],baseline=a['baseline'],
    evaluationDataset=a['dataset'],validationKind='autonomous-policy-parents',
    optimizationStepsHere=0)
r['best']['validation']=a['candidate']
p.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps({'validated':True,'sha256':m['sha256'],'optimizationStepsHere':0}))
