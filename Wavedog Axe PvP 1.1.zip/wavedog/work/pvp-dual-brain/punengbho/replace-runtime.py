"""Replace the stale copied learner with the validated common learning runtime.

Only learning infrastructure is shared; checkpoints and all-input action
decoding stay independent. No WaveDog mechanical controller is imported.
"""
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
COMMON=HERE.parent
assert (COMMON.parents[1]/'outputs/punengbho-integration-20261117/before/source').exists()
source=(COMMON/'fresh-actor.js').read_text(encoding='utf8')
source=re.sub(r"from '\./([^']+)'", r"from '../\1'", source)
source="import { legalMasks, decode } from './pure-actions.js'\n"+source
start=source.index("const project = ")
end=source.index("const server = ", start)
source=source[:start]+"const project = path.resolve(new URL('../../pvp-player-client', import.meta.url).pathname.replace(/^\\/(?=[A-Z]:)/, ''))\n"+source[end:]
start=source.index('const historyFolders = new Map([')
end=source.index('for (const [role, folder] of historyFolders)',start)
source=source[:start]+'const historyFolders = new Map() // This independent brain has no historical actors.\n'+source[end:]
start=source.index('function legalMasks (req) {')
end=source.index('function sample (probabilities)',start)
source=source[:start]+source[end:]
start=source.index('function decode (req, actions) {')
end=source.index('function observed (message)',start)
source=source[:start]+source[end:]
source=source.replace("index < 6 && !req.ignoredHeads.includes(index)","!req.ignoredHeads.includes(index)")
source=source.replace("import('./human-critical-exploiter.js')", "import('../human-critical-exploiter.js')")
(HERE/'fresh-actor.js').write_text(source,encoding='utf8')
for module in ['fresh-policy','fresh-optimizer-checkpoint']:
    (HERE/f'{module}.js').write_text(f"// One implementation; this branch keeps its own weights and optimizer.\nexport * from '../{module}.js'\n",encoding='utf8')
(HERE/'fresh-trainer-worker.js').write_text("// Full-bout PPO with policy-version and collapse checks; no mechanical actions.\nimport '../fresh-trainer-worker.js'\n",encoding='utf8')
service=(HERE/'dual-service.js').read_text(encoding='utf8')
service=service.replace("socket.setEncoding('utf8'); clients.add(socket)","socket.setNoDelay(true); socket.setEncoding('utf8'); clients.add(socket)")
(HERE/'dual-service.js').write_text(service,encoding='utf8')
print('Independent all-input runtime replaced; not yet reloaded')
