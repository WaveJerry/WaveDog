import assert from 'node:assert/strict'
import {directionalMovementSupervision as teach} from './directional-movement-supervision.js'
import {decode} from './pure-actions.js'
const labels={0:2,1:0,2:0,3:0,4:0,5:0,6:6,7:3,8:0},actions=Array(9).fill(0)
for(const[h,a]of Object.entries(labels))actions[h]=a
const advice={labels,actions,reason:'axe-spacing-recover-charge',ppoEligible:false}
const request={self:{x:0,y:0,z:0,eyeY:1.62,held:7,food:20,using:false,wireFalling:false},
 seen:{visible:true,x:0,y:0,z:-3},yaw:180,pitch:0}
const out=teach(advice,request),c=decode(request,out.actions,{pureAimVersion:2})
assert.equal(c.forward,1);assert(c.sprint);assert.equal(c.side,0)
assert(Math.abs(((c.yaw+540)%360)-180)<1e-9,'ordinary forward movement now faces away from opponent')
assert(!c.attack&&!c.flightLook,'teaching a travel direction cannot invent a strike')
assert.deepEqual(advice.labels,labels,'original expert object is preserved')
const strike={...advice,labels:{...labels,4:2},actions:actions.map((a,h)=>h===4?2:a)}
const hit=teach(strike,request)
assert.equal(hit.labels[8],1);assert.equal(hit.labels[5],labels[5])
assert(decode(request,hit.actions,{pureAimVersion:2}).flightLook)
assert.equal(teach(strike,{...request,self:{...request.self,wireFalling:true}}).labels[1],0,
 'actual critical attempt still releases sprint by model choice')
for(const r of [{...request,seen:{...request.seen,z:-1.8}},
 {...request,self:{...request.self,food:6}},{...request,self:{...request.self,using:true}},
 {...request,seen:{visible:false}}])assert.equal(teach(advice,r),advice)
assert.equal(out.ppoEligible,false)
const committed=teach({...advice,reason:'axe-spacing-committed-recovery'},
 {...request,seen:{...request.seen,z:-1.8}})
assert.equal(committed.labels[0],1);assert.equal(committed.labels[1],1);assert.equal(committed.labels[6],0,
 'a committed axe withdrawal turns and sprints even when the opponent is close')
const urgent=teach(advice,{...request,seen:{...request.seen,z:-2.4}})
assert.equal(urgent.labels[0],1);assert.equal(urgent.labels[1],1);assert.equal(urgent.labels[6],0,
 'a deliberate tactical retreat at 2.4 blocks must also turn and forward-sprint')
console.log('OFFLINE_DIRECTIONAL_MOVEMENT_AND_ATTACK_TURN_BACK_LABELS_PASS')
assert.equal(teach(advice,{...request,self:{...request.self,charge:.1}}),advice,
 'modern close threat observations retain facing; do not teach a blind turn')
const longRecovery=teach(advice,{...request,self:{...request.self,charge:.1},seen:{...request.seen,z:-4}})
assert.equal(longRecovery.labels[6],0,'a real recovery gap still permits forward-sprint withdrawal')
