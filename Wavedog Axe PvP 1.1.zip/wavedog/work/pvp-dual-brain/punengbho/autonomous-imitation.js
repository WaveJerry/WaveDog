import {captureDeployedImitation} from '../human-imitation.js'

// BC conditions the attack loss on expert parent actions. A frozen actor must
// instead condition on its OWN chosen weapon/sprint/jump. Report both; an
// excellent teacher-forced attack score cannot hide a wrong weapon choice.
const argmax = xs => xs.indexOf(Math.max(...xs))
export function captureAutonomousImitation(model, output, frame) {
  const teacherForced = captureDeployedImitation(model, output, frame)
  const actions = teacherForced.logits.map(argmax)
  const autonomous = captureDeployedImitation(model, output, {...frame, actions})
  actions[4] = argmax(autonomous.logits[4])
  return {...autonomous, actions, teacherForced}
}
