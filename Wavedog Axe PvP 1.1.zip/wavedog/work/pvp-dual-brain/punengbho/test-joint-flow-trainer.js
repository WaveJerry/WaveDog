// Synthetic, small-model CLI integration test. Never installs a candidate.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {spawnSync}from 'node:child_process'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
import {SharedAdam,saveDualCheckpoint,loadDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
const dest=path.resolve(process.argv[2]||'')
assert(process.argv[2]&&!fs.existsSync(dest),'A new synthetic-test output directory is required')
fs.mkdirSync(dest,{recursive:true})
await tf.setBackend('cpu');await tf.ready()
const source=path.join(dest,'source/checkpoint.json'),dataset=path.join(dest,'dataset.json'),
 trained=path.join(dest,'trained'),model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:2,
 distributionVersion:2,actionConditionedAttack:1,actionContextHeads:[2,5,4,0,1,6,7,8],
 spatialMovementVersion:1,spatialMovementHeads:[0,1,6,5,4,2],spatialControlSplitHeads:[0,2,5],
 publicThreatInputs:12,spatialTemporalFusionVersion:1,spatialTemporalRouteSplit:1}),adam=new SharedAdam(model.params)
fs.mkdirSync(path.dirname(source))
let saved
try{saved=saveDualCheckpoint(source,model,adam,{syntheticTestFixture:true})}finally{adam.dispose();model.dispose()}
fs.writeFileSync(path.join(path.dirname(source),'receipt.json'),JSON.stringify({
 schema:'synthetic-test-fixture-only',referenceCheckpoint:source,referenceSha256:saved.sha256,
 functionPreserved:true,imitationStepsSinceReference:0,notPublishable:true}))
const trace=(split)=>{
 const frames=Array.from({length:18},(_,tick)=>{
  const labels={0:1,1:0,2:1,3:0,4:2,5:1,6:6,7:3,8:0},actions=Array(9).fill(0)
  for(const[h,a]of Object.entries(labels))actions[h]=a
  return {tick,observation:Array.from({length:OBS_SIZE},(_,i)=>i===1?.95:(i%7)/20),actions,labels,
   publicSpatialFeatures:[1,1,1,1,1,.2,0,.2],publicThreatFeatures:Array(12).fill(0),
   publicRequest:{self:{held:0,x:0,y:0,z:0,ground:true,charge:.95,attackAgeTicks:12},
    seen:{visible:true,x:0,y:0,z:1.8,shield:false}},
   labelEvidence:['exact-recorded-client-controls-and-packets'],ppoEligible:false,
   expertReason:'close-sword-early-useful-damage'}
 })
 return {source:'synthetic-'+split,sourceKind:'exact-script-demonstration',
  sourceSha256:crypto.createHash('sha256').update(JSON.stringify(frames)).digest('hex'),
  matchId:'synthetic-'+split,split,lesson:'synthetic-sword-flow',frames}
}
fs.writeFileSync(dataset,JSON.stringify({schema:'public-human-imitation-v1',ppoEligible:false,
 syntheticTestFixture:true,trajectories:[trace('train'),trace('validation')]}))
const args=['work/pvp-dual-brain/punengbho/train-current-state-heads.js','--source',source,
 '--reference-checkpoint',source,'--dataset',dataset,'--dest',trained,'--epochs','2',
 '--learning-rate','.0001','--joint-context-spatial','--autonomous-wait-weight','.4',
 '--autonomous-attack-weight','1','--movement-purpose-loss','.5','--response-purpose-loss','.5',
 '--ground-strike-purpose-loss','.25','--combat-flow-purpose-loss','1','--source-retention-kl','.1',
 '--response-window-audit','--action-flow-audit']
const child=spawnSync(process.execPath,args,{encoding:'utf8',maxBuffer:4*1024*1024})
fs.writeFileSync(path.join(dest,'trainer.log'),child.stdout||'')
fs.writeFileSync(path.join(dest,'stderr.log'),child.stderr||'')
assert.equal(child.status,0,'Trainer CLI failed: '+child.stderr)
const receipt=JSON.parse(fs.readFileSync(path.join(trained,'receipt.json')))
assert(receipt.jointContextSpatial&&receipt.learnedPublicGeometryAndThreatInputs)
assert(receipt.auditActionFlow&&receipt.combatFlowWeight===1&&receipt.purposeLossWeight===.5)
assert(receipt.best.steps>0&&receipt.frozenBackbonesUnchanged&&!receipt.allBackbonesTrainedInThisStage)
assert(!receipt.validationUsedForGradients&&!receipt.ppoEligible&&receipt.ppoOptimizerSteps===0)
assert(receipt.sourceHashesCapturedBeforeTraining&&receipt.trainingSourceSha256['combat-flow-purpose-loss.js'])
assert('actionFlow:swordUsefulHitBeforeTakeoffJointDecision' in receipt.checks)
const original=loadDualCheckpoint(source),candidate=loadDualCheckpoint(path.join(trained,'checkpoint.json'))
try{
 let changed=0
 for(let i=0;i<original.model.params.length;i++){
  const name=original.model.params[i].name.replace(/^dual\d+\./,''),
   a=original.model.params[i].dataSync(),b=candidate.model.params[i].dataSync()
  if(/^(fast\.|slow-|gate-)/.test(name))assert.deepEqual(a,b,'Frozen backbone changed: '+name)
  else if(a.some((v,j)=>v!==b[j]))changed++
 }
 assert(changed>0,'No neural parameters were updated')
 const report={passed:true,syntheticTestFixture:true,notPublishable:true,neuralParameterTensorsChanged:changed,
  trainableParameters:receipt.trainableResidualParameters,frozenBackbonesUnchanged:true,
  jointActionFlowChecksPresent:true,ppoUpdates:0,serverTouched:false}
 fs.writeFileSync(path.join(dest,'test-receipt.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report))
}finally{original.adam.dispose();original.model.dispose();candidate.adam.dispose();candidate.model.dispose()}
