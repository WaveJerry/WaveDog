"""Require independent behavior AND frozen-weight/cache audits before staging."""
from pathlib import Path
import json,hashlib,sys
folder=Path(sys.argv[1]);p=folder/'receipt.json';r=json.loads(p.read_text(encoding='utf-8'))
assert r['schema']=='uniform-calibrated-temporal-bc-v1' and r['allBackbonesTrained'] and r['independentAuditPending']
m=json.loads((folder/'checkpoint.json').read_text(encoding='utf-8'))
assert hashlib.sha256((folder/m['binary']).read_bytes()).hexdigest()==m['sha256']
assert hashlib.sha256(Path(r['dataset']).read_bytes()).hexdigest()==r['datasetSha256']
a=json.loads((folder/'autonomous-audit.json').read_text(encoding='utf-8'))
s=json.loads((folder/'spatial-audit.json').read_text(encoding='utf-8'))
for report,reference in [(a,r['referenceSha256']),(s,r['sourceSha256'])]:
    assert report['candidateSha256']==m['sha256'] and report['referenceSha256']==reference
    assert report['datasetSha256']==r['datasetSha256'] and report['passed'] and all(report['checks'].values())
assert a['causalThreatFeaturesUsed'] and a['usesPolicySelectedParents']
assert s['causalRecurrentFusionUsed'] and s['inheritedSpatialWeightsUnchanged']
(folder/'pre-audit-receipt.json').write_bytes(p.read_bytes())
r.update(offlineChecksPassed=True,independentAuditPending=False,checks=a['checks'],baseline=a['baseline'],
    validationKind='independent-autonomous-and-spatial-audits',optimizationStepsHere=0)
r['best']['validation']=a['candidate']
p.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps({'validated':True,'sha256':m['sha256'],'optimizationStepsHere':0}))
