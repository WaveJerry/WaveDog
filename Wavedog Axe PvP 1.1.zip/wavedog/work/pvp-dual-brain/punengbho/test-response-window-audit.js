import assert from 'node:assert/strict'
import {recordResponseWindows} from './response-window-audit.js'
const frame={publicRequest:{self:{held:7,ground:true,attackAgeTicks:1},seen:{visible:true,shield:false},
 publicActionContext:{targetCriticalThreat:true,targetAirborne:true}},
 labels:{0:2,1:0,2:0,4:0,5:0,6:6},actions:[2,0,0,0,0,0,6,3,0]}
let stats={}
recordResponseWindows(stats,frame,[0,0,0,0,2,0,6,3,0])
assert.equal(stats.forecastThreatClearance.correct,0);assert.equal(stats.recentAttackNoSpam.correct,0)
recordResponseWindows(stats,frame,frame.actions)
assert.equal(stats.forecastThreatClearance.correct,1);assert.equal(stats.recentAttackNoSpam.correct,1)
const strike={...frame,labels:{0:5,1:1,2:0,4:2,5:0,6:6},actions:[5,1,0,0,2,0,6,3,0]}
stats={};recordResponseWindows(stats,strike,[3,1,0,0,2,0,6,3,0])
assert.equal(stats.jointGroundSprintStrike.correct,0,'side-only sprint intent cannot satisfy an actual sprint strike')
recordResponseWindows(stats,strike,strike.actions);assert.equal(stats.jointGroundSprintStrike.correct,1)
const finish={...frame,publicRequest:{...frame.publicRequest,self:{held:0,ground:false,wireFalling:true,attackAgeTicks:8}},
 expertReason:'sword-last-legal-contact-before-separation',labels:{0:1,1:0,4:2,5:1},actions:[1,0,0,0,2,1,6,3,0]}
stats={};recordResponseWindows(stats,finish,[1,1,0,0,2,1,6,3,0])
assert.equal(stats.lastLegalSwordContact.correct,0,'falling sword attack must release sprint')
recordResponseWindows(stats,finish,finish.actions);assert.equal(stats.lastLegalSwordContact.correct,1)
const recovery={...frame,expertReason:'axe-spacing-committed-recovery',
 publicSpatialFeatures:[1,1,1,1,1,.4,0,0],labels:{0:1,1:1,2:0,4:0,5:0,6:0},actions:[1,1,0,0,0,0,0,3,0],
 publicRequest:{...frame.publicRequest,self:{held:7,ground:true,charge:.3,attackAgeTicks:7},publicActionContext:{}}}
stats={};recordResponseWindows(stats,recovery,recovery.actions)
assert.equal(stats.nearThreatFacing,undefined,'correct committed recovery is not scored as a facing failure')
assert.equal(stats.visibleWallRoute.correct,1)
const intercept={...recovery,expertReason:'urgent-legal-interrupt-before-full-charge',labels:{...recovery.labels,4:2}}
stats={};recordResponseWindows(stats,intercept,recovery.actions)
assert.equal(stats.nearThreatFacing.correct,0,'interception still requires facing')
console.log('RESPONSE_WINDOW_JOINT_ACTION_AUDIT_PASS')
