import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS}from '../fresh-policy.js'
import {groundStrikePurposeLoss}from './ground-strike-purpose-loss.js'
await tf.setBackend('cpu');await tf.ready()
const heads=ACTION_WIDTHS.map(w=>tf.tidy(()=>tf.variable(tf.zeros([2,w]))))
tf.tidy(()=>heads[4].assign(tf.tensor2d([[40,0,0,0,0],[0,0,0,0,0]])))
const frame={publicRequest:{self:{ground:true},seen:{shield:false}},labels:{4:2,1:1,5:0},actions:[1,1,0,0,2,0,6,3,0]}
const rows=[{frame},{frame:{...frame,labels:{...frame.labels,4:0}}}]
const {value,grads}=tf.variableGrads(()=>tf.tidy(()=>groundStrikePurposeLoss(rows,heads,.5)),heads)
assert(Number.isFinite(value.dataSync()[0]))
for(const [h,a]of [[4,2],[1,1],[5,0]])assert(grads[heads[h].name].arraySync()[0][a]<-.01)
assert(grads[heads[4].name].arraySync()[1].every(v=>v===0),'avoidance labels never become attack targets')
value.dispose();Object.values(grads).forEach(t=>t.dispose());heads.forEach(t=>t.dispose())
console.log('GROUND_STRIKE_PURPOSE_PASS: useful legal attack has joint gradients; avoidance stays separate')
