// Training-only balancing. A one-tick weapon transition or ground jump must
// not disappear under hundreds of identical hold/wait frames. All recurrent
// frames remain ordered; no online control rule or validation count is used.
export const lessonOf = trace => trace.lesson ||
  (trace.sourceKind === 'dagger-expert-relabel' ? 'close-critical' : 'unclassified')
export function balancedLessonWeights(dataset) {
  const counts={}
  for(const trace of dataset.trajectories.filter(t=>t.split==='train'))
    counts[lessonOf(trace)]=(counts[lessonOf(trace)]||0)+trace.frames.length
  const total=Object.values(counts).reduce((a,b)=>a+b,0),n=Object.keys(counts).length
  return Object.fromEntries(Object.entries(counts).map(([lesson,count])=>[lesson,total/(n*count)]))
}
export function foundationSupervisionWeights(dataset, heads = new Set([2, 4, 5]), balancedHeads = new Set()) {
  const counts = {}, weights = {}
  for (const trace of dataset.trajectories.filter(t=>t.split==='train')) {
    const lesson=lessonOf(trace), group=counts[lesson]||={}
    for (const frame of trace.frames) for (const [h,a] of Object.entries(frame.labels)) {
      if (!heads.has(Number(h))) continue
      const row=group[h]||={};row[a]=(row[a]||0)+1
    }
  }
  for (const [lesson,group] of Object.entries(counts)) {
    weights[lesson]={}
    for (const [h,classes] of Object.entries(group)) {
      const total=Object.values(classes).reduce((a,b)=>a+b,0), n=Object.keys(classes).length
      const raw=Object.fromEntries(Object.entries(classes).map(([a,count])=>[a,Math.min(12,
        balancedHeads.has(Number(h))?total/(n*count):Math.sqrt(total/(n*count)))]))
      const mean=Object.entries(classes).reduce((sum,[a,count])=>sum+count*raw[a],0)/total
      weights[lesson][h]=Object.fromEntries(Object.entries(raw).map(([a,w])=>[a,w/mean]))
    }
  }
  return {counts,weights,method:balancedHeads.size?'train-only-selected-head-inverse-frequency-v1':
    'train-only-per-lesson-per-head-square-root-frequency-v1',balancedHeads:[...balancedHeads]}
}
