"""Four focused trials, only after fresh user approval; no retries."""
from pathlib import Path
import argparse, hashlib, json, runpy, subprocess

ROOT=Path(__file__).resolve().parents[3]
LIVE=ROOT/'work/wavedog-punengbho/runtime'
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--sha',required=True)
a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
cases=[('sync-check',8,[]),('bow',8,['--bow-cancel-every','3']),
       ('shield',1.5,['--shield-interrupt']),('critical-switch',1.5,[])]
report={'authorizedAttempts':4,'attempted':0,'completed':0,'trials':[],
        'fullTacticalMastery':False,'realSynchronizationVerified':False}
for index,(mode,distance,extra) in enumerate(cases):
    client=json.loads((LIVE/'client-ready.json').read_text(encoding='utf-8'))
    if client.get('controlRegime')!='pilot-mechanical-shield-neural-melee':raise RuntimeError('Expected hybrid pilot')
    for name,sha in client['sourceSha256'].items():
        if hashlib.sha256((ROOT/'work/pvp-player-client'/name).read_bytes()).hexdigest()!=sha:
            raise RuntimeError('Client sources changed during test')
    report['attempted']+=1
    (a.out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    command('tellraw WaveJerry '+json.dumps({'text':f'[综合版补验 {index+1}/4] {mode}：冻结模型，只验证实际操作和原生回执。','color':'aqua'},ensure_ascii=True))
    log=a.out/f'{index+1}-{mode}.log'
    with log.open('w',encoding='utf-8')as f:
        result=subprocess.run(['python',str(Path(__file__).with_name('run-main-trial.py')),
            '--mode',mode,'--start-distance',str(distance),'--seconds','25','--retain-learner-kit',*extra],
            cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode:
        report['failureLog']=str(log);(a.out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        raise RuntimeError('Trial failed; preserve evidence, no automatic retry')
    rows=[json.loads(line)for line in log.read_text(encoding='utf-8').splitlines()if line.startswith('{')]
    summary=next(row for row in rows if 'frameFile'in row)
    frames=[json.loads(line)for line in Path(summary['frameFile']).read_text(encoding='utf-8').splitlines()]
    if not frames or any(f.get('policySha')!=a.sha or f.get('controlRegime')!='pilot-mechanical-shield-neural-melee' for f in frames):
        raise RuntimeError('Empty or mixed policy/control regime')
    report['completed']+=1;report['trials'].append(summary)
    (a.out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'completed':report['completed'],'matchId':summary['matchId'],'mode':mode}),flush=True)
