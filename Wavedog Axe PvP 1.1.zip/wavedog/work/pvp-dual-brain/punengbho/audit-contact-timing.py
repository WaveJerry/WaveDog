"""Report actual low-charge axe contacts and sword exit hits, without claiming interruption."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--suite',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
if a.out.exists():raise RuntimeError('Preserve prior evidence')
suite=json.loads(a.suite.read_text());trials=[]
for t in suite['trials']:
    frames=[json.loads(s)for s in Path(t['summary']['frameFile']).read_text().splitlines()]
    events={}
    for f in frames:
        for e in f.get('nativeEvents',[]):
            if e.get('attacker')=='Punengbho' and not e.get('cancelled') and e.get('amount',0)>0:
                events[(e.get('serverTick'),e.get('attackId'),e.get('amount'))]=e
    packets=[f for f in frames if f.get('attackPacket')]
    low=[];exit_hits=[]
    for f in packets:
        damage=[e for e in events.values()if e.get('attackId')==f.get('attackId')]
        linked=sum(e['amount']for e in damage)
        if f.get('attackHeld')==7 and f.get('attackCharge',1)<.9 and not f['seen'].get('shield'):
            low.append({'tick':f['tick'],'charge':f.get('attackCharge'),'reach':f['observation']['reach'],'nativeDamage':linked})
        if f.get('attackHeld')==0:
            out=next((r for r in frames if 0<r['tick']-f['tick']<=4 and r['observation'].get('mutualOutOfReach')),None)
            if out:exit_hits.append({'tick':f['tick'],'outOfReachTick':out['tick'],'nativeDamage':linked,'nativeCritical':any(e.get('nativeCritical')for e in damage)})
    r={'matchId':t['matchId'],'mode':t['mode'],'lowChargeAxePackets':low,'swordPacketsBeforeSeparation':exit_hits,
        'lowChargeAxePositiveDamageCount':sum(x['nativeDamage']>0 for x in low),'positiveDamageDoesNotProveComboInterrupted':True}
    trials.append(r)
a.out.write_text(json.dumps({'checkpointSha256':suite['checkpointSha256'],'trials':trials},indent=2))
print(json.dumps({'bouts':len(trials),'lowChargeAxePackets':sum(len(t['lowChargeAxePackets'])for t in trials),
    'lowChargeAxeDamageContacts':sum(t['lowChargeAxePositiveDamageCount']for t in trials),
    'swordPacketsBeforeSeparation':sum(len(t['swordPacketsBeforeSeparation'])for t in trials)}))
