from copy import deepcopy
from execution_geometry import attack_reach

g={'eye':{'x':0,'y':1.62,'z':0},'hit':{'x':0,'y':1.62,'z':-2.9},
   'wireEye':{'x':0,'y':1.62,'z':0},'wireHit':{'x':0,'y':1.62,'z':-2.9},
   'target':{'x':0,'y':0,'z':-3.2,'width':.6,'height':1.8},
   'rayDistance':2.9,'wireRayDistance':2.9,'source':'execution-public-box-and-sent-position-v1'}
p={'attackGeometry':g,'observation':{'reach':3.16}}
assert attack_reach(p)==2.9
assert p['observation']['reach']==3.16
bad=deepcopy(p);bad['attackGeometry']['wireEye']['z']=1
assert attack_reach(bad)==float('inf'), 'wire geometry outside reach cannot pass'
bad=deepcopy(p);bad['attackGeometry']['target']['z']=-6
assert attack_reach(bad)==float('inf'), 'point must intersect the recorded target box'
bad=deepcopy(p);bad['attackGeometry']['rayDistance']=float('nan')
assert attack_reach(bad)==float('inf'), 'nonfinite reported distance cannot pass'
assert attack_reach({'observation':{'reach':3.16}})==3.16, 'legacy evidence is never retrospectively repaired'
print('EXECUTION_GEOMETRY_LOCAL_WIRE_AND_LEGACY_EVIDENCE_PASS')
