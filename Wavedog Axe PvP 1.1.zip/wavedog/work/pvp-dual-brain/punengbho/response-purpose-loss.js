import * as tf from '@tensorflow/tfjs'
// Offline differentiable joint-action supervision. No runtime control rule.
const forward=[0,1,-1,0,0,1,1,-1,-1],side=[0,0,0,-1,1,-1,1,-1,1]
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
const radial=(move,turn)=>forward[move]*Math.cos(turn*Math.PI/180)-side[move]*Math.sin(turn*Math.PI/180)
export function responsePurposeLoss(rows,logits,weight){
 if(!(weight>0))return null
 const escape=rows.map(({frame:f})=>{const o=f.publicRequest?.publicActionContext
   return Number(Boolean(o?.targetCriticalThreat&&o?.targetAirborne&&f.labels[4]===0
     &&radial(f.actions[0],turns[f.actions[6]])<-.25))})
 const finish=rows.map(({frame:f})=>Number(f.expertReason==='sword-last-legal-contact-before-separation'&&f.labels[4]===2))
 const terms=[]
 const mean=(values,mask)=>tf.div(tf.sum(tf.mul(values,tf.tensor1d(mask))),mask.reduce((a,b)=>a+b,0))
 const logp=logits.map(h=>tf.logSoftmax(h)),column=(h,a)=>logp[h].slice([0,a],[rows.length,1]).reshape([rows.length])
 if(escape.some(Boolean)){
   // Log space retains gradients even when an old residual overwhelms the
   // intended action by 20+ logits. Probability flooring would silence it.
   const allowed=tf.tensor2d(forward.map((_,m)=>turns.map(t=>radial(m,t)<-.25?0:-1e9)))
   const space=tf.logSumExp(tf.add(tf.add(tf.expandDims(logp[0],2),tf.expandDims(logp[6],1)),tf.expandDims(allowed,0)),[1,2])
   terms.push(mean(tf.neg(tf.add(space,tf.add(column(4,0),column(2,0)))),escape))
 }
 if(finish.some(Boolean)){
   const falling=tf.tensor1d(rows.map(r=>Number(r.frame.publicRequest?.self?.wireFalling===true)))
   const legalSprint=tf.mul(falling,column(1,0))
   terms.push(mean(tf.neg(tf.add(tf.add(column(4,2),column(5,1)),legalSprint)),finish))
 }
 return terms.length?tf.mul(weight,tf.addN(terms)):null
}
