"""Check conditional parents against immutable ordinary-player packet records."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('dataset',type=Path);p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
if a.out.exists():raise RuntimeError('Preserve prior action audit')
root=Path(__file__).resolve().parents[3]/'outputs/punengbho-rebuild-20261117/demonstrations'
dataset=json.loads(a.dataset.read_text());checked=0
for trace in dataset['trajectories']:
    if trace['sourceKind']!='exact-script-demonstration':continue
    raw=[json.loads(line)for line in (root/trace['source']).read_text().splitlines()]
    by_tick={row['tick']:row for row in raw if row['type']=='frame'}
    for frame in trace['frames']:
        row=by_tick[frame['tick']];control=row['executed']
        expected={1:int(control['sprint']),2:int(control['jump']),3:int(control['sneak']),
                  4:2 if row['attackPacket'] else 0,5:1 if row['held']==0 else 0}
        for head,action in expected.items():
            assert frame['recordedActions'][head]==action,(trace['source'],frame['tick'],head,action)
            legal_action=0 if head==2 and not frame['publicRequest']['self']['ground']else action
            assert frame['actions'][head]==legal_action
            assert frame['legalMasks'][head][legal_action]is not False
        checked+=1
report={'passed':True,'framesChecked':checked,'recordedControlsPreserved':True,
        'conditionalParentsUseLegalEquivalent':True,'omittedSupervisionDoesNotChangeFactualActions':True}
a.out.write_text(json.dumps(report,indent=2));print(json.dumps(report))
