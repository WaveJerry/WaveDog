'use strict'
// Offline teaching only. Never imported by the actor or packet executor.
const calibration=require('./contact-persistence-calibration.json')
const {eyeReach}=require('../../pvp-player-client/probe-edge-controller')
const {navigationClearance}=require('../navigation-clearance.cjs')
function contactGeometry(request){
 const s=request.self,t=request.seen,dx=t.x-s.x,dz=t.z-s.z,d=Math.hypot(dx,dz),
  ux=d>.001?dx/d:0,uz=d>.001?dz/d:1,v=request.publicActionContext?.targetVelocity||{},
  closing=((s.vx||0)-(v.x||0))*ux+((s.vz||0)-(v.z||0))*uz,
  w=request.publicTerrain?.walls||[8,8,8,8]
 const ray=(x,z)=>Math.max(0,Math.min(8,Math.abs(x)>.001?w[x<0?0:1]/Math.abs(x):8,
  Math.abs(z)>.001?w[z<0?2:3]/Math.abs(z):8)-.3)
 // Protocol left while facing +Z is +X. Preserve the stored feature-channel
 // convention elsewhere; use actual key/world geometry for these labels.
 const navigation=navigationClearance(request)
 return {distance:d,closing,toward:navigation?.toward??ray(ux,uz),away:navigation?.away??ray(-ux,-uz),left:navigation?.left??ray(uz,-ux),right:navigation?.right??ray(-uz,ux),
  lateral:(v.x||0)*uz-(v.z||0)*ux,selfLateral:(s.vx||0)*uz-(s.vz||0)*ux}
}
function sustainableCloseContact(request,reach,wireReach){
 if(reach===undefined||wireReach===undefined){
  const s=request.self,t=request.seen,p=request.publicActionContext?.sentPosition
  if(!s||!t?.visible||!p)return false
  const target={position:t,width:.6,height:1.8},eyeHeight=s.eyeY-s.y
  reach=eyeReach(s,eyeHeight,target);wireReach=eyeReach(p,eyeHeight,target)
 }
 const g=contactGeometry(request),reserve=Math.max(calibration.separationReserve,
  Math.max(0,-g.closing)*calibration.horizonTicks)
 return g.distance<2.05&&Math.max(reach,wireReach)+reserve<3
}
function groundControlMovement(request,plan,history,attack,charge){
 const g=contactGeometry(request),reach=Math.max(plan.reach,plan.wireReach)
 // Select an open lateral route from visible geometry/motion; never use
 // spawn coordinates or random per-frame flips as a preferred direction.
 let side=g.left>g.right+.2?-1:g.right>g.left+.2?1:
  Math.abs(g.lateral)>.04?(g.lateral>0?-1:1):
  Math.abs(g.selfLateral)>.04?(g.selfLateral>0?-1:1):(history.groundControlSide||-1)
 if((side<0?g.left:g.right)<.65)side=(side<0?g.right:g.left)>=.65?-side:0
 if(side)history.groundControlSide=side
 let forward=0
 if(attack)forward=1
 else if(reach>3.05&&charge>=.9)forward=1
 else if(!attack&&reach<2.7&&g.closing>.06&&charge<.9&&g.away>=.9)forward=-1
 // Retreat is a short response to an approaching threat, not the default
 // while recovering. Side movement/holding retains the spacing initiative.
 const action=forward>0?(side<0?5:side>0?6:1):forward<0?(side<0?7:side>0?8:2):side<0?3:side>0?4:0
 return {action,sprint:forward>0,forward,side}
}
module.exports={contactGeometry,sustainableCloseContact,groundControlMovement,calibration}
