"""Reconcile durable status with actual live sources, receipts and PPO progress."""
from pathlib import Path
from datetime import datetime,timezone
from importlib.machinery import SourceFileLoader
import argparse,hashlib,json
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
LIVE=ROOT/'work/wavedog-punengbho'
parser=argparse.ArgumentParser()
parser.add_argument('--training-dir',type=Path)
parser.add_argument('--training-running',action='store_true')
args=parser.parse_args()
candidate_receipt=args.training_dir/'receipt.json' if args.training_dir else None
if args.training_running and (not args.training_dir or not (args.training_dir/'events.jsonl').exists() or candidate_receipt.exists()):
    raise RuntimeError('Active training directory with unfinished events required')
training_running=args.training_running
audit=SourceFileLoader('pure_status',str(Path(__file__).with_name('integration-status.py'))).load_module()
actual=audit.status(18776)
ready=json.loads((LIVE/'runtime/client-ready.json').read_text())
process=json.loads((LIVE/'runtime/client-process.json').read_text())
verified=ready['pid']==process['pid'] and all(hashlib.sha256((ROOT/'work/pvp-player-client'/name).read_bytes()).hexdigest()==digest
    for name,digest in ready['sourceSha256'].items())
verified &= all(hashlib.sha256((ROOT/'work/pvp-dual-brain/punengbho'/name).read_bytes()).hexdigest()==digest
    for name,digest in actual['runtimeSourceSha256'].items())
s=json.loads((BASE/'state.json').read_text())
s.update(updatedAt=datetime.now(timezone.utc).isoformat(),installed=True,
    runtimeAndSourceHashesVerified=verified,mainMinecraftRestarted=False,allTacticsMastered=False,
    trainingRunning=training_running,currentCheckpointSha256=actual['checkpointSha256'],
    currentCounters=actual['counters'],controlRegime=actual['controlRegime'],
    qwenReferenceReview='timed-out-not-completed',fixedCombatRoute=False)
latest=sorted(BASE.glob('install-trained*-receipt.json'),key=lambda f:f.stat().st_mtime)
if latest:
    r=json.loads(latest[-1].read_text())
    s.update(lastInstallSha256=r['checkpointSha256'],installReceipt=str(latest[-1]))
s['liveTrials']=[json.loads(f.read_text())for f in sorted(BASE.glob('live-*/summary.json'))]
s['rejectedCandidates']=[]
receipts=list(BASE.glob('*/trained/receipt.json'))+list((ROOT/'outputs/punengbho-rebuild-20261117').glob('*/receipt.json'))
for file in receipts:
    if file.parent.name.startswith('main-'):continue
    r=json.loads(file.read_text())
    if 'offlineChecksPassed' in r and not r['offlineChecksPassed']:
        saved=r.get('saved',r.get('best',{}).get('saved',{}))
        s['rejectedCandidates'].append({'receipt':str(file),'sha256':saved.get('sha256'),'checks':r.get('checks',{})})
s['promotionAuthorized']=False
s['deploymentTarget']='WaveDog_Punengbho'
s['refinement']={'running':training_running,'offlineOnly':True,'notProofOfTacticMastery':True}
if args.training_dir:
    receipt=json.loads(candidate_receipt.read_text()) if candidate_receipt.exists() else None
    candidate_sha=(receipt.get('best',{}).get('saved',{}).get('sha256')or receipt.get('saved',{}).get('sha256'))if receipt else None
    s['latestCandidate']={'directory':str(args.training_dir.resolve()),'trainingComplete':receipt is not None,
        'offlineChecksPassed':receipt.get('offlineChecksPassed') if receipt else None,
        'sha256':candidate_sha,
        'installed':candidate_sha is not None and candidate_sha==actual['checkpointSha256']}
    s['candidateSha256']=candidate_sha
    s['trainingStatus']=args.training_dir.name+('-running'if training_running else '-complete'if receipt else '-preparing')
s['nextRepair']='Validate native grounded edge hits and continuous sword criticals; preserve purposeful weapon transitions'
(BASE/'state.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'installed':True,'runtimeVerified':verified,'currentSha256':actual['checkpointSha256'],
    'liveTrials':len(s['liveTrials']),'allTacticsMastered':False}))
