// Full-bout PPO with policy-version and collapse checks; no mechanical actions.
import '../fresh-trainer-worker.js'
