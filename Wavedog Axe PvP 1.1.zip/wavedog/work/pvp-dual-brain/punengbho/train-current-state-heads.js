// Supervised correction of a small zero-initialized current-state residual.
// Frozen recurrent features are computed from COMPLETE ordered bouts once.
// No actor/executor rule is added, and inherited GRU/GTrXL parameters survive.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {OBS_SIZE} from '../fresh-policy.js'
import {loadDualCheckpoint,SharedAdam,saveDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation,validateDataset,accumulate,finishStats} from '../human-imitation.js'
import {foundationSupervisionWeights,lessonOf,balancedLessonWeights} from './foundation-supervision-weights.js'
import {exchangeAttackWeights,attackSituation} from '../exchange-imitation-weights.js'
import {skillChecks,skillScore} from './imitation-skill-checks.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
import {conditionalAttackOffsets,autonomousCachedLogits} from './current-state-conditioning.js'
import {autonomousAttackTargets,autonomousAttackLoss} from './autonomous-attack-supervision.js'
import {movementPurposeLoss} from './movement-purpose-loss.js'
import {responsePurposeLoss} from './response-purpose-loss.js'
import {responseSupervisionWeight}from './response-supervision-weight.js'
import {recordResponseWindows,responseWindowChecks}from './response-window-audit.js'
import {groundStrikePurposeLoss}from './ground-strike-purpose-loss.js'
import {sourceRetentionLoss}from './source-retention-loss.js'
import {policyFrame,comparisonFrame,airborneJumpFrame}from './policy-frame-masks.js'
import {jointPolicyResiduals,jointResidualParameters}from './joint-policy-residuals.js'
import {combatFlowPurposeLoss}from './combat-flow-purpose-loss.js'
import {recordActionFlow,actionFlowChecks}from './action-flow-audit.js'
const trainingSources=Object.fromEntries(['train-current-state-heads.js','joint-policy-residuals.js',
  'current-state-conditioning.js','autonomous-attack-supervision.js','foundation-supervision-weights.js',
  'policy-frame-masks.js','movement-purpose-loss.js','movement-supervision-purpose.js','combat-flow-purpose-loss.js','action-flow-audit.js','outer-edge-sprint-supervision.js',
  'response-purpose-loss.js','response-supervision-weight.js','response-window-audit.js','ground-strike-purpose-loss.js',
  'source-retention-loss.js','imitation-skill-checks.js','autonomous-imitation.js',
  '../fresh-policy.js','../fresh-optimizer-checkpoint.js','../human-imitation.js','../exchange-imitation-weights.js','../public-threat-features.js']
  .map(n=>[n,fs.readFileSync(new URL(n,import.meta.url))]))
const trainingSourceSha256=Object.fromEntries(Object.entries(trainingSources)
  .map(([n,bytes])=>[n,crypto.createHash('sha256').update(bytes).digest('hex')]))
const opt=(k,f)=>{const i=process.argv.indexOf(k);return i<0?f:process.argv[i+1]}
const source=path.resolve(opt('--source','')),datasetFile=path.resolve(opt('--dataset','')),dest=path.resolve(opt('--dest',''))
const epochs=Number(opt('--epochs',80)),rate=Number(opt('--learning-rate',.002))
const jumpPositiveWeight=Number(opt('--jump-positive-weight',1))
const attackPositiveWeight=Number(opt('--attack-positive-weight',1))
const movementHoldWeight=Number(opt('--movement-hold-weight',1))
const autonomousWaitWeight=Number(opt('--autonomous-wait-weight',0))
const autonomousAttackWeight=Number(opt('--autonomous-attack-weight',0))
const autonomousSupervision=autonomousWaitWeight>0||autonomousAttackWeight>0
const auditResponseWindows=process.argv.includes('--response-window-audit')
const auditActionFlow=process.argv.includes('--action-flow-audit')
if(auditActionFlow&&!autonomousSupervision)throw Error('Action-flow checks require autonomous parent actions')
if(auditResponseWindows&&!autonomousSupervision)throw Error('Response-window checks require autonomous parent actions')
const balanceLessons=process.argv.includes('--balance-lessons')
const balanceSprintClasses=process.argv.includes('--balance-sprint-classes')
const balanceMovementClasses=process.argv.includes('--balance-movement-classes')
const attackOutputOnly=process.argv.includes('--attack-output-only')
const spatialOnly=process.argv.includes('--spatial-only')
const spatialOutputsOption=opt('--spatial-output-heads',null)
const spatialOutputHeads=spatialOutputsOption===null?null:spatialOutputsOption.split(',').map(Number)
const trainSelectedSpatialInput=process.argv.includes('--train-selected-spatial-input')
const trainAllSpatialInputs=process.argv.includes('--train-all-spatial-inputs')
const spatialTemporalOnly=process.argv.includes('--spatial-temporal-only')
const temporalOutputOnly=process.argv.includes('--temporal-output-only')
const coarseTemporalYaw=process.argv.includes('--coarse-temporal-yaw')
const trainTemporalRouteInput=process.argv.includes('--train-temporal-route-input')
if(trainAllSpatialInputs&&(!spatialOnly||spatialOutputHeads||trainSelectedSpatialInput))throw Error('Full spatial input learning requires all spatial heads')
const responseWeight=Number(opt('--response-window-weight',1)),responseLossWeight=Number(opt('--response-purpose-loss',0))
const groundStrikeWeight=Number(opt('--ground-strike-purpose-loss',0))
const combatFlowWeight=Number(opt('--combat-flow-purpose-loss',0))
const retentionWeight=Number(opt('--source-retention-kl',0))
assert(Number.isFinite(retentionWeight)&&retentionWeight>=0&&retentionWeight<=20)
assert(Number.isFinite(groundStrikeWeight)&&groundStrikeWeight>=0&&groundStrikeWeight<=10)
assert(Number.isFinite(combatFlowWeight)&&combatFlowWeight>=0&&combatFlowWeight<=10)
assert(Number.isFinite(responseWeight)&&responseWeight>=1&&responseWeight<=10)
assert(Number.isFinite(responseLossWeight)&&responseLossWeight>=0&&responseLossWeight<=10)
if(spatialOutputHeads&&(!spatialOnly||!spatialOutputHeads.length||new Set(spatialOutputHeads).size!==spatialOutputHeads.length))
  throw Error('Spatial output selection requires distinct selected heads and spatial-only mode')
const purposeLossWeight=Number(opt('--movement-purpose-loss',0))
assert(Number.isFinite(purposeLossWeight)&&purposeLossWeight>=0&&purposeLossWeight<=10)
const outputHeadsOption=opt('--output-heads',null)
const outputHeads=outputHeadsOption===null?null:outputHeadsOption.split(',').map(Number)
const jointContextSpatial=process.argv.includes('--joint-context-spatial')
const stopOnQualified=process.argv.includes('--stop-on-qualified')
if(jointContextSpatial&&(spatialOnly||outputHeads||attackOutputOnly))throw Error('Joint neural residual fitting requires all context and spatial inputs/outputs')
if(outputHeads&&(attackOutputOnly||!outputHeads.length||new Set(outputHeads).size!==outputHeads.length
    ||outputHeads.some(h=>![0,1,2,5,4,6,7,8].includes(h))))throw Error('Invalid or conflicting output head selection')
if(!Number.isSafeInteger(epochs)||epochs<1||epochs>200||!Number.isFinite(rate)||rate<=0||rate>.01)throw Error('Invalid correction settings')
if(!Number.isFinite(jumpPositiveWeight)||jumpPositiveWeight<1||jumpPositiveWeight>4)throw Error('Invalid jump supervision weighting')
if(!Number.isFinite(attackPositiveWeight)||attackPositiveWeight<1||attackPositiveWeight>4)throw Error('Invalid attack supervision weighting')
if(!Number.isFinite(movementHoldWeight)||movementHoldWeight<1||movementHoldWeight>4)throw Error('Invalid movement hold weighting')
if(!Number.isFinite(autonomousWaitWeight)||autonomousWaitWeight<0||autonomousWaitWeight>2)throw Error('Invalid autonomous wait weighting')
if(!Number.isFinite(autonomousAttackWeight)||autonomousAttackWeight<0||autonomousAttackWeight>2)throw Error('Invalid autonomous attack weighting')
if(fs.existsSync(dest))throw Error('Preserve prior result')
const parent=JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json')))
assert(parent.referenceCheckpoint&&(parent.functionPreserved||parent.allBackbonesTrained),
  'Requires verified extension or tracked jointly-trained checkpoint')
const datasetBytes=fs.readFileSync(datasetFile),datasetSha256=crypto.createHash('sha256').update(datasetBytes).digest('hex')
const data=JSON.parse(datasetBytes);validateDataset(data)
const lessonWeights=balanceLessons?balancedLessonWeights(data):{}
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source),model=loaded.model
if(data.jumpInputVersion===2)model.config.jumpInputVersion=2
const referenceOverride=opt('--reference-checkpoint',null)
const referenceCheckpoint=referenceOverride?path.resolve(referenceOverride):parent.referenceCheckpoint
const referenceConfig=JSON.parse(fs.readFileSync(referenceCheckpoint)).config
const comparable=frame=>comparisonFrame(frame,referenceConfig,model.config)
const referenceSha256=referenceOverride?JSON.parse(fs.readFileSync(referenceCheckpoint)).sha256:parent.referenceSha256
assert(referenceSha256===parent.referenceSha256||referenceSha256===loaded.manifest.sha256,
  'Rebase reference must be the exact source or its verified ancestor')
const inheritedSteps=referenceSha256===loaded.manifest.sha256?0:parent.imitationStepsSinceReference
assert(['[2,5,4]','[2,5,4,0,1]','[2,5,4,0,1,6,7,8]'].includes(JSON.stringify(model.config.actionContextHeads)))
const selectedOutputs=attackOutputOnly?[4]:outputHeads
assert(!selectedOutputs||selectedOutputs.every(h=>model.config.actionContextHeads.includes(h)),'Selected output is absent')
if(spatialOnly)assert(model.config.spatialMovementVersion===1&&!selectedOutputs,'Spatial extension is required')
if(spatialOutputHeads)assert(spatialOutputHeads.every(h=>model.spatialMovementHeads.includes(h)),'Selected spatial head is absent')
if(trainSelectedSpatialInput)assert(spatialOnly&&model.spatialControlIn
  &&JSON.stringify(spatialOutputHeads)===JSON.stringify(model.spatialControlSplitHeads),
  'Separate input training requires exactly its selected output heads')
if(temporalOutputOnly||coarseTemporalYaw)assert(spatialTemporalOnly&&temporalOutputOnly,'Partial temporal updates require output-only mode')
if(trainTemporalRouteInput)assert(temporalOutputOnly&&model.spatialTemporalRouteIn
  &&JSON.stringify(spatialOutputHeads)==='[0,6]','Route projection update requires isolated move/view heads')
if(spatialTemporalOnly)assert(spatialOnly&&model.spatialTemporalIn&&!trainSelectedSpatialInput&&!trainAllSpatialInputs
  &&spatialOutputHeads?.every(h=>model.spatialTemporalHeads.includes(h)),'Temporal-only selection must match its heads')
const trainable=jointContextSpatial?jointResidualParameters(model):spatialTemporalOnly?[...(temporalOutputOnly?[]:model.spatialTemporalIn.params),
  ...(trainTemporalRouteInput?model.spatialTemporalRouteIn.params:[]),
  ...model.spatialTemporalOut.filter((p,i)=>spatialOutputHeads.includes(model.spatialTemporalHeads[i])).flatMap(p=>p.params)]:spatialOnly?[...(spatialOutputHeads?[]:model.spatialMovementIn.params),
  ...(trainSelectedSpatialInput||trainAllSpatialInputs?model.spatialControlIn.params:[]),
  ...model.spatialMovementOut.filter((p,i)=>!spatialOutputHeads||spatialOutputHeads.includes(model.spatialMovementHeads[i])).flatMap(p=>p.params)]:selectedOutputs?selectedOutputs.flatMap(h=>model.actionContextOut[model.config.actionContextHeads.indexOf(h)].params):
  [...model.actionContextIn.params,...model.actionContextOut.flatMap(layer=>layer.params),
    ...(model.contextBaseCalibration?[model.contextBaseCalibration]:[])]
const trainedNames=new Set(trainable.map(p=>p.name)),before=model.params.map(p=>new Float32Array(p.dataSync()))
const optimizer=new SharedAdam(trainable,{learningRate:rate}),heads=spatialOnly?model.spatialMovementHeads:model.config.actionContextHeads
const weights=foundationSupervisionWeights(data,new Set(heads),new Set([
  ...(balanceSprintClasses?[1]:[]),...(balanceMovementClasses?[0]:[])])).weights,
  situations=exchangeAttackWeights(data).weights
fs.mkdirSync(dest,{recursive:true})
for(const[name,bytes]of Object.entries(trainingSources)){
  const snapshot=path.join(dest,'training-source',name.startsWith('../')?name.slice(3):path.join('punengbho',name))
  fs.mkdirSync(path.dirname(snapshot),{recursive:true});fs.writeFileSync(snapshot,bytes)
}
const log=row=>{fs.appendFileSync(path.join(dest,'events.jsonl'),JSON.stringify(row)+'\n');
  console.log(JSON.stringify({stage:row.stage,epoch:row.epoch,steps:row.steps,selectionScore:row.selectionScore,
    passed:row.passed,failed:row.checks?Object.keys(row.checks).filter(k=>!row.checks[k]):undefined}))}
const traces=[]
let steps=0,best=null,bestScore=Infinity,stoppedOnQualified=false
try{
  for(const trace of data.trajectories){
    let state=model.initialState();const frames=[]
    try{for(const f of trace.frames){
      const out=advance(model,state,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);state=out.state
      const captured=captureDeployedImitation(model,out,f)
      const projected=tf.tidy(()=>[...model.projectPolicyInputs(tf.tensor2d([f.observation],[1,OBS_SIZE]),f.publicHealthFeatures,f.publicThreatFeatures).dataSync()])
      const recurrent=model.spatialTemporalIn?{fast:[...out.state.fast.dataSync()],slow:[...out.state.slow.dataSync()]}:null
      // Continuing a trained residual must replace its old contribution,
      // never add the whole residual a second time on top of itself.
      const initialResidual=tf.tidy(()=>residuals([{projected,recurrent,frame:f}]).map(t=>[...t.dataSync()]))
      const initialScales=tf.tidy(()=>heads.map(h=>baseScale(h).dataSync()[0]))
      const baseLogits=captured.logits.map(a=>[...a])
      for(const[j,h]of heads.entries())baseLogits[h]=baseLogits[h].map((v,k)=>
        (v-initialResidual[j][k])/initialScales[j])
      const row={frame:f,projected,recurrent,baseLogits,sourceLogits:retentionWeight>0?captured.logits:null}
      if(autonomousSupervision)row.teacherAttackOffset=tf.tidy(()=>
        [...conditionalAttackOffsets(model,[row],[f.actions]).dataSync()])
      frames.push(row)
    }}finally{disposeState(state)}
    traces.push({...trace,frames})
    console.log(JSON.stringify({stage:'ordered-features',source:trace.source,split:trace.split,frames:frames.length}))
  }
  function residuals(rows){
    if(jointContextSpatial)return jointPolicyResiduals(model,rows)
    const input=tf.tensor2d(rows.map(r=>r.projected),[rows.length,OBS_SIZE])
    if(spatialOnly){
      const spatial=tf.tensor2d(rows.map(r=>r.frame.publicSpatialFeatures),[rows.length,8])
      const threat=model.spatialTemporalIn?tf.tensor2d(rows.map(r=>r.frame.publicThreatFeatures),[rows.length,12]):null
      const recurrent=model.spatialTemporalIn?{fast:tf.tensor2d(rows.map(r=>r.recurrent.fast)),slow:tf.tensor2d(rows.map(r=>r.recurrent.slow))}:null
      return model.spatialMovementResidualBatch(input,spatial,threat,recurrent)
    }
    const context=tf.tanh(model.actionContextIn.apply(model.projectActionContext(input)))
    return model.actionContextOut.map(layer=>layer.apply(context))
  }
  function baseScale(h){
    const i=[2,5].indexOf(h)
    return model.contextBaseCalibration&&i>=0
      ?tf.mul(2,tf.sigmoid(model.contextBaseCalibration.slice([i],[1]))):tf.scalar(1)
  }
  function evaluate(){
    const stats={labels:{},drift:{}},byLesson={},ownStats={labels:{},drift:{}},ownLessons={},responseWindows={},actionFlow={}
    const airborneJump={labels:{},drift:{}}
    for(const trace of traces.filter(t=>t.split==='validation')){
      const flowHistory={}
      for(let start=0;start<trace.frames.length;start+=128){
        const rows=trace.frames.slice(start,start+128)
        const [corrections,scales]=tf.tidy(()=>[residuals(rows).map(t=>t.arraySync()),heads.map(h=>baseScale(h).dataSync()[0])])
        const batch=rows.map((r,i)=>r.baseLogits.map((a,h)=>{
          const j=heads.indexOf(h)
          return a.map((v,k)=>j<0?v:v*scales[j]+corrections[j][i][k])
        }))
        const autonomous=autonomousSupervision?tf.tidy(()=>autonomousCachedLogits(model,rows,
          batch[0].map((_,h)=>tf.tensor2d(batch.map(row=>row[h])))).map(t=>t.arraySync())):null
        for(const[i,r]of rows.entries()){
          const logits=r.baseLogits.map(a=>[...a])
          for(const[j,h]of heads.entries())logits[h]=logits[h].map((v,k)=>v*scales[j]+corrections[j][i][k])
          const common=comparable(r.frame)
          accumulate(stats,common,{logits});accumulate(byLesson[lessonOf(trace)]||={labels:{},drift:{}},common,{logits})
          accumulate(airborneJump,airborneJumpFrame(r.frame),{logits})
          if(autonomous){
            const own={logits:autonomous.map(h=>h[i])}
            accumulate(ownStats,common,own)
            accumulate(ownLessons[lessonOf(trace)]||={labels:{},drift:{}},common,own)
            recordResponseWindows(responseWindows,r.frame,own.logits.map(h=>h.indexOf(Math.max(...h))))
            if(auditActionFlow)recordActionFlow(actionFlow,flowHistory,r.frame,own.logits.map(h=>h.indexOf(Math.max(...h))))
          }
        }
      }
    }
    return {...finishStats(stats),airborneJump:finishStats(airborneJump),responseWindows,actionFlow,byLesson:Object.fromEntries(Object.entries(byLesson).map(([k,v])=>[k,finishStats(v)])),
      ...(autonomousSupervision?{autonomous:{...finishStats(ownStats),
        byLesson:Object.fromEntries(Object.entries(ownLessons).map(([k,v])=>[k,finishStats(v)]))}}:{})}
  }
  // A curriculum extension changes the validation population. Never reuse
  // the migration receipt's scores from another dataset as this baseline.
  const reference=loadDualCheckpoint(referenceCheckpoint)
  let baseline
  try{
    assert.equal(reference.manifest.sha256,referenceSha256,'Reference weights changed')
    const stats={labels:{},drift:{}},byLesson={},ownStats={labels:{},drift:{}},ownLessons={},responseWindows={},actionFlow={}
    const airborneJump={labels:{},drift:{}}
    for(const trace of data.trajectories.filter(t=>t.split==='validation')){
      const flowHistory={}
      let state=reference.model.initialState()
      try{for(const originalFrame of trace.frames){
        const frame=policyFrame(originalFrame,reference.model.config)
        const out=advance(reference.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures);state=out.state
        const captured=captureDeployedImitation(reference.model,out,frame)
        const common=comparable(frame)
        accumulate(stats,common,captured)
        accumulate(byLesson[lessonOf(trace)]||={labels:{},drift:{}},common,captured)
        accumulate(airborneJump,airborneJumpFrame(frame),captured)
        if(autonomousSupervision){
          const own=captureAutonomousImitation(reference.model,out,frame)
          if(auditResponseWindows)recordResponseWindows(responseWindows,frame,own.actions)
          if(auditActionFlow)recordActionFlow(actionFlow,flowHistory,frame,own.actions)
          accumulate(ownStats,common,own)
          accumulate(ownLessons[lessonOf(trace)]||={labels:{},drift:{}},common,own)
        }
      }}finally{disposeState(state)}
    }
    baseline={...finishStats(stats),airborneJump:finishStats(airborneJump),responseWindows,actionFlow,byLesson:Object.fromEntries(Object.entries(byLesson).map(([k,v])=>[k,finishStats(v)])),
      ...(autonomousSupervision?{autonomous:{...finishStats(ownStats),
        byLesson:Object.fromEntries(Object.entries(ownLessons).map(([k,v])=>[k,finishStats(v)]))}}:{})}
  }finally{reference.adam.dispose();reference.model.dispose()}
  log({stage:'baseline',validation:evaluate(),referenceBaseline:baseline,sourceSha256:loaded.manifest.sha256,
    datasetSha256,baselineDatasetSha256:datasetSha256,baselineReferenceSha256:referenceSha256,
    comparisonSemantics:'shared airborne combat labels; airborne jump key labels reported separately across input versions',
    note:'GRU/GTrXL and gate frozen in this correction stage; trained in preceding joint BC stages'})
  for(let epoch=0;epoch<epochs;epoch++){
    // The recurrent features above were computed in complete bout order.
    // This stage trains ONLY a memoryless residual on those frozen features:
    // mix its minibatches across bouts/skills to avoid long blocks of axe-only
    // or wait-only supervision overwriting the immediately preceding skill.
    const ordered=traces.filter(t=>t.split==='train').flatMap(trace=>trace.frames.map((r,i)=>({
      ...r,lesson:lessonOf(trace),key:crypto.createHash('sha256').update(epoch+':'+trace.source+':'+i).digest('hex')})))
      .sort((a,b)=>a.key.localeCompare(b.key))
    for(let start=0;start<ordered.length;start+=128){
      const rows=ordered.slice(start,start+128)
      tf.tidy(()=>{
        const {value,grads}=tf.variableGrads(()=>{
          const corrections=residuals(rows),terms=[]
          const teacherLogits=rows[0].baseLogits.map((_,h)=>{
            const base=tf.tensor2d(rows.map(r=>r.baseLogits[h]))
            const j=heads.indexOf(h)
            return j<0?base:tf.add(tf.mul(base,baseScale(h)),corrections[j])
          })
          const own=autonomousSupervision?autonomousCachedLogits(model,rows,teacherLogits):teacherLogits
          for(const[j,h]of heads.entries()){
            if(spatialOutputHeads&&!spatialOutputHeads.includes(h))continue
            const width=rows[0].baseLogits[h].length
            const logits=tf.add(tf.mul(tf.tensor2d(rows.map(r=>r.baseLogits[h]),[rows.length,width]),baseScale(h)),corrections[j])
            const labels=rows.map(r=>r.frame.labels[h]??0)
            const w=rows.map(r=>{
              const a=r.frame.labels[h];if(a===undefined)return 0
              let n=weights[r.lesson]?.[h]?.[a]??1
              if(spatialOnly&&r.frame.movementPurposeReason?.startsWith('purpose-'))n*=2
              if(h===2&&a===1)n*=jumpPositiveWeight
              if(h===4&&a===2)n*=attackPositiveWeight
              if(h===0&&a===0)n*=movementHoldWeight
              n*=responseSupervisionWeight(r.frame,h,responseWeight)
              if(h===4)n*=Math.max(.25,Math.min(10,situations[attackSituation(r.frame)]?.[a]??1))
              return n*(lessonWeights[r.lesson]??1)
            })
            const maskCount=rows.filter(r=>r.frame.labels[h]!==undefined).length
            if(maskCount)terms.push(tf.div(tf.sum(tf.mul(tf.tensor1d(w),tf.neg(tf.sum(
              tf.mul(tf.oneHot(labels,width),tf.logSoftmax(logits)),1)))),maskCount))
          }
          if(autonomousSupervision){
            // Both wait and compatible positive attacks use policy parents.
            // Do not teach a fictitious attack under a different weapon or
            // critical setup. These counterfactual labels are never PPO.
            const targets=autonomousAttackTargets(rows,teacherLogits,lessonWeights)
            for(const[target,weight]of [[0,autonomousWaitWeight],[2,autonomousAttackWeight]]){
              const loss=autonomousAttackLoss(own[4],targets,target,weight)
              if(loss)terms.push(loss)
            }
          }
          const purpose=spatialOnly||jointContextSpatial?movementPurposeLoss(rows,teacherLogits,purposeLossWeight):null
          if(purpose)terms.push(purpose)
          const response=responsePurposeLoss(rows,own,responseLossWeight)
          if(response)terms.push(response)
          const ground=groundStrikePurposeLoss(rows,own,groundStrikeWeight)
          if(ground)terms.push(ground)
          const combatFlow=combatFlowPurposeLoss(rows,own,combatFlowWeight)
          if(combatFlow)terms.push(combatFlow)
          if(retentionWeight>0){
            const anchor=teacherLogits.map((_,h)=>tf.tensor2d(rows.map(r=>r.sourceLogits[h])))
            const retention=sourceRetentionLoss(teacherLogits,anchor,spatialOutputHeads||heads,retentionWeight)
            if(retention)terms.push(retention)
          }
          return tf.mean(tf.stack(terms))
        },trainable)
        const norm=Math.sqrt(tf.addN(Object.values(grads).map(g=>tf.sum(tf.square(g)))).dataSync()[0])
        assert(Number.isFinite(value.dataSync()[0])&&Number.isFinite(norm))
        const scale=Math.min(1,1/Math.max(norm,1e-12))
        optimizer.applyGradients(Object.fromEntries(Object.entries(grads).map(([k,g])=>{
          // BC-only gradient isolation: retain fine aim learned previously.
          // The recurrent heads still freely choose all view angles at runtime.
          if(coarseTemporalYaw&&k.includes('.spatial-movement-temporal-out-6.'))
            g=tf.mul(g,tf.tensor1d(Array.from({length:13},(_,i)=>Number(i===0||i===12))))
          return [k,tf.mul(g,scale)]
        })));steps++
      })
    }
    if(epoch%5===4||epoch===epochs-1){
      const validation=evaluate(),checks={...skillChecks(baseline,validation),
        ...(auditActionFlow?Object.fromEntries(Object.entries(actionFlowChecks(baseline.actionFlow,validation.actionFlow))
          .map(([k,v])=>['actionFlow:'+k,v])):{}),
        ...(auditResponseWindows?Object.fromEntries(Object.entries(responseWindowChecks(baseline.responseWindows,validation.responseWindows))
          .map(([k,v])=>['responseWindow:'+k,v])):{}),
        ...(autonomousSupervision?Object.fromEntries(Object.entries(skillChecks(baseline.autonomous,validation.autonomous))
          .map(([k,v])=>['autonomous:'+k,v])):{})},eligible=Object.values(checks).every(Boolean)
      const responseScore=responseLossWeight>0?['forecastThreatClearance','lastLegalSwordContact'].reduce((n,k)=>{
        const v=validation.responseWindows[k];return n+(v?.count?1-v.correct/v.count:1)},0)/2:0
      const flowRows=auditActionFlow?Object.values(validation.actionFlow).filter(v=>v.count>=5&&Number.isFinite(v.correct)):[]
      const flowScore=flowRows.length?flowRows.reduce((n,v)=>n+1-v.correct/v.count,0)/flowRows.length:0
      const score=Object.values(validation.byLesson).map(skillScore).reduce((a,b)=>a+b,0)/Object.keys(validation.byLesson).length+responseScore+flowScore
      log({stage:'epoch',epoch,steps,validation,checks,passed:eligible,selectionScore:score})
      if(!best||eligible&&!best.eligible||eligible===best.eligible&&score<bestScore){
        bestScore=score
        const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,loaded.adam,
          {...loaded.counters,lastCurrentStateCorrectionSteps:steps})
        best={epoch,steps,validation,eligible,saved};fs.writeFileSync(path.join(dest,'best.json'),JSON.stringify(best,null,2))
      }
      if(stopOnQualified&&eligible){stoppedOnQualified=true;break}
    }
  }
  // Unchanged recurrent features are an invariant, not a tolerance budget.
  for(const[i,p]of model.params.entries())if(!trainedNames.has(p.name))assert.deepEqual(new Float32Array(p.dataSync()),before[i])
  const receipt={schema:'supervised-current-state-correction-v1',source,dataset:datasetFile,
    datasetSha256,baselineDatasetSha256:datasetSha256,baselineReferenceSha256:referenceSha256,
    sourceSha256:loaded.manifest.sha256,referenceCheckpoint,referenceSha256,
    baseline,best,checks:{...skillChecks(baseline,best.validation),
      ...(auditActionFlow?Object.fromEntries(Object.entries(actionFlowChecks(baseline.actionFlow,best.validation.actionFlow))
        .map(([k,v])=>['actionFlow:'+k,v])):{}),
      ...(auditResponseWindows?Object.fromEntries(Object.entries(responseWindowChecks(baseline.responseWindows,best.validation.responseWindows))
        .map(([k,v])=>['responseWindow:'+k,v])):{}),
      ...(autonomousSupervision?Object.fromEntries(Object.entries(skillChecks(baseline.autonomous,best.validation.autonomous))
        .map(([k,v])=>['autonomous:'+k,v])):{})},offlineChecksPassed:best.eligible,
    allBackbonesTrained:parent.trainedBackbonesInAncestor||parent.allBackbonesTrained===true,allBackbonesTrainedInThisStage:false,
    frozenBackbonesUnchanged:true,trainableResidualParameters:trainable.reduce((n,p)=>n+p.size,0),
    imitationStepsSinceReference:inheritedSteps+best.steps,
    learningRate:rate,ppoOptimizerSteps:loaded.adam.steps,ppoEligible:false,livePvpImprovementVerified:false,
    auditResponseWindows,auditActionFlow,jumpPositiveWeight,attackPositiveWeight,movementHoldWeight,autonomousWaitWeight,autonomousParentsUsedForWaitSupervision:autonomousWaitWeight>0,
    autonomousAttackWeight,autonomousPositiveAttackRequiresMatchingParents:true,
    balanceLessons,balanceSprintClasses,balanceMovementClasses,trainOnlyLessonWeights:lessonWeights,
    attackOutputOnly,spatialOnly,spatialInputFrozen:Boolean(spatialOutputHeads),trainSelectedSpatialInput,trainAllSpatialInputs,spatialTemporalOnly,temporalOutputOnly,coarseTemporalYaw,trainTemporalRouteInput,purposeLossWeight,
    causalThreatFeaturesUsed:model.config.publicThreatInputs===12,causalTemporalFeaturesUsed:model.config.spatialTemporalFusionVersion===1,
    responseWeight,responseLossWeight,groundStrikeWeight,combatFlowWeight,retentionWeight,
    trainedOutputHeads:spatialOnly?(spatialOutputHeads||heads):selectedOutputs,
    jointContextSpatial,learnedPublicGeometryAndThreatInputs:jointContextSpatial,
    stopOnQualified,stoppedOnQualified,
    parentActionParametersUnchanged:selectedOutputs?.length===1&&selectedOutputs[0]===4,
    trainingSourceSha256,sourceHashesCapturedBeforeTraining:true,trainingSourceSnapshot:'training-source',
    cachedFeaturesFromCompleteOrderedBouts:true,validationUsedForGradients:false,noOnlineCombatRuleAdded:true}
  receipt.residualBatchesMixedAcrossTrainingBouts=true
  receipt.inheritedResidualReplacedNotDoubleCounted=true
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
  log({stage:'complete',passed:receipt.offlineChecksPassed,checks:receipt.checks,steps:best.steps})
}finally{optimizer.dispose();loaded.adam.dispose();model.dispose()}
