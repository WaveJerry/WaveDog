import fs from 'node:fs'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,SharedAdam}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
import {conditionalAttackOffsets,autonomousCachedLogits}from './current-state-conditioning.js'
import {jointPolicyResiduals,jointResidualParameters}from './joint-policy-residuals.js'
const [source,dataset]=process.argv.slice(2)
assert(source&&dataset)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source),{model}=loaded,
 data=JSON.parse(fs.readFileSync(dataset)),frames=data.trajectories.find(t=>t.split==='train').frames.slice(0,24)
let state=model.initialState()
const rows=[],expected=[]
const scale=head=>{
 const i=[2,5].indexOf(head)
 return model.contextBaseCalibration&&i>=0?2/(1+Math.exp(-model.contextBaseCalibration.dataSync()[i])):1
}
try{
 for(const frame of frames){
  const out=advance(model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures,
   frame.publicSpatialFeatures,frame.publicThreatFeatures);state=out.state
  const full=captureDeployedImitation(model,out,frame).logits
  const row={frame,projected:tf.tidy(()=>[...model.projectPolicyInputs(tf.tensor2d([frame.observation]),
   frame.publicHealthFeatures,frame.publicThreatFeatures).dataSync()]),
   recurrent:{fast:[...state.fast.dataSync()],slow:[...state.slow.dataSync()]}}
  const residual=tf.tidy(()=>jointPolicyResiduals(model,[row]).map(t=>[...t.dataSync()]))
  row.base=full.map((head,h)=>{const j=model.config.actionContextHeads.indexOf(h)
   return head.map((v,k)=>j<0?v:(v-residual[j][k])/scale(h))})
  row.teacherAttackOffset=tf.tidy(()=>[...conditionalAttackOffsets(model,[row],[frame.actions]).dataSync()])
  rows.push(row);expected.push(full)
 }
 const reconstructed=tf.tidy(()=>jointPolicyResiduals(model,rows).map(t=>t.arraySync()))
 let maxError=0
 for(const[i,row]of rows.entries())for(const[j,h]of model.config.actionContextHeads.entries())
  for(let k=0;k<expected[i][h].length;k++)
   maxError=Math.max(maxError,Math.abs(row.base[h][k]*scale(h)+reconstructed[j][i][k]-expected[i][h][k]))
 assert(maxError<1e-5,'Frozen-base residual replacement changed serving logits: '+maxError)
 const params=jointResidualParameters(model),names=params.map(p=>p.name)
 assert.equal(new Set(names).size,names.length,'Each neural parameter has one optimizer slot')
 assert(!names.some(n=>/\.fast\.|\.slow-\d+\.|\.gate-/.test(n)),'This stage must not claim backbone updates')
 const gradients=tf.tidy(()=>{
  const {value,grads}=tf.variableGrads(()=>tf.addN(jointPolicyResiduals(model,rows).map(t=>tf.mean(tf.square(t)))),params)
  const groups={};for(const p of params){const g=grads[p.name]
   if(g){const group=p.name.replace(/^dual\d+\./,'').split('.')[0]
    groups[group]=(groups[group]||0)+tf.sum(tf.abs(g)).dataSync()[0]}}
  return {loss:value.dataSync()[0],groups}
 })
 assert(Object.values(gradients.groups).every(Number.isFinite))
 for(const name of ['action-context-in','spatial-movement-in','spatial-movement-temporal-in','spatial-movement-temporal-route-in'])
  assert(gradients.groups[name]>0,'Missing gradient for '+name)
 // Test the meaningful invariant after a real optimizer update, rather than
 // only rebuilding logits with the unchanged source weights.
 const selected=new Set(names),frozen=model.params.filter(p=>!selected.has(p.name)),
  before=frozen.map(p=>new Float32Array(p.dataSync())),optimizer=new SharedAdam(params,{learningRate:.0001})
 const cached=()=>{
  const residual=jointPolicyResiduals(model,rows)
  return rows[0].base.map((_,h)=>{
   const base=tf.tensor2d(rows.map(row=>row.base[h])),j=model.config.actionContextHeads.indexOf(h)
   return j<0?base:tf.add(tf.mul(base,scale(h)),residual[j])
  })
 }
 try{
  tf.tidy(()=>{
   const {grads}=tf.variableGrads(()=>{
    const logits=cached(),terms=[]
    for(const h of [0,1,2,4,5,6]){
     const labels=rows.map(row=>row.frame.labels[h]),mask=labels.map(a=>Number(a!==undefined))
     if(!mask.some(Boolean))continue
     terms.push(tf.mean(tf.mul(tf.tensor1d(mask),tf.neg(tf.sum(tf.mul(
      tf.oneHot(labels.map(a=>a??0),logits[h].shape[1]),tf.logSoftmax(logits[h])),1)))))
    }
    return tf.addN(terms)
   },params)
   optimizer.applyGradients(grads)
  })
  const fitted=tf.tidy(()=>cached().map(t=>t.arraySync())),
   fittedOwn=tf.tidy(()=>autonomousCachedLogits(model,rows,cached()).map(t=>t.arraySync()))
  let replay=model.initialState(),maxUpdatedError=0,maxOwnError=0,changed=0
  try{
   for(const[i,row]of rows.entries()){
    const f=row.frame,out=advance(model,replay,f.observation,true,f.legalMasks,f.publicHealthFeatures,
     f.publicSpatialFeatures,f.publicThreatFeatures);replay=out.state
    const full=captureDeployedImitation(model,out,f).logits,own=captureAutonomousImitation(model,out,f).logits
    for(let h=0;h<full.length;h++)for(let k=0;k<full[h].length;k++){
     if(f.legalMasks?.[h]?.[k]===false)continue
     maxUpdatedError=Math.max(maxUpdatedError,Math.abs(fitted[h][i][k]-full[h][k]))
     maxOwnError=Math.max(maxOwnError,Math.abs(fittedOwn[h][i][k]-own[h][k]))
     if(Math.abs(full[h][k]-expected[i][h][k])>1e-6)changed++
    }
   }
  }finally{disposeState(replay)}
  assert(changed>0,'Optimizer step must change the policy')
  assert(maxUpdatedError<2e-5,'Updated residual cache diverges from full serving: '+maxUpdatedError)
  assert(maxOwnError<2e-5,'Policy-selected parents diverge after fitting: '+maxOwnError)
  for(const[i,p]of frozen.entries())assert.deepEqual(new Float32Array(p.dataSync()),before[i],p.name+' changed despite being frozen')
  console.log(JSON.stringify({stage:'fitted-serving-equivalence',passed:true,frames:rows.length,
   maxUpdatedError,maxOwnError,changedLegalLogits:changed,frozenBackbonesUnchanged:true}))
 }finally{optimizer.dispose()}
 console.log(JSON.stringify({passed:true,frames:rows.length,maxServingLogitError:maxError,
  trainableParameters:params.reduce((n,p)=>n+p.size,0),gradients:gradients.groups}))
}finally{disposeState(state);loaded.adam.dispose();model.dispose()}
