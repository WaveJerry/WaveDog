import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,validateDataset} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
const arg=(k)=>{const i=process.argv.indexOf(k);if(i<0)throw Error(k+' required');return path.resolve(process.argv[i+1])}
const file=arg('--checkpoint'),datasetFile=arg('--dataset'),dest=arg('--out')
if(fs.existsSync(dest))throw Error('Preserve error evidence')
const dataset=JSON.parse(fs.readFileSync(datasetFile));validateDataset(dataset)
const splitIndex=process.argv.indexOf('--split'),split=splitIndex<0?'validation':process.argv[splitIndex+1]
if(!['train','validation'].includes(split))throw Error('Invalid diagnostic split')
const headIndex=process.argv.indexOf('--heads'),heads=headIndex<0?[2,4,5]:process.argv[headIndex+1].split(',').map(Number)
if(!heads.length||heads.some(h=>!Number.isInteger(h)||h<0||h>8))throw Error('Invalid diagnostic heads')
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(file),errors=[]
try{for(const trace of dataset.trajectories.filter(t=>t.split===split)){
  let state=loaded.model.initialState()
  try{for(const f of trace.frames){
    const out=advance(loaded.model,state,f.observation,true,f.legalMasks,f.publicHealthFeatures);state=out.state
    const result=captureAutonomousImitation(loaded.model,out,f)
    for(const h of heads)if(f.labels[h]!==undefined&&result.actions[h]!==f.labels[h]){
      const x=f.observation,s=f.publicRequest.self
      const log=result.logits[h],max=Math.max(...log),p=log.map(v=>Math.exp(v-max)),z=p.reduce((a,b)=>a+b,0)
      errors.push({source:trace.source,lesson:trace.lesson,tick:f.tick,head:h,label:f.labels[h],predicted:result.actions[h],
        probabilities:p.map(v=>v/z),effectiveShield:x[23]>.5,inReach:x[97]<=0,held:s.held,ground:s.ground,
        attackAge:s.attackAgeTicks,weaponAge:s.weaponAgeTicks,expertReason:f.expertReason??null,
        horizontal:Math.hypot(f.publicRequest.seen.x-s.x,f.publicRequest.seen.z-s.z),
        selfY:s.y,targetY:f.publicRequest.seen.y,wireFalling:s.wireFalling})
    }
  }}finally{disposeState(state)}
}}
finally{loaded.adam.dispose();loaded.model.dispose()}
fs.writeFileSync(dest,JSON.stringify({checkpointSha256:loaded.manifest.sha256,dataset:datasetFile,split,errors},null,2))
const important=errors.filter(e=>e.head===2&&e.label===1||e.head===5&&e.lesson==='shield-break-sword-continuation')
console.log(JSON.stringify({checkpointSha256:loaded.manifest.sha256,errorCounts:Object.fromEntries(heads.map(h=>[h,errors.filter(e=>e.head===h).length])),important}))
