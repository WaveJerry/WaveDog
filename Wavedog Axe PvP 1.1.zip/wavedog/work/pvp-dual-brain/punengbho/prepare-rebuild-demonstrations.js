// Full teacher-control demonstrations through the SAME deployed observation encoder.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {spawn}from 'node:child_process'
import readline from 'node:readline'
import {deployedShieldObservation}from '../../pvp-player-client/probe-public-observation.js'
import {legalMasks}from './pure-actions.js'
import {hybridLegalMasks}from '../hybrid-action-masks.js'
import {conditionCombatObservation}from '../combat-observation.js'
import {conditionTechniqueObservation}from '../technique-conditioning.js'
import {meleeEntryContext,meleeTechniqueGoal}from '../fresh-melee-progress.js'
import {publicHealthFeatures}from '../public-health-features.js'
import {validateDataset}from '../human-imitation.js'
import {scopeLegacyTacticalLabels}from './tactical-label-scope.js'
const root=path.resolve('.'),dest=path.join(root,'outputs/punengbho-rebuild-20261117')
const option=(key,fallback)=>{const i=process.argv.indexOf(key);return i<0?fallback:process.argv[i+1]}
const outputDir=path.resolve(option('--out',path.join(dest,'demonstrations')))
const priorFile=path.resolve(option('--preserve-splits',path.join(dest,'synchronous-demonstrations/dataset.json')))
const prior=fs.existsSync(priorFile)?JSON.parse(fs.readFileSync(priorFile)).trajectories:[]
const scopedCritical=process.argv.includes('--scope-critical-to-close')
const omitLegacyJumpWaits=process.argv.includes('--omit-legacy-close-jump-waits')
const scopeSpacing=process.argv.includes('--scope-spacing-curriculum')
const hybrid=process.argv.includes('--hybrid')
const preservedSplits=new Map(prior.map(t=>[t.source,t]))
fs.mkdirSync(outputDir,{recursive:true})
const checkpointFile=path.resolve(option('--checkpoint',path.join(dest,'initial/checkpoint.json')))
const config=JSON.parse(fs.readFileSync(checkpointFile)).config
const client=path.join(root,'work/pvp-player-client'),server='D:/Walt Disney/Minecraft-1.21.1-Server'
const cp=[path.join(client,'bridge-classes'),path.join(root,'work/pvp-neural-lab/classes'),
  path.join(server,'versions/1.21.1/paper-1.21.1.jar'),path.join(server,'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')].join(path.delimiter)
const bridge=spawn(path.join(server,'runtime/java21/bin/java.exe'),['-cp',cp,'local.wavedog.lab.ProtocolPlayerBridge',
  path.join(dest,'encoder-cache'),'--observe-only'],{stdio:['pipe','pipe','pipe'],windowsHide:true})
const queue=[],waiters=[];let errors=''
bridge.stderr.on('data',d=>{errors+=d})
readline.createInterface({input:bridge.stdout}).on('line',line=>{
  const r=JSON.parse(line),resolve=waiters.shift();if(resolve)resolve(r);else queue.push(r)
})
const receive=()=>queue.length?Promise.resolve(queue.shift()):new Promise(resolve=>waiters.push(resolve))
async function send(r){bridge.stdin.write(JSON.stringify(r)+'\n');const out=await receive();if(out.event==='error')throw Error(out.message);return out}
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180],pitches=[-30,-10,-3,0,3,10,30]
const nearest=(v,a)=>a.reduce((best,x,i)=>Math.abs(x-v)<Math.abs(a[best]-v)?i:best,0)
const wrap=x=>((x+540)%360)-180
const trajectories=[],audit=[],lessonCounts={}
try{
  if((await receive()).architecture!=='PUBLIC-OBS-98')throw Error('Wrong encoder')
  const files=fs.readdirSync(path.join(dest,'demonstrations')).filter(n=>n.endsWith('.jsonl')).sort()
  for(const [index,name]of files.entries()){
    const file=path.join(dest,'demonstrations',name),bytes=fs.readFileSync(file)
    const rows=bytes.toString().trim().split('\n').map(JSON.parse),start=rows[0],end=rows.at(-1)
    // v1 deferred snapshots can cross physics catch-up ticks. Retain the raw
    // evidence, but never reuse it as exact input supervision.
    if(start.schema!=='exact-protocol-demonstration-v2'||!start.synchronousFrameFinalization)continue
    if(end.type!=='end'||!end.complete)throw Error('Incomplete demonstration '+name)
    const native=fs.readFileSync(end.nativeFeedbackFrames,'utf8').trim().split('\n').map(JSON.parse)
    const ordinaryCooldownOnly=end.feedbackEvidence==='ordinary-defender-client-health-and-shield-cooldown'
    const cutoff=native.at(-1)?.capturedAt??Infinity
    const events=native.flatMap(f=>f.nativeEvents||[]).filter(e=>e.attacker===start.fighter&&!e.cancelled&&e.amount>0)
    const crits=events.filter(e=>e.nativeCritical).length
    if(start.mode==='critical'&&crits<2)throw Error('Teacher critical mode has insufficient native evidence '+name)
    await send({command:'reset',fighter:start.fighter,opponent:start.opponent,learning:false})
    const frames=[],publicHistory={};let previous=null,context=null,first=null
    for(const row of rows.filter(r=>r.type==='frame'&&r.at<=cutoff)){
      const req=deployedShieldObservation(row.publicRequest,publicHistory),c=row.executed
      if(hybrid){req.trainingScope='hybrid_native_player';req.style='AGGRESSIVE'}
      if(first===null)first=req.tick
      req.publicTerrain.episodeTick=req.tick-first
      const raw=await send(req)
      context=meleeEntryContext(previous,req,context)
      context.distributionVersion=config.distributionVersion||1
      context.actionConditionedAttack=config.actionConditionedAttack||0
      context.weaponConditionedAttack=config.weaponConditionedAttack||0
      if(context.distributionVersion>=3)context.calibratedHeads=config.calibratedHeads||[2,5]
      const {focus,techniqueCues}=meleeTechniqueGoal(req,context)
      const observation=conditionCombatObservation(conditionTechniqueObservation(raw.observation,focus,techniqueCues,null,req.publicTerrain),req,config)
      const forward=Number(c.forward)-Number(c.back),side=Number(c.right)-Number(c.left)
      const move=[[0,0],[1,0],[-1,0],[0,-1],[0,1],[1,-1],[1,1],[-1,-1],[-1,1]].findIndex(([f,s])=>f===forward&&s===side)
      if(move<0)throw Error('Unrepresentable recorded movement')
      if(row.heldItemName&&row.heldItemName!==(row.held===0?'diamond_sword':row.held===7?'diamond_axe':null))
        throw Error('Teacher item does not match deployed slot semantics '+name)
      const weapon=row.held===0?1:row.held===7?0:null
      if(weapon===null)throw Error('Unknown teacher melee weapon')
      const labels={0:move,1:Number(c.sprint),3:Number(c.sneak),4:row.attackPacket?2:0,5:weapon,8:0}
      if(req.self.ground)labels[2]=Number(c.jump)
      if(req.seen.visible){
        const s=req.self,t=req.seen
        const px=Math.max(t.x-.3+.0001,Math.min(t.x+.3-.0001,s.x)),pz=Math.max(t.z-.3+.0001,Math.min(t.z+.3-.0001,s.z))
        const py=Math.max(t.y+.0001,Math.min(t.y+1.8-.0001,s.eyeY)),dx=px-s.x,dz=pz-s.z,dy=py-s.eyeY
        const yaw=Math.atan2(-dx,dz)*180/Math.PI,pitch=-Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI
        labels[6]=nearest(wrap(row.executedView.yaw-yaw),turns)
        labels[7]=nearest(row.executedView.pitch-pitch,pitches)
      }
      // Preserve factual parent actions before masking obsolete supervision.
      // Attack conditioning must not turn an actual jump/sword into zero.
      const actions=Array(9).fill(0);for(const[h,a]of Object.entries(labels))actions[h]=a
      const recordedActions=[...actions];recordedActions[2]=Number(c.jump)
      // The deployed action mask excludes airborne re-jump. Keep held-space
      // evidence separately; condition attack on a legal equivalent action.
      actions[2]=req.self.ground?Number(c.jump):0
      const omittedLabels={}
      if(omitLegacyJumpWaits&&(start.closeJumpVersion??1)<2
          &&['critical','critical-switch'].includes(start.mode)&&req.self.ground
          &&req.seen.visible&&!req.seen.shield&&labels[2]===0
          &&Math.hypot(req.seen.x-req.self.x,req.seen.z-req.self.z)<2.45){
        // These are factual old controls, but their artificial rest timer is
        // obsolete under the operator's new continuous-close-jump curriculum.
        // Preserve raw evidence; omit the obsolete target rather than claiming
        // the old teacher actually jumped on a frame where it did not.
        omittedLabels[2]=labels[2];delete labels[2]
      }
      if(scopedCritical&&start.mode==='critical'&&req.seen.visible
          &&Math.hypot(req.seen.x-req.self.x,req.seen.z-req.self.z)>=2.45){
        // A specialist jumping on approach is not a general ground-control
        // teacher. Keep factual observations/actions; omit out-of-scope labels
        // rather than inventing opposite keys for an unexecuted trajectory.
        if(labels[2]===1){omittedLabels[2]=labels[2];delete labels[2]}
        if(labels[4]===0&&row.reach<=3){omittedLabels[4]=labels[4];delete labels[4]}
      }
      const frame={tick:req.tick,observation,labels,actions,recordedActions,context,publicRequest:req,
        labelEvidence:['exact-recorded-client-controls-and-packets'],legalMasks:(hybrid?hybridLegalMasks:legalMasks)(req),
        publicHealthFeatures:publicHealthFeatures(req),supervisionWeight:1,
        teacherNativeCriticalsInBout:ordinaryCooldownOnly?null:crits,omittedOutOfScopeTeacherLabels:omittedLabels,
        publicObservationAdapter:'deployed-five-public-tick-shield-warmup-v1'}
      frames.push(scopeSpacing?scopeLegacyTacticalLabels(frame,start):frame)
      previous=req
    }
    // Preserve the old holdout when expanding the curriculum. Stratify new
    // complete bouts by skill, so new distance data has its own holdout.
    const lesson=start.mode==='critical'?'close-critical':start.mode==='critical-switch'?'shield-break-sword-continuation':'ground-control-and-transition'
    const old=preservedSplits.get(name)
    const sourceSha256=crypto.createHash('sha256').update(bytes).digest('hex')
    if(old&&old.sourceSha256!==sourceSha256)throw Error('Preserved demonstration changed '+name)
    const count=lessonCounts[lesson]||0;lessonCounts[lesson]=count+1
    const split=old?.split??(count%3===2?'validation':'train')
    trajectories.push({source:name,matchId:start.matchId,fighter:start.fighter,opponent:start.opponent,
      sourceKind:'exact-script-demonstration',sourceSha256,split,frames,lesson,teacherMode:start.mode,
      tacticalCurriculumVersion:start.tacticalCurriculumVersion??1,
      requestedStartDistance:start.requestedStartDistance??null,
      actualTeacherStartDistance:start.actualTeacherStartDistance??null})
    audit.push({file:name,split,frames:frames.length,nativeCriticals:ordinaryCooldownOnly?null:crits,
      nativeDamage:ordinaryCooldownOnly?null:events.reduce((n,e)=>n+e.amount,0),
      feedbackEvidence:end.feedbackEvidence||'model-referee-native-damage-events',
      ordinaryShieldCooldowns:ordinaryCooldownOnly?native.filter(r=>r.type==='shield-cooldown'&&r.cooldownTicks>0).length:null,
      lesson,teacherMode:start.mode,actualTeacherStartDistance:start.actualTeacherStartDistance??null,
      actualAttacks:frames.filter(f=>f.labels[4]===2).length,
      omittedLabelsByHead:Object.fromEntries(Array.from({length:9},(_,h)=>[h,
        frames.filter(f=>f.omittedOutOfScopeTeacherLabels[h]!==undefined).length]))})
  }
  const dataset={schema:'public-human-imitation-v1',ppoEligible:false,trajectories,
    exactTeacherControls:true,observationSchema:config.combatObservationVersion===2?'combat-own-state-v2':'public-observation-v1',
    policyObservationConfig:config,controlRegime:hybrid?'hybrid-native-player':'pure-model-all-input',combatRouteForcedAtRuntime:false,
    omitLegacyCloseJumpWaits:omitLegacyJumpWaits,scopeSpacingCurriculum:scopeSpacing}
  const counts=validateDataset(dataset)
  fs.writeFileSync(path.join(outputDir,'dataset.json'),JSON.stringify(dataset))
  fs.writeFileSync(path.join(outputDir,'dataset-audit.json'),JSON.stringify({audit,counts},null,2))
  console.log(JSON.stringify({audit,counts}))
}finally{bridge.stdin.write('{"command":"close"}\n');bridge.stdin.end();
  await new Promise(resolve=>{bridge.once('exit',resolve);setTimeout(resolve,3000)});if(bridge.exitCode===null)bridge.kill()}
