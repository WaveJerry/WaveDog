import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { RolloutJournal } from './rollout-journal.js'

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'pvp-rollouts-'))
try {
  const journal = new RolloutJournal(directory, 0)
  const first = journal.append({ fighter: 'NBot01', round: 5,
    episode: [{ observation: [1], reward: -.018 }] })
  const second = journal.append({ fighter: 'NBot02', round: 5,
    episode: [{ observation: [2], reward: .4 }] })
  assert.equal(first.rolloutSeq, 1)
  assert.equal(second.rolloutSeq, 2)
  assert.deepEqual(new RolloutJournal(directory, 1).pending(1), [second],
    'restart must replay only the rollout missing from the committed checkpoint')
  assert.deepEqual(new RolloutJournal(directory, 2).pending(2), [],
    'saved checkpoint sequence prevents duplicate PPO updates')
  assert.equal(new RolloutJournal(directory, 2).append({ fighter: 'NBot03', round: 6,
    episode: [{ observation: [3], reward: 1 }] }).rolloutSeq, 3)
  console.log('ROLLOUT_JOURNAL_PASS')
} finally {
  for (const name of fs.readdirSync(directory)) fs.unlinkSync(path.join(directory, name))
  fs.rmdirSync(directory)
}
