"""Fetch primary research abstracts; preserve receipts, never server secrets."""
from pathlib import Path
import concurrent.futures,hashlib,json,re,urllib.request
ROOT=Path(__file__).resolve().parents[3]
DEST=ROOT/'outputs/punengbho-rebuild-20261117/research';DEST.mkdir(parents=True,exist_ok=True)
SOURCES={
    'vpt':'https://arxiv.org/abs/2206.11795',
    'gtrxl':'https://arxiv.org/abs/1910.06764',
    'ppo':'https://arxiv.org/abs/1707.06347',
    'dagger':'https://proceedings.mlr.press/v15/ross11a.html',
    'alphastar':'https://www.nature.com/articles/s41586-019-1724-z'}
def fetch(item):
    name,url=item
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 research-reference-check'})
        with urllib.request.urlopen(req,timeout=25)as response:data=response.read(3_000_000)
        (DEST/(name+'.html')).write_bytes(data)
        text=re.sub('<[^>]+>',' ',data.decode('utf8',errors='replace'))
        text=re.sub(r'\s+',' ',text)
        return {'name':name,'url':url,'fetched':True,'sha256':hashlib.sha256(data).hexdigest(),'text':text[:20000]}
    except Exception as error:return {'name':name,'url':url,'fetched':False,'error':str(error)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as pool:rows=list(pool.map(fetch,SOURCES.items()))
(DEST/'sources.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
for r in rows:print(json.dumps({k:v for k,v in r.items()if k!='text'}))
if not all(r['fetched']for r in rows):raise SystemExit(2)
