import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import assert from 'node:assert/strict'
import {criticalExpert,observeLearnerInput,sourceSha256}from './joint-melee-expert.cjs'
import {learnerRequest}from './causal-learner-input.js'
import {directionalMovementSupervision}from './directional-movement-supervision.js'
const [file,out]=process.argv.slice(2)
if(!file||!out||fs.existsSync(out))throw Error('dataset and unused audit path required')
const bytes=fs.readFileSync(file),data=JSON.parse(bytes),counts={teacherFrames:0,mechanicalContext:0,humanTraces:0}
for(const t of data.trajectories){
  if(t.sourceKind!=='dagger-expert-relabel'){counts.humanTraces++;continue}
  const raw=fs.readFileSync(path.resolve('work/wavedog-punengbho/runtime',t.matchId+'-frames.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
  const frames=new Map(t.frames.map(f=>[f.tick,f])),history={}
  for(const r of raw){
    const req={...learnerRequest(r,{matchId:t.matchId,opponent:t.opponent}),jumpInputVersion:2}
    const a=directionalMovementSupervision(criticalExpert(req,history),req),f=frames.get(r.tick)
    observeLearnerInput(history,req,{...r.executed,attackPacket:r.attackPacket,held:r.attackHeld??r.self.held})
    if(!f)continue
    const mechanical=Boolean(r.mode&&r.mode!=='NEURAL')
    assert.deepEqual(f.labels,mechanical?{}:a.labels,`${t.matchId}:${f.tick}: mixed teacher labels`)
    if(mechanical)counts.mechanicalContext++
    else{
      counts.teacherFrames++
      for(const [h,v]of Object.entries(a.labels))assert.equal(f.actions[h],v,'teacher parent and labels must agree')
      assert.equal(f.expertReason,a.reason)
      assert.equal(f.supervisionTargetTick,f.tick)
    }
  }
}
const result={passed:true,counts,expertSourceSha256:sourceSha256,
  datasetSha256:crypto.createHash('sha256').update(bytes).digest('hex'),
  codeSha256:Object.fromEntries(['prepare-sword-continuation.js','causal-learner-input.js','directional-movement-supervision.js']
    .map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(new URL(n,import.meta.url))).digest('hex')])),
  sameTickPublicInputOnly:true,onlineActionOverride:false,trainingPerformed:false}
fs.writeFileSync(out,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
