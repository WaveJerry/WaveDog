import assert from 'node:assert/strict'
import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { meleeEntryContext, meleeTechniqueGoal } from './fresh-melee-progress.js'
import { biasedActionLogits, maskActionLogits, ACTION_WIDTHS, OBS_SIZE } from './fresh-policy.js'
import { biasedActionLogits as oldPolicy } from './runtime/pvp-technique-20261115/before/fresh-policy.js'

const base = { tick: 1, matchId: 'one', opponent: 'B', focus: 'FREE',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62, ground: true, vy: 0,
    health: 20, held: 7, charge: .2, shieldAvailable: false },
  seen: { visible: true, x: 0, y: 0, z: 1.8, shield: false, held: 'DIAMOND_SWORD' } }
const middle = { ...base, tick: 2 }
const last = { ...base, tick: 3 }
const close = meleeEntryContext(middle, last, meleeEntryContext(base, middle))
assert(close.swordDpsWindow)
assert.equal(meleeTechniqueGoal(last, close).focus, 'COMBO')
assert(!meleeEntryContext(middle, { ...last, self: { ...last.self, charge: 1 } }, close).swordDpsWindow,
  'do not throw away an already charged axe')
assert(!meleeEntryContext(middle, { ...last, self: { ...last.self, shieldAvailable: true } }, close).swordDpsWindow)
assert(!meleeEntryContext(middle, { ...last, self: { ...last.self, using: true } }, close).swordDpsWindow)
assert(!meleeEntryContext(middle, { ...last, seen: { ...last.seen, shield: true } }, close).swordDpsWindow)
assert(!meleeEntryContext(middle, { ...last, matchId: 'other' }, close).swordDpsWindow)
assert(!meleeEntryContext(middle, { ...last, tick: 9 }, close).swordDpsWindow)
assert(!meleeEntryContext(middle, { ...last, seen: { ...last.seen, z: 4 } }, close).swordDpsWindow)
const sword = { ...last, self: { ...last.self, held: 0, charge: .8 } }
assert(meleeEntryContext(middle, sword, close).swordCadenceWindow)
const pressured = { ...last, self: { ...last.self, health: 15 } }
assert(meleeEntryContext(middle, pressured, close).jumpResetTrial,
  'actual received damage can trigger an experiment outside the rare SYNC curriculum')
assert.equal(meleeTechniqueGoal(last, { ...close, fallingMeleeThreat: true,
  ownFallingWindow: false, jumpResetTrial: true, swordComboPressure: true }).focus, 'OPPONENT',
  'a later sword/jump cue cannot override recognition of an already falling attack')
const far = { ...base, seen: { ...base.seen, z: 3.5, y: 0 } }
const rising = { ...far, tick: 2, seen: { ...far.seen, z: 3.2, y: .3 } }
const risingContext = meleeEntryContext(far, rising)
assert(risingContext.risingEntryThreat)
assert.equal(meleeTechniqueGoal(rising, risingContext).focus, 'SPRINT_KB')

const observation = Array(OBS_SIZE).fill(0)
observation[0] = 1; observation[1] = .2; observation[2] = 1
observation[10] = 4; observation[12] = .875; observation[31] = 1; observation[97] = -.6
const logits = ACTION_WIDTHS.map(width => tf.zeros([1, width]))
logits[5].dispose(); logits[5] = tf.tensor2d([[13.92, -4.65, 4.76, 2.97, .76]])
const masks = ACTION_WIDTHS.map(width => Array(width).fill(true))
masks[5] = [true, true, false, false, false]
masks[4] = [true, false, true, false, false]
const chance = (x, context, source = logits, index = 5, choice = 1) => tf.tidy(() => {
  const heads = biasedActionLogits(source, x, context)
  return tf.softmax(maskActionLogits(heads, masks)[index]).dataSync()[choice]
})
const before = chance(observation, { ...close, entryCurriculum: 5 })
const reopened = chance(observation, close)
assert(before < 1e-7 && reopened > .02 && reopened < .5,
  'the measured collapsed sword logits become learnable in the demonstrated close follow-up window')
const parameter = tf.variable(tf.tensor2d([[13.92, -4.65, 4.76, 2.97, .76]]))
const sources = logits.map((head, index) => index === 5 ? parameter : head)
const gradient = tf.variableGrads(() => tf.tidy(() => {
  const heads = biasedActionLogits(sources, observation, close)
  return tf.logSoftmax(maskActionLogits(heads, masks)[5]).slice([0, 1], [1, 1]).sum()
}), [parameter])
assert(gradient.grads[parameter.name].dataSync()[1] > .001,
  'PPO retains a useful nonzero gradient for the previously abandoned action')
assert([...gradient.grads[parameter.name].dataSync()].every(Number.isFinite))
const a = tf.tidy(() => biasedActionLogits(logits, observation, close).map(head => [...head.dataSync()]))
const b = tf.tidy(() => biasedActionLogits(logits, observation,
  JSON.parse(JSON.stringify(close))).map(head => [...head.dataSync()]))
assert.deepEqual(a, b, 'acting and PPO replay use exactly the same versioned conditional distribution')
const ordinary = tf.tidy(() => biasedActionLogits(logits, observation,
  { ...close, entryCurriculum: 5 }).map(head => [...head.dataSync()]))
for (const index of [0, 1, 2, 3, 4, 6, 7, 8]) assert.deepEqual(a[index], ordinary[index],
  'the sword repair sends no movement, jump, sprint, offhand or attack override')
const charged = [...observation]; charged[1] = 1
assert.equal(chance(charged, close), chance(charged, { ...close, entryCurriculum: 5 }))
const cadence = [...observation]; cadence[1] = .8; cadence[12] = 0
const hands = logits.map((head, index) => index === 4 ? tf.tensor2d([[8, 0, -9, 0, 0]]) : head)
const cadenceContext = { entryCurriculum: 6, swordCadenceWindow: true }
assert(chance(cadence, cadenceContext, hands, 4, 2) > .01,
  'useful sword cadence is learnable before the axe-oriented waiting threshold')
assert.equal(chance(cadence, { ...cadenceContext, fallingMeleeThreat: true }, hands, 4, 2),
  chance(cadence, { entryCurriculum: 5, fallingMeleeThreat: true }, hands, 4, 2),
  'do not turn a dangerous falling-crit exchange into a compulsory cadence hit')

// Every real frame in this archived rollout must retain its previous replay
// probabilities. New context fields must not reinterpret old on-policy data.
const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(
  new URL('../pvp-8.6-dual-fresh/model/rollouts/rollout-000000001780.json.gz', import.meta.url))))
for (const frame of rollout.episode) {
  const old = tf.tidy(() => oldPolicy(logits, frame.observation, frame.context,
    frame.actions).map(head => [...head.dataSync()]))
  const current = tf.tidy(() => biasedActionLogits(logits, frame.observation, frame.context,
    frame.actions).map(head => [...head.dataSync()]))
  assert.deepEqual(current, old)
}
tf.dispose([parameter, gradient.value, ...Object.values(gradient.grads), ...logits, hands[4]])
console.log(JSON.stringify({ event: 'HUMAN_TECHNIQUES_PASS', oldSwordChance: before,
  newSwordExplorationChance: reopened, historicalFramesVerified: rollout.episode.length,
  modelWeightsChanged: false, serverUpdated: false }))
