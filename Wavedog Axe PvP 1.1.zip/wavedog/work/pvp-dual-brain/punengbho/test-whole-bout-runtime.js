import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import {spawn}from 'node:child_process'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy}from '../fresh-policy.js'
import {SharedAdam,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {legalMasks}from './pure-actions.js'
import {publicThreatFeatures}from '../public-threat-features.js'
const folder=path.resolve('outputs/punengbho-integration-20261117/runtime-regression-'+Date.now())
fs.mkdirSync(folder,{recursive:true})
await tf.setBackend('cpu');await tf.ready()
const frozen=process.argv.includes('--frozen')
const threat=process.argv.includes('--threat')
const temporal=process.argv.includes('--temporal')
const route=process.argv.includes('--route')
if(temporal&&!threat)throw Error('Temporal integration test needs --threat')
if(route&&!temporal)throw Error('Route integration test needs --temporal')
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:3,calibratedHeads:[2,4,5],...(threat?{publicThreatInputs:12}:{}),...(frozen?{trainingStage:'behavior-cloning'}:{}),...(process.argv.includes('--rebuilt')?
    {distributionVersion:2,actionConditionedAttack:1,combatObservationVersion:2}:{}),...(temporal?{
      spatialMovementVersion:1,spatialMovementHeads:[0,1,6,5,4,2],spatialControlSplitHeads:[0,2,5],
      spatialTemporalFusionVersion:1,...(route?{spatialTemporalRouteSplit:1}:{})}:{})})
const adam=new SharedAdam(model.params,{learningRate:.00003})
const saved=saveDualCheckpoint(path.join(folder,'checkpoint.json'),model,adam,{lastRolloutSeq:0,dualUpdates:0})
adam.dispose();model.dispose()
const actor=spawn(process.execPath,[new URL('./fresh-actor.js',import.meta.url).pathname.replace(/^\/(?=[A-Z]:)/,''),saved.manifest],
  {stdio:['pipe','pipe','pipe'],windowsHide:true})
const rows=[];let pending=null,stderr=''
actor.stderr.on('data',d=>{stderr+=d})
readline.createInterface({input:actor.stdout}).on('line',line=>{
  const row=JSON.parse(line)
  if(pending?.predicate(row)){const p=pending;pending=null;clearTimeout(p.timer);p.resolve(row)}else rows.push(row)
})
const send=row=>actor.stdin.write(JSON.stringify(row)+'\n')
function wait(predicate){const i=rows.findIndex(predicate);if(i>=0)return Promise.resolve(rows.splice(i,1)[0])
  return new Promise((resolve,reject)=>{pending={predicate,resolve,timer:setTimeout(()=>{pending=null;reject(Error(stderr+' '+JSON.stringify(rows.slice(-4))))},45000)}})}
const ids={first:1000,ongoing:2000,new:3000}
const req=(fighter,tick)=>({command:'act',fighter,opponent:'test-target',matchId:fighter,requestId:ids[fighter]+tick,
  tick,focus:'FREE',style:'MIXED',trainingScope:'pure_model_all_input',yaw:0,pitch:0,
  ...(threat?{publicActionContext:{tick,visible:true,targetGrounded:false,
    targetVelocity:{x:0,y:-.1,z:-.08},targetCriticalPossible:true,
    airEnvelope:{valid:true,ticks:5,criticalTick:1,meleeTick:0}}}:{}),
  self:{x:0,y:221,z:0,eyeY:222.62,vx:0,vy:0,vz:0,ground:true,charge:1,health:20,food:20,held:0,
    shieldAvailable:true,shielding:false,using:false,useTicks:0,arrows:8,hasBow:true,hasCrossbow:true},
  seen:{visible:true,x:0,y:221,z:2.8,yaw:180,held:'DIAMOND_SWORD',using:false,shield:false,arrows:[]}})
try{
  await wait(r=>r.event==='ready')
  const masks=legalMasks(req('first',1))
  assert(masks[4].every(Boolean)&&masks[5].every(Boolean),'shield/ranged/hold remain model choices')
  for(const fighter of ['first','ongoing'])send({command:'reset',fighter,opponent:'test-target',matchId:fighter})
  for(let tick=1;tick<=8;tick++){
    send(req('first',tick));const action=await wait(r=>r.requestId===1000+tick)
    assert.equal(action.controlRegime,'pure-model-all-input')
    send({command:'executed',fighter:'first',decidedTick:tick,ignoredHeads:[]})
  }
  send({command:'finish',fighter:'first',matchId:'first',round:1,win:true,health:10})
  const trained=await wait(r=>['trained','training_error','evaluation_saved'].includes(r.event))
  assert.equal(trained.event,frozen?'evaluation_saved':'trained',JSON.stringify(trained))
  if(frozen){
    assert.equal(trained.trainingSkipped,true)
    assert.equal(JSON.parse(fs.readFileSync(saved.manifest)).sha256,saved.sha256)
    assert(!fs.readdirSync(path.join(folder,'rollouts')).some(n=>n.endsWith('.json.gz')),'no PPO recovery entry')
  }else{
    assert.equal(trained.candidateAccepted,true,JSON.stringify(trained))
    assert.equal(trained.optimizerSteps,1,'one unified full-bout PPO update')
  }
  const file=frozen?trained.file:path.join(folder,'rollouts',fs.readdirSync(path.join(folder,'rollouts')).find(n=>n.endsWith('.json.gz')))
  const rollout=JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
  if(frozen)assert.equal(rollout.ppoEligible,false)
  if(threat)for(const frame of rollout.episode){
    assert.deepEqual(frame.publicThreatFeatures,publicThreatFeatures(req('first',frame.decidedTick)))
    assert.equal(frame.publicThreatFeatures[6],1,'forecast reaches saved neural input')
  }
  if(frozen)for(const frame of rollout.episode){
    assert.equal(frame.ppoEligible,false)
    assert.equal(frame.behaviorSampling,'argmax-frozen-evaluation')
    for(let h=0;h<frame.actions.length;h++){
      const probabilities=frame.oldHeadProbabilities[h]
      assert.equal(frame.actions[h],probabilities.indexOf(Math.max(...probabilities)))
    }
  }
  assert(rollout.episode.every(f=>f.executedHeads.every(Boolean)),'camera and restoration are also learned')
  send(req('ongoing',1));const original=await wait(r=>r.requestId===2001)
  assert.equal(original.checkpointSha256,saved.sha256,'a current bout keeps its original policy and memory')
  send({command:'reset',fighter:'new',opponent:'test-target',matchId:'new'})
  send(req('new',1));const updated=await wait(r=>r.requestId===3001)
  assert.equal(updated.checkpointSha256,frozen?saved.sha256:trained.sha256,'only accepted training can change new bouts')
  for(const fighter of ['ongoing','new'])send({command:'discard',fighter})
  assert(!rows.some(r=>r.event==='error'),JSON.stringify(rows))
  const receipt={result:'PURE_WHOLE_BOUT_RUNTIME_PASS',allNineHeadsLearn:true,
    shieldAndRangedModelOwned:true,onePpoUpdate:!frozen,weightsPinnedWithinBout:true,
    nextBoutReceivesLearning:!frozen,frozenEvaluation:frozen,temporalSpatialFusion:temporal,routeProjection:route,productionUsed:false,trained}
  fs.writeFileSync(path.join(folder,'test-receipt.json'),JSON.stringify(receipt,null,2))
  console.log(JSON.stringify(receipt))
}finally{send({command:'close'});actor.stdin.end()
  await new Promise(resolve=>{actor.once('exit',resolve);setTimeout(resolve,3000)})
  if(actor.exitCode===null)actor.kill()}
