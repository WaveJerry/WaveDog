'use strict'
// Offline supervision only. No live controller imports this curriculum oracle.
const crypto=require('node:crypto'),fs=require('node:fs')
const {edgePlan,eyeReach}=require('../../pvp-player-client/probe-edge-controller')
const {sustainableCloseContact,groundControlMovement,contactGeometry}=require('./ground-contact-supervision.cjs')
const {contactArrival}=require('./contact-timing-forecast.cjs')
const sourceSha256=crypto.createHash('sha256').update(fs.readFileSync(__filename))
  .update(fs.readFileSync(require.resolve('./ground-contact-supervision.cjs')))
  .update(fs.readFileSync(require.resolve('./contact-persistence-calibration.json')))
  .update(fs.readFileSync(require.resolve('./contact-timing-forecast.cjs'))).digest('hex')
function risingInterruptWindow(request){
  const s=request.self,t=request.seen,o=request.publicActionContext,vy=o?.targetVelocity?.y
  if(!s?.ground||!t?.visible||!o?.sentPosition||![0,7].includes(s.held)
      ||s.shieldAvailable===true||o.shieldReady===true||s.charge<=.9||!Number.isFinite(s.charge)
      ||s.attackAgeTicks<4||t.shield||t.shieldRaised||!(vy>.08))return false
  // A sampled late ascent is not a guarantee the opponent is still rising
  // when our packet arrives. Preserve avoidance of an imminent descent.
  if(o.airEnvelope?.valid&&o.airEnvelope.criticalTick>=0&&o.airEnvelope.criticalTick<=1)return false
  const target={position:t,width:.6,height:1.8},height=s.eyeY-s.y
  return eyeReach(s,height,target)<=3&&eyeReach(o.sentPosition,height,target)<=3
}
function criticalExpert(request,history={}){
  const s=request.self,t=request.seen,tick=request.tick,o=request.publicActionContext
  if(!s||!t?.visible||!o?.sentPosition)return {labels:{},reason:'missing-public-execution-state'}
  const horizontal=Math.hypot(t.x-s.x,t.z-s.z)
  const arrival=contactArrival(request)
  const distantArrival=arrival.valid&&Number.isFinite(arrival.ticks)&&arrival.ticks>20
  const previous=history.publicTarget,elapsed=previous?Math.max(1,tick-previous.tick):1
  const timedPrevious=previous&&tick>previous.tick
  const observedVelocity=o.targetVelocity||{x:timedPrevious?(t.x-previous.x)/elapsed:0,
    y:timedPrevious?(t.y-previous.y)/elapsed:0,z:timedPrevious?(t.z-previous.z)/elapsed:0}
  const velocity={x:observedVelocity.x||0,y:observedVelocity.y||0,z:observedVelocity.z||0}
  const targetAirborne=o.targetAirborne===true||Math.abs(velocity.y)>.04||t.y>(request.publicTerrain?.groundY??s.y)+.2
  const closing=horizontal>.01?((s.vx||0)-velocity.x)*(t.x-s.x)/horizontal
    +((s.vz||0)-velocity.z)*(t.z-s.z)/horizontal:0
  const opponentClosing=horizontal>.01?-(velocity.x*(t.x-s.x)+velocity.z*(t.z-s.z))/horizontal:0
  history.approachFrames=opponentClosing>.04?(history.approachFrames||0)+1:0
  const walls=request.publicTerrain?.walls||[8,8,8,8]
  const away={x:horizontal>.01?(s.x-t.x)/horizontal:0,z:horizontal>.01?(s.z-t.z)/horizontal:0}
  // These are public cardinal wall probes, not hidden map geometry. A wall
  // beside us is not necessarily on the escape path.
  const escapeClearance=Math.min(...[
    Math.abs(away.x)>.01?walls[away.x<0?0:1]/Math.abs(away.x):Infinity,
    Math.abs(away.z)>.01?walls[away.z<0?2:3]/Math.abs(away.z):Infinity])
  // New pilot recordings contain body-sized routes. Older traces keep the
  // same cardinal geometry through contactGeometry's legacy fallback.
  const escapeBlocked=contactGeometry(request).away<.9
  const raised=Boolean(t.shield||t.shieldRaised)
  if(raised&&!history.targetWasRaised)history.targetRaisedSince=tick
  history.targetWasRaised=raised
  const warmupHitSpent=(history.lastWarmupSwordAttackTick??-1000)>=(history.targetRaisedSince??tick)
  const sinceShieldAttempt=tick-(history.lastShieldAxeTick??-1000)
  const recentShieldAttempt=sinceShieldAttempt>=0&&sinceShieldAttempt<=24
  // A disappearing public shield permits follow-up; it is not proof of a
  // hidden cooldown. No future receipt or opponent internal state is read.
  const swordFollowup=recentShieldAttempt&&!t.shield
    &&(history.lastSwordAttackTick??-1000)<history.lastShieldAxeTick
  history.publicTarget={x:t.x,y:t.y,z:t.z,tick}
  const target={position:{x:t.x,y:t.y,z:t.z},height:1.8,width:.6}
  const held=s.held===7?'axe':'sword'
  const plan=edgePlan({position:s,sentPosition:o.sentPosition,eyeHeight:s.eyeY-s.y,
    target,tick,lastAttack:tick-s.attackAgeTicks,lastWeaponTick:tick-s.weaponAgeTicks,weapon:held})
  // Entry and continuation are different decisions. Once a real close
  // exchange begins, a small knockback/receding movement does not turn sword
  // pressure back into axe retreat. Leave only after actual contact is lost.
  if(plan.reach>3&&plan.wireReach>3)history.closeExchangeActive=false
  if(horizontal<2.05)history.closeExchangeActive=true
  const reachable=plan.reach<=3&&plan.wireReach<=3
  const recentSword=tick-(history.lastSwordAttackTick??-1000)<=30
  // A recent sword packet at the edge is not a close combo. Do not use it
  // as permission to chase a shield or throw away the existing cooldown.
  const activeCloseChain=reachable&&recentSword&&(horizontal<2.65||history.closeExchangeActive===true)
  const shieldCombo=reachable&&(activeCloseChain||recentShieldAttempt)&&horizontal<2.65
    &&Math.max(plan.reach,plan.wireReach)+Math.max(0,-closing)*3<2.6
  // Continuation may survive a small separation on landing; it is not a new
  // distant jump. Reject retreating targets whose next descent leaves reach.
  const chainContact=activeCloseChain&&s.held===0&&horizontal<2.65&&closing>.06
    &&Math.max(plan.reach,plan.wireReach)+Math.max(0,-closing)*7<2.75
  const recentAxeStrike=tick-(history.lastAxeStrikeTick??-1000)<=24
  const axeRecovery=distantArrival&&s.held===7&&(s.charge??plan.charge)<=.9
    &&tick-(history.lastAxeStrikeTick??-1000)<=24
    &&history.lastAxeStrikeTick!==history.lastShieldAxeTick
  // A wall remains an obstacle after the cooldown is full or the old strike
  // ages out. Do not let either timer send a cornered player back into it.
  const sustainableContact=sustainableCloseContact(request,plan.reach,plan.wireReach)
  const rushedLowAxe=s.held===7&&(s.charge??plan.charge)<.45&&sustainableContact
    &&history.approachFrames>=2&&!raised
  const forcedCloseExchange=s.held===7&&escapeBlocked&&sustainableContact&&(s.charge??plan.charge)<.9||rushedLowAxe
  // Prior sword contact can preserve an airborne finish, but cannot justify
  // another jump after separation grows. A wall alone is not close combat.
  const near=sustainableContact||chainContact||!s.ground&&reachable&&(history.closeExchangeActive||activeCloseChain)
  // The native self observation includes cooldown lost to weapon switches.
  // A fixed local attack age alone can label a weak swing as ready.
  const charge=Number.isFinite(s.charge)?s.charge:plan.charge
  // The public forecast already includes the rising/apex-to-descent window.
  // Waiting for sampled vy < -.08 misses early descent and delayed packets.
  // This remains offline supervision, never an actor/executor override.
  const forecast=o.airEnvelope,criticalSoon=Boolean(o.targetCriticalThreat&&targetAirborne&&(
    o.targetCriticalPossible||velocity.y<-.08||forecast?.valid&&forecast.criticalTick>=0&&forecast.criticalTick<=6))
  const recentLowAxe=recentAxeStrike&&charge<.45&&o.targetCriticalThreat&&targetAirborne
  // Ground escape and an already-airborne sword finish are different tasks.
  // Do not erase a legal finish by turning away in the middle of that jump.
  const risingInterrupt=risingInterruptWindow(request)
  const g=contactGeometry(request)
  const criticalTicks=forecast?.valid&&forecast.criticalTick>=0?forecast.criticalTick:
    velocity.y<-.08?0:4
  // A retreat label must have room and time to clear the predicted contact.
  // A blocked one-tick escape is not a reason to stand on an uncharged axe.
  const retreatTicks=Math.min(6,Math.max(0,criticalTicks))
  const availableRetreat=Math.min(g.away,retreatTicks*.22)
  const closingTravel=Math.max(0,opponentClosing)*retreatTicks
  const canClearForecast=Math.max(plan.reach,plan.wireReach)+availableRetreat-closingTravel>3.12
  const unavoidableEntry=s.ground===true&&criticalSoon&&!risingInterrupt&&!raised
    &&!canClearForecast&&reachable&&(horizontal<2.65
      ||opponentClosing>.08&&Math.max(plan.reach,plan.wireReach)-closingTravel<2.55
      ||escapeBlocked&&Math.max(g.left,g.right)<.9)
  const evadeForecast=!risingInterrupt&&s.ground===true&&!sustainableContact
    &&(criticalSoon||recentLowAxe)&&!unavoidableEntry
  const closePlay=near||unavoidableEntry
  // Keep a usable sword through landing/contact. Prepare an axe only when
  // the public gap leaves time for its longer recovery, not at 3.4 blocks.
  const safeAxePreparation=distantArrival&&!criticalSoon&&!raised
  // A prepared axe already in hand may spend a ready legal hit; the one-second
  // restriction applies to initiating a new switch, not wasting that window.
  const axeFirstContact=s.held===7&&(!recentAxeStrike||charge>.9)
  let attack=false,jump=false,forward=plan.forward,sprint=plan.sprint,
    weapon=closePlay?1:safeAxePreparation||axeFirstContact&&charge>.9?0:1,reason='ground-edge-preparation'
  // Native sprint knockback and criticals require charge STRICTLY > .9.
  // Preserve an occasional ordinary emergency intercept after meaningful
  // recovery, but never call a four-tick axe click a sprint knockback hit.
  const urgentInterrupt=axeFirstContact&&reachable&&!raised&&!forcedCloseExchange
    &&(opponentClosing>.06||o.targetSwingRecent===true||charge>.9&&axeRecovery&&!near)
    &&charge>=.6&&s.attackAgeTicks>=10
    &&!(o.targetCriticalThreat&&velocity.y<-.08)
  if(risingInterrupt){
    attack=true;forward=horizontal>.9?1:0;sprint=forward>0;weapon=s.held===7?0:1
    reason='reachable-opponent-ascent-interrupt'
  }else if(evadeForecast){
    attack=false;jump=false;forward=escapeBlocked?0:-1;sprint=false
    weapon=s.held===7?0:1;reason='avoid-forecast-retaliation-critical'
  }else if(urgentInterrupt){
    attack=true;forward=1;sprint=charge>.9;weapon=0
    reason=charge>.9?'charged-legal-rush-interrupt':'ordinary-emergency-interrupt-after-recovery'
  }else if(axeRecovery&&!near){
    // A committed spacing hit is followed by continuous withdrawal until
    // charge recovers. No alternating hold/approach merely because knockback
    // briefly takes the opponent out of range. A blocked exit is handled by
    // the close-sword branch, rather than forbidding sword combat near walls.
    const clearGap=horizontal>4.3&&opponentClosing<.12
    attack=false;forward=escapeBlocked||clearGap?0:-1;sprint=false;weapon=0
    reason=escapeBlocked?'axe-recovery-blocked-wait-for-contact':clearGap?
      'axe-spacing-hold-clear-until-ready':'axe-spacing-committed-recovery'
  }else if(raised&&targetAirborne&&!shieldCombo&&!forcedCloseExchange){
    attack=false;forward=horizontal<4.1?-1:0;sprint=false
    weapon=s.held===7?0:1;reason='avoid-airborne-shield-release-critical'
  }else if(raised&&!shieldCombo){
    // A raised shield at the spacing boundary offers no useful free hit.
    // Keep a charged axe ready, move locally, and wait for a public release.
    attack=false;weapon=axeFirstContact&&charge>.9?0:1
    forward=horizontal<2.5?-1:0;sprint=false
    reason='spacing-wait-for-shield-release'
  }else if(raised&&shieldCombo&&!t.shield&&reachable&&s.held===0&&charge>0&&s.attackAgeTicks>=1&&!warmupHitSpent){
    // During the public shield warm-up a real sword hit may still land.
    // Spend that existing combo window before the axe; once effective,
    // the following branch must not pretend sword damage penetrates it.
    weapon=1;attack=true;forward=horizontal>.9?1:0;sprint=forward>0&&!s.wireFalling&&charge>.9
    reason='sword-damage-before-public-shield-effective'
  }else if(raised&&shieldCombo&&!t.shield){
    weapon=1;attack=false;forward=horizontal>.9?1:0;sprint=forward>0
    reason='shield-warmup-hit-spent-keep-contact'
  }else if(t.shield){
    forward=horizontal>.9?1:0;sprint=forward>0
    const sinceAttempt=tick-(history.lastShieldAxeTick??-1000)
    if(sinceAttempt>0&&sinceAttempt<5){
      // Do not call an attempted break confirmed while the shield is still
      // publicly effective. Keep pressure; avoid switch-back/reset loops.
      weapon=0;attack=false;reason='post-shield-attempt-await-public-shield-state'
    }else{
      weapon=0;attack=reachable
      reason='public-shield-axe-then-sword'
    }
  }else if(closePlay){
    attack=s.held===0&&!s.ground&&s.wireFalling===true&&plan.reach<=3&&plan.wireReach<=3
      &&charge>.9
    // A sword is not an axe with a mandatory jump-wait phase. Bank an
    // already useful hit before starting a long ascent; the whole jump then
    // recharges the next strike. A near-apex descent or an incoming critical
    // remains a reason to wait briefly, not to trade an ordinary hit blindly.
    const earlySword=s.held===0&&reachable&&charge>=.85&&s.attackAgeTicks>=10
      &&(s.ground===true||s.vy>.2)&&!criticalSoon
    if(earlySword)attack=true
    const endingDescent=s.y-(request.publicTerrain?.groundY??s.y)<=.6
    if(swordFollowup&&s.held===0&&!s.ground&&s.wireFalling===true
        &&charge>=.35&&charge<=.9&&endingDescent&&plan.reach<=3&&plan.wireReach<=3){
      // A once-only ordinary sword hit can salvage the first descent after
      // an axe switch. It is explicitly NOT a critical demonstration. Later
      // jumps return to the normal charged sword-critical lesson.
      attack=true
    }
    // Grounded close-combat jump opportunities have no scripted rest timer.
    // Distant entry above remains the grounded spacing lesson.
    // Prime the sword before the first takeoff, then allow repeated jumps.
    // Switching and jumping together can spend the entire descent charging.
    const continuing=chainContact||activeCloseChain&&sustainableContact
    const jumpReady=charge>=(continuing?.2:.4)
    jump=s.ground===true&&s.held===0&&jumpReady&&(sustainableContact||chainContact)
    if(request.jumpInputVersion===2&&!s.ground&&s.held===0&&(sustainableContact||chainContact))
      jump=true // hold a key, not a synthetic midair jump or velocity change
    forward=horizontal>.9?1:0;sprint=forward>0&&!attack
    reason=earlySword?'close-sword-early-useful-damage':rushedLowAxe?'persistent-rush-low-axe-close-sword':forcedCloseExchange?'blocked-escape-close-sword-continuation':
      attack&&charge<=.9?'post-shield-sword-ordinary-before-window-closes':'close-sword-critical-continuation'
  }else{
    // Teach actual contacted states after knockback too. Rising body position
    // is not a reason to wait through a charged, legal ground-control strike.
    attack=plan.reach<=3&&plan.wireReach<=3&&charge>.9
    if(o.targetCriticalThreat&&velocity.y<-.08){
      attack=false;forward=-1;sprint=false;reason='avoid-imminent-unfavourable-critical-trade'
    }else reason=attack?'charged-legal-edge-interrupt':'ground-edge-preparation'
    if(attack){weapon=axeFirstContact?0:1;forward=1;sprint=true}
    if(attack&&s.held===7&&tick-(history.lastAxeStrikeTick??-1000)<=40){
      // Once recovery is complete, commit the next legal axe strike instead
      // of teaching another retreat simply because contact is a little deep.
      forward=1;sprint=true
    }
    if(!attack&&s.held===7&&charge<.9&&safeAxePreparation){
      // Complete the exchange: leave retaliation range while charging, hold
      // once clear, and only then approach for another high-damage opener.
      // The earlier close-combat branch can still continue with the sword.
      forward=horizontal<4.3?-1:0;sprint=false;weapon=0
      reason=forward<0?'axe-spacing-recover-charge':'axe-spacing-hold-clear-until-ready'
    }
  }
  if(s.held===0&&!raised&&reachable&&recentSword&&closing<-.08
      &&Math.max(plan.reach,plan.wireReach)+Math.max(0,-closing)*2>3
      &&charge>=.35&&s.attackAgeTicks>=4&&(!evadeForecast||s.wireFalling&&charge>.9)){
    // A legal last contact can be preferable to losing the whole opportunity.
    // This may be ordinary damage; do not relabel it as a critical.
    attack=true;weapon=1;forward=1;sprint=!s.wireFalling&&charge>.9
    reason='sword-last-legal-contact-before-separation'
  }
  let movementAction=null
  if(s.ground&&!closePlay&&!raised&&!evadeForecast&&(!axeRecovery||attack)
      &&!(o.targetCriticalThreat&&velocity.y<-.08)){
    const control=groundControlMovement(request,plan,history,attack,charge)
    movementAction=control.action;forward=control.forward;sprint=control.sprint;jump=false
    if(attack&&charge<=.9)sprint=false
    reason=risingInterrupt?'reachable-opponent-ascent-interrupt':urgentInterrupt?
      charge>.9?'charged-legal-rush-interrupt':'ordinary-emergency-interrupt-after-recovery':
      attack?'ground-control-legal-interrupt':'ground-control-lateral-spacing'
  }
  if(s.ground&&axeRecovery&&!near&&!attack&&escapeBlocked&&!evadeForecast){
    const g=contactGeometry(request)
    movementAction=Math.max(g.left,g.right)<.9?0:g.left>=g.right?3:4
    forward=0;sprint=false;reason='axe-recovery-blocked-lateral-exit'
  }
  if(evadeForecast&&escapeBlocked&&!attack){
    // Do not teach withdrawal into a wall. Use a publicly open tangent;
    // if none is visible, hold facing rather than inventing a safe escape.
    const g=contactGeometry(request)
    movementAction=Math.max(g.left,g.right)<.9?0:g.left>=g.right?3:4
    forward=0;sprint=false;reason+='-lateral-exit'
  }
  // Offline teaching never asks for movement into a publicly blocked escape.
  // A reachable unshielded opponent above already selects close sword play;
  // otherwise retain the current position until a useful route/contact exists.
  if(forward<0&&escapeBlocked){forward=0;sprint=false;reason+='-escape-blocked'}
  if(forward>0&&g.toward<.6){
    forward=0;sprint=false
    movementAction=g.left>=.6?3:g.right>=.6?4:0
    reason+='-forward-blocked'
  }
  if(swordFollowup&&!raised&&s.held===7){
    weapon=1;attack=false;reason='public-shield-clear-restore-sword'
  }
  // Weapon selection consumes charge; never label an immediate melee hit
  // on the frame switching to a different weapon against an unshielded player.
  if(!t.shield&&(weapon===1&&s.held!==0||weapon===0&&s.held!==7))attack=false
  if(attack&&!t.shield&&s.wireFalling)sprint=false
  const labels={0:movementAction??(forward>0?1:forward<0?2:0),1:Number(sprint),3:0,4:attack?2:0,5:weapon,6:6,7:3,8:0}
  if(s.ground||request.jumpInputVersion===2)labels[2]=Number(jump)
  const actions=Array(9).fill(0);for(const[h,a]of Object.entries(labels))actions[h]=a
  return {labels,actions,reason,sourceSha256,counterfactual:true,ppoEligible:false,
    contactForecast:{valid:arrival.valid,ticks:Number.isFinite(arrival.ticks)?arrival.ticks:null,
      axePreparationPermitted:safeAxePreparation},
    teacherScope:'public-ground-edge-close-critical-and-shield-transition'}
}
function observeLearnerInput(history,request,executed){
  if(request.self?.ground&&executed?.jump)history.lastGroundJumpTick=request.tick
  if(executed?.attackPacket&&executed.held===7)history.lastAxeStrikeTick=request.tick
  if(executed?.attackPacket&&executed.held===7&&request.seen?.shield)history.lastShieldAxeTick=request.tick
  if(executed?.attackPacket&&executed.held===0)history.lastSwordAttackTick=request.tick
  if(executed?.attackPacket&&executed.held===0&&request.seen?.shieldRaised&&!request.seen?.shield)
    history.lastWarmupSwordAttackTick=request.tick
}
module.exports={criticalExpert,observeLearnerInput,sourceSha256,risingInterruptWindow}
