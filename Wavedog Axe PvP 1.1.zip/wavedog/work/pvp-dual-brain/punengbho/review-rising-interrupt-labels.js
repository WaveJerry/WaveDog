// Semantic review of offline expert labels, not an online melee rule. Apply
// the same public-state criterion to train/validation without moving bouts.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {createRequire} from 'node:module'
import {validateDataset} from '../human-imitation.js'
const require=createRequire(import.meta.url)
const {criticalExpert,risingInterruptWindow,sourceSha256}=require('./joint-melee-expert.cjs')
const [input,destination]=process.argv.slice(2)
if(!input||!destination||fs.existsSync(destination))throw Error('Input and new destination required')
const bytes=fs.readFileSync(input),data=JSON.parse(bytes),changes=[]
for(const trace of data.trajectories){
  // Human action demonstrations are evidence; this review corrects only
  // counterfactual expert advice on recorded learner states.
  if(trace.sourceKind!=='dagger-expert-relabel')continue
  for(const frame of trace.frames){
    if(frame.labels[4]===undefined||!risingInterruptWindow(frame.publicRequest||{}))continue
    const expert=criticalExpert(frame.publicRequest),before={...frame.labels},oldActions=[...frame.actions]
    const next={...frame.labels}
    for(const h of [0,1,2,4,5,6,7]){
      if(expert.labels[h]!==undefined&&frame.legalMasks[h][expert.labels[h]]!==false)next[h]=expert.labels[h]
    }
    if(JSON.stringify(next)===JSON.stringify(before))continue
    for(const [h,value]of Object.entries(next))frame.actions[h]=value
    frame.labels=next
    frame.previousExpertReason=frame.expertReason
    frame.expertReason='reachable-opponent-ascent-interrupt'
    frame.labelEvidence=[...(frame.labelEvidence||[]),'public-legal-opponent-ascent-review']
    changes.push({source:trace.source,tick:frame.tick,split:trace.split,before,after:next,
      previousReason:frame.previousExpertReason,beforeActions:oldActions,afterActions:frame.actions})
  }
}
validateDataset(data)
fs.mkdirSync(destination,{recursive:true})
fs.writeFileSync(path.join(destination,'dataset.json'),JSON.stringify(data))
fs.writeFileSync(path.join(destination,'review.json'),JSON.stringify({
  source:path.resolve(input),sourceSha256:crypto.createHash('sha256').update(bytes).digest('hex'),
  expertSourceSha256:sourceSha256,changes,wholeBoutSplitsUnchanged:true,observationInputsUnchanged:true,
  nativeHumanDemonstrationsUnchanged:true,criterionUsesNoModelPredictions:true,
  validationLabelsReviewed:true,validationUsedForGradients:false,ppoEligible:false,
  reason:'Separate opponent reachable ascent interrupt from own sword ascent and opponent imminent descent'
},null,2))
console.log(JSON.stringify({changed:changes.length,train:changes.filter(c=>c.split==='train').length,
  validation:changes.filter(c=>c.split==='validation').length}))
