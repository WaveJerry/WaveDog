import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {criticalExpert,observeLearnerInput,sourceSha256}from './critical-expert.cjs'
const dir=path.resolve('outputs/punengbho-rebuild-20261117/demonstrations'),audit=[]
for(const file of fs.readdirSync(dir).filter(f=>f.endsWith('-critical.jsonl'))){
  const rows=fs.readFileSync(path.join(dir,file),'utf8').trim().split('\n').map(JSON.parse)
  if(rows[0].schema!=='exact-protocol-demonstration-v2')continue
  const history={},result={source:file,frames:0,actualAttackPackets:0,attackLabelMismatches:0,
    groundedJumpLabelMismatches:0,sprintOnAttackMismatches:0}
  for(const row of rows.filter(r=>r.type==='frame')){
    const advice=criticalExpert(row.publicRequest,history)
    result.frames++;result.actualAttackPackets+=Number(row.attackPacket)
    result.attackLabelMismatches+=Number((advice.labels[4]===2)!==row.attackPacket)
    if(row.publicRequest.self.ground)
      result.groundedJumpLabelMismatches+=Number(Boolean(advice.labels[2])!==row.executed.jump)
    if(row.attackPacket)result.sprintOnAttackMismatches+=Number(Boolean(advice.labels[1])!==row.executed.sprint)
    observeLearnerInput(history,row.publicRequest,row.executed)
  }
  assert.equal(result.attackLabelMismatches,0,'offline attack oracle must match the verified live teacher')
  assert.equal(result.groundedJumpLabelMismatches,0)
  assert.equal(result.sprintOnAttackMismatches,0)
  audit.push(result)
}
assert(audit.length>=3)
const receipt={expertSourceSha256:sourceSha256,audit,teacherScope:'unshielded-sword-critical',
  onlineControllerModified:false,generalTacticalExpert:false}
fs.writeFileSync(path.join(dir,'expert-agreement.json'),JSON.stringify(receipt,null,2))
console.log(JSON.stringify(receipt))
