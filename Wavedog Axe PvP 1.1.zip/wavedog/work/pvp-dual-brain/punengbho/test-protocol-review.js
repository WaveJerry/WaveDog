import assert from 'node:assert/strict'
import {reviewProtocolFrames} from './protocol-review.js'
const visited=[],records=[];let chunks=0
const original=globalThis.fetch
globalThis.fetch=async(_url,options)=>{
  const request=JSON.parse(options.body),payload=JSON.parse(request.messages.at(-1).content)
  if(payload.frames){
    chunks++
    assert(JSON.stringify(payload.frames).length<12500)
    for(const tuple of payload.frames){
      visited.push(tuple[0]);assert.deepEqual(tuple[23].walls,[2,3,4,5])
      assert.equal(tuple[24].controls.forward,true)
      assert.equal(tuple[24].owners.movement,'neural')
      assert.equal(tuple[24].rangedResult.bowReleased,true)
    }
  }
  return {ok:true,json:async()=>({choices:[{finish_reason:'stop',message:{content:JSON.stringify({focus:'FREE',lesson:'检查实际执行与公开地形。'})}}]})}
}
try{
  const frames=Array.from({length:200},(_,tick)=>({tick,mode:'NEURAL',self:{x:0,y:0,z:0,health:20,charge:1,ground:true},
    seen:{visible:true,x:2,y:0,z:0,arrows:[]},command:{forward:0,side:1,slot:7},
    actualPackets:['look'],publicTerrain:{walls:[2,3,4,5]},
    executed:{forward:true},owners:{movement:'neural',attack:'neural'},rangedResult:{bowReleased:true}}))
  await reviewProtocolFrames({matchId:'test',frames},(type,row)=>records.push({type,...row}),[],[],null)
  assert.deepEqual(visited,frames.map(f=>f.tick),'every frame is visited exactly once in order')
  assert(chunks>3,'large execution context uses smaller bounded chunks')
  assert.equal(records.at(-1).coverage,1)
  console.log('PROTOCOL_REVIEW_ORDER_ENVIRONMENT_ACTUAL_EXECUTION_PASS')
}finally{globalThis.fetch=original}
