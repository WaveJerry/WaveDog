// Offline ablation only: never imported by actor or executor.
import fs from 'node:fs'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
import {recordResponseWindows}from './response-window-audit.js'
const [checkpoint,dataset,outFile]=process.argv.slice(2)
if(!outFile||fs.existsSync(outFile))throw Error('New diagnostic output required')
await tf.setBackend('cpu');await tf.ready()
const data=JSON.parse(fs.readFileSync(dataset)),loaded=loadDualCheckpoint(checkpoint),m=loaded.model
const scales=[0,.25,.5,.75,1],stats=Object.fromEntries(scales.map(s=>[s,{}]))
let count=0
try{
 for(const t of data.trajectories.filter(t=>t.split==='validation')){
  let state=m.initialState()
  try{for(const f of t.frames){
   const out=advance(m,state,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures);state=out.state
   const residual=tf.tidy(()=>m.spatialMovementResidual(m.projectPolicyInputs(tf.tensor2d([f.observation]),f.publicHealthFeatures,f.publicThreatFeatures),f.publicSpatialFeatures,f.publicThreatFeatures,out.state).map(h=>[...h.dataSync()]))
   for(const scale of scales){
    const logits=out.logits.map((v,h)=>{
     const i=m.spatialMovementHeads.indexOf(h)
     return v.map((x,j)=>i<0?x:x+(scale-1)*residual[i][j])
    })
    recordResponseWindows(stats[scale],f,captureAutonomousImitation(m,{logits},f).actions)
   }
   count++
  }}finally{disposeState(state)}
 }
 const result={checkpointSha256:loaded.manifest.sha256,count,stats,offlineAblationOnly:true}
 fs.writeFileSync(outFile,JSON.stringify(result,null,2));console.log(JSON.stringify(result))
}finally{loaded.adam.dispose();m.dispose()}
