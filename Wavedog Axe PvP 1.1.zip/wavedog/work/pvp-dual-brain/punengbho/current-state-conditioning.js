// Offline residual training only. Match the deployed autoregressive attack
// head after the policy, rather than the teacher, chooses its parent actions.
import * as tf from '@tensorflow/tfjs'
import assert from 'node:assert/strict'
import {OBS_SIZE, ACTION_WIDTHS} from '../fresh-policy.js'

export function conditionalAttackOffsets(model, rows, actions) {
  assert.equal(model.config.actionConditionedAttack, 1)
  assert.equal(model.config.distributionVersion, 2)
  const choices = actions.map(a => [
    ...[0, 1].map(i => Number(a[1] === i)),
    ...[0, 1].map(i => Number(a[2] === i)),
    ...[0, 1, 2, 3, 4].map(i => Number(a[5] === i))
  ])
  const input = tf.tensor2d(rows.map((r, i) => [...r.frame.observation, ...choices[i]]),
    [rows.length, OBS_SIZE + 9])
  return model.actionChoiceOut.apply(tf.tanh(model.actionChoiceIn.apply(input)))
}

export function autonomousCachedLogits(model, rows, teacherLogits) {
  // Discrete choices are detached, just as in the categorical live actor.
  // Supervised parent losses still train jump and weapon selection directly.
  const parents = Object.fromEntries([1, 2, 5].map(h =>
    [h, [...teacherLogits[h].argMax(1).dataSync()]]))
  const actions = rows.map((r, i) => {
    const a = [...r.frame.actions]
    for (const h of [1, 2, 5]) a[h] = parents[h][i]
    return a
  })
  const teacherOffset = tf.tensor2d(rows.map(r => r.teacherAttackOffset),
    [rows.length, ACTION_WIDTHS[4]])
  const ownOffset = conditionalAttackOffsets(model, rows, actions)
  return teacherLogits.map((head, h) => h === 4
    ? tf.add(tf.sub(head, teacherOffset), ownOffset) : head)
}
