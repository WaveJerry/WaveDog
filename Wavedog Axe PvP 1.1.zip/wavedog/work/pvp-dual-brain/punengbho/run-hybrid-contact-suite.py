"""Six reviewed pilot trials. Run only after the user's fresh explicit reply."""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import subprocess

ROOT = Path(__file__).resolve().parents[3]
LIVE = ROOT / 'work/wavedog-punengbho/runtime'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--sha', required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
command = runpy.run_path(str(ROOT / 'outputs/MC-Public/rcon_local.py'))['command']
cases = [
    ('edge-control', 3.2, ['--melee-only', '--teacher-weapon', 'axe'], '无盾入距及时接刀与地面控距'),
    ('critical', 3.4, ['--melee-only', '--rising-threat-probe'], '对方上升期打断与下落避让'),
    ('critical', 1.2, ['--melee-only'], '贴身切剑与真实连续暴击'),
    # Default combo-shield preparation strips only the learner shield/ranged
    # equipment, leaving the opponent shield for the learned switch test.
    ('combo-shield', 1.5, [], '无盾剑连遇盾切斧续剑'),
    ('bow', 8, ['--retain-learner-kit', '--bow-cancel-every', '3'], '连续同步弓与取消后的近战蓄力'),
    ('sync-check', 8, ['--retain-learner-kit'], '综合版同步射弩保留'),
]
report = {'authorizedAttempts': len(cases), 'attempted': 0, 'completed': 0,
          'trials': [], 'fullTacticalMastery': False, 'frozenEvaluation': True}

def save():
    (args.out / 'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

for index, (mode, distance, extra, label) in enumerate(cases):
    client = json.loads((LIVE / 'client-ready.json').read_text(encoding='utf-8'))
    if client.get('controlRegime') != 'pilot-mechanical-shield-neural-melee':
        raise RuntimeError('Expected pilot hybrid')
    for name, sha in client['sourceSha256'].items():
        if hashlib.sha256((ROOT / 'work/pvp-player-client' / name).read_bytes()).hexdigest() != sha:
            raise RuntimeError('Client sources changed during test')
    report['attempted'] += 1
    save()
    command('tellraw WaveJerry ' + json.dumps({
        'text': f'[Punengbho 验收 {index+1}/{len(cases)}] {label}；冻结权重，逐帧记录原生命中。',
        'color': 'aqua'}, ensure_ascii=True))
    log = args.out / f'{index+1}-{mode}.log'
    with log.open('w', encoding='utf-8') as stream:
        result = subprocess.run(['python', str(Path(__file__).with_name('run-main-trial.py')),
                                 '--mode', mode, '--start-distance', str(distance),
                                 '--seconds', '25', *extra], cwd=ROOT,
                                stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        report['failureLog'] = str(log)
        save()
        raise RuntimeError('Trial failed; no automatic retry')
    rows = [json.loads(line) for line in log.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    summary = next(row for row in rows if 'frameFile' in row)
    frames = [json.loads(line) for line in Path(summary['frameFile']).read_text(encoding='utf-8').splitlines()]
    if not frames or any(f.get('policySha') != args.sha for f in frames):
        raise RuntimeError('Empty or mixed policy evidence')
    if index < 4 and frames[0]['self'].get('shieldAvailable'):
        raise RuntimeError('Shieldless preparation failed; do not claim neural-only acceptance')
    summary['acceptancePurpose'] = label
    report['trials'].append(summary)
    report['completed'] += 1
    save()
    print(json.dumps({'completed': report['completed'], 'matchId': summary['matchId'], 'mode': mode}), flush=True)
