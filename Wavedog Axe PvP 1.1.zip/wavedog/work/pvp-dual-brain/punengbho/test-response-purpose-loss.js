import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS,DualPolicy}from '../fresh-policy.js'
import {responsePurposeLoss}from './response-purpose-loss.js'
await tf.setBackend('cpu');await tf.ready()
const heads=ACTION_WIDTHS.map(w=>tf.tidy(()=>tf.variable(tf.zeros([2,w]))))
const rows=[{frame:{labels:{4:0},actions:[2,0,0,0,0,0,6,3,0],publicRequest:{publicActionContext:{targetCriticalThreat:true,targetAirborne:true}}}},
 {frame:{labels:{4:2},actions:[1,0,0,0,2,1,6,3,0],expertReason:'sword-last-legal-contact-before-separation',publicRequest:{self:{wireFalling:true}}}}]
const {value,grads}=tf.variableGrads(()=>tf.tidy(()=>responsePurposeLoss(rows,heads,2)),heads)
assert(Number.isFinite(value.dataSync()[0]))
assert(grads[heads[4].name].arraySync()[0][0]<0,'learn wait during the avoidance window')
assert(grads[heads[4].name].arraySync()[1][2]<0,'learn attack before separation')
assert(grads[heads[5].name].arraySync()[1][1]<0,'retain sword for the final contact')
assert(grads[heads[1].name].arraySync()[1][0]<0,'release sprint for falling contact')
assert(grads[heads[0].name].arraySync()[0][2]<0,'learn outward movement with compatible view')
assert(grads[heads[6].name].dataSync().some(x=>x!==0),'view participates in the same loss')
value.dispose();Object.values(grads).forEach(t=>t.dispose());heads.forEach(t=>t.dispose())
const saturated=ACTION_WIDTHS.map(w=>tf.tidy(()=>tf.variable(tf.zeros([2,w]))))
tf.tidy(()=>saturated[4].assign(tf.tensor2d([[0,0,40,0,0],[40,0,0,0,0]])))
const severe=tf.variableGrads(()=>tf.tidy(()=>responsePurposeLoss(rows,saturated,2)),saturated)
assert(Number.isFinite(severe.value.dataSync()[0]))
assert(severe.grads[saturated[4].name].arraySync()[0][0]<-.1,'overconfident attack still learns to wait')
assert(severe.grads[saturated[4].name].arraySync()[1][2]<-.1,'overconfident wait still learns the final hit')
severe.value.dispose();Object.values(severe.grads).forEach(t=>t.dispose());saturated.forEach(t=>t.dispose())
const m=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,publicHealthInputs:5,publicThreatInputs:12})
tf.tidy(()=>{
 m.publicThreatProjection.assign(tf.fill([12,98],.012));m.publicHealthProjection.assign(tf.fill([5,98],.002))
 const x=tf.fill([1,98],.1),h=[1,.4,.3,0,0],t=[1,0,.1,.2,.1,1,1,.3,1,.5,.25,0]
 const old=tf.add(m.projectObservation(x,h),tf.matMul(tf.tensor2d([t]),m.publicThreatProjection))
 assert.deepEqual(m.projectPolicyInputs(x,h,t).dataSync(),old.dataSync(),'refactor keeps exact live projection')
})
m.dispose()
console.log('RESPONSE_PURPOSE_PASS: coordinated move/view/wait, lawful sword finish, exact forecast projection')
