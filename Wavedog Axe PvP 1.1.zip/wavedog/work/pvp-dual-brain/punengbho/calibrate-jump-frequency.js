// Fit one trainable jump intercept on TRAINING bouts only. Recover native
// jumps without turning class-balanced imitation into constant hopping.
import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation,accumulate,finishStats}from '../human-imitation.js'
const base=path.resolve('outputs/punengbho-integration-20261117')
const src=path.join(base,'timing/trained'),dest=path.join(base,'calibrated')
if(fs.existsSync(dest))throw Error('Preserve the prior calibration')
fs.mkdirSync(dest)
const data=JSON.parse(fs.readFileSync(path.join(base,'timing/whole-exchanges.json')))
const prior=JSON.parse(fs.readFileSync(path.join(src,'receipt.json')))
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(path.join(src,'checkpoint.json'))
const frames=[]
for(const trace of data.trajectories){
  let state=loaded.model.initialState()
  try{for(const frame of trace.frames){
    const raw=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures);state=raw.state
    const out=captureDeployedImitation(loaded.model,raw,frame)
    frames.push({frame,split:trace.split,out})
  }}finally{disposeState(state)}
}
const train=frames.filter(f=>f.split==='train'&&f.frame.labels['2']!==undefined)
const target=train.reduce((sum,f)=>sum+f.frame.labels['2'],0)/train.length
const logistic=x=>1/(1+Math.exp(-x))
const rate=delta=>train.reduce((sum,f)=>sum+logistic(f.out.logits[2][1]-f.out.logits[2][0]+delta),0)/train.length
let low=-20,high=20
for(let i=0;i<60;i++){const mid=(low+high)/2;if(rate(mid)>target)high=mid;else low=mid}
const delta=(low+high)/2
const fittedRate=rate(delta)
const stats={train:{labels:{},drift:{}},validation:{labels:{},drift:{}}}
for(const f of frames){f.out.logits[2][1]+=delta;accumulate(stats[f.split],f.frame,f.out)}
for(const value of Object.values(stats))finishStats(value)
// Every other distribution/state remains exactly unchanged by this intercept.
for(const split of ['train','validation'])stats[split].drift=prior.after[split].drift
const index=loaded.model.config.actionContextHeads.indexOf(2)
const layer=loaded.model.actionContextOut[index]
tf.tidy(()=>layer.b.assign(tf.add(layer.b,tf.tensor1d([0,delta]))))
const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),loaded.model,loaded.adam,loaded.counters)
const improved=stats.validation.macroNll<prior.before.validation.macroNll
  &&stats.validation.labels['4:2'].nll<prior.before.validation.labels['4:2'].nll
const receipt={...prior,saved,before:prior.before,after:stats,
  calibration:{kind:'train-only-binomial-intercept',trainFrames:train.length,target,actual:fittedRate,delta,
    validationLabelsUsedForFit:false,parameter:'action-context-head-2.b[1]'},
  checks:{...prior.checks,validationImproved:improved},offlineChecksPassed:prior.offlineChecksPassed&&improved,
  livePvpImprovementVerified:false,sourceCheckpointOverwritten:false}
fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
fs.mkdirSync(path.join(dest,'source'))
const origin=JSON.parse(fs.readFileSync(path.join(base,'refinement/source/checkpoint.json')))
for(const name of ['checkpoint.json',origin.binary])fs.copyFileSync(path.join(base,'refinement/source',name),path.join(dest,'source',name))
loaded.adam.dispose();loaded.model.dispose()
console.log(JSON.stringify({calibration:receipt.calibration,checks:receipt.checks,offlineChecksPassed:receipt.offlineChecksPassed,saved}))
