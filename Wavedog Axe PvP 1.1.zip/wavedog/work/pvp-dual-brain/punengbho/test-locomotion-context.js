import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
await tf.setBackend('cpu');await tf.ready()
const base={fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:2,actionContextHeads:[2,5,4],actionConditionedAttack:1}
const old=new DualPolicy(base),next=new DualPolicy({...base,actionContextHeads:[2,5,4,0,1]})
const name=p=>p.name.replace(/^dual\d+\./,''),prior=new Map(old.params.map(p=>[name(p),p]))
let inherited=0
for(const p of next.params)if(prior.has(name(p))){p.assign(prior.get(name(p)));inherited++}
assert.equal(inherited,old.params.length)
try{tf.tidy(()=>{
  const x=tf.tensor2d([Array.from({length:OBS_SIZE},(_,i)=>Math.sin(i)*.3)])
  const a=old.step(x,old.initialState()),b=next.step(x,next.initialState())
  for(let h=0;h<a.logits.length;h++)assert.deepEqual([...a.logits[h].dataSync()],[...b.logits[h].dataSync()])
  const selected=[...next.actionContextOut[3].params,...next.actionContextOut[4].params]
  const {value,grads}=tf.variableGrads(()=>{
    const c=next.step(x,next.initialState())
    return tf.neg(tf.add(tf.logSoftmax(c.logits[0]).slice([0,1],[1,1]).sum(),
      tf.logSoftmax(c.logits[1]).slice([0,1],[1,1]).sum()))
  },selected)
  assert(Number.isFinite(value.dataSync()[0]))
  for(const p of selected)assert([...grads[p.name].dataSync()].some(v=>Number.isFinite(v)&&Math.abs(v)>1e-8))
  next.actionContextOut[3].b.assign(tf.tensor1d([0,2,0,0,0,0,0,0,0]))
  const c=next.step(x,next.initialState())
  assert(c.logits[0].dataSync()[1]>b.logits[0].dataSync()[1]+1.9)
  for(const h of [2,4,5])assert.deepEqual([...c.logits[h].dataSync()],[...b.logits[h].dataSync()],
    'training a movement output cannot silently change jump/attack/weapon output')
})
console.log('LOCOMOTION_ZERO_EXTENSION_REAL_GRADIENT_AND_HEAD_ISOLATION_PASS')
}finally{old.dispose();next.dispose()}
