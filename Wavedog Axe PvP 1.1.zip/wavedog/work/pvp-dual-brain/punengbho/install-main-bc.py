"""Install a validated main-brain candidate at idle; keep the MC JVM running."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,runpy,shutil,socket,subprocess,time
ROOT=Path(__file__).resolve().parents[3]
LIVE=ROOT/'work/pvp-8.6-dual-fresh/model';RUNTIME=ROOT/'work/wavedog-protocol/runtime'
PS=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
p=argparse.ArgumentParser();p.add_argument('trained',type=Path);a=p.parse_args()
receipt=json.loads((a.trained/'receipt.json').read_text())
if not receipt['offlineChecksPassed']or not receipt['allBackbonesTrained']:raise RuntimeError('Candidate checks failed')
proposed=json.loads((a.trained/'checkpoint.json').read_text())
before=(LIVE/'checkpoint.json').read_bytes();current=json.loads(before)
source=json.loads(Path(receipt.get('referenceCheckpoint',receipt['source'])).read_text())
if receipt.get('referenceSha256',source['sha256'])!=source['sha256']:raise RuntimeError('Candidate lineage mismatch')
if current['sha256']!=source['sha256']:raise RuntimeError('Main brain learned since snapshot; rebase required')
strip=lambda c:{k:v for k,v in c.items()if k!='trainingStage'}
if strip(current['config'])!=strip(proposed['config']):raise RuntimeError('Main observation/action semantics changed')
if Path(proposed['binary']).name!=proposed['binary']:raise RuntimeError('Invalid checkpoint name')
payload=(a.trained/proposed['binary']).read_bytes()
if hashlib.sha256(payload).hexdigest()!=proposed['sha256']:raise RuntimeError('Candidate checksum mismatch')
def status():
    with socket.create_connection(('127.0.0.1',18766),timeout=4)as s:
        s.sendall(b'{"command":"model_status","requestId":"main-bc-install"}\n')
        for line in s.makefile():
            row=json.loads(line)
            if row.get('event')=='model_status':return row
def idle():
    row=status();plugin=command('wavedog status')
    if row['actors']or '对局=空闲'not in plugin or '汇总=false'not in plugin:
        raise RuntimeError('Main bout/learning active; leave it running')
    if row['checkpointSha256']!=current['sha256']:raise RuntimeError('Live policy changed')
idle()
latest=max(int(f.name.split('-')[1].split('.')[0])for f in(LIVE/'rollouts').glob('rollout-*.json.gz'))
if latest!=current['counters']['lastRolloutSeq']:raise RuntimeError('Uncommitted PPO journal')
query=('$owner=(Get-NetTCPConnection -LocalPort 18766 -State Listen).OwningProcess; '
       'Get-CimInstance Win32_Process -Filter "Name=\'node.exe\'" | Where-Object { '
       '$_.ProcessId -eq $owner -and $_.CommandLine -like "*pvp-dual-brain*dual-service.js*" '
       '-and $_.CommandLine -notlike "*punengbho*" } | Select-Object ProcessId | ConvertTo-Json -Compress')
raw=subprocess.check_output([PS,'-NoProfile','-Command',query],text=True,encoding='utf-8').strip()
if not raw:raise RuntimeError('Main service identity not proven')
process=json.loads(raw)
if not isinstance(process,dict):raise RuntimeError('Ambiguous service identity')
stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
backup=LIVE/'backups'/('before-joint-bc-'+stamp);backup.mkdir(parents=True)
for name in['checkpoint.json',current['binary']]:shutil.copy2(LIVE/name,backup/name)
# Pure mechanical tests advanced the durable cursor, but never the optimizer.
# Carry that metadata forward instead of replaying or dropping those bouts.
steps=receipt.get('imitationStepsSinceReference',receipt['best']['steps'])
proposed['counters']={**current['counters'],
    'humanImitationUpdates':current['counters'].get('humanImitationUpdates',0)+steps,
    'behaviorCloningSteps':current['counters'].get('behaviorCloningSteps',0)+steps,
    'lastImitationSessionSteps':steps}
idle()
if(LIVE/'checkpoint.json').read_bytes()!=before:raise RuntimeError('Checkpoint changed during preparation')
subprocess.run(['taskkill.exe','/PID',str(process['ProcessId']),'/T','/F'],capture_output=True,check=True)
def launch():
    with(RUNTIME/'model-service.out.log').open('ab')as out,(RUNTIME/'model-service.err.log').open('ab')as err:
        return subprocess.Popen([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/dual-service.js'),str(LIVE/'checkpoint.json')],
            cwd=ROOT/'work/pvp-dual-brain',stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
try:
    if(LIVE/'checkpoint.json').read_bytes()!=before:raise RuntimeError('Checkpoint changed during shutdown')
    (LIVE/proposed['binary']).write_bytes(payload)
    temp=LIVE/'checkpoint.installing.json';temp.write_text(json.dumps(proposed));os.replace(temp,LIVE/'checkpoint.json')
    child=launch()
    for _ in range(100):
        if child.poll()is not None:raise RuntimeError('New main service exited')
        try:
            loaded=status()
            if loaded.get('ready')and loaded['checkpointSha256']==proposed['sha256']:break
        except(OSError,TimeoutError):pass
        time.sleep(.5)
    else:raise RuntimeError('Main candidate readiness timeout')
    result={'installed':True,'pid':child.pid,'sha256':proposed['sha256'],'sourceSha256':current['sha256'],
        'backup':str(backup),'mainMinecraftRestarted':False,'independentBrainChanged':False,
        'ppoOptimizerPreserved':True,'journalCursorPreserved':True,'fullTacticalMasteryVerified':False}
    (a.trained/'main-install-receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
except Exception:
    if'child'in locals()and child.poll()is None:child.terminate();child.wait(timeout=10)
    (LIVE/'checkpoint.json').write_bytes(before);launch()
    raise
