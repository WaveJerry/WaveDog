"""Retain the repaired view/weapon model and calibrate actual entry/crit timing."""
from pathlib import Path
import gzip,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
DEST=BASE/'timing';DEST.mkdir(exist_ok=False)
data=json.loads((BASE/'refinement/whole-exchanges.json').read_text())
jumps_added=0
for trace in data['trajectories']:
    with gzip.open(Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts')/trace['source'],'rt',encoding='utf8')as stream:
        native=[json.loads(line)for line in stream]
    ground_jump_ticks=set();last_frame=None
    for row in native:
        if row['type']=='frame':last_frame=row
        if row['type']=='action-event'and row.get('event')=='jump'and last_frame and last_frame['self']['ground']:
            ground_jump_ticks.add(last_frame['tick'])
    for f in trace['frames']:
        f['labels']={h:a for h,a in f['labels'].items()if h in ['2','4']}
        if f['tick']in ground_jump_ticks and f['publicRequest']['self']['ground']:
            if f['labels'].get('2')!=1:jumps_added+=1
            f['labels']['2']=1
            f['labelEvidence'].append('ordered-native-jump-with-grounded-observation')
(DEST/'whole-exchanges.json').write_text(json.dumps(data))
env=os.environ.copy()
env.update(IMITATION_HEADS_ONLY='1',IMITATION_CONTEXT_ONLY='0',IMITATION_CONTEXT_HEADS='[2,4]',
    IMITATION_CALIBRATED_HEADS='[2,4,5]',IMITATION_DISTRIBUTION_VERSION='3',IMITATION_WEAPON_CONDITIONING='2',
    IMITATION_LR='0.0008',IMITATION_CONTEXT_RATE='1',IMITATION_EPOCHS='2',
    IMITATION_FREQUENCY_HEADS='[4]',IMITATION_EXCHANGE_BALANCE='1',
    IMITATION_HEAD_WEIGHTS='{"4":2}',IMITATION_ADAPTED_ANCHOR='0.05',IMITATION_ADAPTED_HEADS='[2,4]')
with (DEST/'training.log').open('wb')as log:
    subprocess.run([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/human-imitation.js'),
        str(BASE/'refinement/trained/checkpoint.json'),str(DEST/'whole-exchanges.json'),str(DEST/'trained')],
        cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
receipt=json.loads((DEST/'trained/receipt.json').read_text())
base=json.loads((BASE/'refinement/source/checkpoint.json').read_text())
(DEST/'source').mkdir();shutil.copy2(BASE/'refinement/source/checkpoint.json',DEST/'source/checkpoint.json')
shutil.copy2(BASE/'refinement/source'/base['binary'],DEST/'source'/base['binary'])
(DEST/'timing-receipt.json').write_text(json.dumps({'nativeJumpsAdded':jumps_added,'checks':receipt['checks'],
    'offlineChecksPassed':receipt['offlineChecksPassed'],'installed':False},indent=2))
print(json.dumps({'nativeJumpsAdded':jumps_added,'checks':receipt['checks'],'offlineChecksPassed':receipt['offlineChecksPassed']}))
