"""Frozen independent pilot acceptance in cage 3, with exact native evidence."""
from pathlib import Path
from importlib.machinery import SourceFileLoader
import argparse,json,subprocess,runpy

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--sha',required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
if a.out.exists():raise RuntimeError('Preserve prior suite evidence')
a.out.mkdir(parents=True)
foundation=SourceFileLoader('foundation_suite',str(HERE/'audit-foundation-trial.py')).load_module()
spacing=SourceFileLoader('spacing_suite',str(HERE/'audit-spacing-continuation.py')).load_module()
status=SourceFileLoader('status_suite',str(HERE/'integration-status.py')).load_module()
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
def announce(message):
    command('tellraw WaveJerry '+json.dumps({'text':'[第三竞技场 · Punengbho 模型验收] '+message,
        'color':'aqua'},ensure_ascii=True))
cases=[('edge-control',4.5,True),('critical',1.5,True),('combo-shield',1.2,True),
       ('edge-control',4,True),('critical',1.2,False),('combo-shield',1.5,True)]
results=[]
for index,(mode,distance,kit)in enumerate(cases):
    current=status.status(18776)
    if current['checkpointSha256']!=a.sha or current['config']['trainingStage']!='behavior-cloning':
        raise RuntimeError('Frozen policy changed; do not mix versions in acceptance')
    title={'edge-control':'斧头首刀控距','critical':'近身剑连续暴击','combo-shield':'遇盾切斧后续剑'}[mode]
    announce(f'{index+1}/{len(cases)}：{title}；权重 {a.sha[:8]}，实战检验中。')
    log=a.out/f'{index+1}-{mode}.log'
    cmd=['python',str(HERE/'run-main-trial.py'),'--mode',mode,'--fighter','Punengbho',
        '--start-distance',str(distance),'--seconds','25',
        '--retain-learner-kit'if kit else '--melee-only']
    if mode=='edge-control':cmd+=['--teacher-weapon','axe']
    with log.open('w',encoding='utf8')as stream:
        subprocess.run(cmd,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
    records=[json.loads(line)for line in log.read_text().splitlines()if line.startswith('{')]
    summary=next(r for r in records if 'frameFile'in r)
    frames=[json.loads(line)for line in Path(summary['frameFile']).read_text().splitlines()]
    if any(f.get('policySha')!=a.sha for f in frames):raise RuntimeError('Frame policy mismatch')
    base=(foundation.audit_carried_kit if kit else foundation.audit)(summary,frames)
    axe=spacing.axe_spacing_contract(summary,frames)if mode=='edge-control'else None
    result={'matchId':summary['matchId'],'mode':mode,'carriedKit':kit,'summary':summary,
        'foundation':base,'axeSpacing':axe,'diagnostics':spacing.audit(frames,'Punengbho'),
        'passed':base['passed']and(axe is None or axe['passed'])}
    results.append(result)
    announce(title+('通过本场门槛。'if result['passed']else'本场尚未通过，记录保留。')+
        (f" 斧头首刀={axe['checks']['firstNativeMeleeHitUsesAxe']}"if axe else
         f" 剑暴击={base['nativeSwordCriticals']}，最长连续={base['longestNativeSwordCriticalChain']}。"))
    (a.out/'report.json').write_text(json.dumps({'checkpointSha256':a.sha,'trials':results,
        'complete':len(results)==len(cases),'allBasicContractsPassed':len(results)==len(cases)and all(r['passed']for r in results),
        'fullTacticalMastery':False,'mainWaveDogPromoted':False},indent=2))
    print(json.dumps({'matchId':summary['matchId'],'mode':mode,'passed':result['passed'],
        'nativeSwordCriticals':base['nativeSwordCriticals'],'longestChain':base['longestNativeSwordCriticalChain'],
        'axeSpacingChecks':axe['checks']if axe else None}),flush=True)
if status.status(18776)['checkpointSha256']!=a.sha:raise RuntimeError('Policy changed during frozen suite')
