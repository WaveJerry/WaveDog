// Offline uniform neural trust step; no action/state-dependent override.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
const [trainedFile,dest,amount='0.5']=process.argv.slice(2),alpha=Number(amount)
const coarseYaw=process.argv.includes('--coarse-yaw-only')
assert(trainedFile&&dest&&!fs.existsSync(dest)&&alpha>0&&alpha<=1)
const parentFile=path.join(path.dirname(trainedFile),'receipt.json'),parent=JSON.parse(fs.readFileSync(parentFile))
assert(parent.spatialTemporalOnly&&parent.allBackbonesTrained&&parent.frozenBackbonesUnchanged)
await tf.setBackend('cpu');await tf.ready()
const trained=loadDualCheckpoint(trainedFile),source=loadDualCheckpoint(parent.source)
try{
 assert(trained.model.spatialTemporalIn&&source.model.spatialTemporalIn)
 assert.equal(trained.model.params.length,source.model.params.length)
 for(let i=0;i<source.model.params.length;i++)if(!source.model.params[i].name.includes('.spatial-movement-temporal-'))
  assert.deepEqual(source.model.params[i].dataSync(),trained.model.params[i].dataSync(),'Only new learned fusion may differ')
 tf.tidy(()=>{for(const layer of trained.model.spatialTemporalOut){layer.w.assign(tf.mul(layer.w,alpha));layer.b.assign(tf.mul(layer.b,alpha))}})
 if(coarseYaw)tf.tidy(()=>{
  const layer=trained.model.spatialTemporalOut[trained.model.spatialTemporalHeads.indexOf(6)]
  const mask=tf.tensor1d(Array.from({length:13},(_,i)=>Number(i===0||i===12)))
  layer.w.assign(tf.mul(layer.w,mask));layer.b.assign(tf.mul(layer.b,mask))
 })
 fs.mkdirSync(dest,{recursive:true})
 const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),trained.model,trained.adam,trained.counters)
 const receipt={schema:'uniform-calibrated-temporal-bc-v1',source:parent.source,sourceSha256:source.manifest.sha256,
  trainingCheckpoint:path.resolve(trainedFile),trainingCheckpointSha256:trained.manifest.sha256,
  trainingReceipt:path.resolve(parentFile),referenceCheckpoint:parent.referenceCheckpoint,referenceSha256:parent.referenceSha256,
  dataset:parent.dataset,datasetSha256:parent.datasetSha256,causalThreatFeaturesUsed:true,causalTemporalFeaturesUsed:true,
  spatialOnly:true,spatialTemporalOnly:true,trainedOutputHeads:parent.trainedOutputHeads,frozenBackbonesUnchanged:true,
  allBackbonesTrained:true,allBackbonesTrainedInThisStage:false,
  imitationStepsSinceReference:parent.imitationStepsSinceReference,optimizationStepsHere:0,
  alpha,coarseYaw,noOnlineCombatRuleAdded:true,offlineChecksPassed:false,independentAuditPending:true,
  best:{steps:0,saved},livePvpImprovementVerified:false}
 fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
 console.log(JSON.stringify({alpha,sha256:saved.sha256,independentAuditPending:true,optimizationStepsHere:0}))
}finally{trained.adam.dispose();trained.model.dispose();source.adam.dispose();source.model.dispose()}
