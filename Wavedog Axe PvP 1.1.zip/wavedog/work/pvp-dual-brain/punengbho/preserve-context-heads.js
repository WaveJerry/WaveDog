// Whole-parameter ablation of an offline learned update. Never an online
// state/action override: restored heads remain learned policy parameters.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,saveDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
const [trainedFile,dest,restoreOption]=process.argv.slice(2)
const restoredHeads=restoreOption?.split(',').map(Number)
assert(trainedFile&&dest&&!fs.existsSync(dest)&&restoredHeads?.length)
const parentFile=path.join(path.dirname(trainedFile),'receipt.json')
const parent=JSON.parse(fs.readFileSync(parentFile))
assert(parent.frozenBackbonesUnchanged&&parent.allBackbonesTrained&&parent.trainedOutputHeads)
assert(restoredHeads.every(h=>parent.trainedOutputHeads.includes(h)))
await tf.setBackend('cpu');await tf.ready()
const trained=loadDualCheckpoint(trainedFile),source=loadDualCheckpoint(parent.source)
try{
  assert.deepEqual(trained.model.config,source.model.config)
  const changedNames=new Set(parent.trainedOutputHeads.flatMap(h=>
    trained.model.actionContextOut[trained.model.config.actionContextHeads.indexOf(h)].params.map(p=>p.name)))
  for(const [i,param]of trained.model.params.entries()){
    assert.equal(param.name.replace(/^dual\d+\./,''),source.model.params[i].name.replace(/^dual\d+\./,''))
    if(!changedNames.has(param.name))assert.deepEqual(param.dataSync(),source.model.params[i].dataSync())
  }
  for(const head of restoredHeads){
    const index=trained.model.config.actionContextHeads.indexOf(head)
    for(const [j,param]of trained.model.actionContextOut[index].params.entries()){
      param.assign(source.model.actionContextOut[index].params[j])
      assert.deepEqual(param.dataSync(),source.model.actionContextOut[index].params[j].dataSync())
    }
  }
  fs.mkdirSync(dest,{recursive:true})
  const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),trained.model,trained.adam,trained.counters)
  const receipt={schema:'preserved-context-heads-bc-v1',source:parent.source,sourceSha256:source.manifest.sha256,
    trainingCheckpoint:path.resolve(trainedFile),trainingCheckpointSha256:trained.manifest.sha256,
    trainingReceipt:path.resolve(parentFile),referenceCheckpoint:parent.referenceCheckpoint,referenceSha256:parent.referenceSha256,
    dataset:parent.dataset,datasetSha256:parent.datasetSha256,causalThreatFeaturesUsed:parent.causalThreatFeaturesUsed,
    restoredHeads,trainedOutputHeads:parent.trainedOutputHeads.filter(h=>!restoredHeads.includes(h)),
    retainedUnselectedParametersExact:true,allBackbonesTrained:true,allBackbonesTrainedInThisStage:false,
    frozenBackbonesUnchanged:true,imitationStepsSinceReference:parent.imitationStepsSinceReference,
    optimizationStepsHere:0,offlineChecksPassed:false,independentAuditPending:true,
    noOnlineCombatRuleAdded:true,livePvpImprovementVerified:false,best:{steps:0,saved}}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
  console.log(JSON.stringify({restoredHeads,sha256:saved.sha256,independentAuditPending:true}))
}finally{trained.adam.dispose();trained.model.dispose();source.adam.dispose();source.model.dispose()}
