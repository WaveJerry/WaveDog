// Differentiable offline imitation of a whole useful decision. No actor,
// executor or distance controller imports this module.
import * as tf from '@tensorflow/tfjs'
import {outerEdgeSprintTarget} from './outer-edge-sprint-supervision.js'

export function combatFlowTargets(frame){
 const s=frame.publicRequest?.self,t=frame.publicRequest?.seen,l=frame.labels
 if(!s||!t?.visible||!l||!Object.keys(l).length)return []
 const targets=[],shield=Boolean(t.shield||t.shieldRaised)
 const edge=outerEdgeSprintTarget(frame)
 if(edge)targets.push(edge)
 if(s.held===0&&l[2]===1&&l[5]===1&&frame.publicRequest.jumpInputVersion===2
   &&frame.expertReason==='close-sword-critical-continuation'){
  const heads={2:1,5:1}
  for(const h of [0,1,4,6])if(l[h]!==undefined)heads[h]=l[h]
  targets.push({kind:'held-jump-sword-continuation',heads})
 }
 if(s.held===7&&Number.isFinite(s.charge)&&s.charge<.2&&!shield&&l[4]===0)
  targets.push({kind:'no-near-zero-axe-click',heads:{4:0}})
 if(s.held===0&&!shield&&Math.hypot(t.x-s.x,t.z-s.z)<=3.65&&l[5]===1)
  targets.push({kind:'retain-contact-sword',heads:{5:1}})
 if(frame.expertReason==='close-sword-early-useful-damage'&&l[4]===2&&l[5]===1){
  const heads={4:2,5:1}
  for(const h of [1,2,6])if(l[h]!==undefined)heads[h]=l[h]
  targets.push({kind:'useful-sword-hit-and-next-jump',heads})
 }
 if(frame.expertReason==='public-shield-axe-then-sword'&&l[4]===2&&l[5]===0){
  const heads={4:2,5:0};if(l[6]!==undefined)heads[6]=l[6]
  targets.push({kind:'combo-shield-axe-contact',heads})
 }
 if(['post-shield-attempt-prime-sword-while-checking','public-shield-clear-restore-sword'].includes(frame.expertReason)&&l[5]===1)
  targets.push({kind:'restore-sword-without-uncharged-click',heads:{4:0,5:1}})
 if(frame.contactForecast?.valid&&Number.isFinite(frame.contactForecast.ticks)&&s.held===0&&!shield){
  if(frame.contactForecast.ticks<=20&&l[5]===1)
   targets.push({kind:'sword-default-within-one-second',heads:{5:1}})
  if(frame.contactForecast.ticks>20&&l[5]===0)
   targets.push({kind:'distant-axe-preparation',heads:{5:0}})
 }
 return targets
}

export function combatFlowPurposeLoss(rows,logits,weight){
 if(!(weight>0))return null
 const byKind=new Map()
 for(const[i,row]of rows.entries())for(const target of combatFlowTargets(row.frame)){
  if(!byKind.has(target.kind))byKind.set(target.kind,[])
  byKind.get(target.kind).push({i,heads:target.heads})
 }
 if(!byKind.size)return null
 const logp=logits.map(head=>tf.logSoftmax(head)),terms=[]
 for(const targets of byKind.values()){
  const heads=new Set(targets.flatMap(target=>Object.keys(target.heads))),losses=[]
  for(const h of heads){
   const labels=rows.map(()=>0),mask=rows.map(()=>0)
   for(const target of targets)if(target.heads[h]!==undefined){
    labels[target.i]=target.heads[h];mask[target.i]=1
   }
   const nll=tf.neg(tf.sum(tf.mul(tf.oneHot(labels,logp[h].shape[1]),logp[h]),1))
   losses.push(tf.sum(tf.mul(nll,tf.tensor1d(mask))))
  }
  terms.push(tf.div(tf.addN(losses),targets.length))
 }
 return tf.mul(weight,tf.mean(tf.stack(terms)))
}
