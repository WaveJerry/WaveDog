"""Read actual packet/control/native-damage records; never starts a duel.

Holding space, taking off, and landing a native critical are distinct facts.
The audit reports observed transitions without attributing every ascent to a
jump: damage/knockback can also make the player's Y coordinate increase.
"""
from pathlib import Path
import argparse
import hashlib
import json


def audit(rows):
    landings = []
    takeoffs = []
    damage = {}
    packets = {}
    for index, row in enumerate(rows):
        if row.get('attackPacket'):
            packets[row.get('attackId')] = row
        for event in row.get('nativeEvents', []):
            if (event.get('attacker') == 'Punengbho' and event.get('nativeCritical')
                    and not event.get('cancelled') and event.get('amount', 0) > 0):
                damage[(event.get('serverTick'), event.get('attackId'))] = event
        if index == 0 or row.get('mode') != 'NEURAL':
            continue
        previous = rows[index - 1]
        if previous.get('mode') != 'NEURAL' or row['tick'] != previous['tick'] + 1:
            continue
        if row['self'].get('held') != 0:
            continue
        if row['self'].get('ground') and not previous['self'].get('ground'):
            # Inspect the actual key on the first observed landing frame.
            landings.append({'tick': row['tick'],
                             'heldJumpOnLanding': row.get('executed', {}).get('jump') is True,
                             'previousAirborneJump': previous.get('executed', {}).get('jump') is True})
        if (previous['self'].get('ground') and not row['self'].get('ground')
                and previous.get('executed', {}).get('jump') is True
                and row['self'].get('vy', 0) > .05):
            takeoffs.append(row['tick'])
    criticals = []
    for event in damage.values():
        packet = packets.get(event.get('attackId'))
        if (packet and packet.get('mode') == 'NEURAL'
                and packet.get('attackItemName') == 'diamond_sword'):
            criticals.append({'tick': packet['tick'], 'attackId': event['attackId'],
                              'damage': event['amount'], 'serverTick': event['serverTick']})
    criticals.sort(key=lambda r: r['tick'])
    chains = []
    for old, current in zip(criticals, criticals[1:]):
        if not 0 < current['tick'] - old['tick'] <= 20:
            continue
        between = [r for r in rows if old['tick'] < r['tick'] <= current['tick']]
        if not between or any(r.get('mode') != 'NEURAL' for r in between):
            continue
        landing = [r for r in landings if old['tick'] < r['tick'] < current['tick']]
        jumping = [tick for tick in takeoffs if old['tick'] < tick <= current['tick']]
        # A pair of crits alone is not evidence of a continuous jump cycle.
        chains.append({'from': old, 'to': current,
                       'observedLandingBetween': bool(landing),
                       'jumpOnEveryObservedLanding': bool(landing) and all(
                           r['heldJumpOnLanding'] for r in landing),
                       'jumpInputFollowedByAscentBetween': bool(jumping),
                       'continuousJumpCycleEvidence': bool(landing) and bool(jumping) and all(
                           r['heldJumpOnLanding'] for r in landing)})
    return {'observedSwordLandings': landings,
            'jumpInputsFollowedByAscentTicks': takeoffs,
            'nativeSwordCriticals': criticals,
            'consecutiveCriticalPairs': chains,
            'pairsWithContinuousJumpEvidence': sum(r['continuousJumpCycleEvidence'] for r in chains),
            'ascentCanAlsoIncludeKnockback': True,
            'nativeCriticalEvidenceRequired': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('frames', type=Path, nargs='+')
    args = parser.parse_args()
    if args.out.exists():
        raise RuntimeError('Preserve earlier audit')
    episodes = []
    for file in args.frames:
        payload = file.read_bytes()
        rows = [json.loads(line) for line in payload.decode('utf-8').splitlines()]
        episodes.append({'source': str(file.resolve()),
                         'sha256': hashlib.sha256(payload).hexdigest(),
                         **audit(rows)})
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps({'readOnly': True, 'agentStartedTrials': False,
                                   'episodes': episodes}, indent=2), encoding='utf-8')
    print(json.dumps({'bouts': len(episodes),
                      'nativeSwordCriticals': sum(len(e['nativeSwordCriticals']) for e in episodes),
                      'continuousJumpCriticalPairs': sum(e['pairsWithContinuousJumpEvidence'] for e in episodes)}))
