import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { conditionTechniqueObservation, FOCUS_NAMES } from './technique-conditioning.js'
import { curriculumLogitBias } from './dual-policy.js'

const require = createRequire(import.meta.url)
const { techniques, methodCues, techniqueGoal } = require('../pvp-player-client/technique-goals.js')
for (const focus of FOCUS_NAMES) {
  assert.equal(methodCues[focus].length, techniques[focus].length,
    `Every ${focus} lesson needs a machine cue`)
  methodCues[focus].flat().forEach(cue => assert(FOCUS_NAMES.includes(cue)))
}
const lesson = techniqueGoal('SYNC', 0, 1)
assert.match(lesson.goal, /jump reset/)
const publicFrame = Array(98).fill(0)
publicFrame[0] = 1; publicFrame[1] = .9; publicFrame[2] = 1
publicFrame[31] = 1; publicFrame[96] = .8; publicFrame[97] = -.2
publicFrame[15] = -1; publicFrame[78] = 0
publicFrame[87] = 1
const taught = conditionTechniqueObservation(publicFrame, 'SYNC', lesson.techniqueCues)
assert.equal(taught[14], 0)
assert.equal(taught[15], 1, 'opponent-facing south and north share a heading input')
assert.equal(publicFrame[15], -1, 'original observation remains unchanged')
assert.equal(taught[87], 1)
assert.equal(taught[85], .45)
assert.equal(taught[89], .3)
assert.equal(publicFrame[85], 0, 'conditioning must not mutate the public frame')
assert(curriculumLogitBias(taught)[2][1] > curriculumLogitBias(publicFrame)[2][1],
  'visible swing plus jump reset lesson should encourage a timed jump')
const noSwing = [...taught]; noSwing[96] = 0
assert.equal(curriculumLogitBias(noSwing)[2][1], curriculumLogitBias(publicFrame)[2][1],
  'jump reset cue alone must not make the bot hop continuously')
console.log('TECHNIQUE_CONDITIONING_PASS')
const terrain = conditionTechniqueObservation(publicFrame, 'FREE', [], null,
  {selfY:65,groundY:64,walls:[0,4,8,12]})
assert.equal(terrain[16],.25)
assert.deepEqual(terrain.slice(56,60),[0,.5,1,1])
assert.equal(conditionTechniqueObservation(publicFrame,'FREE',[],null,
  {episodeTick:120})[17],.05,'episode time is local to this bout')
assert.deepEqual(conditionTechniqueObservation(publicFrame,'FREE',[],null),
  conditionTechniqueObservation(publicFrame,'FREE',[],null,null),'legacy callers retain encoding')
