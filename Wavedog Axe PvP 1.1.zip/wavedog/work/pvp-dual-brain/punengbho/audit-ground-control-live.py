"""Descriptive replay audit of ground footwork and confirmed post-input ascent.

No action is changed. A jump input followed by ascent can include knockback;
it is not proof of a successful critical or a sustainable combo.
"""
from pathlib import Path
import argparse,json,math

def audit(frames):
    takeoffs=[];ground=0;lateral=0;away=0;into_wall=[]
    for index,f in enumerate(frames):
        s,t=f.get('self',{}),f.get('seen',{})
        if not t.get('visible') or f.get('owners',{}).get('movement')!='neural':continue
        if not s.get('ground'):continue
        ground+=1
        dx,dz=t['x']-s['x'],t['z']-s['z'];d=math.hypot(dx,dz)
        c=f.get('command')or{};executed=f.get('executed')or{}
        angle=math.radians(c.get('aimYawOffset',0))
        forward,side=c.get('forward',0),c.get('side',0)
        radial=forward*math.cos(angle)-side*math.sin(angle)
        right=forward*math.sin(angle)+side*math.cos(angle)
        lateral+=abs(right)>.25;away+=radial<-.25
        if d>.001:
            # Facing +Z: protocol right is -X. Resolve the full move vector.
            vx,vz=radial*dx/d-right*dz/d,radial*dz/d+right*dx/d
            speed=math.hypot(vx,vz)
            walls=f.get('publicTerrain',{}).get('walls')
            if walls and speed>.001:
                vx,vz=vx/speed,vz/speed
                clearance=min(walls[0 if vx<0 else 1]/abs(vx)if abs(vx)>.001 else math.inf,
                    walls[2 if vz<0 else 3]/abs(vz)if abs(vz)>.001 else math.inf)-.3
                if clearance<.65:into_wall.append(f['tick'])
        if not executed.get('jump'):continue
        ascent=next((q for q in frames[index+1:index+4] if 0<q['tick']-f['tick']<=2
            and not q['self'].get('ground') and q['self'].get('vy',0)>.05),None)
        if ascent:
            takeoffs.append({'tick':f['tick'],'ascentTick':ascent['tick'],'horizontalDistance':d,
                'observedReach':f.get('observation',{}).get('reach'),
                'opponentShield':bool(t.get('shield')or t.get('shieldRaised'))})
    return {'neuralGroundFrames':ground,'groundLateralIntentFrames':lateral,
        'groundRetreatIntentFrames':away,'plannedMovementTowardNearbyWallTicks':into_wall,
        'jumpInputsFollowedByAscent':takeoffs,
        'distantTakeoffsAtLeast2_35':sum(x['horizontalDistance']>=2.35 for x in takeoffs),
        'descriptiveOnly':True,'ascentMayIncludeKnockback':True,'fullTacticalMastery':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--suite',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists():raise RuntimeError('Preserve previous audit')
    suite=json.loads(a.suite.read_text());trials=[]
    for t in suite['trials']:
        frames=[json.loads(s)for s in Path(t['summary']['frameFile']).read_text().splitlines()]
        if any(f.get('policySha')!=suite['checkpointSha256'] for f in frames):raise RuntimeError('Mixed policy evidence')
        trials.append({'matchId':t['matchId'],'mode':t['mode'],'nearWall':t.get('nearWall'),**audit(frames)})
    a.out.write_text(json.dumps({'checkpointSha256':suite['checkpointSha256'],'trials':trials},indent=2))
    print(json.dumps({'bouts':len(trials),'takeoffs':sum(len(t['jumpInputsFollowedByAscent'])for t in trials),
        'distantTakeoffs':sum(t['distantTakeoffsAtLeast2_35']for t in trials),'descriptiveOnly':True}))
