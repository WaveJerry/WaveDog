import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, DualPolicy, OBS_SIZE } from './dual-policy.js'
import { importLastGru } from './import-last-gru.js'
import { SharedAdam } from './optimizer-checkpoint.js'

await tf.setBackend('cpu')
await tf.ready()
const folder = path.resolve(path.dirname(fileURLToPath(import.meta.url)),
  '../pvp-player-client/new-learning/models/last_gru')
const old = JSON.parse(fs.readFileSync(path.join(folder, 'recurrent-ppo.json'), 'utf8'))
const model = new DualPolicy()
const adam = new SharedAdam(model.params)
const imported = importLastGru(model, adam,
  path.join(folder, 'recurrent-ppo.json'), path.join(folder, 'manifest.json'))
assert.equal(imported.updates, old.updates)
assert.equal(adam.steps, old.optimizerSteps)

const stride = OBS_SIZE + 65
const gateSize = 64 * stride
const policyOffset = 3 * gateSize
const sigmoid = value => 1 / (1 + Math.exp(-value))
function gate (weights, offset, x, previous) {
  return Array.from({ length: 64 }, (_, neuron) => {
    const row = offset + neuron * stride
    let sum = weights[row + OBS_SIZE + 64]
    for (let input = 0; input < OBS_SIZE; input++) sum += weights[row + input] * x[input]
    for (let input = 0; input < 64; input++)
      sum += weights[row + OBS_SIZE + input] * previous[input]
    return sigmoid(sum)
  })
}
function legacyStep (x, previous) {
  const update = gate(old.w, 0, x, previous)
  const reset = gate(old.w, gateSize, x, previous)
  const hidden = Array.from({ length: 64 }, (_, neuron) => {
    const row = 2 * gateSize + neuron * stride
    let sum = old.w[row + OBS_SIZE + 64]
    for (let input = 0; input < OBS_SIZE; input++) sum += old.w[row + input] * x[input]
    for (let input = 0; input < 64; input++)
      sum += old.w[row + OBS_SIZE + input] * reset[input] * previous[input]
    return update[neuron] * previous[neuron] +
      (1 - update[neuron]) * Math.tanh(sum)
  })
  let offset = policyOffset
  const logits = ACTION_WIDTHS.map(width => {
    const head = Array.from({ length: width }, (_, action) => {
      const row = offset + action * 65
      let sum = old.w[row + 64]
      for (let index = 0; index < 64; index++) sum += old.w[row + index] * hidden[index]
      return sum
    })
    offset += width * 65
    return head
  })
  let value = old.w[offset + 64]
  for (let index = 0; index < 64; index++) value += old.w[offset + index] * hidden[index]
  return { hidden, logits, value }
}
function close (a, b, label) {
  assert(Math.abs(a - b) < 3e-5, `${label}: ${a} versus ${b}`)
}

try {
  let previous = Array(64).fill(0)
  let state = model.initialState()
  for (let frame = 0; frame < 5; frame++) {
    const observation = Array.from({ length: OBS_SIZE }, (_, index) =>
      .35 * Math.sin(index * .11 + frame * .37))
    const expected = legacyStep(observation, previous)
    const output = model.step(tf.tensor2d([observation]), state)
    state = output.state
    const fast = [...state.fast.dataSync()]
    fast.forEach((value, index) => close(value, expected.hidden[index], `hidden ${index}`))
    model.fastHeads.forEach((head, headIndex) => {
      const logits = [...head.apply(state.fast).dataSync()]
      logits.forEach((value, action) =>
        close(value, expected.logits[headIndex][action], `head ${headIndex}/${action}`))
    })
    close(model.fastValue.apply(state.fast).dataSync()[0], expected.value, 'critic')
    previous = expected.hidden
  }
  assert(outputGateLow(model))
  console.log(JSON.stringify({ result: 'LAST_GRU_IMPORT_PASS',
    updates: imported.updates, episodes: imported.episodes }))
} finally {
  adam.dispose()
  model.dispose()
}

function outputGateLow (model) {
  const result = model.step(tf.zeros([1, OBS_SIZE]), model.initialState())
  return [...result.gate.dataSync()].every(weight => weight < .02)
}
