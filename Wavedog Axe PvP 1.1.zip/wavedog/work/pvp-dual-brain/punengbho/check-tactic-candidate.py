"""Do not let an aggregate imitation score hide lost jump/attack decisions."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[3]
folder=Path(sys.argv[1])
r=json.loads((folder/'receipt.json').read_text())
before=r['before']['validation'];after=r['after']['validation']
label=lambda stats,key:stats['labels'].get(key)
checks={'standardOfflineChecks':r['offlineChecksPassed']}
for key in ['4:2','2:1']:
    a,b=label(before,key),label(after,key)
    if a and b:checks[key+'-not-regressed']=b['nll']<=a['nll']+1e-6
# The over-suppressed reference waited on virtually every grounded frame.
# Do not require preserving that collapse while recovering native jumps;
# bound false positive jumps explicitly before looking at the candidate.
quiet=label(after,'2:0')
if quiet:checks['groundedWaitingRetained']=quiet['probability']>=.8 and quiet['accuracy']>=.85
checks['weaponPolicyPreserved']=after.get('drift',{}).get('5',{}).get('mean',0)<.02
checks['viewPolicyPreserved']=all(after.get('drift',{}).get(str(h),{}).get('mean',0)<.02 for h in [6,7])
report={'passed':all(checks.values()),'checks':checks,'realCombatStillRequired':True,
    'evidence':{key:{'before':label(before,key),'after':label(after,key)}for key in ['4:2','2:1','2:0']},
    'candidateSha256':r['saved']['sha256']}
(folder/'tactic-checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
if not report['passed']:raise SystemExit(1)
