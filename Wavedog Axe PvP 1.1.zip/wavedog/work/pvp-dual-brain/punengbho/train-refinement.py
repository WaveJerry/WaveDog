from pathlib import Path
import json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117/refinement'
if (BASE/'trained/checkpoint.json').exists():raise RuntimeError('Preserve previous candidate')
env=os.environ.copy()
env.update(IMITATION_HEADS_ONLY='1',IMITATION_CONTEXT_ONLY='0',IMITATION_CONTEXT_HEADS='[2,4,5]',
    IMITATION_CALIBRATED_HEADS='[2,4,5]',IMITATION_DISTRIBUTION_VERSION='3',IMITATION_WEAPON_CONDITIONING='2',
    IMITATION_LR='0.001',IMITATION_CONTEXT_RATE='1',IMITATION_EPOCHS='3',
    IMITATION_FREQUENCY_HEADS='[1,2,4,5,6,7]',IMITATION_EXCHANGE_BALANCE='1',
    IMITATION_HEAD_WEIGHTS='{"4":4,"5":2}',IMITATION_ADAPTED_ANCHOR='0.05',
    IMITATION_ADAPTED_HEADS='[1,2,4,5,6,7]')
with (BASE/'training.log').open('wb')as log:
    subprocess.run([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/human-imitation.js'),
        str(BASE/'initial/checkpoint.json'),str(BASE/'whole-exchanges.json'),str(BASE/'trained')],
        cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
d=json.loads((BASE/'trained/receipt.json').read_text())
print(json.dumps({'offlineChecksPassed':d['offlineChecksPassed'],'checks':d['checks'],'saved':d['saved']}))
