import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {publicThreatFeatures}from '../public-threat-features.js'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
import {advance,disposeState}from '../human-imitation.js'
import {responseSupervisionWeight}from './response-supervision-weight.js'
import {retreatPurposeSupervision}from './retreat-purpose-supervision.js'
const r={tick:10,matchId:'a',opponent:'b',self:{x:0,y:0,z:0},seen:{visible:true,x:0,y:.8,z:3},
  publicActionContext:{tick:10,visible:true,targetGrounded:false,targetVelocity:{x:0,y:.01,z:-.1},
    targetCriticalPossible:true,airEnvelope:{valid:true,ticks:6,criticalTick:2,meleeTick:0}}}
const f=publicThreatFeatures(r)
assert.equal(f.length,12);assert.equal(f[6],1);assert.equal(f[7],1/3);assert.equal(f[9],1)
for(const req of [{}, {...r,seen:{...r.seen,visible:false}}, {...r,tick:11},
  {...r,publicActionContext:{...r.publicActionContext,matchId:'other'}},
  {...r,publicActionContext:{...r.publicActionContext,targetVelocity:{x:NaN,y:0,z:0}}}])
  assert.deepEqual(publicThreatFeatures(req),Array(12).fill(0))
assert.equal(publicThreatFeatures({...r,publicActionContext:{...r.publicActionContext,airEnvelope:null}})[5],0)
await tf.setBackend('cpu');await tf.ready()
const m=new DualPolicy({fast:8,slow:16,heads:2,layers:4,ff:24,interval:2,memory:4,publicThreatInputs:12})
const x=Array(OBS_SIZE).fill(.2)
const initial=advance(m,m.initialState(),x,true,null,null,null,f)
const absent=advance(m,m.initialState(),x,true)
assert.deepEqual(initial.logits,absent.logits,'zero extension preserves inference')
disposeState(initial.state);disposeState(absent.state)
tf.tidy(()=>m.publicThreatProjection.assign(tf.fill([12,OBS_SIZE],.01)))
const withInput=advance(m,m.initialState(),x,true,null,null,null,f)
const withoutInput=advance(m,m.initialState(),x,true)
assert.notDeepEqual([...withInput.state.fast.dataSync()],[...withoutInput.state.fast.dataSync()],'GRU sees the forecast')
assert.notDeepEqual([...withInput.state.slow.dataSync()],[...withoutInput.state.slow.dataSync()],'GTrXL sees the forecast')
disposeState(withInput.state);disposeState(withoutInput.state)
const grads=tf.variableGrads(()=>tf.tidy(()=>{
  const out=m.step(tf.tensor2d([x]),null,null,null,null,f)
  return tf.addN(out.logits.map(h=>tf.sum(tf.square(h))))
}),m.params)
for(const name of ['public-threat','fast','slow-0','slow-1','slow-2','slow-3','gate-in'])
  assert(Object.entries(grads.grads).some(([k,v])=>k.includes('.'+name)&&[...v.dataSync()].some(n=>Math.abs(n)>0)),name+' receives gradients')
grads.value.dispose();Object.values(grads.grads).forEach(g=>g.dispose());m.dispose()
assert.equal(responseSupervisionWeight({publicRequest:{self:{ground:true},publicActionContext:{targetAirborne:true,targetCriticalThreat:true}},labels:{4:0}},0,4),4)
assert.equal(responseSupervisionWeight({publicRequest:{self:{ground:false}},labels:{4:2}},0,4),1)
const wallRequest={self:{x:0,y:0,z:0,held:7,charge:.95},seen:{visible:true,x:0,y:1,z:3},
  publicTerrain:{walls:[8,8,.5,8]}}
for(const move of [0,3,4]){
  const advice={reason:'avoid-forecast-retaliation-critical-lateral-exit',actions:[move,0,0,0,0,0,6,3,0],
    labels:{0:move,1:0,2:0,4:0,5:0,6:6}}
  assert.equal(retreatPurposeSupervision(advice,wallRequest),advice,'danger exit is not overwritten by reengagement')
}
console.log('PUBLIC_THREAT_PASS: causal validity, no carryover, zero migration, both branches, joint gradients')
