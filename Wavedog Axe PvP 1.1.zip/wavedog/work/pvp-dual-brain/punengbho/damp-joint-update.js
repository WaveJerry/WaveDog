// A uniform neural-parameter trust step, never a state/action-specific rule.
// No extra optimization is claimed. Retain the original full joint result.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
const [trainedFile,dest,amount='0.5']=process.argv.slice(2),alpha=Number(amount)
assert(trainedFile&&dest&&!fs.existsSync(dest)&&alpha>0&&alpha<1)
const parentFile=path.join(path.dirname(trainedFile),'receipt.json'),parent=JSON.parse(fs.readFileSync(parentFile))
assert(parent.allBackbonesTrained,'Require a completed joint neural update')
await tf.setBackend('cpu');await tf.ready()
const trained=loadDualCheckpoint(trainedFile),source=loadDualCheckpoint(parent.source)
const key=p=>p.name.split('.').slice(1).join('.')
const groups={}
try{
 assert.equal(trained.model.params.length,source.model.params.length)
 for(const[i,p]of trained.model.params.entries()){
   const q=source.model.params[i];assert.equal(key(p),key(q));assert.deepEqual(p.shape,q.shape)
   tf.tidy(()=>p.assign(tf.add(q,tf.mul(alpha,tf.sub(p,q)))))
   const g=groups[key(p).split('.')[0]]||={parameters:0,changed:0,maxAbsDelta:0},a=p.dataSync(),b=q.dataSync()
   for(let j=0;j<a.length;j++){const d=Math.abs(a[j]-b[j]);g.parameters++;g.changed+=Number(d>0);g.maxAbsDelta=Math.max(g.maxAbsDelta,d)}
 }
 const allBackbonesTrained=groups.fast.changed>0&&Array.from({length:trained.model.config.layers},(_,i)=>groups['slow-'+i].changed>0).every(Boolean)
   &&groups['gate-in'].changed>0&&groups['public-threat'].changed>0
 assert(allBackbonesTrained)
 fs.mkdirSync(dest,{recursive:true})
 const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),trained.model,trained.adam,trained.counters)
 const receipt={schema:'uniform-damped-joint-bc-v1',source:path.resolve(trainedFile),sourceSha256:trained.manifest.sha256,
   jointTrainingReceipt:path.resolve(parentFile),preUpdateCheckpoint:parent.source,preUpdateSha256:source.manifest.sha256,
   referenceCheckpoint:parent.referenceCheckpoint,referenceSha256:parent.referenceSha256,
   dataset:parent.dataset,datasetSha256:parent.datasetSha256,causalThreatFeaturesUsed:parent.causalThreatFeaturesUsed,
   imitationStepsSinceReference:parent.imitationStepsSinceReference,optimizationStepsHere:0,
   alpha,parameterChanges:groups,allBackbonesTrained,noOnlineCombatRules:true,
   offlineChecksPassed:false,independentAuditPending:true,best:{steps:0,saved},livePvpImprovementVerified:false}
 fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
 console.log(JSON.stringify({alpha,sha256:saved.sha256,allBackbonesTrained,independentAuditPending:true}))
}finally{trained.adam.dispose();trained.model.dispose();source.adam.dispose();source.model.dispose()}
