// Bounded truncated PPO updates, spread through a bout and around feedback.
// Keeping these windows separate preserves the recurrent state at each point.
export function selectTrainingWindows (frames, width = 8, maxWindows = 12) {
  const count = frames.length
  if (!count) return []
  if (count <= width) return [{ start: 0, end: count }]
  const windows = []
  const add = index => {
    if (windows.length >= maxWindows) return false
    const start = Math.max(0, Math.min(count - width,
      Math.round(index) - Math.floor(width / 2)))
    if (windows.some(window => start < window.end && start + width > window.start))
      return false
    windows.push({ start, end: start + width })
    return true
  }
  add(0)
  add(count - 1)
  const bins = Math.min(8, Math.max(1, maxWindows - 4))
  for (let bin = 0; bin < bins; bin++) {
    const begin = Math.floor(bin * count / bins)
    const end = Math.floor((bin + 1) * count / bins)
    let strongest = begin
    for (let index = begin + 1; index < end; index++)
      if (Math.abs(frames[index].reward) > Math.abs(frames[strongest].reward))
        strongest = index
    add(strongest)
  }
  const ranked = [...frames.keys()].sort((a, b) =>
    Math.abs(frames[b].reward) - Math.abs(frames[a].reward))
  // Reserve feedback slots for both useful actions and costly actions.
  for (const sign of [1, -1]) {
    const candidate = ranked.find(index => Math.sign(frames[index].reward) === sign
      && !windows.some(window => index >= window.start && index < window.end))
    if (candidate != null) add(candidate)
  }
  for (const index of ranked) {
    if (windows.length >= maxWindows || Math.abs(frames[index].reward) < .004) break
    add(index)
  }
  return windows.sort((a, b) => a.start - b.start)
}

// Chronological truncated BPTT over every actor frame. A window boundary
// truncates gradients, but no observed action or reward is skipped.
export function selectCompleteTrainingWindows (frames, width = 32) {
  if (!Number.isInteger(width) || width < 1) throw Error('Invalid PPO window width')
  const windows = []
  for (let start = 0; start < frames.length; start += width)
    windows.push({ start, end: Math.min(start + width, frames.length) })
  return windows
}
