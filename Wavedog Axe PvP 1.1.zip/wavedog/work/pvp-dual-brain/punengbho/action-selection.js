// Deterministic BC evaluation is separate from stochastic on-policy PPO.
export function chooseAction(probabilities,frozenEvaluation,random=Math.random){
  if(frozenEvaluation)return probabilities.reduce((best,p,i)=>p>probabilities[best]?i:best,0)
  let draw=random()
  for(let i=0;i<probabilities.length;i++){draw-=probabilities[i];if(draw<=0)return i}
  return probabilities.length-1
}
