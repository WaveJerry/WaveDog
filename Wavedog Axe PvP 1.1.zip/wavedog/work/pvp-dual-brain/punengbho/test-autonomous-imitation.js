import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS} from '../fresh-policy.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
await tf.setBackend('cpu'); await tf.ready()
const logits = ACTION_WIDTHS.map(n=>Array.from({length:n},(_,a)=>a===0?0:-10))
logits[5][1]=5 // The policy picks a sword; the expert label picks an axe.
const policy={config:{distributionVersion:2,actionConditionedAttack:1},
  conditionActionLogits(heads,observation,actions) {
    return heads.map((head,h)=>h===4?tf.tensor2d([actions[5]===0?[0,-10,5,-10]:[5,-10,0,-10]]):head)
  }}
const frame={observation:Array(98).fill(0),context:{},actions:[0,0,0,0,2,0,0,0,0]}
const out=captureAutonomousImitation(policy,{logits},frame)
assert.equal(out.teacherForced.logits[4].indexOf(Math.max(...out.teacherForced.logits[4])),2)
assert.equal(out.actions[5],1)
assert.equal(out.actions[4],0,'audit must use the policy weapon, not inject the expert axe')
assert.equal(tf.memory().numTensors,0,'diagnostic inference must not leak tensors')
console.log('AUTONOMOUS_CONDITIONAL_ACTION_AUDIT_PASS')
