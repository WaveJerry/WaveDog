"""Keep old learning intact and prepare a separate fresh-generation install manifest."""
from pathlib import Path
import argparse,hashlib,json,shutil
from importlib.machinery import SourceFileLoader
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
LIVE=ROOT/'work/wavedog-punengbho/model'
audit=SourceFileLoader('pure_status',str(Path(__file__).with_name('integration-status.py'))).load_module()
actual=audit.status(18776)
if actual['actors']:raise RuntimeError('Preserve active bout')
current=json.loads((LIVE/'checkpoint.json').read_text())
if actual['checkpointSha256']!=current['sha256']:raise RuntimeError('Wait for learning commit')
p=argparse.ArgumentParser();p.add_argument('--trained',type=Path,default=BASE/'behavior-cloning')
p.add_argument('--out',type=Path,default=BASE/'install');args=p.parse_args()
trained=args.trained
r=json.loads((trained/'receipt.json').read_text())
if not r['offlineChecksPassed']:raise RuntimeError('Fresh BC did not pass holdout checks')
candidate=json.loads((trained/'checkpoint.json').read_text())
assert candidate['optimizer']['steps']==0 and candidate['counters']['dualUpdates']==0
DEST=args.out;DEST.mkdir(exist_ok=False)
(DEST/'source').mkdir()
for name in ['checkpoint.json',current['binary']]:shutil.copy2(LIVE/name,DEST/'source'/name)
# Sequence is a durable transport cursor, not inherited policy experience.
candidate['counters']['lastRolloutSeq']=current['counters']['lastRolloutSeq']
candidate['counters']['journalSequenceCarriedWithoutTraining']=True
candidate['counters']['archivedPreviousGenerationSha256']=current['sha256']
candidate['counters']['archivedPreviousGenerationPpoUpdates']=current['counters']['dualUpdates']
payload=(trained/candidate['binary']).read_bytes()
assert hashlib.sha256(payload).hexdigest()==candidate['sha256']
(DEST/candidate['binary']).write_bytes(payload)
(DEST/'checkpoint.json').write_text(json.dumps(candidate))
(DEST/'receipt.json').write_text(json.dumps({'offlineChecksPassed':True,'freshRandomInitialization':True,
    'originalReceipt':str(trained/'receipt.json'),'sourceSha256':current['sha256'],
    'newGenerationSha256':candidate['sha256'],'allTacticsMastered':False,
    'onlyTransportSequenceCarried':True,'oldLearningArchived':True},indent=2))
print(json.dumps({'candidate':str(DEST/'checkpoint.json'),'freshGeneration':True,
    'previousLearningArchived':current['sha256'],'newSha256':candidate['sha256']}))
