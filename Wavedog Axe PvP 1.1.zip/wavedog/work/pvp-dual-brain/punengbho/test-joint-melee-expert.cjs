'use strict'
const assert=require('node:assert/strict')
const {criticalExpert,observeLearnerInput}=require('./joint-melee-expert.cjs')
const forwardOf=a=>[0,1,-1,0,0,1,1,-1,-1][a.labels[0]]
function request(distance,over={}) {
  return {tick:100,self:{x:0,y:0,z:0,eyeY:1.62,held:0,ground:true,
    attackAgeTicks:40,weaponAgeTicks:40,wireFalling:false,...over.self},
    seen:{x:0,y:0,z:distance,visible:true,shield:false,...over.seen},
    publicActionContext:{sentPosition:{x:0,y:0,z:0},targetVelocity:{x:0,y:0,z:0},...over.context}}
}
let r=criticalExpert(request(4))
assert.equal(r.labels[2],0,'approach is grounded')
assert.equal(r.labels[4],0,'no out-of-range swing')
r=criticalExpert(request(1.5),{lastGroundJumpTick:99})
assert.equal(r.labels[2],1,'close sword combat does not inherit an artificial jump rest timer')
r=criticalExpert(request(2.8),{lastGroundJumpTick:99})
assert.equal(r.labels[2],0,'distant grounded spacing must not become early jump spam')
r=criticalExpert(request(3.299))
assert.equal(r.labels[4],2,'charged earliest legal boundary strike')
assert.equal(r.labels[1],1,'ground boundary hit uses sprint knockback')
r=criticalExpert(request(3.301))
assert.equal(r.labels[4],0,'3-block reach is strict')
r=criticalExpert(request(3.1,{context:{sentPosition:{x:0,y:0,z:-.3}}}))
assert.equal(r.labels[4],0,'predicted client position cannot extend wire reach')
r=criticalExpert(request(1.5,{self:{ground:false,wireFalling:true}}))
assert.equal(r.labels[4],2);assert.equal(r.labels[1],0,'sprint releases for real critical')
assert.equal(r.labels[2],undefined,'airborne jump is not invented')
r=criticalExpert(request(1.5,{self:{ground:false,wireFalling:false}}))
assert.equal(r.labels[4],0,'predicted falling does not imply sent falling')
r=criticalExpert(request(1.5,{self:{held:7,ground:false,wireFalling:true}}))
assert.equal(r.labels[5],1);assert.equal(r.labels[4],0,'sword switch precedes sword damage')
r=criticalExpert(request(3.299,{self:{held:7}}))
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'keep charged first edge axe strike')
const history={}
observeLearnerInput(history,request(3.299),{attackPacket:true,held:7})
r=criticalExpert(request(3.1,{self:{held:7}}),history)
assert.equal(r.labels[5],0,'a ready axe already in hand may spend its legal window before returning to sword')
r=criticalExpert(request(3.1,{self:{held:7,attackAgeTicks:3}}),history)
assert.equal(r.labels[4],0);assert.equal(r.labels[5],1,'a spent opener primes sword without another low-charge click')
r=criticalExpert(request(12,{self:{held:0}}))
assert.equal(r.labels[5],0,'prepare high-damage axe before distant entry')
r=criticalExpert(request(1.5,{seen:{shield:true}}))
assert.equal(r.labels[4],0,'a static close shield alone cannot start a forced break')
r=criticalExpert(request(3.5,{seen:{shield:true}}))
assert.equal(r.labels[4],0,'shield break cannot extend reach')
r=criticalExpert(request(2.9,{seen:{shield:true},self:{held:7}}))
assert.equal(r.labels[4],0,'do not spend the spacing opener on an already raised shield')
r=criticalExpert(request(1.5,{seen:{shield:true,y:.8},context:{targetAirborne:true,targetVelocity:{x:0,y:-.2,z:0}}}))
assert.equal(r.labels[4],0);assert.equal(r.labels[0],2);assert.equal(r.labels[2],0,
  'a descending shielded opponent is dangerous even inside close range')
r=criticalExpert(request(2.35))
assert.equal(r.labels[2],0,'borderline reach is not yet a sustainable close critical exchange')
r=criticalExpert(request(1.5,{context:{targetVelocity:{x:0,y:.23,z:.25}}}))
assert.equal(r.labels[2],1,'deep close exchanges remain possible despite an airborne opponent')
r=criticalExpert(request(1.5,{seen:{shield:true},self:{held:7,attackAgeTicks:1}}),{lastAxeStrikeTick:99,lastShieldAxeTick:99})
assert.equal(r.labels[5],0,'keep axe until the effective shield actually clears')
assert.equal(r.labels[4],0,'a failed or still-unconfirmed attempt must not teach two-tick axe spam')
r=criticalExpert(request(1.5,{seen:{shield:true},self:{held:0}}),{lastAxeStrikeTick:97,lastSwordAttackTick:95})
assert.equal(r.labels[5],0,'a persistently visible shield is reconsidered, never assumed disabled')
r=criticalExpert(request(1.5,{self:{held:7},seen:{shield:false}}),{lastAxeStrikeTick:99})
assert.equal(r.labels[5],1,'public shield disappearance allows returning to sword')
assert.equal(r.labels[2],0,'prime the newly selected sword before takeoff')
r=criticalExpert(request(1.5,{self:{held:0,charge:.92,attackAgeTicks:11,weaponAgeTicks:40,ground:false,wireFalling:true}}))
assert.equal(r.labels[4],2,'native-ready critical must not wait for an arbitrary 13th tick')
r=criticalExpert(request(1.5,{self:{held:0,charge:.84,attackAgeTicks:30,ground:false,wireFalling:true}}))
assert.equal(r.labels[4],0,'native low charge cannot be overridden by a local timer')
r=criticalExpert(request(3.3,{self:{held:7,charge:.3,attackAgeTicks:3}}))
assert.equal(forwardOf(r),0);assert.equal(r.labels[4],0);assert.equal(r.labels[5],1)
r=criticalExpert(request(4.6,{self:{held:7,charge:.5,attackAgeTicks:8}}))
assert.equal(forwardOf(r),0,'once out of retaliation range do not rush back with an uncharged axe')
assert.equal(r.labels[5],1,'within one second of contact, prepare the default sword')
r=criticalExpert(request(4.6,{self:{held:7,charge:.95,attackAgeTicks:19}}))
assert.equal(forwardOf(r),1);assert.equal(r.labels[1],1,'resume entry after charge recovers')
r=criticalExpert(request(1.5,{self:{held:7,charge:.15,attackAgeTicks:2}}))
assert.equal(r.labels[5],1,'deep close pressure retains the sword continuation option')
const followup={}
observeLearnerInput(followup,request(1.5,{seen:{shield:true}}),{attackPacket:true,held:7})
let followRequest={...request(1.5,{self:{held:0,charge:.6,ground:false,wireFalling:true}}),tick:108,
 publicTerrain:{groundY:0,walls:[8,8,8,8]}}
r=criticalExpert(followRequest,followup)
assert.equal(r.labels[4],2,'first sword descent can salvage an ordinary hit after shield axe attempt')
assert.equal(r.reason,'post-shield-sword-ordinary-before-window-closes')
observeLearnerInput(followup,followRequest,{attackPacket:true,held:0})
r=criticalExpert({...followRequest,tick:109},followup)
assert.equal(r.labels[4],0,'the ordinary-hit exception cannot become low-charge sword spam')
r=criticalExpert({...followRequest,self:{...followRequest.self,charge:.2}},{lastShieldAxeTick:100})
assert.equal(r.labels[4],0,'near-zero-charge flailing is not taught as productive continuation')
r=criticalExpert(request(1.5,{seen:{shield:true,y:.8},context:{targetAirborne:true}}),{lastSwordAttackTick:95})
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'active close sword chain responds to effective shield')
const closeHistory={}
criticalExpert(request(1.5),closeHistory)
r=criticalExpert(request(2.6,{context:{targetVelocity:{x:0,y:0,z:.3}}}),closeHistory)
assert.equal(r.labels[5],1);assert.equal(forwardOf(r),1);assert.equal(r.labels[2],0,
  'prior close contact preserves a ground sword hit, not a new distant jump')
r=criticalExpert(request(3.6),closeHistory)
assert.equal(closeHistory.closeExchangeActive,false,'out-of-reach separation ends close continuation')
r=criticalExpert(request(2.7),closeHistory)
assert.equal(r.labels[2],0,'a new distant exchange does not inherit old close jumping')
r=criticalExpert(request(3.1,{context:{targetCriticalThreat:true,targetVelocity:{y:-.12}}}))
assert.equal(r.labels[4],0);assert.equal(r.labels[0],2,'avoid a falling critical for ordinary damage')
const risingReady={self:{held:7,charge:1},context:{targetAirborne:true,targetCriticalThreat:true,
  targetVelocity:{x:0,y:.25,z:-.1},airEnvelope:{valid:true,criticalTick:4}}}
r=criticalExpert(request(3.1,risingReady))
assert.equal(r.labels[4],2,'future descent risk must not erase a ready legal ascent interrupt')
assert.equal(r.labels[5],0);assert.equal(r.labels[2],0)
r=criticalExpert(request(3.6,risingReady))
assert.equal(r.labels[4],0,'an ascending opponent beyond reach is not an interrupt opportunity')
r=criticalExpert(request(3.1,{...risingReady,context:{...risingReady.context,targetVelocity:{x:0,y:-.1,z:-.1}}}))
assert.equal(r.labels[4],0,'enemy descent remains a different trade from enemy ascent')
r=criticalExpert(request(1.5,{self:{held:0,charge:1,ground:false,wireFalling:false},context:risingReady.context}))
assert.equal(r.labels[4],0,'our own safe sword ascent may wait for our critical window')
assert.equal(r.ppoEligible,false);assert.equal(r.counterfactual,true)
const recoverHistory={lastAxeStrikeTick:99}
r=criticalExpert(request(5,{self:{held:7,charge:.6,attackAgeTicks:10}}),recoverHistory)
assert.equal(forwardOf(r),0);assert.equal(r.labels[5],1,'do not keep fleeing; prepare sword for the next contact')
r=criticalExpert(request(1.8,{self:{held:7,charge:.5,attackAgeTicks:10}}),recoverHistory)
assert.equal(r.labels[0],1);assert.equal(r.labels[5],1,'actual sustained deep contact can transition to sword instead of automatic retreat')
r=criticalExpert({...request(2.4,{self:{held:7,charge:.5,attackAgeTicks:10}}),
 publicTerrain:{groundY:0,walls:[8,8,.5,8]}},recoverHistory)
assert.equal(r.labels[5],1);assert.equal(forwardOf(r),0);assert.equal(r.labels[2],0,'default sword at a wall still cannot authorize a distant jump')
r=criticalExpert({...request(2.4,{self:{held:7,charge:.5,attackAgeTicks:10}}),
 publicTerrain:{groundY:0,walls:[.5,8,8,8]}},recoverHistory)
assert.equal(r.labels[5],1);assert.equal(r.labels[2],0,'a side wall does not override the new sword default or start a distant jump')
r=criticalExpert(request(4.6,{self:{held:7,charge:.95,attackAgeTicks:20}}),recoverHistory)
assert.equal(forwardOf(r),1,'native strong charge is already available; do not wait for 98 percent')
r=criticalExpert(request(4.6,{self:{held:7,charge:1,attackAgeTicks:21}}),recoverHistory)
assert.equal(forwardOf(r),1,'full charge ends recovery and prepares reengagement')
r=criticalExpert(request(1.8,{seen:{shield:true,y:.5},context:{targetAirborne:true},
 self:{held:0,charge:.1,attackAgeTicks:1}}),{lastSwordAttackTick:99})
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'reachable sword chain switches and attacks effective shield immediately')
r=criticalExpert(request(1.8,{seen:{shield:true},self:{held:7,attackAgeTicks:1}}),
 {lastSwordAttackTick:95,lastAxeStrikeTick:99,lastShieldAxeTick:99})
assert.equal(r.labels[5],0);assert.equal(r.labels[4],0);assert.equal(r.labels[0],1,
 'keep pressure and await actual shield clearance, without switch-back loops')
r=criticalExpert(request(1.8,{seen:{shield:true},self:{held:0,attackAgeTicks:6}}),
 {lastSwordAttackTick:90,lastAxeStrikeTick:94,lastShieldAxeTick:94})
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'a genuinely persistent shield is retried rather than ignored')
console.log('JOINT_MELEE_EXPERT_PUBLIC_STATE_PASS')
for(const charge of [.4,.9,1]){
 const corner={...request(2.7,{self:{held:7,charge,attackAgeTicks:40}}),
   publicTerrain:{groundY:0,walls:[8,8,.3,8]}}
 const cornerAdvice=criticalExpert(corner,{lastAxeStrikeTick:40})
 assert.equal(cornerAdvice.labels[5],charge>.9?0:1,'ready first axe hit remains; otherwise prepare the default sword')
 assert(forwardOf(cornerAdvice)>=0,'use lateral control rather than retreating into the wall')
 assert.equal(cornerAdvice.labels[2],0,'do not start a jump at boundary spacing')
 assert.equal(cornerAdvice.labels[4],charge>.9?2:0,'native strong ground axe contact is retained at the wall')
}
r=criticalExpert({...request(4.5,{self:{held:7,charge:.4,attackAgeTicks:8}}),
 publicTerrain:{groundY:0,walls:[8,8,.3,8]}},{lastAxeStrikeTick:95})
assert([3,4].includes(r.labels[0]),'blocked retreat permits lateral preparation without running into the wall')
r=criticalExpert(request(2.8,{self:{held:7,charge:.95,attackAgeTicks:20}}),{lastAxeStrikeTick:80})
assert.equal(r.labels[4],2);assert.equal(forwardOf(r),1);assert.equal(r.labels[1],1,
 'a recovered axe can reengage without another purposeless retreat')
console.log('BLOCKED_RETREAT_AND_RECOVERED_AXE_REENGAGEMENT_PASS')
for(const [dx,dz,wallIndex]of [[0,2.7,2],[0,-2.7,3],[2.7,0,0],[-2.7,0,1]]){
 const walls=[8,8,8,8];walls[wallIndex]=.35
 const q={...request(2.7,{self:{held:7,charge:1},seen:{x:dx,z:dz}}),
   publicTerrain:{groundY:0,walls}}
 const a=criticalExpert(q)
 assert.equal(a.labels[5],0,'wall response retains grounded axe control across spawn directions')
 assert.equal(forwardOf(a),1);assert.equal(a.labels[2],0)
}
console.log('WALL_ESCAPE_FOUR_DIRECTIONS_PASS')
const incoming=request(3.1,{self:{held:7,charge:.35,attackAgeTicks:7},
  context:{targetVelocity:{x:0,y:0,z:-.22}}})
r=criticalExpert(incoming,{lastAxeStrikeTick:93})
assert.equal(r.labels[4],0,'a low-charge axe click is not a reliable sprint interrupt')
assert.equal(r.labels[5],1,'an unready axe near contact yields to the default sword')
for(const charge of [.7,.92]){
 const a=criticalExpert({...incoming,self:{...incoming.self,charge,attackAgeTicks:14}})
 assert.equal(a.labels[4],2,'a meaningful recovered emergency hit is retained')
 assert.equal(a.labels[1],Number(charge>.9),'only native strong charge teaches sprint knockback')
}
r=criticalExpert({...incoming,self:{...incoming.self,attackAgeTicks:1}})
assert.equal(r.labels[4],0,'an emergency lesson cannot become one-tick attack spam')
r=criticalExpert({...incoming,seen:{...incoming.seen,z:3.6}})
assert.equal(r.labels[4],0,'the interception lesson cannot extend legal reach')
r=criticalExpert({...incoming,publicActionContext:{...incoming.publicActionContext,targetCriticalThreat:true,targetVelocity:{x:0,y:-.2,z:-.22}}})
assert.equal(r.labels[4],0,'already descending critical threat is not taught as free ordinary trade')
const rush={approachFrames:2}
r=criticalExpert({...incoming,seen:{...incoming.seen,z:1.75}},rush)
assert.equal(r.labels[5],1);assert.equal(r.labels[4],0,'persistent deep pressure primes sword instead of waiting for another axe')
r=criticalExpert(request(3.15,{self:{held:0,charge:.55,attackAgeTicks:7,ground:false,wireFalling:true},
  context:{targetVelocity:{x:0,y:0,z:.22}}}),{lastSwordAttackTick:93})
assert.equal(r.labels[4],2);assert.equal(r.labels[5],1);assert.equal(r.labels[1],0)
assert.equal(r.reason,'sword-last-legal-contact-before-separation')
console.log('URGENT_INTERRUPT_DEEP_SWORD_AND_LAST_CONTACT_PASS')
for(const distance of [2.35,2.7,3.1]){
 r=criticalExpert(request(distance),{lastSwordAttackTick:99,closeExchangeActive:true})
 assert.equal(r.labels[2],0,'old sword contact cannot authorize another distant takeoff')
}
r=criticalExpert(request(1.9,{context:{targetVelocity:{x:0,y:0,z:.6}}}),{lastSwordAttackTick:99})
assert.equal(r.labels[2],0,'rapidly opening contact must retain a one-hit separation reserve')
r=criticalExpert(request(2.85,{self:{ground:false,wireFalling:true,charge:1}}),{lastSwordAttackTick:95})
assert.equal(r.labels[4],2);assert.equal(r.labels[1],0,'an already airborne legal finish remains available')
const lateral=criticalExpert({...request(3.45,{self:{held:7,charge:.5}}),publicTerrain:{walls:[.4,8,8,8]}})
assert([3,4].includes(lateral.labels[0]));assert.equal(lateral.labels[2],0)
console.log('SUSTAINED_CONTACT_ENTRY_AND_LATERAL_GROUND_CONTROL_PASS')
// Native protocol left: +Z -> +X, +X -> -Z, -Z -> -X, -X -> +Z.
// Put a wall on that left side and require the right key in every rotation.
for(const [x,z,leftWall]of [[0,3.45,1],[3.45,0,2],[0,-3.45,0],[-3.45,0,3]]){
 const walls=[8,8,8,8];walls[leftWall]=.4
 const q={...request(3.45,{self:{held:7,charge:.5},seen:{x,z}}),publicTerrain:{walls}}
 const a=criticalExpert(q)
 assert.equal(a.labels[0],4,'visible left wall must select the actual right strafe key')
}
console.log('PROTOCOL_STRAFE_WORLD_GEOMETRY_FOUR_ROTATIONS_PASS')
// Counterexamples from the live exposure review: the target may still be
// rising in the last public sample, while its predicted critical is imminent.
const forecastRequest=request(3.1,{self:{held:7,charge:.15,attackAgeTicks:2},
 seen:{y:.8},context:{targetAirborne:true,targetCriticalThreat:true,
 targetVelocity:{x:0,y:.1,z:-.1},airEnvelope:{valid:true,criticalTick:4}}})
for(const dt of [0,1,2]){
 const a=criticalExpert({...forecastRequest,tick:100+dt},{lastAxeStrikeTick:98})
 assert.equal(a.labels[4],0,'low-charge spam cannot replace evading a forecast retaliation')
 assert.equal(forwardOf(a),-1,'keep clearing the threat instead of retreating for only one frame')
 assert.equal(a.labels[2],0);assert(a.reason.startsWith('avoid-forecast-retaliation-critical'))
}
const wallForecast={...forecastRequest,publicTerrain:{groundY:0,walls:[8,8,.4,8]}}
r=criticalExpert(wallForecast,{lastAxeStrikeTick:98})
assert.equal(r.labels[5],1);assert.equal(r.labels[4],0,'unavoidable close entry prepares sword without a fake interrupt')
r=criticalExpert({...forecastRequest,publicTerrain:{walls:[.4,.4,.4,.4]}},{lastAxeStrikeTick:98})
assert.equal(r.labels[0],0,'no invented route through an enclosed wall')
// A fresh rising enemy at the boundary can still be interrupted. No blanket
// rule forbids attacking airborne players or forces retreat after every hit.
r=criticalExpert(request(3.1,{self:{held:7,charge:.8,attackAgeTicks:16},seen:{y:.3},
 context:{targetAirborne:true,targetCriticalThreat:true,targetVelocity:{x:0,y:.35,z:-.2},
 airEnvelope:{valid:true,criticalTick:10}}}))
assert.equal(r.labels[4],2);assert.equal(forwardOf(r),1)
// An unusually fast separation can close the window even before the old
// hardcoded 2.65 centre-distance trigger; an already legal finish stays legal.
r=criticalExpert(request(2.5,{self:{held:0,charge:.7,attackAgeTicks:8,ground:false,wireFalling:true},
 context:{targetVelocity:{x:0,y:0,z:.5}}}),{lastSwordAttackTick:92})
assert.equal(r.labels[4],2);assert.equal(r.reason,'sword-last-legal-contact-before-separation')
r=criticalExpert(request(3.4,{self:{held:0,charge:.7,attackAgeTicks:8,ground:false,wireFalling:true},
 context:{targetVelocity:{x:0,y:0,z:.5}}}),{lastSwordAttackTick:92})
assert.equal(r.labels[4],0,'a last-hit lesson never authorizes an out-of-range swing')
console.log('FORECAST_RETALIATION_ESCAPE_AND_LAST_LEGAL_CONTACT_PASS')
const airborneExit=request(2.8,{self:{held:0,charge:1,attackAgeTicks:14,ground:false,wireFalling:false},
 seen:{y:.8},context:{targetAirborne:true,targetCriticalThreat:true,targetCriticalPossible:true,
 targetVelocity:{x:0,y:.04,z:.35},airEnvelope:{valid:true,criticalTick:1}}})
r=criticalExpert(airborneExit,{lastSwordAttackTick:86,closeExchangeActive:true})
assert.equal(r.labels[4],2);assert.equal(r.labels[5],1)
assert.equal(r.reason,'sword-last-legal-contact-before-separation','do not replace an airborne final contact with a ground-retreat lesson')
r=criticalExpert({...airborneExit,self:{...airborneExit.self,wireFalling:true}},
 {lastSwordAttackTick:86,closeExchangeActive:true})
assert.equal(r.labels[4],2);assert.equal(r.labels[1],0,'the same legal finish releases sprint when truly descending')
console.log('AIRBORNE_FINISH_NOT_OVERWRITTEN_BY_GROUND_ESCAPE_PASS')
const chainHistory={lastSwordAttackTick:90,closeExchangeActive:true}
r=criticalExpert(request(1.5,{self:{charge:.8,attackAgeTicks:10},seen:{shieldRaised:true,shield:false}}),{...chainHistory})
assert.equal(r.labels[5],1);assert.equal(r.labels[4],2)
assert.equal(r.reason,'sword-damage-before-public-shield-effective')
r=criticalExpert(request(1.5,{self:{charge:.8,attackAgeTicks:10},seen:{shieldRaised:true,shield:true}}),{...chainHistory})
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'effective shield uses the axe in an existing chain')
r=criticalExpert(request(3.1,{seen:{shieldRaised:true,shield:true}}))
assert.equal(r.labels[4],0,'the same shield is not a reason to initiate a distant break')
r=criticalExpert({...request(1.5,{self:{charge:.7,ground:false,wireFalling:true}}),jumpInputVersion:2},{...chainHistory})
assert.equal(r.labels[2],1,'v2 may hold jump for landing without inventing a midair jump')
console.log('SWORD_DAMAGE_SHIELD_WARMUP_AND_CONTINUATION_PASS')
for(const state of [{ground:true,vy:0},{ground:false,vy:.32}]){
 r=criticalExpert(request(1.8,{self:{...state,charge:.92,attackAgeTicks:11}}),{...chainHistory})
 assert.equal(r.labels[4],2,'ready close sword damage is not postponed through a whole ascent')
 assert.equal(r.labels[5],1);assert.equal(r.labels[1],0,'early close damage does not force sprint knockback')
 assert.equal(r.reason,'close-sword-early-useful-damage')
}
r=criticalExpert(request(1.8,{self:{ground:false,vy:.05,charge:1,attackAgeTicks:13}}),{...chainHistory})
assert.equal(r.labels[4],0,'an imminent own descent can still justify a short wait for a real critical')
r=criticalExpert(request(1.8,{self:{ground:true,charge:.92,attackAgeTicks:11},seen:{y:.7},
 context:{targetAirborne:true,targetCriticalThreat:true,targetCriticalPossible:true,targetVelocity:{x:0,y:-.25,z:-.1}}}),{...chainHistory})
assert.equal(r.labels[4],0,'early sword lesson does not force flat trades into a descending critical')
r=criticalExpert(request(1.8,{self:{ground:true,charge:.5,attackAgeTicks:4}}),{...chainHistory})
assert.equal(r.labels[4],0,'early damage is not per-tick ineffective clicking')
console.log('SWORD_EARLY_DAMAGE_WITH_SHORT_CRITICAL_WAIT_PASS')
for(const charge of [.12,.55,.89]){
 r=criticalExpert(request(3.4,{self:{held:7,charge,attackAgeTicks:Math.max(2,Math.round(charge*20))}}),{lastAxeStrikeTick:90})
 assert([3,4].includes(r.labels[0]));assert.equal(r.labels[4],0)
 assert.equal(r.labels[5],1,'spent opener returns to sword, without alternating weapon choices or low-charge clicks')
}
r=criticalExpert(request(3.1,{self:{held:7,charge:.5,attackAgeTicks:10},context:{targetVelocity:{x:0,y:0,z:-.22}}}),{lastAxeStrikeTick:90})
assert.equal(r.labels[4],0);assert.equal(r.labels[5],1)
r=criticalExpert(request(3.7,{self:{held:7,charge:.5,attackAgeTicks:10},context:{targetVelocity:{x:0,y:0,z:-.22}}}),{lastAxeStrikeTick:90})
assert.equal(r.labels[4],0);assert([3,4].includes(r.labels[0]),'approaching outside range does not trigger an empty interruption')
r=criticalExpert(request(4.6,{self:{held:7,charge:.7,attackAgeTicks:14}}),{lastAxeStrikeTick:86})
assert([3,4].includes(r.labels[0]),'safe separation permits lateral sword preparation, not endless flight')
console.log('AXE_RECOVERY_INTERCEPT_SINGLE_PLAN_PASS')
// Landing and cooldown failures observed in the latest human bouts.
for(const distance of [2.35,2.7,3.459]){
 const a=criticalExpert(request(distance,{self:{held:0,charge:.95,attackAgeTicks:12}}))
 assert.equal(a.labels[5],1,'retain the already charged sword at contact')
 assert.equal(a.labels[2],0,'a boundary first hit is not a distant critical jump')
 assert.equal(a.labels[4],distance<=3.3?2:0,'spend legal sword contact without inventing reach')
}
for(const charge of [.075,.175,.35]){
 const a=criticalExpert(request(3.1,{self:{held:7,charge,attackAgeTicks:4},
  context:{targetVelocity:{x:0,y:0,z:-.2}}}),{lastAxeStrikeTick:96})
 assert.equal(a.labels[4],0,'recent low-charge axe clicks do not restart recovery')
}
for(const distance of [2.7,3.1]){
 const a=criticalExpert(request(distance,{seen:{shield:true}}),{lastSwordAttackTick:95,closeExchangeActive:true})
 assert.equal(a.labels[4],0,'old sword history cannot justify an edge shield chase')
}
const trapped=request(2.48,{self:{held:7,charge:.075,attackAgeTicks:2},seen:{y:.5},
 context:{targetAirborne:true,targetCriticalThreat:true,targetCriticalPossible:true,
 targetVelocity:{x:0,y:-.25,z:-.18},airEnvelope:{valid:true,criticalTick:0}}})
r=criticalExpert(trapped)
assert.equal(r.labels[5],1);assert.equal(r.labels[4],0);assert.equal(forwardOf(r),1)
assert.equal(r.labels[2],0,'an unavoidable entry primes sword; it cannot grant an axe hit or distant jump')
// A sword hit before takeoff earns damage now; the jump recharges the next.
const rhythm={lastSwordAttackTick:80,closeExchangeActive:true}
r=criticalExpert({...request(1.8,{self:{held:0,charge:.95,attackAgeTicks:12}}),jumpInputVersion:2},rhythm)
assert.equal(r.labels[4],2);assert.equal(r.labels[2],1);assert.equal(r.labels[1],0)
r=criticalExpert({...request(1.8,{self:{held:0,charge:.95,attackAgeTicks:12,ground:false,wireFalling:true}}),jumpInputVersion:2},rhythm)
assert.equal(r.labels[4],2);assert.equal(r.labels[2],1);assert.equal(r.labels[1],0)
console.log('LANDING_SWORD_FIRST_CONTACT_REAL_KNOCKBACK_AND_EARLY_DAMAGE_RHYTHM_PASS')
// New sword-first curriculum: use the remaining pre-shield damage once,
// break an effective shield at low charge, return only after it clears.
const warm={lastSwordAttackTick:90,closeExchangeActive:true}
const warmRequest=request(1.6,{self:{held:0,charge:.15,attackAgeTicks:2},seen:{shieldRaised:true,shield:false}})
r=criticalExpert(warmRequest,warm)
assert.equal(r.labels[4],2,'an existing legal warm-up damage window can be spent before the axe switch')
observeLearnerInput(warm,warmRequest,{attackPacket:true,held:0})
r=criticalExpert({...warmRequest,tick:101,self:{...warmRequest.self,charge:.05,attackAgeTicks:1}},warm)
assert.equal(r.labels[4],0,'one shield warm-up cannot teach repeated weak sword clicks')
r=criticalExpert({...warmRequest,tick:102,seen:{...warmRequest.seen,shield:true}},warm)
assert.equal(r.labels[5],0);assert.equal(r.labels[4],2,'effective shield interrupts close combat: switch and attempt the break')
const attempted={...warm,lastShieldAxeTick:102}
r=criticalExpert({...request(1.6,{self:{held:7,charge:.05,attackAgeTicks:1},seen:{shieldRaised:true,shield:true}}),tick:103},attempted)
assert.equal(r.labels[5],0,'still-effective public shield is not evidence of a completed break')
r=criticalExpert({...request(1.6,{self:{held:7,charge:.05,attackAgeTicks:1},seen:{shieldRaised:false,shield:false}}),tick:104},attempted)
assert.equal(r.labels[5],1);assert.equal(r.labels[4],0,'public shield clearance permits immediate sword preparation without a weak switched hit')
for(const distance of [4,6,8]){
 const a=criticalExpert(request(distance,{self:{held:0,charge:1},context:{targetVelocity:{x:0,y:0,z:-.28}}}))
 assert.equal(a.labels[5],1,'a rushing enemy can be within one second despite a larger current gap')
}
assert.equal(criticalExpert(request(12,{self:{held:0,charge:1}})).labels[5],0)
console.log('SWORD_DEFAULT_ONE_SECOND_AND_SHIELD_RHYTHM_PASS')
