// Isolate the trainable movement/jump/weapon representation; no runtime rules.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy}from '../fresh-policy.js'
import {SharedAdam,loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
const [source,datasetFile,dest]=process.argv.slice(2)
assert(source&&datasetFile&&dest&&!fs.existsSync(dest))
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source)
const parent=JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json')))
assert(loaded.model.config.spatialMovementVersion===1&&!loaded.model.spatialControlIn)
const model=new DualPolicy({...loaded.model.config,spatialMovementHeads:[0,1,6,5,4,2],
  spatialControlSplitHeads:[0,2,5]},loaded.model.gateMode)
const adam=new SharedAdam(model.params,loaded.manifest.optimizer);adam.steps=loaded.adam.steps
const key=p=>p.name.split('.').slice(1).join('.')
const indexes=new Map(loaded.model.params.map((p,i)=>[key(p),i]))
let retained=0,checked=0,maxDelta=0
try{
  for(const[i,p]of model.params.entries()){
    const j=indexes.get(key(p));if(j===undefined)continue
    p.assign(loaded.model.params[j]);retained++
    for(const group of ['first','second']){adam[group][i].dispose();adam[group][i]=loaded.adam[group][j].clone()}
  }
  assert.equal(retained,loaded.model.params.length)
  model.spatialControlIn.w.assign(model.spatialMovementIn.w)
  model.spatialControlIn.b.assign(model.spatialMovementIn.b)
  const data=JSON.parse(fs.readFileSync(datasetFile))
  for(const t of data.trajectories.filter(t=>t.split==='validation').slice(0,4)){
    let a=loaded.model.initialState(),b=model.initialState()
    try{for(const f of t.frames.slice(0,32)){
      const x=advance(loaded.model,a,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures);a=x.state
      const y=advance(model,b,f.observation,true,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures);b=y.state
      const left=captureAutonomousImitation(loaded.model,x,f),right=captureAutonomousImitation(model,y,f)
      assert.deepEqual(left.actions,right.actions)
      for(let h=0;h<left.logits.length;h++)for(let j=0;j<left.logits[h].length;j++)
        maxDelta=Math.max(maxDelta,Math.abs(left.logits[h][j]-right.logits[h][j]))
      checked++
    }}finally{disposeState(a);disposeState(b)}
  }
  assert.equal(maxDelta,0)
  fs.mkdirSync(dest,{recursive:true})
  const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,adam,loaded.counters)
  const reloaded=loadDualCheckpoint(saved.manifest)
  try{for(let i=0;i<model.params.length;i++)assert.deepEqual(model.params[i].dataSync(),reloaded.model.params[i].dataSync())}
  finally{reloaded.adam.dispose();reloaded.model.dispose()}
  const receipt={schema:'split-spatial-control-extension-v1',source:path.resolve(source),sourceSha256:loaded.manifest.sha256,
    referenceCheckpoint:path.resolve(source),referenceSha256:loaded.manifest.sha256,dataset:path.resolve(datasetFile),
    functionPreserved:true,existingActiveWeightsPreserved:true,ppoOptimizerPreserved:true,retainedParameterTensors:retained,
    checkedFrames:checked,maxOutputDelta:maxDelta,imitationStepsSinceReference:0,checkpointRoundTripVerified:true,
    trainedBackbonesInAncestor:parent.allBackbonesTrained===true||parent.trainedBackbonesInAncestor===true,
    noOnlineCombatRuleAdded:true,saved}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt))
}finally{adam.dispose();model.dispose();loaded.adam.dispose();loaded.model.dispose()}
