"""Publish only the idle independent service, preserving the main MC process."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, runpy, shutil, subprocess, time
from importlib.machinery import SourceFileLoader

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
LIVE=ROOT/'work/wavedog-punengbho'
PS=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
audit=SourceFileLoader('pure_status',str(Path(__file__).with_name('integration-status.py'))).load_module()
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
parser=argparse.ArgumentParser();parser.add_argument('--candidate',type=Path)
parser.add_argument('--fresh-generation',action='store_true')
args=parser.parse_args()
status=audit.status(18776)
plugin=command('wavedog_punengbho status')
if status['actors'] or '对局=空闲' not in plugin or '汇总=false' not in plugin:
    raise RuntimeError('Independent bout/learning is active; no process stopped')
current=json.loads((LIVE/'model/checkpoint.json').read_text())
if current['sha256']!=status['checkpointSha256']:raise RuntimeError('Checkpoint changes have not settled')
source=json.loads((BASE/'before/model/checkpoint.json').read_text())
candidate=None
if args.candidate:
    candidate=json.loads(args.candidate.read_text())
    receipt=json.loads(args.candidate.with_name('receipt.json').read_text())
    if not receipt['offlineChecksPassed']:raise RuntimeError('Offline candidate rejected')
    tactics=args.candidate.with_name('tactic-checks.json')
    if args.candidate.parent.name=='calibrated' and (not tactics.exists()or not json.loads(tactics.read_text())['passed']):
        raise RuntimeError('Attack/jump/view preservation checks required before timing deployment')
    if args.candidate.parent.name=='opener-constrained':
        checks=args.candidate.with_name('cadence-checks.json')
        if not checks.exists()or not json.loads(checks.read_text())['passed']:
            raise RuntimeError('Weapon/attack preservation and recorded-state diagnostics required')
    origin=args.candidate.parent/'source/checkpoint.json'
    if not origin.exists():origin=args.candidate.parent.parent/'source/checkpoint.json'
    expectedSource=json.loads(origin.read_text())if origin.exists()else source
    if current['sha256']!=expectedSource['sha256']:raise RuntimeError('Preserve new independent learning; retraining/rebase required')
    if args.fresh_generation:
        if candidate['config'].get('generation')!='punengbho-clean-20261117' or not receipt.get('freshRandomInitialization'):
            raise RuntimeError('Explicit fresh-generation provenance required')
        if candidate['optimizer']['steps']!=0 or candidate['counters']['dualUpdates']!=0:
            raise RuntimeError('Fresh generation must not claim inherited PPO training')
    for key in (['lastRolloutSeq']if args.fresh_generation else ['dualUpdates','lastRolloutSeq']):
        if current['counters'][key]!=candidate['counters'][key]:raise RuntimeError('PPO progress differs')
    payload=args.candidate.with_name(candidate['binary']).read_bytes()
    if hashlib.sha256(payload).hexdigest()!=candidate['sha256']:raise RuntimeError('Candidate hash mismatch')
phase='trained-'+candidate['sha256'][:12] if candidate else 'runtime'
archive=BASE/f'pre-install-{phase}'
if archive.exists():archive=BASE/f'pre-install-{phase}-{datetime.now(timezone.utc).strftime("%H%M%S-%f")}'
archive.mkdir(exist_ok=False)
for name in ['checkpoint.json',current['binary']]:shutil.copy2(LIVE/'model'/name,archive/name)
identities=[]
for file,needle in [('client-process.json','protocol-punengbho.js'),('service-process.json','punengbho*dual-service.js')]:
    row=json.loads((LIVE/'runtime'/file).read_text());pid=int(row['pid'])
    script=f'Get-CimInstance Win32_Process -Filter "ProcessId={pid}" | Where-Object {{ $_.Name -eq "node.exe" -and $_.CommandLine -like "*{needle}*" }} | Select-Object ProcessId | ConvertTo-Json -Compress'
    out=subprocess.check_output([PS,'-NoProfile','-Command',script],text=True,encoding='utf8').strip()
    if not out or json.loads(out)['ProcessId']!=pid:raise RuntimeError('Independent process identity mismatch')
    identities.append(pid)
# Recheck immediately before stopping either process.
if audit.status(18776)['actors'] or '对局=空闲'not in command('wavedog_punengbho status'):
    raise RuntimeError('Bout started during preparation; leave it running')
for pid in identities:
    subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
time.sleep(1)
try:
    if candidate:
        (LIVE/'model'/candidate['binary']).write_bytes(payload)
        temporary=LIVE/'model/checkpoint.integration.tmp'
        temporary.write_bytes(args.candidate.read_bytes());os.replace(temporary,LIVE/'model/checkpoint.json')
    coach=LIVE/'model/coach';coach.mkdir(exist_ok=True)
    shutil.copy2(BASE/'teaching.json',coach/'operator-critical-defense.json')
    review=BASE/'qwen-teaching-review.json'
    if review.exists():
        with (coach/'shared-lessons.jsonl').open('a',encoding='utf8')as stream:
            stream.write(json.dumps(json.loads(review.read_text()),ensure_ascii=False)+'\n')
    runpy.run_path(str(LIVE/'start-service.py'),run_name='__main__')
    runpy.run_path(str(LIVE/'start-client.py'),run_name='__main__')
    actual=audit.status(18776)
    if actual.get('controlRegime')!='pure-model-all-input':raise RuntimeError('Wrong brain control regime')
    for name,expected in actual['runtimeSourceSha256'].items():
        if hashlib.sha256((ROOT/'work/pvp-dual-brain/punengbho'/name).read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Brain runtime hash mismatch')
    expected=candidate['sha256']if candidate else current['sha256']
    if actual['checkpointSha256']!=expected:raise RuntimeError('Published weights not loaded')
    expectedConfig=candidate['config']if candidate else current['config']
    if actual.get('config')!=expectedConfig:raise RuntimeError('Published action schema/config not loaded')
    for _ in range(30):
        result=command('wavedog_punengbho status')
        if '协议玩家=true'in result and '模型=true'in result:break
        time.sleep(.5)
    else:raise RuntimeError('Server did not confirm ready client')
    receipt={'at':datetime.now(timezone.utc).isoformat(),'phase':phase,'installed':True,
        'checkpointSha256':expected,'runtimeSourceSha256':actual['runtimeSourceSha256'],
        'client':json.loads((LIVE/'runtime/client-ready.json').read_text()),
        'independentWeights':True,'allInputsModelOwned':True,'oldRuntimeReplaced':True,
        'mainMinecraftRestarted':False,'mainWaveDogChanged':False,'allTacticsMastered':False}
    (BASE/f'install-{phase}-receipt.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps({'phase':phase,'installed':True,'sha256':expected,'mainMinecraftRestarted':False}))
except Exception as error:
    (BASE/f'install-{phase}-error.json').write_text(json.dumps({'error':str(error),'rollback':str(archive)}))
    raise
