"""Actual pilot bouts: four wall directions and retained close sword skills."""
from pathlib import Path
from importlib.machinery import SourceFileLoader
import argparse,json,math,runpy,subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
p=argparse.ArgumentParser();p.add_argument('--sha',required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--include-open-ground',action='store_true',help='Prepend two open-ground spacing bouts')
p.add_argument('--response-windows',action='store_true',help='Eight bouts focused on retaliation and contact exits')
p.add_argument('--start-index',type=int,default=0,help='Resume only the unattempted cases of an authorized suite')
a=p.parse_args()
if a.out.exists():raise RuntimeError('Preserve previous evidence')
a.out.mkdir(parents=True)
status=SourceFileLoader('purpose_status',str(HERE/'integration-status.py')).load_module()
recovery=SourceFileLoader('purpose_recovery',str(HERE/'audit-exchange-recovery.py')).load_module()
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
cases=[('edge-control',side,4,True)for side in ['east','west','north','south']]+[('critical','east',1.2,False),('combo-shield','east',1.5,False)]
if a.include_open_ground:cases=[('edge-control',side,4,False)for side in ['east','west']]+cases
if a.response_windows:
    if a.include_open_ground:raise ValueError('Response-window suite already includes open ground')
    cases=[('edge-control',side,4,False)for side in ['east','west']]
    cases += [('edge-control',side,4,True)for side in ['east','north']]
    cases += [('critical',side,3.4,False)for side in ['east','west']]
    cases += [('critical','east',1.2,False),('combo-shield','east',1.5,False)]
if not 0<=a.start_index<len(cases):raise ValueError('Start index outside planned suite')
trials=[]
for index,(mode,side,distance,wall)in enumerate(cases):
    if index<a.start_index:continue
    if status.status(18776)['checkpointSha256']!=a.sha:raise RuntimeError('Policy changed')
    label='墙边撤离与近敌面向 '+side if wall else '空旷场地地面控距 '+side if mode=='edge-control' else '预判下落威胁与散开后的重新接战 '+side if mode=='critical' and distance>3 else '保留剑连与切斧衔接'
    command('tellraw WaveJerry '+json.dumps({'text':f'[Punengbho 实测 {index+1}/{len(cases)}] '+label+'；记录实际表现，不以单次赢输判定完成。','color':'aqua'},ensure_ascii=True))
    cmd=['python',str(HERE/'run-main-trial.py'),'--mode',mode,'--seconds','25','--start-distance',str(distance),'--start-side',side,'--retain-learner-kit']
    if wall:cmd+=['--near-wall']
    if mode=='edge-control':cmd+=['--teacher-weapon','axe']
    if a.response_windows and mode=='critical' and distance>3:cmd+=['--rising-threat-probe']
    log=a.out/f'{index+1}-{mode}-{side}.log'
    with log.open('w',encoding='utf8')as f:subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
    records=[json.loads(s)for s in log.read_text().splitlines()if s.startswith('{')]
    summary=next(r for r in records if 'frameFile'in r)
    frames=[json.loads(s)for s in Path(summary['frameFile']).read_text().splitlines()]
    if any(f.get('policySha')!=a.sha for f in frames):raise RuntimeError('Mixed frame policy')
    r=recovery.audit(frames)
    near=0;back=0;ready=0;ready_back=0
    for f in frames:
        if f.get('owners',{}).get('movement')!='neural' or not f['seen'].get('visible'):continue
        c=f.get('command')or{};s,t=f['self'],f['seen']
        enemy_reach=math.sqrt(max(0,abs(s['x']-t['x'])-.3)**2+max(0,abs(s['z']-t['z'])-.3)**2+max(0,s['y']-t['y']-1.62,t['y']+1.62-s['y']-1.8)**2)
        facing_back=abs(c.get('aimYawOffset',0))>90
        if enemy_reach<=3.45 and not(t.get('shield')or t.get('shieldRaised')):near+=1;back+=int(facing_back)
        if s['held']==7 and s['charge']>=.9 and not(t.get('shield')or t.get('shieldRaised')):
            ready+=1;ready_back+=int(facing_back)
    result={'matchId':summary['matchId'],'mode':mode,'side':side,'nearWall':wall,'summary':summary,
        'wallRetreatFrames':len(r['modelRetreatIntoBlockedEscapeTicks']),
        'readyAxeRetreatFrames':len(r['readyAxeRetreatAgainstUnshieldedTicks']),
        'nearEnemyFrames':near,'nearEnemyBackFacingFrames':back,'readyAxeFrames':ready,'readyAxeBackFacingFrames':ready_back,
        'recovery':r}
    trials.append(result)
    (a.out/'report.json').write_text(json.dumps({'checkpointSha256':a.sha,'trials':trials,
        'plannedTotal':len(cases),'startIndex':a.start_index,'complete':len(trials)==len(cases)-a.start_index,
        'fullTacticalMastery':False},indent=2))
    print(json.dumps({k:v for k,v in result.items()if k not in ['summary','recovery']}),flush=True)
