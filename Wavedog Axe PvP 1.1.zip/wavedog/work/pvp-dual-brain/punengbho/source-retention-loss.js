// Supervised trust-region regularization. Preserve the source distribution
// while allowing demonstrated corrections; never selects live actions.
import * as tf from '@tensorflow/tfjs'
export function sourceRetentionLoss(logits,sourceLogits,heads,weight){
 if(!weight)return null
 const terms=heads.map(h=>{
  const oldLog=tf.logSoftmax(sourceLogits[h]),nextLog=tf.logSoftmax(logits[h])
  return tf.mean(tf.sum(tf.mul(tf.exp(oldLog),tf.sub(oldLog,nextLog)),1))
 })
 return terms.length?tf.mul(weight,tf.mean(tf.stack(terms))):null
}
