// Recorded-state diagnostics, never an online movement/attack controller.
// Command reversals are measurable here; real circling needs a live rollout.
import {radialMovement,viewTurns}from './movement-supervision-purpose.js'
import {outerEdgeSprintTarget,outerEdgeSprintDecision}from './outer-edge-sprint-supervision.js'
const sign=x=>x>.25?1:x<-.25?-1:0
const facing=a=>Math.abs(viewTurns[a[6]])<=15
export function recordActionFlow(stats,history,frame,actions){
  const l=frame.labels,s=frame.publicRequest?.self,reason=frame.expertReason||''
  if(!s||!Object.keys(l).length){history.previous=null;return}
  const add=(key,good)=>{const r=stats[key]||={count:0,correct:0};r.count++;r.correct+=Number(good)}
  const swordStrike=()=>actions[4]===2&&actions[5]===1&&facing(actions)
  const edge=outerEdgeSprintTarget(frame)
  if(edge){
    const good=outerEdgeSprintDecision(edge,actions)
    add('outerEdgeSprintStrike',good)
    if(edge.withinLastCentimetre)add('lastCentimetreSprintStrike',good)
  }
  let purpose=null
  if(reason==='axe-spacing-committed-recovery'){
    purpose='axe-recovery'
    add('committedAxeWithdrawal',radialMovement(actions)<-.25&&actions[1]===l[1]&&actions[2]===0&&actions[4]===0&&actions[5]===0
      &&(l[6]!==6||facing(actions)))
  }else if(reason==='axe-spacing-hold-clear-until-ready'){
    purpose='axe-clear-hold';add('stopWhenClear',Math.abs(radialMovement(actions))<=.25&&actions[4]===0&&actions[5]===0)
  }else if(['urgent-legal-interrupt-before-full-charge','charged-legal-rush-interrupt',
    'ordinary-emergency-interrupt-after-recovery'].includes(reason)&&l[4]===2){
    purpose='axe-intercept';add('pursuerInReachInterception',actions[4]===2&&actions[5]===0&&actions[2]===0&&facing(actions))
  }else if(reason==='close-sword-early-useful-damage'&&l[4]===2){
    purpose='sword-early';add('readySwordUsefulDamage',swordStrike())
  }else if(reason==='sword-last-legal-contact-before-separation'&&l[4]===2){
    purpose='sword-last';add('lastSwordContact',swordStrike()&&(!s.wireFalling||actions[1]===0))
  }else if(reason==='close-sword-critical-continuation'){
    purpose='sword-continuation'
    add('swordContinuationNoConflictingRetreat',radialMovement(actions)>=0&&facing(actions)&&actions[5]===1)
    if(l[4]===2)add('chargedSwordDescent',swordStrike()&&actions[1]===0)
  }else if(reason==='public-shield-axe-then-sword'&&l[4]===2){
    add('comboShieldAxeStrike',actions[5]===0&&actions[4]===2&&facing(actions))
  }else if(['post-shield-attempt-prime-sword-while-checking','public-shield-clear-restore-sword'].includes(reason)){
    add('primeSwordAfterShieldAttempt',actions[5]===1&&actions[4]===0)
  }
  if(reason==='post-shield-attempt-await-public-shield-state')
    add('unconfirmedShieldNoSwitchLoop',actions[5]===0&&actions[4]===0)
  const t=frame.publicRequest?.seen
  if(s.held===0&&l[2]===1&&l[5]===1&&frame.publicRequest.jumpInputVersion===2
      &&reason==='close-sword-critical-continuation')
    add(s.ground?'closeSwordLandingReadyJump':'closeSwordAirborneHeldJump',
      actions[2]===1&&actions[5]===1&&radialMovement(actions)>=0&&facing(actions))
  if(s.held===7&&Number.isFinite(s.charge)&&s.charge<.2&&!t?.shield&&l[4]===0)
    add('nearZeroAxeNoSpam',actions[4]!==2)
  if(s.held===0&&t?.visible&&!t.shield&&Math.hypot(t.x-s.x,t.z-s.z)<=3.65&&l[5]===1)
    add('dangerousGapRetainsSword',actions[5]===1)
  if(s.held===0&&!t?.shield&&!t?.shieldRaised&&frame.contactForecast?.valid
      &&Number.isFinite(frame.contactForecast.ticks)&&frame.contactForecast.ticks<=20&&l[5]===1)
    add('swordDefaultWithinOneSecond',actions[5]===1)
  if(reason==='spacing-wait-for-shield-release')
    add('spacingShieldNoForcedBreak',actions[4]!==2&&radialMovement(actions)<=.25)
  if(s.held===0&&s.ground&&l[4]===2&&l[2]===1&&!t?.shield)
    add('swordUsefulHitBeforeTakeoff',swordStrike()&&actions[2]===1&&actions[1]===l[1])
  if(s.held===0&&s.charge>=.85&&!t?.shield&&l[4]===2&&l[5]===1)
    add('readySwordContact',swordStrike()&&actions[1]===l[1])
  if(reason==='reachable-opponent-ascent-interrupt'&&l[4]===2)
    add('readyRisingInterrupt',actions[4]===2&&actions[5]===l[5]&&actions[2]===0&&facing(actions))
  const desired=sign(radialMovement(frame.actions)),actual=sign(radialMovement(actions)),old=history.previous
  if(purpose&&old?.purpose===purpose&&frame.tick===old.tick+1&&desired===old.desired){
    const r=stats.stablePurposeTransitions||={count:0,radialReversals:0,viewReversals:0}
    r.count++;r.radialReversals+=Number(actual*old.actual===-1)
    const delta=((viewTurns[actions[6]]-viewTurns[old.actions[6]]+540)%360)-180
    r.viewReversals+=Number(Math.abs(delta)>120)
  }
  history.previous={tick:frame.tick,purpose,desired,actual,actions:[...actions]}
}

// Additional offline release gates. These complement, and never relax, the
// existing per-skill and response-window preservation checks.
export function actionFlowChecks(before,after){
 const floors={nearZeroAxeNoSpam:.95,dangerousGapRetainsSword:.9,
  spacingShieldNoForcedBreak:.9,swordUsefulHitBeforeTakeoff:.85,readySwordUsefulDamage:.85,
  readySwordContact:.85,readyRisingInterrupt:.8,comboShieldAxeStrike:.8,primeSwordAfterShieldAttempt:.8,
  unconfirmedShieldNoSwitchLoop:.9,swordDefaultWithinOneSecond:.9,
  outerEdgeSprintStrike:.9,lastCentimetreSprintStrike:.9,
  closeSwordLandingReadyJump:.9,closeSwordAirborneHeldJump:.9}
 const checks={}
 for(const[key,floor]of Object.entries(floors)){
  const old=before[key],next=after[key]
  if(!old||old.count<5)continue
  checks[key+'Samples']=next?.count===old.count
  checks[key+'JointDecision']=Boolean(next?.count&&next.correct/next.count>=Math.max(floor,old.correct/old.count*.95))
 }
 const old=before.stablePurposeTransitions,next=after.stablePurposeTransitions
 if(old?.count>=5){
  checks.stablePurposeSamples=next?.count===old.count
  checks.radialReversalsNotIncreased=Boolean(next&&next.radialReversals<=old.radialReversals)
  checks.viewReversalsNotIncreased=Boolean(next&&next.viewReversals<=old.viewReversals)
 }
 return checks
}
