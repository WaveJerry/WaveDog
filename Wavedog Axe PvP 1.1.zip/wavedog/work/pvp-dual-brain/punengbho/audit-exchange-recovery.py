"""Describe real axe-recovery and axe-to-sword sequences, without training labels."""
from pathlib import Path
import argparse, json, math, statistics

def audit(frames, fighter='Punengbho'):
    packets={f['attackId']:f for f in frames if f.get('attackPacket') and f.get('attackId') is not None}
    events={}
    for f in frames:
        for e in f.get('nativeEvents',[]):
            key=(e.get('serverTick'),e.get('attackId'),e.get('attacker'),e.get('victim'),e.get('amount'))
            if not e.get('cancelled') and e.get('amount',0)>0: events[key]=(f,e)
    linked=[(packets[e['attackId']],e) for _,e in events.values()
        if e.get('attacker')==fighter and e.get('melee') and e.get('attackId') in packets]
    recoveries=[]
    for hit,e in linked:
        if hit.get('attackHeld')!=7 or hit['seen'].get('shield'): continue
        following=next((f for f in frames if f['tick']>hit['tick'] and f.get('attackPacket')),None)
        end=following['tick'] if following else frames[-1]['tick']
        segment=[f for f in frames if hit['tick']<f['tick']<=end]
        charging=[f for f in segment if f['self']['held']==7 and f['self']['charge']<.9]
        committed=[];closed=False
        for f in segment:
            if f['self']['held']!=7 or f['self']['charge']>=.9:break
            c=f.get('command')or{}
            dx=f['self']['x']-f['seen']['x'];dz=f['self']['z']-f['seen']['z'];d=math.hypot(dx,dz)
            walls=f.get('publicTerrain',{}).get('walls',[8,8,8,8])
            clearance=min(walls[0 if dx<0 else 1]*d/abs(dx)if abs(dx)>.01 else math.inf,
                walls[2 if dz<0 else 3]*d/abs(dz)if abs(dz)>.01 else math.inf)
            if clearance<1.2:closed=True;break
            if f.get('owners',{}).get('movement')!='neural':continue
            away=math.cos(math.radians(c.get('aimYawOffset',0)))<-.5
            executed=f.get('executed')or{}
            committed.append({'tick':f['tick'],'charge':f['self']['charge'],
                'forwardSprintAway':bool(away and executed.get('forward')and executed.get('sprint'))})
        retreat=[]
        for f in charging:
            c=f.get('command') or {}
            # Relative forward intent; actual travel is reported separately.
            if c.get('forward',0)*math.cos(math.radians(c.get('aimYawOffset',0)))<-.5: retreat.append(f)
        moved_away=0.0
        for a,b in zip(segment,segment[1:]):
            dx=a['seen']['x']-a['self']['x']; dz=a['seen']['z']-a['self']['z']; distance=math.hypot(dx,dz)
            if distance>0:
                moved_away+=max(0,-((b['self']['x']-a['self']['x'])*dx+(b['self']['z']-a['self']['z'])*dz)/distance)
        received=sum(d['amount'] for f,d in events.values() if d.get('victim')==fighter and hit['tick']<f['tick']<=end)
        ready=[f for f in segment if f['self']['held']==7 and f['self']['charge']>=.9
            and f.get('owners',{}).get('movement')=='neural']
        ready_retreat=[]
        for f in ready:
            c=f.get('command')or{}
            if c.get('forward',0)*math.cos(math.radians(c.get('aimYawOffset',0)))<-.5:
                ready_retreat.append(f['tick'])
        recoveries.append({'axeHitTick':hit['tick'],'reach':hit['observation']['reach'],
            'groundedAtHit':hit['self']['ground'],
            'observedEdgeCandidate':hit['self']['ground']and hit['observation']['reach']>=2.7,
            'damage':e['amount'],'chargingFrames':len(charging),'retreatIntentFrames':len(retreat),
            'mutuallyOutOfReachFrames':sum(bool(f['observation'].get('mutualOutOfReach')) for f in charging),
            'lateralIntentFrames':sum(abs((f.get('command')or{}).get('side',0))>.5 for f in charging),
            'observedAwayTravelIncludingKnockback':moved_away,'receivedBeforeNextAttack':received,
            'nextAttackTick':following['tick'] if following else None,
            'nextAttackWeapon':following.get('attackHeld') if following else None,
            'nextAttackCharge':following.get('attackCharge') if following else None})
        recoveries[-1].update(availableCommittedRecoveryFrames=len(committed),
            forwardSprintAwayFrames=sum(f['forwardSprintAway']for f in committed),
            interruptedRecoveryTicks=[f['tick']for f in committed if not f['forwardSprintAway']],
            recoveryStoppedAtBlockedEscape=closed,
            readyAxeFrames=len(ready),readyAxeStillRetreatingTicks=ready_retreat,
            firstReadyTick=ready[0]['tick']if ready else None,
            attackDelayAfterReadyTicks=following['tick']-ready[0]['tick']if ready and following else None,
            firstRetreatDelayTicks=next((f['tick']-hit['tick']for f in committed if f['forwardSprintAway']),None))
    transitions=[]
    for f in frames:
        if not (f.get('attackPacket') and f.get('attackHeld')==7 and f['seen'].get('shield')): continue
        following=[r for r in frames if 0<r['tick']-f['tick']<=40]
        release=next((r for r in following if not r['seen'].get('shield')),None)
        sword=next((r for r in following if r['self']['held']==0),None)
        strike=next((r for r in following if r.get('attackPacket') and r.get('attackHeld')==0),None)
        damage=next(((p,e) for p,e in linked if p.get('attackHeld')==0 and 0<p['tick']-f['tick']<=40),None)
        transitions.append({'axeAttemptTick':f['tick'],'publicShieldGoneTick':release['tick'] if release else None,
            'swordHeldTick':sword['tick'] if sword else None,'swordAttackTick':strike['tick'] if strike else None,
            'swordDamageTick':damage[0]['tick'] if damage else None,
            'swordDamage':damage[1]['amount'] if damage else None,
            'shieldDisappearanceAloneDoesNotProveDisable':True})
    ages=[f.get('timings',{}).get('modelActionAgeTicks') for f in frames]
    times=[f['timings']['observationToExecutionMs'] for f in frames if 'observationToExecutionMs' in f.get('timings',{})]
    blocked_retreat=[];ready_retreat=[]
    for f in frames:
        if f.get('owners',{}).get('movement')!='neural' or not f['seen'].get('visible'):continue
        c=f.get('command')or{}
        retreat=c.get('forward',0)*math.cos(math.radians(c.get('aimYawOffset',0)))<-.5
        if not retreat:continue
        s,t=f['self'],f['seen'];dx=s['x']-t['x'];dz=s['z']-t['z'];d=math.hypot(dx,dz)
        walls=f.get('publicTerrain',{}).get('walls',[8,8,8,8])
        clearance=min(walls[0 if dx<0 else 1]*d/abs(dx)if abs(dx)>.01 else math.inf,
            walls[2 if dz<0 else 3]*d/abs(dz)if abs(dz)>.01 else math.inf)
        if clearance<1.2:blocked_retreat.append(f['tick'])
        if s['held']==7 and s['charge']>=.9 and not(t.get('shield')or t.get('shieldRaised')):
            ready_retreat.append(f['tick'])
    return {'frames':len(frames),'sameFrameCommands':ages.count(0),'oneTickOldCommands':ages.count(1),
        'modelRetreatIntoBlockedEscapeTicks':blocked_retreat,
        'readyAxeRetreatAgainstUnshieldedTicks':ready_retreat,
        'medianObservationToExecutionMs':statistics.median(times) if times else None,
        'axeRecoveryExchanges':recoveries,'shieldAxeSwordAttempts':transitions,
        'descriptiveOnly':True,'fullTacticalMastery':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--suite',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists():raise RuntimeError('Preserve prior audit')
    suite=json.loads(a.suite.read_text());results=[]
    for t in suite['trials']:
        frames=[json.loads(s) for s in Path(t['summary']['frameFile']).read_text().splitlines()]
        results.append({'matchId':t['matchId'],'mode':t['mode'],**audit(frames)})
    a.out.write_text(json.dumps({'checkpointSha256':suite['checkpointSha256'],'trials':results},indent=2))
    for r in results:
        print(json.dumps({k:v for k,v in r.items() if k!='axeRecoveryExchanges'}))
