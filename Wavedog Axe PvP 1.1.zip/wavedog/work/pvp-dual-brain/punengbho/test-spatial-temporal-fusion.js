import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE}from '../fresh-policy.js'
import {advance,disposeState}from '../human-imitation.js'
await tf.setBackend('cpu');await tf.ready()
const config={fast:8,slow:16,heads:2,layers:4,ff:24,interval:2,memory:4,publicThreatInputs:12,
 spatialMovementVersion:1,spatialMovementHeads:[0,1,6,5,4,2],spatialControlSplitHeads:[0,2,5]}
const a=new DualPolicy(config),b=new DualPolicy({...config,spatialTemporalFusionVersion:1})
for(let i=0;i<a.params.length;i++)b.params[i].assign(a.params[i])
const observation=Array(OBS_SIZE).fill(.15),spatial=[1,.8,.8,.7,.7,.4,.9,.1],threat=[1,0,.2,.3,-.1,1,1,.25,1,.5,.3,0]
let sa=a.initialState(),sb=b.initialState()
try{
 for(let i=0;i<7;i++){
  const x=advance(a,sa,observation,true,null,null,spatial,threat);sa=x.state
  const y=advance(b,sb,observation,true,null,null,spatial,threat);sb=y.state
  assert.deepEqual(x.logits,y.logits,'zero migration preserves full sequence outputs')
 }
 const frozenJump=tf.tidy(()=>[...b.step(tf.tensor2d([observation]),sb,null,null,spatial,threat).logits[2].dataSync()])
 tf.tidy(()=>{for(const p of b.spatialTemporalOut)p.w.assign(tf.fill(p.w.shape,.025))})
 const evaluate=t=>tf.tidy(()=>{
  const x=tf.tensor2d([observation]),projected=b.projectPolicyInputs(x,null,t)
  const full=b.step(x,sb,null,null,spatial,t)
  const single=b.spatialMovementResidual(projected,spatial,t,full.state)
  const batched=b.spatialMovementResidualBatch(projected,tf.tensor2d([spatial]),tf.tensor2d([t]),full.state)
  single.forEach((p,i)=>assert.deepEqual(p.dataSync(),batched[i].dataSync(),'cache and live residual agree'))
  assert.deepEqual([...full.logits[2].dataSync()],frozenJump,'jump head is untouched')
  return full.logits.map(h=>[...h.dataSync()])
 })
 assert.notDeepEqual(evaluate(threat)[0],evaluate(Array(12).fill(0))[0],'raw forecast changes the learned spatial fusion')
 const grad=tf.variableGrads(()=>tf.tidy(()=>{
  const o=b.step(tf.tensor2d([observation]),null,null,null,spatial,threat)
  return tf.sum(tf.square(o.logits[0]))
 }),b.params)
 for(const name of ['spatial-movement-temporal-in','spatial-movement-temporal-out-0','fast','slow-0','slow-1','slow-2','slow-3'])
  assert(Object.entries(grad.grads).some(([k,v])=>k.includes('.'+name)&&v.dataSync().some(n=>Math.abs(n)>0)),name+' is differentiable')
 grad.value.dispose();Object.values(grad.grads).forEach(g=>g.dispose())
 // Missing temporal context must fail loudly instead of silently training a different policy.
 assert.throws(()=>tf.tidy(()=>b.spatialMovementResidualBatch(tf.tensor2d([observation]),tf.tensor2d([spatial]),tf.tensor2d([threat]))),/recurrent state/)
}finally{disposeState(sa);disposeState(sb);a.dispose();b.dispose()}
console.log('SPATIAL_TEMPORAL_PASS: zero migration, unchanged jump, forecast and recurrent gradients, cached/live equivalence')
