// Every protocol frame is visited in chronological chunks; none are sampled out.
export async function localReview (messages) {
  const response = await fetch('http://127.0.0.1:18765/v1/chat/completions', {
    method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(150000),
    body:JSON.stringify({model:'wavedog-tactics',temperature:.2,max_tokens:512,
      chat_template_kwargs:{enable_thinking:false},
      response_format:{type:'json_object',schema:{type:'object',properties:{
        focus:{type:'string',enum:['CRITICAL','COMBO','SHIELD','FREE']},
        lesson:{type:'string',maxLength:150}},required:['focus','lesson'],additionalProperties:false}},messages}) })
  if(!response.ok)throw Error('Qwen HTTP '+response.status)
  const payload=await response.json(),choice=payload.choices?.[0]
  if(choice?.finish_reason!=='stop')throw Error('Qwen review incomplete: '+choice?.finish_reason)
  const answer=JSON.parse(choice.message.content)
  if(!['CRITICAL','COMBO','SHIELD','FREE'].includes(answer.focus)||!answer.lesson?.trim())throw Error('Invalid Qwen review')
  return answer
}
export async function reviewProtocolFrames (row,append,lessons,cards,teaching) {
  const frames=row.frames||[],parts=[]
  if(!frames.length)throw Error('Protocol review needs ordered frames')
  const n=x=>Number.isFinite(x)?Math.round(x*100)/100:null
  for(let i=0;i<frames.length;){
    const chunk=[],tuples=[];let characters=0
    while(i+chunk.length<frames.length&&chunk.length<96){
      const f=frames[i+chunk.length]
      const tuple=[f.tick,f.mode,
      n(f.self.health),n(f.self.charge),Number(f.self.ground),n(f.self.vy),Number(f.self.shieldAvailable),Number(f.self.shielding),
      Number(f.seen.visible),f.seen.visible?n(f.seen.x-f.self.x):null,f.seen.visible?n(f.seen.z-f.self.z):null,
      f.seen.visible?n(f.seen.y-f.self.y):null,Number(f.seen.shield||false),f.seen.held,
      f.command?.forward,f.command?.side,Number(f.command?.sprint||false),Number(f.command?.jump||false),f.command?.slot,
      Number(f.attackPacket||false),n(f.nativeDealt||0),n(f.nativeReceived||0),f.owners?.attack,
      {eyeY:n(f.self.eyeY),velocity:[n(f.self.vx),n(f.self.vy),n(f.self.vz)],
        groundY:n(f.publicTerrain?.groundY),walls:f.publicTerrain?.walls?.map(n),
        reach:n(f.observation?.reach),targetYaw:n(f.seen.yaw),
        targetFacingDot:n(f.observation?.targetFacingDot),
        arrows:(f.seen.arrows||[]).map(a=>[a.id,n(a.x-f.self.x),n(a.y-f.self.y),n(a.z-f.self.z),
          n(a.vx),n(a.vy),n(a.vz),a.shooterId??null]),arrowThreat:f.observation?.arrowThreat||null},
      {controls:f.executed||{},owners:f.owners||{},offhand:f.offhand||null,
        offhandBusy:Boolean(f.offhandBusy),ranged:f.command?.ranged||null,
        rangedResult:f.rangedResult||{},packets:f.actualPackets||[],ignoredHeads:f.ignoredHeads||[]}]
      const size=JSON.stringify(tuple).length
      if(chunk.length&&characters+size>12000)break
      chunk.push(f);tuples.push(tuple);characters+=size
    }
    i+=chunk.length
    const answer=await localReview([{role:'system',content:'你是盾斧PVP复盘教练。按给定顺序逐帧分析，本分支从开局到结束全部由模型控制，按实际执行动作归因；出刀动作不是命中，未知信息不要猜。只输出JSON，lesson只写一句不超过60汉字的可验证结论，指出原因和下一步，不重复模板。'},
      {role:'user',content:JSON.stringify({matchId:row.matchId,chunk:parts.length,previous:parts.slice(-2),
        fields:['tick','owner_mode','own_hp','charge','ground','vy','shield_ready','shield_effective','target_visible','target_dx','target_dz','target_dy','target_shield','target_weapon','requested_forward','requested_side','requested_sprint','requested_jump','requested_slot','actual_attack_packet','native_dealt','native_received','attack_owner','public_environment','actual_execution'],frames:tuples})}])
    parts.push({from:chunk[0].tick,to:chunk.at(-1).tick,frames:chunk.length,...answer})
    append('protocol-review-chunks.jsonl',{at:new Date().toISOString(),matchId:row.matchId,...parts.at(-1)})
  }
  if(parts.reduce((n,p)=>n+p.frames,0)!==frames.length)throw Error('Qwen frame coverage mismatch')
  const answer=await localReview([{role:'system',content:'你是独立WaveDog_Punengbho大脑的局后教练。所有帧已经按序审阅，结合全局结果写下一局可检验目标。近战移动和出刀由GRU/Transformer选择；盾、弓弩、跳跃、出刀和移动也由模型选择，没有机械接管。学习极限距离击退打断、下落暴击威胁的躲避、惩罚暴击、剑连续暴击和地面连击；不强制固化一个招式。只输出JSON，lesson一句不超过60汉字，不声称已经学会。'},
    {role:'user',content:JSON.stringify({outcome:row.outcome,parts,previousLessons:lessons,playerExperience:cards,priorityTeaching:teaching})}])
  append('frame-review-receipts.jsonl',{at:new Date().toISOString(),matchId:row.matchId,
    frameCount:frames.length,reviewedFrames:parts.reduce((n,p)=>n+p.frames,0),chunks:parts.length,coverage:1})
  return answer
}
