import assert from 'node:assert/strict'
import {preservedDaggerBouts,daggerBoutSplit}from './dagger-splits.js'
const bout={sourceKind:'dagger-expert-relabel',matchId:'held-out',split:'validation',sourceSha256:'original'}
const prior=preservedDaggerBouts({trajectories:[bout]})
assert.equal(daggerBoutSplit(prior.get('held-out'),'original','train'),'validation',
  'Reordering old bouts must never move holdout data into gradient training')
assert.equal(daggerBoutSplit(undefined,'fresh','train'),'train')
assert.throws(()=>daggerBoutSplit(bout,'modified','train'),/raw trajectory changed/)
assert.throws(()=>preservedDaggerBouts({trajectories:[bout,{...bout,split:'train'}]}),/Conflicting/)
assert.equal(preservedDaggerBouts({trajectories:[{...bout,sourceKind:'exact-script-demonstration'}]}).size,0)
console.log('DAGGER_SPLIT_PRESERVATION_PASS')
