import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy}from '../fresh-policy.js'
import {loadDualCheckpoint,saveDualCheckpoint,SharedAdam}from '../fresh-optimizer-checkpoint.js'
const base=path.resolve('outputs/punengbho-integration-20261117')
const dest=path.join(base,'refinement');if(fs.existsSync(dest))throw Error('Preserve prior refinement')
fs.mkdirSync(dest)
const live=path.resolve('work/wavedog-punengbho/model/checkpoint.json')
const payload=fs.readFileSync(live),manifest=JSON.parse(payload)
const bytes=fs.readFileSync(path.join(path.dirname(live),manifest.binary))
if(crypto.createHash('sha256').update(bytes).digest('hex')!==manifest.sha256)throw Error('Source changed')
fs.mkdirSync(path.join(dest,'source'))
fs.writeFileSync(path.join(dest,'source/checkpoint.json'),payload)
fs.writeFileSync(path.join(dest,'source',manifest.binary),bytes)
const dataset=JSON.parse(fs.readFileSync(path.join(base,'whole-exchanges.json')))
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180],pitches=[-30,-10,-3,0,3,10,30]
const wrap=x=>((x+540)%360)-180
const nearest=(v,bins)=>bins.reduce((best,x,i)=>Math.abs(x-v)<Math.abs(bins[best]-v)?i:best,0)
let views=0,states=0,weapons=0
for(const trace of dataset.trajectories){
  const file=path.resolve('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/PvPFrameRecorder/bouts',trace.source)
  const raw=fs.readFileSync(file)
  if(crypto.createHash('sha256').update(raw).digest('hex')!==trace.sourceSha256)throw Error('Native evidence SHA mismatch')
  const rows=zlib.gunzipSync(raw).toString().trim().split('\n').map(l=>JSON.parse(l))
  if(rows.at(-1).type!=='end'||rows.at(-1).droppedGlobal!==0)throw Error('Incomplete recorder')
  const observed=new Map(rows.filter(r=>r.type==='frame').map(r=>[r.tick,r]))
  const jumps=new Set(rows.filter(r=>r.type==='action-event'&&JSON.stringify(r).toLowerCase().includes('jump')).map(r=>r.tick))
  for(const f of trace.frames){
    delete f.labels['6'];delete f.labels['7']
    const r=observed.get(f.tick),n=observed.get(f.tick+1),{self:s,seen:t}=f.publicRequest
    if(!r||!n)continue
    const current=r.self,next=n.self
    if(typeof next.sprint==='boolean'){
      f.labels['1']=f.labelEvidence.includes('native-confirmed-sword-critical')?0:Number(next.sprint)
      f.labelEvidence.push('consecutive-native-resulting-sprint-state');states++
    }
    if(s.ground&&next.ground&&!jumps.has(f.tick)&&!jumps.has(f.tick+1)&&f.labels['2']===undefined){
      f.labels['2']=0;f.labelEvidence.push('consecutive-grounded-without-native-jump')
    }
    const hand=current.main?.type
    if(['DIAMOND_SWORD','DIAMOND_AXE'].includes(hand)){
      f.labels['5']=hand==='DIAMOND_SWORD'?1:0
      f.labelEvidence.push('public-selected-melee-weapon');weapons++
    }
    if(!t.visible)continue
    const px=Math.max(t.x-.3+.0001,Math.min(t.x+.3-.0001,s.x))
    const pz=Math.max(t.z-.3+.0001,Math.min(t.z+.3-.0001,s.z))
    const py=Math.max(t.y+.0001,Math.min(t.y+1.8-.0001,s.eyeY))
    const dx=px-s.x,dz=pz-s.z,dy=py-s.eyeY
    const yaw=Math.atan2(-dx,dz)*180/Math.PI,pitch=-Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI
    for(const [h,value,bins]of [[6,wrap(next.yaw-yaw),turns],[7,next.pitch-pitch,pitches]]){
      if(!Number.isFinite(value))continue
      const a=nearest(value,bins)
      // Quantize the recorded desired view, never a fabricated perfect shot.
      f.labels[h]=a;views++
      f.labelEvidence.push('public-view-relative-to-visible-hitbox')
    }
  }
}
dataset.cameraActionSchema='pure-target-relative-v2'
dataset.learningPurpose='Expert whole-bout decisions with persistent held weapon, native sprint states, jump cadence, attack timing and target-relative view'
fs.writeFileSync(path.join(dest,'whole-exchanges.json'),JSON.stringify(dataset))
await tf.setBackend('cpu');await tf.ready()
const old=loadDualCheckpoint(path.join(dest,'source/checkpoint.json'))
const model=new DualPolicy({...old.model.config,pureAimVersion:2},old.model.gateMode)
const adam=new SharedAdam(model.params,old.manifest.optimizer);adam.steps=old.adam.steps
for(let i=0;i<model.params.length;i++){
  model.params[i].assign(old.model.params[i])
  for(const key of ['first','second']){adam[key][i].dispose();adam[key][i]=old.adam[key][i].clone()}
}
const saved=saveDualCheckpoint(path.join(dest,'initial/checkpoint.json'),model,adam,old.counters)
for(const x of [old,{model,adam}]){x.adam.dispose();x.model.dispose()}
fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify({sourceSha256:manifest.sha256,
  wholeExpertBouts:dataset.trajectories.length,nativeSourcesVerified:true,views,states,weapons,saved,
  exactUnobservedKeysNotClaimed:true,originalPpoPreserved:true,installed:false},null,2))
console.log(JSON.stringify({sourceSha256:manifest.sha256,views,states,weapons,saved}))
