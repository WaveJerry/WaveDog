// Offline, function-preserving extension of the existing GRU/GTrXL policy.
// Current public state gets a small LEARNED residual for jump/weapon/attack.
// Zero output weights preserve the original decisions before supervision.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy} from '../fresh-policy.js'
import {SharedAdam,loadDualCheckpoint,saveDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,validateDataset} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
const arg=k=>{const i=process.argv.indexOf(k);if(i<0)throw Error(k+' required');return path.resolve(process.argv[i+1])}
const source=arg('--source'),datasetFile=arg('--dataset'),dest=arg('--out')
if(fs.existsSync(dest))throw Error('Preserve prior checkpoint')
const parent=JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json')))
const referenceIndex=process.argv.indexOf('--reference-checkpoint')
const referenceCheckpoint=referenceIndex<0?(parent.referenceCheckpoint||source):path.resolve(process.argv[referenceIndex+1])
const referenceSha256=JSON.parse(fs.readFileSync(referenceCheckpoint)).sha256
const data=JSON.parse(fs.readFileSync(datasetFile));validateDataset(data)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source)
assert(referenceSha256===loaded.manifest.sha256||referenceSha256===parent.referenceSha256,
  'Reference must be the actual source or its verified ancestor')
const appendLocomotion=process.argv.includes('--append-locomotion')
const appendDirectional=process.argv.includes('--append-directional')
assert(!(appendLocomotion&&appendDirectional),'Select one extension')
if(appendDirectional)assert.deepEqual(loaded.model.config.actionContextHeads,[2,5,4,0,1])
else if(appendLocomotion)assert.deepEqual(loaded.model.config.actionContextHeads,[2,5,4])
else if(loaded.model.config.actionContextHeads)throw Error('Current-state extension already exists')
const model=new DualPolicy({...loaded.model.config,actionContextHeads:appendDirectional?[2,5,4,0,1,6,7,8]:appendLocomotion?[2,5,4,0,1]:[2,5,4],
  ...(process.argv.includes('--calibrate-context-bases')?{contextBaseCalibration:1}:{}),
  // Keep the immediate residual invariant to compass, arena walls, scripted
  // style hints and bout age. Both temporal branches still receive EVERYTHING.
  ...(process.argv.includes('--physical-context-features')?{actionContextFeatures:[
    ...Array.from({length:13},(_,i)=>i),...Array.from({length:14},(_,i)=>18+i),
    ...Array.from({length:12},(_,i)=>60+i),95,96,97]}:{})},loaded.model.gateMode)
const adam=new SharedAdam(model.params,loaded.manifest.optimizer);adam.steps=loaded.adam.steps
const key=p=>p.name.replace(/^dual\d+\./,'')
const indexes=new Map(loaded.model.params.map((p,i)=>[key(p),i]))
let retained=0,maxDelta=0,checked=0
try{
  for(const[i,p]of model.params.entries()){
    const old=indexes.get(key(p));if(old===undefined)continue
    p.assign(loaded.model.params[old]);retained++
    for(const group of ['first','second']){
      adam[group][i].dispose();adam[group][i]=loaded.adam[group][old].clone()
    }
  }
  assert.equal(retained,loaded.model.params.length,'every learned parameter must survive')
  for(const trace of data.trajectories.filter(t=>t.split==='validation').slice(0,3)){
    let oldState=loaded.model.initialState(),nextState=model.initialState()
    try{for(const f of trace.frames.slice(0,24)){
      const a=advance(loaded.model,oldState,f.observation,true,f.legalMasks,f.publicHealthFeatures);oldState=a.state
      const b=advance(model,nextState,f.observation,true,f.legalMasks,f.publicHealthFeatures);nextState=b.state
      const left=captureAutonomousImitation(loaded.model,a,f),right=captureAutonomousImitation(model,b,f)
      assert.deepEqual(left.actions,right.actions,'zero residual cannot change a decision')
      for(let h=0;h<left.logits.length;h++)for(let j=0;j<left.logits[h].length;j++)
        maxDelta=Math.max(maxDelta,Math.abs(left.logits[h][j]-right.logits[h][j]))
      checked++
    }}finally{disposeState(oldState);disposeState(nextState)}
  }
  assert(maxDelta<=1e-6,'zero residual must preserve the full distribution')
  fs.mkdirSync(dest,{recursive:true})
  const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,adam,loaded.counters)
  const receipt={schema:'zero-current-state-residual-extension-v1',source,sourceSha256:loaded.manifest.sha256,
    referenceCheckpoint,referenceSha256,
    imitationStepsSinceReference:referenceSha256===loaded.manifest.sha256?0:(parent.imitationStepsSinceReference??parent.best.steps),
    referenceBaseline:parent.baseline,trainedBackbonesInAncestor:parent.allBackbonesTrained===true||parent.trainedBackbonesInAncestor===true,
    appendedLocomotionHeads:appendLocomotion,
    appendedDirectionalHeads:appendDirectional,
    retainedParameterTensors:retained,newParameterTensors:model.params.length-retained,
    checkedFrames:checked,maxOutputDelta:maxDelta,functionPreserved:true,ppoOptimizerPreserved:true,
    noOnlineCombatRuleAdded:true,requiresSupervisedTrainingAndLiveAcceptance:true,saved}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
  console.log(JSON.stringify({sourceSha256:receipt.sourceSha256,sha256:saved.sha256,retainedParameterTensors:retained,
    newParameterTensors:receipt.newParameterTensors,checkedFrames:checked,maxOutputDelta:maxDelta,functionPreserved:true}))
}finally{adam.dispose();model.dispose();loaded.adam.dispose();loaded.model.dispose()}
