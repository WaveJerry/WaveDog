"""One real ordinary-player bout in unused cage 3; never controls human inputs."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,re,runpy,shutil,subprocess,time

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-integration-20261117'
RUNTIME=ROOT/'work/wavedog-punengbho/runtime'
PROBE=ROOT/'work/wavedog-protocol/runtime'
command=runpy.run_path(str(ROOT/'outputs/MC-Public/rcon_local.py'))['command']
def read_complete_json(file,timeout=5):
    deadline=time.monotonic()+timeout
    while True:
        try:return json.loads(file.read_text(encoding='utf-8'))
        except (FileNotFoundError,PermissionError,json.JSONDecodeError):
            if time.monotonic()>=deadline:raise
            time.sleep(.05)
parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['pressure','critical','combo-shield','edge-control','edge-mixed','bow','load','sync-check','break-follow','shield-recovery','critical-switch','shield','shield-cycle'],default='pressure')
parser.add_argument('--fighter',choices=['Punengbho'],default='Punengbho')
parser.add_argument('--seconds',type=int,default=25)
kit=parser.add_mutually_exclusive_group()
kit.add_argument('--melee-only',action='store_true')
kit.add_argument('--retain-learner-kit',action='store_true',
    help='Keep the learner shield/bow/crossbow; do not override model combat inputs')
parser.add_argument('--start-distance',type=float,default=1.5)
parser.add_argument('--start-side',choices=['east','west','north','south'],default='east')
parser.add_argument('--near-wall',action='store_true',help='Start inside cage 3 near its boundary for escape testing')
parser.add_argument('--rising-threat-probe',action='store_true',help='Defensive trial against a jumping opponent starting outside contact')
parser.add_argument('--record-teacher',action='store_true')
parser.add_argument('--bow-cancel-every',type=int,default=0,help='Cancel every Nth opponent draw by normal slot switch')
parser.add_argument('--shield-interrupt',action='store_true',help='Shield opponent periodically interrupts its own guard to strike')
parser.add_argument('--teacher-weapon',choices=['sword','axe'],default='sword')
parser.add_argument('--shield-cycle-offset',type=int,default=0)
parser.add_argument('--shield-cycle-weapon',choices=['sword','crossbow'],default='sword',
    help='Sampling opponent only; crossbow variant exposes public weapon/shield transitions without firing')
args=parser.parse_args()
if args.bow_cancel_every and (args.mode!='bow' or args.bow_cancel_every<2):
    raise ValueError('Bow cancellation requires bow mode and interval >= 2')
if args.shield_interrupt and args.mode!='shield':raise ValueError('Shield interrupt requires shield mode')
if args.shield_cycle_weapon!='sword' and args.mode!='shield-cycle':
    raise ValueError('Crossbow transition variant requires the shield-cycle sampling opponent')
if not 1<=args.start_distance<=10:raise ValueError('Start distance must be 1 to 10 blocks')
if args.rising_threat_probe and not(args.mode=='critical' and 3<=args.start_distance<=4):
    raise ValueError('Rising-threat probe requires critical opponent at 3 to 4 blocks')
if args.mode in ['critical','critical-switch']and args.start_distance>1.5 and not args.rising_threat_probe:
    raise ValueError('Critical-only practice starts within 1.5 blocks; use edge-control/edge-mixed for entry practice')
control='wavedog'if args.fighter=='WaveDog'else'wavedog_punengbho'
if args.fighter=='WaveDog':RUNTIME=PROBE
status=command(control+' status')
gate_deadline=time.monotonic()+10
while '对局=空闲'in status and '汇总=true'in status and time.monotonic()<gate_deadline:
    time.sleep(.25);status=command(control+' status')
if '对局=空闲'not in status or '汇总=false'not in status:raise RuntimeError('Independent bot busy')
gate=command('selfplay status')
desired=re.search(r'desired=(\d+)',gate)
if not desired or int(desired[1])>2 or 'singleLane=false'not in gate:
    raise RuntimeError('Cannot prove cage 3 is unused; existing training unchanged')
if 'WaveDogSon'in command('list'):raise RuntimeError('Existing probe player preserved')
command('kill @e[type=minecraft:item,x=1122.5,y=221,z=960.5,distance=..16]')
stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
dest=BASE/f'live-{args.mode}-{stamp}';dest.mkdir()
before={f.name for f in RUNTIME.glob('*-frames.jsonl')}
orders=PROBE/'probe-command.json';saved=orders.read_bytes()if orders.exists()else None
teacher_file=ROOT/'outputs/punengbho-rebuild-20261117/demonstrations'/f'{stamp}-{args.mode}.jsonl'
def write_order(payload):
    temporary=orders.with_name(f'.{orders.name}.{os.getpid()}.tmp')
    temporary.write_bytes(payload)
    os.replace(temporary,orders)

def order(active):
    row={'target':args.fighter,'active':active,'mode':args.mode,'slot':7 if args.teacher_weapon=='axe'else 0,'fire':args.mode=='sync-check',
         'requestedStartDistance':args.start_distance,'shieldCycleOffset':args.shield_cycle_offset,
         'shieldCycleWeapon':args.shield_cycle_weapon}
    if args.bow_cancel_every:row['bowCancelEvery']=args.bow_cancel_every
    if args.shield_interrupt:row['interrupt']=True
    if args.rising_threat_probe:row['risingThreatProbe']=True
    if active:row['matchId']=match
    if args.record_teacher and active:row.update(matchId=match,demonstrationFile=str(teacher_file))
    write_order(json.dumps(row).encode('utf8'))
environment=os.environ.copy();environment['WAVEDOG_PROBE_NAME']='WaveDogSon'
out=(dest/'probe.out.log').open('wb');err=(dest/'probe.err.log').open('wb')
order(False)
def spawn_probe():return subprocess.Popen([shutil.which('node'),str(ROOT/'work/pvp-player-client/protocol-wavedog-probe.js')],
    cwd=ROOT,env=environment,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
process=spawn_probe()
match=None;started=False
try:
    deadline=time.monotonic()+180;attempts=1
    def own_probe_ready():
        try:ready=json.loads((PROBE/'probe-ready.json').read_text())
        except(FileNotFoundError,json.JSONDecodeError):return False
        return ready.get('pid')==process.pid and ready.get('name')=='WaveDogSon' and 'WaveDogSon'in command('list')
    while not own_probe_ready():
        if process.poll()is not None:
            if attempts>=5:raise RuntimeError('Probe login failed five times; no combat claimed')
            time.sleep(4);process=spawn_probe();attempts+=1
            print(json.dumps({'stage':'probe-login-retry','attempt':attempts}),flush=True)
        if time.monotonic()>deadline:raise RuntimeError('Probe login timeout')
        time.sleep(.5)
    command('authme forcelogin WaveDogSon');time.sleep(1)
    command('gamemode survival WaveDogSon')
    sx,sz={'east':(1,0),'west':(-1,0),'north':(0,-1),'south':(0,1)}[args.start_side]
    teacher_offset=13.5-args.start_distance if args.near_wall else 0
    learner_offset=teacher_offset+args.start_distance
    start_yaw={'east':90,'west':-90,'north':0,'south':180}[args.start_side]
    command(f'tp WaveDogSon {1122.5+sx*teacher_offset} 221 {960.5+sz*teacher_offset} {(start_yaw+180)%360} 0')
    reply=command(control+' duel WaveDogSon')
    if '将在'not in reply:raise RuntimeError('Referee refused test: '+reply)
    started=True
    # Referee preparation only. The model still selects every combat input.
    # Keep model-owned ranged choices available in full-kit acceptance bouts.
    command(f'tp {args.fighter} {1122.5+sx*learner_offset} 221 {960.5+sz*learner_offset} {start_yaw} 0')
    if args.melee_only:
        for who in [args.fighter,'WaveDogSon']:
            command(f'item replace entity {who} weapon.offhand with minecraft:air')
            for item in ['bow','crossbow','arrow']:command(f'clear {who} minecraft:{item}')
    elif args.mode=='critical-switch':
        command('item replace entity WaveDogSon weapon.offhand with minecraft:air')
        for item in ['bow','crossbow','arrow']:command(f'clear WaveDogSon minecraft:{item}')
    elif args.mode in ['shield-cycle','combo-shield']:
        if not args.retain_learner_kit:
            command(f'item replace entity {args.fighter} weapon.offhand with minecraft:air')
        for who in [args.fighter,'WaveDogSon']:
            if who==args.fighter and args.retain_learner_kit:continue
            for item in ['bow','crossbow','arrow']:command(f'clear {who} minecraft:{item}')
    command('item replace entity WaveDogSon hotbar.0 with minecraft:diamond_sword')
    # Match the deployed observation/action vocabulary: axe=7, sword=0.
    # The stock kit also contains an axe in slot 4 (the model's crossbow slot).
    # Leaving that copy in place corrupts otherwise exact demonstration inputs.
    command('clear WaveDogSon minecraft:diamond_axe')
    command('item replace entity WaveDogSon hotbar.7 with minecraft:diamond_axe')
    if args.mode=='shield-cycle' and args.shield_cycle_weapon=='crossbow':
        command('item replace entity WaveDogSon hotbar.4 with minecraft:crossbow')
    if args.mode=='sync-check':
        command('item replace entity WaveDogSon hotbar.1 with minecraft:crossbow[charged_projectiles=[{id:"minecraft:arrow",count:1}]]')
    if args.mode=='load':
        # Preparation, before control starts: an empty crossbow on each side.
        # This exercises observed loading instead of the stock charged kit.
        for who in [args.fighter,'WaveDogSon']:
            command(f'clear {who} minecraft:crossbow')
            command(f'item replace entity {who} hotbar.4 with minecraft:crossbow')
    for slot,item in [('head','helmet'),('chest','chestplate'),('legs','leggings'),('feet','boots')]:
        command(f'item replace entity WaveDogSon armor.{slot} with minecraft:diamond_{item}')
    deadline=time.monotonic()+20
    while match is None:
        files=[f for f in RUNTIME.glob('*-frames.jsonl')if f.name not in before]
        if files:match=files[0].name[:36];break
        if time.monotonic()>deadline:raise RuntimeError('No frame journal')
        time.sleep(.2)
    # Enable the opponent as soon as the first active frame is saved. A five
    # second stationary-opponent head start is not a fair acceptance trial.
    order(True)
    print(json.dumps({'stage':'combat','matchId':match,'mode':args.mode,'realServer':True}),flush=True)
    deadline=time.monotonic()+args.seconds
    while time.monotonic()<deadline:
        if '对局=空闲'in command(control+' status'):break
        time.sleep(.5)
    if '对局=进行中'in command(control+' status'):command(control+' stop')
    order(False)
    report=RUNTIME/f'{match}-report.json'
    deadline=time.monotonic()+30
    while not report.exists():
        if time.monotonic()>deadline:raise RuntimeError('Completed frame save timeout')
        time.sleep(.5)
    row=read_complete_json(report);shutil.copy2(report,dest/report.name)
    if process.poll()is not None or row['outcome'].get('reason')=='disconnect':
        (dest/'invalid-trial.json').write_text(json.dumps({'reason':'scripted teacher disconnected',
            'teacherExitCode':process.poll(),'includeInDemonstrations':False}))
        raise RuntimeError('Teacher disconnected; partial raw trace retained, no completed demonstration claimed')
    if args.record_teacher and teacher_file.exists():
        with teacher_file.open('a',encoding='utf8')as stream:
            stream.write(json.dumps({'type':'end','matchId':match,'outcome':row['outcome'],
                'nativeFeedbackFrames':row['completedFrames'],'complete':True})+'\n')
    framefile=Path(row['completedFrames']);frames=[json.loads(line)for line in framefile.read_text().splitlines()]
    hits=[f for f in frames if f.get('attackPacket')]
    events=[e for f in frames for e in f.get('nativeEvents',[])]
    damage=[e for e in events if e.get('attacker')==args.fighter and not e.get('cancelled')and e.get('amount',0)>0]
    crits=[e for e in damage if e.get('nativeCritical')]
    attack_by_id={f['attackId']:f for f in hits if f.get('attackId')is not None}
    sword_crits=[];edge_axe=[];edge_sword=[];chain=longest=0;last_crit_tick=-1000
    for e in damage:
        attack=attack_by_id.get(e.get('attackId'))
        if not attack:continue
        if e.get('nativeCritical') and attack.get('attackHeld')==0:
            sword_crits.append(e)
            t=e['serverTick'];chain=chain+1 if t-last_crit_tick<=16 else 1
            longest=max(longest,chain);last_crit_tick=t
        else:chain=0
        if e.get('melee')and attack['self']['ground']and 2.7<=attack['observation']['reach']<=3:
            if attack.get('attackHeld')==7:edge_axe.append(e)
            if attack.get('attackHeld')==0:edge_sword.append(e)
    feedback=[e for f in frames for e in f.get('learningFeedback',[])]
    expired=sum(f.get('owners',{}).get('attack')=='neutral-expired'for f in frames)
    summary={'matchId':match,'frames':len(frames),'realServerVersion':'1.21.11','protocolVersion':'1.21.1 via installed compatibility',
        'scriptedOrdinaryProtocolOpponent':True,'opponentMode':args.mode,'meleeOnlyScenario':args.melee_only,
        'retainLearnerKit':args.retain_learner_kit,
        'actualAttacks':len(hits),'actualSwordAttacks':sum(f.get('attackHeld')==0 for f in hits),
        'nativeDamage':sum(e['amount']for e in damage),'nativeCriticals':len(crits),
        'nativeSwordCriticals':len(sword_crits),'longestSwordCriticalChain':longest,
        'nativeGroundedEdgeAxeHits':len(edge_axe),'nativeGroundedEdgeSwordHits':len(edge_sword),'controlLossFeedback':feedback,
        'requestedStartDistance':args.start_distance,
        'startSide':args.start_side,'nearWallStart':args.near_wall,
        'shieldCycleOffset':args.shield_cycle_offset if args.mode=='shield-cycle'else None,
        'shieldCycleWeapon':args.shield_cycle_weapon if args.mode=='shield-cycle'else None,
        'competitiveWinRateTrial':not(args.mode=='shield-cycle'and args.shield_cycle_weapon=='crossbow'),
        'samplingPurpose':'public-held-crossbow-shield-release-transitions'
            if args.mode=='shield-cycle'and args.shield_cycle_weapon=='crossbow'else None,
        'actualFirstFrameDistance':frames[0]['observation']['distance'],
        'fighter':args.fighter,
        'receivedDamage':sum(e.get('amount',0)for e in events if e.get('victim')==args.fighter and not e.get('cancelled')),
        'rangedExecutions':{k:sum(bool(f.get('rangedResult',{}).get(k))for f in frames)for k in ['useStarted','bowReleased','fireSent','loadReleased']},
        'rangedAimFrames':sum(bool(f.get('rangedAim'))for f in frames),
        'expiredFrames':expired,'expiredRatio':expired/max(1,len(frames)),
        'suppressed':{reason:sum(f.get('attackSuppressedReason')==reason for f in frames)
            for reason in set(f.get('attackSuppressedReason')for f in frames)if reason},
        'outcome':row['outcome'],'frameFile':str(framefile),'allTacticsMastered':False}
    shieldReceipts=PROBE/'probe-shield-receipts.jsonl'
    summary['opponentShieldDisableReceipts']=[r for line in shieldReceipts.read_text().splitlines()
        if line and(r:=json.loads(line)).get('matchId')==match]if shieldReceipts.exists()else[]
    summary['modelAxeAttacksAgainstVisibleShield']=sum(f.get('attackHeld')==7 and f['seen'].get('shield')for f in hits)
    summary['modelSwordPacketsAfterAxe']=sum(f.get('attackHeld')==0 and any(
        older.get('attackHeld')==7 and 0<f['tick']-older['tick']<=30 for older in hits)for f in hits)
    summary['risingThreatProbe']=args.rising_threat_probe
    if args.rising_threat_probe:
        summary['risingThreatStartVerified']=abs(summary['actualFirstFrameDistance']-args.start_distance)<.05
    elif args.mode=='critical':
        summary['criticalPracticeStartVerified']=abs(summary['actualFirstFrameDistance']-args.start_distance)<.05 and summary['actualFirstFrameDistance']<=1.55
    if args.mode in ['edge-control','edge-mixed']:
        teacherHits=[e for e in events if e.get('attacker')=='WaveDogSon'and not e.get('cancelled')and e.get('amount',0)>0]
        teacherPackets=PROBE/'probe-attacks.jsonl'
        startTime=datetime.strptime(stamp,'%Y%m%d-%H%M%S').replace(tzinfo=timezone.utc).timestamp()*1000
        from datetime import datetime
        teacherAttempts=[json.loads(line)for line in teacherPackets.read_text().splitlines()
            if line and json.loads(line).get('mode')==args.mode
            and json.loads(line).get('matchId',match)==match
            and datetime.fromisoformat(json.loads(line)['at'].replace('Z','+00:00')).timestamp()*1000>=startTime]
        summary['edgeTeacher']={'attempts':teacherAttempts,'nativeDamageHits':len(teacherHits),
            'nativeCriticals':sum(bool(e.get('nativeCritical'))for e in teacherHits),
            'rangeVerifiedFromPublicSnapshots':True,'serverConfirmedExactReach':False}
    (dest/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
    deadline=time.monotonic()+240
    training=RUNTIME/f'{match}-training.json'
    while not training.exists():
        if time.monotonic()>deadline:raise RuntimeError('PPO still pending; preserve service and trajectory')
        time.sleep(1)
    shutil.copy2(training,dest/training.name)
    train=read_complete_json(training);print(json.dumps({'stage':'evaluation'if train.get('trainingSkipped')else'learning','accepted':train.get('candidateAccepted'),
        'trainingSkipped':train.get('trainingSkipped',False),'evaluationFile':train.get('file'),
        'quarantined':train.get('quarantined'),'checkpointSha256':train.get('checkpointSha256'),
        'trajectorySha256':train.get('sha256'),'reasons':train.get('reasons')}),flush=True)
finally:
    order(False)
    if started and match:
        try:live=read_complete_json(RUNTIME/'client-state.json',2)
        except (FileNotFoundError,PermissionError,json.JSONDecodeError):live={}
        if live.get('active')and live.get('nativeSelf',{}).get('matchId')==match:
            command(control+' stop')
    if process.poll()is None:
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    out.close();err.close()
    if saved is not None:write_order(saved)
