import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {publicSpatialFeatures}from '../public-spatial-features.js'
import {criticalExpert,observeLearnerInput,sourceSha256 as expertSha256}from './joint-melee-expert.cjs'
import {directionalMovementSupervision}from './directional-movement-supervision.js'
import {retreatPurposeSupervision}from './retreat-purpose-supervision.js'
import {sustainableCloseContact}from './ground-contact-supervision.cjs'
import {validateDataset}from '../human-imitation.js'
const [input,output]=process.argv.slice(2)
if(!input||!output||fs.existsSync(output))throw Error('New input and output required')
const data=JSON.parse(fs.readFileSync(input)),audit={changedMovementLabels:0,omittedOldMovementLabels:0,unchangedOtherLabels:true}
const sha=crypto.createHash('sha256').update(fs.readFileSync(new URL('./retreat-purpose-supervision.js',import.meta.url))).digest('hex')
for(const trace of data.trajectories){
  const adviceByTick=new Map()
  if(trace.sourceKind==='dagger-expert-relabel'){
    trace.previousExpertSourceSha256=trace.expertSourceSha256
    trace.expertSourceSha256=expertSha256
    const history={}
    const raw=fs.readFileSync(path.join('work/wavedog-punengbho/runtime',trace.matchId+'-frames.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
    for(const r of raw){
      const req={tick:r.tick,self:r.self,seen:r.seen,publicTerrain:r.publicTerrain,publicActionContext:r.observation}
      const a=retreatPurposeSupervision(directionalMovementSupervision(criticalExpert(req,history),req),req)
      adviceByTick.set(r.tick,a)
      observeLearnerInput(history,req,{...r.executed,attackPacket:r.attackPacket,held:r.attackHeld??r.executedHeld})
    }
  }
  for(const f of trace.frames){
    f.publicSpatialFeatures=publicSpatialFeatures(f.publicRequest||{})
    const a=adviceByTick.get(f.supervisionTargetTick)
    if(a){
      const heads=process.argv.includes('--with-ground-control')?[0,1,6,4,5,2]:
        process.argv.includes('--with-contact-timing')?[0,1,6,4,5]:[0,1,6]
      for(const h of heads)if(a.labels[h]!==undefined&&f.legalMasks[h][a.labels[h]]!==false){
        if(f.labels[h]!==a.labels[h])audit.changedMovementLabels++
        f.labels[h]=a.labels[h];f.actions[h]=a.labels[h]
      }
      f.movementPurposeReason=a.reason;f.movementPurposeSourceSha256=sha
      if(heads.includes(4)){f.expertReason=a.reason;audit.unchangedOtherLabels=false}
    }else if(trace.sourceKind==='exact-script-demonstration'){
      const request=f.publicRequest,s=request?.self,t=request?.seen
      const knownDistant=t?.visible&&s&&Math.hypot(s.x-t.x,s.z-t.z)>=2.35
      const knownUnsupported=request?.publicActionContext?.sentPosition
        ?!sustainableCloseContact(request):knownDistant
      if(process.argv.includes('--with-ground-control')&&f.labels[2]===1
          &&s?.ground&&knownUnsupported){
        // Keep the actual demonstration intact. Superseded distant jump
        // starts are not positive examples for this new curriculum.
        f.omittedGroundContactLabels={2:f.labels[2]};delete f.labels[2]
      }
      // Keep factual evidence; obsolete back-facing near-threat controls are
      // removed only from movement supervision, never rewritten as executed.
      const g=f.publicSpatialFeatures
      if(g[0]&&(g[5]*8<=3.45||g[1]*8<.9)&&[0,12].includes(f.labels[6])){
        f.omittedMovementPurposeLabels={}
        for(const h of [0,1,6])if(h in f.labels){f.omittedMovementPurposeLabels[h]=f.labels[h];delete f.labels[h];audit.omittedOldMovementLabels++}
      }
    }
  }
}
validateDataset(data)
fs.mkdirSync(path.dirname(output),{recursive:true})
fs.writeFileSync(output,JSON.stringify(data))
fs.writeFileSync(output+'.audit.json',JSON.stringify({...audit,source:input,sha,rawObservationsChanged:false,wholeBoutSplitsPreserved:true,ppoEligible:false},null,2))
console.log(JSON.stringify(audit))
