import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
import {validateDataset}from '../human-imitation.js'
const file=process.argv[2]
if(!file)throw Error('Supply a real DAgger dataset')
const data=JSON.parse(fs.readFileSync(file));validateDataset(data)
let labeled=0
for(const trace of data.trajectories.filter(t=>t.sourceKind==='dagger-expert-relabel')){
  const raw=fs.readFileSync(path.resolve('work/wavedog-punengbho/runtime',trace.matchId+'-frames.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
  const byTick=new Map(raw.map(r=>[r.tick,r]))
  const rollout=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.resolve('work/wavedog-punengbho/model/evaluations',trace.matchId+'.json.gz'))))
  const obs=new Map(rollout.episode.map(r=>[r.decidedTick,r.observation]))
  for(const f of trace.frames){
    assert.deepEqual(f.observation,obs.get(f.tick),'no later observation may enter the input')
    assert.deepEqual(f.publicRequest.self,byTick.get(f.tick).self)
    assert.equal(f.ppoEligible,false)
    assert.equal(f.futureStateInObservation,false)
    if(Object.keys(f.labels).length){
      labeled++;assert.equal(f.supervisionTargetTick,f.tick+f.labelDelayTicks)
      assert(byTick.has(f.supervisionTargetTick),'no missing future labels may be invented')
    }
  }
}
assert(labeled>0)
console.log(JSON.stringify({result:'DAGGER_CAUSAL_INPUT_ALIGNMENT_PASS',labeledFrames:labeled}))
