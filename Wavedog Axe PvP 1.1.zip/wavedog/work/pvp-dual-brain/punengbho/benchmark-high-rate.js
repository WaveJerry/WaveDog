import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {OBS_SIZE,ACTION_WIDTHS} from '../fresh-policy.js'
const require=createRequire(import.meta.url)
const {createHighRateLoop,createHighRateControlGate,monoMs}=require('../../pvp-player-client/protocol-high-rate-loop')
const opt=(key,fallback)=>{const i=process.argv.indexOf(key);return i<0?fallback:process.argv[i+1]}
const output=path.resolve(opt('--output','outputs/full-model-86-20261118/frequency-benchmark.json'))
const checkpoint=path.resolve(opt('--checkpoint','work/wavedog-punengbho/model/checkpoint.json'))
const duration=Number(opt('--duration-ms',4000))
const summary=values=>{const a=values.filter(Number.isFinite).sort((x,y)=>x-y)
  const q=p=>a[Math.min(a.length-1,Math.floor(p*a.length))]??null
  return {count:a.length,p50:q(.5),p95:q(.95),p99:q(.99),max:a.at(-1)??null}}
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(checkpoint);loaded.adam.dispose()
const model=loaded.model,masks=ACTION_WIDTHS.map(n=>Array(n).fill(true))
const obs=Array(OBS_SIZE).fill(0);obs[31]=1;obs[2]=1;obs[97]=0
const tensors=s=>[s.fast,s.slow,...s.pending,...s.caches.flatMap(c=>c?[c.key,c.value]:[])].filter(Boolean)
const dispose=(s,next=null)=>{const keep=new Set(next?tensors(next):[]);for(const t of new Set(tensors(s)))if(!keep.has(t))t.dispose()}
let state=model.initialState(),revision=0
const steps=[],refines=[]
for(let i=0;i<100;i++){
 const at=performance.now(),previous=state
 state=tf.tidy(()=>{const out=model.step(tf.tensor2d([obs]),state,masks,[0,0,0,0,0],Array(8).fill(0),Array(12).fill(0));out.logits.forEach(h=>h.dataSync());return out.state})
 steps.push({ms:performance.now()-at,slowRefresh:!previous.slow||previous.frames%model.config.interval===0});dispose(previous,state)
}
for(let i=0;i<200;i++){
 const at=performance.now()
 tf.tidy(()=>model.refine(tf.tensor2d([obs]),state,masks,[0,0,0,0,0],Array(8).fill(0),Array(12).fill(0)).logits.forEach(h=>h.dataSync()))
 refines.push(performance.now()-at)
}
async function run(withInference){
 const rows=[],gate=createHighRateControlGate({apply:()=>{}}),matchId=withInference?'loaded':'idle',epoch=gate.reset(matchId)
 let errors=[],latest=null
 const loop=createHighRateLoop({hz:500,onCycle:r=>{
   rows.push(r);latest=r
   // The model command is a fixture. This tests scheduling, not combat.
   gate.publish({matchId,epoch,revision:r.serial,observationRevision:r.revision,atMs:monoMs(),command:{fixtureOnly:true}})
   gate.check(r,monoMs())
 },onError:e=>errors.push(String(e))})
 loop.reset(matchId)
 const started=monoMs()
 const sampleTimer=setInterval(()=>{
   const elapsed=monoMs()-started,tick=Math.floor(elapsed/50)
   loop.sample({matchId,revision:++revision,atMs:monoMs(),tick,source:'physics',
    self:{position:{x:0,y:0,z:0},sourceTick:tick,grounded:true},
    opponent:{position:{x:3.3+.2*Math.sin(elapsed/1000),y:0,z:0},sourceTick:tick,grounded:true}})
 },50)
 const inferenceTimer=withInference?setInterval(()=>{
   tf.tidy(()=>model.refine(tf.tensor2d([obs]),state,masks,[0,0,0,0,0],Array(8).fill(0),Array(12).fill(0)).logits.forEach(h=>h.dataSync()))
 },10):null
 await new Promise(resolve=>setTimeout(resolve,duration))
 clearInterval(sampleTimer);if(inferenceTimer)clearInterval(inferenceTimer)
 const elapsed=monoMs()-started;await loop.close()
 return {fixtureOnly:true,errors,durationMs:elapsed,cycles:rows.length,
  activeHz:rows.length>1?(rows.length-1)*1000/(rows.at(-1).analyzedAtMs-rows[0].analyzedAtMs):null,
  timerBackend:rows[0]?.timerBackend,
  deliveredHz:rows.length*1000/elapsed,workerIntervalMs:summary(rows.map(r=>r.intervalMs)),
  clientDeliveryMs:summary(rows.map(r=>r.deliveryMs)),latenessMs:summary(rows.map(r=>r.latenessMs)),
  analysisComputeMs:summary(rows.map(r=>r.computeMs)),missedDeadlines:latest?.missedDeadlines??null,
  controlGate:gate.counts}
}
try{
 const baseline=await run(false),underInference=await run(true)
 const report={at:new Date().toISOString(),targetHz:500,checkpointSha256:loaded.manifest.sha256,
  backend:tf.getBackend(),parameters:model.parameterCount(),mainServerTouched:false,modelChanged:false,
  syntheticGeometryOnly:true,fullNetworkStepMs:summary(steps.slice(16).map(x=>x.ms)),
  transformerRefreshMs:summary(steps.slice(16).filter(x=>x.slowRefresh).map(x=>x.ms)),
  fastStepMs:summary(steps.slice(16).filter(x=>!x.slowRefresh).map(x=>x.ms)),
  packetRefinementMs:summary(refines.slice(16)),baseline,underInference,
  guaranteed500Hz:false,combatControlVerified:false}
 fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,JSON.stringify(report,null,2));console.log(JSON.stringify(report))
}finally{dispose(state);model.dispose()}
