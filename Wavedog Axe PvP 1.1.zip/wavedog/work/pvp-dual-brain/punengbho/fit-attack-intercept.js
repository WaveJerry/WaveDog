// Fit one existing trainable attack intercept using TRAIN bouts only. The
// probability still depends on the full observation and recurrent context.
import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation,accumulate,finishStats,imitationClassWeights,validateDataset}from '../human-imitation.js'
import {attackSituation,exchangeAttackWeights}from '../exchange-imitation-weights.js'
const base=path.resolve('outputs/punengbho-integration-20261117'),src=path.join(base,'opener-cadence-absolute')
const constrained=process.argv.includes('--constrained')
const dest=path.join(base,constrained?'opener-constrained':'opener-calibrated');if(fs.existsSync(dest))throw Error('Preserve previous candidate')
fs.mkdirSync(dest)
const data=JSON.parse(fs.readFileSync(path.join(src,'whole-exchanges.json')))
const prior=JSON.parse(fs.readFileSync(path.join(src,'trained/receipt.json')))
const counts=validateDataset(data),weights=imitationClassWeights(data,counts,[1,2,4,5]).weights
weights.exchangeAttack=exchangeAttackWeights(data)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(path.join(src,'trained/checkpoint.json')),frames=[]
for(const trace of data.trajectories){
  let state=loaded.model.initialState()
  try{for(const frame of trace.frames){
    const raw=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures);state=raw.state
    frames.push({frame,split:trace.split,out:captureDeployedImitation(loaded.model,raw,frame)})
  }}finally{disposeState(state)}
}
const train=frames.filter(f=>f.split==='train'&&f.frame.labels['4']!==undefined)
function probability(logits,delta){
  const v=logits.map((x,i)=>x+(i===2?delta:0)),m=Math.max(...v)
  return Math.exp(v[2]-m)/v.reduce((sum,x)=>sum+Math.exp(x-m),0)
}
const grad=delta=>train.reduce((sum,f)=>{
  const action=f.frame.labels['4'],conditional=weights.exchangeAttack.weights[attackSituation(f.frame)]?.[action]??1
  const weight=weights['4']*conditional*(f.frame.supervisionWeight??1)
  return sum+weight*(probability(f.out.logits[4],delta)-Number(action===2))
},0)
let low=-10,high=10
for(let i=0;i<60;i++){const middle=(low+high)/2;if(grad(middle)>0)high=middle;else low=middle}
const optimum=(low+high)/2
let delta=optimum,quietBudget=null
if(constrained){
  const quiet=train.filter(f=>f.frame.labels['4']===0)
  const nll=d=>quiet.reduce((sum,f)=>{
    const logits=f.out.logits[4].map((v,i)=>v+(i===2?d:0)),m=Math.max(...logits)
    return sum+m+Math.log(logits.reduce((s,v)=>s+Math.exp(v-m),0))-logits[0]
  },0)/quiet.length
  // The constraint is fixed using TRAIN-only quiet-frame loss. Do not trade
  // away charge/aim restraint to optimize positive hit likelihood alone.
  quietBudget=Math.min(prior.before.train.labels['4:0'].nll,nll(0)+.025)
  let left=-10,right=10
  for(let i=0;i<60;i++){const mid=(left+right)/2;if(nll(mid)>quietBudget)right=mid;else left=mid}
  delta=Math.min(optimum,(left+right)/2)
}
const stats={train:{labels:{},drift:{}},validation:{labels:{},drift:{}}}
for(const f of frames){f.out.logits[4][2]+=delta;accumulate(stats[f.split],f.frame,f.out)}
for(const [split,s]of Object.entries(stats)){finishStats(s);s.drift=prior.after[split].drift}
const index=loaded.model.config.actionContextHeads.indexOf(4),layer=loaded.model.actionContextOut[index]
tf.tidy(()=>layer.b.assign(tf.add(layer.b,tf.tensor1d([0,0,delta,0,0]))))
const initial=loadDualCheckpoint(path.join(src,'source/checkpoint.json')),audit={}
for(let i=0;i<loaded.model.params.length;i++){
  const name=loaded.model.params[i].name.replace(/^dual\d+\./,'').split('.')[0]
  const a=loaded.model.params[i].dataSync(),b=initial.model.params[i].dataSync()
  const g=audit[name]||={parameters:0,changed:0,maxAbsDelta:0}
  for(let j=0;j<a.length;j++){g.parameters++;if(a[j]!==b[j])g.changed++;g.maxAbsDelta=Math.max(g.maxAbsDelta,Math.abs(a[j]-b[j]))}
}
const before=prior.before.validation,after=stats.validation
const checks={changedFast:prior.checks.changedFast,changedSlow:prior.checks.changedSlow,
  validationImproved:after.macroNll<before.macroNll&&after.labels['4:2'].nll<before.labels['4:2'].nll,
  unrelatedHeadDriftOK:prior.checks.unrelatedHeadDriftOK,
  noAttackTimingPreserved:after.labels['4:0'].nll<=before.labels['4:0'].nll+.03,
  actualJumpTimingPreserved:after.labels['2:1'].nll<=before.labels['2:1'].nll+.03,
  weapon0Preserved:after.labels['5:0'].nll<=before.labels['5:0'].nll+.03,
  weapon1Preserved:after.labels['5:1'].nll<=before.labels['5:1'].nll+.03}
const counters={...loaded.counters,humanImitationUpdates:loaded.counters.humanImitationUpdates+1}
const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),loaded.model,loaded.adam,counters)
const receipt={...prior,source:prior.source,sourceSha256:initial.manifest.sha256,saved,after:stats,checks,
  parameterAudit:audit,offlineChecksPassed:Object.values(checks).every(Boolean),
  calibration:{kind:'train-only-contextual-attack-intercept',delta,optimum,quietBudget,frames:train.length,
    validationLabelsUsedForFit:false,immediateSourceSha256:loaded.manifest.sha256,
    variable:'action-context-out-4.b[2]'},livePvpImprovementVerified:false}
fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2))
fs.mkdirSync(path.join(dest,'source'))
for(const name of ['checkpoint.json',initial.manifest.binary])fs.copyFileSync(path.join(src,'source',name),path.join(dest,'source',name))
for(const p of [loaded,initial]){p.adam.dispose();p.model.dispose()}
console.log(JSON.stringify({saved,checks,offlineChecksPassed:receipt.offlineChecksPassed,
  calibration:receipt.calibration,before:before.labels,after:after.labels}))
