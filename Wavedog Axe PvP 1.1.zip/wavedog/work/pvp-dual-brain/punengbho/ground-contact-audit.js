// Offline diagnostics on complete held-out bouts. No action is overridden.
export function recordGroundContact(stats,frame,actions){
 const s=frame.publicRequest?.self,t=frame.publicRequest?.seen
 if(!s||!t?.visible)return
 const add=(name,good)=>{const r=stats[name]||={count:0,correct:0};r.count++;r.correct+=Number(good)}
 const distance=Math.hypot(t.x-s.x,t.z-s.z)
 if(s.ground&&distance>=2.35&&!t.shield&&!t.shieldRaised)
  add('distantGroundedNoNewJump',actions[2]===0)
 if(s.ground&&frame.labels[2]===1)add('labeledCloseTakeoff',actions[2]===1)
 if(frame.expertReason?.startsWith('ground-control-')&&frame.labels[0]>=3)
  add('lateralGroundControl',actions[0]===frame.labels[0]&&actions[2]===0)
 if(frame.expertReason==='ground-control-legal-interrupt'&&frame.labels[4]===2)
  add('groundWeaponAttackJoint',actions[4]===2&&actions[5]===frame.labels[5])
 if(frame.labels[4]===2&&frame.labels[5]===1&&s.held===0&&s.wireFalling)
  add('retainedSwordDescentAttack',actions[4]===2&&actions[5]===1)
}
export function groundContactChecks(before,after){
 const rate=(s,k)=>s[k]?.count?s[k].correct/s[k].count:0
 const far='distantGroundedNoNewJump',near='labeledCloseTakeoff',side='lateralGroundControl',
  sword='retainedSwordDescentAttack',ground='groundWeaponAttackJoint'
 return {
  sufficientGroundContactSamples:[far,near,side,sword,ground].every(k=>after[k]?.count>=5),
  fewerDistantTakeoffs:1-rate(after,far)<=Math.max(.01,Math.min(.1,(1-rate(before,far))*.6)),
  closeTakeoffsPreserved:rate(after,near)>=Math.max(.6,rate(before,near)*.9),
  lateralGroundControlLearned:rate(after,side)>=.5,
  swordDescentAttacksPreserved:rate(after,sword)>=rate(before,sword)*.9,
  groundAttacksPreserved:rate(after,ground)>=rate(before,ground)*.9
 }
}
