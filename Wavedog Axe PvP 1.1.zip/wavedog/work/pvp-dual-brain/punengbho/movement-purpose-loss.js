import * as tf from '@tensorflow/tfjs'
import {supervisedWithdrawal}from './movement-supervision-purpose.js'
// Training-only geometric penalties on action probabilities, not a live veto.
// The exact causal frame supplies the obstacle/near-threat condition.
const forward=[0,1,-1,0,0,1,1,-1,-1],side=[0,0,0,-1,1,-1,1,-1,1]
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
export function movementPurposeLoss(rows,logits,weight){
  if(!(weight>0))return null
  const blocked=rows.map(r=>{const g=r.frame.publicSpatialFeatures;return Number(g?.[0]===1&&(g[1]*8<.9||g.slice(2,5).some(v=>v*8<.65)))})
  const nearby=rows.map(r=>{const g=r.frame.publicSpatialFeatures,s=r.frame.publicRequest?.self,t=r.frame.publicRequest?.seen;
    // A supervised ground escape from a forecast critical cannot also be
    // penalized for its necessary turn. Keep wall penalties and ordinary
    // near-opponent facing intact; this exception is training-only.
    // A committed axe recovery has the same necessary turn. A later legal
    // interception has an attack label and is NOT exempt. Wall costs stay.
    return Number(g?.[0]===1&&g[5]*8<=3.45&&[0,7].includes(s?.held)&&!t?.shield&&!t?.shieldRaised&&!supervisedWithdrawal(r.frame))})
  const terms=[]
  if(blocked.some(Boolean)){
    // Positive side means protocol right; at +90 degrees it points away
    // from the original opponent. Use the same projection as packet physics.
    const risk=tf.tensor3d(rows.map(r=>{const g=r.frame.publicSpatialFeatures||Array(8).fill(0)
      return forward.map((f,i)=>turns.map(a=>{
        const rad=f*Math.cos(a*Math.PI/180)-side[i]*Math.sin(a*Math.PI/180)
        const right=f*Math.sin(a*Math.PI/180)+side[i]*Math.cos(a*Math.PI/180)
        return Number(g[0]===1&&(rad<-.25&&g[1]*8<.9||rad>.25&&g[2]*8<.65
          ||right>.25&&g[3]*8<.65||right<-.25&&g[4]*8<.65))
      }))
    }))
    // Log safe mass keeps a gradient when a legacy head is confidently
    // pointing into a wall. A bounded risk-probability loss saturates there.
    const joint=tf.add(tf.expandDims(tf.logSoftmax(logits[0]),2),tf.expandDims(tf.logSoftmax(logits[6]),1))
    const safeLoss=tf.neg(tf.logSumExp(tf.add(joint,tf.mul(risk,-1e9)),[1,2]))
    terms.push(tf.div(tf.sum(tf.mul(tf.tensor1d(blocked),safeLoss)),blocked.reduce((n,x)=>n+x,0)))
  }
  if(nearby.some(Boolean)){
    const permitted=turns.map((a,i)=>Math.abs(a)<=90?i:-1).filter(i=>i>=0)
    const faceLoss=tf.neg(tf.logSumExp(tf.gather(tf.logSoftmax(logits[6]),permitted,1),1))
    terms.push(tf.div(tf.sum(tf.mul(tf.tensor1d(nearby),faceLoss)),nearby.reduce((n,x)=>n+x,0)))
  }
  return terms.length?tf.mul(weight,tf.addN(terms)):null
}
