import assert from 'node:assert/strict'
import {chooseAction}from './action-selection.js'
const p=[.85,0,.15]
assert.equal(chooseAction(p,true,()=>.99),0,'evaluation must not turn a low-probability click into an attack')
assert.equal(chooseAction(p,false,()=>.99),2,'PPO sampling must preserve the stochastic policy')
assert.equal(chooseAction(p,false,()=>.2),0)
assert.equal(chooseAction([.1,.2,.7],true),2,'no rule may override a learned attack preference')
console.log('EVALUATION_VS_PPO_SELECTION_PASS')
