import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {validateDataset,advance,disposeState,accumulate,finishStats} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
import {skillChecks} from './imitation-skill-checks.js'
import {recordGroundContact,groundContactChecks}from './ground-contact-audit.js'
import {recordResponseWindows,responseWindowChecks}from './response-window-audit.js'
import {policyFrame,comparisonFrame,airborneJumpFrame}from './policy-frame-masks.js'
import {recordActionFlow,actionFlowChecks}from './action-flow-audit.js'
const option=(key)=>{const i=process.argv.indexOf(key);if(i<0)throw Error('Missing '+key);return path.resolve(process.argv[i+1])}
const datasetFile=option('--dataset'),referenceFile=option('--reference'),candidateFile=option('--candidate'),dest=option('--out')
if(fs.existsSync(dest))throw Error('Preserve previous audit')
const data=JSON.parse(fs.readFileSync(datasetFile));validateDataset(data)
const referenceConfig=JSON.parse(fs.readFileSync(referenceFile)).config,candidateConfig=JSON.parse(fs.readFileSync(candidateFile)).config
const auditGroundContact=process.argv.includes('--ground-contact-audit')
const auditResponseWindows=process.argv.includes('--response-window-audit')
const auditActionFlow=process.argv.includes('--action-flow-audit')
const decisionDiffFile=process.argv.includes('--decision-diff')?option('--decision-diff'):null
if(decisionDiffFile&&fs.existsSync(decisionDiffFile))throw Error('Preserve previous decision diff')
const referenceDecisions=new Map(),decisionChanges=[]
await tf.setBackend('cpu');await tf.ready()
function evaluate(file,isReference=false,withoutThreat=false){
  const loaded=loadDualCheckpoint(file),stats={labels:{},drift:{}},byLesson={},byTacticalReason={},traces=[],groundContact={},responseWindows={}
  const airborneJump={labels:{},drift:{}},actionFlow={}
  try{
    for(const trace of data.trajectories.filter(t=>t.split==='validation')){
      const flowHistory={}
      let state=loaded.model.initialState(),teacherAttacks=0,autonomousAttacks=0,jointWeaponAttacks=0,labeledAttacks=0
      try{for(const originalFrame of trace.frames){
        const frame=policyFrame(originalFrame,loaded.model.config)
        const out=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures,frame.publicSpatialFeatures,
          withoutThreat?null:frame.publicThreatFeatures);state=out.state
        const captured=captureAutonomousImitation(loaded.model,out,frame)
        recordActionFlow(actionFlow,flowHistory,frame,captured.actions)
        if(decisionDiffFile&&!withoutThreat){
          const key=JSON.stringify([trace.source,frame.tick])
          if(isReference)referenceDecisions.set(key,captured.actions)
          else{
            const old=referenceDecisions.get(key)
            if(!old)throw Error('Missing paired reference frame '+key)
            const changedHeads=Object.keys(frame.labels).map(Number).filter(h=>old[h]!==captured.actions[h])
            if(changedHeads.length){
              const s=frame.publicRequest?.self,t=frame.publicRequest?.seen
              decisionChanges.push({source:trace.source,tick:frame.tick,lesson:trace.lesson,
                expertReason:frame.expertReason,changedHeads,
                regained:changedHeads.filter(h=>captured.actions[h]===frame.labels[h]),
                lost:changedHeads.filter(h=>old[h]===frame.labels[h]),
                labels:frame.labels,before:old,after:captured.actions,
                geometry:s&&t?.visible?{distance:Math.hypot(t.x-s.x,t.z-s.z),ground:s.ground,
                  held:s.held,charge:s.charge,falling:s.wireFalling,shield:t.shield||t.shieldRaised,
                  spatial:frame.publicSpatialFeatures}:null})
            }
          }
        }
        if(auditGroundContact)recordGroundContact(groundContact,frame,captured.actions)
        if(auditResponseWindows)recordResponseWindows(responseWindows,frame,captured.actions)
        const common=comparisonFrame(frame,referenceConfig,candidateConfig)
        accumulate(stats,common,captured)
        accumulate(byLesson[trace.lesson]||={labels:{},drift:{}},common,captured)
        accumulate(airborneJump,airborneJumpFrame(frame),captured)
        if(frame.expertReason){
          const reasons=[frame.expertReason],s=frame.publicRequest?.self,t=frame.publicRequest?.seen
          if(s?.held===7&&s.charge>=.9&&t?.visible&&!t.shield&&!t.shieldRaised
              &&frame.labels[0]===1&&frame.labels[6]===6)reasons.push('diagnostic-ready-axe-reengage')
          for(const reason of reasons){
            const r=byTacticalReason[reason]||={frames:0,heads:{},jointMovementWeaponViewCorrect:0,
              labeledAttacks:0,policyAttacks:0,jointWeaponAttacks:0};r.frames++
            if(frame.labels[4]===2){r.labeledAttacks++;r.policyAttacks+=Number(captured.actions[4]===2);
              r.jointWeaponAttacks+=Number(captured.actions[4]===2&&captured.actions[5]===frame.labels[5])}
            const selected=[0,1,5,6].filter(h=>frame.labels[h]!==undefined)
            r.jointMovementWeaponViewCorrect+=Number(selected.length===4&&selected.every(h=>captured.actions[h]===frame.labels[h]))
            for(const h of selected){
              const k=r.heads[h]||={count:0,correct:0};k.count++;k.correct+=Number(captured.actions[h]===frame.labels[h])
            }
          }
        }
        if(frame.labels[4]===2){
          labeledAttacks++;if(captured.actions[4]===2)autonomousAttacks++
          if(captured.actions[4]===2&&captured.actions[5]===frame.labels[5])jointWeaponAttacks++
          if(captured.teacherForced.logits[4].indexOf(Math.max(...captured.teacherForced.logits[4]))===2)teacherAttacks++
        }
      }}finally{disposeState(state)}
      traces.push({source:trace.source,lesson:trace.lesson,labeledAttacks,teacherForcedAttackRecall:teacherAttacks/Math.max(1,labeledAttacks),
        autonomousAttackRecall:autonomousAttacks/Math.max(1,labeledAttacks),jointWeaponAttackRecall:jointWeaponAttacks/Math.max(1,labeledAttacks)})
    }
    return {...finishStats(stats),airborneJump:finishStats(airborneJump),byLesson:Object.fromEntries(Object.entries(byLesson).map(([name,s])=>[name,finishStats(s)])),
      actionFlow,byTacticalReason,traces,...(auditGroundContact?{groundContact}:{}),...(auditResponseWindows?{responseWindows}:{})}
  }finally{loaded.adam.dispose();loaded.model.dispose()}
}
const baseline=evaluate(referenceFile,true),candidate=evaluate(candidateFile),checks={...skillChecks(baseline,candidate),
  ...(auditActionFlow?Object.fromEntries(Object.entries(actionFlowChecks(baseline.actionFlow,candidate.actionFlow))
    .map(([k,v])=>['actionFlow:'+k,v])):{}),
  ...(auditGroundContact?Object.fromEntries(Object.entries(groundContactChecks(baseline.groundContact,candidate.groundContact))
    .map(([k,v])=>['groundContact:'+k,v])):{}),
  ...(auditResponseWindows?Object.fromEntries(Object.entries(responseWindowChecks(baseline.responseWindows,candidate.responseWindows))
    .map(([k,v])=>['responseWindow:'+k,v])):{})}
const receipt={schema:'autonomous-conditional-imitation-audit-v1',dataset:datasetFile,reference:referenceFile,candidateFile,
  comparisonSemantics:'shared airborne combat labels; airborne jump key labels reported separately across input versions',
  candidateSha256:JSON.parse(fs.readFileSync(candidateFile)).sha256,
  referenceSha256:JSON.parse(fs.readFileSync(referenceFile)).sha256,
  datasetSha256:crypto.createHash('sha256').update(fs.readFileSync(datasetFile)).digest('hex'),
  causalThreatFeaturesUsed:data.policyObservationConfig?.publicThreatInputs===12,
  baseline,candidate,checks,passed:Object.values(checks).every(Boolean),usesPolicySelectedParents:true,
  offlineRecordedStateDiagnosticOnly:true,livePvpImprovementVerified:false,liveStateMutated:false}
receipt.auditActionFlow=auditActionFlow
if(process.argv.includes('--threat-input-ablation')){
  const absent=evaluate(candidateFile,false,true)
  receipt.threatInputAblation={sameWeights:true,noFutureOrLabelInput:true,zeroInput:absent,
    fullInputMeanNll:candidate.meanNll,zeroInputMeanNll:absent.meanNll}
}
fs.writeFileSync(dest,JSON.stringify(receipt,null,2))
if(decisionDiffFile)fs.writeFileSync(decisionDiffFile,JSON.stringify({schema:'paired-recorded-state-decisions-v1',
  datasetSha256:receipt.datasetSha256,referenceSha256:receipt.referenceSha256,candidateSha256:receipt.candidateSha256,
  offlineRecordedStateDiagnosticOnly:true,changes:decisionChanges},null,2))
console.log(JSON.stringify({passed:receipt.passed,failed:Object.keys(checks).filter(k=>!checks[k]),traces:candidate.traces}))
