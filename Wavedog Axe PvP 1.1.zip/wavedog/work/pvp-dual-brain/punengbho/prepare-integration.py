"""Freeze the independent brain and old sources before replacing implementations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil
from importlib.machinery import SourceFileLoader

ROOT = Path(__file__).resolve().parents[3]
DEST = ROOT/'outputs/punengbho-integration-20261117'
if DEST.exists(): raise RuntimeError('Existing integration must be continued, never overwritten')
audit = SourceFileLoader('pure_status', str(Path(__file__).with_name('integration-status.py'))).load_module()
status = audit.status(18776)
if status['actors']: raise RuntimeError('Wait for the current bout to finish')
model = ROOT/'work/wavedog-punengbho/model'
payload = (model/'checkpoint.json').read_bytes()
manifest = json.loads(payload)
binary = (model/manifest['binary']).read_bytes()
if hashlib.sha256(binary).hexdigest() != manifest['sha256'] or status['checkpointSha256'] != manifest['sha256']:
    raise RuntimeError('Model changed during snapshot')
(DEST/'before/model').mkdir(parents=True)
(DEST/'before/model/checkpoint.json').write_bytes(payload)
(DEST/'before/model'/manifest['binary']).write_bytes(binary)
for relative in ['work/pvp-dual-brain/punengbho','work/pvp-player-client/protocol-punengbho.js',
                 'work/pvp-player-client/protocol-pure-executor.js','work/pvp-player-client/protocol-pure-brain.js']:
    source=ROOT/relative; target=DEST/'before/source'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if source.is_dir(): shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'))
    else: shutil.copy2(source,target)
(DEST/'state.json').write_text(json.dumps({'startedAt':datetime.now(timezone.utc).isoformat(),
    'sourceSha256':manifest['sha256'],'independentModel':True,'deploymentTarget':'WaveDog_Punengbho',
    'oldImplementationWillBeReplaced':True,'oldImplementationRetainedOnlyAsInactiveRollback':True,
    'mainWaveDogModified':False,'installed':False,'allTacticsMastered':False},indent=2))
print(json.dumps({'snapshot':str(DEST),'sourceSha256':manifest['sha256']}))
