// Compare offline advice with the actual public states at mechanical handoff.
// Does not run bots, infer new weights, or claim counterfactual combat results.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import assert from 'node:assert/strict'
import {criticalExpert,observeLearnerInput,sourceSha256}from './joint-melee-expert.cjs'
import {directionalMovementSupervision}from './directional-movement-supervision.js'
import {learnerRequest}from './causal-learner-input.js'
const [reviewFile,out]=process.argv.slice(2)
assert(reviewFile&&out,'Review JSON and new output file required')
assert(!fs.existsSync(out),'Preserve previous audit')
const review=JSON.parse(fs.readFileSync(reviewFile)),episodes=[],totals={}
const add=(name,n=1)=>totals[name]=(totals[name]||0)+n
for(const episode of review.episodes){
 const bytes=fs.readFileSync(episode.source.path),rows=bytes.toString().trim().split('\n').map(JSON.parse)
 assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),episode.source.sha256)
 const history={},handoffs=[],problems=[]
 let neuralStart=null
 for(let i=0;i<rows.length;i++){
  const r=rows[i],request={...learnerRequest(r,{matchId:episode.matchId,
    opponent:episode.opponent??r.observedOpponentMotion?.opponent}),jumpInputVersion:2}
  const a=directionalMovementSupervision(criticalExpert(request,history),request),s=r.self,t=r.seen
  const d=Math.hypot(t.x-s.x,t.z-s.z),charge=s.charge
  if(r.mode==='NEURAL'&&rows[i-1]?.mode==='ESCAPE'){neuralStart=r.tick;add('handoffs')}
  if(r.mode!=='NEURAL')neuralStart=null
  if(r.mode==='NEURAL'&&t.visible){
   add('neuralFrames')
   if(a.labels[4]===2){
    add('advisedAttacks')
    if(!t.shield&&a.labels[1]===1&&charge<=.9){
     problems.push({tick:r.tick,issue:'weak-hit-labeled-sprint-knockback',charge,reason:a.reason})
    }
    if(!t.shield&&charge<.2){
     problems.push({tick:r.tick,issue:'near-zero-charge-click',charge,reason:a.reason})
    }
    if(!t.shield&&(a.labels[5]===0?s.held!==7:s.held!==0)){
     problems.push({tick:r.tick,issue:'switch-and-attack-uncharged',charge,reason:a.reason})
    }
   }
   if(s.held===0&&a.labels[5]===0&&!t.shield&&d<=3.65){
    problems.push({tick:r.tick,issue:'sword-discarded-in-dangerous-gap',distance:d,reason:a.reason})
   }
   if(neuralStart!==null&&r.tick-neuralStart<=8){
    handoffs.push({tick:r.tick,afterHandoff:r.tick-neuralStart,distance:d,charge,held:s.held,
     ground:s.ground,actualAttack:r.attackPacket,actualSlot:r.command?.slot,
     labels:a.labels,reason:a.reason,threat:r.observation?.targetCriticalThreat})
   }
  }
  observeLearnerInput(history,request,{...r.executed,attackPacket:r.attackPacket,held:r.attackHeld??s.held})
 }
 for(const p of problems)add(p.issue)
 episodes.push({matchId:episode.matchId,handoffs,problems,source:episode.source})
}
fs.mkdirSync(path.dirname(out),{recursive:true})
fs.writeFileSync(out,JSON.stringify({sourceSha256,totals,episodes,passed:episodes.every(e=>!e.problems.length),
 offlineSupervisionOnly:true,modelUpdated:false,liveCombatVerified:false},null,2))
console.log(JSON.stringify({totals,passed:episodes.every(e=>!e.problems.length),out}))
