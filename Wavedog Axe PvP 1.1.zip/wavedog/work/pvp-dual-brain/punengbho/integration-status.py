"""Read-only local service audit; never print credentials or command lines."""
from pathlib import Path
import json, socket

ROOT = Path(__file__).resolve().parents[3]

def status(port):
    with socket.create_connection(('127.0.0.1', port), timeout=15) as sock:
        sock.settimeout(30)
        sock.sendall((json.dumps({'command': 'model_status', 'requestId': 'pure-integration-audit'})+'\n').encode())
        stream = sock.makefile()
        while line := stream.readline():
            row = json.loads(line)
            if row.get('event') == 'model_status':
                return row
        raise RuntimeError('Service closed before status')

if __name__ == '__main__':
    result = {'service': status(18776)}
    for name in ['client-state', 'client-ready']:
        p = ROOT/'work/wavedog-punengbho/runtime'/f'{name}.json'
        if p.exists():
            row = json.loads(p.read_text(encoding='utf8'))
            result[name] = {k: row[k] for k in ['pid','protocol','active','mode','tick','controllerCode','sourceSha256'] if k in row}
    print(json.dumps(result))
