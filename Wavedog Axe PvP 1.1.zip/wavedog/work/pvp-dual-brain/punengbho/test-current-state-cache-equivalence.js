import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {OBS_SIZE} from '../fresh-policy.js'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation} from '../human-imitation.js'
const arg=k=>{const i=process.argv.indexOf(k);if(i<0)throw Error(k+' required');return path.resolve(process.argv[i+1])}
const source=arg('--source'),candidate=arg('--candidate'),dataset=JSON.parse(fs.readFileSync(arg('--dataset'))),outFile=arg('--out')
if(fs.existsSync(outFile))throw Error('Preserve cache equivalence proof')
await tf.setBackend('cpu');await tf.ready()
const a=loadDualCheckpoint(source),b=loadDualCheckpoint(candidate)
let checked=0,maxDelta=0
try{
  for(const trace of dataset.trajectories.filter(t=>t.split==='validation')){
    let sa=a.model.initialState(),sb=b.model.initialState()
    try{for(const frame of trace.frames){
      const left=advance(a.model,sa,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures);sa=left.state
      const right=advance(b.model,sb,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures);sb=right.state
      const base=captureDeployedImitation(a.model,left,frame),full=captureDeployedImitation(b.model,right,frame)
      const oldResidual=tf.tidy(()=>{
        const x=a.model.projectObservation(tf.tensor2d([frame.observation],[1,OBS_SIZE]),frame.publicHealthFeatures)
        const h=tf.tanh(a.model.actionContextIn.apply(a.model.projectActionContext(x)))
        return a.model.actionContextOut.map(layer=>[...layer.apply(h).dataSync()])
      })
      const residual=tf.tidy(()=>{
        const x=b.model.projectObservation(tf.tensor2d([frame.observation],[1,OBS_SIZE]),frame.publicHealthFeatures)
        const h=tf.tanh(b.model.actionContextIn.apply(b.model.projectActionContext(x)))
        return b.model.actionContextOut.map(layer=>[...layer.apply(h).dataSync()])
      })
      for(let h=0;h<base.logits.length;h++)for(let j=0;j<base.logits[h].length;j++){
        if(frame.legalMasks?.[h]?.[j]===false)continue
        const k=b.model.config.actionContextHeads.indexOf(h)
        const ci=[2,5].indexOf(h)
        const scale=b.model.contextBaseCalibration&&ci>=0
          ?2/(1+Math.exp(-b.model.contextBaseCalibration.dataSync()[ci])):1
        const oldScale=a.model.contextBaseCalibration&&ci>=0
          ?2/(1+Math.exp(-a.model.contextBaseCalibration.dataSync()[ci])):1
        const oldIndex=a.model.config.actionContextHeads.indexOf(h)
        const frozenBase=(base.logits[h][j]-(oldIndex<0?0:oldResidual[oldIndex][j]))/oldScale
        const cached=frozenBase*scale+(k<0?0:residual[k][j])
        maxDelta=Math.max(maxDelta,Math.abs(cached-full.logits[h][j]))
      }
      checked++
    }}finally{disposeState(sa);disposeState(sb)}
  }
  assert(maxDelta<1e-5,'cached correction must match full recurrent model inference')
  const r={passed:true,checkedFrames:checked,maxOutputDelta:maxDelta,sourceSha256:a.manifest.sha256,
    candidateSha256:b.manifest.sha256,fullRecurrentInferenceEquivalent:true,completeValidationBouts:true}
  fs.writeFileSync(outFile,JSON.stringify(r,null,2));console.log(JSON.stringify(r))
}finally{a.adam.dispose();a.model.dispose();b.adam.dispose();b.model.dispose()}
