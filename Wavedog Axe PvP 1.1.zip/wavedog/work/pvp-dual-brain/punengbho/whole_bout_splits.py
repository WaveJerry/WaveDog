"""Prevent opposite viewpoints of one actual match crossing data partitions."""
def require_whole_bout_splits(dataset):
    groups={}
    for trace in dataset['trajectories']:
        match=trace.get('matchId')
        if not match:raise ValueError('Every tactical training trajectory requires its actual matchId')
        groups.setdefault(match,set()).add(trace['split'])
    conflicts=sorted(match for match,splits in groups.items()if len(splits)>1)
    if conflicts:raise ValueError('Same match crosses train/validation: '+', '.join(conflicts))
    return {'checkedMatches':len(groups),'wholeMatchSplitsConsistent':True}
