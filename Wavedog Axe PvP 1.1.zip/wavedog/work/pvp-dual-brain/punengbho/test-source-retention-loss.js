import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {sourceRetentionLoss}from './source-retention-loss.js'
await tf.setBackend('cpu');await tf.ready()
const source=[tf.tensor2d([[6,-6],[-6,6]])],x=[tf.variable(tf.tensor2d([[-3,3],[3,-3]]))]
tf.tidy(()=>{
 assert.equal(sourceRetentionLoss(x,source,[0],0),null)
 assert(Math.abs(sourceRetentionLoss(source,source,[0],1).dataSync()[0])<1e-7)
 const r=tf.variableGrads(()=>sourceRetentionLoss(x,source,[0],1),x)
 assert(Number.isFinite(r.value.dataSync()[0])&&r.value.dataSync()[0]>0)
 const g=r.grads[x[0].name].arraySync()
 assert(g[0][0]<0&&g[0][1]>0&&g[1][0]>0&&g[1][1]<0,'penalty restores each source class, not a global preferred action')
})
x.forEach(t=>t.dispose());source.forEach(t=>t.dispose())
console.log('SOURCE_RETENTION_PASS: zero loss at reference, finite KL and bidirectional restoration gradients')
