import { ACTION_WIDTHS } from './fresh-policy.js'
const FORWARD=[0,1,-1,0,0,1,1,-1,-1],SIDE=[0,0,0,-1,1,-1,1,-1,1]
const SLOT=[7,0,1,4,-1],TURN=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
const PITCH=[-30,-10,-3,0,3,10,30]
export function legalMasks(req,config={}){
  const m=ACTION_WIDTHS.map(n=>Array(n).fill(true)),s=req.self||{}
  // v2 means a held jump KEY. Airborne players cannot double-jump, but may
  // hold the key for the next landing. Legacy checkpoints retain v1 masks.
  if(config.jumpInputVersion!==2&&s.ground===false)m[2][1]=false
  if(!s.shieldAvailable)m[4][1]=false
  if(!s.hasBow)m[5][2]=false
  if(!s.hasCrossbow)m[5][3]=false
  if(!s.hasBow&&!s.hasCrossbow)m[4][3]=false
  return m
}
export function decode(req,a,config={}){
  const seen=req.seen,self=req.self
  const relative=config.pureAimVersion===2&&seen?.visible&&self
  const half=.3,height=1.8,eyeY=Number.isFinite(self?.eyeY)?self.eyeY:self?.y+1.62
  const px=relative?Math.max(seen.x-half+.0001,Math.min(seen.x+half-.0001,self.x)):0
  const pz=relative?Math.max(seen.z-half+.0001,Math.min(seen.z+half-.0001,self.z)):0
  const py=relative?Math.max(seen.y+.0001,Math.min(seen.y+height-.0001,eyeY)):0
  const dx=px-self?.x,dz=pz-self?.z,dy=py-eyeY
  // The network selects a target-relative view primitive. Reusing a sampled
  // turn no longer accumulates 1/15/180 degrees on each frame and spins away.
  // Offset actions still allow all directions, deliberate misses and evasion.
  const yaw=relative?Math.atan2(-dx,dz)*180/Math.PI:req.yaw
  const pitch=relative?-Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI:req.pitch
  return {model:'DUAL-GRU-GTRXL',fighter:req.fighter,opponent:req.opponent,
    requestId:req.requestId,decidedTick:req.tick,focus:req.focus,
    yaw:yaw+TURN[a[6]],pitch:Math.max(-90,Math.min(90,pitch+PITCH[a[7]])),
    forward:FORWARD[a[0]],side:SIDE[a[0]],sprint:a[1]===1,jump:a[2]===1,
    sneak:a[3]===1,shield:a[4]===1,attack:a[4]===2,use:a[4]===3,release:a[4]===4,
    slot:SLOT[a[5]]<0?req.self.held:SLOT[a[5]],flightLook:a[8]===1&&a[4]===2,
    controlRegime:'pure-model-all-input',pureAimVersion:config.pureAimVersion||1,
    ...(relative?{aimYawOffset:TURN[a[6]],aimPitchOffset:PITCH[a[7]]}:{}),
    observedArrows:req.seen?.arrows?.length||0}
}
