// Held-out action combinations. Scores do not establish real combat success.
import {supervisedWithdrawal}from './movement-supervision-purpose.js'
const forward=[0,1,-1,0,0,1,1,-1,-1],side=[0,0,0,-1,1,-1,1,-1,1]
const turns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
export function recordResponseWindows(stats,frame,actions){
 const r=frame.publicRequest,s=r?.self,t=r?.seen,o=r?.publicActionContext,l=frame.labels
 if(!s||!t?.visible)return
 const add=(key,good)=>{const v=stats[key]||={count:0,correct:0};v.count++;v.correct+=Number(good)}
 const radial=a=>forward[a[0]]*Math.cos(turns[a[6]]*Math.PI/180)-side[a[0]]*Math.sin(turns[a[6]]*Math.PI/180)
 const wanted=frame.actions
 if(o?.targetCriticalThreat&&o.targetAirborne&&l[4]===0&&radial(wanted)<-.25)
  add('forecastThreatClearance',actions[4]!==2&&radial(actions)<-.25&&actions[2]===0)
 if(frame.expertReason==='sword-last-legal-contact-before-separation'&&l[4]===2)
  add('lastLegalSwordContact',actions[4]===2&&actions[5]===1&&(!s.wireFalling||actions[1]===0))
 if(s.ground&&l[4]===2&&l[1]===1&&forward[wanted[0]]>0&&!t.shield)
  add('jointGroundSprintStrike',actions[4]===2&&actions[1]===1&&forward[actions[0]]>0&&actions[5]===l[5])
 if(s.attackAgeTicks<4&&l[4]===0&&!t.shield)
  add('recentAttackNoSpam',actions[4]!==2)
 if(s.held===0&&s.wireFalling&&l[4]===2&&l[1]===0&&l[5]===1)
  add('jointSwordFallingStrike',actions[4]===2&&actions[1]===0&&actions[5]===1)
 if(s.ground&&o?.targetVelocity?.y>.08&&!t.shield&&!t.shieldRaised&&l[4]===2)
  add('opponentAscentInterrupt',actions[4]===2&&actions[5]===l[5]&&actions[2]===0&&Math.abs(actions[6]-6)<=2)
 if(s.held===0&&!s.ground&&s.wireFalling===false&&l[4]===0&&!t.shield)
  add('ownSwordAscentWait',actions[4]!==2)
 const g=frame.publicSpatialFeatures
 if(g?.[0]&&s.ground){
  const angle=turns[actions[6]]*Math.PI/180,rad=radial(actions),
   right=forward[actions[0]]*Math.sin(angle)+side[actions[0]]*Math.cos(angle)
  add('visibleWallRoute',!(rad<-.25&&g[1]*8<.9||rad>.25&&g[2]*8<.65||right>.25&&g[3]*8<.65||right<-.25&&g[4]*8<.65))
 }
 if(g?.[0]&&g[5]*8<=3.45&&!t.shield&&!supervisedWithdrawal(frame))
  add('nearThreatFacing',Math.abs(actions[6]-6)<=2)
}
export function responseWindowChecks(before,after){
 const rate=(s,k)=>s[k]?.count?s[k].correct/s[k].count:0
 const keys=['forecastThreatClearance','lastLegalSwordContact','jointGroundSprintStrike','recentAttackNoSpam','jointSwordFallingStrike','visibleWallRoute','nearThreatFacing']
 return Object.fromEntries([...keys.flatMap(k=>[[k+'Samples',(after[k]?.count||0)>=5],
  [k+'Preserved',rate(after,k)>=rate(before,k)*.95]]),
  ...['opponentAscentInterrupt','ownSwordAscentWait'].filter(k=>before[k]?.count)
    .map(k=>[k+'Preserved',rate(after,k)>=rate(before,k)*.95])])
}
