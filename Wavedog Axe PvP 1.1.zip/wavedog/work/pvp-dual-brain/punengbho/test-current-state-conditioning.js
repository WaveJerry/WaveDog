import fs from 'node:fs'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,captureDeployedImitation,validateDataset} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
import {conditionalAttackOffsets,autonomousCachedLogits} from './current-state-conditioning.js'

const arg=k=>{const i=process.argv.indexOf(k);assert(i>=0,k+' required');return process.argv[i+1]}
const dataset=JSON.parse(fs.readFileSync(arg('--dataset')));validateDataset(dataset)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(arg('--checkpoint'))
let checked=0,maxDelta=0,gradientChecked=false
try{
  for(const trace of dataset.trajectories.filter(t=>t.split==='validation')){
    let state=loaded.model.initialState()
    try{for(const frame of trace.frames){
      const output=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures)
      state=output.state
      const teacher=captureDeployedImitation(loaded.model,output,frame)
      const expected=captureAutonomousImitation(loaded.model,output,frame)
      tf.tidy(()=>{
        const row={frame}
        row.teacherAttackOffset=[...conditionalAttackOffsets(loaded.model,[row],[frame.actions]).dataSync()]
        const actual=autonomousCachedLogits(loaded.model,[row],teacher.logits.map(x=>tf.tensor2d([x])))
        for(let h=0;h<actual.length;h++)for(const[j,v]of actual[h].dataSync().entries())
          maxDelta=Math.max(maxDelta,Math.abs(v-expected.logits[h][j]))
        if(!gradientChecked&&frame.labels[4]===0){
          const attack=tf.variable(tf.tensor2d([teacher.logits[4]]))
          try{
            const {value,grads}=tf.variableGrads(()=>{
              const logits=teacher.logits.map((x,h)=>h===4?attack:tf.tensor2d([x]))
              return tf.neg(tf.logSoftmax(autonomousCachedLogits(loaded.model,[row],logits)[4]).slice([0,0],[1,1]).sum())
            },[attack])
            assert(Number.isFinite(value.dataSync()[0]))
            const g=[...grads[attack.name].dataSync()]
            assert(g.every(Number.isFinite)&&g[0]<0&&g.some((v,j)=>j>0&&v>0),
              'wait supervision must train the attack head through policy-selected parents')
            gradientChecked=true
          }finally{attack.dispose()}
        }
      })
      checked++
    }}finally{disposeState(state)}
  }
  assert(gradientChecked)
  assert(maxDelta<1e-5,'cached self-conditioned attack must match full deployed inference')
  const result={passed:true,checkedFrames:checked,maxOutputDelta:maxDelta,gradientChecked,
    checkpointSha256:loaded.manifest.sha256,completeValidationBouts:true,onlineCombatRulesChanged:false}
  fs.writeFileSync(arg('--out'),JSON.stringify(result,null,2));console.log(JSON.stringify(result))
}finally{loaded.adam.dispose();loaded.model.dispose()}
