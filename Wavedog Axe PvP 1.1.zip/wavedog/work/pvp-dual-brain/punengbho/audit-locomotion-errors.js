// Diagnostic only: separate inherited temporal logits from learned current-state
// corrections without changing weights, observations, labels or live controls.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,validateDataset} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
import {OBS_SIZE} from '../fresh-policy.js'
const arg=(k)=>{const i=process.argv.indexOf(k);if(i<0)throw Error(k+' required');return path.resolve(process.argv[i+1])}
const file=arg('--checkpoint'),datasetFile=arg('--dataset'),outFile=arg('--out')
if(fs.existsSync(outFile))throw Error('Preserve diagnostic evidence')
const bytes=fs.readFileSync(datasetFile),dataset=JSON.parse(bytes);validateDataset(dataset)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(file),groups={},examples=[]
let frames=0
const best=a=>a.indexOf(Math.max(...a))
try {
 for(const trace of dataset.trajectories.filter(t=>t.lesson==='shield-state-transitions')) {
  let state=loaded.model.initialState()
  try {for(const f of trace.frames){
   const o=advance(loaded.model,state,f.observation,true,f.legalMasks,f.publicHealthFeatures);state=o.state
   const result=captureAutonomousImitation(loaded.model,o,f)
   const [residual,hidden]=tf.tidy(()=>{
    const x=loaded.model.projectObservation(tf.tensor2d([f.observation],[1,OBS_SIZE]),f.publicHealthFeatures)
    const h=tf.tanh(loaded.model.actionContextIn.apply(loaded.model.projectActionContext(x)))
    return [loaded.model.actionContextOut.map(layer=>[...layer.apply(h).dataSync()]),[...h.dataSync()]]
   })
   for(const h of [0,1]) {
    const label=f.labels[h];if(label===undefined)continue
    const j=loaded.model.config.actionContextHeads.indexOf(h),correction=residual[j]
    const logits=result.logits[h],base=logits.map((v,k)=>v-correction[k])
    const predicted=result.actions[h],key=trace.split+':'+h+':'+label
    const g=groups[key]||={split:trace.split,head:h,label,n:0,correct:0,baseCorrect:0,correctionCorrect:0,
      errorBaseMargin:0,errorCorrectionMargin:0,errorCount:0,saturatedFraction:0}
    g.n++;g.correct+=Number(predicted===label);g.baseCorrect+=Number(best(base)===label)
    g.correctionCorrect+=Number(best(correction)===label)
    g.saturatedFraction+=hidden.filter(v=>Math.abs(v)>.97).length/hidden.length
    if(predicted!==label){
     g.errorCount++;g.errorBaseMargin+=base[predicted]-base[label]
     g.errorCorrectionMargin+=correction[predicted]-correction[label]
     if(trace.split==='validation'&&label===1&&examples.filter(e=>e.head===h).length<12)
      examples.push({source:trace.source,tick:f.tick,head:h,label,predicted,
       base:base.slice(0,h===0?3:2),correction:correction.slice(0,h===0?3:2),
       reason:f.expertReason,targetHeld:f.publicRequest.seen.held,
       targetShield:f.publicRequest.seen.shield,held:f.publicRequest.self.held,
       age:f.publicRequest.self.attackAgeTicks})
    }
   }
   frames++
  }}finally{disposeState(state)}
 }
 const rows=Object.values(groups).map(g=>({...g,recall:g.correct/g.n,baseRecall:g.baseCorrect/g.n,
  residualOnlyRecall:g.correctionCorrect/g.n,saturatedFraction:g.saturatedFraction/g.n,
  errorBaseMargin:g.errorCount?g.errorBaseMargin/g.errorCount:0,
  errorCorrectionMargin:g.errorCount?g.errorCorrectionMargin/g.errorCount:0}))
 const report={checkpointSha256:loaded.manifest.sha256,datasetSha256:crypto.createHash('sha256').update(bytes).digest('hex'),
  frames,diagnosticOnly:true,trainingPerformed:false,groups:rows,examples}
 fs.writeFileSync(outFile,JSON.stringify(report,null,2));console.log(JSON.stringify(report))
} finally {loaded.adam.dispose();loaded.model.dispose()}
