// Learned neural residuals on causal geometry/threat and frozen recurrent
// features. No distance threshold, action override or online controller here.
import * as tf from '@tensorflow/tfjs'
import {OBS_SIZE}from '../fresh-policy.js'

export function jointResidualParameters(model){
 return [...model.actionContextIn.params,...model.actionContextOut.flatMap(l=>l.params),
  ...(model.contextBaseCalibration?[model.contextBaseCalibration]:[]),
  ...model.spatialMovementIn.params,...model.spatialMovementOut.flatMap(l=>l.params),
  ...(model.spatialControlIn?.params||[]),...(model.spatialTemporalIn?.params||[]),
  ...(model.spatialTemporalRouteIn?.params||[]),...(model.spatialTemporalOut?.flatMap(l=>l.params)||[])]
}
export function jointPolicyResiduals(model,rows){
 const input=tf.tensor2d(rows.map(r=>r.projected),[rows.length,OBS_SIZE]),
  selected=model.projectActionContext(input),context=tf.tanh(model.actionContextIn.apply(selected))
 const result=model.actionContextOut.map((layer,i)=>layer.apply(
  model.config.actionContextHeads[i]===4&&model.attackContextMask
   ?tf.tanh(model.actionContextIn.apply(tf.mul(selected,model.attackContextMask))):context))
 const spatial=tf.tensor2d(rows.map(r=>r.frame.publicSpatialFeatures),[rows.length,8]),
  threat=model.spatialTemporalIn?tf.tensor2d(rows.map(r=>r.frame.publicThreatFeatures),[rows.length,12]):null,
  recurrent=model.spatialTemporalIn?{fast:tf.tensor2d(rows.map(r=>r.recurrent.fast)),
   slow:tf.tensor2d(rows.map(r=>r.recurrent.slow))}:null
 const side=model.spatialMovementResidualBatch(input,spatial,threat,recurrent)
 for(const[i,h]of model.spatialMovementHeads.entries()){
  const j=model.config.actionContextHeads.indexOf(h)
  if(j<0)throw Error('Spatial head is absent from joint context outputs')
  result[j]=tf.add(result[j],side[i])
 }
 return result
}
