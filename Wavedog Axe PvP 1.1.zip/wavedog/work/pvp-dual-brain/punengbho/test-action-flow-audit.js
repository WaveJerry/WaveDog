import assert from 'node:assert/strict'
import {recordActionFlow,actionFlowChecks}from './action-flow-audit.js'
const frame={tick:1,expertReason:'axe-spacing-committed-recovery',
 labels:{0:1,1:1,2:0,4:0,5:0,6:0},actions:[1,1,0,0,0,0,0,3,0],publicRequest:{self:{ground:true}}}
const stats={},h={}
recordActionFlow(stats,h,frame,frame.actions)
recordActionFlow(stats,h,{...frame,tick:2},[1,1,0,0,0,0,6,3,0])
assert.equal(stats.committedAxeWithdrawal.correct,1)
assert.equal(stats.stablePurposeTransitions.radialReversals,1)
assert.equal(stats.stablePurposeTransitions.viewReversals,1)
recordActionFlow(stats,h,{...frame,tick:3,expertReason:'urgent-legal-interrupt-before-full-charge',labels:{...frame.labels,4:2}},[1,1,0,0,2,0,6,3,0])
assert.equal(stats.pursuerInReachInterception.correct,1)
assert.equal(stats.stablePurposeTransitions.count,1,'changing tactical purpose is not indecision')
const wrap={},wh={};recordActionFlow(wrap,wh,frame,frame.actions)
recordActionFlow(wrap,wh,{...frame,tick:2},[1,1,0,0,0,0,12,3,0])
assert.equal(wrap.stablePurposeTransitions.viewReversals,0,'-180 and +180 are the same direction')
recordActionFlow(wrap,wh,{...frame,tick:3,labels:{}},frame.actions)
recordActionFlow(wrap,wh,{...frame,tick:4},frame.actions)
assert.equal(wrap.stablePurposeTransitions.count,1,'mechanical frames break a model control sequence')
console.log('OFFLINE_COHERENT_ACTION_AND_REVERSAL_AUDIT_PASS')
const facingRecovery={...frame,labels:{...frame.labels,0:2,1:0,6:6},actions:[2,0,0,0,0,0,6,3,0]}
const close={};recordActionFlow(close,{},facingRecovery,facingRecovery.actions)
assert.equal(close.committedAxeWithdrawal.correct,1,'a short facing retreat is distinct from distant turn-and-sprint travel')
const sword={...frame,expertReason:'close-sword-early-useful-damage',
 labels:{0:1,1:0,2:1,4:2,5:1,6:6},actions:[1,0,1,0,2,1,6,3,0],
 publicRequest:{self:{held:0,x:0,z:0,ground:true},seen:{visible:true,x:0,z:1.8,shield:false}}}
const rhythm={};recordActionFlow(rhythm,{},sword,sword.actions)
recordActionFlow(rhythm,{},sword,[1,0,1,0,0,1,6,3,0])
assert.equal(rhythm.swordUsefulHitBeforeTakeoff.count,2)
assert.equal(rhythm.swordUsefulHitBeforeTakeoff.correct,1,'a jump without the available first hit is not the taught sword rhythm')
const baseline={nearZeroAxeNoSpam:{count:20,correct:16},dangerousGapRetainsSword:{count:20,correct:18},
 stablePurposeTransitions:{count:20,radialReversals:2,viewReversals:1}}
const regressed={nearZeroAxeNoSpam:{count:20,correct:18},dangerousGapRetainsSword:{count:20,correct:16},
 stablePurposeTransitions:{count:20,radialReversals:3,viewReversals:0}}
const gates=actionFlowChecks(baseline,regressed)
assert.equal(gates.nearZeroAxeNoSpamJointDecision,false,'improvement from 80 to 90 percent still misses the no-spam floor')
assert.equal(gates.dangerousGapRetainsSwordJointDecision,false,'a worse weapon decision cannot hide in lower total NLL')
assert.equal(gates.radialReversalsNotIncreased,false,'more frequent tactical reversals reject release')
assert.equal(gates.viewReversalsNotIncreased,true)
const improved={...baseline,nearZeroAxeNoSpam:{count:20,correct:20}}
assert(Object.values(actionFlowChecks(baseline,improved)).every(Boolean))
assert.deepEqual(actionFlowChecks({readySwordUsefulDamage:{count:2,correct:1}},{readySwordUsefulDamage:{count:2,correct:2}}),{},
 'two samples cannot establish a useful-sword release rate')
console.log('ACTION_FLOW_RELEASE_GATES_PASS')
