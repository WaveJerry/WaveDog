"""Read-only combat audit and immutable copies of the six pilot trials."""
from pathlib import Path
import argparse, collections, hashlib, json, shutil

ROOT = Path(__file__).resolve().parents[3]
RUNTIME = ROOT / 'work/wavedog-punengbho/runtime'
p = argparse.ArgumentParser()
p.add_argument('--suite', type=Path, required=True)
a = p.parse_args()
suite = json.loads((a.suite / 'report.json').read_text(encoding='utf-8'))
ids = {t['matchId'] for t in suite['trials']}
events = [json.loads(line) for line in (RUNTIME / 'client-events.jsonl').read_text(encoding='utf-8').splitlines()]
events = [e for e in events if e.get('matchId') in ids]
evidence = a.suite / 'trajectories'
evidence.mkdir(exist_ok=True)
manifest = []

def preserve(source):
    dest = evidence / source.name
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest() != sha:
        raise RuntimeError('Existing evidence changed: ' + str(dest))
    if not dest.exists():
        shutil.copy2(source, dest)
    assert hashlib.sha256(dest.read_bytes()).hexdigest() == sha
    manifest.append({'source': str(source.resolve()), 'copy': str(dest.resolve()), 'sha256': sha})

def percentile(values, percent):
    if not values:
        return None
    return sorted(values)[round((len(values)-1)*percent)]

audit = {'completed': suite['completed'], 'allSixAccepted': False,
         'weightsChanged': False, 'ppoUpdated': False, 'trials': [],
         'limits': ['Frozen evaluation, not PPO/Qwen training',
                    'Observation-to-command latency is not opponent-input-to-server latency',
                    'Scripted ordinary-player scenarios are not human competitive win-rate tests']}
for trial in suite['trials']:
    match = trial['matchId']
    frames = [json.loads(line) for line in Path(trial['frameFile']).read_text(encoding='utf-8').splitlines()]
    for source in RUNTIME.glob(match + '-*'):
        if source.is_file():
            preserve(source)
    receipt = json.loads((RUNTIME / (match+'-training.json')).read_text(encoding='utf-8'))
    frozen = Path(receipt['file'])
    assert hashlib.sha256(frozen.read_bytes()).hexdigest() == receipt['sha256']
    preserve(frozen)
    assert receipt['trainingSkipped'] and all(f['policySha'] == receipt['checkpointSha256'] for f in frames)
    ev = [e for e in events if e['matchId'] == match]
    native = [e for e in ev if e['type'] == 'damage']
    packets = [json.loads(line) for line in (RUNTIME/(match+'-packets.jsonl')).read_text().splitlines()]
    attacks = {f['attackId']: f for f in frames if f.get('attackPacket')}
    melee_hits = [e for e in native if e.get('melee') and e.get('attacker') == 'Punengbho'
                  and e.get('amount', 0) > 0 and not e.get('cancelled') and e.get('attackId') in attacks]
    shots = []
    loads = []
    for f in frames:
        rr, o = f.get('rangedResult', {}), f['observation']
        if rr.get('fireSent') or rr.get('bowReleased'):
            shots.append({'tick': f['tick'], 'weapon': 'crossbow' if rr.get('fireSent') else 'bow',
                          'targetShotEvent': o.get('targetShotEvent'),
                          'observedShotToPacketTicks': f['tick']-o['targetShotTick'],
                          'serverUseTicksAtReleaseSample': (f.get('nativeSelf') or {}).get('useTicks'),
                          'packets': f['actualPackets']})
        if f['command'].get('ranged') == 'load-crossbow' and rr.get('useStarted'):
            start = f['tick']
            finish = next((g for g in frames if g['tick'] >= start and g['self']['crossbowLoaded']), None)
            during = [g for g in frames if start <= g['tick'] <= (finish['tick'] if finish else frames[-1]['tick'])]
            loads.append({'startTick': start, 'observedTargetLoading': bool(o.get('targetLoading')),
                          'chargedAckTick': finish['tick'] if finish else None,
                          'switchesBeforeAck': sum('held_item_slot' in g['actualPackets'] for g in during),
                          'firePacketsBeforeAck': sum(bool(g.get('rangedResult',{}).get('fireSent')) for g in during)})
    transitions = [e for e in ev if e['type'] == 'handoff']
    escapes = []
    for e in transitions:
        if e['to'] != 'ESCAPE':
            continue
        handoff = next((g for g in transitions if g['tick'] >= e['tick'] and g['from'] == 'ESCAPE'), None)
        segment = [f for f in frames if f['mode'] == 'ESCAPE' and e['tick'] <= f['tick'] <= (handoff['tick'] if handoff else 10**9)]
        escapes.append({'enteredTick': e['tick'], 'entryReason': e['reason'], 'handoff': handoff,
                        'swordFrames': sum(f['self']['held'] == 0 for f in segment),
                        'sprintCommands': sum(bool(f['command'].get('sprint')) for f in segment),
                        'jumpCommands': sum(bool(f['command'].get('jump')) for f in segment),
                        'exitAttacks': sum(f['attackPacket'] for f in segment)})
    critical_guard = [f for f in frames if f['command'].get('guardAirborne')]
    orbit = [f for f in frames if f['command'].get('orbit')]
    cancel_swaps = [q for q in packets if q['name'] == 'block_dig' and q['data'].get('status') == 6]
    observation_execution = [f['timings']['observationToExecutionMs'] for f in frames
                             if f.get('timings',{}).get('observationToExecutionMs') is not None]
    result = {'matchId': match, 'mode': trial['opponentMode'], 'frames': len(frames),
              'states': dict(collections.Counter(f['mode'] for f in frames)),
              'shots': shots, 'loads': loads, 'handoffs': transitions, 'escapes': escapes,
              'mechanicalAttackKinds': dict(collections.Counter(f['command'].get('kind') for f in frames if f['attackPacket'])),
              'nativeMeleeHitsByKind': dict(collections.Counter(attacks[e['attackId']]['command'].get('kind') for e in melee_hits)),
              'nativeReceivedMeleeCriticals': [e for e in native if e.get('victim') == 'Punengbho' and e.get('melee') and e.get('nativeCritical') and e.get('amount',0)>0 and not e.get('cancelled')],
              'blockedNativeCriticals': sum(e.get('victim')=='Punengbho' and bool(e.get('nativeCritical')) and e.get('shieldModifier',0)<0 and e.get('amount',0)==0 for e in native),
              'orbitMovementFrames': len(orbit), 'cancelSwapPackets': len(cancel_swaps),
              'airGuardFrames': len(critical_guard),
              'airGuardReleaseViolations': sum(bool(f['command'].get('attack') or f['command'].get('ranged') or not f['command'].get('shield')) for f in critical_guard),
              'unassistedNeuralFrames': sum(f['mode']=='NEURAL' and f['owners']['movement']=='neural' for f in frames),
              'neuralMeleePackets': sum(f['attackPacket'] and f['command'].get('kind')=='neural' for f in frames),
              'expiredFrames': sum(f['owners'].get('attack')=='neutral-expired' for f in frames),
              'observationToExecutionMs': {'p50':percentile(observation_execution,.5),'p95':percentile(observation_execution,.95),'max':max(observation_execution,default=None)},
              'checkpointSha256': receipt['checkpointSha256'], 'trajectorySha256':receipt['sha256']}
    audit['trials'].append(result)
(evidence/'client-events.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in events),encoding='utf-8')
(a.suite/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(a.suite/'mechanical-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps({'completed':audit['completed'],'trials':[{k:t[k] for k in ['mode','states','shots','loads','orbitMovementFrames','cancelSwapPackets','blockedNativeCriticals','nativeMeleeHitsByKind','airGuardReleaseViolations','neuralMeleePackets','expiredFrames']} for t in audit['trials']]}))
