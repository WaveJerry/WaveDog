import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE} from '../fresh-policy.js'
import {SharedAdam,saveDualCheckpoint,loadDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
await tf.setBackend('cpu');await tf.ready()
const config={fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:2,actionContextHeads:[2,5,4]}
const a=new DualPolicy(config),b=new DualPolicy({...config,contextBaseCalibration:1})
const key=p=>p.name.replace(/^dual\d+\./,'')
const inherited=new Map(a.params.map(p=>[key(p),p]))
for(const p of b.params)if(inherited.has(key(p)))p.assign(inherited.get(key(p)))
const adam=new SharedAdam(b.params)
const folder=fs.mkdtempSync(path.join(os.tmpdir(),'pvp-context-calibration-'))
try{
  tf.tidy(()=>{
    const x=tf.tensor2d([Array.from({length:OBS_SIZE},(_,i)=>Math.sin(i)*.2)])
    const left=a.step(x,a.initialState()),right=b.step(x,b.initialState())
    for(let h=0;h<left.logits.length;h++)assert.deepEqual(
      [...left.logits[h].dataSync()],[...right.logits[h].dataSync()],'identity migration preserves every head')
    b.contextBaseCalibration.assign(tf.tensor1d([-1.5,.8]))
    const calibrated=b.step(x,b.initialState())
    for(let h=0;h<left.logits.length;h++){
      const i=[2,5].indexOf(h),scale=i<0?1:2/(1+Math.exp(-[-1.5,.8][i]))
      const expected=[...left.logits[h].dataSync()].map(v=>v*scale)
      for(const[j,v]of calibrated.logits[h].dataSync().entries())assert(Math.abs(v-expected[j])<1e-6)
    }
    const {value,grads}=tf.variableGrads(()=>{
      const out=b.step(x,b.initialState())
      return tf.neg(tf.add(tf.logSoftmax(out.logits[2]).slice([0,1],[1,1]).sum(),
        tf.logSoftmax(out.logits[5]).slice([0,0],[1,1]).sum()))
    },[b.contextBaseCalibration])
    assert(Number.isFinite(value.dataSync()[0]))
    assert([...grads[b.contextBaseCalibration.name].dataSync()].every(v=>Number.isFinite(v)&&Math.abs(v)>1e-8),
      'both calibration parameters must receive real action-loss gradients')
  })
  const file=path.join(folder,'checkpoint.json');saveDualCheckpoint(file,b,adam,{testOnly:true})
  const loaded=loadDualCheckpoint(file)
  try{
    assert.deepEqual([...loaded.model.contextBaseCalibration.dataSync()],[...b.contextBaseCalibration.dataSync()])
    assert.equal(loaded.model.params.length,b.params.length)
    assert.equal(loaded.adam.first.length,adam.first.length)
  }finally{loaded.adam.dispose();loaded.model.dispose()}
  console.log('CONTEXT_CALIBRATION_IDENTITY_GRADIENT_AND_CHECKPOINT_PASS')
}finally{
  a.dispose();b.dispose();adam.dispose()
  assert.equal(path.dirname(folder),path.resolve(os.tmpdir()))
  fs.rmSync(folder,{recursive:true})
}
