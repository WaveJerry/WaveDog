"""Aggregate complete new learner bouts; preserve all prior held-out splits."""
from pathlib import Path
import hashlib,json,shutil,subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'outputs/punengbho-rebuild-20261117'
SOURCE=BASE/'axe-sword-flow-v32-data/dataset.json'
REVIEW=BASE/'landing-contact-review-20261118/audit.json'
DEST=BASE/'ground-handoff-v33-data'
if DEST.exists() and any(p.name not in {'preserved-splits.json','dataset.json','continuation-audit.json'} for p in DEST.iterdir()):
    raise RuntimeError('Preserve existing dataset')
DEST.mkdir(exist_ok=True)
prior=json.loads(SOURCE.read_text(encoding='utf-8'))
review=json.loads(REVIEW.read_text(encoding='utf-8'))
existing={t['matchId'] for t in prior['trajectories']}
episodes=[e for e in review['episodes'] if e['matchId'] not in existing]
for match in ['ad3f931c-f0aa-4051-a22a-34809c706034','233fd3f4-e3a2-4026-992f-a03eb955f402',
              '1f592ce1-71db-4dc7-823b-6eca42e8463f','f506c475-13a3-4f66-aa12-8e9dca38dac3']:
    if match in existing or any(e['matchId']==match for e in episodes):continue
    raw=ROOT/'work/wavedog-punengbho/runtime'/f'{match}-frames.jsonl'
    report=json.loads(raw.with_name(f'{match}-report.json').read_text(encoding='utf-8'))
    assert report['outcome']['reason']=='death' and not report['outcome'].get('invalid')
    episodes.append({'matchId':match,'source':{'path':str(raw),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}})
holdout={'2a206495-5f45-4ce4-90fe-80ae94d5c2b7',
         'dbb7d6ab-a483-4f75-be8f-20c4f56d7fb8',
         '8afb52ea-123b-4bcf-b574-484f0b0f82b8','233fd3f4-e3a2-4026-992f-a03eb955f402',
         'f506c475-13a3-4f66-aa12-8e9dca38dac3'}
splits=[{k:t[k] for k in ('sourceKind','sourceSha256','matchId','split','lesson') if k in t}
        for t in prior['trajectories'] if t.get('sourceKind')=='dagger-expert-relabel']
splits.extend(dict(sourceKind='dagger-expert-relabel',sourceSha256=e['source']['sha256'],
    matchId=e['matchId'],split='validation' if e['matchId'] in holdout else 'train',
    lesson='hybrid-shieldless-contact') for e in episodes)
split_file=DEST/'preserved-splits.json'
split_file.write_text(json.dumps({'trajectories':splits},indent=2),encoding='utf-8')
node=shutil.which('node')
if not (BASE/'ground-handoff-v33-aggregation/dataset.json').exists():subprocess.run([node,str(ROOT/'work/pvp-dual-brain/punengbho/prepare-dagger-dataset.js'),
    'ground-handoff-v33-aggregation','--label-delay','0','--expert','joint-melee',
    '--directional-movement',
    '--preserve-splits',str(split_file),'--base',str(SOURCE),
    *[e['matchId'] for e in episodes]],cwd=ROOT,check=True)
if not (DEST/'dataset.json').exists():subprocess.run([node,str(ROOT/'work/pvp-dual-brain/punengbho/prepare-sword-continuation.js'),
    str(BASE/'ground-handoff-v33-aggregation/dataset.json'),str(DEST/'dataset.json')],cwd=ROOT,check=True)
data=json.loads((DEST/'dataset.json').read_text(encoding='utf-8'))
by_source={t['source']:t for t in data['trajectories']}
for t in prior['trajectories']:
    assert by_source[t['source']]['split']==t['split']
    if t.get('sourceKind')!='dagger-expert-relabel':
        assert [f['labels'] for f in by_source[t['source']]['frames']]==[f['labels'] for f in t['frames']]
teacher=DEST/'teacher-source';teacher.mkdir()
names=['joint-melee-expert.cjs','ground-contact-supervision.cjs',
       'contact-persistence-calibration.json','directional-movement-supervision.js',
       'causal-learner-input.js','prepare-sword-continuation.js']
hashes={}
for name in names:
    source=ROOT/'work/pvp-dual-brain/punengbho'/name
    shutil.copy2(source,teacher/name)
    hashes[name]=hashlib.sha256(source.read_bytes()).hexdigest()
manifest={'newBouts':len(episodes),'newTrainBouts':sum(e['matchId'] not in holdout for e in episodes),
    'newValidationBouts':sum(e['matchId'] in holdout for e in episodes),
    'priorSplitsPreserved':True,'priorDemonstrationLabelsPreserved':True,
    'noValidationGradients':True,'mechanicalFramesContextOnly':True,'teacherHashes':hashes,
    'datasetSha256':hashlib.sha256((DEST/'dataset.json').read_bytes()).hexdigest()}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(manifest),flush=True)
