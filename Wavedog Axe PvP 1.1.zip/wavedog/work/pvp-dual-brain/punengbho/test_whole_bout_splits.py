import unittest
from whole_bout_splits import require_whole_bout_splits

class WholeBoutTests(unittest.TestCase):
    def test_opposite_viewpoints_cannot_cross_splits(self):
        data={'trajectories':[{'matchId':'one','source':'teacher','split':'validation'},
                              {'matchId':'one','source':'learner','split':'train'}]}
        with self.assertRaisesRegex(ValueError,'Same match crosses'):require_whole_bout_splits(data)
    def test_matching_viewpoints_and_separate_holdout(self):
        data={'trajectories':[{'matchId':'one','split':'train'},
                              {'matchId':'one','split':'train'},
                              {'matchId':'two','split':'validation'}]}
        self.assertEqual(require_whole_bout_splits(data)['checkedMatches'],2)
    def test_missing_identity_is_not_independence(self):
        with self.assertRaises(ValueError):require_whole_bout_splits({'trajectories':[{'split':'train'}]})

if __name__=='__main__':unittest.main()
