import assert from 'node:assert/strict'
import {policyFrame,comparisonFrame,airborneJumpFrame}from './policy-frame-masks.js'
import {accumulate,finishStats}from '../human-imitation.js'
const frame={publicRequest:{self:{ground:false}},legalMasks:[[true],[true],[true,true]],
  actions:[0,0,1],labels:{0:0,2:1}}
const old=policyFrame(frame,{}),next=policyFrame(frame,{jumpInputVersion:2})
assert.equal(old.legalMasks[2][1],false);assert.equal(old.actions[2],0)
assert.equal(next,frame);assert.equal(frame.legalMasks[2][1],true);assert.equal(frame.actions[2],1)
const score=(f,logits)=>{const stats={labels:{},drift:{}};accumulate(stats,f,{logits});return finishStats(stats)}
const before=score(comparisonFrame(old,{}, {jumpInputVersion:2}),[[0],[0],[0,-1e9]])
const after=score(comparisonFrame(next,{}, {jumpInputVersion:2}),[[0],[0],[0,10]])
assert.equal(before.meanNll,after.meanNll,'held-key support cannot fabricate shared combat NLL improvement')
assert.equal(before.labels['2:1'],undefined)
assert(score(airborneJumpFrame(old),[[0],[0],[0,-1e9]]).meanNll>1e8,'unsupported key is disclosed separately')
assert.equal(comparisonFrame(frame,{jumpInputVersion:2},{jumpInputVersion:2}),frame)
const ground={...frame,publicRequest:{self:{ground:true}}}
assert.equal(comparisonFrame(ground,{}, {jumpInputVersion:2}),ground,'actual takeoff must remain comparable')
assert.equal(policyFrame(ground,{}),ground)
const release={...frame,labels:{0:0,2:0}}
assert.equal(comparisonFrame(release,{}, {jumpInputVersion:2}).labels[2],undefined,'both air-key classes leave the shared metric')
console.log('VERSIONED_POLICY_MASK_AND_COMPARABLE_METRICS_PASS')
