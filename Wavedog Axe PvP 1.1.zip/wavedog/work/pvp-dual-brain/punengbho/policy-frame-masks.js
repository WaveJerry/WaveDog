// An old checkpoint must not gain v2 held-jump actions just because a new
// curriculum can label them. Match the versioned live actor's legality.
export function policyFrame(frame,config={}){
  if(config.jumpInputVersion===2||frame.publicRequest?.self?.ground!==false)
    return frame
  const legalMasks=frame.legalMasks.map(row=>[...row]);legalMasks[2][1]=false
  // Teacher-forced parents must obey the old actor's semantics as well.
  const actions=frame.actions?[...frame.actions]:undefined
  if(actions)actions[2]=0
  return {...frame,legalMasks,...(actions?{actions}:{})}
}

// Compare the same labels under compatible action semantics. Keep all
// airborne combat labels, but report airborne key-holding separately when
// the old actor cannot perform it. Never count a masked 1e9 NLL as progress.
export function comparisonFrame(frame,referenceConfig,candidateConfig){
  if((referenceConfig.jumpInputVersion===2)===(candidateConfig.jumpInputVersion===2)
      ||frame.publicRequest?.self?.ground!==false||frame.labels[2]===undefined)return frame
  const labels={...frame.labels};delete labels[2]
  return {...frame,labels}
}
export function airborneJumpFrame(frame){
  return {...frame,labels:frame.publicRequest?.self?.ground===false&&frame.labels[2]!==undefined
    ?{2:frame.labels[2]}:{}}
}
