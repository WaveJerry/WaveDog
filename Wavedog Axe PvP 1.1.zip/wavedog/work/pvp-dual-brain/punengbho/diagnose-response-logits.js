import fs from 'node:fs'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {disposeState}from '../human-imitation.js'
import {captureAutonomousImitation}from './autonomous-imitation.js'
const [checkpoint,dataset,outFile]=process.argv.slice(2)
if(!outFile||fs.existsSync(outFile))throw Error('New diagnostic output required')
const data=JSON.parse(fs.readFileSync(dataset)),loaded=loadDualCheckpoint(checkpoint),m=loaded.model
const rows=[],counts={moveCorrect:0,waitCorrect:0,noJump:0,total:0}
await tf.setBackend('cpu');await tf.ready()
try{for(const t of data.trajectories.filter(t=>t.split==='validation')){
 let state=m.initialState()
 try{for(const f of t.frames){
   const r=f.publicRequest,o=r?.publicActionContext
   const wanted=o?.targetCriticalThreat&&o.targetAirborne&&f.labels[4]===0&&[2,7,8].includes(f.actions[0])
   const old=state
   const result=tf.tidy(()=>{
     const ob=tf.tensor2d([f.observation]),a=m.step(ob,state,f.legalMasks,f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures)
     if(!wanted)return {state:a.state}
     let x=m.projectObservation(ob,f.publicHealthFeatures)
     if(m.publicThreatProjection)x=tf.add(x,tf.matMul(tf.tensor2d([f.publicThreatFeatures]),m.publicThreatProjection))
     const spatial=m.spatialMovementResidual(x,f.publicSpatialFeatures,f.publicThreatFeatures,a.state)[m.spatialMovementHeads.indexOf(0)]
     const context=m.actionContextOut[m.config.actionContextHeads.indexOf(0)].apply(tf.tanh(m.actionContextIn.apply(m.projectActionContext(x))))
     return {state:a.state,logits:a.logits.map(h=>[...h.dataSync()]),spatial:[...spatial.dataSync()],context:[...context.dataSync()]}
   });state=result.state;disposeState(old,state)
   if(wanted){
     const a=captureAutonomousImitation(m,result,f).actions,target=f.actions[0],chosen=a[0]
     counts.total++;counts.moveCorrect+=Number(chosen===target);counts.waitCorrect+=Number(a[4]===0);counts.noJump+=Number(a[2]===0)
     const diff=v=>v[chosen]-v[target],spatial=diff(result.spatial),context=diff(result.context),total=diff(result.logits[0])
     rows.push({source:t.source,tick:f.tick,actions:a,labels:f.labels,reason:f.expertReason,
       charge:r.self.charge,ground:r.self.ground,forecast:r.publicActionContext.airEnvelope,
       moveMargin:{total,spatial,context,recurrent:total-spatial-context}})
   }
 }}finally{disposeState(state)}
}
fs.writeFileSync(outFile,JSON.stringify({counts,rows},null,2));console.log(JSON.stringify({counts,wrongExamples:rows.filter(r=>r.actions[0]!==r.labels[0]).slice(0,6)}))
}finally{loaded.adam.dispose();m.dispose()}
