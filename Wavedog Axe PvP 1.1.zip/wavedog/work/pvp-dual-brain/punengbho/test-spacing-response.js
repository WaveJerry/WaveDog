import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { LatestObservationQueue, applyDefaultGoal } from './fresh-inference-queue.js'
import { meleeEntryContext } from './fresh-melee-progress.js'
import { OBS_SIZE, ACTION_WIDTHS, biasedActionLogits, maskActionLogits } from './fresh-policy.js'

// A backlog represents late public observations, not repeated native actions.
const tasks = [], ran = [], dropped = []
const queue = new LatestObservationQueue(job => ran.push([job.name, job.tick]), {
  schedule: callback => tasks.push(callback), onDrop: job => dropped.push(job.tick)
})
queue.push('human', { name: 'human', matchId: 'one', tick: 10, priority: true })
queue.push('human', { name: 'human', matchId: 'one', tick: 12, priority: true })
queue.push('human', { name: 'human', matchId: 'one', tick: 11, priority: true })
queue.push('bot', { name: 'bot', matchId: 'two', tick: 20 })
while (tasks.length) tasks.shift()()
assert.deepEqual(ran, [['human', 12], ['bot', 20]])
assert.deepEqual(dropped, [10, 11])
assert.equal(queue.stats.maxQueued, 2)
assert.equal(queue.stats.coalesced, 1)
queue.push('human', { name: 'human', matchId: 'old', tick: 50 })
queue.clearFighter('human')
while (tasks.length) tasks.shift()()
assert.equal(ran.length, 2, 'reset/finish cannot run a pending old-bout observation')

const fairnessTasks = [], order = []
let fairness
fairness = new LatestObservationQueue(job => {
  order.push(job.name)
  if (job.name === 'human' && order.length < 6)
    fairness.push('human', { name: 'human', matchId: 'fair', tick: job.tick + 1, priority: true })
}, { schedule: callback => fairnessTasks.push(callback) })
fairness.push('bot', { name: 'bot', matchId: 'bot', tick: 1 })
fairness.push('human', { name: 'human', matchId: 'fair', tick: 1, priority: true })
while (fairnessTasks.length) fairnessTasks.shift()()
assert.equal(order.indexOf('bot'), 2, 'human priority must not starve selfplay')
assert.equal(applyDefaultGoal({ focus: 'COMBO' }, 'SPRINT_KB').focus, 'COMBO')
assert.equal(applyDefaultGoal({ focus: 'FREE' }, 'CRITICAL').focus, 'FREE')
assert.equal(applyDefaultGoal({}, 'SPRINT_KB').focus, 'SPRINT_KB')

const previous = { tick: 10, opponent: 'B', matchId: 'fight',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62, health: 20, charge: .6 },
  seen: { visible: true, x: 0, y: 0, z: 3.3, shield: false } }
const current = { ...previous, tick: 11,
  self: { ...previous.self, health: 18 }, seen: { ...previous.seen, z: 3.1 } }
const danger = meleeEntryContext(previous, current)
assert.equal(danger.entryCurriculum, 8)
assert(danger.edgeComboRisk)
assert.equal(danger.edgeRiskReason, 'own-damage-at-boundary')
assert(!meleeEntryContext(previous, { ...current, self: previous.self }).edgeComboRisk,
  'ordinary proximity alone does not assume combo intent')
const visibleSwing = { ...current, self: previous.self, observedOpponentSwingAge: 1 }
assert(meleeEntryContext(previous, visibleSwing).edgeComboRisk)
assert(meleeEntryContext(previous, { ...visibleSwing, observedOpponentSwingAge: undefined,
  seen: { ...visibleSwing.seen, swing: 10 } }).edgeComboRisk,
  'public swing ticks work when the caller has no precomputed swing age')
assert(!meleeEntryContext(previous, { ...visibleSwing, seen: previous.seen }).edgeComboRisk,
  'a stationary visible swing is not a closing boundary attack')
assert(!meleeEntryContext(previous, { ...current, matchId: 'other' }, danger).edgeComboRisk)
assert(!meleeEntryContext(previous, { ...current, seen: { ...current.seen, visible: false } }, danger).edgeComboRisk)
assert(!meleeEntryContext(previous, { ...current, self: { ...current.self, using: true } }).edgeComboRisk)
assert(!meleeEntryContext(previous, { ...current, self: { ...current.self, shielding: true } }).edgeComboRisk)
assert(!meleeEntryContext(previous, { ...current, seen: { ...current.seen, shield: true } }).edgeComboRisk)
const persisted = meleeEntryContext(current, { ...current, tick: 12 }, danger)
assert(persisted.edgeComboRisk)
assert(!meleeEntryContext({ ...current, tick: 23 }, { ...current, tick: 24 }, danger).edgeComboRisk,
  'a risk observation expires instead of becoming a permanent aggressive mode')
const outside = { ...current, seen: { ...current.seen, z: 3.7 } }
assert(!meleeEntryContext(previous, outside, danger).edgeComboRisk)

const observation = Array(OBS_SIZE).fill(0)
observation[0] = 1; observation[1] = .6; observation[2] = 1
observation[10] = 1; observation[31] = 1; observation[97] = -.05
const legal = ACTION_WIDTHS.map(width => Array(width).fill(true))
legal[4] = [true, false, true, false, false]
const raw = ACTION_WIDTHS.map(width => tf.zeros([1, width]))
raw[4].dispose(); raw[4] = tf.tensor2d([[0, 0, -16, 0, 0]])
const chance = context => tf.tidy(() => {
  const heads = biasedActionLogits(raw, observation, context)
  return tf.softmax(maskActionLogits(heads, legal)[4]).dataSync()[2]
})
const old = chance({ entryCurriculum: 3, edgeComboRisk: true })
const relaxed = chance(danger)
assert(relaxed > old * 1000 && relaxed > .01 && relaxed < .95,
  'public risk enables meaningful low-charge exploration without forced attack')
const newHeads = biasedActionLogits(raw, observation, danger)
const replayHeads = biasedActionLogits(raw, observation, JSON.parse(JSON.stringify(danger)))
newHeads.forEach((head, index) => assert.deepEqual([...head.dataSync()], [...replayHeads[index].dataSync()]))
const ordinary = biasedActionLogits(raw, observation, { entryCurriculum: 3 })
const noRisk = biasedActionLogits(raw, observation, { entryCurriculum: 4, edgeComboRisk: false })
ordinary.forEach((head, index) => assert.deepEqual([...head.dataSync()], [...noRisk[index].dataSync()]))
for (const index of [0, 1, 2, 3, 5, 6, 7, 8])
  assert.deepEqual([...ordinary[index].dataSync()], [...newHeads[index].dataSync()],
    'risk exploration does not override movement, sprint, jump or weapon heads')
observation[97] = .01
assert.equal(chance(danger), chance({ entryCurriculum: 3 }), 'outside reach does not gain an attack cue')
observation[97] = -.05; observation[1] = 1
assert.equal(chance(danger), chance({ entryCurriculum: 3 }), 'full-charge opportunity is not weakened')
observation[1] = .6
const handParameter = tf.variable(tf.tensor2d([[0, 0, -16, 0, 0]]))
const differentiable = raw.map((head, index) => index === 4 ? handParameter : head)
const gradient = tf.variableGrads(() => tf.tidy(() => {
  const heads = biasedActionLogits(differentiable, observation, danger)
  return tf.logSoftmax(maskActionLogits(heads, legal)[4]).slice([0, 2], [1, 1]).sum()
}), [handParameter])
assert([...gradient.grads[handParameter.name].dataSync()].every(Number.isFinite))
assert(gradient.grads[handParameter.name].dataSync()[2] > 0,
  'conditional exploration retains a real gradient for PPO instead of clipping it away')
tf.dispose([handParameter, gradient.value, ...Object.values(gradient.grads)])
tf.dispose([...raw, ...newHeads, ...replayHeads, ...ordinary, ...noRisk])
console.log('SPACING_RESPONSE_PASS: latest observations, per-frame goals, public risk, conditional exploration, exact PPO replay')
