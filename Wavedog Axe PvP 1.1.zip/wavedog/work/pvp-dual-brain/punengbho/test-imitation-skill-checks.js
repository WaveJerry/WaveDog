import assert from 'node:assert/strict'
import {skillChecks,skillScore}from './imitation-skill-checks.js'
const stat=(nll,accuracy)=>({nll,accuracy,count:20})
const old={meanNll:2,labels:{'2:1':stat(.00001,1),'2:0':stat(11,0),'4:2':stat(.5,1),'4:0':stat(.3,.9)}}
const fixed={meanNll:.5,labels:{'2:1':stat(.2,1),'2:0':stat(.2,1),'4:2':stat(.4,1),'4:0':stat(.2,1)}}
const wrap=s=>({...s,byLesson:{control:s}})
assert(skillScore(fixed)<skillScore(old),'balanced score penalizes constant jumping')
assert(Object.values(skillChecks(wrap(old),wrap(fixed))).every(Boolean),
  'learning to stay grounded does not require making positive jumps more overconfident')
const noJumps={...fixed,labels:{...fixed.labels,'2:1':stat(3,0)}}
assert(Object.values(skillChecks(wrap(old),wrap(noJumps))).some(v=>!v),'never jumping cannot pass')
const noAttack={...fixed,labels:{...fixed.labels,'4:2':stat(3,0)}}
assert(Object.values(skillChecks(wrap(old),wrap(noAttack))).some(v=>!v),'never attacking cannot pass')
const newWeapon={...fixed,labels:{...fixed.labels,'5:0':stat(8,0),'5:1':stat(.01,1)}}
assert(Object.values(skillChecks(wrap(newWeapon),wrap(newWeapon))).some(v=>!v),
  'a newly taught axe switch cannot pass while still never selected')
console.log('CONDITIONAL_SKILL_VALIDATION_PASS')
