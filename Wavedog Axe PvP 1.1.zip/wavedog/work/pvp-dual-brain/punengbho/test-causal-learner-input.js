import assert from 'node:assert/strict'
import {learnerRequest,recordedPolicyFeatures}from './causal-learner-input.js'
import {publicThreatFeatures}from '../public-threat-features.js'
import {publicSpatialFeatures}from '../public-spatial-features.js'
import {policyFrame}from './policy-frame-masks.js'
const raw={tick:42,self:{x:0,y:0,z:0,vx:0,vz:0},seen:{visible:true,x:0,y:0,z:2},
  publicTerrain:{walls:[8,8,8,8]},observedOpponentMotion:{matchId:'one',opponent:'player',vx:0,vy:.2,vz:-.15},
  observation:{tick:42,visible:true,targetGrounded:false,targetVelocity:{x:0,y:.2,z:-.15}},
  nativeSelf:{privateDiagnostic:true}}
const req=learnerRequest(raw)
const frame={decidedTick:42,publicHealthFeatures:[0,0,0,0,0],
  publicSpatialFeatures:publicSpatialFeatures(req),publicThreatFeatures:publicThreatFeatures(req)}
assert.deepEqual(recordedPolicyFeatures(frame,req),{publicHealthFeatures:frame.publicHealthFeatures,
  publicSpatialFeatures:frame.publicSpatialFeatures,publicThreatFeatures:frame.publicThreatFeatures})
assert(!('nativeSelf'in req))
assert.throws(()=>recordedPolicyFeatures({...frame,decidedTick:43},req),/same tick/)
assert.throws(()=>recordedPolicyFeatures({...frame,publicThreatFeatures:Array(12).fill(0)},req),/Causal input mismatch/)
assert.throws(()=>recordedPolicyFeatures({...frame,publicSpatialFeatures:Array(8).fill(0)},req),/Causal input mismatch/)
const airborne={publicRequest:{self:{ground:false}},legalMasks:[[true],[true],[true,true]]}
assert.equal(policyFrame(airborne,{}).legalMasks[2][1],false)
assert.equal(policyFrame(airborne,{jumpInputVersion:2}).legalMasks[2][1],true)
assert.equal(airborne.legalMasks[2][1],true,'baseline evaluation never mutates candidate masks')
console.log('CAUSAL_LEARNER_FEATURES_PASS')
