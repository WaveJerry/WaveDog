// Only public, consecutive observations from the same bout may describe entry.
function consecutive (previous, current) {
  const ticks = current?.tick - previous?.tick
  return previous?.seen?.visible && current?.seen?.visible
    && previous.opponent === current.opponent
    && previous.matchId === current.matchId && ticks > 0 && ticks <= 4
}

export function publicMeleeReach (frame) {
  const { self, seen } = frame
  if (!self || !seen || ![self.x, self.y, self.z, seen.x, seen.y, seen.z].every(Number.isFinite))
    return Infinity
  const dx = Math.max(0, Math.abs(seen.x - self.x) - .3)
  const dz = Math.max(0, Math.abs(seen.z - self.z) - .3)
  const eyeY = Number.isFinite(self.eyeY) ? self.eyeY : self.y + 1.62
  const dy = Math.max(0, seen.y - eyeY, eyeY - (seen.y + 1.8))
  return Math.hypot(dx, dy, dz)
}
const inReach = frame => publicMeleeReach(frame) <= 3

// Version the context so pending older trajectories retain their exact PPO
// behavior distribution. New actors do not condition feet on a sampled attack.
export function meleeEntryContext (previous, current, previousContext = null) {
  const context = { entryCurriculum: 11, opponentApproaching: false, enteredReach: false,
    edgeComboRisk: false, edgeRiskUntilTick: -1, edgeRiskReason: null,
    opponentVerticalPhase: 'unknown', fallingMeleeThreat: false,
    ownFallingWindow: false, punishmentWindowClosing: false, lastOwnHitTick: -1000,
    jumpResetTrial: false, swordComboPressure: false, recentOwnHits: [],
    closeExchangeTicks: 0, risingEntryThreat: false, comboUnderPressure: false,
    swordDpsWindow: false, swordCadenceWindow: false,
    swordSustainWindow: false, swordCriticalSetupWindow: false, swordRisingWindow: false,
    swordShieldBreakWindow: false, axeShieldBreakWindow: false,
    shieldRushThreat:false, shieldRushRetreatWindow:false, groundChainReentry:false }
  if (!consecutive(previous, current)) return context
  context.enteredReach = !inReach(previous) && inReach(current)
  const ticks = current.tick - previous.tick
  const dx = previous.seen.x - previous.self.x
  const dz = previous.seen.z - previous.self.z
  const distance = Math.hypot(dx, dz)
  // Entity position packets need not change on every client physics tick.
  // Keep the client's bounded, public sample velocity across repeated frames;
  // never replace it with a hidden server velocity or another bout's sample.
  const motion = current.observedOpponentMotion
  const publicMotion = motion?.source === 'public-position-samples'
    && typeof current.matchId === 'string' && typeof current.opponent === 'string'
    && motion.matchId === current.matchId && motion.opponent === current.opponent
    && Number.isInteger(motion.sampleTick) && motion.sampleTick <= current.tick
    && current.tick - motion.sampleTick <= 3 && typeof motion.grounded === 'boolean'
    && [motion.vx, motion.vy, motion.vz].every(Number.isFinite)
    && Math.hypot(motion.vx, motion.vz) < 1.5 && Math.abs(motion.vy) < 1.5
  const vx = publicMotion ? motion.vx : (current.seen.x - previous.seen.x) / ticks
  const vz = publicMotion ? motion.vz : (current.seen.z - previous.seen.z) / ticks
  if (distance > .1 && Math.hypot(vx, vz) < 1.5)
    context.opponentApproaching = (vx * dx + vz * dz) / distance < -.035
  const reach = publicMeleeReach(current), previousReach = publicMeleeReach(previous)
  const closing = (previousReach - reach) / ticks > .025
  const ownHealthLoss = Number.isFinite(previous.self.health) && Number.isFinite(current.self.health)
    && current.self.health < previous.self.health - .0001
  // Public pressure cue, not a retreat command. Observed shield encounters
  // include both useful disengagement and late retreats that still lose HP.
  // Only suggest the escape lesson in model-owned melee with a real retreat
  // lane and a current disadvantage; ordinary net damage remains the reward.
  const walls=current.publicTerrain?.walls
  const retreatLane=Array.isArray(walls)&&walls.length===4
    &&walls.every(Number.isFinite)&&distance>.1
    &&(Math.abs(dx)<.1||walls[dx>0?0:1]>1.2)
    &&(Math.abs(dz)<.1||walls[dz>0?2:3]>1.2)
  context.shieldRushThreat=Boolean(current.seen.shield||current.seen.shieldRaised)
    &&context.opponentApproaching&&reach<=3.7
  context.shieldRushRetreatWindow=context.shieldRushThreat&&retreatLane
    &&current.self.shieldAvailable===false&&!current.self.shielding&&!current.self.using
    &&(current.self.health<=5||current.self.charge<.55||ownHealthLoss)
  const edge = value => value >= 2.4 && value <= 3.4
  // A visible downward trajectory is a threat hypothesis, not knowledge of
  // hidden fallDistance, sprint input, attack charge or a guaranteed critical.
  const vy = publicMotion ? motion.grounded ? 0 : motion.vy
    : (current.seen.y - previous.seen.y) / ticks
  const elevated = current.seen.y > current.self.y + .15
    || previous.seen.y > previous.self.y + .15
  if (Number.isFinite(vy) && Math.abs(vy) < 1.5)
    context.opponentVerticalPhase = vy > .03 ? 'rising'
      : vy < -.03 && elevated ? 'falling' : 'level-or-apex'
  context.fallingMeleeThreat = context.opponentVerticalPhase === 'falling'
    && reach <= 3.4 && !current.seen.shield
    && !current.self.shielding && !current.self.using
  context.ownFallingWindow = current.self.ground === false
    && current.self.vy < -.08 && current.self.charge >= .9
  context.lastOwnHitTick = ownHealthLoss ? current.tick
    : previousContext?.lastOwnHitTick ?? -1000
  context.recentOwnHits = (previousContext?.recentOwnHits || [])
    .filter(tick => current.tick - tick <= 30)
  if (ownHealthLoss) context.recentOwnHits.push(current.tick)
  context.swordComboPressure = reach < 2.4 && /SWORD/i.test(current.seen.held || '')
    && (context.fallingMeleeThreat || context.recentOwnHits.length >= 2
      && current.tick - context.lastOwnHitTick <= 12)
  const movingAway = distance > .1 && (vx * dx + vz * dz) / distance > .035
  context.punishmentWindowClosing = current.tick - context.lastOwnHitTick <= 12
    && movingAway && reach >= 2.4 && reach <= 3.3
    && !current.self.shielding && !current.self.using
  const swingAge = Number.isFinite(current.observedOpponentSwingAge) && current.observedOpponentSwingAge >= 0
    ? current.observedOpponentSwingAge
    : Number.isFinite(current.seen.swing) && current.seen.swing >= 0
      ? current.tick - current.seen.swing : -1
  const recentSwing = Number.isFinite(swingAge) && swingAge >= 0 && swingAge <= 5
  context.jumpResetTrial = current.self.ground === true && reach <= 3.3
    && (ownHealthLoss || current.focus === 'SYNC' && recentSwing && swingAge <= 2)
  const freeMelee = !current.self.shielding && !current.self.using && !current.seen.shield
  context.closeExchangeTicks = freeMelee && reach <= 2.1 && previousReach <= 2.4
    ? (previousContext?.closeExchangeTicks || 0) + ticks : 0
  context.risingEntryThreat = freeMelee && context.opponentVerticalPhase === 'rising'
    && reach >= 2.4 && reach <= 3.3 && (closing || context.opponentApproaching)
  context.comboUnderPressure = freeMelee && reach <= 2.6
    && context.recentOwnHits.length >= 2 && current.tick - context.lastOwnHitTick <= 12
  // The demonstrated sword follow-up comes after committing an axe hit, while
  // both fighters remain close. Do not throw away an already charged axe, or
  // equate "the enemy holds a sword" with an unconditional weapon switch.
  context.swordDpsWindow = freeMelee && context.closeExchangeTicks >= 2
    && current.self.held === 7 && current.self.charge < .55
  context.swordCadenceWindow = freeMelee && context.closeExchangeTicks >= 2
    && current.self.held === 0 && current.self.charge >= .75
    && current.self.charge < .85
    && (!context.fallingMeleeThreat || context.ownFallingWindow)
  // A switch is an action, not a complete combo. The old exploration repair
  // only covered axe -> sword; the next sword-held frame used collapsed axe
  // logits again and immediately reset charge. Keep BOTH weapon choices
  // learnable throughout the observed close exchange, without a weapon lock.
  context.swordSustainWindow = freeMelee && context.closeExchangeTicks >= 2
    && current.self.held === 0 && reach <= 2.1
  context.swordCriticalSetupWindow = context.swordSustainWindow
    && current.self.ground === true && current.self.charge >= .3
    && current.self.charge < .75 && !context.fallingMeleeThreat
  context.swordRisingWindow = context.swordSustainWindow
    && current.self.ground === false && current.self.vy > .03
  // Public facing and effective shield only. This offers a learned axe
  // response, never a mechanical click or a hidden opponent cooldown query.
  const yaw = current.seen.yaw * Math.PI / 180
  const sx = current.self.x - current.seen.x, sz = current.self.z - current.seen.z
  const separation = Math.hypot(sx, sz)
  const frontalShield = current.seen.shield && Number.isFinite(yaw) && separation > .01
    && (-Math.sin(yaw) * sx + Math.cos(yaw) * sz) / separation > .1
  const shieldBreakWindow = !current.self.shielding && !current.self.using && frontalShield && reach <= 3
  context.swordShieldBreakWindow = Boolean(shieldBreakWindow && current.self.held === 0)
  context.axeShieldBreakWindow = Boolean(shieldBreakWindow && current.self.held === 7)
  // wasplan: a deep first hit can launch us OUT of range; the next ground
  // return is dangerous even when the original hit was not at the boundary.
  // Observed swing age is public history, not the enemy's private cooldown.
  const recentPressure = current.tick - context.lastOwnHitTick <= 20
  const targetGround = publicMotion ? motion.grounded
    : context.opponentVerticalPhase === 'level-or-apex' && !elevated
  context.groundChainReentry = freeMelee && recentPressure && targetGround
    && reach >= 2.4 && reach <= 3.15 && swingAge >= 6 && swingAge <= 20
    && (closing || context.opponentApproaching || context.enteredReach)
  const edgeHit = ownHealthLoss && (edge(previousReach) || edge(reach))
  const edgeSwing = edge(reach) && recentSwing && (closing || context.opponentApproaching)
  if (edgeHit || edgeSwing) {
    context.edgeRiskUntilTick = current.tick + 12
    context.edgeRiskReason = edgeHit ? 'own-damage-at-boundary' : 'visible-swing-closing-at-boundary'
  } else if (previousContext?.edgeRiskUntilTick >= current.tick) {
    context.edgeRiskUntilTick = previousContext.edgeRiskUntilTick
    context.edgeRiskReason = previousContext.edgeRiskReason
  }
  context.edgeComboRisk = context.edgeRiskUntilTick >= current.tick && reach <= 3
    && !current.self.shielding && !current.self.using && !current.seen.shield
  return context
}

// One ordered selection: a later combo cue must not silently overwrite the
// earlier recognition that the opponent is already descending onto us.
export function meleeTechniqueGoal (request, context) {
  if (context.fallingMeleeThreat && !context.ownFallingWindow)
    return { focus: 'OPPONENT', techniqueCues: ['ESCAPE', 'FLANK'] }
  if (context.risingEntryThreat)
    return { focus: 'SPRINT_KB', techniqueCues: ['CHARGE', 'FLANK'] }
  if (context.shieldRushRetreatWindow)
    return { focus:'ESCAPE',techniqueCues:['COMBO','FLANK'] }
  if (context.groundChainReentry)
    return { focus:'SPRINT_KB',techniqueCues:['ESCAPE','FLANK'] }
  if (context.swordShieldBreakWindow || context.axeShieldBreakWindow)
    return { focus: 'AXE_BREAK', techniqueCues: ['COMBO', 'CHARGE'] }
  if (context.swordSustainWindow)
    return { focus: 'CRITICAL', techniqueCues: ['COMBO', 'CHARGE'] }
  if (context.swordDpsWindow || context.swordCadenceWindow || context.swordComboPressure)
    return { focus: 'COMBO', techniqueCues: ['CHARGE', 'ESCAPE'] }
  if (context.comboUnderPressure)
    return { focus: 'ESCAPE', techniqueCues: ['SPRINT_KB', 'COMBO'] }
  if (context.jumpResetTrial)
    return { focus: 'SYNC', techniqueCues: ['SPRINT_KB', 'COMBO'] }
  if (context.punishmentWindowClosing)
    return { focus: context.ownFallingWindow ? 'CRITICAL' : 'SPRINT_KB',
      techniqueCues: ['CHARGE', 'ESCAPE'] }
  if (context.edgeComboRisk)
    return { focus: 'SPRINT_KB', techniqueCues: ['ESCAPE', 'FLANK'] }
  return { focus: request.focus, techniqueCues: request.techniqueCues }
}

// Reward the fighter's own distant approach, without crediting opponent motion.
export function meleeApproachFeedback (previous, current) {
  if (previous?.trainingScope !== 'fresh_dual_sword_axe_unshielded'
      || current?.trainingScope !== previous.trainingScope
      || !previous.seen?.visible || !current.seen?.visible)
    return 0
  const dx = previous.seen.x - previous.self.x
  const dz = previous.seen.z - previous.self.z
  const distance = Math.hypot(dx, dz)
  if (!Number.isFinite(distance) || distance <= 4.5) return 0
  const ownDx = current.self.x - previous.self.x
  const ownDz = current.self.z - previous.self.z
  const projected = Math.max(-.25, Math.min(.25,
    (ownDx * dx + ownDz * dz) / distance))
  return .12 * projected - .006
}
