"""A changed curriculum cannot be published using stale reference scores."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,unittest

ROOT=Path(__file__).resolve().parents[3]
SCRIPT=Path(__file__).with_name('prepare-publish-candidate.py')

class CorrectionProvenance(unittest.TestCase):
    def test_publication_rejects_stale_dataset_or_reference_before_staging(self):
        current=json.loads((ROOT/'work/wavedog-punengbho/model/checkpoint.json').read_text())
        with tempfile.TemporaryDirectory(prefix='correction-provenance-') as folder:
            base=Path(folder);trained=base/'trained';trained.mkdir()
            dataset=base/'dataset.json';dataset.write_text('{"newCurriculum":true}')
            sha=hashlib.sha256(dataset.read_bytes()).hexdigest()
            (trained/'checkpoint.json').write_text(json.dumps(current))
            receipt={'schema':'supervised-current-state-correction-v1','dataset':str(dataset),
                'datasetSha256':sha,'baselineDatasetSha256':sha,
                'baselineReferenceSha256':current['sha256'],'offlineChecksPassed':False}
            for patch,reason in [
                ({'baselineDatasetSha256':'0'*64},'same unchanged dataset'),
                ({'datasetSha256':'0'*64},'same unchanged dataset'),
                ({'baselineReferenceSha256':'0'*64},'current live reference'),
                ({},'Training checks failed')]:
                with self.subTest(patch=patch):
                    (trained/'receipt.json').write_text(json.dumps({**receipt,**patch}))
                    result=subprocess.run([sys.executable,str(SCRIPT),'--trained',str(trained),
                        '--out',str(base/'must-not-exist')],cwd=ROOT,capture_output=True,text=True)
                    self.assertNotEqual(result.returncode,0)
                    self.assertIn(reason,result.stderr)
                    self.assertFalse((base/'must-not-exist').exists())

if __name__=='__main__':unittest.main()
