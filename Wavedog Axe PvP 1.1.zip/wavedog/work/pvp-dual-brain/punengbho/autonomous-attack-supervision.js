// Offline auxiliary BC only. A positive attack is valid only with the same
// weapon, sprint and jump parents used to label that expert decision.
// Never turn an expert attack with another weapon into an executed PPO action.
import * as tf from '@tensorflow/tfjs'

export function autonomousAttackTargets(rows, logits, lessonWeights = {}) {
  const parents = Object.fromEntries([1, 2, 5].map(h =>
    [h, [...logits[h].argMax(1).dataSync()]]))
  return rows.map((row, i) => {
    const target = row.frame.labels[4]
    const compatible = [1, 2, 5].every(h => parents[h][i] === row.frame.actions[h])
    return {
      target,
      weight: target === 0 || target === 2 && compatible
        ? lessonWeights[row.lesson] ?? 1 : 0
    }
  })
}

export function autonomousAttackLoss(logits, targets, target, weight) {
  if (!weight) return null
  const weights = targets.map(r => r.target === target ? r.weight : 0)
  const total = weights.reduce((a, b) => a + b, 0)
  if (!total) return null
  return tf.mul(weight, tf.div(tf.sum(tf.mul(tf.tensor1d(weights),
    tf.neg(tf.logSoftmax(logits).slice([0, target], [weights.length, 1])
      .reshape([weights.length])))), total))
}
