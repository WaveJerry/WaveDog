// From-scratch recurrent behavior cloning; no random-policy KL anchor and no
// pretending demonstration returns are on-policy PPO experience.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import {OBS_SIZE,gateRegularizer}from '../fresh-policy.js'
import {SharedAdam,loadDualCheckpoint,saveDualCheckpoint}from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,deployedImitationLogits,validateDataset,captureDeployedImitation,accumulate,finishStats}from '../human-imitation.js'
import {exchangeAttackWeights,attackSituation}from '../exchange-imitation-weights.js'
import {skillScore,skillChecks}from './imitation-skill-checks.js'
import {foundationSupervisionWeights,lessonOf}from './foundation-supervision-weights.js'
import {responseSupervisionWeight}from './response-supervision-weight.js'
const root=path.resolve('outputs/punengbho-rebuild-20261117')
const option=(key,fallback)=>{const i=process.argv.indexOf(key);return i<0?fallback:process.argv[i+1]}
const dest=path.resolve(option('--dest',path.join(root,'behavior-cloning')))
const datasetFile=path.resolve(option('--dataset',path.join(root,'demonstrations/dataset.json')))
const source=path.resolve(option('--source',path.join(root,'initial/checkpoint.json')))
const referenceFile=path.resolve(option('--reference-checkpoint',source))
const epochs=Number(option('--epochs',12))
const jumpPositiveWeight=Number(option('--jump-positive-weight',2))
const learningRate=Number(option('--learning-rate',.0003))
const responseWeight=Number(option('--response-window-weight',1))
if(!Number.isFinite(responseWeight)||responseWeight<1||responseWeight>10)throw Error('Invalid response window weight')
const balancedSituations=process.argv.includes('--situation-balanced')
const balancedSkills=process.argv.includes('--balanced-skills')
const shieldSwitchWeight=Number(option('--shield-switch-weight',1))
const attackPositiveWeight=Number(option('--attack-positive-weight',3))
const supervisedHeads=new Set(option('--train-heads','0,1,2,3,4,5,6,7,8').split(',').map(Number))
if(!Number.isFinite(attackPositiveWeight)||attackPositiveWeight<=0||attackPositiveWeight>20)throw Error('Invalid attack weight')
if(!supervisedHeads.size||[...supervisedHeads].some(h=>!Number.isSafeInteger(h)||h<0||h>8))throw Error('Invalid supervised heads')
if(!Number.isFinite(shieldSwitchWeight)||shieldSwitchWeight<1||shieldSwitchWeight>20)throw Error('Invalid shield weight')
if(!Number.isFinite(learningRate)||learningRate<=0||learningRate>.001)throw Error('Invalid BC learning rate')
if(!Number.isFinite(jumpPositiveWeight)||jumpPositiveWeight<1||jumpPositiveWeight>10)throw Error('Invalid jump class weighting')
if(!Number.isSafeInteger(epochs)||epochs<1||epochs>100)throw Error('Invalid epoch count')
if(fs.existsSync(path.join(dest,'receipt.json')))throw Error('Existing training result must be preserved')
fs.mkdirSync(dest,{recursive:true})
const data=JSON.parse(fs.readFileSync(datasetFile))
validateDataset(data)
const situationWeights=balancedSituations?exchangeAttackWeights(data).weights:null
const skillWeights=balancedSkills?foundationSupervisionWeights(data,supervisedHeads):null
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source),{model}=loaded
// Freeze on-server validation until BC/DAgger behavior is demonstrated. PPO
// optimizer/history is preserved, but evaluation bouts cannot change weights.
model.config.trainingStage='behavior-cloning'
const originalParameters=model.params.map(p=>new Float32Array(p.dataSync()))
const optimizer=new SharedAdam(model.params,{learningRate})
let steps=0,best=null,bestScore=Infinity
const log=row=>{fs.appendFileSync(path.join(dest,'events.jsonl'),JSON.stringify(row)+'\n');
  console.log(JSON.stringify({stage:row.stage,epoch:row.epoch,steps:row.steps,meanLoss:row.meanLoss,
    selectionScore:row.selectionScore,offlineChecksPassed:row.offlineChecksPassed,checks:row.checks,
    sha256:row.best?.saved?.sha256,validationNll:row.validation?.meanNll}))}
function auditParameters(){
  const groups={}
  for(const[i,param]of model.params.entries()){
    const name=param.name.replace(/^dual\d+\./,'').split('.')[0]
    const g=groups[name]||={parameters:0,changed:0,maxAbsDelta:0}
    const values=param.dataSync(),before=originalParameters[i]
    for(let k=0;k<values.length;k++){const delta=Math.abs(values[k]-before[k]);g.parameters++;
      if(delta>0)g.changed++;g.maxAbsDelta=Math.max(g.maxAbsDelta,delta)}
  }
  return groups
}
function loss(segment,initial,lesson){
  let state=initial;const terms=[],gates=[]
  for(const frame of segment){
    const out=model.step(tf.tensor2d([frame.observation],[1,OBS_SIZE]),state,frame.legalMasks,frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures)
    state=out.state;gates.push(out.gate)
    const logits=deployedImitationLogits(model,out.logits,frame)
    for(const [h,a]of Object.entries(frame.labels)){
      if(!supervisedHeads.has(Number(h)))continue
      let multiplier=h==='4'?(a===2?attackPositiveWeight:1):h==='2'&&a===1?jumpPositiveWeight:1
      if(skillWeights)multiplier*=skillWeights.weights[lesson]?.[h]?.[a]??1
      if(h==='4'&&situationWeights)multiplier*=Math.max(.25,Math.min(10,situationWeights[attackSituation(frame)]?.[a]??1))
      if(h==='5'&&a===0)multiplier*=frame.observation[23]>.5?shieldSwitchWeight:Math.min(3,shieldSwitchWeight)
      multiplier*=responseSupervisionWeight(frame,Number(h),responseWeight)
      terms.push(tf.mul(multiplier,tf.neg(tf.sum(tf.mul(tf.oneHot([a],logits[h].shape[1]),tf.logSoftmax(logits[h]))))))
    }
  }
  return tf.add(tf.mean(tf.stack(terms)),gateRegularizer(gates,model.gateMode))
}
function evaluate(split,policy=model){
  const stats={labels:{},drift:{}},byLesson={}
  for(const trace of data.trajectories.filter(t=>t.split===split)){
    let state=policy.initialState()
    try{for(const frame of trace.frames){
      const raw=advance(policy,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures);state=raw.state
      const captured=captureDeployedImitation(policy,raw,frame)
      accumulate(stats,frame,captured)
      const lesson=lessonOf(trace)
      accumulate(byLesson[lesson]||=( {labels:{},drift:{}} ),frame,captured)
    }}finally{disposeState(state)}
  }
  return {...finishStats(stats),byLesson:Object.fromEntries(Object.entries(byLesson).map(([k,v])=>[k,finishStats(v)]))}
}
const scoreOf=skillScore
let baseline,referenceSha256=loaded.manifest.sha256
if(referenceFile!==source){
  const reference=loadDualCheckpoint(referenceFile)
  try{baseline=evaluate('validation',reference.model);referenceSha256=reference.manifest.sha256}
  finally{reference.adam.dispose();reference.model.dispose()}
}else baseline=evaluate('validation')
log({stage:'baseline',validation:baseline,config:model.config,ppoEligible:false,skillWeights})
try{
  for(let epoch=0;epoch<epochs;epoch++){
    let lossSum=0,segments=0
    // Shuffle whole bouts reproducibly; preserve frame order and reset memory
    // between bouts. Avoid always training the new skill last in every epoch.
    const ordered=data.trajectories.filter(t=>t.split==='train').map(trace=>({trace,
      key:crypto.createHash('sha256').update(epoch+':'+trace.source).digest('hex')})).sort((a,b)=>a.key.localeCompare(b.key))
    for(const {trace} of ordered){
      let state=model.initialState()
      try{for(let start=0;start<trace.frames.length;start+=24){
        const segment=trace.frames.slice(start,start+24)
        // Missing/out-of-scope labels still advance recurrent memory. They
        // cannot become a gate-only optimizer update or an empty loss stack.
        if(segment.some(frame=>Object.keys(frame.labels).some(h=>supervisedHeads.has(Number(h)))))tf.tidy(()=>{
          const {value,grads}=tf.variableGrads(()=>loss(segment,state,lessonOf(trace)),model.params)
          const norm=Math.sqrt(tf.addN(Object.values(grads).map(g=>tf.sum(tf.square(g)))).dataSync()[0])
          const v=value.dataSync()[0];if(!Number.isFinite(norm)||!Number.isFinite(v))throw Error('Non-finite BC loss')
          const scale=Math.min(1,1/Math.max(norm,1e-12))
          optimizer.applyGradients(Object.fromEntries(Object.entries(grads).map(([n,g])=>[n,tf.mul(g,scale)])))
          lossSum+=v;segments++;steps++
        })
        // Every tick advances memory; TBPTT only truncates gradients.
        for(const frame of segment)state=advance(model,state,frame.observation,false,frame.legalMasks,frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures).state
      }}finally{disposeState(state)}
      if(process.argv.includes('--trace-progress'))console.log(JSON.stringify({stage:'trace-trained',epoch,source:trace.source,steps}))
    }
    const validation=evaluate('validation')
    const critical=validation.labels['4:2'],jump=validation.labels['2:1']
    const lessonScores=Object.values(validation.byLesson).map(scoreOf)
    const score=lessonScores.reduce((a,b)=>a+b,0)/lessonScores.length
    const epochChecks=skillChecks(baseline,validation),eligible=Object.values(epochChecks).every(Boolean)
    log({stage:'epoch',epoch,steps,meanLoss:lossSum/segments,validation,selectionScore:score,epochChecks})
    if(!best||eligible&&!best.eligible||eligible===best.eligible&&score<bestScore){
      bestScore=score
      const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,loaded.adam,
        {...loaded.counters,humanImitationUpdates:(loaded.counters.humanImitationUpdates||0)+steps,
          behaviorCloningSteps:(loaded.counters.behaviorCloningSteps||0)+steps})
      best={epoch,steps,saved,validation,eligible,parameterChanges:auditParameters()}
      fs.writeFileSync(path.join(dest,'best.json'),JSON.stringify(best,null,2))
    }
  }
  const checks=skillChecks(baseline,best.validation)
  const groups=best.parameterChanges
  const allBackbonesTrained=groups.fast?.changed>0&&Array.from({length:model.config.layers},(_,i)=>groups['slow-'+i]?.changed>0).every(Boolean)
    &&groups['gate-in']?.changed>0
  const parentReceipt=source!==referenceFile?JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json'))):null
  const imitationStepsSinceReference=(parentReceipt?.imitationStepsSinceReference??parentReceipt?.best.steps??0)+best.steps
  const receipt={schema:'fresh-recurrent-bc-v1',source,dataset:datasetFile,
    referenceCheckpoint:referenceFile,referenceSha256,
    sourceSha256:loaded.manifest.sha256,baseline,best,checks,jumpPositiveWeight,offlineChecksPassed:Object.values(checks).every(Boolean),
    datasetSha256:crypto.createHash('sha256').update(fs.readFileSync(datasetFile)).digest('hex'),
    causalSpatialFeaturesUsed:true,causalThreatFeaturesUsed:model.config.publicThreatInputs===12,responseWeight,ppoEligible:false,
    allBackbonesTrained,parameterChanges:groups,learningRate,balancedSituations,shieldSwitchWeight,imitationStepsSinceReference,
    supervisedHeads:[...supervisedHeads],attackPositiveWeight,balancedSkills,skillWeights,
    noInheritedWeights:source===path.join(root,'initial/checkpoint.json'),originalLiveOverwritten:false,
    ppoOptimizerSteps:loaded.adam.steps,livePvpImprovementVerified:false}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2));log({stage:'complete',...receipt})
}finally{optimizer.dispose();loaded.adam.dispose();model.dispose()}
