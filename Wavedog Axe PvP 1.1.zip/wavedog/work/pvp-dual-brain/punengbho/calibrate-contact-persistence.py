"""Offline spacing reserve estimated only from whole training bouts."""
from pathlib import Path
import argparse,hashlib,json,math
p=argparse.ArgumentParser();p.add_argument("--dataset",type=Path,required=True);p.add_argument("--out",type=Path,required=True);a=p.parse_args()
if a.out.exists():raise RuntimeError("Preserve prior calibration")
data=json.loads(a.dataset.read_text(encoding="utf8"));samples=[];bouts=[]
for trace in data["trajectories"]:
    if trace["split"]!="train" or trace.get("sourceKind")!="dagger-expert-relabel":continue
    source=Path("work/wavedog-punengbho/runtime")/(trace["matchId"]+"-frames.jsonl")
    raw=source.read_bytes();frames=[json.loads(s)for s in raw.decode().splitlines()];count=0
    for i,f in enumerate(frames):
        if not(f.get("nativeDealt",0)>0 or f.get("nativeReceived",0)>0)or not f.get("seen",{}).get("visible"):continue
        distance=lambda r:math.hypot(r["self"]["x"]-r["seen"]["x"],r["self"]["z"]-r["seen"]["z"])
        future=[n for n in frames[i+1:i+7]if 0<n["tick"]-f["tick"]<=3 and n.get("seen",{}).get("visible")]
        if not future or max(n["tick"]for n in future)-f["tick"]<3:continue
        delta=max(0,max(distance(n)for n in future)-distance(f))
        if delta<4:samples.append(delta);count+=1
    bouts.append({"matchId":trace["matchId"],"split":"train","samples":count,"sourceSha256":hashlib.sha256(raw).hexdigest()})
if len(samples)<100:raise RuntimeError("Insufficient actual contact evidence")
samples.sort();reserve=samples[int(.75*(len(samples)-1))]
result={"schema":"offline-contact-separation-reserve-v1","trainingDataset":str(a.dataset.resolve()),
    "datasetSha256":hashlib.sha256(a.dataset.read_bytes()).hexdigest(),"sampleCount":len(samples),"bouts":bouts,
    "horizonTicks":3,"quantile":.75,"separationReserve":reserve,"validationUsed":False,
    "limitation":"Observed post-damage separation includes movement and knockback; a training estimate, not a guaranteed one-hit bound."}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2),encoding="utf8")
print(json.dumps({"samples":len(samples),"reserve":reserve,"validationUsed":False}))
