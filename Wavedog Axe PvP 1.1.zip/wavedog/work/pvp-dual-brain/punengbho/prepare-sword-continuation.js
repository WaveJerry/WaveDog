// Offline labels on complete episodes. Never replaces the actor's decisions.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import {criticalExpert,observeLearnerInput,sourceSha256}from './joint-melee-expert.cjs'
import {validateDataset}from '../human-imitation.js'
import {learnerRequest}from './causal-learner-input.js'
import {directionalMovementSupervision}from './directional-movement-supervision.js'
const [source,destination]=process.argv.slice(2)
if(!source||!destination)throw Error('source dataset and new destination required')
if(fs.existsSync(destination))throw Error('Preserve prior dataset')
const data=JSON.parse(fs.readFileSync(source)),counts={frames:0,heldJump:0,staticShieldWait:0,mechanicalContext:0}
for(const t of data.trajectories){
  const history={},rawFile=path.resolve('work/wavedog-punengbho/runtime',t.matchId+'-frames.jsonl')
  const raw=t.sourceKind==='dagger-expert-relabel'&&fs.existsSync(rawFile)
    ?fs.readFileSync(rawFile,'utf8').trim().split('\n').map(JSON.parse):null
  const rows=new Map(raw?.map(r=>[r.tick,r])||[])
  const advice=new Map()
  for(const row of raw||[]){
    const req={...learnerRequest(row,{matchId:t.matchId,opponent:t.opponent}),jumpInputVersion:2}
    advice.set(row.tick,directionalMovementSupervision(criticalExpert(req,history),req))
    observeLearnerInput(history,req,{...row.executed,attackPacket:row.attackPacket,
      held:row.attackHeld??row.self.held})
  }
  for(const f of t.frames){
    f.legalMasks[2][1]=true
    if(!raw){
      // Old human data did not establish whether an airborne key was held.
      // Preserve every other label, but don't turn absence into a release.
      if(f.publicRequest?.self?.ground===false)delete f.labels[2]
      continue
    }
    const r=rows.get(f.tick),a=advice.get(f.tick)
    if(!r||!a)throw Error('Exact learner frame unavailable')
    const mechanical=Boolean(r.mode&&r.mode!=='NEURAL')
    if(mechanical)f.labels={}
    else{
      // A revised tactical action is one coherent vector. Replacing only
      // sprint/jump/weapon/attack kept old retreat/turn labels under a new
      // close-sword lesson (including impossible backwards sprint intent).
      // Recompute EVERY DAgger label from this teacher version, including
      // forecast escape/static-shield/ordinary preparation. Retaining older
      // partial teachers silently reintroduces the same contradictions.
      // Original human demonstrations remain above, without relabeling.
      f.labels={...a.labels}
    }
    f.actions=[...f.actions];for(const[h,v]of Object.entries(f.labels))f.actions[h]=v
    if(mechanical)counts.mechanicalContext++
    f.expertReason=mechanical?'mechanical-prefix-context-only':a.reason
    if(a.contactForecast)f.contactForecast=a.contactForecast
    f.publicRequest.jumpInputVersion=2
    f.supervisionTargetTick=f.tick;f.labelDelayTicks=0
    f.ppoEligible=false;f.expertSourceSha256=sourceSha256
    counts.frames++;counts.heldJump+=Number(!r.self.ground&&f.labels[2]===1)
    counts.staticShieldWait+=Number(f.expertReason==='spacing-wait-for-shield-release')
  }
  if(raw)t.expertSourceSha256=sourceSha256
}
data.jumpInputVersion=2;data.actionSemantics='jump key held/released; vanilla physics alone controls takeoff'
const validated=validateDataset(data)
fs.mkdirSync(path.dirname(destination),{recursive:true})
fs.writeFileSync(destination,JSON.stringify(data))
fs.writeFileSync(path.join(path.dirname(destination),'continuation-audit.json'),JSON.stringify({
  counts,validated,sourceSha256:crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  expertSourceSha256:sourceSha256,wholeBoutSplitsUnchanged:true,mechanicalFramesContextOnly:true,
  coherentJointActionRelabeling:true,newPPOData:false,newHumanDemonstrationsClaimed:false},null,2))
console.log(JSON.stringify({counts,validated}))
