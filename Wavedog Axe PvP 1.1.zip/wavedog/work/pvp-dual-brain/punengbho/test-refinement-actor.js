import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import {spawn} from 'node:child_process'
import {fileURLToPath} from 'node:url'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy} from '../fresh-policy.js'
import {SharedAdam,saveDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {PublicMotionMonitor} from '../../pvp-player-client/protocol-high-rate-motion.js'
await tf.setBackend('cpu');await tf.ready()
const dir=fs.mkdtempSync(path.resolve('outputs/full-model-86-20261118/actor-fixture-'))
const checkpoint=path.join(dir,'checkpoint.json')
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:32,interval:2,memory:4,
  distributionVersion:2,trainingStage:'behavior-cloning',behaviorPriorVersion:0,
  publicMotionInputs:32,sameTickRefinementVersion:1,wholeFightControlVersion:1,pureAimVersion:2,jumpInputVersion:2})
const adam=new SharedAdam(model.params);saveDualCheckpoint(checkpoint,model,adam,{fixtureOnly:true});adam.dispose();model.dispose()
const actor=spawn(process.execPath,[fileURLToPath(new URL('./fresh-actor.js',import.meta.url)),checkpoint],
  {stdio:['pipe','pipe','pipe'],windowsHide:true})
const received=[],waiters=[];let stderr=''
actor.stderr.on('data',b=>{stderr+=b})
readline.createInterface({input:actor.stdout}).on('line',line=>{
  const row=JSON.parse(line);received.push(row)
  for(const w of [...waiters])if(w.test(row)){waiters.splice(waiters.indexOf(w),1);clearTimeout(w.timer);w.resolve(row)}
})
const wait=test=>new Promise((resolve,reject)=>{
  const found=received.find(test);if(found){resolve(found);return}
  const w={test,resolve,timer:setTimeout(()=>reject(Error('Actor fixture timeout '+stderr)),30000)};waiters.push(w)
})
const send=row=>actor.stdin.write(JSON.stringify(row)+'\n')
try{
  await wait(r=>r.event==='ready')
  const motion=new PublicMotionMonitor();motion.reset('fixture-bout')
  for(let i=0;i<2;i++)motion.ingest({matchId:'fixture-bout',revision:i+1,tick:10,atMs:100+i*50,source:'packet',
    self:{position:{x:1058,y:221,z:960},grounded:true,sourceTick:i},
    opponent:{position:{x:1061.5-i*.2,y:221,z:960},grounded:true,sourceTick:i}})
  const req={fighter:'fixture',opponent:'fixture-other',matchId:'fixture-bout',tick:10,requestId:1,
    style:'MIXED',focus:'FREE',yaw:-90,pitch:0,
    self:{x:1058,y:221,z:960,eyeY:222.62,ground:true,charge:1,health:20,held:0},
    seen:{visible:true,x:1061.3,y:221,z:960,held:'DIAMOND_AXE',arrows:[]},
    publicMotionAnalysis:motion.analyze(150)}
  send({...req,command:'reset',learning:false})
  send({...req,command:'act'})
  await wait(r=>r.requestId===1&&r.model==='DUAL-GRU-GTRXL')
  send({...req,command:'refine',requestId:2,controlRevision:1,observationRevision:2})
  const response=await wait(r=>r.requestId===2)
  assert.equal(response.event,'refined_action',JSON.stringify(response))
  assert.equal(response.recurrentMemoryAdvanced,false);assert.equal(response.ppoEligible,false)
  assert.equal(response.inputEvidence.publicMotionFeatures[0],1)
  send({command:'model_status',requestId:'after-refinement'})
  const status=await wait(r=>r.requestId==='after-refinement')
  assert.equal(status.actors[0].frames,1,'a refinement is not another PPO frame')
  send({...req,command:'refine',requestId:3,controlRevision:1,observationRevision:2})
  assert.equal((await wait(r=>r.requestId===3)).reason,'old-control-revision')
  send({...req,command:'refine',requestId:4,controlRevision:2,observationRevision:2,tick:11})
  assert.equal((await wait(r=>r.requestId===4)).reason,'physical-anchor-changed')
  assert(!received.some(r=>r.event==='error'),JSON.stringify(received))
  fs.writeFileSync(path.join(dir,'report.json'),JSON.stringify({passed:true,syntheticFixtureOnly:true,
    mainServerTouched:false,modelTrained:false,actorFrames:status.actors[0].frames},null,2))
  console.log('WHOLE_FIGHT_ACTOR_REFINEMENT_TRANSPORT_PASS '+dir)
}finally{for(const w of waiters)clearTimeout(w.timer);actor.kill()}
