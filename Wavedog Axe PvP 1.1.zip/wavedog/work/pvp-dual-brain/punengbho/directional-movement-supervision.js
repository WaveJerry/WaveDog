// Counterfactual offline teaching only. Reuses existing forward/sprint/view/
// turn-back actions; never adds a runtime keep-distance or attack controller.
export function directionalMovementSupervision(advice,request){
 const s=request.self,t=request.seen,labels={...advice.labels}
 if(!s||!t?.visible||labels[0]!==2||s.food<=6||s.using)return advice
 const distance=Math.hypot(t.x-s.x,t.z-s.z)
 // Near a live strike, a view reversal gives the next hit away even when
 // a backwards label was intentional. Keep watching during a short dodge.
 // Long recovery travel can turn only after a real gap has been established.
 if(distance<=3.45&&Number.isFinite(s.charge))return advice
 // Short close corrections remain available; teach larger spacing transfers
 // with a turn + ordinary forward sprint instead of illegal backwards sprint.
 if(distance<2.05&&advice.reason!=='axe-spacing-committed-recovery')return advice
 const attack=labels[4]===2,critical=attack&&s.wireFalling===true
 labels[0]=1;labels[1]=critical?0:1;labels[6]=0;labels[7]=3;labels[8]=Number(attack)
 const actions=[...advice.actions];for(const[h,a]of Object.entries(labels))actions[h]=a
 return {...advice,labels,actions,movementTeaching:'face-travel-direction-with-optional-attack-turn-back-v1',
  viewYawOffsetDegrees:-180,viewPitchOffsetDegrees:0,counterfactual:true,ppoEligible:false}
}
