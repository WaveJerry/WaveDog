"""Read-only attribution of the first shieldless exchange after escape landing."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, collections, hashlib, json

ROOT=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--count',type=int,default=12)
p.add_argument('--matches',nargs='+',help='Audit these completed bouts, including other public opponents')
a=p.parse_args();runtime=ROOT/'work/wavedog-punengbho/runtime'
events=[json.loads(l)for l in (runtime/'client-events.jsonl').read_text(encoding='utf8').splitlines()if l.strip()]
reports=[]
for file in sorted(runtime.glob('*-report.json'),key=lambda x:x.stat().st_mtime,reverse=True):
    r=json.loads(file.read_text(encoding='utf8'))
    if (r.get('matchId')in a.matches if a.matches else r.get('opponent')=='WaveJerry') and r.get('outcome',{}).get('reason')=='death' and not r['outcome'].get('invalid'):
        reports.append((file,r))
    if len(reports)>=a.count:break

def eligible(f):
    s,o=f['self'],f['observation']
    return f['mode']=='NEURAL' and f['seen'].get('visible') and o['reach']<=3 and s['charge']>=.9 \
        and not o.get('targetShieldFacing') and s['held']in[0,7]

def brief(f):
    s,o,c=f['self'],f['observation'],f.get('command')or{}
    return dict(tick=f['tick'],mode=f['mode'],held=s['held'],charge=round(s['charge'],3),
        reach=round(o['reach'],3),ground=s['ground'],vy=round(s['vy'],3),critical=s.get('critical'),
        targetVy=o.get('targetVelocity',{}).get('y'),criticalThreat=o.get('targetCriticalThreat'),
        targetShield=o.get('targetShieldFacing'),requestedSlot=c.get('slot'),requestedAttack=c.get('attack'),
        attackPacket=f.get('attackPacket'),attackCharge=f.get('attackCharge'),suppressed=f.get('attackSuppressedReason'),
        forward=c.get('forward'),side=c.get('side'),sprint=c.get('sprint'),jump=c.get('jump'),
        yawOffset=c.get('aimYawOffset'),owner=f.get('owners',{}).get('attack'),
        modelAge=f.get('timings',{}).get('modelActionAgeTicks'),wireGround=s.get('wireGround'),
        wireFalling=s.get('wireFalling'))

episodes=[];landings=[]
for file,r in reversed(reports):
    mid=r['matchId'];path=Path(r['completedFrames']);raw=path.read_bytes()
    fs=[json.loads(l)for l in raw.splitlines()];es=[e for e in events if e.get('matchId')==mid]
    neural=[f for f in fs if f['mode']=='NEURAL']
    hits=[e for e in es if e['type']=='damage'and e.get('attacker')=='Punengbho'and e.get('amount',0)>0 and not e.get('cancelled')]
    hit_ids={e['attackId']:e for e in hits}
    packets=[f for f in neural if f.get('attackPacket')]
    waits=[f for f in neural if eligible(f) and f['self']['held']==0 and not f.get('command',{}).get('attack')]
    switches=[(x,y)for x,y in zip(neural,neural[1:])if y['tick']==x['tick']+1 and x['self']['held']!=y['self']['held']]
    ep=dict(matchId=mid,frames=len(fs),neuralFrames=len(neural),neuralAttackPackets=len(packets),
        swordAttackPackets=sum(f.get('attackHeld')==0 for f in packets),axeAttackPackets=sum(f.get('attackHeld')==7 for f in packets),
        swordNativeHits=sum(f.get('attackHeld')==0 and f['attackId']in hit_ids for f in packets),
        swordNativeCriticals=sum(f.get('attackHeld')==0 and hit_ids.get(f['attackId'],{}).get('nativeCritical',False)for f in packets),
        chargedReachableSwordWaitFrames=len(waits),weaponSwitches=len(switches),
        attackSuppression=dict(collections.Counter(f.get('attackSuppressedReason') for f in neural if f.get('command',{}).get('attack')and not f.get('attackPacket'))),
        opponent=r.get('opponent'),source={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()},policySha=r['policySha'])
    episodes.append(ep)
    handoffs=[e for e in es if e['type']=='handoff'and e.get('from')=='ESCAPE'and e.get('to')=='NEURAL']
    used=set()
    for handoff in handoffs:
        i=next((i for i,f in enumerate(fs)if f['tick']>=handoff['tick']and f['self']['ground']),None)
        if i is None or fs[i]['tick']>handoff['tick']+18 or fs[i]['tick']in used:continue
        used.add(fs[i]['tick']);landing=fs[i];window=fs[max(0,i-3):i+17]
        valid=[f for f in window if f['tick']>=landing['tick'] and eligible(f)]
        attacks=[f for f in window if f['tick']>=landing['tick']and f['mode']=='NEURAL'and f.get('attackPacket')]
        near=next((f for f in window if f['tick']>=landing['tick']and f['mode']=='NEURAL'and f['observation']['reach']<=3),None)
        began=landing['capturedAt'];ended=window[-1]['capturedAt']
        received=[e for e in es if e['type']=='damage'and e.get('victim')=='Punengbho'and e.get('amount',0)>0
            and not e.get('cancelled')and began<=datetime.fromisoformat(e['at'].replace('Z','+00:00')).timestamp()*1000<=ended]
        first=valid[0]if valid else None
        futureAttack=next((f for f in attacks if first and f['tick']>=first['tick']),None)
        landings.append(dict(matchId=mid,handoff=handoff,landingTick=landing['tick'],landing=brief(landing),
            firstReachable=brief(near)if near else None,firstChargedOpportunity=brief(first)if first else None,
            delayAfterFirstChargedOpportunity=futureAttack['tick']-first['tick']if futureAttack and first else None,
            received=received,frames=[brief(f)for f in window]))

report={'createdAt':datetime.now(timezone.utc).isoformat(),'episodes':episodes,'landings':landings,
    'limits':['A reachable charged observation is a candidate window, not proof of an unobstructed server hit.',
              'Intentional evasion or a near descending critical can justify waiting; the frame sequence supplies context.',
              'No new match started, no training or deployment performed by this audit.']}
a.out.mkdir(parents=True,exist_ok=True);(a.out/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
summary={k:sum(ep[k]for ep in episodes)for k in ['neuralFrames','neuralAttackPackets','swordAttackPackets','axeAttackPackets','swordNativeHits','swordNativeCriticals','chargedReachableSwordWaitFrames','weaponSwitches']}
summary.update(episodes=len(episodes),landings=len(landings),landingsWithReceivedDamage=sum(bool(l['received'])for l in landings))
print(json.dumps(summary))
for l in landings:
    print(json.dumps({k:l[k]for k in ['matchId','landingTick','landing','firstChargedOpportunity','delayAfterFirstChargedOpportunity']},ensure_ascii=True))
