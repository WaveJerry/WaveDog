import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE,biasedActionLogits,maskActionLogits,ppoLoss}from '../fresh-policy.js'
import {deployedImitationLogits,disposeState}from '../human-imitation.js'
import {conditionCombatObservation}from '../combat-observation.js'
await tf.setBackend('cpu');await tf.ready()
const config={fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:2,actionConditionedAttack:1,combatObservationVersion:2}
const model=new DualPolicy(config),old=Array(OBS_SIZE).fill(0)
old[60]=.7;assert.equal(conditionCombatObservation(old,{},{}),old,'legacy inputs unchanged')
const x=conditionCombatObservation(old,{self:{sprint:true,wireFalling:true,wireGround:false,
  attackAgeTicks:13,weaponAgeTicks:20,food:20}},config)
assert.equal(x[60],1);assert.equal(x[61],1);assert.equal(x[64],13/25)
const masks=[9,2,2,2,5,5,13,7,2].map(n=>Array(n).fill(true))
const actions=[1,0,0,0,2,1,6,3,0],context={distributionVersion:2,actionConditionedAttack:1}
tf.tidy(()=>{
  model.actionChoiceOut.w.assign(tf.onesLike(model.actionChoiceOut.w))
  const out=model.step(tf.tensor2d([x]),null,masks)
  const live=maskActionLogits(biasedActionLogits(out.logits,x,context,actions,model),masks)
  const train=deployedImitationLogits(model,out.logits,{observation:x,labels:{4:2},actions,context,legalMasks:masks})
  assert.deepEqual(live.map(h=>[...h.dataSync()]),train.map(h=>[...h.dataSync()]))
  for(const h of [0,1,2,3,5,6,7,8])assert.deepEqual([...live[h].dataSync()],[...out.logits[h].dataSync()],
    'conditional attack never overrides another selected control')
})
const frame={observation:x,actions,context,legalMasks:masks,executedHeads:Array(9).fill(true),
  oldHeadLogProbs:Array(9).fill(-1),advantage:1,target:0}
const {value,grads}=tf.variableGrads(()=>ppoLoss(model,[[frame]]),model.params)
assert(Number.isFinite(value.dataSync()[0]))
for(const variable of model.actionChoiceOut.params)assert(grads[variable.name], 'conditional head receives PPO gradients')
for(const t of [value,...Object.values(grads)])t.dispose()
model.dispose();console.log('REBUILT_POLICY_PASS: legacy compatibility, exact BC/PPO distribution, learned conditional attack')
