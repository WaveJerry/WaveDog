"""Read-only, episode-complete audit of the old counter -> escape path."""
from pathlib import Path
import argparse, collections, hashlib, json, shutil

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--count', type=int, default=6)
args = parser.parse_args()
runtime = ROOT / 'work/wavedog-punengbho/runtime'
events = [json.loads(line) for line in (runtime / 'client-events.jsonl').read_text().splitlines()]
ended = {e['matchId'] for e in events if e['type'] == 'end'}
ids = [e['matchId'] for e in events if e['type'] == 'prepare' and e.get('opponent') == 'WaveJerry'
       and e['matchId'] in ended][-args.count:]
args.out.mkdir(parents=True, exist_ok=True)
windows, manifest = [], {}
for mid in ids:
    bout_events = [e for e in events if e.get('matchId') == mid]
    for suffix in ['frames.jsonl', 'packets.jsonl']:
        source = runtime / f'{mid}-{suffix}'
        target = args.out / source.name
        shutil.copy2(source, target)
        manifest[target.name] = hashlib.sha256(target.read_bytes()).hexdigest()
    rows = [json.loads(line) for line in (runtime / f'{mid}-frames.jsonl').read_text().splitlines()]
    packets = [json.loads(line) for line in (runtime / f'{mid}-packets.jsonl').read_text().splitlines()]
    current = []
    for row in rows:
        if row['mode'] == 'ESCAPE':
            current.append(row)
            continue
        if not current:
            continue
        exposed_fall = [f for f in current if f['self']['critical'] and f['observation']['reach'] <= 3
                        and not f['observation']['targetShieldFacing']]
        attacks = []
        for f in current:
            if not f['attackPacket']:
                continue
            damage = [e for e in bout_events if e['type'] == 'damage' and e.get('attacker') == 'Punengbho'
                      and e.get('attackId') == f['attackId']]
            attacks.append({'tick': f['tick'], 'attackId': f['attackId'], 'kind': f['command']['kind'],
                            'charge': f['attackCharge'], 'damage': damage,
                            'packets': [p for p in packets if p['tick'] == f['tick']]})
        reason = 'native-critical' if any(d['nativeCritical'] for a in attacks for d in a['damage']) else (
            'exposed-fall-undercharged' if exposed_fall else 'no-exposed-fall-in-reach')
        windows.append({'matchId': mid, 'firstTick': current[0]['tick'], 'lastTick': current[-1]['tick'],
                        'classification': reason, 'exposedFallFrames': len(exposed_fall),
                        'maximumChargeInExposedFall': max((f['self']['charge'] for f in exposed_fall), default=0),
                        'attacks': attacks, 'handoff': [e for e in bout_events if e['type'] == 'handoff'
                            and e.get('from') == 'ESCAPE' and current[0]['tick'] <= e['tick'] <= row['tick']]})
        current = []
selected = [e for e in events if e.get('matchId') in ids]
(args.out / 'events.json').write_text(json.dumps(selected, indent=2), encoding='utf-8')
summary = dict(collections.Counter(w['classification'] for w in windows))
report = {'matches': ids, 'completeEpisodesOnly': True, 'summary': summary, 'windows': windows,
          'sourceSha256': manifest, 'limitations': 'Recorded observations cannot prove a counterfactual hit; native receipts confirm actual criticals only.'}
(args.out / 'audit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({'matches': len(ids), 'windows': len(windows), **summary}))
