import {publicSpatialFeatures} from '../public-spatial-features.js'
// Offline labels only: preserve melee technique and change locomotion context.
export function retreatPurposeSupervision(advice,request){
  if(!Array.isArray(advice.actions))return advice
  if(advice.reason?.startsWith('ground-control-'))return advice
  // A visible side exit/hold during an imminent forecast is already the wall
  // response. The generic recovered-axe lesson must not turn it into a rush.
  if(advice.reason?.startsWith('avoid-forecast-retaliation-critical-lateral-exit'))return advice
  const s=request.self,t=request.seen,g=publicSpatialFeatures(request)
  if(!g[0]||s.held!==7||t.shield||t.shieldRaised)return advice
  const labels={...advice.labels},reach=g[5]*8,distance=g[7]*8,charge=s.charge??0
  const backward=labels[0]===2||labels[0]===1&&[0,12].includes(labels[6])
  let reason=advice.reason,changed=false
  const set=(move,sprint)=>{labels[0]=move;labels[1]=sprint;labels[6]=6;changed=true}
  if(advice.reason==='urgent-legal-interrupt-before-full-charge'||advice.reason==='persistent-rush-low-axe-close-sword'){
    set(1,1);reason=advice.reason
  }else if(g[1]*8<.9){
    // No retreat into a blocked escape. Preserve the existing close sword
    // fallback; with space in front, a ready axe can prepare its next entry.
    set(reach<=3||charge>=.9?1:0,reach<=3||charge>=.9?1:0)
    reason='purpose-blocked-escape-face-reengage'
  }else if(charge>=.9&&!advice.reason.includes('avoid-')){
    set(1,1);reason='purpose-ready-axe-reengage'
  }else if(backward&&reach<=3.45){
    set(2,0);reason='purpose-near-threat-face-while-spacing'
  }else if(backward&&distance>4.3&&g[6]<.12){
    set(0,0);reason='purpose-safe-gap-recover-facing'
  }
  if(!changed)return advice
  if(labels[4]===2&&s.wireFalling)labels[1]=0
  const actions=[...advice.actions];for(const[h,a]of Object.entries(labels))actions[h]=a
  return {...advice,labels,actions,reason,viewYawOffsetDegrees:0,
    counterfactual:true,ppoEligible:false,movementTeaching:'retreat-has-a-recovery-purpose-v1'}
}
