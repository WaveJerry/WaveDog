import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {ACTION_WIDTHS}from '../fresh-policy.js'
import {combatFlowTargets,combatFlowPurposeLoss}from './combat-flow-purpose-loss.js'
await tf.setBackend('cpu');await tf.ready()
const sword={publicRequest:{self:{held:0,x:0,z:0,ground:true,charge:.95},
 seen:{visible:true,x:0,z:1.8,shield:false}},labels:{1:0,2:1,4:2,5:1,6:6},
 expertReason:'close-sword-early-useful-damage'}
const axe={publicRequest:{self:{held:7,x:0,z:0,ground:true,charge:.075},
 seen:{visible:true,x:0,z:3.1,shield:false}},labels:{4:0,5:0}}
const shield={...sword,publicRequest:{...sword.publicRequest,seen:{...sword.publicRequest.seen,shield:true}},
 labels:{4:2,5:0,6:6},expertReason:'public-shield-axe-then-sword'}
const rows=[sword,axe,shield].map(frame=>({frame})),heads=ACTION_WIDTHS.map(w=>tf.variable(tf.zeros([3,w])))
try{
 const {value,grads}=tf.variableGrads(()=>tf.tidy(()=>combatFlowPurposeLoss(rows,heads,1)),heads)
 assert(Number.isFinite(value.dataSync()[0]))
 const g=h=>grads[heads[h].name].arraySync()
 assert(g(4)[0][2]<0&&g(4)[0][0]>0,'ready sword attack must learn now, rather than wait')
 assert(g(2)[0][1]<0,'the same early-hit decision prepares the next jump')
 assert(g(1)[0][0]<0&&g(5)[0][1]<0&&g(6)[0][6]<0,'sword timing, weapon and facing learn together')
 assert(g(4)[1][0]<0&&g(4)[1][2]>0,'near-zero axe recovery cannot learn repeated clicks')
 assert(g(4)[2][2]<0&&g(5)[2][0]<0,'a deep shield continuation learns axe and attack together')
 value.dispose();Object.values(grads).forEach(g=>g.dispose())
 assert.deepEqual(combatFlowTargets({...sword,labels:{}}),[],'mechanical context frames receive no imitation target')
 assert.deepEqual(combatFlowTargets({...sword,expertReason:'spacing-wait-for-shield-release',
  labels:{4:0,5:0},publicRequest:{...shield.publicRequest,seen:{...shield.publicRequest.seen,z:3.2}}}),[],
 'a distant raised shield must not acquire a forced axe attack target')
 tf.tidy(()=>{
  assert.equal(combatFlowPurposeLoss([{frame:{labels:{}}}],heads,1),null)
  assert.equal(combatFlowPurposeLoss(rows,heads,0),null)
 })
}finally{heads.forEach(h=>h.dispose())}
console.log('COMBAT_FLOW_LOSS_PASS: useful sword contact, next jump, retained weapon, no weak clicks, deep shield continuation')
const heldJump={...sword,expertReason:'close-sword-critical-continuation',
 publicRequest:{...sword.publicRequest,jumpInputVersion:2,self:{...sword.publicRequest.self,ground:false}},
 labels:{0:1,1:1,2:1,4:0,5:1,6:6}}
assert(combatFlowTargets(heldJump).some(t=>t.kind==='held-jump-sword-continuation'&&t.heads[2]===1))
assert(!combatFlowTargets({...heldJump,publicRequest:{...heldJump.publicRequest,jumpInputVersion:1}})
 .some(t=>t.kind==='held-jump-sword-continuation'),'legacy airborne release semantics cannot be called held jump')
