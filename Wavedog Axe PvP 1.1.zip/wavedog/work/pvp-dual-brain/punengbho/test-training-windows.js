import assert from 'node:assert/strict'
import { selectTrainingWindows } from './training-windows.js'

const frames = Array.from({ length: 320 }, () => ({ reward: 0 }))
frames[39].reward = -.03 // empty swing
frames[121].reward = .4 // actual hit
frames[199].reward = -.025 // food loss / fast swing
frames[281].reward = .6 // critical hit
const windows = selectTrainingWindows(frames)
assert(windows.length > 4 && windows.length <= 12)
for (const index of [39, 121, 199, 281])
  assert(windows.some(window => window.start <= index && index < window.end),
    `feedback at frame ${index} must be trained`)
assert(windows.every((window, index) => index === 0
  || windows[index - 1].end <= window.start), 'windows may not overlap')
assert.deepEqual(selectTrainingWindows(frames.slice(0, 5)),
  [{ start: 0, end: 5 }])
assert.deepEqual(selectTrainingWindows([]), [])
console.log('TRAINING_WINDOWS_PASS')
