// Offline, sparse expert corrections on exact causal model inputs. No actor
// imports this file. Whole bouts stay ordered and existing holdouts stay fixed.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import zlib from 'node:zlib'
import {createRequire} from 'node:module'
import {validateDataset} from '../human-imitation.js'
const require=createRequire(import.meta.url)
const {criticalExpert,observeLearnerInput,sourceSha256:baseExpertSha}=require('./joint-melee-expert.cjs')
const expertSourceSha256=crypto.createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).update(baseExpertSha).digest('hex')
const {eyeReach}=require('../../pvp-player-client/probe-edge-controller')
const [prior,destination,...reports]=process.argv.slice(2)
if(!prior||!destination||!reports.length||fs.existsSync(destination))throw Error('New output and input reports required')
const data=JSON.parse(fs.readFileSync(prior)),root=path.resolve('work/wavedog-punengbho')
const oldSplits=new Map(data.trajectories.map(t=>[t.source,t.split])),audit=[]
for(const file of reports){
 const report=JSON.parse(fs.readFileSync(file))
 for(const trial of report.trials){
  const rawBytes=fs.readFileSync(trial.frameFile),raw=rawBytes.toString().trim().split('\n').map(JSON.parse)
  const byTick=new Map(raw.map(f=>[f.tick,f])),history={},adviceByTick=new Map()
  for(const f of raw){
   const request={tick:f.tick,self:f.self,seen:f.seen,publicTerrain:f.publicTerrain,publicActionContext:f.observation}
   adviceByTick.set(f.tick,criticalExpert(request,history))
   observeLearnerInput(history,request,{...f.executed,attackPacket:f.attackPacket,held:f.attackHeld??f.self.held})
  }
  const trace=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(root,'model/evaluations',trial.matchId+'.json.gz'))))
  const frames=[];let corrected=0,chargedAxe=0
  for(const actual of trace.episode){
   const f=byTick.get(actual.decidedTick);if(!f)throw Error('Missing exact causal frame')
   const {self:s,seen:t,observation:o}=f,advice=adviceByTick.get(f.tick)
   const request={tick:f.tick,self:s,seen:t,publicTerrain:f.publicTerrain,publicActionContext:o}
   const target={position:t,width:.6,height:1.8},legal=t.visible&&o.sentPosition
     &&eyeReach(s,s.eyeY-s.y,target)<=3&&eyeReach(o.sentPosition,s.eyeY-s.y,target)<=3
   const enabled=f.mode==='NEURAL'&&f.owners.attack==='neural'&&!o.shieldReady
     &&!o.arrowThreat&&!f.command.ranged&&t.visible
   // Preserve the existing movement/aim labels rather than fabricating a
   // new live chase. Only timing/weapon/jump outputs are taught here.
   const labels=enabled?Object.fromEntries(Object.entries(advice?.labels||{}).filter(([h])=>[1,2,4,5].includes(Number(h)))):{}
   const actions=[...(enabled&&advice?.actions?advice.actions:actual.actions)]
   let reason=advice?.reason||'no-expert-label'
   // Cash a ready axe contact before switching. Do not label an airborne
   // rising wait or imminent descending trade as a mandatory ground strike.
   if(enabled&&legal&&s.held===7&&s.ground&&s.charge>=.9&&s.attackAgeTicks>=4
      &&!t.shieldRaised&&!t.shield&&!o.targetCriticalThreat&&!o.targetAirborneThreat){
    labels[4]=2;labels[5]=0;labels[2]=0;labels[1]=1;reason='ready-axe-contact-before-close-sword';chargedAxe++
   }
   for(const[h,v]of Object.entries(labels)){
    if(actual.legalMasks[h][v]===false)delete labels[h]
    else actions[h]=v
   }
   if(Object.keys(labels).length)corrected++
   frames.push({tick:actual.decidedTick,observation:actual.observation,context:actual.context,
    publicHealthFeatures:actual.publicHealthFeatures,publicSpatialFeatures:actual.publicSpatialFeatures,
    publicThreatFeatures:actual.publicThreatFeatures,legalMasks:actual.legalMasks,labels,actions,
    publicRequest:request,actualLearnerActions:actual.actions,expertReason:reason,
    supervisionWeight:Object.keys(labels).length?3:1,labelEvidence:['offline-expert-on-actual-learner-state'],
    supervisionTargetTick:f.tick,labelDelayTicks:0,futureStateInObservation:false,ppoEligible:false})
  }
  // Entire bow bouts are held out, including the reported 11-tick idle. The
  // correction must generalize from other weapons/opponents, not memorize it.
  const split=trial.opponentMode==='bow'?'validation':'train'
  data.trajectories.push({source:trial.matchId+'-hybrid-dagger',sourceKind:'dagger-expert-relabel',
   sourceSha256:crypto.createHash('sha256').update(rawBytes).digest('hex'),matchId:trial.matchId,
   fighter:'Punengbho',opponent:'WaveDogSon',split,lesson:'hybrid-shieldless-contact',
   observationsFromLearner:true,expertSourceSha256,frames})
  audit.push({matchId:trial.matchId,mode:trial.opponentMode,split,frames:frames.length,corrected,chargedAxe})
 }
}
for(const t of data.trajectories)if(oldSplits.has(t.source)&&oldSplits.get(t.source)!==t.split)throw Error('Old split changed')
const counts=validateDataset(data)
fs.mkdirSync(destination,{recursive:true})
fs.writeFileSync(path.join(destination,'dataset.json'),JSON.stringify(data))
fs.writeFileSync(path.join(destination,'audit.json'),JSON.stringify({audit,counts,
 labelerSha256:crypto.createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).digest('hex'),
 entireOldDatasetPreserved:true,fullOrderedBouts:true,labelsAreCounterfactualNotExecuted:true,
 noFutureInputs:true,ppoEligible:false,reportedIdleBoutHeldOut:true},null,2))
console.log(JSON.stringify({audit,counts}))
