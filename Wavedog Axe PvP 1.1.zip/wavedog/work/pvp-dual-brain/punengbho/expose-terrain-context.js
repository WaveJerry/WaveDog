// Expose already-recorded public terrain to the learned instantaneous residual.
// Newly unmasked input rows are zeroed so every pre-training decision is preserved.
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE} from '../fresh-policy.js'
import {SharedAdam,loadDualCheckpoint,saveDualCheckpoint} from '../fresh-optimizer-checkpoint.js'
import {advance,disposeState,validateDataset} from '../human-imitation.js'
import {captureAutonomousImitation} from './autonomous-imitation.js'
const arg=k=>{const i=process.argv.indexOf(k);assert(i>=0,k+' required');return path.resolve(process.argv[i+1])}
const source=arg('--source'),reference=arg('--reference'),datasetFile=arg('--dataset'),dest=arg('--out')
assert(!fs.existsSync(dest),'Preserve previous experiment')
const parent=JSON.parse(fs.readFileSync(path.join(path.dirname(source),'receipt.json')))
const data=JSON.parse(fs.readFileSync(datasetFile));validateDataset(data)
await tf.setBackend('cpu');await tf.ready()
const loaded=loadDualCheckpoint(source),referenceSha=JSON.parse(fs.readFileSync(reference)).sha256
assert.equal(loaded.manifest.sha256,referenceSha,'Extend the current live weights only')
const oldFeatures=loaded.model.config.actionContextFeatures
assert(Array.isArray(oldFeatures)&&oldFeatures.length)
const featureOption=process.argv.indexOf('--features')
const requested=featureOption<0?[16,56,57,58,59]:process.argv[featureOption+1].split(',').map(Number)
assert(requested.length&&requested.every(i=>[14,15,16,56,57,58,59].includes(i)),
  'Only existing public self orientation and terrain channels may be exposed')
const added=[...new Set(requested)].filter(i=>!oldFeatures.includes(i))
assert(added.length,'Requested public context is already exposed')
const model=new DualPolicy({...loaded.model.config,actionContextFeatures:[...oldFeatures,...added].sort((a,b)=>a-b)},loaded.model.gateMode)
const adam=new SharedAdam(model.params,loaded.manifest.optimizer);adam.steps=loaded.adam.steps
let checked=0,maxDelta=0
try{
  assert.equal(model.params.length,loaded.model.params.length)
  for(const[i,p]of model.params.entries()){
    assert.equal(p.name.split('.').slice(1).join('.'),loaded.model.params[i].name.split('.').slice(1).join('.'))
    p.assign(loaded.model.params[i])
    for(const group of ['first','second']){adam[group][i].dispose();adam[group][i]=loaded.adam[group][i].clone()}
  }
  tf.tidy(()=>{
    const mask=tf.tensor2d(Array.from({length:OBS_SIZE},(_,i)=>[added.includes(i)?0:1]))
    model.actionContextIn.w.assign(tf.mul(model.actionContextIn.w,mask))
  })
  for(const trace of data.trajectories.filter(t=>t.split==='validation').slice(0,4)){
    let a=loaded.model.initialState(),b=model.initialState()
    try{for(const f of trace.frames.slice(0,32)){
      const left=advance(loaded.model,a,f.observation,true,f.legalMasks,f.publicHealthFeatures);a=left.state
      const right=advance(model,b,f.observation,true,f.legalMasks,f.publicHealthFeatures);b=right.state
      const x=captureAutonomousImitation(loaded.model,left,f),y=captureAutonomousImitation(model,right,f)
      assert.deepEqual(x.actions,y.actions)
      for(let h=0;h<x.logits.length;h++)for(let j=0;j<x.logits[h].length;j++)
        maxDelta=Math.max(maxDelta,Math.abs(x.logits[h][j]-y.logits[h][j]))
      checked++
    }}finally{disposeState(a);disposeState(b)}
  }
  assert(maxDelta<=1e-6)
  fs.mkdirSync(dest,{recursive:true})
  const saved=saveDualCheckpoint(path.join(dest,'checkpoint.json'),model,adam,loaded.counters)
  const receipt={schema:'public-terrain-context-extension-v1',source,sourceSha256:loaded.manifest.sha256,
    referenceCheckpoint:reference,referenceSha256:referenceSha,dataset:datasetFile,
    imitationStepsSinceReference:0,trainedBackbonesInAncestor:parent.allBackbonesTrained===true,
    addedFeatures:added,changedPreviouslyMaskedRowsOnly:true,existingActiveWeightsPreserved:true,
    checkedFrames:checked,maxOutputDelta:maxDelta,functionPreserved:true,ppoOptimizerPreserved:true,
    noOnlineCombatRuleAdded:true,requiresSupervisedTrainingAndLiveAcceptance:true,saved}
  fs.writeFileSync(path.join(dest,'receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt))
}finally{adam.dispose();model.dispose();loaded.adam.dispose();loaded.model.dispose()}
