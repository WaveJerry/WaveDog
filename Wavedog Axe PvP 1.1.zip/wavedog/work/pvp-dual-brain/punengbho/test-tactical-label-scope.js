import assert from 'node:assert/strict'
import {scopeLegacyTacticalLabels}from './tactical-label-scope.js'
const frame={labels:{0:1,1:1,2:1,4:2,5:1},actions:[1,1,1,0,2,1,6,3,0],
  publicRequest:{self:{x:0,z:0},seen:{visible:true,x:0,z:2.5,shield:true}}}
const before=JSON.stringify(frame),next=scopeLegacyTacticalLabels(frame,{})
assert.equal(JSON.stringify(frame),before,'raw exact demonstration remains untouched')
assert.equal(next.labels[5],undefined)
assert.equal(next.labels[4],undefined)
assert.deepEqual(next.actions,frame.actions,'omitting a target cannot invent a different teacher parent action')
assert.deepEqual(scopeLegacyTacticalLabels(frame,{tacticalCurriculumVersion:3}).labels,frame.labels)
const close={...frame,publicRequest:{...frame.publicRequest,seen:{...frame.publicRequest.seen,z:1.5,shield:false}}}
const scoped=scopeLegacyTacticalLabels(close,{mode:'edge-control'})
assert.equal(scoped.labels[5],undefined)
assert.equal(scoped.labels[4],undefined)
assert.deepEqual(scoped.actions,frame.actions)
const distantCritical=scopeLegacyTacticalLabels({...frame,publicRequest:{...frame.publicRequest,
  seen:{...frame.publicRequest.seen,shield:false}}},{mode:'critical'})
assert.equal(distantCritical.labels[0],undefined)
assert.equal(distantCritical.labels[1],undefined)
assert.deepEqual(distantCritical.actions,frame.actions)
assert.equal(scoped.labels[0],undefined)
console.log('TACTICAL_SCOPE_PRESERVES_FACTUAL_ACTIONS_PASS')
