import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, DEFAULT_CONFIG, DualPolicy, GATE_TARGET,
  OBS_SIZE, actionLogProbability, maskActionLogits, curriculumLogitBias, computeGAE,
  ppoUpdate } from './dual-policy.js'

await tf.setBackend('cpu')
await tf.ready()
const tiny = new DualPolicy({ fast: 16, slow: 64, heads: 4,
  layers: 2, ff: 128, interval: 4, memory: 16 })
let state = tiny.initialState()
const raw = []
for (let frame = 0; frame < 12; frame++) {
  const observation = Array.from({ length: OBS_SIZE }, (_, i) =>
    .2 * Math.sin(frame * .37 + i * .13))
  const output = tiny.step(tf.tensor2d([observation]), state)
  state = output.state
  const actions = ACTION_WIDTHS.map((width, head) => (frame + head) % width)
  const oldHeadLogProbs = output.logits.map((logits, head) =>
    tf.logSoftmax(logits, -1).dataSync()[actions[head]])
  raw.push({ observation, actions, oldHeadLogProbs,
    oldValue: output.value.dataSync()[0],
    reward: frame === 11 ? 1 : (frame % 3 - 1) * .05,
    done: frame === 11,
    executedHeads: ACTION_WIDTHS.map((_, head) => !(frame === 5 && head === 4)) })
}
assert.equal(state.frames, 12)
assert(state.caches.every(cache => cache && cache.key.shape[2] === 3))
assert(tiny.initialState().caches.every(cache => cache === null))

// A clone carries only its own temporary hidden state and tactical cache.
const obsA = tf.tensor2d([Array.from({ length: OBS_SIZE }, (_, i) => Math.sin(i * .02))])
const obsB = tf.tensor2d([Array.from({ length: OBS_SIZE }, (_, i) => Math.cos(i * .03))])
const firstA = tiny.step(obsA, tiny.initialState())
const firstB = tiny.step(obsB, tiny.initialState())
const secondA = tiny.step(obsA, firstA.state)
const uninterruptedA = tiny.step(obsA,
  tiny.step(obsA, tiny.initialState()).state)
assert.deepEqual([...secondA.state.fast.dataSync()],
  [...uninterruptedA.state.fast.dataSync()])
assert.deepEqual([...firstA.state.caches[0].key.dataSync()].slice(0, 16),
  [...tiny.step(obsA, tiny.initialState()).state.caches[0].key.dataSync()].slice(0, 16))
assert.notDeepEqual([...firstA.state.fast.dataSync()],
  [...firstB.state.fast.dataSync()])
assert.equal(tiny.initialState().frames, 0)
const entry = Array(OBS_SIZE).fill(0)
entry[31] = 1; entry[73] = 1; entry[97] = .8; entry[1] = 1
const prior = curriculumLogitBias(entry)
assert(prior[0][1] > prior[0][2], 'unarmed distant attacker explores approach')
assert(prior[4][1] < 0, 'distant no-ammo bot reduces passive shielding')
entry[97] = -.1
assert(curriculumLogitBias(entry)[4][2] > 0,
  'charged legal-edge attacker explores real melee packets')
entry[0] = 1; entry[1] = .25
assert(curriculumLogitBias(entry)[4][2] < 0,
  'ordinary low-charge click spam is less likely')
entry[1] = 1; entry[23] = 0; entry[97] = -.8
assert(curriculumLogitBias(entry)[4][2] > 25,
  'full-charge legal-range fighter gets a prompt attack opportunity')

const fastName = tiny.fast.params[0].name
const slowName = tiny.slowBlocks[0].query.w.name
const gateName = tiny.gateIn.w.name
const optimizer = tf.train.adam(1e-4)
const updated = ppoUpdate(tiny, optimizer, computeGAE([raw]))
assert(Number.isFinite(updated.loss))
assert(updated.gradients[fastName] > 0, 'fast GRU must receive PPO gradient')
assert(updated.gradients[slowName] > 0, 'slow Transformer must receive PPO gradient')
assert(updated.gradients[gateName] > 0, 'learned gate must receive PPO gradient')

const fixed = new DualPolicy({ fast: 16, slow: 64, heads: 4,
  layers: 2, ff: 128, interval: 4, memory: 16 }, 'fixed')
const fixedOutput = fixed.step(tf.zeros([1, OBS_SIZE]), fixed.initialState())
Array.from(fixedOutput.gate.dataSync()).forEach((value, index) =>
  assert(Math.abs(value - GATE_TARGET[index]) < 1e-6))

const legalMasks = ACTION_WIDTHS.map(width => Array(width).fill(true))
legalMasks[2][1] = false
legalMasks[4][3] = false
const masked = maskActionLogits(fixedOutput.logits, legalMasks)
assert.equal(tf.softmax(masked[2]).dataSync()[1], 0)
assert.equal(tf.softmax(masked[4]).dataSync()[3], 0)
const legalActions = ACTION_WIDTHS.map(() => 0)
assert(Number.isFinite(actionLogProbability(fixedOutput.logits,
  legalActions, null, legalMasks).dataSync()[0]))
const illegalActions = [...legalActions]; illegalActions[2] = 1
assert.throws(() => actionLogProbability(fixedOutput.logits,
  illegalActions, null, legalMasks), /illegal executed action/)
assert.throws(() => maskActionLogits(fixedOutput.logits,
  legalMasks.map(() => [])), /invalid legal mask/)

const full = new DualPolicy()
const parameterCount = full.parameterCount()
assert.equal(full.config.layers, DEFAULT_CONFIG.layers)
assert.equal(full.config.slow, 256)
assert(parameterCount > 3_000_000 && parameterCount < 4_000_000, parameterCount)
const start = performance.now()
const fullOutput = full.step(tf.zeros([1, OBS_SIZE]), full.initialState())
fullOutput.value.dataSync()
const firstStepMs = +(performance.now() - start).toFixed(1)
assert.equal(fullOutput.logits.length, 9)
assert.equal(fullOutput.state.caches.length, 4)
console.log(JSON.stringify({ result: 'DUAL_POLICY_PASS',
  fullParameters: parameterCount, firstStepMs,
  fastGradient: updated.gradients[fastName],
  slowGradient: updated.gradients[slowName],
  gateGradient: updated.gradients[gateName] }))

tiny.dispose(); fixed.dispose(); full.dispose()
