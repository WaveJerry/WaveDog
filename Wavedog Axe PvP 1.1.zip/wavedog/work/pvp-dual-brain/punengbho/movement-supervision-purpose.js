// Offline supervision and audits only. This never chooses an actor action.
export const movementForward=[0,1,-1,0,0,1,1,-1,-1]
export const movementSide=[0,0,0,-1,1,-1,1,-1,1]
export const viewTurns=[-180,-90,-45,-15,-5,-1,0,1,5,15,45,90,180]
export function radialMovement(a){
  if(!a)return 0
  const angle=viewTurns[a[6]]*Math.PI/180
  return movementForward[a[0]]*Math.cos(angle)-movementSide[a[0]]*Math.sin(angle)
}
export function supervisedWithdrawal(frame){
  const r=frame.publicRequest,s=r?.self,o=r?.publicActionContext
  if(s?.ground!==true||frame.labels?.[4]!==0||radialMovement(frame.actions)>=-.25)return false
  const forecast=Boolean(o?.targetCriticalThreat&&o.targetAirborne)
  const recovery=frame.expertReason==='axe-spacing-committed-recovery'
    &&s.held===7&&s.charge<.98&&frame.labels[5]===0
    &&!r.seen?.shield&&!r.seen?.shieldRaised
  return forecast||recovery
}
