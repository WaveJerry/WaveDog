import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawn } from 'node:child_process'
import readline from 'node:readline'
import { fileURLToPath } from 'node:url'
import { loadDualCheckpoint } from './optimizer-checkpoint.js'

const here = path.dirname(fileURLToPath(import.meta.url))
const source = path.join(here, 'models/seed-last-gru')
const sourceManifest = JSON.parse(fs.readFileSync(path.join(source, 'checkpoint.json'), 'utf8'))
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'wavedog-dual-bridge-'))
const checkpoint = path.join(temporary, 'checkpoint.json')
fs.copyFileSync(path.join(source, 'checkpoint.json'), checkpoint)
fs.copyFileSync(path.join(source, sourceManifest.binary),
  path.join(temporary, sourceManifest.binary))
const bridge = spawn(process.execPath, [path.join(here, 'dual-bridge.js'), checkpoint],
  { cwd: here, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
let stderr = '', nextWaiter = null
const messages = []
bridge.stderr.on('data', chunk => { stderr += chunk.toString('utf8') })
readline.createInterface({ input: bridge.stdout }).on('line', line => {
  const row = JSON.parse(line)
  if (nextWaiter && nextWaiter.predicate(row)) {
    const waiter = nextWaiter; nextWaiter = null; waiter.resolve(row)
  } else messages.push(row)
})
function send (value) { bridge.stdin.write(JSON.stringify(value) + '\n') }
function waitFor (predicate, timeoutMs = 30000) {
  const existing = messages.findIndex(predicate)
  if (existing >= 0) return Promise.resolve(messages.splice(existing, 1)[0])
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      nextWaiter = null
      reject(Error(`Bridge timeout; stderr=${stderr.slice(-1000)}; messages=${JSON.stringify(messages.slice(-3))}`))
    }, timeoutMs)
    nextWaiter = { predicate, resolve: value => { clearTimeout(timer); resolve(value) } }
  })
}
try {
  const ready = await waitFor(row => row.event === 'ready')
  assert.equal(ready.model, 'DUAL-GRU-GTRXL')
  const historyPath = path.join(here, 'models/history-44kk/recurrent-ppo.json')
  const frozenBefore = fs.readFileSync(historyPath)
  send({ command: 'reset', fighter: 'NBot02', opponent: 'NBot01',
    learning: false, role: 'history-44kk' })
  send({ command: 'act', fighter: 'NBot02', opponent: 'NBot01',
    requestId: 100, tick: 1, focus: 'FREE', style: 'AGGRESSIVE',
    yaw: 180, pitch: 0, self: { x: 1058.5, y: 221, z: 963,
      eyeY: 222.62, ground: true, charge: 1, health: 20,
      shieldAvailable: true, arrows: 0, held: 7 },
    seen: { visible: true, x: 1058.5, y: 221, z: 960.5,
      yaw: 0, shield: false, held: 'DIAMOND_AXE', arrows: [] } })
  const historical = await waitFor(row => row.requestId === 100)
  assert.equal(historical.model, 'GRU64-PPO')
  assert.equal(historical.leagueRole, 'history-44kk')
  send({ command: 'finish', fighter: 'NBot02', round: 1, win: false })
  const frozen = await waitFor(row => row.event === 'history_finished')
  assert.equal(frozen.frozen, true)
  assert.deepEqual(fs.readFileSync(historyPath), frozenBefore)
  send({ command: 'reset', fighter: 'NBot01', opponent: 'NBot02', learning: true })
  for (let tick = 1; tick <= 8; tick++) {
    const requestId = tick
    send({ command: 'act', fighter: 'NBot01', opponent: 'NBot02',
      requestId, tick, focus: 'FREE', style: 'AGGRESSIVE',
      yaw: 0, pitch: 0, observedOpponentSwingAge: -1,
      self: { x: 1058.5, y: 221, z: 960.5, eyeY: 222.62,
        vx: 0, vy: 0, vz: 0, ground: true, critical: false,
        charge: 1, health: 20, shieldAvailable: true, shielding: false,
        arrows: 5, crossbowLoaded: false, using: false,
        useTicks: 0, held: 7 },
      seen: { visible: true, x: 1058.5, y: 221, z: 963,
        yaw: 180, shield: false, held: 'DIAMOND_AXE',
        using: false, swing: 0, arrows: [] } })
    const reply = await waitFor(row => row.requestId === requestId)
    assert.equal(reply.model, 'DUAL-GRU-GTRXL')
    assert.equal(reply.opponent, 'NBot02')
    send({ command: 'executed', fighter: 'NBot01', decidedTick: tick,
      ignoredHeads: [6, 7] })
  }
  send({ command: 'native_step', fighter: 'NBot01', decidedTick: 4, reward: .1 })
  send({ command: 'finish', fighter: 'NBot01', round: 1,
    win: true, health: 12 })
  const trained = await waitFor(row => row.event === 'trained', 60000)
  assert(trained.gradient_updates_after > 0)
  assert.equal(trained.rollout_frames, 8)
  assert.equal(trained.trained_frames, 8)
  const loaded = loadDualCheckpoint(checkpoint)
  assert(loaded.counters.dualUpdates > 0)
  loaded.adam.dispose(); loaded.model.dispose()
  console.log(JSON.stringify({ result: 'DUAL_BRIDGE_LIVE_PASS',
    rolloutFrames: trained.rollout_frames,
    trainedFrames: trained.trained_frames,
    dualUpdates: trained.gradient_updates_after,
    durationMs: trained.durationMs }))
} finally {
  send({ command: 'close' })
  bridge.stdin.end()
  await new Promise(resolve => { bridge.once('exit', resolve); setTimeout(resolve, 3000) })
  if (bridge.exitCode === null) bridge.kill()
  fs.rmSync(temporary, { recursive: true, force: true })
}
