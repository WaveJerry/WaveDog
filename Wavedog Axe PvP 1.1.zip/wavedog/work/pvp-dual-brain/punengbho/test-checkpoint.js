import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './dual-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './optimizer-checkpoint.js'
import { ACTION_WIDTHS, OBS_SIZE, computeGAE,
  ppoUpdate } from './dual-policy.js'

await tf.setBackend('cpu')
await tf.ready()

const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'wavedog-dual-checkpoint-'))
const manifestPath = path.join(folder, 'checkpoint.json')
const config = { fast: 8, slow: 32, heads: 4, layers: 1, ff: 64,
  interval: 2, memory: 4 }
const original = new DualPolicy(config)
const firstAdam = new SharedAdam(original.params)

function update (model, optimizer, scale) {
  const gradients = Object.fromEntries(model.params.map((variable, index) =>
    [variable.name, tf.fill(variable.shape, scale * (index + 1) / model.params.length)]))
  optimizer.applyGradients(gradients)
  Object.values(gradients).forEach(tensor => tensor.dispose())
}
function compareTensors (left, right, label) {
  assert.equal(left.length, right.length, `${label} length`)
  for (let index = 0; index < left.length; index++) {
    assert.deepEqual(left[index].shape, right[index].shape, `${label} shape ${index}`)
    assert.deepEqual([...left[index].dataSync()], [...right[index].dataSync()],
      `${label} values ${index}`)
  }
}

try {
  update(original, firstAdam, .01)
  update(original, firstAdam, .02)
  const observation = Array(OBS_SIZE).fill(0)
  const actions = ACTION_WIDTHS.map(() => 0)
  const output = original.step(tf.tensor2d([observation]), original.initialState())
  const oldHeadLogProbs = output.logits.map(head => tf.logSoftmax(head).dataSync()[0])
  ppoUpdate(original, firstAdam, computeGAE([[{ observation, actions,
    oldHeadLogProbs, oldValue: output.value.dataSync()[0],
    reward: 1, done: true, executedHeads: ACTION_WIDTHS.map(() => true) }]]))
  saveDualCheckpoint(manifestPath, original, firstAdam,
    { episodes: 2, updates: 2, validNativeBouts: 2 })
  const loaded = loadDualCheckpoint(manifestPath)
  try {
  assert.equal(loaded.adam.steps, 3)
    assert.deepEqual(loaded.counters, { episodes: 2, updates: 2, validNativeBouts: 2 })
    compareTensors(original.params, loaded.model.params, 'weights')
    compareTensors(firstAdam.first, loaded.adam.first, 'first moments')
    compareTensors(firstAdam.second, loaded.adam.second, 'second moments')
    update(original, firstAdam, .03)
    update(loaded.model, loaded.adam, .03)
    compareTensors(original.params, loaded.model.params, 'continued weights')
    compareTensors(firstAdam.first, loaded.adam.first, 'continued first moments')
    compareTensors(firstAdam.second, loaded.adam.second, 'continued second moments')
  } finally {
    loaded.adam.dispose()
    loaded.model.dispose()
  }

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  const badLayout = structuredClone(manifest)
  badLayout.layout[1].offset += 4
  fs.writeFileSync(manifestPath, JSON.stringify(badLayout))
  assert.throws(() => loadDualCheckpoint(manifestPath), /layout mismatch/)
  const badPath = { ...manifest, binary: '../outside.bin' }
  fs.writeFileSync(manifestPath, JSON.stringify(badPath))
  assert.throws(() => loadDualCheckpoint(manifestPath), /binary name invalid/)
  fs.writeFileSync(manifestPath, JSON.stringify(manifest))
  const payloadPath = path.join(folder, manifest.binary)
  const payload = fs.readFileSync(payloadPath)
  payload[0] ^= 1
  fs.writeFileSync(payloadPath, payload)
  assert.throws(() => loadDualCheckpoint(manifestPath), /hash mismatch/)
  console.log('DUAL_CHECKPOINT_PASS')
} finally {
  firstAdam.dispose()
  original.dispose()
  fs.rmSync(folder, { recursive: true, force: true })
}
