// One learner, immutable serving generations. A bout's memory never crosses
// a weight replacement, and both perspectives acquire the same generation.
export class PolicySnapshots {
  constructor (snapshot) {
    this.current = snapshot
    this.references = new Map([[snapshot, 0]])
    this.matches = new Map()
  }
  acquire (matchId) {
    if (!matchId) throw Error('A policy lease needs a match ID')
    const match = this.matches.get(matchId) || { snapshot: this.current, users: 0 }
    match.users++
    this.matches.set(matchId, match)
    this.references.set(match.snapshot, (this.references.get(match.snapshot) || 0) + 1)
    return match.snapshot
  }
  release (matchId) {
    const match = this.matches.get(matchId)
    if (!match || match.users <= 0) throw Error('Missing policy lease')
    match.users--
    const count = this.references.get(match.snapshot) - 1
    this.references.set(match.snapshot, count)
    if (!match.users) this.matches.delete(matchId)
    this.collect(match.snapshot)
  }
  publish (snapshot) {
    const previous = this.current
    this.current = snapshot
    this.references.set(snapshot, this.references.get(snapshot) || 0)
    this.collect(previous)
  }
  collect (snapshot) {
    if (snapshot !== this.current && this.references.get(snapshot) === 0) {
      snapshot.model.dispose()
      this.references.delete(snapshot)
    }
  }
}
