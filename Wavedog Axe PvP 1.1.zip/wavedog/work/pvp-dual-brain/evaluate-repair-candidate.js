import fs from 'node:fs'
import zlib from 'node:zlib'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'
import { advance, disposeState } from './human-imitation.js'

const [source, candidate, destination, ...files] = process.argv.slice(2)
if (!files.length) throw Error('Need independent rollouts')
await tf.setBackend('cpu'); await tf.ready()
const left = loadDualCheckpoint(source), migrated = loadDualCheckpoint(source), right = loadDualCheckpoint(candidate)
migrated.model.config.distributionVersion = right.model.config.distributionVersion
migrated.model.config.calibratedHeads = right.model.config.calibratedHeads
for (const loaded of [left,migrated,right]) loaded.adam.dispose()
const report = { caveat: 'Sequential replay of recorded observations, not measured combat performance or recreation of retired behavior weights.',
  source: left.manifest.sha256, candidate: right.manifest.sha256, rollouts: [] }
try {
  for (const file of files) {
    const trace = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    const row = { file, fighter: trace.fighter, rolloutSeq: trace.rolloutSeq, variants: {} }
    for (const [name, loaded] of [['original',left],['calibrated-untrained',migrated],['expert-trained',right]]) {
      let state = loaded.model.initialState()
      const groups = {}
      try {
        for (const f of trace.episode) {
          const output = advance(loaded.model,state,f.observation,true,f.legalMasks); state = output.state
          const p = tf.tidy(() => maskActionLogits(biasedActionLogits(
            output.logits.map(v=>tf.tensor2d([v])),f.observation,
            {...f.context,distributionVersion:loaded.model.config.distributionVersion||1},f.actions),f.legalMasks)
            .map(h=>[...tf.softmax(h).dataSync()]))
          if (!f.executedHeads[4]) continue
          const x=f.observation
          const keys = ['executed']
          if (x[31]>.5 && x[97]<=0 && x[1]>=.85 && x[8]<.5 && x[23]<.5) keys.push('legalCharged')
          if (x[31]>.5 && x[97]>.12) keys.push('outOfReach')
          if (x[1]<.5) keys.push('lowCharge')
          for (const key of keys) {
            const item = groups[key] ||= { frames:0,attack:0,sword:0,sprint:0,jump:0,sneak:0 }
            item.frames++;item.attack+=p[4][2];item.sword+=p[5][1];item.sprint+=p[1][1];item.jump+=p[2][1];item.sneak+=p[3][1]
          }
        }
      } finally { disposeState(state) }
      for(const item of Object.values(groups))for(const key of ['attack','sword','sprint','jump','sneak'])item[key]/=item.frames
      row.variants[name]=groups
    }
    report.rollouts.push(row)
    console.log(JSON.stringify({rollout:trace.rolloutSeq,variants:row.variants}))
  }
  fs.mkdirSync(path.dirname(path.resolve(destination)),{recursive:true})
  fs.writeFileSync(destination,JSON.stringify(report,null,2))
} finally { for(const loaded of [left,migrated,right])loaded.model.dispose() }
