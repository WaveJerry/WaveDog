"""Join public human frames to durable policy actions; never assert counterfactual damage."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import gzip, json, math

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
source = MODEL / 'coach/bouts.jsonl'
with source.open('rb') as stream:
    end = stream.seek(0, 2)
    size = min(end, 16 * 1024 * 1024)
    stream.seek(end - size)
    lines = stream.read().splitlines()
    if size < end:
        lines = lines[1:]
bouts = [json.loads(line) for line in lines[-16:]]
wanted = {row['matchId'] for row in bouts}
actions = {}
for path in sorted((MODEL / 'rollouts').glob('rollout-*.json.gz'), reverse=True)[:220]:
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        rollout = json.load(stream)
    if rollout.get('fighter') == 'WaveDog' and rollout.get('round') in wanted:
        actions[rollout['round']] = {frame['decidedTick']: frame for frame in rollout['episode']}

def reach(frame):
    own, seen = frame['self'], frame['seen']
    eye = own.get('eyeY', own['y'] + 1.62)
    return math.sqrt(max(0, abs(seen['x'] - own['x']) - .3) ** 2
        + max(0, abs(seen['z'] - own['z']) - .3) ** 2
        + max(0, seen['y'] - eye, eye - seen['y'] - 1.8) ** 2)

report = {'at': datetime.now().astimezone().isoformat(),
    'limitation': 'Windows are public geometric attack candidates, not proof an alternative attack would damage, knock back or cancel a combo. Opponent hurt protection is not recorded here.',
    'bouts': []}
for bout in bouts:
    result = {key: bout.get(key) for key in ['matchId', 'receivedAt', 'fighter', 'opponent']}
    result.update(statusCounts=dict(Counter(frame.get('neuralStatus') for frame in bout['frames']
        if frame.get('owner') == 'dual')), candidateWindows=[], actualResults=[])
    by_tick = actions.get(bout['matchId'], {})
    for frame in bout['frames']:
        own, seen = frame['self'], frame['seen']
        distance = reach(frame)
        damage = frame.get('nativeDealt', 0), frame.get('nativeReceived', 0)
        if any(value > 0 for value in damage):
            result['actualResults'].append({'tick': frame['tick'], 'dealt': damage[0], 'received': damage[1],
                'reach': distance, 'charge': own['charge'], 'opponentY': seen['y']})
        if frame.get('owner') != 'dual' or not seen.get('visible') or seen.get('shield') \
                or own.get('using') or own.get('shielding') or distance > 3 or own['charge'] < .5 \
                or frame.get('attackPacket'):
            continue
        selected = by_tick.get(frame.get('actionSourceTick'))
        status = frame.get('neuralStatus')
        if status != 'fresh-action':
            category = 'inference-not-fresh'
        elif selected and selected['actions'][4] == 2:
            category = 'selected-attack-not-sent'
        elif selected:
            category = 'policy-chose-wait'
        else:
            category = 'policy-selection-not-joined'
        pending_selection = by_tick.get(frame['tick'])
        result['candidateWindows'].append({'tick': frame['tick'], 'reach': distance,
            'charge': own['charge'], 'held': own['held'], 'status': status, 'category': category,
            'sourceTick': frame.get('actionSourceTick'), 'ignoredHeads': frame.get('ignoredHeads'),
            'actions': selected.get('actions') if selected else None,
            'sameTickModelAttack': pending_selection['actions'][4] == 2 if pending_selection else None,
            'sameTickExecutedHeads': pending_selection.get('executedHeads') if pending_selection else None})
    report['bouts'].append(result)
directory = MODEL / 'coach/audits'
directory.mkdir(parents=True, exist_ok=True)
destination = directory / ('spacing-window-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.json')
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'audit': str(destination), 'bouts': len(report['bouts']),
    'categories': dict(Counter(window['category'] for bout in report['bouts'] for window in bout['candidateWindows'])),
    'fullChargeStaleExamples': [dict(matchId=bout['matchId'], **window)
        for bout in report['bouts'] for window in bout['candidateWindows']
        if window['charge'] >= .999 and window['category'] == 'inference-not-fresh'][:4]}, ensure_ascii=False))
