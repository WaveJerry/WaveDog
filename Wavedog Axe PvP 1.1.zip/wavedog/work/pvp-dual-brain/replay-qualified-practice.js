// Assimilate recorded practice into the latest production-based candidate.
// This is bounded-lag PPO replay, not new live combat or a weight average.
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import crypto from 'node:crypto'
import { Worker } from 'node:worker_threads'

const [source, destination, ...trials] = process.argv.slice(2)
if (!source || !destination || !trials.length || fs.existsSync(destination))
  throw Error('Need source manifest, NEW output directory and qualified trial directories')
fs.mkdirSync(destination, { recursive: true })
const checkpointPath = path.resolve(destination, 'checkpoint.json')
const original = JSON.parse(fs.readFileSync(source))
fs.copyFileSync(source, checkpointPath)
fs.copyFileSync(path.join(path.dirname(source), original.binary), path.join(destination, original.binary))
const worker = new Worker(new URL('./fresh-trainer-worker.js', import.meta.url), { workerData: { checkpointPath } })
let waiting = null, resolveReady, rejectReady
const ready = new Promise((resolve, reject) => { resolveReady = resolve; rejectReady = reject })
worker.on('message', message => {
  if (message.event === 'trainer_ready') resolveReady()
  else if (waiting) { const { resolve, reject } = waiting; waiting = null
    if (message.event === 'training_error') reject(Error(message.error)); else resolve(message) }
})
worker.on('error', error => { rejectReady(error); waiting?.reject(error) })
const receipts = [], seen = new Set()
try {
  await ready
  for (const trial of trials) {
    const result = JSON.parse(fs.readFileSync(path.join(trial, 'result.json')))
    if (!result.validLearningTrial || result.expiredFrameRatio > .05) throw Error('Unqualified trial: ' + trial)
    const folder = path.join(trial, 'rollouts')
    const files = fs.readdirSync(folder).filter(x => /^rollout-\d+\.json\.gz$/.test(x))
    if (files.length !== 1) throw Error('Ambiguous rollout: ' + trial)
    const bytes = fs.readFileSync(path.join(folder, files[0]))
    const digest = crypto.createHash('sha256').update(bytes).digest('hex')
    if (seen.has(digest)) throw Error('Duplicate practice rollout')
    seen.add(digest)
    const row = JSON.parse(zlib.gunzipSync(bytes))
    const validation = JSON.parse(fs.readFileSync(path.join(trial, `validation-${row.rolloutSeq}.json`)))
    if (!validation.accepted || row.episode.some(f => f.checkpointSha256 !== result.sourceSha256))
      throw Error('Unverified behavior policy')
    const current = JSON.parse(fs.readFileSync(checkpointPath))
    const sourceSequence = row.rolloutSeq
    row.rolloutSeq = current.counters.lastRolloutSeq + 1
    row.replayProvenance = { sourceTrial: path.resolve(trial), sourceSequence,
      sourceRolloutSha256: digest, sourceMatchId: result.matchId,
      mode: 'bounded-lag-replay', originalBehaviorAndExecutionUnchanged: true }
    const journal = path.join(destination, 'rollouts'); fs.mkdirSync(journal, { recursive: true })
    fs.writeFileSync(path.join(journal, `rollout-${String(row.rolloutSeq).padStart(12, '0')}.json.gz`),
      zlib.gzipSync(Buffer.from(JSON.stringify(row))))
    const response = await new Promise((resolve, reject) => {
      waiting = { resolve, reject }; worker.postMessage(row)
    })
    receipts.push({ ...row.replayProvenance, rolloutSeq: row.rolloutSeq, response })
    fs.writeFileSync(path.join(destination, 'practice-replay-receipt.json'), JSON.stringify({
      productionBaseSha256: original.counters.actionContextRebase.liveSha256,
      sourceCandidateSha256: original.sha256, notNewLiveCombat: true,
      usesExistingUnrelaxedPpoKlGates: true, receipts }, null, 2))
    console.log(JSON.stringify({ stage: 'practice-replayed', seq: row.rolloutSeq,
      accepted: response.candidateAccepted, sha256: response.sha256 }))
    if (!response.candidateAccepted || response.quarantined)
      throw Error('PPO replay rejected; do not install: ' + JSON.stringify(response.reasons))
  }
} finally { await worker.terminate() }
