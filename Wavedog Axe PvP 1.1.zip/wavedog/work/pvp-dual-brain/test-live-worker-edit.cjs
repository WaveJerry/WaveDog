const fs = require('node:fs')
const path = require('node:path')
const { spawn } = require('node:child_process')
const assert = require('node:assert/strict')
async function main () {
  const folder = path.join(__dirname, 'runtime/live-worker-test')
  fs.mkdirSync(folder, { recursive: true })
  const policy = path.join(folder, 'probe-policy.mjs')
  const backup = path.join(folder, 'probe-policy.before')
  const original = 'export function value() { return 1 }\n'
  fs.writeFileSync(policy, original); fs.writeFileSync(backup, original)
  const entry = path.join(folder, 'probe-main.mjs')
  fs.writeFileSync(entry, 'import { Worker, isMainThread } from "node:worker_threads";\nimport { value } from "./probe-policy.mjs";\nawait Promise.resolve();\nif (isMainThread) new Worker(new URL(import.meta.url));\nsetInterval(() => console.log((isMainThread ? "main:" : "worker:") + value()), 100);\n')
  const child = spawn(process.execPath, [entry], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
  let output = ''
  child.stdout.on('data', b => { output += b })
  try {
    await new Promise(resolve => setTimeout(resolve, 800))
    assert(output.includes('main:1') && output.includes('worker:1'))
    fs.writeFileSync(policy, original.replace('return 1', 'return 2'))
    const plan = path.join(folder, 'plan.json')
    fs.writeFileSync(plan, JSON.stringify({ pid: child.pid,
      files: [{ path: policy, before: backup, worker: true }, { path: policy, before: backup }],
      receipt: path.join(folder, 'receipt.json') }))
    const helper = spawn(process.execPath, [path.join(__dirname, 'live-edit.cjs'), plan],
      { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
    let errors = ''
    helper.stderr.on('data', b => { errors += b })
    const code = await new Promise(resolve => helper.on('exit', resolve))
    assert.equal(code, 0, errors)
    await new Promise(resolve => setTimeout(resolve, 300))
    assert(output.includes('main:2') && output.includes('worker:2'), output)
    console.log('LIVE_EDIT_WORKER_PASS: exact source hashes, both isolates updated, same running PID')
  } finally { child.kill() }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
