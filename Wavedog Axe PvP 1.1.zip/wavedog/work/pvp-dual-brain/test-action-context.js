import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { addActionContextInput, addAttackContextOutput } from './migrate-public-health.js'
import { advance, disposeState } from './human-imitation.js'
await tf.setBackend('cpu');await tf.ready()
const old=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:32,interval:2,memory:4})
const optimizer=new SharedAdam(old.params);optimizer.steps=17
const migrated=addActionContextInput({model:old,adam:optimizer,
  manifest:{optimizer:{},sha256:'test'},counters:{dualUpdates:17}})
try{
  let a=old.initialState(),b=migrated.model.initialState()
  try{
    for(let t=0;t<8;t++){
      const obs=Array.from({length:OBS_SIZE},(_,i)=>Math.sin(i+t)*.1)
      const left=advance(old,a,obs,true);a=left.state
      const right=advance(migrated.model,b,obs,true);b=right.state
      assert.deepEqual(right.logits,left.logits,'zero adapter must preserve the whole old sequence')
      assert.equal(right.value,left.value)
    }
  }finally{disposeState(a);disposeState(b)}
  assert.equal(migrated.adam.steps,17)
  const model=migrated.model
  const params=[model.actionContextIn,...model.actionContextOut].flatMap(layer=>layer.params)
  const teacher=new SharedAdam(params,{learningRate:.03})
  const before=old.params.map(p=>[...p.dataSync()])
  // A basic capacity test: exact current weapon is legally observed. Keep
  // sword and axe distinguishable without changing either recurrent trunk.
  const x=Array.from({length:2},(_,i)=>{const row=Array(OBS_SIZE).fill(0);row[12]=i*.875;return row})
  let first,last
  try{
    for(let step=0;step<80;step++)tf.tidy(()=>{
      const {value,grads}=tf.variableGrads(()=>{
        const out=model.step(tf.tensor2d(x),model.initialState(2))
        return tf.neg(tf.mean(tf.sum(tf.mul(tf.oneHot([1,0],5),tf.logSoftmax(out.logits[5])),1)))
      },params)
      if(step===0)first=value.dataSync()[0]
      last=value.dataSync()[0];teacher.applyGradients(grads)
    })
  }finally{teacher.dispose()}
  assert(last<first*.1,'context output must actually learn distinguishable legal states')
  for(let i=0;i<old.params.length;i++)assert.deepEqual([...model.params[i].dataSync()],before[i])
  const attack = addAttackContextOutput({ ...migrated,
    manifest: { optimizer: {}, sha256: 'context-test' } }, [1,2,4,7,8,12,19,23,31,97])
  try {
    assert.equal(attack.adam.steps, 17)
    for (let i = 0; i < model.params.length; i++) {
      assert.deepEqual([...attack.model.params[i].dataSync()], [...model.params[i].dataSync()])
      for (const key of ['first', 'second'])
        assert.deepEqual([...attack.adam[key][i].dataSync()], [...migrated.adam[key][i].dataSync()])
    }
    let leftState=model.initialState(),rightState=attack.model.initialState()
    try {
      for(let t=0;t<6;t++) {
        const obs=Array.from({length:OBS_SIZE},(_,i)=>Math.sin(i+t)*.1)
        const left=advance(model,leftState,obs,true);leftState=left.state
        const right=advance(attack.model,rightState,obs,true);rightState=right.state
        assert.deepEqual(right.logits,left.logits,'zero attack residual must preserve every old output')
      }
    } finally { disposeState(leftState);disposeState(rightState) }
    const recurrentBefore=attack.model.params.slice(0,old.params.length).map(p=>[...p.dataSync()])
    const params=[...attack.model.actionContextIn.params,...attack.model.actionContextOut[2].params]
    const timingOptimizer=new SharedAdam(params,{learningRate:.03})
    const timingInputs=[[.2,false,-.2],[1,false,.2],[1,false,-.2],[1,true,0]].map(([charge,ground,vy])=>{
      const row=Array(OBS_SIZE).fill(0);row[1]=charge;row[2]=ground?1:0;row[4]=vy;row[12]=0;return row
    })
    try {
      for(let step=0;step<100;step++)tf.tidy(()=>{
        const {grads}=tf.variableGrads(()=>{
          const out=attack.model.step(tf.tensor2d(timingInputs),attack.model.initialState(4))
          return tf.neg(tf.mean(tf.sum(tf.mul(tf.oneHot([0,0,2,2],5),tf.logSoftmax(out.logits[4])),1)))
        },params)
        timingOptimizer.applyGradients(grads)
      })
      const probabilities=tf.tidy(()=>tf.softmax(attack.model.step(tf.tensor2d(timingInputs),
        attack.model.initialState(4)).logits[4]).arraySync())
      assert(probabilities[0][2]<.1&&probabilities[1][2]<.1
        &&probabilities[2][2]>.9&&probabilities[3][2]>.9,
      'learned timing must distinguish charge and phase, including grounded attacks')
      for(let i=0;i<old.params.length;i++)
        assert.deepEqual([...attack.model.params[i].dataSync()],recurrentBefore[i])
    } finally { timingOptimizer.dispose() }
  } finally { attack.adam.dispose();attack.model.dispose() }
  console.log('ACTION_CONTEXT_PASS: exact zero migration, original weights unchanged, conditional learning verified')
  console.log('ATTACK_CONTEXT_PASS: exact append migration and native-feature timing capacity; no learned skill claim')
}finally{optimizer.dispose();old.dispose();migrated.adam.dispose();migrated.model.dispose()}
