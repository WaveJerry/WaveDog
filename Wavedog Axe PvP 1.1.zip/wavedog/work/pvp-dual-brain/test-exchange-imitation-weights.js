import assert from 'node:assert/strict'
import {attackSituation,exchangeAttackWeights}from './exchange-imitation-weights.js'
function frame(charge,range,attack){const x=Array(98).fill(0);x[31]=1;x[1]=charge;x[97]=range;x[2]=1
  return {observation:x,labels:{4:attack}}}
const frames=[...Array.from({length:180},()=>frame(1,-.3,0)),
  ...Array.from({length:20},()=>frame(1,-.3,2)),
  ...Array.from({length:995},()=>frame(.4,-.3,0)),
  ...Array.from({length:5},()=>frame(.4,-.3,2)),...Array.from({length:400},()=>frame(1,.5,0))]
const dataset={trajectories:[{split:'train',frames},
  {split:'validation',frames:Array.from({length:100},()=>frame(1,-.3,2))}]}
const a=exchangeAttackWeights(dataset)
assert.equal(a.groups.ready.total,200,'validation labels never influence training weights')
assert.equal(a.weights.ready[0]*180,a.weights.ready[2]*20,'charged legal first hits receive equal class mass')
assert.equal(a.weights.recovering[0],a.weights.recovering[2],'low-charge interruptions retain native frequency')
const descending=frame(1,-.3,0);descending.context={fallingMeleeThreat:true,ownFallingWindow:false}
assert.equal(attackSituation(descending),'falling-opponent','do not force a bad normal-hit/crit trade')
const rise=frame(1,-.3,0);rise.observation[2]=0;rise.observation[4]=.4
assert.equal(attackSituation(rise),'rising-self','waiting for a real critical remains distinct from passivity')
const opening=frame(1,-.05,2);opening.operatorGroundedEdgeOpening=true
assert.equal(attackSituation(opening),'grounded-edge-opening')
opening.context={fallingMeleeThreat:true,ownFallingWindow:false}
assert.equal(attackSituation(opening),'falling-opponent','imminent critical threat outranks ordinary grounded opener')
console.log('EXCHANGE_IMITATION_WEIGHTS_PASS')
