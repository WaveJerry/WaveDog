import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {DurableReviewQueue} from './durable-review-queue.js'
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-review-'))
try {
  const row={matchId:'recovered-bout',frames:[{tick:1},{tick:2}]}
  let release
  const old=new DurableReviewQueue(dir,()=>new Promise(r=>{release=r}))
  old.enqueue(row);old.enqueue(row)
  assert.equal(fs.readdirSync(dir).length,1,'persist before waiting on Qwen')
  await Promise.resolve()
  const seen=[]
  const fresh=new DurableReviewQueue(dir,async r=>{seen.push(r);return true})
  fresh.recover();await fresh.tail
  assert.deepEqual(seen,[row],'full ordered raw frames survive reload')
  fresh.enqueue(row);await fresh.tail
  assert.equal(seen.length,1,'completed jobs are not reviewed twice')
  // Simulate the old process terminating; its promise does not write state.
  assert.equal(typeof release,'function')
  const bad=new DurableReviewQueue(dir,async()=>false)
  bad.enqueue({matchId:'failed',frames:[{tick:3}]});await bad.tail
  const jobs=fs.readdirSync(dir).map(f=>JSON.parse(fs.readFileSync(path.join(dir,f))))
  assert(jobs.some(j=>j.state==='failed'&&j.row.frames[0].tick===3),'failure retains raw data')
  console.log('DURABLE_REVIEW_QUEUE_PASS')
} finally {
  // Only the explicitly created temporary directory is removed.
  fs.rmSync(dir,{recursive:true,force:true})
}
