import {ACTION_WIDTHS}from './fresh-policy.js'
// Shared by acting and imitation. Offhand/shield remain mechanical inputs.
export function hybridLegalMasks(req){
  const masks=ACTION_WIDTHS.map(width=>Array(width).fill(true))
  if(req.self?.ground===false)masks[2][1]=false
  for(const a of[1,3,4])masks[4][a]=false
  for(const a of[2,3,4])masks[5][a]=false
  return masks
}
