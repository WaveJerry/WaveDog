import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE, biasedActionLogits, DualPolicy, computeGAE } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { replayPolicyHealth, completeRolloutUpdate, releaseState } from './stable-ppo.js'
await tf.setBackend('cpu'); await tf.ready()
tf.tidy(() => {
  const x = Array(OBS_SIZE).fill(0); x[0] = 1; x[1] = 1; x[12] = .875; x[31] = 1; x[97] = -.7
  const context = { entryCurriculum: 10, distributionVersion: 3, calibratedHeads: [2, 5] }
  const logits = ACTION_WIDTHS.map(width => tf.zeros([1, width]))
  const keep = Array(9).fill(0), change = [...keep]; change[5] = 1
  const legacy = biasedActionLogits(logits, x, context, change)
  const held = biasedActionLogits(logits, x, { ...context, weaponConditionedAttack: 1 }, keep)
  const switched = biasedActionLogits(logits, x, { ...context, weaponConditionedAttack: 1 }, change)
  assert(legacy[4].dataSync()[2] > 20, 'legacy charged-hit distribution remains available')
  assert.deepEqual([...held[4].dataSync()], [...legacy[4].dataSync()], 'keeping weapon preserves charged hit')
  assert(switched[4].dataSync()[2] < 0, 'a fresh sword must not inherit the old axe charged-hit prior')
  for (const h of [0, 1, 2, 3, 5, 6, 7, 8])
    assert.deepEqual([...switched[h].dataSync()], [...legacy[h].dataSync()], 'only conditional attack may change')
  x[12] = 0; x[23] = 1
  const axe = biasedActionLogits(logits, x, { ...context, weaponConditionedAttack: 1 }, keep)
  assert(tf.softmax(axe[4]).dataSync()[2] > .1, 'low-charge switched axe strike remains a real legal choice')
})
console.log('CONDITIONAL_HAND_PASS: old policies preserved, charge follows selected stack, other controls unchanged, shield strike available')

// PPO must replay the actual conditional behavior probability, rather than
// credit the pre-weapon attack distribution. Exercise real recurrent replay
// and an optimizer update with changing weapons and a slow refresh boundary.
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:3,calibratedHeads:[2,5],weaponConditionedAttack:1})
const adam=new SharedAdam(model.params,{learningRate:.00003})
const rollout=[];let state=model.initialState()
for(let tick=0;tick<12;tick++){
  const observation=Array(OBS_SIZE).fill(0)
  observation[0]=1;observation[1]=1;observation[2]=1;observation[31]=1
  observation[12]=tick%2?0:.875;observation[97]=-.7
  const actions=ACTION_WIDTHS.map(()=>0);actions[5]=tick%3?1:0;actions[4]=tick%2?2:0
  const context={entryCurriculum:10,distributionVersion:3,calibratedHeads:[2,5],weaponConditionedAttack:1}
  const previous=state
  const output=tf.tidy(()=>{
    const result=model.step(tf.tensor2d([observation]),state)
    const heads=biasedActionLogits(result.logits,observation,context,actions)
    return {state:result.state,value:result.value.dataSync()[0],p:heads.map(h=>[...tf.softmax(h).dataSync()])}
  })
  state=output.state;releaseState(previous,state)
  rollout.push({observation,actions,context,oldHeadProbabilities:output.p,
    oldHeadLogProbs:output.p.map((p,h)=>Math.log(Math.max(1e-30,p[actions[h]]))),
    oldValue:output.value,reward:tick===11?1:0,done:tick===11,
    checkpointSha256:'same-conditional-policy',executedHeads:ACTION_WIDTHS.map(()=>true)})
}
releaseState(state)
assert(replayPolicyHealth(model,rollout).maxMeanHeadKL<1e-6,'online/replay conditional distributions must agree')
const learned=completeRolloutUpdate(model,adam,computeGAE([rollout])[0])
assert.equal(learned.trainedFrames,12)
assert(Number.isFinite(learned.loss)&&learned.gradientNorm>0)
adam.dispose();model.dispose()
console.log('CONDITIONAL_HAND_PPO_REPLAY_PASS')

// Learned attack timing must also follow the selected stack, even when the
// calibrated attack head no longer uses any legacy curriculum charge prior.
const conditionalModel=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4,
  distributionVersion:3,calibratedHeads:[2,4,5],weaponConditionedAttack:2,
  actionContextHeads:[2,5,4],publicHealthInputs:5,attackContextFeatures:[1,2,4,7,8,12,19,23,31,97]})
const conditionalAdam=new SharedAdam(conditionalModel.params,{learningRate:.00003})
try {
  tf.tidy(()=>{
    const weights=Array.from({length:OBS_SIZE},()=>Array(32).fill(0));weights[1][0]=2
    conditionalModel.actionContextIn.w.assign(tf.tensor2d(weights))
    conditionalModel.actionContextIn.b.assign(tf.zeros([32]))
    const attackWeights=Array.from({length:32},()=>Array(5).fill(0));attackWeights[0][2]=4
    conditionalModel.actionContextOut[2].w.assign(tf.tensor2d(attackWeights))
    const health=Array.from({length:5},()=>Array(OBS_SIZE).fill(0));health[0][1]=.1
    conditionalModel.publicHealthProjection.assign(tf.tensor2d(health))
  })
  const frames=[];let current=conditionalModel.initialState()
  for(let tick=0;tick<8;tick++) {
    const observation=Array(OBS_SIZE).fill(0)
    observation[0]=observation[1]=observation[2]=observation[31]=1
    observation[12]=tick%2?0:.875;observation[97]=-.7
    const actions=ACTION_WIDTHS.map(()=>0);actions[5]=tick%2?0:1;actions[4]=tick%2?2:0
    const context={entryCurriculum:10,distributionVersion:3,calibratedHeads:[2,4,5],weaponConditionedAttack:2}
    const publicHealthFeatures=[.5,0,0,0,0],previous=current
    const out=tf.tidy(()=>{
      const result=conditionalModel.step(tf.tensor2d([observation]),current,null,publicHealthFeatures)
      const heads=biasedActionLogits(result.logits,observation,context,actions,conditionalModel,publicHealthFeatures)
      const keep=[...actions];keep[5]=tick%2?1:0
      const unchanged=biasedActionLogits(result.logits,observation,context,keep,conditionalModel,publicHealthFeatures)
      assert(tf.softmax(heads[4]).dataSync()[2]<tf.softmax(unchanged[4]).dataSync()[2],
        'learned attack probability must reflect reset charge, including public-health projection')
      for(const h of [0,1,2,3,5,6,7,8])assert.deepEqual([...heads[h].dataSync()],[...unchanged[h].dataSync()])
      assert.throws(()=>biasedActionLogits(result.logits,observation,context,actions),/same policy/)
      return {state:result.state,value:result.value.dataSync()[0],p:heads.map(h=>[...tf.softmax(h).dataSync()])}
    })
    current=out.state;releaseState(previous,current)
    frames.push({observation,actions,context,publicHealthFeatures,oldHeadProbabilities:out.p,
      oldHeadLogProbs:out.p.map((p,h)=>Math.log(Math.max(1e-30,p[actions[h]]))),
      oldValue:out.value,reward:tick===7?1:0,done:tick===7,checkpointSha256:'conditional-residual',
      executedHeads:ACTION_WIDTHS.map(()=>true)})
  }
  releaseState(current)
  assert(replayPolicyHealth(conditionalModel,frames).maxMeanHeadKL<1e-6)
  const update=completeRolloutUpdate(conditionalModel,conditionalAdam,computeGAE([frames])[0])
  assert.equal(update.trainedFrames,8)
  assert(Number.isFinite(update.loss)&&update.gradientNorm>0)
  console.log('LEARNED_CONDITIONAL_ATTACK_PPO_PASS: reset charge, same acting/replay distribution, real gradients')
} finally { conditionalAdam.dispose();conditionalModel.dispose() }
