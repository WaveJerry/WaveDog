"""Add a measured learning receipt to shared coach memory; no Qwen weight claim."""
from pathlib import Path
from datetime import datetime
import json

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
CANDIDATE = BASE / 'runtime/pvp-technique-20261115/imitation/candidate-20261115-a'
receipt = json.loads((CANDIDATE / 'receipt.json').read_text())
memory = ROOT / 'work/pvp-8.6-dual-fresh/model/coach/shared-lessons.jsonl'
key = receipt['saved']['sha256']
existing = [json.loads(line) for line in memory.read_text(encoding='utf-8').splitlines() if line.strip()]
if any(row.get('source') == 'native-human-imitation-verified' and row.get('checkpointSha256') == key for row in existing):
    print(json.dumps({'alreadyPublished': True, 'checkpointSha256': key}))
else:
    row = {'at': datetime.now().astimezone().isoformat(), 'source': 'native-human-imitation-verified',
        'focus': 'COMBO', 'checkpointSha256': key, 'trainingReceipt': str(CANDIDATE / 'receipt.json'),
        'lesson': '疾风和WaveJerry的原生对局示范已用于独立模仿训练：贴身换剑与合法攻击窗口可继续练；切换会重置蓄力，已蓄好斧击不要浪费。留出改善不等于实战掌握，继续按净换血、剑伤害与胜负复验。',
        'methodology': [
            '所有招式结合距离、敌我上升或下落阶段、盾与蓄力判断；不固定成等待惩罚暴击。',
            '对方上升期或平地进入边界时练抢断；已经进入下落暴击窗口要比较躲开、反击和换血代价。',
            '贴身持续交换时比较剑连击、暴击输出与斧头惩罚，按原生效果学习，不能只数动作次数。',
            '跳跃重置仍需受击tick起跳与实际击退验证，不能用普通跳跃冒充。'],
        'humanImitationUpdates': receipt['imitationOptimizer']['steps'],
        'ppoCountersPreserved': receipt['ppoCountersPreserved'],
        'qwenMemoryUpdated': True, 'qwenWeightsUpdated': False,
        'livePvpImprovementVerified': False}
    with memory.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + '\n')
    (CANDIDATE / 'shared-coach-lesson.json').write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'sharedMemory': str(memory), 'checkpointSha256': key, 'qwenWeightsUpdated': False}))
