import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, DualPolicy, OBS_SIZE,
  computeGAE, ppoUpdate } from './dual-policy.js'
import { SharedAdam } from './optimizer-checkpoint.js'

await tf.setBackend('cpu')
await tf.ready()
const model = new DualPolicy()
const adam = new SharedAdam(model.params)
const raw = []
let state = model.initialState()
for (let frame = 0; frame < 8; frame++) {
  const observation = Array.from({ length: OBS_SIZE }, (_, index) =>
    .25 * Math.sin(index * .13 + frame * .29))
  const output = model.step(tf.tensor2d([observation]), state)
  state = output.state
  const actions = ACTION_WIDTHS.map(() => 0)
  const oldHeadLogProbs = output.logits.map((head, index) =>
    tf.logSoftmax(head).dataSync()[actions[index]])
  raw.push({ observation, actions, oldHeadLogProbs,
    oldValue: output.value.dataSync()[0], reward: frame === 7 ? 1 : 0,
    done: frame === 7, executedHeads: ACTION_WIDTHS.map(() => true) })
}
const start = performance.now()
const result = ppoUpdate(model, adam, computeGAE([raw]))
console.log(JSON.stringify({ frames: raw.length,
  updateMs: +(performance.now() - start).toFixed(1),
  loss: result.loss, memory: tf.memory() }))
adam.dispose()
model.dispose()
