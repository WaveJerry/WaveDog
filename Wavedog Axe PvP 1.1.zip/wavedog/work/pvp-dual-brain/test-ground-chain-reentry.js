import assert from 'node:assert/strict'
import fs from 'node:fs'
import * as tf from '@tensorflow/tfjs'
import {meleeEntryContext,meleeTechniqueGoal} from './fresh-melee-progress.js'
import {ACTION_WIDTHS,OBS_SIZE,biasedActionLogits} from './fresh-policy.js'
const matchId='8ace6dcb-0c16-41f0-b7f7-db56560136cd'
const rows=fs.readFileSync(new URL(`../wavedog-protocol/runtime/${matchId}-frames.jsonl`,import.meta.url),'utf8')
  .trim().split('\n').map(JSON.parse)
let previous=null,context=null,found
for(const f of rows){
  const req={...f,matchId,opponent:'wasplan',focus:'FREE',
    observedOpponentMotion:f.observedOpponentMotion,
    observedOpponentSwingAge:f.seen.swing?f.tick-f.seen.swing:-1}
  context=meleeEntryContext(previous,req,context)
  if(f.tick===24638)found={context,req}
  previous=req
}
assert(found.context.groundChainReentry,'the recorded 2.99-block ground return must be recognized')
assert.equal(meleeTechniqueGoal(found.req,found.context).focus,'SPRINT_KB')
const current=found.req,prior={...current,tick:current.tick-1}
for(const over of [{matchId:'different'},{self:{...current.self,using:true}},
  {self:{...current.self,shielding:true}},{seen:{...current.seen,shield:true}},
  {observedOpponentMotion:{...current.observedOpponentMotion,grounded:false,vy:-.3}}]){
  const next=meleeEntryContext(prior,{...current,...over},found.context)
  assert(!next.groundChainReentry,JSON.stringify(over))
}
await tf.setBackend('cpu');await tf.ready()
const x=Array(OBS_SIZE).fill(0);x[31]=1;x[1]=.65;x[2]=1;x[12]=1;x[97]=-.01
const logits=ACTION_WIDTHS.map(n=>tf.tensor2d([Array.from({length:n},(_,i)=>i===0?8:0)]))
function hand(ctx){return tf.tidy(()=>Array.from(tf.softmax(biasedActionLogits(logits,x,ctx)[4]).dataSync()))}
const old=hand({entryCurriculum:8,groundChainReentry:false})
assert.deepEqual(old,hand({entryCurriculum:8,groundChainReentry:true}),'old v8 rollouts retain their distribution')
const now=hand({entryCurriculum:9,groundChainReentry:true})
assert(now[2]>old[2]&&now[0]>0&&now[2]<1,'a timely light hit is learnable, never mandatory')
logits.forEach(t=>t.dispose())
console.log(JSON.stringify({result:'WASPLAN_GROUND_REENTRY_CAUSAL_REPLAY_PASS',tick:24638,
  reach:found.req.observation.reach,charge:found.req.self.charge,context:found.context}))
