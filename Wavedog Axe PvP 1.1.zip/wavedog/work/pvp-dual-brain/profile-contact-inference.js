import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { advance, disposeState } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const [checkpoint, rolloutFile, destination] = process.argv.slice(2)
const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(rolloutFile)))
const loaded = loadDualCheckpoint(checkpoint); loaded.adam.dispose()
const rows = []; let state = loaded.model.initialState()
try {
  for (const frame of rollout.episode.slice(0, 192)) {
    const refresh = !state.slow || state.frames % loaded.model.config.interval === 0
    const start = performance.now()
    const output = advance(loaded.model, state, frame.observation, true,
      frame.legalMasks, frame.publicHealthFeatures)
    state = output.state
    rows.push({ tick: frame.decidedTick, refresh, milliseconds: performance.now() - start })
  }
  const summary = values => {
    values.sort((a, b) => a - b)
    return { count: values.length, median: values[Math.floor(values.length * .5)],
      p95: values[Math.floor(values.length * .95)], max: values.at(-1) }
  }
  const report = { checkpointSha256: loaded.manifest.sha256, training: false,
    ordinary: summary(rows.filter(x => !x.refresh).map(x => x.milliseconds)),
    refresh: summary(rows.filter(x => x.refresh).map(x => x.milliseconds)), rows }
  fs.writeFileSync(destination, JSON.stringify(report, null, 2))
  console.log(JSON.stringify({ ordinary: report.ordinary, refresh: report.refresh }))
} finally { disposeState(state); loaded.model.dispose() }
