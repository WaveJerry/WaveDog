import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { localReview } from './protocol-review.js'

const root=path.resolve('outputs/sword-learning-next-20261116/joint-expert-sequences-v1')
const reference=JSON.parse(fs.readFileSync(path.join(root,'wasplan-six-crit-reference.json')))
const referenceHash=()=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'wasplan-six-crit-reference.json'))).digest('hex')
const sourceReferenceHash=referenceHash()
const frames=reference.frames.map(frame=>{
  const {self,seen}=frame.publicRequest
  return [frame.tick,self.held,self.charge,self.ground,self.vy,
    self.x,self.y,self.z,seen.x-self.x,seen.y-self.y,seen.z-self.z,
    seen.shield,frame.labels,frame.labelEvidence]
})
const answer=await localReview([
  {role:'system',content:'你是WaveDog的局后教练。严格按完整逐帧参考和原生暴击证据分析剑连跳劈。未知移动按键不能猜；指出持剑续连、起落/蓄力与出刀衔接的可检验目标。原生暴击证明结果，不证明上一采样帧的疾跑键状态。不能称WaveDog已学会、不能用机械强制出刀代替模型学习。只输出规定JSON，lesson一句60汉字内。'},
  {role:'user',content:JSON.stringify({fighter:reference.fighter,
    tickGaps:reference.tickGaps,positiveDamage:reference.positiveDamage,
    nativeCriticalEvidence:reference.nativeCriticalEvidence,
    nativeEvents:reference.knownNativeEvents,
    fields:['tick','held','charge','ground','vy','x','y','z','target_dx','target_dy','target_dz','target_shield','known_labels','evidence'],
    frames,method:'原完整18局同场划分，联合监督原生跳跃、换武器、出刀及真实等待；未知走位按键不编造。独立验证必须在协议玩家实际对局中产生真实正伤害暴击链。'})}
])
const receipt={at:new Date().toISOString(),source:'verified-expert-sequence',fighter:reference.fighter,
  sourceReferenceHash,
  sourceSha256:reference.sourceSha256,frameCount:frames.length,reviewedFrames:frames.length,
  coverage:1,weightsAlreadyMastered:false,...answer}
if(referenceHash()!==sourceReferenceHash)throw Error('Reference changed during review; do not persist stale analysis')
fs.writeFileSync(path.join(root,'qwen-reference-review.json'),JSON.stringify(receipt,null,2))
fs.appendFileSync('work/pvp-8.6-dual-fresh/model/coach/shared-lessons.jsonl',JSON.stringify(receipt)+'\n')
console.log(JSON.stringify(receipt))
