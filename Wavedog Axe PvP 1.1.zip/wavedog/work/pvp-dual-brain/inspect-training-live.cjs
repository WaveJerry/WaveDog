// Source/state snapshots. The explicit 'repair' mode replaces only the verified
// legacy learning listener with the tested sender-bound listener.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto')
async function main () {
  const pid = Number(process.argv[2]), folder = path.resolve(process.argv[3])
  process._debugProcess(pid)
  let endpoint
  for (let i = 0; i < 25; i++) {
    try { endpoint = (await (await fetch('http://127.0.0.1:9229/json/list')).json())[0]; break }
    catch { await new Promise(r => setTimeout(r, 100)) }
  }
  if (!endpoint) throw Error('Inspector unavailable')
  const ws = new WebSocket(endpoint.webSocketDebuggerUrl), pending = new Map(), scripts = [], workers = []
  let sequence = 0, onPause, breakpoint, paused = false, verified = false
  const receive = (row, session = '') => {
    if (row.id) { const cb = pending.get(session + ':' + row.id); pending.delete(session + ':' + row.id); cb?.(row) }
    else if (row.method === 'Debugger.scriptParsed') scripts.push({ ...row.params, session })
    else if (row.method === 'Debugger.paused') { paused = true; onPause?.(row.params) }
    else if (row.method === 'NodeWorker.attachedToWorker') workers.push(row.params)
    else if (row.method === 'NodeWorker.receivedMessageFromWorker') receive(JSON.parse(row.params.message), row.params.sessionId)
  }
  ws.addEventListener('message', e => receive(JSON.parse(e.data)))
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve); ws.addEventListener('error', reject) })
  const call = (method, params = {}, session = '') => new Promise((resolve, reject) => {
    const id = ++sequence, timer = setTimeout(() => reject(Error('Inspector timeout: ' + method)), 10000)
    pending.set(session + ':' + id, row => { clearTimeout(timer); row.error ? reject(Error(JSON.stringify(row.error))) : resolve(row.result) })
    ws.send(JSON.stringify(session ? { id: ++sequence, method: 'NodeWorker.sendMessageToWorker',
      params: { sessionId: session, message: JSON.stringify({ id, method, params }) } } : { id, method, params }))
  })
  try {
    if ((await call('Runtime.evaluate', { expression: 'process.pid', returnByValue: true })).result.value !== pid) throw Error('Wrong process')
    verified = true; await call('Debugger.enable')
    await call('NodeWorker.enable', { waitForDebuggerOnStart: false })
    for (const worker of workers) await call('Debugger.enable', {}, worker.sessionId)
    const physicsMode = process.argv[4] === 'physics'
    const selected = scripts.filter(s => /\/(fresh-policy|fresh-melee-progress|selfplay)\.js$/.test(s.url)
      || physicsMode && s.url.endsWith('/mineflayer/lib/plugins/physics.js'))
    fs.mkdirSync(folder, { recursive: true })
    const result = []
    for (const script of selected) {
      const source = (await call('Debugger.getScriptSource', { scriptId: script.scriptId }, script.session)).scriptSource
      const file = path.join(folder, `${script.session ? 'worker' : 'main'}-${script.scriptId}-${path.basename(script.url)}`)
      fs.writeFileSync(file, source)
      result.push({ id: script.scriptId, url: script.url, worker: !!script.session,
        context: script.executionContextId, liveEdit: !!script.isLiveEdit,
        sha256: crypto.createHash('sha256').update(source).digest('hex'), file })
    }
    const selfplay = selected.filter(s => s.url.endsWith(physicsMode ? '/mineflayer/lib/plugins/physics.js' : '/selfplay.js') && !s.session).at(-1)
    const locations = []
    for (const session of ['', ...workers.map(w => w.sessionId)]) {
      if (!selected.some(s => s.url.endsWith('/fresh-policy.js') && s.session === session)) continue
      const url = selected.find(s => s.url.endsWith('/fresh-policy.js') && s.session === session).url
      const fn = await call('Runtime.evaluate', { expression: `import(${JSON.stringify(url)}).then(m=>m.biasedActionLogits)`, awaitPromise: true }, session)
      if (fn.result.objectId) {
        const properties = await call('Runtime.getProperties', { objectId: fn.result.objectId }, session)
        const location = properties.internalProperties?.find(p => p.name === '[[FunctionLocation]]')
        const fields = location?.value?.objectId ? (await call('Runtime.getProperties',
          { objectId: location.value.objectId }, session)).result : []
        locations.push({ worker: !!session, url, function: fn.result.description,
          internal: properties.internalProperties, location: Object.fromEntries(fields.map(p => [p.name, p.value?.value])) })
      } else locations.push({ worker: !!session, url, failed: fn.exceptionDetails?.text })
    }
    let state = null
    if (selfplay) {
      const source = (await call('Debugger.getScriptSource', { scriptId: selfplay.scriptId })).scriptSource
      const lines = source.split('\n'), callback = process.argv[4] === 'callback'
      const start = callback ? lines.findIndex(l => l.includes("bot.on('physicsTick', () =>")) : 0
      const qualityMode = process.argv[4] === 'quality'
      const lineNumber = lines.findIndex((l, i) => i >= start && l.includes(callback
        ? 'const session = sessions.get(name)' : physicsMode ? "if (bot._client.state !== 'play')"
          : qualityMode ? 'if (stopping || !bridgeReady) { fs.rmSync' : 'const bot = bots.get(session.name), target')) + (callback ? 1 : 0)
      if (lineNumber < 0) throw Error('Known safe snapshot location missing')
      const waiting = new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(Error('No training callback within 8 seconds')), 8000)
        onPause = row => { clearTimeout(timer); resolve(row) }
      })
      breakpoint = qualityMode ? await call('Debugger.setBreakpointByUrl', { url: selfplay.url, lineNumber })
        : await call('Debugger.setBreakpoint', { location: { scriptId: selfplay.scriptId, lineNumber } })
      const hit = await waiting
      const expression = qualityMode ? `JSON.stringify({activePairs:pairs.size,lessonPool:sharedLessons.length})`
        : physicsMode ? `JSON.stringify({name:bot.username,shouldUsePhysics,physicsEnabled:bot.physicsEnabled,state:bot._client.state,chunk:bot.blockAt(bot.entity.position)?.name,timeAccumulator,catchupTicks,lastPhysicsFrameTime,now,delta:performance.now()-lastPhysicsFrameTime})`
        : callback ? `JSON.stringify({capturedName:name,capturedBot:bot.username,sessionName:session?.name,mapSession:sessions.get(name)?.name,sessions:[...sessions].map(([k,s])=>({key:k,name:s.name,frames:s.framesSeen,decisions:s.decisions}))})`
        : `JSON.stringify({sessionNames:[...sessions].map(([k,s])=>({key:k,name:s.name,arena:s.arena,bout:s.bout,opponent:s.opponent,frames:s.framesSeen,decisions:s.decisions,matchId:s.matchId})),bots:[...bots].map(([k,b])=>({key:k,username:b.username,health:b.health,physics:b.physicsEnabled,physicsListeners:b.listenerCount('physicsTick'),position:b.entity?.position,ended:b._client.ended})),pairs:[...pairs].map(([k,p])=>({key:k,...p})),callbackName:session.name})`
      const value = await call('Debugger.evaluateOnCallFrame', { callFrameId: hit.callFrames[0].callFrameId,
        expression, returnByValue: true })
      if (value.exceptionDetails) throw Error('State snapshot failed')
      state = JSON.parse(value.result.value)
      if (process.argv[4] === 'repair') {
        const modulePath = path.resolve('work/pvp-player-client/learning-frame-listener.js')
        const expression = `(() => {const install=process.mainModule.require(${JSON.stringify(modulePath)}).installLearningFrames;for(const bot of bots.values())install(bot,{sessions,recordFighterFrame,requestAction},true);return [...bots].map(([name,bot])=>({name,learningCallbacks:bot.listeners('physicsTick').filter(fn=>fn.name==='learningPhysicsTick').length,totalCallbacks:bot.listenerCount('physicsTick')}));})()`
        const repaired = await call('Debugger.evaluateOnCallFrame', { callFrameId: hit.callFrames[0].callFrameId,
          expression, returnByValue: true })
        if (repaired.exceptionDetails) throw Error('Listener repair failed: '
          + (repaired.exceptionDetails.exception?.description || repaired.exceptionDetails.text))
        state.repair = repaired.result.value
      }
      if (process.argv[4] === 'quality') {
        const file = path.resolve('work/pvp-8.6-dual-fresh/model/coach/quality-flags.jsonl')
        const expression = `(() => {const ids=new Set(fs.readFileSync(${JSON.stringify(file)},'utf8').split(/\\r?\\n/).flatMap(line=>{try{const row=JSON.parse(line);return ['review-invalid','mechanics-invalid'].includes(row.status)?[row.matchId]:[]}catch{return []}}));for(const id of ids)invalidMatchIds.add(id);let removed=0;for(let i=sharedLessons.length-1;i>=0;i--)if(ids.has(sharedLessons[i].matchId)){sharedLessons.splice(i,1);removed++}return {invalidMatches:ids.size,removedFromLiveLessonPool:removed,rawLogsRetained:true};})()`
        const result = await call('Debugger.evaluateOnCallFrame', { callFrameId: hit.callFrames[0].callFrameId,
          expression, returnByValue: true })
        if (result.exceptionDetails) throw Error('Quality flag refresh failed: '
          + (result.exceptionDetails.exception?.description || result.exceptionDetails.text))
        state.quality = result.result.value
      }
      if (process.argv[4] === 'watch') {
        const target = path.join(folder, 'frame-watch.json')
        const watch = `(() => { const counts={},initial={},hooks=[]; for(const [name,b] of bots){ counts[name]=0; initial[name]=sessions.get(name)?.framesSeen; const listener=function(){counts[this.username]++};b.on('physicsTick',listener);hooks.push([b,listener]);} setTimeout(()=>{for(const [b,listener]of hooks)b.removeListener('physicsTick',listener);fs.writeFileSync(${JSON.stringify(target)},JSON.stringify({counts,initial,final:[...sessions].map(([k,s])=>({name:k,frames:s.framesSeen,bout:s.bout}))},null,2));},3000);return true;})()`
        const installed = await call('Debugger.evaluateOnCallFrame', { callFrameId: hit.callFrames[0].callFrameId,
          expression: watch, returnByValue: true })
        if (installed.exceptionDetails) throw Error('Watch installation failed')
      }
      if (physicsMode || callback) {
        state = [state]
        for (let i = 0; i < 20 && new Set(state.map(s => s.name || s.capturedName)).size < 4; i++) {
          const next = new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(Error('Physics sample timeout')), 2000)
            onPause = row => { clearTimeout(timer); resolve(row) }
          })
          await call('Debugger.resume'); paused = false
          const frame = await next; paused = true
          const sampled = await call('Debugger.evaluateOnCallFrame', {
            callFrameId: frame.callFrames[0].callFrameId, expression, returnByValue: true })
          if (sampled.exceptionDetails) throw Error('Physics sample failed')
          state.push(JSON.parse(sampled.result.value))
        }
      }
      if (callback && !Array.isArray(state) && hit.callFrames[1]) {
        const emitter = await call('Debugger.evaluateOnCallFrame', { callFrameId: hit.callFrames[1].callFrameId,
          expression: 'this.username', returnByValue: true })
        state.emitter = emitter.result.value
      }
    }
    const receipt = { at: new Date().toISOString(), pid, scripts: result, locations, state }
    fs.writeFileSync(path.join(folder, 'snapshot.json'), JSON.stringify(receipt, null, 2))
    console.log(JSON.stringify(receipt))
  } finally {
    if (breakpoint) await call('Debugger.removeBreakpoint', { breakpointId: breakpoint.breakpointId })
    if (paused) await call('Debugger.resume')
    if (verified) await call('Runtime.evaluate', { expression: 'setTimeout(() => process.getBuiltinModule("inspector").close(), 100); true' })
    ws.close()
  }
}
main().catch(e => { console.error(e); process.exitCode = 1 })
