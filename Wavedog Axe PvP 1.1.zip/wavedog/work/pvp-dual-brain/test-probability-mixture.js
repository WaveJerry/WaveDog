import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { probabilityMixture, biasedActionLogits, DualPolicy, OBS_SIZE } from './fresh-policy.js'
await tf.setBackend('cpu'); await tf.ready()
const result = tf.tidy(() => {
  const fast = [tf.tensor2d([[0, 0, 0, 0, 0]])]
  const slow = [tf.tensor2d([[1000, 0, -1000, 0, 0]])]
  const gate = tf.tensor2d([[.75]])
  const mask = [[true, false, true, false, false]]
  const mixture = probabilityMixture(fast, slow, gate, mask)
  const probabilities = [...tf.softmax(mixture[0]).dataSync()]
  assert.equal(biasedActionLogits(mixture, Array(OBS_SIZE).fill(0),
    { distributionVersion: 2 }), mixture, 'v2 must not reapply old tactical overrides')
  return probabilities
})
assert(Math.abs(result[2] - .13) < 1e-5, 'an extreme slow wait preference must retain calibrated fast influence')
assert.equal(result[1], 0, 'illegal shield action remains impossible')
assert(Math.abs(result.reduce((a, b) => a + b) - 1) < 1e-6)
const tiny = { fast: 8, slow: 16, heads: 2, layers: 1, ff: 24, interval: 2, memory: 4 }
const legacy = new DualPolicy(tiny)
const mixed = new DualPolicy({ ...tiny, distributionVersion: 2 })
assert.deepEqual(mixed.params.map(p => p.shape), legacy.params.map(p => p.shape),
  'upgrade retains every existing weight and Adam tensor shape')
legacy.dispose(); mixed.dispose()
const original = new DualPolicy(tiny)
const selective = new DualPolicy({ ...tiny, distributionVersion: 2, calibratedHeads: [4,5] })
for (let i = 0; i < original.params.length; i++) selective.params[i].assign(original.params[i])
tf.tidy(() => {
  const observation = tf.tensor2d([Array.from({length: OBS_SIZE},(_,i)=>Math.sin(i)*.1)])
  const a = original.step(observation, original.initialState())
  const b = selective.step(observation, selective.initialState())
  for (const head of [0,1,2,3,6,7,8]) assert.deepEqual([...a.logits[head].dataSync()], [...b.logits[head].dataSync()],
    'attack/weapon calibration must leave other heads unchanged')
})
original.dispose(); selective.dispose()
const old = new DualPolicy(tiny)
const versioned = new DualPolicy({ ...tiny, distributionVersion: 3, calibratedHeads: [2,5] })
for(let i=0;i<old.params.length;i++)versioned.params[i].assign(old.params[i])
tf.tidy(()=>{
  const obs=Array(OBS_SIZE).fill(0);obs[1]=1;obs[2]=1;obs[31]=1;obs[97]=-.2
  const tensor=tf.tensor2d([obs])
  const a=old.step(tensor,old.initialState()),b=versioned.step(tensor,versioned.initialState())
  const context={entryCurriculum:10,swordSustainWindow:true}
  const prior=biasedActionLogits(a.logits,obs,context)
  const after=biasedActionLogits(b.logits,obs,{...context,distributionVersion:3,calibratedHeads:[2,5]})
  for(const h of [0,1,3,4,6,7,8])assert.deepEqual([...after[h].dataSync()],[...prior[h].dataSync()],
    'v3 must preserve every uncalibrated deployed head including charge/entry priors')
  for(const h of [2,5])assert.deepEqual([...after[h].dataSync()],[...b.logits[h].dataSync()],
    'calibrated heads must use exactly the probability mixture')
})
old.dispose();versioned.dispose()
console.log(JSON.stringify({ result: 'PROBABILITY_FUSION_PASS', extremeSlowAttackProbability: result[2] }))
