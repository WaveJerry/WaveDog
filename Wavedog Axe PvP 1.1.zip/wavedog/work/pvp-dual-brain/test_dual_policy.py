from pathlib import Path
import tempfile
import torch
from dual_policy import (ACTION_WIDTHS, OBS_SIZE, SLOW_LAYERS, SLOW_MEMORY,
                         DualPolicy, Transition, ppo_update, save_checkpoint)

torch.set_num_threads(1)
torch.manual_seed(20261113)
model = DualPolicy(gate_mode="learned")
optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
parameters = sum(weight.numel() for weight in model.parameters())
assert 2_500_000 <= parameters <= 5_000_000, parameters

def episode(seed):
    torch.manual_seed(seed)
    state = model.initial_state()
    result = []
    with torch.no_grad():
        for frame in range(16):
            observation = torch.randn(1, OBS_SIZE) * .2
            output, state = model.forward_step(observation, state)
            reward = ((frame % 4) - 1.5) * .04
            if frame == 15:
                reward += 1.0
            result.append(Transition(observation[0], output.actions[0],
                output.log_probs[0], float(output.value[0]), reward,
                frame == 15, torch.tensor([True] * len(ACTION_WIDTHS))))
    assert len(state.caches) == SLOW_LAYERS
    assert all(cache is not None and cache[0].shape[2] <= SLOW_MEMORY
               for cache in state.caches)
    assert state.frames == 16
    assert model.initial_state().frames == 0  # no cross-bout hidden-state carryover
    return result

episodes = [episode(15), episode(16)]
fast_before = model.fast_cell.weight_ih.detach().clone()
slow_before = model.slow_blocks[0].query.weight.detach().clone()
gate_before = model.gate_network[0].weight.detach().clone()
metrics = ppo_update(model, optimizer, episodes)
assert torch.isfinite(torch.tensor(metrics["loss"]))
assert not torch.equal(fast_before, model.fast_cell.weight_ih)
assert not torch.equal(slow_before, model.slow_blocks[0].query.weight)
assert not torch.equal(gate_before, model.gate_network[0].weight)
assert all(0 < value < 1 for value in metrics["gate_mean"])

fixed = DualPolicy(gate_mode="fixed")
with torch.no_grad():
    output, _ = fixed.forward_step(torch.zeros(1, OBS_SIZE), deterministic=True)
assert torch.allclose(output.gate[0], fixed.fixed_gate)

with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
    checkpoint = Path(folder) / "dual.pt"
    save_checkpoint(checkpoint, model, optimizer,
                    {"episodes": 2, "baseline": "last_gru"})
    saved = torch.load(checkpoint, weights_only=False)
    assert saved["metadata"]["baseline"] == "last_gru"
    assert "model" in saved and "optimizer" in saved

print({"result": "DUAL_POLICY_PASS", "parameters": parameters,
       "frames": sum(map(len, episodes)), "ppo": metrics})
