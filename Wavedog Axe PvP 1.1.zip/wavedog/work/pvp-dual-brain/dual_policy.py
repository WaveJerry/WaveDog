"""A causal GRU + gated Transformer XL actor with one joint PPO policy."""
from dataclasses import dataclass, field
from pathlib import Path
import math
import os
import torch
from torch import nn
from torch.distributions import Categorical

OBS_SIZE = 98
ACTION_WIDTHS = (9, 2, 2, 2, 5, 5, 13, 7, 2)
FAST_SIZE = 64
SLOW_SIZE = 256
SLOW_HEADS = 8
SLOW_LAYERS = 4
SLOW_FF = 1024
SLOW_INTERVAL = 8
SLOW_MEMORY = 256
GATE_TARGET = (0.20, 0.25, 0.25, 0.25, 0.45, 0.55, 0.35, 0.35, 0.35)


@dataclass
class ActorState:
    fast: torch.Tensor
    slow: torch.Tensor | None = None
    caches: list[tuple[torch.Tensor, torch.Tensor] | None] = field(default_factory=list)
    pending: list[torch.Tensor] = field(default_factory=list)
    frames: int = 0

    def detached(self):
        return ActorState(self.fast.detach(),
            None if self.slow is None else self.slow.detach(),
            [None if pair is None else (pair[0].detach(), pair[1].detach())
             for pair in self.caches], [x.detach() for x in self.pending], self.frames)


class GatedXLBlock(nn.Module):
    """One causal attention step with a per-layer projected K/V memory."""
    def __init__(self, width=SLOW_SIZE, heads=SLOW_HEADS, ff_width=SLOW_FF):
        super().__init__()
        self.heads = heads
        self.head_width = width // heads
        self.norm_attention = nn.LayerNorm(width)
        self.query = nn.Linear(width, width)
        self.key = nn.Linear(width, width)
        self.value = nn.Linear(width, width)
        self.attention_out = nn.Linear(width, width)
        self.attention_gate = nn.Linear(width * 2, width)
        self.norm_ff = nn.LayerNorm(width)
        self.ff = nn.Sequential(nn.Linear(width, ff_width), nn.GELU(),
                                nn.Linear(ff_width, width))
        self.ff_gate = nn.Linear(width * 2, width)
        self.register_buffer("age_slope", torch.linspace(.003, .03, heads).view(1, heads, 1))

    def forward(self, current, cache=None, memory_limit=SLOW_MEMORY):
        batch, width = current.shape
        normalized = self.norm_attention(current)
        query = self.query(normalized).view(batch, self.heads, 1, self.head_width)
        key = self.key(normalized).view(batch, self.heads, 1, self.head_width)
        value = self.value(normalized).view(batch, self.heads, 1, self.head_width)
        if cache is not None:
            key = torch.cat((cache[0], key), dim=2)
            value = torch.cat((cache[1], value), dim=2)
        key = key[:, :, -memory_limit:, :]
        value = value[:, :, -memory_limit:, :]
        age = torch.arange(key.shape[2] - 1, -1, -1,
                           device=current.device, dtype=current.dtype).view(1, 1, -1)
        score = (query * key).sum(dim=-1) / math.sqrt(self.head_width)
        score = score - self.age_slope.to(dtype=current.dtype) * age
        weights = torch.softmax(score, dim=-1)
        attended = (weights.unsqueeze(-1) * value).sum(dim=2).reshape(batch, width)
        attention = self.attention_out(attended)
        gate = torch.sigmoid(self.attention_gate(torch.cat((current, attention), dim=-1)))
        output = current + gate * attention
        feed_forward = self.ff(self.norm_ff(output))
        feed_gate = torch.sigmoid(self.ff_gate(torch.cat((output, feed_forward), dim=-1)))
        output = output + feed_gate * feed_forward
        return output, (key, value)


@dataclass
class PolicyOutput:
    actions: torch.Tensor
    log_probs: torch.Tensor
    entropies: torch.Tensor
    value: torch.Tensor
    gate: torch.Tensor
    logits: list[torch.Tensor]


class DualPolicy(nn.Module):
    def __init__(self, gate_mode="learned", slow_interval=SLOW_INTERVAL,
                 memory_limit=SLOW_MEMORY):
        super().__init__()
        if gate_mode not in {"learned", "fixed"}:
            raise ValueError("gate_mode must be learned or fixed")
        self.gate_mode = gate_mode
        self.slow_interval = slow_interval
        self.memory_limit = memory_limit
        self.fast_cell = nn.GRUCell(OBS_SIZE, FAST_SIZE)
        self.fast_heads = nn.ModuleList(nn.Linear(FAST_SIZE, width) for width in ACTION_WIDTHS)
        self.slow_token = nn.Linear(OBS_SIZE * 2, SLOW_SIZE)
        self.slow_blocks = nn.ModuleList(GatedXLBlock() for _ in range(SLOW_LAYERS))
        self.slow_heads = nn.ModuleList(nn.Linear(SLOW_SIZE, width) for width in ACTION_WIDTHS)
        self.gate_network = nn.Sequential(nn.Linear(OBS_SIZE + FAST_SIZE + SLOW_SIZE, 128),
            nn.Tanh(), nn.Linear(128, len(ACTION_WIDTHS)))
        self.critic = nn.Sequential(nn.Linear(OBS_SIZE + FAST_SIZE + SLOW_SIZE, 256),
            nn.Tanh(), nn.Linear(256, 1))
        self.register_buffer("fixed_gate", torch.tensor(GATE_TARGET))

    def initial_state(self, batch=1, device=None):
        device = device or next(self.parameters()).device
        return ActorState(torch.zeros(batch, FAST_SIZE, device=device),
                          caches=[None] * SLOW_LAYERS)

    def forward_step(self, observation, state=None, actions=None,
                     legal_masks=None, deterministic=False):
        if observation.ndim != 2 or observation.shape[1] != OBS_SIZE:
            raise ValueError(f"Expected [batch,{OBS_SIZE}] public observations")
        state = state or self.initial_state(observation.shape[0], observation.device)
        if state.fast.shape[0] != observation.shape[0]:
            raise ValueError("Actor state belongs to a different batch")
        fast = self.fast_cell(observation, state.fast)
        pending = [*state.pending, observation]
        slow = state.slow
        caches = state.caches
        if slow is None or state.frames % self.slow_interval == 0:
            summary = torch.stack(pending, dim=0).mean(dim=0)
            slow = torch.tanh(self.slow_token(torch.cat((observation, summary), dim=-1)))
            caches = []
            for block, cache in zip(self.slow_blocks, state.caches):
                slow, next_cache = block(slow, cache, self.memory_limit)
                caches.append(next_cache)
            pending = []
        fused_features = torch.cat((observation, fast, slow), dim=-1)
        gate = torch.sigmoid(self.gate_network(fused_features)) if self.gate_mode == "learned" \
            else self.fixed_gate.view(1, -1).expand(observation.shape[0], -1)
        logits = []
        selected = []
        log_probs = []
        entropies = []
        for index, (fast_head, slow_head) in enumerate(zip(self.fast_heads, self.slow_heads)):
            bias = gate[:, index:index + 1]
            head_logits = (1 - bias) * fast_head(fast) + bias * slow_head(slow)
            if legal_masks is not None:
                mask = legal_masks[index].to(dtype=torch.bool, device=observation.device)
                if mask.ndim == 1:
                    mask = mask.unsqueeze(0).expand_as(head_logits)
                if not mask.any(dim=-1).all():
                    raise ValueError("Action head has no legal choice")
                head_logits = head_logits.masked_fill(~mask, -1e9)
            distribution = Categorical(logits=head_logits)
            chosen = actions[:, index] if actions is not None else \
                head_logits.argmax(dim=-1) if deterministic else distribution.sample()
            selected.append(chosen)
            log_probs.append(distribution.log_prob(chosen))
            entropies.append(distribution.entropy())
            logits.append(head_logits)
        result = PolicyOutput(torch.stack(selected, dim=-1),
            torch.stack(log_probs, dim=-1), torch.stack(entropies, dim=-1),
            self.critic(fused_features).squeeze(-1), gate, logits)
        next_state = ActorState(fast, slow, caches, pending, state.frames + 1)
        return result, next_state


@dataclass
class Transition:
    observation: torch.Tensor
    actions: torch.Tensor
    old_log_probs: torch.Tensor
    old_value: float
    reward: float
    done: bool
    executed_heads: torch.Tensor


def ppo_update(model, optimizer, episodes, clip=.2, gamma=.997, gae_lambda=.99,
               value_coef=.5, entropy_coef=.0001, gate_warmup=1.0):
    if not episodes or any(not episode for episode in episodes):
        raise ValueError("PPO requires nonempty completed episodes")
    advantages, targets = [], []
    for episode in episodes:
        gae = 0.0
        next_value = 0.0
        local = []
        for item in reversed(episode):
            survival = 0.0 if item.done else 1.0
            delta = item.reward + gamma * next_value * survival - item.old_value
            gae = delta + gamma * gae_lambda * survival * gae
            local.append(gae)
            next_value = item.old_value
        local.reverse()
        advantages.extend(local)
        targets.extend(a + item.old_value for a, item in zip(local, episode))
    device = next(model.parameters()).device
    advantage = torch.tensor(advantages, dtype=torch.float32, device=device)
    advantage = (advantage - advantage.mean()) / (advantage.std(unbiased=False) + 1e-6)
    target = torch.tensor(targets, dtype=torch.float32, device=device)
    new_log_probs, old_log_probs, values, entropies, gates = [], [], [], [], []
    for episode in episodes:
        state = model.initial_state(device=device)
        for item in episode:
            observation = item.observation.to(device).reshape(1, OBS_SIZE)
            actions = item.actions.to(device).reshape(1, len(ACTION_WIDTHS))
            result, state = model.forward_step(observation, state, actions=actions)
            executed = item.executed_heads.to(device).to(torch.float32)
            new_log_probs.append((result.log_probs[0] * executed).sum())
            old_log_probs.append((item.old_log_probs.to(device) * executed).sum())
            entropies.append((result.entropies[0] * executed).sum()
                             / executed.sum().clamp_min(1))
            values.append(result.value[0])
            gates.append(result.gate[0])
    ratio = (torch.stack(new_log_probs) - torch.stack(old_log_probs)).exp()
    policy = -torch.minimum(ratio * advantage,
                            ratio.clamp(1 - clip, 1 + clip) * advantage).mean()
    value = (torch.stack(values) - target).square().mean()
    entropy = torch.stack(entropies).mean()
    gate_values = torch.stack(gates)
    balance = (gate_values.mean(dim=0) - model.fixed_gate).square().mean()
    specialization = (gate_values * (1 - gate_values)).mean()
    gate_penalty = gate_warmup * (.01 * balance + .001 * specialization)
    loss = policy + value_coef * value - entropy_coef * entropy + gate_penalty
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    optimizer.step()
    return {"loss": float(loss.detach()), "policy": float(policy.detach()),
            "value": float(value.detach()), "entropy": float(entropy.detach()),
            "gate_balance": float(balance.detach()),
            "gate_mean": [float(x) for x in gate_values.mean(dim=0).detach()]}


def save_checkpoint(path, model, optimizer, metadata):
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    torch.save({"format": 1, "metadata": metadata, "model": model.state_dict(),
                "optimizer": optimizer.state_dict()}, temporary)
    os.replace(temporary, destination)
