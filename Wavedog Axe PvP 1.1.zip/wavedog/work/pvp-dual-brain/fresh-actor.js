import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { Worker } from 'node:worker_threads'
import readline from 'node:readline'
import {hybridLegalMasks as legalMasks}from './hybrid-action-masks.js'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE, maskActionLogits,
  biasedActionLogits } from './fresh-policy.js'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { RolloutJournal } from './rollout-journal.js'
import { meleeApproachFeedback, meleeEntryContext, meleeTechniqueGoal } from './fresh-melee-progress.js'
import { conditionTechniqueObservation } from './technique-conditioning.js'
import { LatestObservationQueue, applyDefaultGoal } from './fresh-inference-queue.js'
import { PolicySnapshots } from './policy-snapshots.js'
import { publicHealthFeatures } from './public-health-features.js'
import { warmPolicy } from './policy-warmup.js'

await tf.setBackend('cpu')
await tf.ready()
const checkpointPath = path.resolve(process.argv[2] || '')
const project = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\//, '')),
  '../pvp-player-client')
const server = path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server')
const classpath = [path.join(project, 'bridge-classes'),
  path.resolve(project, '../pvp-neural-lab/classes'),
  path.join(server, 'versions/1.21.1/paper-1.21.1.jar'),
  path.join(server, 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')]
  .join(path.delimiter)
if (!fs.existsSync(checkpointPath)) throw Error(`Missing dual checkpoint: ${checkpointPath}`)
// WaveDog is one shared current brain. These are immutable league snapshots:
// they may control a test opponent, but their trajectories never enter PPO.
const historyFolders = new Map([
  ['history-44kk', path.resolve(project, '../pvp-dual-brain/models/history-44kk')],
  ['history-48k', path.resolve(project,
    'new-learning/backups/before-hybrid-wavedog-20261112-122357/work/pvp-player-client/new-learning/models')],
  ['history-53k', path.resolve(project,
    'new-learning/backups/before-shield-handover-20261112-162729')],
  ['history-119k', path.resolve(project,
    'new-learning/backups/before-shared-clones-20261113-170732/models')]
])
for (const [role, folder] of historyFolders)
  if (!fs.existsSync(path.join(folder, 'recurrent-ppo.json')))
    throw Error(`Missing frozen checkpoint ${role}: ${folder}`)
let loaded = loadDualCheckpoint(checkpointPath)
let model = loaded.model
loaded.adam.dispose()
const startupWarmup = warmPolicy(model)
const snapshots = new PolicySnapshots(loaded)
const journal = new RolloutJournal(path.join(path.dirname(checkpointPath), 'rollouts'),
  loaded.counters.lastRolloutSeq || 0)
const qwenLessons = path.join(path.dirname(checkpointPath), 'coach', 'shared-lessons.jsonl')
function latestQwenFocus () {
  if (!fs.existsSync(qwenLessons)) return null
  const flags = path.join(path.dirname(qwenLessons), 'quality-flags.jsonl')
  const invalid = new Set(fs.existsSync(flags)
    ? fs.readFileSync(flags, 'utf8').split('\n').flatMap(line => {
      try { const row = JSON.parse(line)
        return ['mechanics-invalid', 'review-invalid'].includes(row.status)
          ? [row.matchId] : []
      } catch { return [] }
    }) : [])
  const lines = fs.readFileSync(qwenLessons, 'utf8').trim().split('\n').slice(-8)
  for (const line of lines.reverse()) {
    try {
      const row = JSON.parse(line)
      if (invalid.has(row.matchId) || row.lesson === '可检验的一句话') continue
      const focus = row.focus
      if (['CRITICAL', 'COMBO', 'SHIELD', 'FREE'].includes(focus)) return focus
    } catch {}
  }
  return null
}
const recoveredRollouts = journal.pending(loaded.counters.lastRolloutSeq || 0)
const recoveryPending = new Set(recoveredRollouts.map(row => row.rolloutSeq))
const sidecar = spawn(path.join(server, 'runtime/java21/bin/java.exe'),
  ['-cp', classpath, 'local.wavedog.lab.ProtocolPlayerBridge',
    path.join(path.dirname(checkpointPath), 'observation-cache'), '--observe-only'],
  { cwd: project, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
const histories = new Map([...historyFolders].map(([role, folder]) => [role,
  spawn(path.join(server, 'runtime/java21/bin/java.exe'),
    ['-cp', classpath, 'local.wavedog.lab.ProtocolPlayerBridge', folder],
    { cwd: project, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })]))
const trainer = new Worker(new URL('./fresh-trainer-worker.js', import.meta.url),
  { workerData: { checkpointPath } })
const actors = new Map(), pending = new Map(), historicalPending = new Map()
const observationQueue = new LatestObservationQueue(job => observed(job.message), {
  onDrop: job => pending.delete(job.message.requestId),
  onError: failure => error(failure.stack || failure)
})
let sidecarReady = false, trainerReady = false, ready = false
const historiesReady = new Set()
const FORWARD = [0, 1, -1, 0, 0, 1, 1, -1, -1]
const SIDE = [0, 0, 0, -1, 1, -1, 1, -1, 1]
const SLOT = [7, 0, 1, 4, -1]
function emit (value) { process.stdout.write(JSON.stringify(value) + '\n') }
function error (message) { emit({ event: 'error', message: String(message) }) }
function stateTensors (state) {
  if (!state) return []
  return [state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])]
    .filter(Boolean)
}
function disposeState (state, next = null) {
  const retained = new Set(next ? stateTensors(next) : [])
  for (const tensor of new Set(stateTensors(state)))
    if (!retained.has(tensor)) tensor.dispose()
}
function maybeReady () {
  if (sidecarReady && historiesReady.size === histories.size && trainerReady
      && !recoveryPending.size && !ready) {
    ready = true
    emit({ event: 'ready', model: 'DUAL-GRU-GTRXL',
      architecture: 'GRU64+GTrXL4x256+learned-gate PPO Adam',
      checkpoint: checkpointPath, dualUpdates: loaded.counters.dualUpdates || 0,
      checkpointSha256: loaded.manifest.sha256,
      startupWarmup,
      humanImitationUpdates: loaded.counters.humanImitationUpdates || 0 })
  }
}
function sample (probabilities) {
  let draw = Math.random()
  for (let action = 0; action < probabilities.length; action++) {
    draw -= probabilities[action]
    if (draw <= 0) return action
  }
  return probabilities.length - 1
}
function decode (req, actions) {
  const hand = actions[4]
  return { model: 'DUAL-GRU-GTRXL', fighter: req.fighter,
    opponent: req.opponent, requestId: req.requestId,
    decidedTick: req.tick, focus: req.focus,
    yaw: req.yaw, pitch: req.pitch,
    forward: FORWARD[actions[0]], side: SIDE[actions[0]],
    sprint: actions[1] === 1, jump: actions[2] === 1,
    sneak: actions[3] === 1, shield: false,
    attack: hand === 2, slot: SLOT[actions[5]] < 0
      ? (req.self?.held ?? 7) : SLOT[actions[5]],
    use: false, release: false,
    observedArrows: req.seen?.arrows?.length || 0 }
}
function observed (message) {
  const req = pending.get(message.requestId)
  pending.delete(message.requestId)
  const actor = actors.get(message.fighter)
  if (!req || !actor || actor.opponent !== message.opponent || actor.matchId !== req.matchId
      || req.tick <= (actor.lastObservedTick ?? -Infinity)
      || req.fighter !== message.fighter) return
  if (!Array.isArray(message.observation)
      || message.observation.length !== OBS_SIZE)
    throw Error('Public observation shape mismatch')
  // The named bout focus and its two weak method cues reach both policy
  // branches through the same 98 public input values used in PPO replay.
  const prior = actor.previousPublic
  const context = meleeEntryContext(prior, req, actor.previousContext)
  context.distributionVersion = actor.policy.model.config.distributionVersion || 1
  context.weaponConditionedAttack = actor.policy.model.config.weaponConditionedAttack || 0
  if (context.distributionVersion >= 3) context.calibratedHeads = actor.policy.model.config.calibratedHeads || [2, 5]
  const { focus, techniqueCues } = meleeTechniqueGoal(req, context)
  const conditioned = conditionTechniqueObservation(message.observation,
    focus, techniqueCues, req.arenaBounds ? { self: req.self, bounds: req.arenaBounds } : null,
    req.publicTerrain ? { ...req.publicTerrain, selfY: req.self?.y } : null)
  if (prior) {
    const priorFrame = actor.byTick.get(prior.tick)
    if (priorFrame) priorFrame.reward += meleeApproachFeedback(prior, req)
  }
  actor.previousPublic = req
  actor.previousContext = context
  actor.lastObservedTick = req.tick
  const previous = actor.state
  const masks = legalMasks(req)
  const healthFeatures = publicHealthFeatures(req)
  const policyStart = performance.now()
  const slowRefresh = !previous.slow || previous.frames % actor.policy.model.config.interval === 0
  const outcome = tf.tidy(() => {
    const observation = tf.tensor2d([conditioned], [1, OBS_SIZE])
    const output = actor.policy.model.step(observation, previous, masks, healthFeatures)
    const biased = biasedActionLogits(output.logits, conditioned, context)
    const masked = maskActionLogits(biased, masks)
    const probabilities = masked.map(head => [...tf.softmax(head).dataSync()])
    const actions = probabilities.map(sample)
    if ([1, 2].includes(context.weaponConditionedAttack)) {
      const conditional = maskActionLogits(biasedActionLogits(output.logits,
        conditioned, context, actions, actor.policy.model, healthFeatures), masks)
      probabilities[4] = [...tf.softmax(conditional[4]).dataSync()]
      actions[4] = sample(probabilities[4])
    }
    return { state: output.state, actions, probabilities,
      oldHeadLogProbs: probabilities.map((head, index) =>
        Math.log(Math.max(1e-30, head[actions[index]]))),
      oldValue: output.value.dataSync()[0],
      gate: [...output.gate.dataSync()] }
  })
  actor.state = outcome.state
  disposeState(previous, actor.state)
  const frame = { observation: conditioned, publicHealthFeatures: healthFeatures, actions: outcome.actions,
    checkpointSha256: actor.policy.manifest.sha256,
    context,
    tacticalGoal: { requestedFocus: req.focus, effectiveFocus: focus, techniqueCues },
    oldHeadLogProbs: outcome.oldHeadLogProbs,
    oldHeadProbabilities: outcome.probabilities,
    oldValue: outcome.oldValue, reward: 0, done: false,
    executedHeads: ACTION_WIDTHS.map(() => false), legalMasks: masks,
    decidedTick: req.tick }
  if (req.trainingScope === 'fresh_dual_sword_axe_unshielded'
      && actor.previousSneak !== null && actor.previousSneak !== undefined
      && actor.previousSneak !== Boolean(outcome.actions[3]))
    frame.reward -= .008
  actor.frames.push(frame)
  actor.byTick.set(req.tick, frame)
  actor.previousSneak = Boolean(outcome.actions[3])
  actor.gateSum += outcome.gate.reduce((sum, weight) => sum + weight, 0)
  actor.gateCount += outcome.gate.length
  emit({ ...decode(req, outcome.actions), tacticalFocus: focus,
    inferenceTiming: { slowRefresh, policyMs: performance.now() - policyStart,
      observationBridgeMs: req.observationReturnedAt - req.receivedAt,
      dispatchWaitMs: policyStart - req.observationReturnedAt },
    checkpointSha256: actor.policy.manifest.sha256,
    humanImitationUpdates: actor.policy.counters.humanImitationUpdates || 0,
    edgeComboRisk: context.edgeComboRisk, fallingMeleeThreat: context.fallingMeleeThreat,
    shieldRushThreat:context.shieldRushThreat,shieldRushRetreatWindow:context.shieldRushRetreatWindow,
    punishmentWindowClosing: context.punishmentWindowClosing,
    opponentVerticalPhase: context.opponentVerticalPhase,
    swordComboPressure: context.swordComboPressure, jumpResetTrial: context.jumpResetTrial })
}
function handleSidecar (message) {
  if (message.event === 'ready') {
    if (message.architecture !== 'PUBLIC-OBS-98')
      throw Error(`Unexpected Java observation bridge: ${message.architecture}`)
    sidecarReady = true; maybeReady(); return
  }
  if (message.model === 'DUAL-OBS') {
    const req = pending.get(message.requestId)
    if (req) req.observationReturnedAt = performance.now()
    if (req) observationQueue.push(req.fighter, { message, matchId: req.matchId, tick: req.tick,
      priority: req.trainingScope !== 'fresh_dual_sword_axe_unshielded' })
    return
  }
  if (message.event === 'error') error(`observation bridge: ${message.message}`)
}
function handleHistory (role, message) {
  if (message.event === 'ready') {
    if (message.architecture !== 'GRU64-PPO')
      throw Error(`Unexpected historical bridge: ${message.architecture}`)
    historiesReady.add(role); maybeReady(); return
  }
  if (message.model === 'GRU64-PPO') {
    const actor = actors.get(message.fighter)
    const req = historicalPending.get(message.requestId)
    historicalPending.delete(message.requestId)
    if (actor?.role === role && actor.opponent === message.opponent
        && req?.fighter === message.fighter) {
      const available = message.slot === 1 ? req.self?.hasBow
        : message.slot === 4 ? req.self?.hasCrossbow : true
      emit({ ...message, leagueRole: role,
        shield: Boolean(message.shield && req.self?.shieldAvailable),
        slot: available ? message.slot : 7,
        use: available ? message.use : false,
        release: available ? message.release : false })
    }
    return
  }
  if (message.event === 'error') error(`historical bridge: ${message.message}`)
}
function handleTrainer (message) {
  if (message.event === 'trainer_ready') {
    trainerReady = true
    for (const row of recoveredRollouts) trainer.postMessage(row)
    maybeReady(); return
  }
  if (message.event === 'training_error') { emit(message); return }
  if (message.event !== 'trained' && message.event !== 'trained_partial') return
  const refreshed = loadDualCheckpoint(checkpointPath)
  model = refreshed.model
  refreshed.adam.dispose()
  loaded = refreshed
  snapshots.publish(refreshed)
  recoveryPending.delete(message.rolloutSeq)
  emit(message)
  maybeReady()
}
readline.createInterface({ input: sidecar.stdout }).on('line', line => {
  try { handleSidecar(JSON.parse(line)) } catch (failure) { error(failure.stack || failure) }
})
sidecar.stderr.on('data', data => process.stderr.write(data))
sidecar.on('exit', code => { error(`Observation bridge exited ${code}`); process.exit(1) })
for (const [role, history] of histories) {
  readline.createInterface({ input: history.stdout }).on('line', line => {
    try { handleHistory(role, JSON.parse(line)) } catch (failure) { error(failure.stack || failure) }
  })
  history.stderr.on('data', data => process.stderr.write(data))
  history.on('exit', code => { error(`${role} bridge exited ${code}`); process.exit(1) })
}
trainer.on('message', message => {
  try { handleTrainer(message) } catch (failure) { error(failure.stack || failure) }
})
trainer.on('error', failure => { error(failure.stack || failure); process.exit(1) })
trainer.on('exit', code => { if (code) { error(`Trainer exited ${code}`); process.exit(1) } })

readline.createInterface({ input: process.stdin }).on('line', line => {
  try {
    const req = JSON.parse(line)
    const actor = actors.get(req.fighter)
    switch (req.command) {
      case 'model_status':
        emit({ event: 'model_status', requestId: req.requestId,
          checkpointSha256: loaded.manifest.sha256,
          counters: loaded.counters, ready,
          actors: [...actors].map(([fighter, state]) => ({ fighter,
            policySha256: state.policy?.manifest.sha256,
            frames: state.frames.length,
            executedFrames: state.frames.filter(frame => frame.executedHeads.some(Boolean)).length })) })
        break
      case 'discard':
        if (actor?.frames.some(frame => frame.executedHeads.some(Boolean)))
          throw Error('Cannot discard executed real actions; finish and preserve the bout')
        observationQueue.clearFighter(req.fighter)
        if (actor?.state) disposeState(actor.state)
        if (actor?.policy) snapshots.release(actor.matchId)
        actors.delete(req.fighter)
        emit({ event: 'discarded_probe', fighter: req.fighter })
        break
      case 'reset': {
        if (actor?.frames.some(frame => frame.executedHeads.some(Boolean)))
          throw Error('Cannot reset an executed bout before its trajectory is saved')
        observationQueue.clearFighter(req.fighter)
        if (actor) disposeState(actor.state)
        if (actor?.policy) snapshots.release(actor.matchId)
        // Legacy idle cleanup has no opponent/match ID. It releases an empty
        // observer, rather than creating a policy lease for a non-existent bout.
        if (!req.matchId && req.opponent === '') {
          actors.delete(req.fighter)
          emit({ event: 'discarded_probe', fighter: req.fighter }); break
        }
        const role = historyFolders.has(req.role) || req.role === 'wavejerry-critical-exploiter'
          ? req.role : 'current'
        const policy = role === 'current' ? snapshots.acquire(req.matchId) : null
        actors.set(req.fighter, { opponent: req.opponent, policy,
          matchId: req.matchId, role,
          focus: req.focus || latestQwenFocus(),
          state: role === 'current' ? policy.model.initialState() : null,
          frames: [], byTick: new Map(),
          gateSum: 0, gateCount: 0 })
        if (role !== 'wavejerry-critical-exploiter') {
          const destination = histories.get(role) || sidecar
          destination.stdin.write(JSON.stringify({ ...req, learning: false }) + '\n')
        }
        break
      }
      case 'act':
        req.receivedAt = performance.now()
        if (!actor || actor.opponent !== req.opponent
            || actor.matchId !== req.matchId)
          throw Error('Missing or changed named opponent')
        applyDefaultGoal(req, actor.focus)
        if (actor.role === 'wavejerry-critical-exploiter') {
          import('./human-critical-exploiter.js').then(({ criticalExploiterAction }) => {
            if (actors.get(req.fighter) !== actor || req.tick <= (actor.lastScriptTick ?? -1)) return
            const result = criticalExploiterAction(req, actor.exploiterState)
            actor.exploiterState = result.state; actor.lastScriptTick = req.tick
            emit({ ...result.action, model: 'DUAL-GRU-GTRXL', fighter: req.fighter,
              opponent: req.opponent, requestId: req.requestId, decidedTick: req.tick,
              policyRole: actor.role, scriptedOpponent: true, focus: 'CRITICAL' })
          }).catch(failure => error(failure.stack || failure))
          break
        }
        if (historyFolders.has(actor.role)) {
          historicalPending.set(req.requestId, req)
          histories.get(actor.role).stdin.write(JSON.stringify(req) + '\n')
        } else {
          pending.set(req.requestId, req)
          sidecar.stdin.write(JSON.stringify(req) + '\n')
        }
        break
      case 'executed': {
        const frame = actor?.byTick.get(req.decidedTick)
        if (frame) frame.executedHeads = ACTION_WIDTHS.map((_, index) =>
          index < 6 && !req.ignoredHeads.includes(index))
        break
      }
      case 'native_step': {
        const frame = actor?.byTick.get(req.decidedTick)
        if (frame && Number.isFinite(req.reward)) frame.reward += req.reward
        break
      }
      case 'feedback': {
        const frame = actor?.frames.at(-1)
        if (frame) frame.reward += ((req.dealt || 0) - (req.received || 0)) / 20
        break
      }
      case 'finish':
      case 'partial': {
        if (!actor || actor.matchId !== req.matchId)
          throw Error('Missing or changed match to train')
        observationQueue.clearFighter(req.fighter)
        if (historyFolders.has(actor.role) || actor.role === 'wavejerry-critical-exploiter') {
          emit({ event: 'history_finished', fighter: req.fighter, round: req.round,
            role: actor.role,
            checkpoint: historyFolders.has(actor.role)
              ? path.join(historyFolders.get(actor.role), 'recurrent-ppo.json') : null,
            scriptedOpponent: actor.role === 'wavejerry-critical-exploiter',
            frozen: true })
          actors.delete(req.fighter)
          break
        }
        const frames = actor.frames
        emit({ event: 'inference_queue', fighter: req.fighter, matchId: req.matchId,
          ...observationQueue.stats, frames: frames.length,
          edgeRiskFrames: frames.filter(frame => frame.context?.edgeComboRisk).length })
        if (!frames.length) throw Error('Fighter has no rollout frames')
        const terminal = req.command === 'finish'
          ? (req.win ? 1 + Math.max(0, req.health || 0) / 40 : -1) : 0
        if (terminal) {
          const shared = .4 * terminal / frames.length
          for (const frame of frames) frame.reward += shared
          frames.at(-1).reward += .6 * terminal
        }
        try {
          const durable = journal.append({ episode: frames, fighter: req.fighter,
            round: req.round, partial: req.command === 'partial',
            requestId: req.requestId || `${req.fighter}:${req.round}:${req.command}` })
          trainer.postMessage(durable)
        } catch (failure) {
          emit({ event: 'training_error', fighter: req.fighter, round: req.round,
            error: `PPO journal write failed: ${failure.stack || failure}` })
          break
        }
        disposeState(actor.state)
        snapshots.release(actor.matchId)
        actors.delete(req.fighter)
        break
      }
      case 'close':
        sidecar.stdin.end()
        for (const history of histories.values()) history.stdin.end()
        trainer.terminate(); process.exit(0)
        break
      default: throw Error(`Unknown bridge command: ${req.command}`)
    }
  } catch (failure) { error(failure.stack || failure) }
})
