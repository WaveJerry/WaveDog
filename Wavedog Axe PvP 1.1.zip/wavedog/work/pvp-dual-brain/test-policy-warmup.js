import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE } from './fresh-policy.js'
import { warmPolicy } from './policy-warmup.js'

await tf.setBackend('cpu'); await tf.ready()
for (const adapter of [false, true]) {
  const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 1,
    ff: 24, interval: 2, memory: 4,
    ...(adapter ? { publicHealthInputs: 5, actionContextHeads: [2, 5, 4],
      distributionVersion: 3, weaponConditionedAttack: 2,
      calibratedHeads: [2, 4, 5], attackContextFeatures: [1, 12, 97] } : {}) })
  const before = model.params.map(p => [...p.dataSync()])
  const replay = () => tf.tidy(() => {
    const output = model.step(tf.ones([1, OBS_SIZE]), null)
    return output.logits.map(x => [...x.dataSync()])
  })
  const expected = replay(), tensorCount = tf.memory().numTensors
  const result = warmPolicy(model)
  assert.equal(result.frames, 5)
  assert.equal(tf.memory().numTensors, tensorCount, 'Private warmup state leaked')
  model.params.forEach((p, i) => assert.deepEqual([...p.dataSync()], before[i]))
  assert.deepEqual(replay(), expected, 'Warmup contaminated the next bout state')
  model.dispose()
}
console.log('POLICY_WARMUP_PASS: no weight changes, no state leak, unchanged fresh-bout outputs')
