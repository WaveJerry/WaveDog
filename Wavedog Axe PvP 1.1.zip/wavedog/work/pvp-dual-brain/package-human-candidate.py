"""Package actual trained weights, provenance, source, and truthful live status."""
from pathlib import Path
from datetime import datetime
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
STATUS = BASE / 'runtime/pvp-technique-20261115'
CANDIDATE = STATUS / 'imitation/candidate-20261115-a'
manifest = json.loads((CANDIDATE / 'checkpoint.json').read_text())
files = [BASE / name for name in ('fresh-policy.js', 'fresh-melee-progress.js', 'fresh-actor.js',
    'fresh-optimizer-checkpoint.js', 'human-imitation.js', 'test-human-imitation.js',
    'audit-imitation-retention.js', 'snapshot-for-imitation.py', 'install-human-candidate.py', 'publish-trained-lesson.py')]
files += [STATUS / '当前安装状态.md', STATUS / 'PVP-交接说明.md', STATUS / '玩家执行端迁移要求.md',
    STATUS / 'imitation/dataset.json', STATUS / 'imitation/20261115-162105-install-receipt.json']
files += [CANDIDATE / name for name in ('checkpoint.json', manifest['binary'], 'receipt.json', 'retention.json', 'training-events.jsonl', 'shared-coach-lesson.json')]
files += [ROOT / 'work/pvp-frame-recorder/prepare_imitation.py']
files += sorted((ROOT / 'work/wavedog-command').glob('*.py'))
files += [ROOT / 'work/wavedog-command' / name for name in ('plugin.yml', 'WaveDogCommand.jar',
    'install-receipt.json', 'src/local/wavedog/command/WaveDogCommandPlugin.java')]
payload = {file.relative_to(ROOT).as_posix(): file.read_bytes() for file in files}
receipt = {'at': datetime.now().astimezone().isoformat(), 'trainedWeightsIncluded': True,
    'modelServiceLoaded': True, 'gameWaveDogConnected': False, 'commandPluginInstalled': True,
    'checkpointSha256': manifest['sha256'],
    'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in payload.items()]}
payload['artifact-manifest.json'] = json.dumps(receipt, ensure_ascii=False, indent=2).encode('utf-8')
output = ROOT / 'outputs/PvP-Transformer-human-trained-20261115.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in payload.items(): archive.writestr(name, data)
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    for name, data in payload.items(): assert archive.read(name) == data, name
print(json.dumps({'path': str(output), 'bytes': output.stat().st_size,
    'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'gameWaveDogConnected': False}, ensure_ascii=False))
