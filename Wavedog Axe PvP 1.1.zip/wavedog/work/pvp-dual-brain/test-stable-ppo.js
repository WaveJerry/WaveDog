import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE, ACTION_WIDTHS, computeGAE } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { completeRolloutUpdate, replayPolicyHealth, releaseState, rolloutHealth } from './stable-ppo.js'

await tf.setBackend('cpu'); await tf.ready()
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 1,
  ff: 24, interval: 2, memory: 4, distributionVersion: 2 })
const adam = new SharedAdam(model.params, { learningRate: .00003 })
const raw = []; let state = model.initialState()
for (let tick = 0; tick < 67; tick++) {
  const observation = Array.from({ length: OBS_SIZE }, (_, i) => .1 * Math.sin(tick*.2+i))
  const previous = state
  const output = tf.tidy(() => {
    const r = model.step(tf.tensor2d([observation]), state)
    return { state: r.state, value: r.value.dataSync()[0],
      p: r.logits.map(h => [...tf.softmax(h).dataSync()]) }
  })
  state = output.state; releaseState(previous, state)
  const actions = ACTION_WIDTHS.map((width, h) => (tick+h)%width)
  raw.push({ observation, actions, oldHeadLogProbs: output.p.map((p,h) => Math.log(p[actions[h]])),
    oldHeadProbabilities: output.p, context: { distributionVersion: 2 },
    oldValue: output.value, checkpointSha256: 'same',
    reward: tick === 66 ? 1 : Math.sin(tick)*.01, done: tick === 66,
    executedHeads: ACTION_WIDTHS.map(() => true) })
}
releaseState(state)
assert(rolloutHealth(raw).passed)
const mechanicalOnly=raw.map(frame=>({...frame,executedHeads:Array(9).fill(false)}))
assert(rolloutHealth(mechanicalOnly).reasons.includes('no-model-owned-actions'),
  'pure mechanical observation must never update PPO weights or Adam')
assert(rolloutHealth([{ ...raw[0], checkpointSha256: 'a' }, { ...raw[1], checkpointSha256: 'b' }])
  .reasons.includes('weights-changed-within-bout'))
const noAttack = Array.from({ length: 50 }, () => {
  const observation = Array(OBS_SIZE).fill(0); observation[31] = 1; observation[1] = 1
  return { ...raw[0], observation, actions: Array(9).fill(0) }
})
assert(rolloutHealth(noAttack).reasons.includes('prolonged-legal-melee-with-zero-attacks'))
assert(replayPolicyHealth(model, raw).maxMeanHeadKL < 1e-6)
const count = tf.memory().numTensors
const updated = completeRolloutUpdate(model, adam, computeGAE([raw])[0])
assert.equal(updated.trainedFrames, 67, 'no frame discarded at TBPTT boundaries')
assert.equal(updated.windows, 3)
assert.equal(updated.optimizerSteps, 1)
assert.equal(adam.steps, 1, 'long bouts apply one accumulated Adam step')
assert(Number.isFinite(updated.loss) && updated.gradientNorm > 0)
assert.equal(tf.memory().numTensors, count, 'all window gradients/states released')
assert(replayPolicyHealth(model, raw).maxMeanHeadKL < .03)
adam.dispose(); model.dispose()
console.log(JSON.stringify({ result: 'STABLE_FULL_ROLLOUT_PASS', frames: 67, windows: 3, optimizerSteps: 1 }))
