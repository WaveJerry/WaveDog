import fs from 'node:fs'
import zlib from 'node:zlib'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import {loadDualCheckpoint} from './fresh-optimizer-checkpoint.js'
import {biasedActionLogits,maskActionLogits} from './fresh-policy.js'
import {advance,disposeState} from './human-imitation.js'
const [rollout,destination,...checkpoints]=process.argv.slice(2)
await tf.setBackend('cpu');await tf.ready()
const trace=JSON.parse(zlib.gunzipSync(fs.readFileSync(rollout)))
const report={rollout,caveat:'Recorded public observations replayed in order; combat performance requires server evaluation.',models:[]}
for(const file of checkpoints){
  const loaded=loadDualCheckpoint(file),groups={};let state=loaded.model.initialState()
  loaded.adam.dispose()
  try{
    for(const f of trace.episode){
      const output=advance(loaded.model,state,f.observation,true,f.legalMasks);state=output.state
      const p=tf.tidy(()=>maskActionLogits(biasedActionLogits(output.logits.map(h=>tf.tensor2d([h])),
        f.observation,{...f.context,distributionVersion:loaded.model.config.distributionVersion||1},f.actions),f.legalMasks)
        .map(h=>[...tf.softmax(h).dataSync()]))
      if(!f.executedHeads[0])continue
      const x=f.observation,keys=['neural']
      if(x[31]>.5&&x[97]<=0&&x[1]>=.9&&x[8]<.5&&x[23]<.5)keys.push(x[12]<.25?'chargedSword':'chargedAxe')
      if(x[97]>.12)keys.push('outOfReach')
      if(x[1]<.5)keys.push('lowCharge')
      for(const key of keys){const g=groups[key]||={frames:0,attack:0,sword:0,jump:0};
        g.frames++;g.attack+=p[4][2];g.sword+=p[5][1];g.jump+=p[2][1]}
    }
    for(const g of Object.values(groups))for(const k of ['attack','sword','jump'])g[k]/=g.frames
    const row={file,sha256:loaded.manifest.sha256,updates:loaded.counters.dualUpdates,groups}
    report.models.push(row);console.log(JSON.stringify(row))
  }finally{disposeState(state);loaded.model.dispose()}
}
fs.mkdirSync(path.dirname(path.resolve(destination)),{recursive:true})
fs.writeFileSync(destination,JSON.stringify(report,null,2))
