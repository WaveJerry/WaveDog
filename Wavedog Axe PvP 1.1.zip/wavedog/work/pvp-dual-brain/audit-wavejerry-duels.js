// Offline causal probes only. Never connects to Minecraft or publishes weights.
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'

const [destination, checkpoint, ...files] = process.argv.slice(2)
if (!destination || !checkpoint || !files.length) throw Error('output checkpoint rollout... required')
await tf.setBackend('cpu'); await tf.ready()
const { model, adam, manifest } = loadDualCheckpoint(checkpoint)
adam.dispose()
const tensors = s => s ? [s.fast, s.slow, ...s.pending,
  ...s.caches.flatMap(c => c ? [c.key, c.value] : [])].filter(Boolean) : []
function dispose (s, next) {
  const kept = new Set(tensors(next))
  for (const t of new Set(tensors(s))) if (!kept.has(t)) t.dispose()
}
const result = { at: new Date().toISOString(), checkpoint: path.resolve(checkpoint),
  checkpointSha256: manifest.sha256,
  caveat: 'Replays use the post-match current checkpoint. Original sampled probabilities are retained separately; these probes are not a reconstruction of retired weights or a measured win rate.',
  weightsChanged: false, gameInputsSent: false, rollouts: [] }
try {
  for (const file of files) {
    const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    const variants = rollout.fighter === 'WaveDog' ? ['sequential', 'reset-at-model-entry'] : ['sequential']
    for (const variant of variants) {
      let state = null, priorExecuted = false
      const groups = {}, examples = []
      function add (name, r, f) {
        const g = groups[name] ||= { n: 0, attackProbability: 0, movementForwardProbability: 0,
          movementSideProbability: 0, jumpProbability: 0, sprintProbability: 0,
          rawWaitAttackGap: 0, fastWaitAttackGap: 0, slowWaitAttackGap: 0,
          attackGate: 0, movementGate: 0, slowAbsMax: 0 }
        g.n++
        for (const k of Object.keys(g)) if (k !== 'n') g[k] += r[k]
      }
      try {
        for (const f of rollout.episode) {
          const executed = f.executedHeads[0]
          if (variant === 'reset-at-model-entry' && executed && !priorExecuted) {
            dispose(state); state = null
          }
          priorExecuted = executed
          const old = state
          const r = tf.tidy(() => {
            const output = model.step(tf.tensor2d([f.observation]), state, f.legalMasks, f.publicHealthFeatures)
            const biased = biasedActionLogits(output.logits, f.observation,
              { ...f.context, distributionVersion: model.config.distributionVersion || 1 }, f.actions)
            const p = maskActionLogits(biased, f.legalMasks).map(h => [...tf.softmax(h).dataSync()])
            const raw = [...output.logits[4].dataSync()]
            const fast = [...model.fastHeads[4].apply(output.state.fast).dataSync()]
            const slow = [...model.slowHeads[4].apply(output.state.slow).dataSync()]
            const gate = [...output.gate.dataSync()]
            return { state: output.state, attackProbability: p[4][2],
              movementForwardProbability: p[0][1],
              movementSideProbability: p[0][3] + p[0][4] + p[0][5] + p[0][6] + p[0][7] + p[0][8],
              jumpProbability: p[2][1], sprintProbability: p[1][1],
              rawWaitAttackGap: raw[0] - raw[2], fastWaitAttackGap: fast[0] - fast[2],
              slowWaitAttackGap: slow[0] - slow[2], attackGate: gate[4], movementGate: gate[0],
              slowAbsMax: Math.max(...[...output.state.slow.dataSync()].map(Math.abs)) }
          })
          state = r.state; dispose(old, state); delete r.state
          if (!executed) continue
          add('modelExecuted', r, f)
          if (f.observation[97] <= 0 && f.observation[8] < .5 && f.observation[23] < .5) {
            add('inReach', r, f)
            if (f.observation[1] >= .85) {
              add('chargedInReach', r, f)
              add(f.observation[12] < .25 ? 'chargedSwordInReach' : 'chargedAxeInReach', r, f)
              if (examples.length < 5) examples.push({ tick: f.decidedTick, observation: f.observation,
                originalAction: f.actions, originalSelectedProbability: Math.exp(f.oldHeadLogProbs[4]), ...r })
            }
          }
        }
      } finally { dispose(state) }
      for (const g of Object.values(groups)) for (const k of Object.keys(g)) if (k !== 'n') g[k] /= g.n
      result.rollouts.push({ rolloutSeq: rollout.rolloutSeq, fighter: rollout.fighter,
        originalCheckpoint: rollout.episode[0].checkpointSha256, variant, groups, examples })
      console.log(JSON.stringify({ rollout: rollout.rolloutSeq, variant, groups }))
    }
  }
  fs.mkdirSync(path.dirname(path.resolve(destination)), { recursive: true })
  fs.writeFileSync(destination, JSON.stringify(result, null, 2))
} finally { model.dispose() }
