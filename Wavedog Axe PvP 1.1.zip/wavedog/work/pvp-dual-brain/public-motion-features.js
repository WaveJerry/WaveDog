export const PUBLIC_MOTION_SIZE=32
// Missing data stays unknown (first feature = 0). Predictions retain source
// revision/age and never impersonate newly received position packets.
export function publicMotionFeatures(req={}){
  const p=req.publicMotionAnalysis
  const zero=()=>Array(PUBLIC_MOTION_SIZE).fill(0)
  if(!p||p.schema!=='public-motion-v1'||p.matchId!==req.matchId
      ||p.physicalTick!==req.tick||!p.available||!Number.isSafeInteger(p.revision)
      ||!Number.isFinite(p.analyzedAtMs)||!Number.isFinite(p.sourceAtMs)
      ||p.analyzedAtMs<p.sourceAtMs||p.analyzedAtMs-p.sourceAtMs>100)return zero()
  if(!Array.isArray(p.features)||p.features.length!==PUBLIC_MOTION_SIZE
      ||!p.features.every(Number.isFinite))throw Error('Invalid recorded public motion features')
  return [...p.features]
}
