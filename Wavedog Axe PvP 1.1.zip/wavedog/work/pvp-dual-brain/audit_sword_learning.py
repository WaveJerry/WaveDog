"""Read completed shared-model rollouts and native events; never control a bot."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import gzip
import json

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
DEST = ROOT / 'work/wavedog-protocol/runtime/orbit-and-entry'
NATIVE = Path('D:/Walt Disney/Minecraft-1.21.1-Server/plugins/WaveDogSelfPlayGate/bouts.jsonl')


def main():
    deployed = json.loads((DEST / 'sword-cycle-live-receipt.json').read_text())['at']
    traces = []
    for source in sorted((MODEL / 'rollouts').glob('*.json.gz'), key=lambda p: p.stat().st_mtime)[-48:]:
        with gzip.open(source, 'rt', encoding='utf8') as stream:
            row = json.load(stream)
        frames = [f for f in row['episode'] if f['context'].get('entryCurriculum') == 8]
        if not frames:
            continue
        runs, length = [], 0
        for frame in frames:
            if frame['observation'][12] < .25:
                length += 1
            elif length:
                runs.append(length)
                length = 0
        if length:
            runs.append(length)
        traces.append({'sequence': row['rolloutSeq'], 'fighter': row['fighter'],
            'source': source.name, 'frames': len(frames), 'swordRuns': runs,
            'executedSwordAttackChoices': sum(f['observation'][12] < .25 and f['actions'][4] == 2
                and f['executedHeads'][4] for f in frames),
            'executedJumpChoices': sum(f['actions'][2] == 1 and f['executedHeads'][2] for f in frames)})
    reports = {}
    for line in (MODEL / 'coach/rounds.jsonl').read_text(encoding='utf8').splitlines():
        row = json.loads(line)
        if row['at'] >= deployed:
            reports[row['arena'], row['bout']] = row
    # Read a bounded tail. Its first partial line cannot be a full JSON event.
    with NATIVE.open('rb') as stream:
        start = max(0, NATIVE.stat().st_size - 4_000_000)
        stream.seek(start)
        if start:
            stream.readline()
        lines = stream.readlines()
    counts, events, sequences = Counter(), [], []
    previous = {}
    for line in lines:
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        report = reports.get((event.get('arena'), event.get('bout')))
        if not report or event.get('at', '') < deployed or event.get('type') != 'damage':
            continue
        fighter = event.get('attacker')
        if report['fighters'].get(fighter, {}).get('leagueRole') != 'current':
            continue
        if not any(r.get('fighter') == fighter and r.get('event') in ('trained', 'trained_partial')
                   for r in report['training']):
            continue  # A script/historical opponent or an uncommitted bout is not learned evidence.
        if event.get('cancelled') or event.get('amount', 0) <= 0 or event.get('source') != 'MELEE':
            continue
        counts['meleeHits'] += 1
        sword = event.get('weapon') == 'DIAMOND_SWORD'
        critical = bool(event.get('native_critical'))
        counts['swordHits'] += sword
        counts['swordNativeCriticalHits'] += sword and critical
        key = event['arena'], event['bout'], fighter, event['victim']
        prior = previous.get(key)
        if sword and critical:
            events.append(event)
            if prior and prior.get('weapon') == 'DIAMOND_SWORD' and prior.get('native_critical') \
                    and 0 < event['tick'] - prior['tick'] <= 30:
                sequences.append({'arena': key[0], 'bout': key[1], 'fighter': fighter,
                    'ticks': [prior['tick'], event['tick']],
                    'amounts': [prior['amount'], event['amount']],
                    'proof': 'consecutive successful native sword critical hits; not proof of an unanswered combo'})
        previous[key] = event
    result = {'at': datetime.now(timezone.utc).isoformat(), 'deployedAt': deployed,
        'readOnly': True, 'weightsReset': False, 'mechanicalForcedBreak': False,
        'rollouts': traces, 'nativeCounts': dict(counts),
        'nativeSwordCriticalExamples': events[-12:], 'consecutiveSwordCriticalPairs': sequences,
        'limits': ['Action choices and jump poses are not confirmed hits.',
            'Scripted and historical opponents are excluded from learned combat counts.',
            'This is an initial sample, not proof of mastery or superior win rate.',
            'Jump reset requires native hit timing and knockback validation separately.']}
    target = DEST / 'sword-cycle-after.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'rollouts': len(traces), 'swordAttackChoices': sum(r['executedSwordAttackChoices'] for r in traces),
        'longestSwordRun': max((max(r['swordRuns'], default=0) for r in traces), default=0),
        'nativeCounts': dict(counts), 'consecutiveNativeSwordCriticalPairs': len(sequences),
        'output': str(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
