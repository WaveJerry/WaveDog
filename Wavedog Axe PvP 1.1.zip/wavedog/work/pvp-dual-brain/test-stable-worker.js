import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { Worker } from 'node:worker_threads'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, ACTION_WIDTHS, OBS_SIZE } from './fresh-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { releaseState } from './stable-ppo.js'

await tf.setBackend('cpu'); await tf.ready()
const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'stable-ppo-test-'))
const checkpointPath = path.join(folder, 'checkpoint.json')
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 1,
  ff: 24, interval: 2, memory: 4, distributionVersion: 2 })
const adam = new SharedAdam(model.params, { learningRate: .00003 })
const initial = saveDualCheckpoint(checkpointPath, model, adam, { lastRolloutSeq: 0, dualUpdates: 0 })
const episode = []; let state = model.initialState()
for (let tick = 0; tick < 35; tick++) {
  const observation = Array.from({ length: OBS_SIZE }, (_, i) => .05 * Math.sin(tick*.2+i))
  const previous = state
  const out = tf.tidy(() => {
    const r = model.step(tf.tensor2d([observation]), state)
    return { state: r.state, value: r.value.dataSync()[0], p: r.logits.map(h => [...tf.softmax(h).dataSync()]) }
  })
  state = out.state; releaseState(previous, state)
  const actions = ACTION_WIDTHS.map((n,h) => (tick+h)%n)
  episode.push({ observation, actions, oldHeadLogProbs: out.p.map((p,h) => Math.log(p[actions[h]])),
    oldHeadProbabilities: out.p, context: { distributionVersion: 2 }, oldValue: out.value,
    checkpointSha256: 'single-policy', reward: tick === 34 ? 1 : .01*Math.sin(tick),
    done: tick === 34, executedHeads: ACTION_WIDTHS.map(() => true) })
}
releaseState(state); adam.dispose(); model.dispose()
const worker = new Worker(new URL('./fresh-trainer-worker.js', import.meta.url), { workerData: { checkpointPath } })
const inbox = [], waiters = []
worker.on('message', row => { const resolve = waiters.shift(); if (resolve) resolve(row); else inbox.push(row) })
const next = () => inbox.length ? Promise.resolve(inbox.shift()) : new Promise(resolve => waiters.push(resolve))
async function send (seq, data) {
  worker.postMessage({ episode: data, rolloutSeq: seq, fighter: 'test-only', round: seq, partial: false, requestId: seq })
  const reply = await next()
  assert.notEqual(reply.event, 'training_error', reply.error)
  return reply
}
try {
  assert.equal((await next()).event, 'trainer_ready')
  const mixed = structuredClone(episode); mixed[1].checkpointSha256 = 'different'
  const rejected = await send(1, mixed)
  assert.equal(rejected.quarantined, true)
  assert.equal(rejected.sha256, initial.sha256, 'quarantine preserves all weights and Adam')
  const valid = await send(2, episode)
  assert.equal(valid.candidateAccepted, true, JSON.stringify(valid))
  assert.equal(valid.optimizerSteps, 1)
  assert.equal(valid.trained_frames, 35)
  const stale = structuredClone(episode)
  for (const frame of stale) frame.oldHeadProbabilities = ACTION_WIDTHS.map(n => [1, ...Array(n-1).fill(0)])
  const refused = await send(3, stale)
  assert(refused.reasons.includes('stale-behavior-policy'))
  assert.equal(refused.sha256, valid.sha256, 'stale rollout must not alter weights or Adam')
  const restored = loadDualCheckpoint(checkpointPath)
  assert.equal(restored.adam.steps, 1); assert.equal(restored.counters.lastRolloutSeq, 3)
  restored.adam.dispose(); restored.model.dispose()
  assert(fs.existsSync(path.join(folder, 'accepted-before-2.json')), 'pre-update state retained')
  console.log(JSON.stringify({ result: 'STABLE_WORKER_PASS', quarantined: 2, accepted: 1, optimizerSteps: 1 }))
} finally {
  await worker.terminate()
  // Temporary test directory is explicitly verified before recursive removal.
  assert(path.resolve(folder).startsWith(path.resolve(os.tmpdir()) + path.sep))
  fs.rmSync(folder, { recursive: true, force: true })
}
