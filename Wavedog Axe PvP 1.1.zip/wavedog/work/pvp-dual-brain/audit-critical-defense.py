"""Read native evidence and durable PPO journals; never submit old trajectories."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
DEST = MODEL / 'coach/priority-reviews/wavejerry-critical-20261115'
NUMBER = r'(-?[\d.]+(?:E-?\d+)?)'

def frame_parts(detail):
    own, target = detail.split('own={', 1)[1].split(' target={', 1)
    def player(text):
        pos = re.search(r'pos=' + ','.join([NUMBER] * 3), text)
        return {'pos': [float(v) for v in pos.groups()],
                'vy': float(re.search(r'vy=' + NUMBER, text)[1]),
                'ground': 'grounded=true' in text,
                'charge': float(re.search(r'charge=' + NUMBER, text)[1])}
    return player(own), player(target)

def main():
    counters = json.loads((MODEL / 'checkpoint.json').read_text(encoding='utf-8'))['counters']
    report = {'counters': counters, 'bouts': [], 'human_rollouts': []}
    for file in sorted(DEST.glob('*-WaveDog.jsonl')):
        rows = [json.loads(line) for line in file.read_text(encoding='utf-8').splitlines()]
        frames = {r['tick']: r for r in rows if r['type'] == 'FRAME'}
        criticals = [r for r in rows if r['type'] == 'TAKEN' and 'critical=true' in r['detail']]
        evidence = []
        for hit in criticals:
            tick = hit['tick']
            prior = [r for t, r in frames.items() if tick - 4 <= t <= tick]
            nearby = [r for r in rows if abs(r['tick'] - tick) <= 4 and r['type'] in ('DEALT', 'TAKEN')]
            evidence.append({'tick': tick, 'damage': hit['detail'],
                'preceding_frames': [{'tick': r['tick'], 'own': frame_parts(r['detail'])[0],
                                      'opponent': frame_parts(r['detail'])[1]} for r in prior],
                'exchange': nearby})
        report['bouts'].append({'file': file.name, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
            'tick_start': min(frames), 'tick_end': max(frames),
            'critical_hits_taken': len(criticals), 'critical_evidence': evidence})
    for file in sorted((MODEL / 'rollouts').glob('rollout-*.json.gz'))[-260:]:
        with gzip.open(file, 'rt', encoding='utf-8') as stream:
            row = json.load(stream)
        if row.get('fighter') != 'WaveDog':
            continue
        episode = row['episode']
        ticks = [f['decidedTick'] for f in episode]
        report['human_rollouts'].append({
            'file': file.name, 'sequence': row['rolloutSeq'], 'round': row.get('round'),
            'requestId': row.get('requestId'), 'partial': row.get('partial'),
            'tick_start': min(ticks), 'tick_end': max(ticks), 'frames': len(episode),
            'executed_jump_choices': sum(f['actions'][2] == 1 and f['executedHeads'][2] for f in episode),
            'last_reward': episode[-1]['reward'],
            'committed': row['rolloutSeq'] <= counters['lastRolloutSeq']})
    for bout in report['bouts']:
        bout['matching_rollouts'] = [r for r in report['human_rollouts']
            if r['tick_start'] <= bout['tick_end'] and r['tick_end'] >= bout['tick_start']]
    path = DEST / 'native-and-ppo-audit.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'report': str(path), 'counters': counters,
        'bouts': [{k: v for k, v in b.items() if k != 'critical_evidence'} for b in report['bouts']],
        'human_rollout_count': len(report['human_rollouts']),
        'recent_human_rollouts': report['human_rollouts'][-6:]}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
