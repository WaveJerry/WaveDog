"""Persist evidence-based operator/agent teaching without promoting a model."""
from pathlib import Path
from datetime import datetime, timezone
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'outputs/sword-learning-next-20261116'
receipt = json.loads((OUT/'candidate-balanced-b/receipt.json').read_text(encoding='utf-8'))
retention = json.loads((OUT/'candidate-balanced-b/retention.json').read_text(encoding='utf-8'))
loss = json.loads((OUT/'latest-wavejerry-comeback.json').read_text(encoding='utf-8'))
source = 'contact-intent-and-finishing-20261116-v1'
lesson = (
    '冲量破盾的意图是打开无盾窗口并维持接触，用后续剑输出赢整轮，而不只赢破盾那一下。'
    '边缘首击后若已出距，重新控距蓄力；持续贴住且下一次剑周期内仍能接触，比较剑连击、'
    '落地再起跳、真实下落暴击前松疾跑与已有斧首刀价值，不强制斧后必切剑。'
    '对手平地或上升进距可抢断；已下落的暴击要比较避开落点、反打与净换血，不能硬拿平A换暴击。'
    '惩罚暴击需要对方仍在射程与未来可接触，不能亏血也执着等斧头惩罚。'
    '剑遇有效正面盾时学习自主切斧与真实破盾后的续连，禁止恢复机械强制破盾或固定距离后退程序。'
    '残血收割比较当前可造成的有效伤害与目标可观测血量上界，不为无用伤害溢出继续等满蓄力；'
    '同时考虑护甲、吸收、有效盾、伤害免疫窗口、切槽重置与被反杀风险，不等于无脑低蓄力连点。'
    '本服有wd_hearts公开头顶血量，显示分数为ceil(HP)，不代表精确小数；当前协议输入尚未接通，'
    '所以不可把事后裁判记录的敌方血量偷偷作为在线输入，也不可宣称网络已能精确抢残血。'
)
row = {
    'at': datetime.now(timezone.utc).isoformat(), 'source': source,
    'authorship': 'operator guidance and agent analysis of native journals; not a Qwen-generated review',
    'focus': 'COMBO', 'text': lesson, 'lesson': lesson,
    'analysisPath': str(OUT/'高手打法与破局教学.md'),
    'latestCounterexample': loss['matchId'],
    'latestCounterexampleModelOwnedWeaponFrames': loss['modelOwnedWeaponChoices'],
    'latestCounterexampleLateExchange': loss['latePhase'],
    'learningEvidence': {
        'nativeExpertBouts': 18, 'nativeExpertFrames': 6920,
        'imitationUpdates': receipt['imitationOptimizer']['steps'],
        'fastAndSlowParametersChanged': receipt['checks']['changedFast'] and receipt['checks']['changedSlow'],
        'retentionPassed': retention['retentionPassed'],
        'candidateSha256': receipt['saved']['sha256'],
        'liveModelReplaced': False, 'skillsMastered': False, 'qwenWeightsUpdated': False
    },
    'nextAcceptance': ['sustained sword damage', 'native consecutive sword criticals',
        'public health input with uncertainty', 'timely finishing without unnecessary charge waiting',
        'no return of charged in-range inactivity', 'measure stale neutral frames separately']
}
memory = ROOT/'work/pvp-8.6-dual-fresh/model/coach/shared-lessons.jsonl'
existing = memory.read_text(encoding='utf-8').splitlines() if memory.exists() else []
if not any(json.loads(line).get('source') == source for line in existing if line.strip()):
    with memory.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False)+'\n')
(OUT/'shared-coach-lesson.json').write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding='utf-8')
status = {
    'fullPortableBackup': str(ROOT/'outputs/xieyi1'), 'backupReady': True,
    'isolatedCandidate': str(OUT/'candidate-balanced-b/checkpoint.json'),
    'offlineNativeImitationCompleted': True, 'candidateInstalledOnMainServer': False,
    'candidateIsFullServerBundle': False,
    'candidateStillInsufficient': {
        key: item['probability'] for key, item in receipt['after']['validation']['labels'].items()
        if key in ['5:1', '2:1', '1:0']
    },
    'mainLiveCheckpointsPreserved': True, 'qwenSharedTeachingMemoryUpdated': True,
    'mainServerRestarted': False, 'selfplayAutomaticallyResumed': False,
    'opponentPublicHealthIntegrated': False, 'livePvpImprovementClaimed': False
}
(OUT/'STATUS.json').write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(status, ensure_ascii=False))
