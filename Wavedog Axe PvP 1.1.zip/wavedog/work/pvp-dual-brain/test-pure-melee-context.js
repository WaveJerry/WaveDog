import assert from 'node:assert/strict'
import { meleeEntryContext as pure } from './punengbho/fresh-melee-progress.js'
import { meleeEntryContext as hybrid } from './fresh-melee-progress.js'
const base = { tick: 1, matchId: 'pure-melee', opponent: 'target',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62, ground: true, vy: 0,
    shieldAvailable: true, shielding: false, using: false, held: 7, charge: .3, health: 20 },
  seen: { visible: true, x: 0, y: 0, z: 1.8, shield: false, yaw: 180 } }
const middle = { ...base, tick: 2 }, next = { ...base, tick: 3 }
const context = pure(middle, next, pure(base, middle))
assert(context.swordDpsWindow, 'own available shield must not suppress a pure learner sword opportunity')
assert(!hybrid(middle, next, hybrid(base, middle)).swordDpsWindow,
  'the original hybrid keeps its shield-phase ownership boundary')
const shield = { ...next, self: { ...next.self, held: 0 }, seen: { ...next.seen, shield: true } }
assert(pure(middle, shield, context).swordShieldBreakWindow,
  'the pure learner can choose a sword-to-axe shield response while its own shield is available')
for (const flag of ['using', 'shielding']) {
  const result = pure(middle, { ...next, self: { ...next.self, [flag]: true } }, context)
  assert(!result.swordDpsWindow && !result.swordSustainWindow)
}
assert(!pure(middle, { ...next, matchId: 'other' }, context).swordDpsWindow)
console.log(JSON.stringify({ event: 'PURE_MELEE_SHIELD_OWNERSHIP_PASS', hybridUntouched: true }))
