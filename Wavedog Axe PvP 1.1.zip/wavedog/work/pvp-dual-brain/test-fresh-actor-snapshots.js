import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawn } from 'node:child_process'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './fresh-policy.js'
import { SharedAdam, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'

await tf.setBackend('cpu'); await tf.ready()
const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'fresh-snapshot-test-'))
const checkpointPath = path.join(folder, 'checkpoint.json')
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 1,
  ff: 24, interval: 2, memory: 4, distributionVersion: 2 })
const adam = new SharedAdam(model.params, { learningRate: .00003 })
const before = saveDualCheckpoint(checkpointPath, model, adam, { lastRolloutSeq: 0, dualUpdates: 0 })
adam.dispose(); model.dispose()
const actor = spawn(process.execPath, [new URL('./fresh-actor.js', import.meta.url).pathname.replace(/^\/(?=[A-Z]:)/, ''), checkpointPath],
  { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
const messages = []; let waiter = null, error = ''
actor.stderr.on('data', d => { error += d })
readline.createInterface({ input: actor.stdout }).on('line', line => {
  const row = JSON.parse(line)
  if (waiter?.predicate(row)) { const w = waiter; waiter = null; clearTimeout(w.timer); w.resolve(row) }
  else messages.push(row)
})
function send (row) { actor.stdin.write(JSON.stringify(row) + '\n') }
function wait (predicate, timeout = 30000) {
  const i = messages.findIndex(predicate)
  if (i >= 0) return Promise.resolve(messages.splice(i, 1)[0])
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { waiter = null; reject(Error('Fresh actor timeout '+error.slice(-300)+' '+JSON.stringify(messages.slice(-4)))) }, timeout)
    waiter = { predicate, resolve, timer }
  })
}
function request (fighter, tick, matchId = 'same-bout') {
  const requestId = { one: 1000, two: 2000, three: 3000 }[fighter] + tick
  return { command: 'act', fighter, opponent: 'opponent', matchId,
    requestId, tick, focus: 'FREE', style: 'MIXED', yaw: 0, pitch: 0,
    self: { x: 0, y: 221, z: 0, eyeY: 222.62, vx: 0, vy: 0, vz: 0,
      ground: true, charge: 1, health: 20, food: 20, held: 0, shieldAvailable: false,
      shielding: false, using: false, useTicks: 0, arrows: 0 },
    seen: { visible: true, x: 0, y: 221, z: 2.8, yaw: 180,
      held: 'DIAMOND_SWORD', using: false, shield: false, arrows: [] } }
}
try {
  await wait(r => r.event === 'ready')
  for (const fighter of ['one', 'two']) send({ command: 'reset', fighter, opponent: 'opponent', matchId: 'same-bout' })
  for (let tick = 1; tick <= 8; tick++) {
    send(request('one', tick)); const r = await wait(r => r.requestId === 1000+tick)
    assert.equal(r.checkpointSha256, before.sha256)
    send({ command: 'executed', fighter: 'one', decidedTick: tick, ignoredHeads: [6,7,8] })
  }
  send({ command: 'finish', fighter: 'one', matchId: 'same-bout', round: 1, win: true, health: 10 })
  const trained = await wait(r => r.event === 'trained' || r.event === 'training_error')
  assert.equal(trained.candidateAccepted, true, JSON.stringify(trained))
  assert.notEqual(trained.sha256, before.sha256)
  send(request('two', 1)); const old = await wait(r => r.requestId === 2001)
  assert.equal(old.checkpointSha256, before.sha256, 'ongoing actor keeps original weights after another actor trains')
  send({ command: 'reset', fighter: 'three', opponent: 'opponent', matchId: 'new-bout' })
  send(request('three', 1, 'new-bout')); const current = await wait(r => r.requestId === 3001)
  assert.equal(current.checkpointSha256, trained.sha256, 'new bout gets published version')
  for (const fighter of ['two','three']) send({ command: 'discard', fighter })
  send({ command: 'model_status', requestId: 'end' })
  const status = await wait(r => r.requestId === 'end')
  assert.equal(status.actors.length, 0)
  assert(!messages.some(r => r.event === 'error'), JSON.stringify(messages))
  console.log(JSON.stringify({ result: 'FRESH_ACTOR_SNAPSHOTS_PASS', sameBoutWeightsPinned: true,
    newBoutReceivesUpdate: true, mainServerUsed: false }))
} finally {
  send({ command: 'close' }); actor.stdin.end()
  await new Promise(resolve => { actor.once('exit', resolve); setTimeout(resolve, 3000) })
  if (actor.exitCode === null) actor.kill()
  assert(path.resolve(folder).startsWith(path.resolve(os.tmpdir()) + path.sep))
  fs.rmSync(folder, { recursive: true, force: true })
}
