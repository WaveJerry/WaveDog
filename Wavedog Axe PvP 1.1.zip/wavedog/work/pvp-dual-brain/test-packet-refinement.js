import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import {DualPolicy,OBS_SIZE,ACTION_WIDTHS,biasedActionLogits} from './fresh-policy.js'
await tf.setBackend('cpu');await tf.ready()
const model=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:32,interval:2,memory:4})
const obs=Array(OBS_SIZE).fill(0);obs[31]=1;obs[97]=-.1;obs[1]=1
const masks=ACTION_WIDTHS.map(n=>Array(n).fill(true))
const dispose=s=>{for(const t of new Set([s.fast,s.slow,...s.pending,...s.caches.flatMap(c=>c?[c.key,c.value]:[])].filter(Boolean)))t.dispose()}
const initial=model.initialState()
const anchor=tf.tidy(()=>model.step(tf.tensor2d([obs]),initial,masks).state)
dispose(initial)
const before={frames:anchor.frames,fast:[...anchor.fast.dataSync()],slow:[...anchor.slow.dataSync()],
  caches:anchor.caches.map(c=>({key:[...c.key.dataSync()],value:[...c.value.dataSync()]})),pending:[...anchor.pending]}
const baseline=tf.memory().numTensors
let first
for(let i=0;i<500;i++){
  const values=tf.tidy(()=>model.refine(tf.tensor2d([obs]),anchor,masks).logits.map(h=>[...h.dataSync()]))
  if(!first)first=values
  else assert.deepEqual(values,first,'same anchor and same sample give the same prediction')
}
assert.equal(tf.memory().numTensors,baseline,'speculative refinements leak no tensors')
assert.equal(anchor.frames,before.frames)
assert.deepEqual([...anchor.fast.dataSync()],before.fast)
assert.deepEqual([...anchor.slow.dataSync()],before.slow)
assert.deepEqual(anchor.pending,before.pending)
assert.deepEqual(anchor.caches.map(c=>({key:[...c.key.dataSync()],value:[...c.value.dataSync()]})),before.caches)
const changed=[...obs];changed[97]=.5;changed[3]=.3
const after=tf.tidy(()=>model.refine(tf.tensor2d([changed]),anchor,masks).logits.map(h=>[...h.dataSync()]))
assert(after.some((h,i)=>h.some((x,j)=>Math.abs(x-first[i][j])>1e-8)))
tf.tidy(()=>{
  const raw=ACTION_WIDTHS.map(n=>tf.tensor2d([Array.from({length:n},(_,i)=>i)]))
  const policy=biasedActionLogits(raw,obs,{behaviorPriorVersion:0,entryCurriculum:10,
    swordDpsWindow:true,swordSustainWindow:true,edgeComboRisk:true,fallingMeleeThreat:true,jumpResetTrial:true})
  policy.forEach((h,i)=>assert.deepEqual([...h.dataSync()],[...raw[i].dataSync()],
    'whole-fight policy must not inherit handwritten tactical logit overrides'))
})
dispose(anchor);model.dispose()
console.log('PACKET_REFINEMENT_NO_MEMORY_ADVANCE_NO_PRIORS_PASS')
