import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE, ACTION_WIDTHS, biasedActionLogits, maskActionLogits } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { advance, disposeState, imitationUpdate, validateDataset, deployedImitationLogits, imitationClassWeights } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const balancedFrames = [
  ...Array.from({ length: 8 }, () => ({ labels: { 4: 2 } })),
  ...Array.from({ length: 2 }, () => ({ labels: { 4: 0 } })),
  { labels: { 2: 1 }, supervisionWeight: .5 }
]
const balanced = imitationClassWeights({ trajectories: [
  { split: 'train', frames: balancedFrames },
  { split: 'validation', frames: [{ labels: { 2: 1 } }] }
] })
const masses = {}
for (const f of balancedFrames) for (const [head, action] of Object.entries(f.labels))
  masses[head] = (masses[head] || 0) + (f.supervisionWeight ?? 1) * balanced.weights[`${head}:${action}`]
assert(Math.abs(masses[2]-masses[4]) < 1e-9, 'rare native jumps need equal supervised head mass')
assert.equal(balanced.classCounts[2][1], .5, 'validation must not affect training weights')
const frequency = imitationClassWeights({ trajectories: [
  { split: 'train', frames: balancedFrames }
] }, undefined, [4])
assert.equal(frequency.weights['4:0'], frequency.weights['4:2'],
  'per-frame attack labels must preserve observed frequencies')
assert.equal(frequency.weights['2:1'], balanced.weights['2:1'],
  'attack frequency must not change rare jump head balancing')
const attackMass = action => balancedFrames.filter(f => f.labels[4] === action)
  .reduce((sum, f) => sum + (f.supervisionWeight ?? 1) * frequency.weights[`4:${action}`], 0)
assert.equal(attackMass(2) / attackMass(0), 4,
  'empirical 8:2 event frequency must not be flattened to 1:1')
// A charged sword entry and an airborne threat have different live priors.
// Imitation must use exactly those distributions, including legality masks.
for (const fallingMeleeThreat of [false, true]) for (const distributionVersion of [1, 2]) {
  tf.tidy(() => {
    const obs = Array(OBS_SIZE).fill(0)
    obs[1] = 1; obs[31] = 1; obs[97] = -.2
    const context = { entryCurriculum: 10, fallingMeleeThreat, swordSustainWindow: true }
    const masks = ACTION_WIDTHS.map(width => Array(width).fill(true)); masks[4][1] = false
    const logits = ACTION_WIDTHS.map(width => tf.tensor2d([Array.from({ length: width }, (_, i) => i * .2)]))
    const deployed = deployedImitationLogits({ config: { distributionVersion } }, logits,
      { observation: obs, context, legalMasks: masks })
    const expected = maskActionLogits(biasedActionLogits(logits, obs,
      { ...context, distributionVersion }), masks)
    assert.deepEqual(deployed.map(h => [...h.dataSync()]), expected.map(h => [...h.dataSync()]))
    if (distributionVersion === 1 && !fallingMeleeThreat)
      assert(deployed[4].dataSync()[2] > 20, 'must include live charged-entry prior')
    if (distributionVersion === 2)
      assert.equal(deployed[4].dataSync()[2], logits[4].dataSync()[2], 'v2 must not reintroduce old priors')
  })
}
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 2, ff: 32, interval: 2, memory: 4 })
const unrelated = [...model.fastHeads[0].w.dataSync()]
const fastBefore = [...model.fast.candidate.w.dataSync()]
const slowBefore = [...model.slowBlocks[0].ffOut.w.dataSync()]
const optimizer = new SharedAdam([model.fast, model.slowToken, ...model.slowBlocks,
  model.fastHeads[4], model.fastHeads[5], model.slowHeads[4], model.slowHeads[5],
  model.gateIn, model.gateOut].flatMap(layer => layer.params), { learningRate: .0001 })
const observation = Array.from({ length: OBS_SIZE }, (_, i) => Math.sin(i + 1) * .1)
const segment = Array.from({ length: 4 }, (_, tick) => ({ tick,
  observation: observation.map(value => value + tick * .01), labels: tick === 3 ? { 5: 1 } : {} }))
let state = model.initialState()
for (const frame of segment) {
  const output = advance(model, state, frame.observation, true); state = output.state
  frame.reference = { logits: output.logits, value: output.value }
}
disposeState(state)
const initial = model.initialState()
const update = imitationUpdate(model, optimizer, segment, initial, { 5: 1 })
disposeState(initial)
assert(Number.isFinite(update.loss) && update.gradientNorm > 0)
assert(model.fast.candidate.w.dataSync().some((v, i) => v !== fastBefore[i]), 'GRU must receive gradients')
assert(model.slowBlocks[0].ffOut.w.dataSync().some((v, i) => v !== slowBefore[i]), 'Transformer must receive gradients')
assert.deepEqual([...model.fastHeads[0].w.dataSync()], unrelated, 'unknown human action heads have no direct supervised update')
const trace = (source, split, matchId) => ({ source, split, matchId, frames: segment })
const dataset = { schema: 'public-human-imitation-v1', ppoEligible: false,
  trajectories: [trace('a', 'train', 'm1'), trace('b', 'validation', 'm2')] }
assert.deepEqual(validateDataset(dataset), { train: { 5: 1 }, validation: { 5: 1 } })
assert.throws(() => validateDataset({ ...dataset, trajectories: [trace('a', 'train', 'same'), trace('b', 'validation', 'same')] }), /leakage/)
assert.throws(() => validateDataset({ ...dataset, ppoEligible: true }), /non-PPO/)
const heldTrace=(source,split,matchId,evidence)=>({source,split,matchId,frames:[{
  tick:1,observation,labels:{5:4},labelEvidence:evidence}]})
assert.doesNotThrow(()=>validateDataset({...dataset,trajectories:[
  heldTrace('hold-a','train','hold-m1',['consecutive-native-melee-weapon-choice']),
  heldTrace('hold-b','validation','hold-m2',['consecutive-native-melee-weapon-choice'])]}))
assert.throws(()=>validateDataset({...dataset,trajectories:[
  heldTrace('hold-a','train','hold-m1',[]),heldTrace('hold-b','validation','hold-m2',[])]}),
  /fabricated/,'hold labels require native transition evidence')
assert.throws(() => validateDataset({ ...dataset, trajectories: [
  { ...trace('1794720829881-23128-view-a', 'train', 'observer-a'), fighter: 'A', opponent: 'B' },
  { ...trace('1794720829881-23128-view-b', 'validation', 'observer-b'), fighter: 'B', opponent: 'A' }
] }), /leakage/, 'observer UUID must not defeat whole-match holdout')
optimizer.dispose(); model.dispose()
console.log(JSON.stringify({ result: 'HUMAN_IMITATION_PASS', gradientsToBothBranches: true,
  unrelatedHeadUnchanged: true, wholeMatchLeakageRejected: true, offPolicyPPORejected: true,
  exactLiveContextDistribution: true }))
