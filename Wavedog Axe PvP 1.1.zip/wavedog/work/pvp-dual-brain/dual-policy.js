import * as tf from '@tensorflow/tfjs'

export const OBS_SIZE = 98
export const ACTION_WIDTHS = [9, 2, 2, 2, 5, 5, 13, 7, 2]
export const DEFAULT_CONFIG = Object.freeze({ fast: 64, slow: 256, heads: 8,
  layers: 4, ff: 1024, interval: 8, memory: 32 })
export const GATE_TARGET = [.20, .25, .25, .25, .45, .55, .35, .35, .35]
let modelCount = 0
const gelu = x => tf.mul(.5, tf.mul(x, tf.add(1,
  tf.tanh(tf.mul(Math.sqrt(2 / Math.PI),
    tf.add(x, tf.mul(.044715, tf.pow(x, 3))))))))

// Public-observation curriculum priors only change exploration logits. PPO
// trains against the resulting distribution and can learn to override them.
export function curriculumLogitBias (x) {
  if (!Array.isArray(x) || x.length !== OBS_SIZE)
    throw Error('curriculum bias needs one public observation')
  const bias = ACTION_WIDTHS.map(width => Array(width).fill(0))
  if (x[31] < .5) return bias
  const outOfReach = x[97] > .12
  const nearEdge = x[97] > -.55 && x[97] < .2
  const noRangedAmmo = x[10] <= 0 && x[11] < .5
  const aggressive = x[73] > .5
  const defensive = x[72] > .5
  const flank = x[74] > .5
  const groundCombo = x[75] > .5
  if (outOfReach && noRangedAmmo) {
    bias[0][1] += 2.2
    bias[0][2] -= 1.4
    bias[0][5] += .65
    bias[0][6] += .65
    bias[1][1] += .55
    if (x[97] > .65) bias[4][1] -= 1.8
  }
  if (aggressive) {
    if (outOfReach) { bias[0][1] += .8; bias[0][2] -= .7 }
    if (nearEdge && x[1] > .75) bias[4][2] += .9
  }
  if (defensive && nearEdge && x[6] > .5) bias[4][1] += .4
  if (flank && outOfReach) { bias[0][5] += .5; bias[0][6] += .5 }
  if (groundCombo && nearEdge && x[23] < .5) bias[5][1] += 1.5
  if (nearEdge && x[1] > .85 && x[8] < .5) bias[4][2] += 1.1
  if (x[1] > .85 && x[8] < .5 && x[23] < .5
      && x[97] > -.97 && x[97] < .2) bias[4][2] += 1.5
  // Once the public hitbox-distance feature says the opponent is legally
  // reachable and attack cooldown is full, keep exploration from settling
  // into a long observe-only loop. This is a soft PPO prior, not a forced
  // attack and does not affect out-of-reach swings.
  if (x[1] >= .85 && x[8] < .5 && x[23] < .5 && x[97] < .2)
    bias[4][2] += 24.0
  // Written method cues become conditional exploration opportunities. They
  // never replace the learned action distribution or fabricate a hit.
  if (x[82] > .95 && x[6] > .5 && x[8] < .5
      && x[97] > -.95 && x[97] < .3) {
    bias[4][1] += 1.3
    if (x[96] > .4) bias[4][1] += .8
  }
  if (x[86] > .95 && x[89] > .25 && x[96] > .4
      && x[97] < .25 && x[97] > -.95) {
    bias[0][2] += .9
    bias[1][1] += .4
  }
  if (x[84] > .95 && x[85] > .25 && x[2] > .5
      && x[97] > .5 && x[8] < .5) {
    bias[0][1] += 1.0
    bias[1][1] += .8
    bias[2][1] += .7
  }
  if (x[90] > .95 && x[10] > 0 && x[97] > .9) {
    bias[5][2] += 1.5
    bias[4][3] += 1.1
  }
  if (x[91] > .95 && (x[10] > 0 || x[11] > .5)
      && x[97] > .9) {
    bias[5][3] += 1.5
    bias[4][3] += 1.1
  }
  // Jump reset is a public-swing timing experiment, never a permanent jump.
  // The SYNC goal and its two method cues identify this particular lesson.
  if (x[87] > .5 && x[85] > .4 && x[89] > .25
      && x[2] > .5 && x[96] > .4 && x[97] > -.95 && x[97] < .25)
    bias[2][1] += 1.0
  // Current self-play still clicks at low charge in almost every melee frame.
  // Keep light hits available for shield breaks and low-health emergencies;
  // shift ordinary exploration toward waiting for a useful damage window.
  if (x[23] < .5 && x[0] > .3 && x[1] < .85) {
    bias[4][2] -= x[1] < .55 ? 5.5 : 2.5
  }
  return bias
}

class Dense {
  constructor (input, output, name) {
    this.w = tf.variable(tf.randomNormal([input, output], 0, 1 / Math.sqrt(input)),
      true, `${name}.w`)
    this.b = tf.variable(tf.zeros([output]), true, `${name}.b`)
    this.params = [this.w, this.b]
  }
  apply (x) { return tf.add(tf.matMul(x, this.w), this.b) }
}
class LayerNorm {
  constructor (width, name) {
    this.scale = tf.variable(tf.ones([width]), true, `${name}.scale`)
    this.bias = tf.variable(tf.zeros([width]), true, `${name}.bias`)
    this.params = [this.scale, this.bias]
  }
  apply (x) {
    const { mean, variance } = tf.moments(x, -1, true)
    return tf.add(tf.mul(tf.div(tf.sub(x, mean), tf.sqrt(tf.add(variance, 1e-5))),
      this.scale), this.bias)
  }
}
class FastGRU {
  constructor (input, hidden, name) {
    this.hidden = hidden
    this.reset = new Dense(input + hidden, hidden, `${name}.reset`)
    this.update = new Dense(input + hidden, hidden, `${name}.update`)
    this.candidate = new Dense(input + hidden, hidden, `${name}.candidate`)
    this.params = [...this.reset.params, ...this.update.params, ...this.candidate.params]
  }
  step (observation, previous) {
    const joined = tf.concat([observation, previous], 1)
    const reset = tf.sigmoid(this.reset.apply(joined))
    const update = tf.sigmoid(this.update.apply(joined))
    const candidate = tf.tanh(this.candidate.apply(tf.concat([
      observation, tf.mul(reset, previous)], 1)))
    return tf.add(tf.mul(update, previous), tf.mul(tf.sub(1, update), candidate))
  }
}
class GatedXLBlock {
  constructor (width, heads, ff, name) {
    if (width % heads !== 0) throw Error('slow width must divide attention heads')
    this.width = width; this.heads = heads; this.headWidth = width / heads
    this.normAttention = new LayerNorm(width, `${name}.norm-attention`)
    this.query = new Dense(width, width, `${name}.query`)
    this.key = new Dense(width, width, `${name}.key`)
    this.value = new Dense(width, width, `${name}.value`)
    this.attentionOut = new Dense(width, width, `${name}.attention-out`)
    this.attentionGate = new Dense(width * 2, heads, `${name}.attention-gate`)
    this.normFF = new LayerNorm(width, `${name}.norm-ff`)
    this.ffIn = new Dense(width, ff, `${name}.ff-in`)
    this.ffOut = new Dense(ff, width, `${name}.ff-out`)
    this.ffGate = new Dense(width * 2, heads, `${name}.ff-gate`)
    this.slopes = tf.tensor3d(Array.from({ length: heads }, (_, i) =>
      .003 + .027 * i / Math.max(1, heads - 1)), [1, heads, 1])
    this.params = [this.normAttention, this.query, this.key, this.value,
      this.attentionOut, this.attentionGate, this.normFF, this.ffIn,
      this.ffOut, this.ffGate].flatMap(layer => layer.params)
  }
  gate (x, proposal, layer) {
    const batch = x.shape[0]
    const perHead = tf.sigmoid(layer.apply(tf.concat([x, proposal], 1)))
    const expanded = tf.reshape(tf.tile(tf.expandDims(perHead, -1),
      [1, 1, this.headWidth]), [batch, this.width])
    return tf.add(x, tf.mul(expanded, proposal))
  }
  step (input, cache, limit) {
    const batch = input.shape[0]
    const normalized = this.normAttention.apply(input)
    const shape = [batch, this.heads, 1, this.headWidth]
    const query = tf.reshape(this.query.apply(normalized), shape)
    const nextKey = tf.reshape(this.key.apply(normalized), shape)
    const nextValue = tf.reshape(this.value.apply(normalized), shape)
    let key = cache ? tf.concat([cache.key, nextKey], 2) : nextKey
    let value = cache ? tf.concat([cache.value, nextValue], 2) : nextValue
    const length = Math.min(key.shape[2], limit)
    if (key.shape[2] > limit) {
      key = key.slice([0, 0, key.shape[2] - limit, 0], [batch, this.heads, length, this.headWidth])
      value = value.slice([0, 0, value.shape[2] - limit, 0], [batch, this.heads, length, this.headWidth])
    }
    const age = tf.reshape(tf.range(length - 1, -1, -1), [1, 1, length])
    const score = tf.sub(tf.div(tf.sum(tf.mul(query, key), -1), Math.sqrt(this.headWidth)),
      tf.mul(this.slopes, age))
    const weights = tf.softmax(score, -1)
    const attended = tf.reshape(tf.sum(tf.mul(tf.expandDims(weights, -1), value), 2),
      [batch, this.width])
    const attention = this.attentionOut.apply(attended)
    const afterAttention = this.gate(input, attention, this.attentionGate)
    const ff = this.ffOut.apply(gelu(this.ffIn.apply(this.normFF.apply(afterAttention))))
    return { output: this.gate(afterAttention, ff, this.ffGate), cache: { key, value } }
  }
}

export class DualPolicy {
  constructor (config = {}, gateMode = 'learned') {
    if (!['learned', 'fixed'].includes(gateMode)) throw Error('invalid gate mode')
    this.config = { ...DEFAULT_CONFIG, ...config }
    this.gateMode = gateMode
    const { fast, slow, heads, layers, ff } = this.config
    const name = `dual${++modelCount}`
    this.fast = new FastGRU(OBS_SIZE, fast, `${name}.fast`)
    this.fastHeads = ACTION_WIDTHS.map((width, index) =>
      new Dense(fast, width, `${name}.fast-head-${index}`))
    this.fastValue = new Dense(fast, 1, `${name}.fast-value`)
    this.slowToken = new Dense(OBS_SIZE * 2, slow, `${name}.slow-token`)
    this.slowBlocks = Array.from({ length: layers }, (_, index) =>
      new GatedXLBlock(slow, heads, ff, `${name}.slow-${index}`))
    this.slowHeads = ACTION_WIDTHS.map((width, index) =>
      new Dense(slow, width, `${name}.slow-head-${index}`))
    this.gateIn = new Dense(OBS_SIZE + fast + slow, 128, `${name}.gate-in`)
    this.gateOut = new Dense(128, ACTION_WIDTHS.length, `${name}.gate-out`)
    this.valueIn = new Dense(OBS_SIZE + fast + slow, 256, `${name}.value-in`)
    this.valueOut = new Dense(256, 1, `${name}.value-out`)
    this.fixedGate = tf.tensor2d([GATE_TARGET])
    this.params = [this.fast, ...this.fastHeads, this.fastValue, this.slowToken,
      ...this.slowBlocks, ...this.slowHeads, this.gateIn, this.gateOut,
      this.valueIn, this.valueOut].flatMap(layer => layer.params)
  }
  parameterCount () { return this.params.reduce((n, variable) => n + variable.size, 0) }
  initialState (batch = 1) {
    return { fast: tf.zeros([batch, this.config.fast]), slow: null,
      caches: Array(this.config.layers).fill(null), pending: [], frames: 0 }
  }
  step (observation, state) {
    if (observation.shape.length !== 2 || observation.shape[1] !== OBS_SIZE)
      throw Error(`expected [batch,${OBS_SIZE}] public observation`)
    state ||= this.initialState(observation.shape[0])
    if (state.fast.shape[0] !== observation.shape[0]) throw Error('actor state batch mismatch')
    const fast = this.fast.step(observation, state.fast)
    let pending = [...state.pending, observation]
    let slow = state.slow
    let caches = state.caches
    if (!slow || state.frames % this.config.interval === 0) {
      const average = tf.mean(tf.stack(pending), 0)
      slow = tf.tanh(this.slowToken.apply(tf.concat([observation, average], 1)))
      caches = []
      for (let index = 0; index < this.slowBlocks.length; index++) {
        const result = this.slowBlocks[index].step(slow, state.caches[index], this.config.memory)
        slow = result.output; caches.push(result.cache)
      }
      pending = []
    }
    const features = tf.concat([observation, fast, slow], 1)
    const gate = this.gateMode === 'learned'
      ? tf.sigmoid(this.gateOut.apply(tf.tanh(this.gateIn.apply(features))))
      : tf.tile(this.fixedGate, [observation.shape[0], 1])
    const rawLogits = this.fastHeads.map((layer, index) => {
      const weight = gate.slice([0, index], [observation.shape[0], 1])
      return tf.add(tf.mul(tf.sub(1, weight), layer.apply(fast)),
        tf.mul(weight, this.slowHeads[index].apply(slow)))
    })
    const observed = observation.dataSync()
    const priors = Array.from({ length: observation.shape[0] }, (_, batch) =>
      curriculumLogitBias(Array.from(observed.slice(batch * OBS_SIZE,
        (batch + 1) * OBS_SIZE))))
    const logits = rawLogits.map((head, index) => tf.add(head,
      tf.tensor2d(priors.map(row => row[index]),
        [observation.shape[0], ACTION_WIDTHS[index]])))
    const value = tf.add(this.fastValue.apply(fast),
      tf.mul(tf.mean(gate, 1, true),
        this.valueOut.apply(tf.tanh(this.valueIn.apply(features)))))
    return { logits, value, gate, state: { fast, slow, caches, pending,
      frames: state.frames + 1 } }
  }
  dispose () { for (const variable of this.params) variable.dispose(); this.fixedGate.dispose() }
}

export function maskActionLogits (logits, legalMasks = null) {
  if (legalMasks == null) return logits
  if (!Array.isArray(legalMasks) || legalMasks.length !== logits.length)
    throw Error('legal mask head count mismatch')
  return logits.map((head, index) => {
    const legal = legalMasks[index]
    if (!Array.isArray(legal) || legal.length !== head.shape[1]
        || legal.some(value => typeof value !== 'boolean') || !legal.some(Boolean))
      throw Error(`invalid legal mask at head ${index}`)
    const mask = tf.tensor2d([legal], [1, legal.length], 'bool')
    const limited = tf.where(mask, head, tf.fill(head.shape, -1e9))
    mask.dispose()
    return limited
  })
}
export function actionLogProbability (logits, actions, executedHeads = null,
  legalMasks = null) {
  const masked = maskActionLogits(logits, legalMasks)
  const terms = masked.map((head, index) => {
    if (executedHeads?.[index] === false) return tf.scalar(0)
    const action = actions[index]
    if (!Number.isInteger(action) || action < 0 || action >= head.shape[1]
        || legalMasks?.[index]?.[action] === false)
      throw Error(`illegal executed action at head ${index}`)
    const oneHot = tf.oneHot([action], head.shape[1])
    const logProb = tf.sum(tf.mul(oneHot, tf.logSoftmax(head, -1)))
    return logProb
  })
  return tf.addN(terms)
}
export function gateRegularizer (gates, gateMode, warmup = 1) {
  if (gateMode !== 'learned') return tf.scalar(0)
  const values = tf.concat(gates, 0)
  const target = tf.tensor1d(GATE_TARGET)
  const balance = tf.mean(tf.square(tf.sub(tf.mean(values, 0), target)))
  const specialization = tf.mean(tf.mul(values, tf.sub(1, values)))
  return tf.mul(warmup, tf.add(tf.mul(.01, balance), tf.mul(.001, specialization)))
}
export function computeGAE (episodes, gamma = .997, lambda = .99) {
  const prepared = episodes.map(episode => {
    let advantage = 0, nextValue = episode.bootstrapValue || 0
    const frames = episode.map(frame => ({ ...frame }))
    for (let index = frames.length - 1; index >= 0; index--) {
      const frame = frames[index]
      const live = frame.done ? 0 : 1
      const delta = frame.reward + gamma * nextValue * live - frame.oldValue
      advantage = delta + gamma * lambda * live * advantage
      frame.advantage = advantage
      frame.target = advantage + frame.oldValue
      nextValue = frame.oldValue
    }
    return frames
  })
  const all = prepared.flat().map(frame => frame.advantage)
  const mean = all.reduce((sum, value) => sum + value, 0) / all.length
  const variance = all.reduce((sum, value) => sum + (value - mean) ** 2, 0) / all.length
  for (const frame of prepared.flat())
    frame.advantage = (frame.advantage - mean) / (Math.sqrt(variance) + 1e-6)
  return prepared
}
export function ppoLoss (model, episodes, { clip = .2, valueCoef = .5,
  entropyCoef = .0001, gateWarmup = 1 } = {}) {
  if (!episodes.length || episodes.some(episode => !episode.length))
    throw Error('PPO needs completed actor episodes')
  const policyLosses = [], valueLosses = [], entropies = [], gates = []
  for (const episode of episodes) {
    let state = episode.initialState || model.initialState()
    for (const frame of episode) {
      const observation = tf.tensor2d([frame.observation], [1, OBS_SIZE])
      const output = model.step(observation, state)
      state = output.state
      const masked = maskActionLogits(output.logits, frame.legalMasks)
      const newLog = actionLogProbability(output.logits, frame.actions,
        frame.executedHeads, frame.legalMasks)
      const oldLog = frame.oldHeadLogProbs.reduce((sum, value, index) =>
        sum + (frame.executedHeads[index] ? value : 0), 0)
      const ratio = tf.exp(tf.sub(newLog, oldLog))
      const advantage = tf.scalar(frame.advantage)
      const unclipped = tf.mul(ratio, advantage)
      const clipped = tf.mul(tf.clipByValue(ratio, 1 - clip, 1 + clip), advantage)
      policyLosses.push(tf.neg(tf.minimum(unclipped, clipped)))
      valueLosses.push(tf.square(tf.sub(tf.squeeze(output.value), frame.target)))
      const headEntropies = masked.map((head, index) => {
        if (!frame.executedHeads[index]) return tf.scalar(0)
        const probability = tf.softmax(head, -1)
        return tf.neg(tf.sum(tf.mul(probability, tf.logSoftmax(head, -1))))
      })
      entropies.push(tf.div(tf.addN(headEntropies),
        Math.max(1, frame.executedHeads.filter(Boolean).length)))
      gates.push(output.gate)
    }
  }
  const policy = tf.mean(tf.stack(policyLosses))
  const value = tf.mean(tf.stack(valueLosses))
  const entropy = tf.mean(tf.stack(entropies))
  return tf.addN([policy, tf.mul(valueCoef, value), tf.mul(-entropyCoef, entropy),
    gateRegularizer(gates, model.gateMode, gateWarmup)])
}
export function ppoUpdate (model, optimizer, episodes, options = {}) {
  return tf.tidy(() => {
    const { value, grads } = tf.variableGrads(
      () => ppoLoss(model, episodes, options), model.params)
    const result = { loss: value.dataSync()[0], gradients: Object.fromEntries(
      Object.entries(grads).map(([name, gradient]) =>
        [name, tf.norm(gradient).dataSync()[0]])) }
    optimizer.applyGradients(grads)
    return result
  })
}
