"""Restart the idle shared learner and its two-arena client controller."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, socket, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
PLAYER = ROOT / 'work/pvp-player-client'
sys.path.insert(0, str(ROOT / 'work'))
from server_control_1211 import command

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    status = command('selfplay status')
    if 'desired=0 active=0' not in status:
        raise RuntimeError('Refusing to restart active bouts: ' + status)
    raw = subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
        'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress'],
        text=True, encoding='utf-8', errors='replace')
    processes = json.loads(raw)
    roots = [p for p in processes if p.get('Name', '').lower() == 'node.exe'
        and any(part in (p.get('CommandLine') or '').replace(chr(92), '/').lower()
            for part in ['/work/pvp-dual-brain/dual-service.js', '/work/pvp-player-client/selfplay.js'])]
    resume = '--resume' in sys.argv
    if resume:
        try:
            with socket.create_connection(('127.0.0.1', 18766), timeout=1):
                raise RuntimeError('Resume requires the snapshot-stopped model port to be free')
        except OSError:
            pass
    if not resume and not any('dual-service.js' in (p.get('CommandLine') or '') for p in roots):
        raise RuntimeError('Active shared service process was not resolved; refusing duplicate launch')
    for p in roots:
        subprocess.run(['taskkill.exe', '/PID', str(p['ProcessId']), '/T', '/F'],
            check=True, capture_output=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = MODEL / 'backups' / (stamp + '-before-input-authority')
    backup.mkdir(parents=True)
    manifest = json.loads((MODEL / 'checkpoint.json').read_text(encoding='utf-8'))
    binary = manifest['binary']
    if Path(binary).name != binary:
        raise RuntimeError('Unexpected checkpoint binary path')
    for name in ['checkpoint.json', binary]:
        shutil.copy2(MODEL / name, backup / name)
    before = sha(MODEL / 'checkpoint.json')
    logs = ROOT / 'work/pvp-8.6-dual-fresh/runtime/services'
    logs.mkdir(parents=True, exist_ok=True)
    out = logs / (stamp + '-dual.out.log')
    err = logs / (stamp + '-dual.err.log')
    node = shutil.which('node') or 'E:/node/node.exe'
    with out.open('wb') as stdout, err.open('wb') as stderr:
        service = subprocess.Popen([node, str(ROOT / 'work/pvp-dual-brain/dual-service.js'),
            str(MODEL / 'checkpoint.json')], cwd=ROOT / 'work/pvp-dual-brain',
            stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
            creationflags=subprocess.CREATE_NO_WINDOW)
    print(json.dumps({'phase': 'service-started', 'pid': service.pid, 'backup': str(backup)}), flush=True)
    connected = None
    for _ in range(90):
        if service.poll() is not None:
            raise RuntimeError('Service exited: ' + str(err))
        try:
            connected = socket.create_connection(('127.0.0.1', 18766), timeout=1)
            break
        except OSError:
            time.sleep(1)
    if connected is None:
        raise RuntimeError('Service did not listen')
    connected.settimeout(120)
    reader = connected.makefile('r', encoding='utf-8')
    while True:
        row = json.loads(reader.readline())
        if row.get('event') == 'ready':
            break
        if row.get('event') in ['error', 'service_error']:
            raise RuntimeError(str(row))
    print(json.dumps({'phase': 'shared-model-ready'}), flush=True)
    probe_before = sha(MODEL / 'checkpoint.json')
    match = 'entry-probe-' + stamp
    def send(row):
        connected.sendall((json.dumps(row) + '\n').encode())
    send({'command': 'reset', 'fighter': 'EntryProbe', 'opponent': 'ProbeTarget',
        'matchId': match, 'learning': False, 'role': 'current', 'focus': 'FREE'})
    send({'command': 'act', 'fighter': 'EntryProbe', 'opponent': 'ProbeTarget',
        'matchId': match, 'requestId': 991001, 'tick': 1, 'focus': 'FREE',
        'style': 'MIXED', 'yaw': 0, 'pitch': 0,
        'self': {'x': 1050, 'y': 221, 'z': 952, 'eyeY': 222.62, 'vx': 0, 'vy': 0,
            'vz': 0, 'ground': True, 'critical': False, 'charge': 1, 'health': 20,
            'shieldAvailable': False, 'shielding': False, 'arrows': 0,
            'crossbowLoaded': False, 'using': False, 'useTicks': 0, 'held': 7},
        'seen': {'visible': True, 'x': 1050, 'y': 221, 'z': 955, 'yaw': 180,
            'shield': False, 'held': 'DIAMOND_AXE', 'using': False, 'swing': 0, 'arrows': []}})
    while True:
        action = json.loads(reader.readline())
        if action.get('fighter') == 'EntryProbe' and action.get('model') == 'DUAL-GRU-GTRXL':
            break
        if action.get('event') in ['error', 'service_error']:
            raise RuntimeError(str(action))
    send({'command': 'reset', 'fighter': 'EntryProbe', 'opponent': 'ProbeTarget',
        'matchId': match + '-cleared', 'learning': False, 'role': 'current'})
    reader.close(); connected.close()
    if sha(MODEL / 'checkpoint.json') != probe_before:
        raise RuntimeError('Checkpoint changed during no-training smoke test')
    ready = PLAYER / 'new-learning/selfplay-ready.json'
    while ready.exists() and time.time() - ready.stat().st_mtime < 6:
        time.sleep(1)
    environment = os.environ.copy(); environment['WAVEDOG_FRESH_DUAL'] = '1'
    controller = subprocess.run([sys.executable, '-X', 'utf8',
        str(PLAYER / 'start-retention-controller.py'), '4', '--dual'],
        cwd=ROOT, env=environment, capture_output=True, text=True, encoding='utf-8', timeout=110)
    if controller.returncode:
        raise RuntimeError(controller.stdout + controller.stderr)
    print(controller.stdout, flush=True)
    start = command('selfplay start 2')
    result = {'at': datetime.datetime.now().isoformat(), 'service_pid': service.pid,
        'checkpoint_snapshot_sha256': before, 'checkpoint_after_recovery_sha256': probe_before, 'backup': str(backup),
        'service_stdout': str(out), 'service_stderr': str(err),
        'live_action': action, 'start': start, 'status': command('selfplay status')}
    (logs / (stamp + '-receipt.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)

if __name__ == '__main__':
    main()
