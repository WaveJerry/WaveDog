import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE, biasedActionLogits } from './fresh-policy.js'

// Keep the reference within this package so its TensorFlow import resolves to
// exactly the same runtime as the current policy.
const temporary = fs.mkdtempSync(new URL('./runtime/v9-reference-', import.meta.url))
try {
  const reference = path.join(temporary, 'fresh-policy.js')
  fs.copyFileSync(new URL('../wavedog-protocol/runtime/wasplan-ground-combo/before-sword-exploration-v9.js', import.meta.url), reference)
  const previous = (await import(pathToFileURL(reference).href)).biasedActionLogits
  await tf.setBackend('cpu'); await tf.ready()
  const logits = ACTION_WIDTHS.map(n => tf.tensor2d([Array.from({ length: n }, (_, i) => (i - 1) * 3.17)]))
  const output = (policy, x, context) => tf.tidy(() => policy(logits, x, context)
    .map(head => [...tf.logSoftmax(head).dataSync()]))
  let checked = 0
  const x = Array(OBS_SIZE).fill(0)
  x[0] = 1; x[31] = 1; x[97] = -.6
  for (let version = 0; version <= 9; version++) {
    for (const charge of [.1, .3, .5, .8, .95]) {
      for (const held of [0, .875]) for (const shield of [0, 1]) for (const ground of [0, 1]) {
        const obs = [...x]; obs[1] = charge; obs[12] = held; obs[23] = shield; obs[2] = ground
        const context = { entryCurriculum: version, swordDpsWindow: true,
          swordSustainWindow: true, swordCriticalSetupWindow: true,
          swordShieldBreakWindow: true, axeShieldBreakWindow: true,
          swordCadenceWindow: true, swordRisingWindow: false,
          groundChainReentry: true, edgeComboRisk: true, ownFallingWindow: false }
        assert.deepEqual(output(biasedActionLogits, obs, context), output(previous, obs, context))
        checked++
      }
    }
  }
  const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL(
    '../pvp-8.6-dual-fresh/model/rollouts/rollout-000000002044.json.gz', import.meta.url))))
  for (const frame of rollout.episode) {
    assert.deepEqual(output(biasedActionLogits, frame.observation, frame.context),
      output(previous, frame.observation, frame.context))
    checked++
  }
  logits.forEach(head => head.dispose())
  console.log(JSON.stringify({ event: 'SWORD_V10_REPLAY_COMPATIBILITY_PASS',
    distributionsChecked: checked, oldContextVersions: '0..9', recordedFrames: rollout.episode.length }))
} finally {
  fs.unlinkSync(path.join(temporary, 'fresh-policy.js'))
  fs.rmdirSync(temporary)
}
