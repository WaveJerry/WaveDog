// Replay the real causal observations; report probabilities, never force hits.
import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { advance, disposeState, deployedImitationLogits } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const [manifest, output, ...files]=process.argv.slice(2)
if(!manifest||!output||!files.length)throw Error('Need manifest, output and native rollout files')
const loaded=loadDualCheckpoint(manifest);loaded.adam.dispose()
const report={candidateSha256:loaded.manifest.sha256,realCombatReproduced:false,
  method:'causal recorded-observation replay; conditional attack uses the recorded weapon choice',rollouts:[]}
try{
  for(const file of files){
    const row=JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    let state=loaded.model.initialState();const eligible=[],close=[],suspect=[]
    try{
      for(const frame of row.episode){
        const result=advance(loaded.model,state,frame.observation,true,frame.legalMasks,frame.publicHealthFeatures)
        state=result.state
        const probabilities=tf.tidy(()=>deployedImitationLogits(loaded.model,
          result.logits.map(head=>tf.tensor2d([head])),frame).map(head=>[...tf.softmax(head).dataSync()]))
        const x=frame.observation
        const item={tick:frame.decidedTick,charge:x[1],rangeChannel:x[97],heldChannel:x[12],
          oldAttack:frame.oldHeadProbabilities?.[4]?.[2],newAttack:probabilities[4][2],
          oldSword:frame.oldHeadProbabilities?.[5]?.[1],newSword:probabilities[5][1]}
        if(x[31]>.5&&x[97]<=0&&x[1]>=.85&&x[7]<.5&&x[8]<.5&&x[23]<.5
            &&!(frame.context.fallingMeleeThreat&&!frame.context.ownFallingWindow))eligible.push(item)
        if(x[31]>.5&&x[97]<-.7&&x[7]<.5&&x[8]<.5&&x[23]<.5)close.push(item)
        if(frame.decidedTick>=12198&&frame.decidedTick<=12202)suspect.push(item)
      }
    }finally{disposeState(state)}
    const mean=(rows,key)=>rows.length?rows.reduce((sum,r)=>sum+(r[key]||0),0)/rows.length:null
    report.rollouts.push({file,frames:row.episode.length,eligibleFrames:eligible.length,
      meanOldAttack:mean(eligible,'oldAttack'),meanNewAttack:mean(eligible,'newAttack'),
      closeFrames:close.length,meanOldSword:mean(close,'oldSword'),meanNewSword:mean(close,'newSword'),suspect})
  }
  fs.writeFileSync(output,JSON.stringify(report,null,2));console.log(JSON.stringify(report))
}finally{loaded.model.dispose()}
