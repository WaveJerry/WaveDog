"""Snapshot the current brain, then train only its demonstrated readouts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

ROOT=Path(__file__).resolve().parents[2]
OUTPUT=ROOT/'outputs/sword-learning-next-20261116/candidate-s-joint-sequence'
MODEL=ROOT/'work/pvp-8.6-dual-fresh/model'
DATA=ROOT/'outputs/sword-learning-next-20261116/joint-expert-sequences-v1/live-context.json'
if OUTPUT.exists():raise RuntimeError('Preserve prior candidate')
snapshot=OUTPUT/'production-snapshot';snapshot.mkdir(parents=True)
payload=(MODEL/'checkpoint.json').read_bytes();manifest=json.loads(payload)
binary=(MODEL/manifest['binary']).read_bytes()
if hashlib.sha256(binary).hexdigest()!=manifest['sha256']:raise RuntimeError('Snapshot hash mismatch')
(snapshot/manifest['binary']).write_bytes(binary);(snapshot/'checkpoint.json').write_bytes(payload)
environment=os.environ.copy()
environment.update(IMITATION_HEADS_ONLY='1',IMITATION_CONTEXT_ONLY='0',
    IMITATION_CONTEXT_HEADS='[2,4,5]',IMITATION_CALIBRATED_HEADS='[2,4,5]',
    IMITATION_DISTRIBUTION_VERSION='3',IMITATION_WEAPON_CONDITIONING='2',
    IMITATION_LR='0.00005',IMITATION_CONTEXT_RATE='4',IMITATION_EPOCHS='2',
    IMITATION_FREQUENCY_HEADS='[4]',IMITATION_ADAPTED_ANCHOR='0.1',
    IMITATION_ADAPTED_HEADS='[2,4,5]')
state={'startedAt':datetime.now(timezone.utc).isoformat(),'sourceSha256':manifest['sha256'],
    'status':'training','changes':['GRU readouts 2/4/5','GTrXL readouts 2/4/5','gate columns 2/4/5','context readouts'],
    'recurrentBackbonesFrozen':True,'originalPpoOptimizerPreserved':True,
    'mainCheckpointModified':False,'autoPublish':False}
def save(): (OUTPUT/'job-state.json').write_text(json.dumps(state,indent=2),encoding='utf8')
save()
try:
    with (OUTPUT/'training.log').open('wb')as log:
        subprocess.run([shutil.which('node'),str(ROOT/'work/pvp-dual-brain/human-imitation.js'),
            str(snapshot/'checkpoint.json'),str(DATA),str(OUTPUT/'trained')],cwd=ROOT,env=environment,
            stdout=log,stderr=subprocess.STDOUT,check=True)
    receipt=json.loads((OUTPUT/'trained/receipt.json').read_text())
    protected=[name for name in receipt['parameterAudit']if name in ['fast','slow-token','gate-in','value-in','value-out']
        or name.startswith('slow-')and name[5:].isdigit()]
    assert all(receipt['parameterAudit'][name]['changed']==0 for name in protected)
    state.update(status='offline-complete-awaiting-live-acceptance',
        offlineChecksPassed=receipt['offlineChecksPassed'],
        candidateSha256=receipt['saved']['sha256'],checks=receipt['checks'])
except Exception as error:
    state.update(status='failed-preserving-records',error=str(error));raise
finally:save()
print(json.dumps(state),flush=True)
