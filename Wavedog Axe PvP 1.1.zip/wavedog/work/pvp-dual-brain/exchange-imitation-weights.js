// Balance decision situations, not isolated button counts. The entire causal
// sequence still advances through both recurrent branches on every frame.
export function attackSituation(frame){
  const x=frame.observation
  if(x[31]<.5||x[97]>0)return 'outside'
  if(x[23]>.5)return 'shield'
  if(x[1]<.75)return 'recovering'
  if(frame.context?.fallingMeleeThreat&&!frame.context?.ownFallingWindow)return 'falling-opponent'
  if(x[2]<.5&&x[4]>.08)return 'rising-self'
  if(frame.operatorGroundedEdgeOpening&&x[2]>.5)return 'grounded-edge-opening'
  return 'ready'
}
export function exchangeAttackWeights(dataset){
  const groups={}
  for(const trace of dataset.trajectories.filter(t=>t.split==='train'))for(const frame of trace.frames){
    const action=frame.labels?.['4'];if(action===undefined)continue
    const key=attackSituation(frame),g=groups[key]||=( {total:0,actions:{}} )
    const n=frame.supervisionWeight??1;g.total+=n;g.actions[action]=(g.actions[action]||0)+n
  }
  const total=Object.values(groups).reduce((sum,g)=>sum+g.total,0)
  const weights={}
  for(const [key,g]of Object.entries(groups)){
    // Preserve actual click frequency while recovering/outside. Balance the
    // legal ready-window choices so cooldown waiting cannot drown out attacks.
    const balanced=['ready','grounded-edge-opening'].includes(key)&&g.actions[0]&&g.actions[2]
    const groupWeight=total/(Object.keys(groups).length*g.total)
    weights[key]=Object.fromEntries(Object.entries(g.actions).map(([action,n])=>[action,
      groupWeight*(balanced?g.total/(2*n):1)]))
  }
  return {groups,weights}
}
