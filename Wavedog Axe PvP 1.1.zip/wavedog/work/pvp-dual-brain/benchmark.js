import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE } from './dual-policy.js'

await tf.setBackend('cpu')
await tf.ready()
const model = new DualPolicy()
const actors = Array.from({ length: 4 }, () => model.initialState())
function tensors (state) {
  return [state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])]
    .filter(Boolean)
}
const normal = [], refresh = []
for (let frame = 0; frame < 80; frame++) for (let actor = 0; actor < actors.length; actor++) {
  const old = actors[actor]
  const start = performance.now()
  const next = tf.tidy(() => {
    const observation = tf.tensor2d([Array.from({ length: OBS_SIZE }, (_, i) =>
      .2 * Math.sin(frame * .1 + actor + i * .07))])
    const output = model.step(observation, old)
    output.value.dataSync()
    return output.state
  })
  const elapsed = performance.now() - start
  ;(frame % model.config.interval === 0 ? refresh : normal).push(elapsed)
  const retained = new Set(tensors(next))
  for (const tensor of tensors(old)) if (!retained.has(tensor)) tensor.dispose()
  actors[actor] = next
}
function percentile (numbers, fraction) {
  const sorted = [...numbers].sort((a, b) => a - b)
  return +sorted[Math.min(sorted.length - 1, Math.floor(fraction * sorted.length))].toFixed(2)
}
console.log(JSON.stringify({ actors: 4, framesPerActor: 80,
  parameters: model.parameterCount(),
  ordinaryMs: { median: percentile(normal, .5), p95: percentile(normal, .95) },
  refreshMs: { median: percentile(refresh, .5), p95: percentile(refresh, .95) },
  memory: tf.memory() }))
for (const state of actors) for (const tensor of tensors(state)) tensor.dispose()
model.dispose()
