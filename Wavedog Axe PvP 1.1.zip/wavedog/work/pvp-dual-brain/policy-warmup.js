import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE, biasedActionLogits, maskActionLogits } from './fresh-policy.js'

const tensors = state => [state.fast, state.slow, ...state.pending,
  ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])].filter(Boolean)

// Compile/initialize inference kernels before announcing readiness. This state
// is private to startup: no actor, observations, sampling, rewards or PPO data.
export function warmPolicy (model) {
  let state = model.initialState()
  const started = performance.now()
  const observation = Array(OBS_SIZE).fill(0)
  const masks = ACTION_WIDTHS.map(width => Array(width).fill(true))
  const context = { distributionVersion: model.config.distributionVersion || 1,
    calibratedHeads: model.config.calibratedHeads || [2, 5],
    weaponConditionedAttack: model.config.weaponConditionedAttack || 0 }
  context.actionConditionedAttack=model.config.actionConditionedAttack||0
  const count = model.config.interval * 2 + 1
  try {
    for (let tick = 0; tick < count; tick++) {
      const next = tf.tidy(() => {
        const result = model.step(tf.tensor2d([observation]), state, masks, [0, 0, 0, 0, 0])
        const logits = biasedActionLogits(result.logits, observation, context,
          Array(ACTION_WIDTHS.length).fill(0), model, [0, 0, 0, 0, 0])
        for (const head of maskActionLogits(logits, masks)) {
          if (![...tf.softmax(head).dataSync()].every(Number.isFinite))
            throw Error('Non-finite warmup inference')
        }
        result.value.dataSync(); result.gate.dataSync()
        return result.state
      })
      const retained = new Set(tensors(next))
      for (const tensor of new Set(tensors(state))) if (!retained.has(tensor)) tensor.dispose()
      state = next
    }
    return { frames: count, durationMs: performance.now() - started }
  } finally {
    for (const tensor of new Set(tensors(state))) tensor.dispose()
  }
}
