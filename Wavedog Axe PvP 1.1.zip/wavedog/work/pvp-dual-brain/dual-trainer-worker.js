import { parentPort, workerData } from 'node:worker_threads'
import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE, computeGAE, ppoUpdate } from './dual-policy.js'
import { loadDualCheckpoint, saveDualCheckpoint } from './optimizer-checkpoint.js'
import { selectTrainingWindows } from './training-windows.js'

await tf.setBackend('cpu')
await tf.ready()
const checkpointPath = workerData.checkpointPath
const loaded = loadDualCheckpoint(checkpointPath)
const { model, adam } = loaded
const counters = { ...loaded.counters }
const queue = []
let busy = false
let failed = false

function stateTensors (state) {
  return [state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])]
    .filter(Boolean)
}
function advance (state, observation) {
  const next = tf.tidy(() => model.step(
    tf.tensor2d([observation], [1, OBS_SIZE]), state).state)
  const retained = new Set(stateTensors(next))
  for (const tensor of new Set(stateTensors(state)))
    if (!retained.has(tensor)) tensor.dispose()
  return next
}
function disposeState (state) {
  for (const tensor of new Set(stateTensors(state))) tensor.dispose()
}
function saveLatest () {
  const previous = fs.existsSync(checkpointPath)
    ? JSON.parse(fs.readFileSync(checkpointPath, 'utf8')).binary : null
  const saved = saveDualCheckpoint(checkpointPath, model, adam, counters)
  // Preserve the original seed separately. The live checkpoint rotates its
  // binary; raw bout records and the GRU baseline remain intact.
  if (previous && previous !== path.basename(
    JSON.parse(fs.readFileSync(checkpointPath, 'utf8')).binary)) {
    const previousPath = path.join(path.dirname(checkpointPath), previous)
    if (previous.startsWith('checkpoint-') && fs.existsSync(previousPath))
      fs.rmSync(previousPath)
  }
  return saved
}
function train (message) {
  const { episode, fighter, round, partial, requestId, rolloutSeq } = message
  if (!Number.isSafeInteger(rolloutSeq) || rolloutSeq < 1)
    throw Error('PPO rollout sequence is missing')
  if (rolloutSeq <= (counters.lastRolloutSeq || 0))
    return { event: partial ? 'trained_partial' : 'trained', fighter, round,
      requestId, rolloutSeq, alreadyCommitted: true,
      gradient_updates_after: counters.dualUpdates,
      trained_episodes: counters.dualEpisodes,
      checkpoint: checkpointPath }
  if (rolloutSeq !== (counters.lastRolloutSeq || 0) + 1)
    throw Error(`PPO rollout gap: expected ${(counters.lastRolloutSeq || 0) + 1}, got ${rolloutSeq}`)
  if (!Array.isArray(episode) || !episode.length)
    throw Error('No completed rollout frames')
  if (episode.some(frame => !Array.isArray(frame.observation)
      || frame.observation.length !== OBS_SIZE))
    throw Error('Invalid public observation in rollout')
  episode[episode.length - 1].done = !partial
  if (partial) episode.bootstrapValue = episode.at(-1).oldValue
  const prepared = computeGAE([episode])[0]
  const windows = selectTrainingWindows(prepared)
  let cursor = 0
  let state = model.initialState()
  let lastLoss = null
  const started = performance.now()
  try {
    for (const window of windows) {
      while (cursor < window.start)
        state = advance(state, prepared[cursor++].observation)
      const segment = prepared.slice(window.start, window.end)
      segment.initialState = state
      lastLoss = ppoUpdate(model, adam, [segment],
        { gateWarmup: Math.min(1, (counters.dualUpdates + 1) / 1000) }).loss
      counters.dualUpdates++
      while (cursor < window.end)
        state = advance(state, prepared[cursor++].observation)
    }
  } finally {
    disposeState(state)
  }
  if (!partial) counters.dualEpisodes++
  counters.rolloutFrames = (counters.rolloutFrames || 0) + episode.length
  counters.trainedFrames = (counters.trainedFrames || 0) +
    windows.reduce((sum, window) => sum + window.end - window.start, 0)
  counters.lastRolloutSeq = rolloutSeq
  const saved = saveLatest()
  return { event: partial ? 'trained_partial' : 'trained', fighter, round,
    requestId, rolloutSeq, gradient_updates_after: counters.dualUpdates,
    trained_episodes: counters.dualEpisodes,
    rollout_frames: episode.length,
    trained_frames: windows.reduce((sum, window) => sum + window.end - window.start, 0),
    loss: lastLoss, durationMs: Math.round(performance.now() - started),
    checkpoint: saved.manifest, sha256: saved.sha256 }
}
function pump () {
  if (busy || failed || !queue.length) return
  busy = true
  const message = queue.shift()
  try { parentPort.postMessage(train(message)) }
  catch (error) {
    failed = true
    parentPort.postMessage({ event: 'training_error',
      fighter: message.fighter, round: message.round,
      requestId: message.requestId, error: String(error.stack || error) })
    for (const waiting of queue.splice(0)) parentPort.postMessage({
      event: 'training_error', fighter: waiting.fighter, round: waiting.round,
      requestId: waiting.requestId,
      error: 'PPO worker halted after an earlier failed rollout; journal retained for replay' })
  }
  busy = false
  setImmediate(pump)
}
parentPort.on('message', message => {
  if (failed) parentPort.postMessage({ event: 'training_error',
    fighter: message.fighter, round: message.round,
    requestId: message.requestId,
    error: 'PPO worker halted after an earlier failed rollout; journal retained for replay' })
  else { queue.push(message); setImmediate(pump) }
})
parentPort.postMessage({ event: 'trainer_ready', checkpoint: checkpointPath,
  dualUpdates: counters.dualUpdates || 0 })
