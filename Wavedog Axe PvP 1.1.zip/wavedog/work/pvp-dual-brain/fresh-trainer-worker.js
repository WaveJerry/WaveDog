import { parentPort, workerData } from 'node:worker_threads'
import fs from 'node:fs'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE, computeGAE } from './fresh-policy.js'
import { loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { completeRolloutUpdate, replayPolicyHealth, rolloutHealth } from './stable-ppo.js'

await tf.setBackend('cpu'); await tf.ready()
const checkpointPath = workerData.checkpointPath
let loaded = loadDualCheckpoint(checkpointPath)
let { model, adam } = loaded
adam.learningRate = Math.min(adam.learningRate, .00003)
const counters = { ...loaded.counters }, queue = []
let busy = false, failed = false

function train (message) {
  const { episode, fighter, round, partial, requestId, rolloutSeq } = message
  if (!Number.isSafeInteger(rolloutSeq) || rolloutSeq < 1) throw Error('Missing PPO rollout sequence')
  const receipt = () => ({ event: partial ? 'trained_partial' : 'trained', fighter,
    round, requestId, rolloutSeq, gradient_updates_after: counters.dualUpdates,
    trained_episodes: counters.dualEpisodes, checkpoint: checkpointPath })
  if (rolloutSeq <= (counters.lastRolloutSeq || 0))
    return { ...receipt(), alreadyCommitted: true }
  if (rolloutSeq !== (counters.lastRolloutSeq || 0) + 1) throw Error('PPO rollout sequence gap')
  if (!episode?.length || episode.some(f => !Array.isArray(f.observation)
      || f.observation.length !== OBS_SIZE || !f.observation.every(Number.isFinite)))
    throw Error('Invalid public rollout observations')
  const started = performance.now(), health = rolloutHealth(episode)
  // Only explicitly versioned records may train a new distribution. Old raw
  // trajectories remain available for evaluation/imitation, never fake PPO.
  if (episode.some(f => (f.context?.distributionVersion || 1) !== (model.config.distributionVersion || 1)))
    health.reasons.push('behavior-distribution-version-mismatch')
  health.passed = health.reasons.length === 0
  const reasons = [...health.reasons]
  const directory = path.dirname(checkpointPath)
  const archive = path.join(directory, `accepted-before-${rolloutSeq}.json`)
  fs.copyFileSync(checkpointPath, archive)
  let before = null, after = null, update = null, candidate = null
  if (!reasons.length) {
    before = replayPolicyHealth(model, episode)
    if (before.maxMeanHeadKL > .05) reasons.push('stale-behavior-policy')
  }
  if (!reasons.length) {
    episode.at(-1).done = !partial
    if (partial) episode.bootstrapValue = episode.at(-1).oldValue
    const prepared = computeGAE([episode])[0]
    update = completeRolloutUpdate(model, adam, prepared, {
      entropyCoef: model.config.distributionVersion >= 2 ? .003 : .0001,
      gateWarmup: Math.min(1, (counters.dualUpdates + 1) / 1000) })
    after = replayPolicyHealth(model, episode)
    if (!Number.isFinite(after.meanEntropy) || after.meanKL !== null && !Number.isFinite(after.meanKL))
      reasons.push('non-finite-candidate')
    if (after.maxMeanHeadKL > .03) reasons.push('candidate-policy-KL-too-large')
    if (after.opportunities >= 40 && after.meanAttackProbability < .005)
      reasons.push('candidate-melee-collapse')
    if (before.meanEntropy > .01 && after.meanEntropy < .7 * before.meanEntropy)
      reasons.push('candidate-entropy-collapse')
    // Keep every candidate and pre-update weights + Adam for exact diagnosis.
    candidate = saveDualCheckpoint(path.join(directory, `candidate-${rolloutSeq}.json`), model, adam, counters)
    if (reasons.length) {
      adam.dispose(); model.dispose()
      loaded = loadDualCheckpoint(archive); ({ model, adam } = loaded)
      adam.learningRate = Math.min(adam.learningRate, .00003)
    }
  }
  const accepted = reasons.length === 0
  if (accepted) {
    counters.dualUpdates = (counters.dualUpdates || 0) + 1
    if (!partial) counters.dualEpisodes = (counters.dualEpisodes || 0) + 1
    counters.trainedFrames = (counters.trainedFrames || 0) + episode.length
  } else counters.quarantinedRollouts = (counters.quarantinedRollouts || 0) + 1
  counters.rolloutFrames = (counters.rolloutFrames || 0) + episode.length
  // The durable journal is acknowledged even on quarantine; no raw frames
  // are deleted and a rejected record cannot deadlock all future bouts.
  counters.lastRolloutSeq = rolloutSeq
  const saved = saveDualCheckpoint(checkpointPath, model, adam, counters)
  const validation = { health, before, after, reasons, candidate,
    accepted, optimizerSteps: accepted ? 1 : 0, update }
  fs.writeFileSync(path.join(directory, `validation-${rolloutSeq}.json`), JSON.stringify(validation, null, 2))
  return { ...receipt(), candidateAccepted: accepted, quarantined: !accepted,
    reasons, rollout_frames: episode.length, trained_frames: accepted ? episode.length : 0,
    optimizerSteps: accepted ? 1 : 0, loss: update?.loss ?? null,
    durationMs: Math.round(performance.now() - started), sha256: saved.sha256,
    validation: path.join(directory, `validation-${rolloutSeq}.json`) }
}
function errorReceipt (message, error) {
  return { event: 'training_error', fighter: message.fighter, round: message.round,
    requestId: message.requestId, error: String(error.stack || error) }
}
function pump () {
  if (busy || failed || !queue.length) return
  busy = true
  const message = queue.shift()
  try { parentPort.postMessage(train(message)) }
  catch (error) {
    failed = true; parentPort.postMessage(errorReceipt(message, error))
    for (const waiting of queue.splice(0)) parentPort.postMessage(errorReceipt(waiting,
      'PPO worker halted after an earlier failed rollout; journal retained'))
  }
  busy = false; setImmediate(pump)
}
parentPort.on('message', message => {
  if (failed) parentPort.postMessage(errorReceipt(message, 'PPO worker halted; journal retained'))
  else { queue.push(message); setImmediate(pump) }
})
parentPort.postMessage({ event: 'trainer_ready', checkpoint: checkpointPath,
  dualUpdates: counters.dualUpdates || 0 })
