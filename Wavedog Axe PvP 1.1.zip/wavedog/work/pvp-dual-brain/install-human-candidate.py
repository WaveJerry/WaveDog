"""Promote a checked candidate only while the shared learner has no live bouts.

Restarts only the local model service. Never stops or changes the MC JVM/core.
"""
from pathlib import Path
from datetime import datetime
import hashlib, json, os, runpy, shutil, socket, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
command = runpy.run_path(str(ROOT / 'outputs/MC-Public/rcon_local.py'))['command']

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def service_processes():
    raw = subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
        "Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" | Where-Object { $_.CommandLine -like '*pvp-dual-brain*dual-service.js*' } | Select-Object ProcessId | ConvertTo-Json -Compress"],
        text=True, encoding='utf-8')
    if not raw.strip(): return []
    rows = json.loads(raw)
    return [rows] if isinstance(rows, dict) else rows

def main():
    candidate = Path(sys.argv[1]).resolve()
    receipt = json.loads((candidate / 'receipt.json').read_text())
    retention = json.loads((candidate / 'retention.json').read_text())
    if not receipt['offlineChecksPassed'] or not retention['retentionPassed']:
        raise RuntimeError('Candidate failed offline checks')
    proposed_bytes = (candidate / 'checkpoint.json').read_bytes()
    proposed = json.loads(proposed_bytes)
    live_bytes = (MODEL / 'checkpoint.json').read_bytes()
    live = json.loads(live_bytes)
    if live['sha256'] != receipt['sourceSha256'] or retention['candidateSha256'] != proposed['sha256']:
        raise RuntimeError('Live model changed since imitation; rebase training instead of losing updates')
    if Path(proposed['binary']).name != proposed['binary']:
        raise RuntimeError('Invalid candidate binary')
    if sha(candidate / proposed['binary']) != proposed['sha256']:
        raise RuntimeError('Candidate hash mismatch')
    latest_rollout = max(int(file.name.split('-')[1].split('.')[0])
        for file in (MODEL / 'rollouts').glob('rollout-*.json.gz'))
    if latest_rollout != live['counters']['lastRolloutSeq']:
        raise RuntimeError('PPO journal has uncommitted bouts; refusing service switch')
    status = command('selfplay status')
    if 'active=0' not in status or 'controller=false' not in status:
        raise RuntimeError('Selfplay controller is active: ' + status)
    players = command('list')
    if any(name in players for name in ('WaveDog', 'NBot', 'WPlayer')):
        raise RuntimeError('A combat bot is online; refusing to interrupt its bout')
    processes = service_processes()
    if len(processes) != 1:
        raise RuntimeError('Expected one explicitly identified model service')
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = MODEL / 'backups' / (stamp + '-before-human-imitation')
    backup.mkdir(parents=True)
    for file in (MODEL / 'checkpoint.json', MODEL / live['binary']):
        shutil.copy2(file, backup / file.name)
    logs = BASE / 'runtime/pvp-technique-20261115/imitation'
    stdout = logs / (stamp + '-service.out.log')
    stderr = logs / (stamp + '-service.err.log')
    node = shutil.which('node') or 'E:/node/node.exe'

    def launch():
        with stdout.open('ab') as out, stderr.open('ab') as err:
            return subprocess.Popen([node, str(BASE / 'dual-service.js'), str(MODEL / 'checkpoint.json')],
                cwd=BASE, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                creationflags=subprocess.CREATE_NO_WINDOW)

    subprocess.run(['taskkill.exe', '/PID', str(processes[0]['ProcessId']), '/T', '/F'],
        check=True, capture_output=True)
    process = None
    try:
        if (MODEL / 'checkpoint.json').read_bytes() != live_bytes:
            raise RuntimeError('Weights changed during shutdown; refusing stale candidate')
        target_binary = MODEL / proposed['binary']
        if target_binary.exists() and sha(target_binary) != proposed['sha256']:
            raise RuntimeError('Candidate binary name collision')
        if not target_binary.exists(): shutil.copy2(candidate / proposed['binary'], target_binary)
        temp = MODEL / 'checkpoint.installing.json'
        temp.write_bytes(proposed_bytes); os.replace(temp, MODEL / 'checkpoint.json')
        process = launch()
        print(json.dumps({'stage': 'model-service-started', 'pid': process.pid, 'backup': str(backup)}), flush=True)
        connected = None
        for _ in range(100):
            if process.poll() is not None: raise RuntimeError('Model service exited; see ' + str(stderr))
            try:
                connected = socket.create_connection(('127.0.0.1', 18766), timeout=1); break
            except OSError: time.sleep(.2)
        if connected is None: raise RuntimeError('Model service did not listen')
        connected.settimeout(60)
        reader = connected.makefile('r', encoding='utf-8')
        while True:
            line = reader.readline()
            if not line: raise RuntimeError('Service disconnected before readiness')
            row = json.loads(line)
            if row.get('event') == 'ready': break
            if row.get('event') in ('error', 'service_error'): raise RuntimeError(str(row))
        def send(row): connected.sendall((json.dumps(row) + '\n').encode())
        def receive(event):
            while True:
                line = reader.readline()
                if not line: raise RuntimeError('Service disconnected')
                row = json.loads(line)
                if row.get('event') in ('error', 'service_error'): raise RuntimeError(str(row))
                if row.get('event') == event: return row
        send({'command': 'model_status', 'requestId': 'human-candidate-install'})
        loaded = receive('model_status')
        if loaded['checkpointSha256'] != proposed['sha256']:
            raise RuntimeError('Service did not actually load trained weights')
        match = 'candidate-smoke-' + stamp
        send({'command': 'reset', 'fighter': 'ImitationProbe', 'opponent': 'ProbeTarget',
            'matchId': match, 'learning': False, 'role': 'current', 'focus': 'FREE'})
        send({'command': 'act', 'fighter': 'ImitationProbe', 'opponent': 'ProbeTarget',
            'matchId': match, 'requestId': 992001, 'tick': 1, 'focus': 'FREE', 'style': 'MIXED',
            'yaw': 0, 'pitch': 0,
            'self': {'x': 1050, 'y': 221, 'z': 952, 'eyeY': 222.62, 'vx': 0, 'vy': 0,
                'vz': 0, 'ground': True, 'critical': False, 'charge': 1, 'health': 20,
                'shieldAvailable': False, 'shielding': False, 'arrows': 0,
                'crossbowLoaded': False, 'using': False, 'useTicks': 0, 'held': 7},
            'seen': {'visible': True, 'x': 1050, 'y': 221, 'z': 955, 'yaw': 180,
                'shield': False, 'held': 'DIAMOND_AXE', 'using': False, 'swing': 0, 'arrows': []}})
        while True:
            line = reader.readline()
            if not line: raise RuntimeError('Service disconnected before probe')
            action = json.loads(line)
            if action.get('event') in ('error', 'service_error'): raise RuntimeError(str(action))
            if action.get('fighter') == 'ImitationProbe' and action.get('model') == 'DUAL-GRU-GTRXL': break
        if action.get('checkpointSha256') != proposed['sha256']:
            raise RuntimeError('Live inference used wrong weights')
        send({'command': 'discard', 'fighter': 'ImitationProbe'})
        receive('discarded_probe')
        reader.close(); connected.close()
        if (MODEL / 'checkpoint.json').read_bytes() != proposed_bytes:
            raise RuntimeError('Non-training probe unexpectedly changed the checkpoint')
        result = {'at': datetime.now().astimezone().isoformat(), 'candidate': str(candidate),
            'servicePid': process.pid, 'previousServicePid': processes[0]['ProcessId'],
            'backup': str(backup), 'checkpointSha256': proposed['sha256'],
            'loadedModelStatus': loaded, 'liveInference': action,
            'serverRestarted': False, 'serverCombatCoreChanged': False,
            'pvpMasteryVerified': False, 'selfplayStatus': command('selfplay status')}
        out = logs / (stamp + '-install-receipt.json')
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({'stage': 'model-loaded-and-inference-verified', 'receipt': str(out),
            'sha256': proposed['sha256'], 'serverRestarted': False}, ensure_ascii=False), flush=True)
    except Exception:
        if process and process.poll() is None:
            subprocess.run(['taskkill.exe', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
        # Restore the latest source snapshot; no raw records or old binaries are deleted.
        if (MODEL / 'checkpoint.json').read_bytes() == proposed_bytes:
            (MODEL / 'checkpoint.rollback.json').write_bytes(live_bytes)
            os.replace(MODEL / 'checkpoint.rollback.json', MODEL / 'checkpoint.json')
        launch()
        raise

if __name__ == '__main__': main()
