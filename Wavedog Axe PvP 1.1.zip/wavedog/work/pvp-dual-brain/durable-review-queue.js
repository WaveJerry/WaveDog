import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

// Persist on receipt, before the slow reviewer starts. Reloads may retry an
// unfinished review; they must never silently drop its complete raw frames.
export class DurableReviewQueue {
  constructor(directory, review) {
    this.directory = directory
    this.review = review
    this.tail = Promise.resolve()
    this.scheduled = new Set()
    fs.mkdirSync(directory, { recursive: true })
  }
  enqueue(row) {
    if (!row.matchId || !Array.isArray(row.frames)) throw Error('Invalid review job')
    const key = crypto.createHash('sha256').update(String(row.matchId)).digest('hex')
    const file = path.join(this.directory, key + '.json')
    if (!fs.existsSync(file)) {
      const temp = file + '.tmp'
      fs.writeFileSync(temp, JSON.stringify({ state: 'pending', receivedAt: new Date().toISOString(), row }))
      fs.renameSync(temp, file)
    }
    const saved = JSON.parse(fs.readFileSync(file))
    if (saved.state === 'completed' || this.scheduled.has(key)) return
    this.scheduled.add(key)
    this.tail = this.tail.then(async () => {
      try {
        const success = await this.review(saved.row)
        const result = { ...saved, state: success ? 'completed' : 'failed', attemptedAt: new Date().toISOString() }
        const temp = file + '.tmp'
        fs.writeFileSync(temp, JSON.stringify(result)); fs.renameSync(temp, file)
      } finally { this.scheduled.delete(key) }
    }).catch(() => { this.scheduled.delete(key) })
  }
  recover() {
    for (const name of fs.readdirSync(this.directory).filter(n => n.endsWith('.json'))) {
      const job = JSON.parse(fs.readFileSync(path.join(this.directory, name)))
      if (job.state === 'pending') this.enqueue(job.row)
    }
  }
}
