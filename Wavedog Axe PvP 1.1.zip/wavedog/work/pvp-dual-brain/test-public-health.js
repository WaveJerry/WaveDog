import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy, OBS_SIZE } from './fresh-policy.js'
import { SharedAdam, saveDualCheckpoint, loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { addPublicHealthInput } from './migrate-public-health.js'
import { publicHealthFeatures } from './public-health-features.js'
import { advance, disposeState } from './human-imitation.js'
await tf.setBackend('cpu'); await tf.ready()
const request = { opponent: 'Fighter', matchId: 'm', tick: 8, self: { x: 0, y: 0, z: 0 },
  seen: { visible: true, x: 2, y: 0, z: 0, publicHealth: { source: 'public-below-name-scoreboard',
    objective: 'wd_hearts', roundedUp: true, opponent: 'Fighter', matchId: 'm', observedTick: 7,
    healthUpper: 1, healthLowerExclusive: 0, absorptionKnown: false } } }
assert.deepEqual(publicHealthFeatures(request), [1, .05, 0, 0, 0])
assert.deepEqual(publicHealthFeatures({ ...request, matchId: 'other' }), [0, 0, 0, 0, 0])
assert.deepEqual(publicHealthFeatures({ ...request, seen: { ...request.seen, x: 11 } }), [0, 0, 0, 0, 0])
const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'health-migration-'))
const model = new DualPolicy({ fast: 8, slow: 16, heads: 2, layers: 1, ff: 32, interval: 2, memory: 4 })
const adam = new SharedAdam(model.params)
tf.tidy(() => adam.applyGradients(Object.fromEntries(model.params.map(p => [p.name, tf.fill(p.shape, .001)]))))
let loaded, migrated, roundtrip
try {
  const file = path.join(folder, 'old.json')
  saveDualCheckpoint(file, model, adam, { dualUpdates: 7 })
  loaded = loadDualCheckpoint(file); migrated = addPublicHealthInput(loaded)
  assert.equal(migrated.adam.steps, adam.steps)
  for (let i = 0; i < model.params.length; i++) {
    assert.deepEqual([...migrated.model.params[i].dataSync()], [...model.params[i].dataSync()])
    assert.deepEqual([...migrated.adam.first[i].dataSync()], [...adam.first[i].dataSync()])
    assert.deepEqual([...migrated.adam.second[i].dataSync()], [...adam.second[i].dataSync()])
  }
  for (const group of [migrated.model.params, migrated.adam.first, migrated.adam.second])
    assert([...group.at(-1).dataSync()].every(v => v === 0), 'new weight and Adam slots start at zero')
  let a = model.initialState(), b = migrated.model.initialState()
  try {
    for (let t = 0; t < 7; t++) {
      const obs = Array.from({ length: OBS_SIZE }, (_, i) => Math.sin(i + t) * .1)
      const left = advance(model, a, obs, true); a = left.state
      const right = advance(migrated.model, b, obs, true, null, [1, .05, 0, 1, 0]); b = right.state
      assert.deepEqual(right.logits, left.logits, 'migration must preserve the whole sequence behavior')
      assert.equal(right.value, left.value)
    }
  } finally { disposeState(a); disposeState(b) }
  tf.tidy(() => {
    const { grads, value } = tf.variableGrads(() => {
      const output = migrated.model.step(tf.zeros([1, OBS_SIZE]), null, null, [1, .05, 0, 1, 0])
      return tf.sum(output.logits[4])
    }, [migrated.model.publicHealthProjection])
    assert(Number.isFinite(value.dataSync()[0]))
    assert([...grads[migrated.model.publicHealthProjection.name].dataSync()].some(v => v !== 0), 'health must receive gradients')
    migrated.adam.applyGradients(grads)
  })
  const next = path.join(folder, 'new.json')
  saveDualCheckpoint(next, migrated.model, migrated.adam, migrated.counters)
  roundtrip = loadDualCheckpoint(next)
  assert.deepEqual([...roundtrip.model.publicHealthProjection.dataSync()], [...migrated.model.publicHealthProjection.dataSync()])
  assert.equal(roundtrip.counters.dualUpdates, 7)
  console.log('PUBLIC_HEALTH_MIGRATION_PASS: old weights, Adam, sequence outputs preserved; new input trainable')
} finally {
  for (const row of [loaded, migrated, roundtrip]) if (row) { row.adam.dispose(); row.model.dispose() }
  adam.dispose(); model.dispose()
  assert.equal(path.dirname(path.resolve(folder)), path.resolve(os.tmpdir()))
  assert(path.basename(folder).startsWith('health-migration-'))
  fs.rmSync(folder, { recursive: true, force: true })
}
