// Persistent coaching knowledge is separate from neural gradient updates.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { localReview } from './protocol-review.js'
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')
const output = path.join(root, 'outputs/learning-repair-20261116')
const coach = path.join(root, 'work/pvp-8.6-dual-fresh/model/coach')
const file = path.join(coach, 'operator-critical-defense.json')
const original = fs.readFileSync(file)
fs.writeFileSync(path.join(output, 'before/operator-critical-defense.json'), original)
const knowledge = {
  at: new Date().toISOString(), priorityPlayers: ['jifengoqk', 'wasplan', 'YarmWino'],
  intent: '保留已有近战成果，学习真实优秀对局；所有建议都是情境策略，不能变成机械强制动作。',
  principles: [
    'wasplan：合法射程按眼睛到碰撞箱算。地面入距先手、击退后跟位再入距、被连后抓真实反打或后撤断连；不固定在3格外永退，不恢复机械自动极限出刀。',
    'jifengoqk与YarmWino：贴近连续换血可多试钻石剑，比较剑连击和真实下落剑暴击的净换血，避免持慢斧白吃剑的持续输出。',
    '边界平A或对方上升期可争取击退打断；对方已下落进入暴击窗口时，评估躲避与安全反击，不能默认平A换暴击。惩罚暴击需要落下时仍能命中；将出距就及时止损。',
    '真实暴击要求下落等原生条件，出刀前松疾跑；普通击退连招可重置疾跑。仅有动画或负vy不能认定已暴击；跳跃重置的输入时机必须有原生受击与动作证据。',
    '切斧起手、随后切剑续攻，及剑连遇有效盾切斧破盾，是两种不同选择；计入换武器的蓄力重置，不预设剑速斧伤，也不恢复强制破盾。',
    '蓄力增长到满后封顶；普通连点与空挥须计成本，但抢断连招、临界出距补刀、可见残血抢杀可以比较轻击收益，不能用统一满蓄力门槛堵住出刀。',
    '机械持盾、盾反撤离和弓弩躲箭单独归因；自由近战只由共享GRU/GTrXL策略选动作。Qwen复盘不等于神经权重学习。'
  ],
  evidence: JSON.parse(fs.readFileSync(path.join(output, 'expert-data/selection.json'), 'utf8')),
  forbiddenClaims: ['移动轨迹证明W-tap按键', '下落命中必为暴击', '提示词已写入所以技法掌握', '少量离线误差下降等于真人胜率提高']
}
fs.writeFileSync(path.join(output, 'expert-teaching.json'), JSON.stringify(knowledge, null, 2))
const teaching = JSON.parse(original)
teaching.expertRepairPriority = knowledge
fs.writeFileSync(path.join(output, 'prepared-operator-critical-defense.json'), JSON.stringify(teaching, null, 2))
const answer = await localReview([
  { role: 'system', content: '你是WaveDog本地PVP教练。依据证据提出一个可检验训练目标。重点jifengoqk、wasplan、YarmWino。不要声称已学会，不要把猜测当按键或伤害事实。只输出规定JSON。' },
  { role: 'user', content: JSON.stringify(knowledge) }
])
const receipt = { at: new Date().toISOString(), scope: 'expert-methodology-and-selected-bout-statistics',
  fullRawFramesReviewedByThisCall: false, neuralWeightsUpdatedByThisCall: false,
  teachingSha256: crypto.createHash('sha256').update(JSON.stringify(knowledge)).digest('hex'), ...answer }
fs.writeFileSync(path.join(output, 'qwen-expert-review.json'), JSON.stringify(receipt, null, 2))
console.log(JSON.stringify(receipt))
