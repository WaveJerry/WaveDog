"""Copy a hash-verified live checkpoint without modifying or stopping it."""
from pathlib import Path
from datetime import datetime
import hashlib, json

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'work/pvp-8.6-dual-fresh/model/checkpoint.json'
DEST = ROOT / 'work/pvp-dual-brain/runtime/pvp-technique-20261115/imitation' / ('source-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
for attempt in range(5):
    manifest_bytes = SOURCE.read_bytes()
    manifest = json.loads(manifest_bytes)
    name = manifest['binary']
    if Path(name).name != name:
        raise ValueError('Unexpected checkpoint binary path')
    try:
        payload = SOURCE.with_name(name).read_bytes()
    except FileNotFoundError:
        continue
    if SOURCE.read_bytes() != manifest_bytes:
        continue
    if len(payload) != manifest['bytes'] or hashlib.sha256(payload).hexdigest() != manifest['sha256']:
        raise ValueError('Checkpoint failed hash verification')
    DEST.mkdir(parents=True)
    (DEST / name).write_bytes(payload)
    (DEST / 'checkpoint.json').write_bytes(manifest_bytes)
    print(json.dumps({'checkpoint': str(DEST / 'checkpoint.json'), 'sha256': manifest['sha256'], 'counters': manifest['counters']}))
    break
else:
    raise RuntimeError('Live checkpoint kept changing; no snapshot written')
