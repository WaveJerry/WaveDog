// Sparse native-event imitation. Human records are never passed off as PPO.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { pathToFileURL } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE, ACTION_WIDTHS, biasedActionLogits, maskActionLogits } from './fresh-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { attackSituation, exchangeAttackWeights } from './exchange-imitation-weights.js'
import {publicThreatFeatures}from './public-threat-features.js'

export function stateTensors (state) {
  return [...new Set([state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])].filter(Boolean))]
}
export function disposeState (state, retained = null) {
  const keep = new Set(retained ? stateTensors(retained) : [])
  for (const tensor of stateTensors(state)) if (!keep.has(tensor)) tensor.dispose()
}
export function advance (model, state, observation, capture = false, masks = null, health = null, spatial = null, threat = null, motion = null) {
  const out = tf.tidy(() => {
    const output = model.step(tf.tensor2d([observation], [1, OBS_SIZE]), state, masks, health, spatial, threat, motion)
    return { state: output.state, ...(capture ? {
      logits: maskActionLogits(output.logits, masks).map(head => [...head.dataSync()]),
      value: output.value.dataSync()[0], gate: [...output.gate.dataSync()]
    } : {}) }
  })
  disposeState(state, out.state)
  return out
}
// Supervise and audit the SAME distribution used by the live actor. In v1,
// raw network logits omit the contextual curriculum and can reward a change
// that makes the actually deployed attack/weapon policy worse.
export function deployedImitationLogits (model, logits, frame) {
  const version = model.config.distributionVersion || 1
  const actions = frame.actions || Object.assign(Array(9).fill(0), {
    5: frame.attackWeaponAction ?? frame.labels?.['5'] ?? (frame.observation[12] < .25 ? 1 : 0) })
  return maskActionLogits(biasedActionLogits(logits, frame.observation,
    { ...frame.context, distributionVersion: version, behaviorPriorVersion:model.config.behaviorPriorVersion,
      weaponConditionedAttack: model.config.weaponConditionedAttack || 0,
      actionConditionedAttack:model.config.actionConditionedAttack||0,
      ...(version >= 3 ? { calibratedHeads: model.config.calibratedHeads || [2, 5] } : {}) }, actions,
    model, frame.publicHealthFeatures), frame.legalMasks)
}
export function captureDeployedImitation (model, output, frame) {
  return { ...output, logits: tf.tidy(() => deployedImitationLogits(model,
    output.logits.map(head => tf.tensor2d([head])), frame).map(head => [...head.dataSync()])) }
}
const logSoftmax = values => {
  const largest = Math.max(...values)
  const normalizer = largest + Math.log(values.reduce((sum, value) => sum + Math.exp(value - largest), 0))
  return values.map(value => value - normalizer)
}
export function validateDataset (dataset) {
  if (dataset.schema !== 'public-human-imitation-v1' || dataset.ppoEligible !== false)
    throw Error('Only explicitly non-PPO human demonstrations accepted')
  if (!dataset.trajectories?.length) throw Error('Full ordered trajectories required')
  const splitByMatch = new Map(), sources = new Set()
  const counts = { train: {}, validation: {} }
  for (const trace of dataset.trajectories) {
    if (!['train', 'validation'].includes(trace.split) || !trace.matchId || sources.has(trace.source))
      throw Error('Invalid or repeated source')
    sources.add(trace.source)
    // Recorder IDs include observer UUIDs. Pair both perspectives by run/tick
    // and unordered participants, so a second view cannot leak into training.
    const encounter = trace.source.match(/^(\d+-\d+)-/)
    const matchKey = encounter && trace.fighter && trace.opponent
      ? encounter[1] + ':' + [trace.fighter, trace.opponent].sort().join(':') : trace.matchId
    if (splitByMatch.has(matchKey) && splitByMatch.get(matchKey) !== trace.split)
      throw Error('Whole-match train/validation leakage')
    splitByMatch.set(matchKey, trace.split)
    let previous = -Infinity
    for (const frame of trace.frames) {
      if(dataset.policyObservationConfig?.publicThreatInputs===12&&
          JSON.stringify(frame.publicThreatFeatures)!==JSON.stringify(publicThreatFeatures(frame.publicRequest)))
        throw Error('Threat input must match the same causal public request')
      if (!Number.isSafeInteger(frame.tick) || frame.tick <= previous
          || frame.observation.length !== OBS_SIZE || !frame.observation.every(Number.isFinite))
        throw Error('Invalid causal observation sequence')
      previous = frame.tick
      for (const [head, action] of Object.entries(frame.labels)) {
        const reliableBot = trace.sourceKind === 'executed-bot-retention'
          && typeof trace.sourceSha256 === 'string' && trace.sourceSha256.length === 64
        const exactTeacher=trace.sourceKind==='exact-script-demonstration'&&trace.sourceSha256?.length===64
          &&frame.labelEvidence?.includes('exact-recorded-client-controls-and-packets')
        const daggerTeacher=trace.sourceKind==='dagger-expert-relabel'
          && trace.sourceSha256?.length===64 && trace.expertSourceSha256?.length===64
          && trace.observationsFromLearner===true && frame.ppoEligible===false
          && frame.labelEvidence?.includes('offline-expert-on-actual-learner-state')
        const taughtSprint = trace.sourceKind === 'operator-guidance' && head === '1' && action === 0
          && frame.labelEvidence?.includes('operator-stop-sprint-before-native-confirmed-critical')
        const nativeJump = head === '2' && action === 1
          && (frame.labelEvidence?.includes('native-jump-leading-to-confirmed-sword-critical')
            || frame.labelEvidence?.includes('ordered-native-jump-with-grounded-observation'))
        const nativeCriticalSprint = head === '1' && action === 0
          && frame.labelEvidence?.includes('native-confirmed-sword-critical')
        const nativeLook = ['6','7'].includes(head) && Number.isInteger(action)
          && action>=0 && action<ACTION_WIDTHS[Number(head)]
          && (frame.labelEvidence?.includes('consecutive-public-view-delta-within-quantization-tolerance')
            || frame.labelEvidence?.includes('public-view-relative-to-visible-hitbox'))
        const nativeState = head==='1'&&[0,1].includes(action)
          && frame.labelEvidence?.includes('consecutive-native-resulting-sprint-state')
          || head==='2'&&action===0&&frame.labelEvidence?.includes('consecutive-grounded-without-native-jump')
        const nativeWeapon = head==='5'&&[0,1].includes(action)
          && frame.labelEvidence?.includes('public-selected-melee-weapon')
        const nativeWeaponTransition = head==='5'&&[0,1,4].includes(action)
          && frame.labelEvidence?.includes('consecutive-native-melee-weapon-choice')
        if (!((reliableBot||exactTeacher||daggerTeacher) && Number.isInteger(action) && action >= 0 && action < ACTION_WIDTHS[Number(head)]
            || taughtSprint || nativeJump || nativeCriticalSprint || nativeLook || nativeState || nativeWeapon || nativeWeaponTransition
            || head === '4' && [0, 2].includes(action) || head === '5' && [0, 1].includes(action)))
          throw Error('Unsupported or fabricated human label')
        if (frame.legalMasks?.[head]?.[action] === false) throw Error('Illegal demonstration label')
        counts[trace.split][head] = (counts[trace.split][head] || 0) + 1
      }
    }
  }
  if (!Object.keys(counts.train).length || !Object.keys(counts.validation).length)
    throw Error('Need separate training and validation evidence')
  return counts
}
function distributionKL (before, after) {
  const p = logSoftmax(before), q = logSoftmax(after)
  return Math.max(0, p.reduce((sum, value, i) => sum + Math.exp(value) * (value - q[i]), 0))
}
export function imitationLoss (model, segment, initialState, weights) {
  let state = initialState
  const supervised = [], auxiliary = [], anchors = []
  for (const frame of segment) {
    const output = model.step(tf.tensor2d([frame.observation], [1, OBS_SIZE]), state, frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures)
    state = output.state
    const deployed = deployedImitationLogits(model, output.logits, frame)
    for (const [key, action] of Object.entries(frame.labels)) {
      const head = Number(key)
      const conditional=key==='4'&&weights.exchangeAttack?.weights[attackSituation(frame)]?.[action]
      const weight = (conditional!==false&&typeof conditional==='number'
        ? weights[key]*conditional : (weights[`${key}:${action}`] ?? weights[key])) * (frame.supervisionWeight ?? 1)
      supervised.push(tf.mul(weight, tf.neg(tf.sum(tf.mul(
        tf.oneHot([action], deployed[head].shape[1]), tf.logSoftmax(deployed[head]))))))
      // Mixture-only CE can recover by ignoring a saturated branch. Give each
      // branch direct native-event supervision, without inventing unknown keys.
      if (model.config.distributionVersion >= 2 && (model.config.distributionVersion === 2
          || (model.config.calibratedHeads || [2, 5]).includes(head))) for (const branch of [output.fastLogits, output.slowLogits]) {
        const logits = maskActionLogits(branch, frame.legalMasks)[head]
        auxiliary.push(tf.mul(.01 * weight, tf.neg(tf.sum(tf.mul(
          tf.oneHot([action], logits.shape[1]), tf.logSoftmax(logits))))))
      }
    }
    // Anchor every real frame, including heads whose human intent is unknown.
    // A frozen reference supplies distributions, never invented button labels.
    for (const [head, logits] of deployed.entries()) {
      const reference = tf.tensor2d([frame.reference.logits[head]])
      const logP = tf.logSoftmax(reference)
      const kl = tf.sum(tf.mul(tf.exp(logP), tf.sub(logP, tf.logSoftmax(logits))))
      const adapted = weights.adaptedHeads?.includes(head)
      const anchorWeight = adapted && weights.adaptedHeadAnchor !== undefined
        ? weights.adaptedHeadAnchor : head in frame.labels ? .15 : 2
      anchors.push(tf.mul(anchorWeight, kl))
    }
    anchors.push(tf.mul(.05, tf.square(tf.sub(tf.squeeze(output.value), frame.reference.value))))
  }
  return tf.add(supervised.length ? tf.mean(tf.stack(supervised)) : tf.scalar(0),
    tf.add(auxiliary.length ? tf.mean(tf.stack(auxiliary)) : tf.scalar(0), tf.mean(tf.stack(anchors))))
}
export function imitationUpdate (model, optimizer, segment, initialState, weights) {
  return tf.tidy(() => {
    const { value, grads } = tf.variableGrads(
      () => imitationLoss(model, segment, initialState, weights), optimizer.parameters)
    const gradientNorm = Math.sqrt(tf.addN(Object.values(grads).map(g => tf.sum(tf.square(g)))).dataSync()[0])
    if (!Number.isFinite(value.dataSync()[0]) || !Number.isFinite(gradientNorm))
      throw Error('Non-finite imitation loss/gradient')
    const scale = Math.min(1, 1 / Math.max(gradientNorm, 1e-12))
    optimizer.applyGradients(Object.fromEntries(Object.entries(grads).map(([key, grad]) => [key, tf.mul(grad, scale)])))
    return { loss: value.dataSync()[0], gradientNorm }
  })
}
const parameterGroup = variable => variable.name.replace(/^dual\d+\./, '').split('.')[0]
function parameterAudit (model, baseline) {
  const groups = {}
  for (let i = 0; i < model.params.length; i++) {
    const name = parameterGroup(model.params[i]), left = baseline.params[i].dataSync(), right = model.params[i].dataSync()
    const item = groups[name] ||= { parameters: 0, changed: 0, squaredDelta: 0, maxAbsDelta: 0 }
    for (let j = 0; j < left.length; j++) {
      const delta = right[j] - left[j]
      item.parameters++; if (delta !== 0) item.changed++
      item.squaredDelta += delta * delta
      item.maxAbsDelta = Math.max(item.maxAbsDelta, Math.abs(delta))
    }
  }
  for (const item of Object.values(groups)) {
    item.rmsDelta = Math.sqrt(item.squaredDelta / item.parameters); delete item.squaredDelta
  }
  return groups
}
export function accumulate (stats, frame, result, reference = null) {
  for (const [head, action] of Object.entries(frame.labels)) {
    const logP = logSoftmax(result.logits[head])
    const key = `${head}:${action}`
    const item = stats.labels[key] ||= { count: 0, nll: 0, probability: 0, correct: 0 }
    item.count++; item.nll -= logP[action]; item.probability += Math.exp(logP[action])
    item.correct += logP.indexOf(Math.max(...logP)) === action ? 1 : 0
  }
  if (Object.hasOwn(frame.labels, '4')) {
    const x = frame.observation
    const phase = x[2] > .5 ? 'ground' : x[4] >= 0 ? 'rising' : 'falling'
    const charge = x[1] < .4 ? 'low-charge' : x[1] < .85 ? 'charging' : 'charged'
    const weapon = x[12] < .25 ? 'sword' : x[12] > .7 ? 'axe' : 'other'
    const key = [weapon, phase, charge, x[97] <= 0 ? 'in-reach' : 'out-of-reach'].join(':')
    const logP = logSoftmax(result.logits[4])
    const probability = Math.exp(logP[2])
    const observed = frame.labels['4'] === 2 ? 1 : 0
    const bucket = (stats.attackCadence ||= {})[key] ||= {
      frames: 0, observedAttacks: 0, predictedAttacks: 0, greedyAttacks: 0, brier: 0 }
    bucket.frames++; bucket.observedAttacks += observed; bucket.predictedAttacks += probability
    bucket.greedyAttacks += logP.indexOf(Math.max(...logP)) === 2 ? 1 : 0
    bucket.brier += (probability - observed) ** 2
  }
  if (reference) for (let head = 0; head < result.logits.length; head++) {
    const kl = distributionKL(reference.logits[head], result.logits[head])
    const item = stats.drift[head] ||= { frames: 0, sum: 0, max: 0 }
    item.frames++; item.sum += kl; item.max = Math.max(item.max, kl)
  }
}
export function finishStats (stats) {
  let nll = 0, count = 0
  for (const item of Object.values(stats.labels)) {
    nll += item.nll; count += item.count
    item.nll /= item.count; item.probability /= item.count; item.accuracy = item.correct / item.count
    delete item.correct
  }
  stats.meanNll = count ? nll / count : null
  stats.macroNll = Object.values(stats.labels).length
    ? Object.values(stats.labels).reduce((sum,item) => sum + item.nll, 0) / Object.keys(stats.labels).length : null
  for (const item of Object.values(stats.drift)) { item.mean = item.sum / item.frames; delete item.sum }
  for (const item of Object.values(stats.attackCadence || {})) {
    item.observedRate = item.observedAttacks / item.frames
    item.predictedRate = item.predictedAttacks / item.frames
    item.greedyRate = item.greedyAttacks / item.frames
    item.brier /= item.frames
  }
  return stats
}
export function imitationClassWeights (dataset, counts, frequencyHeads = []) {
  const classCounts = {}
  for (const trace of dataset.trajectories.filter(t => t.split === 'train'))
    for (const frame of trace.frames) for (const [head, action] of Object.entries(frame.labels)) {
      const item = classCounts[head] ||= {}
      item[action] = (item[action] || 0) + (frame.supervisionWeight ?? 1)
    }
  const headTotals = Object.fromEntries(Object.entries(classCounts)
    .map(([head, classes]) => [head, Object.values(classes).reduce((a, b) => a + b, 0)]))
  const total = Object.values(headTotals).reduce((a, b) => a + b, 0)
  const weights = {}
  for (const [head, classes] of Object.entries(classCounts)) {
    const headBalance = total / (Object.keys(headTotals).length * headTotals[head])
    weights[head] = headBalance
    for (const [action, count] of Object.entries(classes))
      // Preserve head balance when adding within-head class balance. Replacing
      // it with class balance alone silently starves rare native jump labels.
      weights[`${head}:${action}`] = frequencyHeads.includes(Number(head)) ? headBalance
        : headBalance * headTotals[head] / (Object.keys(classes).length * count)
  }
  return { weights, classCounts }
}
async function main () {
  const [sourceArg, datasetArg, destinationArg] = process.argv.slice(2)
  if (!sourceArg || !datasetArg || !destinationArg) throw Error('Usage: human-imitation.js SOURCE DATASET NEW_FOLDER')
  const source = path.resolve(sourceArg), destination = path.resolve(destinationArg)
  if (destination === path.dirname(source) || fs.existsSync(path.join(destination, 'checkpoint.json')))
    throw Error('Candidate destination must be new and isolated from source')
  const datasetBytes = fs.readFileSync(datasetArg), dataset = JSON.parse(datasetBytes)
  const counts = validateDataset(dataset)
  fs.mkdirSync(destination, { recursive: true })
  const log = row => {
    const line = JSON.stringify({ at: new Date().toISOString(), ...row })
    fs.appendFileSync(path.join(destination, 'training-events.jsonl'), line + '\n'); console.log(line)
  }
  await tf.setBackend('cpu'); await tf.ready()
  const candidate = loadDualCheckpoint(source), reference = loadDualCheckpoint(source)
  const { model } = candidate
  const version = Number(process.env.IMITATION_DISTRIBUTION_VERSION || model.config.distributionVersion || 1)
  model.config.distributionVersion = version
  reference.model.config.distributionVersion = version
  if (process.env.IMITATION_WEAPON_CONDITIONING !== undefined) {
    const conditioning = Number(process.env.IMITATION_WEAPON_CONDITIONING)
    if (![0, 1, 2].includes(conditioning)) throw Error('Invalid weapon conditioning version')
    if (conditioning === 2 && !model.config.actionContextHeads?.includes(4))
      throw Error('Learned weapon conditioning requires the attack context')
    model.config.weaponConditionedAttack = reference.model.config.weaponConditionedAttack = conditioning
  }
  if (version < 2 && dataset.trajectories.some(trace => trace.frames.some(frame =>
    !Number.isSafeInteger(frame.context?.entryCurriculum))))
    throw Error('Version-1 imitation requires the causal live actor context on every frame')
  if (version >= 2) {
    const calibratedHeads = JSON.parse(process.env.IMITATION_CALIBRATED_HEADS || '[4,5]')
    model.config.calibratedHeads = calibratedHeads
    reference.model.config.calibratedHeads = calibratedHeads
  }
  const supervisedHeads = Object.keys(counts.train).map(Number)
  const headsOnly = process.env.IMITATION_HEADS_ONLY === '1'
  const contextOnly=process.env.IMITATION_CONTEXT_ONLY==='1'
  if(contextOnly&&!model.actionContextIn)throw Error('Context-only training requires migrated contextual heads')
  const contextHeads = JSON.parse(process.env.IMITATION_CONTEXT_HEADS || 'null')
  if (contextHeads !== null && (!Array.isArray(contextHeads) || contextHeads.some(h =>
    !model.config.actionContextHeads?.includes(h)))) throw Error('Invalid contextual training heads')
  const trainable = contextOnly ? [] : [...(headsOnly ? [] : [model.fast, model.slowToken, ...model.slowBlocks]),
    ...supervisedHeads.map(h => model.fastHeads[h]), ...supervisedHeads.map(h => model.slowHeads[h]),
    ...(headsOnly ? [] : [model.gateIn]), model.gateOut].flatMap(layer => layer.params)
  if (model.publicHealthProjection && !headsOnly && !contextOnly) trainable.push(model.publicHealthProjection)
  if (model.actionContextIn) trainable.push(...model.actionContextIn.params,
    ...model.actionContextOut.filter((_, i) => contextHeads === null
      || contextHeads.includes(model.config.actionContextHeads[i])).flatMap(layer => layer.params))
  const optimizer = new SharedAdam(trainable, { learningRate: Number(process.env.IMITATION_LR || .000003) })
  // Preserve previously learned representations while adapting the two
  // demonstrated action heads. Gate columns for unknown actions stay frozen.
  const backboneRate = Number(process.env.IMITATION_BACKBONE_RATE || .01)
  optimizer.parameterLearningRates = new Map([model.fast, model.slowToken,
    ...model.slowBlocks, model.gateIn].flatMap(layer => layer.params)
    .map(parameter => [parameter.name, backboneRate]))
  const gateMask = tf.tensor1d(ACTION_WIDTHS.map((_, h) => supervisedHeads.includes(h) ? 1 : 0))
  for (const parameter of model.gateOut.params)
    optimizer.parameterLearningRates.set(parameter.name, gateMask)
  if(model.actionContextIn)for(const parameter of [model.actionContextIn,...model.actionContextOut].flatMap(layer=>layer.params))
    optimizer.parameterLearningRates.set(parameter.name,Number(process.env.IMITATION_CONTEXT_RATE || 1))
  const beforeStats = { train: { labels: {}, drift: {} }, validation: { labels: {}, drift: {} } }
  const afterStats = structuredClone(beforeStats)
  // Per-frame attack sampling needs its real event frequency. Equalizing rare
  // hits with every quiet cooldown frame can teach repeated low-charge clicks.
  // Other curricula (e.g. rare weapon switches) retain class balancing.
  const frequencyHeads = JSON.parse(process.env.IMITATION_FREQUENCY_HEADS || '[]')
  if (!Array.isArray(frequencyHeads) || frequencyHeads.some(h => !Number.isInteger(h) || h < 0 || h >= ACTION_WIDTHS.length))
    throw Error('Invalid frequency heads')
  const { weights, classCounts } = imitationClassWeights(dataset, counts, frequencyHeads)
  const headMultipliers=JSON.parse(process.env.IMITATION_HEAD_WEIGHTS||'{}')
  for(const [head,multiplier]of Object.entries(headMultipliers)){
    if(!Number.isFinite(multiplier)||multiplier<=0||multiplier>10)throw Error('Invalid head loss multiplier')
    for(const key of Object.keys(weights))if(key===head||key.startsWith(head+':'))weights[key]*=multiplier
  }
  if(process.env.IMITATION_EXCHANGE_BALANCE==='1')weights.exchangeAttack=exchangeAttackWeights(dataset)
  if(process.env.IMITATION_ADAPTED_ANCHOR!==undefined){
    const anchor=Number(process.env.IMITATION_ADAPTED_ANCHOR)
    if(!Number.isFinite(anchor)||anchor<0||anchor>2)throw Error('Invalid adapted-head anchor')
    weights.adaptedHeadAnchor=anchor
    weights.adaptedHeads=JSON.parse(process.env.IMITATION_ADAPTED_HEADS || 'null')
      || model.config.calibratedHeads || [2,5]
    if (!Array.isArray(weights.adaptedHeads) || weights.adaptedHeads.some(h =>
      !Number.isSafeInteger(h) || h < 0 || h >= ACTION_WIDTHS.length)) throw Error('Invalid adapted heads')
  }
  const updates = [], sourceHash = candidate.manifest.sha256
  try {
    // The reference sees every tick, retaining whole-bout recurrent memory.
    // Both perspectives of the held-out match remain outside gradient updates.
    for (const trace of dataset.trajectories) {
      let state = reference.model.initialState()
      try {
        for (const frame of trace.frames) {
          const raw = advance(reference.model, state, frame.observation, true, frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures); state = raw.state
          const output = captureDeployedImitation(reference.model, raw, frame)
          frame.reference = { logits: output.logits, value: output.value, gate: output.gate }
          accumulate(beforeStats[trace.split], frame, output)
        }
      } finally { disposeState(state) }
      log({ stage: 'baseline-replay', source: trace.source, frames: trace.frames.length, split: trace.split })
    }
    const epochs = Number(process.env.IMITATION_EPOCHS || 1)
    if (!Number.isSafeInteger(epochs) || epochs < 1 || epochs > 12) throw Error('Invalid imitation epochs')
    for (let epoch = 0; epoch < epochs; epoch++) for (const trace of dataset.trajectories.filter(trace => trace.split === 'train')) {
      let state = model.initialState()
      try {
        for (let start = 0; start < trace.frames.length; start += 16) {
          const part = trace.frames.slice(start, start + 16)
          const labeled = part.some(frame => Object.keys(frame.labels).length)
          if (labeled || start % 128 === 0) {
            const update = imitationUpdate(model, optimizer, part, state, weights)
            updates.push({ epoch, source: trace.source, start, end: start + part.length,
              labels: part.reduce((sum, frame) => sum + Object.keys(frame.labels).length, 0), ...update })
          }
          for (const frame of part) state = advance(model, state, frame.observation, false, frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures).state
        }
      } finally { disposeState(state) }
      log({ stage: 'imitation-training', epoch, source: trace.source, updates: updates.length })
    }
    for (const trace of dataset.trajectories) {
      let state = model.initialState()
      try {
        for (const frame of trace.frames) {
          const raw = advance(model, state, frame.observation, true, frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures); state = raw.state
          const output = captureDeployedImitation(model, raw, frame)
          accumulate(afterStats[trace.split], frame, output, frame.reference)
        }
      } finally { disposeState(state) }
      log({ stage: 'candidate-replay', source: trace.source, frames: trace.frames.length })
    }
    for (const stats of [beforeStats, afterStats]) for (const split of ['train', 'validation']) finishStats(stats[split])
    const audit = parameterAudit(model, reference.model)
    const changedFast = audit.fast?.changed > 0 || headsOnly
      && Object.entries(audit).some(([name, item]) => name.startsWith('fast-head-') && item.changed > 0)
    const changedSlow = Object.entries(audit).some(([name, item]) => name.startsWith('slow-') && item.changed > 0)
    const validationImproved = afterStats.validation.macroNll < beforeStats.validation.macroNll
      && (!beforeStats.validation.labels['4:2'] ||
        (contextOnly ? afterStats.validation.labels['4:2'].nll <= beforeStats.validation.labels['4:2'].nll+1e-6
          : afterStats.validation.labels['4:2'].nll < beforeStats.validation.labels['4:2'].nll))
    const unrelatedHeads = Array.from({ length: ACTION_WIDTHS.length }, (_, h) => h)
      .filter(h => !Object.hasOwn(counts.train, String(h)))
    const driftOK = unrelatedHeads.every(head => afterStats.validation.drift[head].mean < .02)
    const labelsBySource = {}
    for (const trace of dataset.trajectories.filter(t => t.split === 'train')) {
      const kind = trace.sourceKind || 'native-human-events'
      labelsBySource[kind] = (labelsBySource[kind] || 0)
        + trace.frames.reduce((sum,f) => sum + Object.keys(f.labels).length,0)
    }
    const counters = { ...candidate.counters,
      humanImitationUpdates: (candidate.counters.humanImitationUpdates || 0) + updates.length,
      humanImitationNativeLabels: (candidate.counters.humanImitationNativeLabels || 0)
        + (labelsBySource['native-human-events'] || 0),
      botRetentionLabels: (candidate.counters.botRetentionLabels || 0)
        + (labelsBySource['executed-bot-retention'] || 0),
      operatorPreferenceLabels: (candidate.counters.operatorPreferenceLabels || 0)
        + (labelsBySource['operator-guidance'] || 0),
      humanImitationSourceSha256: sourceHash }
    // Keep original PPO Adam moments/counter. Imitation uses its own optimizer.
    const saved = saveDualCheckpoint(path.join(destination, 'checkpoint.json'), model, candidate.adam, counters)
    const receipt = { schema: 'human-imitation-receipt-v1', at: new Date().toISOString(), source,
      sourceSha256: sourceHash, datasetSha256: crypto.createHash('sha256').update(datasetBytes).digest('hex'),
      supervisedDistribution: 'live-actor-with-context-and-legality-masks', distributionVersion: version, behaviorPriorVersion:model.config.behaviorPriorVersion,
      saved, counts, classCounts, labelsBySource, classWeights: weights, before: beforeStats, after: afterStats, parameterAudit: audit,
      updates, imitationOptimizer: { learningRate: optimizer.learningRate, backboneRate, steps: optimizer.steps,
        separateFromPPO: true, headsOnly, contextOnly, contextHeads, frequencyHeads },
      ppoCountersPreserved: candidate.counters.dualUpdates === counters.dualUpdates,
      checks: { changedFast, changedSlow, validationImproved, unrelatedHeadDriftOK: driftOK },
      representationUpdate: { gruBackbone: audit.fast?.changed > 0,
        transformerBackbone: Object.entries(audit).some(([name,item]) => /^slow-\d+$/.test(name) && item.changed > 0),
        outputHeadsOnly: headsOnly,contextualHeadsOnly:contextOnly },
      offlineChecksPassed: (contextOnly
        ? Object.entries(audit).some(([name,item])=>name.startsWith('action-context-')&&item.changed>0)
        : changedFast && changedSlow) && validationImproved && driftOK,
      livePvpImprovementVerified: false, sourceCheckpointOverwritten: false }
    fs.writeFileSync(path.join(destination, 'receipt.json'), JSON.stringify(receipt, null, 2))
    log({ stage: 'complete', checkpoint: saved.manifest, checks: receipt.checks,
      validationBefore: beforeStats.validation.meanNll, validationAfter: afterStats.validation.meanNll,
      ppoUpdates: counters.dualUpdates, humanImitationUpdates: updates.length })
  } finally {
    gateMask.dispose(); optimizer.dispose(); candidate.adam.dispose(); reference.adam.dispose()
    model.dispose(); reference.model.dispose()
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href)
  main().catch(error => { console.error(error.stack || error); process.exitCode = 1 })
