import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './fresh-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'

export function addPublicHealthInput (loaded) {
  if (loaded.model.config.publicHealthInputs) throw Error('Health input already present')
  const model = new DualPolicy({ ...loaded.model.config, publicHealthInputs: 5 }, loaded.model.gateMode)
  const adam = new SharedAdam(model.params, loaded.manifest.optimizer)
  adam.steps = loaded.adam.steps
  for (let i = 0; i < loaded.model.params.length; i++) {
    model.params[i].assign(loaded.model.params[i])
    for (const key of ['first', 'second']) {
      adam[key][i].dispose()
      adam[key][i] = loaded.adam[key][i].clone()
    }
  }
  return { model, adam, counters: { ...loaded.counters, publicHealthInputVersion: 1,
    publicHealthMigrationSource: loaded.manifest.sha256 } }
}
export function addActionContextInput (loaded) {
  if (loaded.model.config.actionContextHeads)throw Error('Contextual action inputs already present')
  const model=new DualPolicy({...loaded.model.config,actionContextHeads:[2,5]},loaded.model.gateMode)
  const adam=new SharedAdam(model.params,loaded.manifest.optimizer);adam.steps=loaded.adam.steps
  for(let i=0;i<loaded.model.params.length;i++){
    model.params[i].assign(loaded.model.params[i])
    for(const key of ['first','second']){adam[key][i].dispose();adam[key][i]=loaded.adam[key][i].clone()}
  }
  return {model,adam,counters:{...loaded.counters,actionContextInputVersion:1,
    actionContextMigrationSource:loaded.manifest.sha256}}
}
export function addAttackContextOutput (loaded, features = null) {
  if (JSON.stringify(loaded.model.config.actionContextHeads) !== '[2,5]')
    throw Error('Need the existing jump/weapon context; do not replace a trained attack context')
  // Append a zero readout to the SAME contextual encoder. Existing parameter
  // indices, weights, PPO moments and all output distributions stay exact.
  const model = new DualPolicy({ ...loaded.model.config, actionContextHeads: [2, 5, 4],
    ...(features ? { attackContextFeatures: features } : {}) }, loaded.model.gateMode)
  const adam = new SharedAdam(model.params, loaded.manifest.optimizer)
  adam.steps = loaded.adam.steps
  for (let i = 0; i < loaded.model.params.length; i++) {
    model.params[i].assign(loaded.model.params[i])
    for (const key of ['first', 'second']) {
      adam[key][i].dispose(); adam[key][i] = loaded.adam[key][i].clone()
    }
  }
  return { model, adam, counters: { ...loaded.counters, attackContextInputVersion: 1,
    attackContextMigrationSource: loaded.manifest.sha256 } }
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  await tf.setBackend('cpu'); await tf.ready()
  const [source, destination] = process.argv.slice(2)
  if (!source || !destination || fs.existsSync(destination)) throw Error('Need source and NEW destination manifest')
  const loaded = loadDualCheckpoint(source)
  let migrated
  try {
    migrated = process.argv.includes('--attack-context') ? addAttackContextOutput(loaded,
      JSON.parse(process.env.ATTACK_CONTEXT_FEATURES || 'null'))
      : process.argv.includes('--action-context') ? addActionContextInput(loaded) : addPublicHealthInput(loaded)
    console.log(JSON.stringify(saveDualCheckpoint(destination, migrated.model, migrated.adam, migrated.counters)))
  } finally {
    loaded.adam.dispose(); loaded.model.dispose()
    if (migrated) { migrated.adam.dispose(); migrated.model.dispose() }
  }
}
