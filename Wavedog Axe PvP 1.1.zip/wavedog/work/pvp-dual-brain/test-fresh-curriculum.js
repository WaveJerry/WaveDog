import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE, ACTION_WIDTHS, curriculumLogitBias, biasedActionLogits,
  DualPolicy, computeGAE, ppoUpdate } from './fresh-policy.js'
import { meleeEntryContext } from './fresh-melee-progress.js'
import { conditionTechniqueObservation } from './technique-conditioning.js'

const arenaInput = Array(OBS_SIZE).fill(0)
arenaInput[56] = -2.31; arenaInput[59] = -3
const arenaBounds = { minX: 992.4, maxX: 1036.6, minZ: 992.4, maxZ: 1036.6 }
const humanArena = conditionTechniqueObservation(arenaInput, 'FREE', [],
  { self: { x: 1025, z: 1012 }, bounds: arenaBounds })
assert(humanArena.slice(56, 60).every(x => x >= 0 && x <= 1),
  'main-arena policy must not see negative clearances from a remote training cage')
assert.deepEqual(conditionTechniqueObservation(arenaInput, 'FREE'), arenaInput,
  'existing selfplay encoding and tensor shapes remain unchanged')
const observation = Array(OBS_SIZE).fill(0)
observation[31] = 1 // named opponent visible
observation[2] = 1 // grounded
observation[1] = 1 // charged weapon
observation[10] = 5 // ranged ammo must not disable melee approach
observation[11] = 1
observation[97] = .8 // outside legal melee reach
const ordinary = curriculumLogitBias(observation)
const idle = [0, 0, 0, 0, 0, 0, 0, 0, 0]
const attack = [...idle]; attack[4] = 2
// Historical rollouts retain the version-1 behavior distribution.
const context = { entryCurriculum: 1, opponentApproaching: false }
assert.deepEqual(curriculumLogitBias(observation, context, idle), ordinary,
  'distant stationary opponent does not create blanket forward pressure')
const entry = curriculumLogitBias(observation, context, attack)
assert(entry[0][1] > ordinary[0][1] && entry[1][1] > ordinary[1][1])
assert.deepEqual(entry[4], ordinary[4], 'hand intent is sampled before feet without changing its distribution')
assert.equal(entry[0][2], ordinary[0][2], 'retreat is not globally suppressed')

observation[97] = .3
const closeBase = curriculumLogitBias(observation)
const close = curriculumLogitBias(observation, context, idle)
assert(close[0][1] > closeBase[0][1], 'ground entry is available while waiting for a punish critical')

const currentContext = { entryCurriculum: 2, opponentApproaching: false, enteredReach: false }
observation[97] = .8
assert.deepEqual(curriculumLogitBias(observation, currentContext, attack),
  curriculumLogitBias(observation, currentContext, idle), 'new movement never depends on sampled attack')
assert.deepEqual(curriculumLogitBias(observation, currentContext), curriculumLogitBias(observation),
  'distant stationary opponent creates no new forward pressure')
const approachingContext = { ...currentContext, opponentApproaching: true }
assert(curriculumLogitBias(observation, approachingContext)[1][1] > curriculumLogitBias(observation)[1][1])
observation[97] = .3
const nearby = curriculumLogitBias(observation, currentContext)
assert(nearby[0][1] > curriculumLogitBias(observation)[0][1])
assert(nearby[1][1] > curriculumLogitBias(observation)[1][1])
assert.equal(nearby[0][2], curriculumLogitBias(observation)[0][2], 'retreat remains available')
for (const head of [2, 3, 4, 5, 6, 7, 8])
  assert.deepEqual(nearby[head], curriculumLogitBias(observation)[head], 'approach changes only ground movement')
observation[78] = 1
assert.deepEqual(curriculumLogitBias(observation, approachingContext), curriculumLogitBias(observation),
  'forward while facing away must not be encouraged as toward the enemy')
observation[78] = 0

const previous = { tick: 10, matchId: 'test-bout', opponent: 'B',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62 }, seen: { visible: true, x: 0, y: 0, z: 6 } }
const approaching = { ...previous, tick: 11, seen: { visible: true, x: 0, z: 5.8 } }
assert(meleeEntryContext(previous, approaching).opponentApproaching)
assert(!meleeEntryContext(previous, { ...previous, tick: 11, self: { x: 0, z: 1 } }).opponentApproaching,
  'own approach cannot be mistaken for opponent approach')
assert(!meleeEntryContext(previous, { ...approaching, opponent: 'C' }).opponentApproaching)
assert(!meleeEntryContext(previous, { ...approaching, matchId: 'next-bout' }).opponentApproaching)
assert(!meleeEntryContext(previous, { ...approaching, tick: 15 }).opponentApproaching)
const beforeEntry = { ...previous, seen: { ...previous.seen, z: 3.31 } }
const afterEntry = { ...beforeEntry, tick: 11, self: { ...previous.self, z: .02 } }
const revertedEntry = meleeEntryContext(beforeEntry, afterEntry)
assert.equal(revertedEntry.entryCurriculum, 10)
assert.deepEqual(curriculumLogitBias(observation, revertedEntry), curriculumLogitBias(observation),
  "new actors restore the pre-forward curriculum without changing historical replay")
const firstEntry = { ...revertedEntry, entryCurriculum: 2 }
assert(firstEntry.enteredReach, 'entry uses eye-to-player-box reach rather than center distance')
assert(!meleeEntryContext(afterEntry, { ...afterEntry, tick: 12 }).enteredReach,
  'remaining in range is not a second first-entry event')
assert(!meleeEntryContext(beforeEntry, { ...afterEntry, seen: { ...afterEntry.seen, visible: false } }).enteredReach)
observation[97] = -.02
const firstHit = curriculumLogitBias(observation, firstEntry)
assert(firstHit[4][2] > curriculumLogitBias(observation, currentContext)[4][2])
for (const [field, value] of [[1, .2], [7, 1], [8, 1], [23, 1], [97, .01]]) {
  const blocked = [...observation]; blocked[field] = value
  assert.equal(curriculumLogitBias(blocked, firstEntry)[4][2],
    curriculumLogitBias(blocked, currentContext)[4][2],
    'entry cue respects charge, shields, active item use and legal reach')
}

observation[2] = 0; observation[4] = -.1
assert.deepEqual(curriculumLogitBias(observation, { ...context, opponentApproaching: true }, attack),
  curriculumLogitBias(observation), 'ground entry leaves every airborne action head unchanged')
assert.deepEqual(curriculumLogitBias(observation, approachingContext), curriculumLogitBias(observation),
  'new approach cue leaves airborne critical movement unchanged')
observation[4] = .1
assert.deepEqual(curriculumLogitBias(observation, firstEntry), curriculumLogitBias(observation),
  'rising critical setup is not replaced by an entry attack cue')
observation[4] = -.1
const falling = curriculumLogitBias(observation, firstEntry)
assert(falling[4][2] > curriculumLogitBias(observation)[4][2])
assert.deepEqual(falling[1], curriculumLogitBias(observation)[1],
  'entry hit preference does not enable sprint during a falling critical')

observation[2] = 1; observation[4] = 0
const logits = ACTION_WIDTHS.map(width => tf.zeros([1, width]))
const acting = biasedActionLogits(logits, observation, context, attack)
const replay = biasedActionLogits(logits, observation, JSON.parse(JSON.stringify(context)), [...attack])
acting.forEach((head, index) => assert.deepEqual([...head.dataSync()], [...replay[index].dataSync()]))
tf.dispose([...logits, ...acting, ...replay])
const model = new DualPolicy({ fast: 8, slow: 32, heads: 4, layers: 1,
  ff: 64, interval: 2, memory: 4 })
let state = model.initialState()
const rollout = []
for (let tick = 0; tick < 4; tick++) {
  const actions = tick % 2 ? [...attack] : [...idle]
  actions[0] = 1; actions[1] = 1
  const output = model.step(tf.tensor2d([observation]), state)
  state = output.state
  const frameContext = tick % 2 ? { ...firstEntry } : { ...context }
  const behavior = biasedActionLogits(output.logits, observation, frameContext, actions)
  const replayed = biasedActionLogits(output.logits, observation,
    JSON.parse(JSON.stringify(frameContext)), [...actions])
  behavior.forEach((head, index) => assert.deepEqual([...head.dataSync()], [...replayed[index].dataSync()]))
  tf.dispose(replayed)
  rollout.push({ observation: [...observation], context: frameContext, actions,
    oldHeadLogProbs: behavior.map((head, index) => tf.logSoftmax(head).dataSync()[actions[index]]),
    oldValue: output.value.dataSync()[0], reward: tick === 3 ? 1 : 0,
    done: tick === 3, executedHeads: ACTION_WIDTHS.map((_, index) => [0, 1, 2, 4, 5].includes(index)) })
}
const adam = tf.train.adam(.00003)
const groups = { fast: model.fast.params, slow: model.slowBlocks[0].params, gate: model.gateIn.params }
const before = new Map(Object.values(groups).flat().map(parameter =>
  [parameter.name, [...parameter.dataSync()]]))
const updated = ppoUpdate(model, adam, computeGAE([rollout]))
assert(Number.isFinite(updated.loss))
for (const [name, parameters] of Object.entries(groups))
  assert(parameters.some(parameter => [...parameter.dataSync()].some((value, index) =>
    value !== before.get(parameter.name)[index])), `conditional PPO updates ${name}`)
adam.dispose(); model.dispose()
console.log('FRESH_CURRICULUM_PASS')
