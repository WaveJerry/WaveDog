import fs from 'node:fs'
import crypto from 'node:crypto'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE } from './dual-policy.js'

const LEGACY_HIDDEN = 64
const STRIDE = OBS_SIZE + LEGACY_HIDDEN + 1
const GATE = LEGACY_HIDDEN * STRIDE
const POLICY = 3 * GATE
const OUTPUTS = ACTION_WIDTHS.reduce((sum, width) => sum + width, 0)
const VALUE = POLICY + OUTPUTS * (LEGACY_HIDDEN + 1)
const LENGTH = VALUE + LEGACY_HIDDEN + 1

function assignDense (dense, legacy, offset, outputWidth, inputWidth) {
  const weights = new Float32Array(inputWidth * outputWidth)
  const bias = new Float32Array(outputWidth)
  for (let output = 0; output < outputWidth; output++) {
    const row = offset + output * (inputWidth + 1)
    for (let input = 0; input < inputWidth; input++)
      weights[input * outputWidth + output] = legacy[row + input]
    bias[output] = legacy[row + inputWidth]
  }
  const w = tf.tensor2d(weights, [inputWidth, outputWidth])
  const b = tf.tensor1d(bias)
  dense.w.assign(w); dense.b.assign(b)
  w.dispose(); b.dispose()
}

function importVector (model, vector, setDense) {
  // Java stores each GRU gate as output-major rows, in update, reset,
  // candidate order. The new model stores input-major Dense matrices.
  setDense(model.fast.update, vector, 0, LEGACY_HIDDEN, OBS_SIZE + LEGACY_HIDDEN)
  setDense(model.fast.reset, vector, GATE, LEGACY_HIDDEN, OBS_SIZE + LEGACY_HIDDEN)
  setDense(model.fast.candidate, vector, 2 * GATE,
    LEGACY_HIDDEN, OBS_SIZE + LEGACY_HIDDEN)
  let offset = POLICY
  for (let head = 0; head < ACTION_WIDTHS.length; head++) {
    setDense(model.fastHeads[head], vector, offset, ACTION_WIDTHS[head], LEGACY_HIDDEN)
    offset += ACTION_WIDTHS[head] * (LEGACY_HIDDEN + 1)
  }
  setDense(model.fastValue, vector, VALUE, 1, LEGACY_HIDDEN)
}

export function importLastGru (model, adam, checkpointPath, manifestPath) {
  if (model.config.fast !== LEGACY_HIDDEN)
    throw Error('last_gru requires a GRU64 fast branch')
  if (adam.parameters !== model.params) throw Error('Adam must own this model')
  const payload = fs.readFileSync(checkpointPath)
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  const digest = crypto.createHash('sha256').update(payload).digest('hex')
  if (manifest.sha256 !== digest) throw Error('last_gru SHA256 mismatch')
  const legacy = JSON.parse(payload.toString('utf8'))
  for (const key of ['w', 'm', 'v']) {
    if (!Array.isArray(legacy[key]) || legacy[key].length !== LENGTH
        || legacy[key].some(value => !Number.isFinite(value)))
      throw Error(`last_gru ${key} shape or values invalid`)
  }
  if (legacy.updates !== manifest.updates
      || legacy.episodes !== manifest.episodes
      || legacy.optimizerSteps !== manifest.optimizerSteps)
    throw Error('last_gru manifest counters disagree')
  importVector(model, legacy.w, assignDense)

  // The Java optimizer maximized the PPO objective, while SharedAdam
  // minimizes loss. The old first moments therefore need the opposite sign.
  const momentModel = {
    fast: { update: {}, reset: {}, candidate: {} },
    fastHeads: ACTION_WIDTHS.map(() => ({})), fastValue: {}
  }
  const originalDense = [model.fast.update, model.fast.reset, model.fast.candidate,
    ...model.fastHeads, model.fastValue]
  const mappedDense = [momentModel.fast.update, momentModel.fast.reset,
    momentModel.fast.candidate, ...momentModel.fastHeads, momentModel.fastValue]
  const positions = new Map(model.params.map((parameter, index) => [parameter, index]))
  for (let dense = 0; dense < originalDense.length; dense++) {
    mappedDense[dense].w = positions.get(originalDense[dense].w)
    mappedDense[dense].b = positions.get(originalDense[dense].b)
  }
  const importMoment = (source, destination, sign) => {
    importVector(momentModel, source, (dense, vector, offset, outputWidth, inputWidth) => {
      const weights = new Float32Array(inputWidth * outputWidth)
      const bias = new Float32Array(outputWidth)
      for (let output = 0; output < outputWidth; output++) {
        const row = offset + output * (inputWidth + 1)
        for (let input = 0; input < inputWidth; input++)
          weights[input * outputWidth + output] = sign * vector[row + input]
        bias[output] = sign * vector[row + inputWidth]
      }
      for (const [index, values, shape] of [
        [dense.w, weights, [inputWidth, outputWidth]],
        [dense.b, bias, [outputWidth]]]) {
        const replacement = tf.tensor(values, shape)
        destination[index].dispose()
        destination[index] = replacement
      }
    })
  }
  importMoment(legacy.m, adam.first, -1)
  importMoment(legacy.v, adam.second, 1)
  adam.steps = legacy.optimizerSteps

  // Start the new branch near the preserved policy. PPO can then learn how
  // much tactical influence is useful instead of replacing the old fighter.
  const zeroGate = tf.zerosLike(model.gateOut.w)
  const prior = tf.fill(model.gateOut.b.shape, -4)
  const zeroResidual = tf.zerosLike(model.valueOut.w)
  const zeroResidualBias = tf.zerosLike(model.valueOut.b)
  model.gateOut.w.assign(zeroGate); model.gateOut.b.assign(prior)
  model.valueOut.w.assign(zeroResidual); model.valueOut.b.assign(zeroResidualBias)
  ;[zeroGate, prior, zeroResidual, zeroResidualBias].forEach(tensor => tensor.dispose())
  return { sourceSha256: digest, updates: legacy.updates,
    episodes: legacy.episodes, samples: legacy.samples,
    optimizerSteps: legacy.optimizerSteps }
}
