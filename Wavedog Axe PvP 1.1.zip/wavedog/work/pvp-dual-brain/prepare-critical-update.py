"""Prepare evidence, live-edit plans and operator teaching without stopping play."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import re

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / 'work/pvp-8.6-dual-fresh/model'
RUNTIME = ROOT / 'work/pvp-dual-brain/runtime/critical-defense-20261115'
SERVER = Path('D:/Walt Disney/Minecraft-1.21.1-Server')

def main():
    RUNTIME.mkdir(parents=True, exist_ok=True)
    pointer = json.loads((ROOT / 'backups/7jbk-location.json').read_text(encoding='utf-8'))
    backup = Path(pointer['path'])
    assert not (backup / 'INCOMPLETE').exists()
    native = SERVER / 'plugins/PvPArenaAI/diagnostics/last-10-rounds'
    saved = MODEL / 'coach/priority-reviews/jifengoqk-20261115'
    saved.mkdir(parents=True, exist_ok=True)
    reports = []
    deaths = []
    for line in (SERVER / 'logs/latest.log').read_text(encoding='utf-8', errors='replace').splitlines():
        if not re.search(r'(?i)(WaveDog was .+ by jifengoqk|jifengoqk was .+ by WaveDog)', line):
            continue
        clock = re.search(r'^\[(\d\d:\d\d:\d\d)\]', line)
        if clock:
            deaths.append(datetime.combine(datetime.now().date(),
                datetime.strptime(clock[1], '%H:%M:%S').time()).timestamp())
    for source in sorted(native.glob('*-WaveDog.jsonl')):
        if not deaths or min(abs(source.stat().st_mtime - t) for t in deaths) > 3:
            continue
        data = source.read_bytes()
        if not data:
            continue
        data = data[:data.rfind(b'\n') + 1]
        destination = saved / source.name
        if destination.exists() and destination.read_bytes() != data:
            destination = saved / (source.stem + '-prefix-' + str(len(data)) + '.jsonl')
        destination.write_bytes(data)
        frames, taken, dealt = {}, [], []
        for line in data.decode('utf-8').splitlines():
            row = json.loads(line)
            if row['type'] == 'FRAME': frames[row['tick']] = row
            if row['type'] == 'TAKEN': taken.append(row)
            if row['type'] == 'DEALT': dealt.append(row)
        def sword_at(tick):
            frame = frames.get(tick) or frames.get(tick - 1)
            return bool(frame and 'main=DIAMOND_SWORD' in frame['detail'].split(' target={', 1)[-1])
        reports.append({'file': destination.name, 'sha256': hashlib.sha256(data).hexdigest(),
            'tick_start': min(frames, default=None), 'tick_end': max(frames, default=None),
            'taken_sword_events': sum(sword_at(r['tick']) for r in taken),
            'taken_critical_events': sum('critical=true' in r['detail'] for r in taken),
            'taken_total': len(taken), 'dealt_total': len(dealt)})
    (saved / 'manifest.json').write_text(json.dumps({'priorityOpponent': 'jifengoqk',
        'at': datetime.now().astimezone().isoformat(), 'files': reports,
        'identityEvidence': 'latest.log timed jifengoqk/WaveDog death records; native file timestamps',
        'status': 'raw evidence preserved; chronological review required'}, ensure_ascii=False, indent=2), encoding='utf-8')
    source_audit = MODEL / 'coach/priority-reviews/wavejerry-critical-20261115/native-and-ppo-audit.json'
    audit = json.loads(source_audit.read_text(encoding='utf-8'))
    teaching = {'at': datetime.now().astimezone().isoformat(), 'contextVersion': 5,
        'priorityOpponents': ['WaveJerry', 'jifengoqk'],
        'evidence': [{'file': b['file'], 'sha256': b['sha256'],
                      'nativeCriticalsTaken': b['critical_hits_taken'],
                      'ppo': b['matching_rollouts']} for b in audit['bouts']],
        'measuredBadExchanges': [
            {'ticks': [35572,35573], 'dealt': 2.6100, 'receivedCritical': 4.5225},
            {'ticks': [37330,37333], 'dealt': 2.6100, 'receivedCritical': 4.5225},
            {'ticks': [37425,37428], 'receivedCritical': 4.5225, 'dealt': 2.2258}],
        'rules': [
            '主要从这两局学习选择的度。地面/上升期可用合法疾跑击退先手抢断；对手已经下落时不能把平A换暴击冒充打断。',
            '惩罚暴击能接上且换血有利就打；不合适而仍有抢断窗口时用疾跑刀；预期被拍出射程、交换不利时比较提前退距和侧移。不是看见下落就强制后退。',
            '对手开始脱离，惩罚窗口将消失时及时改选：仍在合法范围且划算可补一刀止损；够不着就停止追刀，不能距离外挥空。',
            '受击那一tick按空格是jump reset练习的目标时机。实际执行起跳、水平击退与后续可命中必须分别验证，不能把被击飞或普通跳跃当作成功。当前没有掌握证据。',
            '重点复盘jifengoqk剑连击的起手、跟进、出距；被剑连击压到近身要比较切剑反制、打断与脱连，计入切换导致的蓄力重置，不是机械强制切剑。',
            '机械弓弩彻底取消主动装弩，仅保留对手装填的同步响应。不要读取隐藏背包、攻击输入或血量。'],
        'learning': 'one shared GRU64/GTrXL PPO model; versioned public context, actual executed-head credit and native outcomes; Qwen review/memory only',
        'noSuccessClaim': True, 'noForcedLearnerMovement': True,
        'exploiter': 'arena 2 every third bout: alternate one public-only scripted critical/retreat opponent; only current side enters PPO; ordinary shared-clone bouts continue'}
    (MODEL / 'coach/operator-critical-defense.json').write_text(json.dumps(teaching, ensure_ascii=False, indent=2), encoding='utf-8')
    text = '；'.join(teaching['rules'])
    for file in [MODEL / 'coach/player-experience.jsonl', ROOT / 'work/pvp-player-client/new-learning/selfplay/player-experience.jsonl']:
        with file.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({'at': teaching['at'], 'source': 'operator-verified-critical-defense',
                'text': text, 'evidence': str(source_audit)}, ensure_ascii=False) + '\n')
    raw = subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
        'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress'],
        text=True, encoding='utf-8', errors='replace')
    processes = json.loads(raw)
    by_script = {}
    for row in processes:
        cmd = (row.get('CommandLine') or '').replace('\\', '/').lower()
        if row.get('Name', '').lower() != 'node.exe': continue
        for script in ['fresh-actor.js', 'dual-service.js', 'selfplay.js']:
            if '/'+script in cmd: by_script.setdefault(script, []).append(row['ProcessId'])
    for script in ['fresh-actor.js', 'dual-service.js', 'selfplay.js']:
        if len(by_script.get(script, [])) != 1:
            raise RuntimeError('Ambiguous running script: ' + script)
    specs = {'actor': ('fresh-actor.js', [
        ('work/pvp-dual-brain/fresh-policy.js', True), ('work/pvp-dual-brain/fresh-policy.js', False),
        ('work/pvp-dual-brain/fresh-melee-progress.js', False), ('work/pvp-dual-brain/fresh-actor.js', False)]),
        'service': ('dual-service.js', [('work/pvp-dual-brain/dual-service.js', False)]),
        'controller': ('selfplay.js', [('work/pvp-player-client/selfplay.js', False)])}
    for name, (script, files) in specs.items():
        plan = {'pid': by_script[script][0], 'files': [{'path': str(ROOT / file),
            'before': str(backup / file), 'worker': worker} for file, worker in files],
            'receipt': str(RUNTIME / (name + '-live-receipt.json'))}
        (RUNTIME / (name + '-plan.json')).write_text(json.dumps(plan, indent=2), encoding='utf-8')
    print(json.dumps({'backup': pointer, 'processes': by_script,
        'preserved_jifengoqk_candidates': len(reports),
        'recent_jifengoqk': reports[-4:],
        'teaching': str(MODEL / 'coach/operator-critical-defense.json')}, ensure_ascii=False, indent=2))

if __name__ == '__main__': main()
