"""Publish measured teaching notes without replacing any live checkpoint."""
from pathlib import Path
from datetime import datetime, timezone
import collections
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'work/wavedog-protocol/runtime/wasplan-ground-combo'
OUT.mkdir(exist_ok=True)
stamp = datetime.now(timezone.utc).isoformat()
match_id = '8ace6dcb-0c16-41f0-b7f7-db56560136cd'
source = ROOT / f'work/wavedog-protocol/runtime/{match_id}-frames.jsonl'
frames = [json.loads(line) for line in source.open(encoding='utf-8')]
selected = [frame for frame in frames if 24600 <= frame['tick'] <= 24655]
(OUT / 'wasplan-selected-full-frames.json').write_text(json.dumps({
    'matchId': match_id, 'source': str(source),
    'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'frames': selected}, ensure_ascii=False, indent=2), encoding='utf-8')

lesson = (
    '平地控距：合法射程边界争取先手和真实疾跑击退，命中后跟位，比较下一次入距、'
    '净换血及是否反被连；不在距离外空挥，不写固定距离后退脚本。wasplan样本24638帧：'
    '自己落地再入距2.9949格、斧蓄力0.65、对手地面逼近，旧动作仍不攻击，随后再次受伤。'
    '比较低蓄力抢断、横移出距和近身剑反打，不只等满斧蓄力或惩罚暴击。'
    '贴近且能持续接触时，多尝试钻石剑连续真实下落暴击，出刀前松疾跑，按需要恢复疾跑跟位；'
    '上升时可准备下一刀，不把普通起跳算成暴击或跳跃重置。'
    '剑连期间观察到有效正面盾，学习快速切斧单次破盾，再根据对手距离和反击切剑续连；'
    '切槽、实际攻击包、盾禁用回执、后续剑伤分别确认。不要预设秒切可保留剑蓄力、'
    '剑速斧伤或无损combo；切换损失和失败必须进入真实回报。对手已下落时避免盲目平A换暴击。'
    '边缘平地控距和贴脸剑连并存，按场景学习选择，而非贴脸强制切剑或强制破盾。'
)

def append_once(path, row):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        for line in path.open(encoding='utf-8'):
            try:
                existing = json.loads(line)
                if existing.get('source') == row['source']:
                    return
            except (ValueError, UnicodeError):
                continue
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + '\n')

main_coach = ROOT / 'work/pvp-8.6-dual-fresh/model/coach'
pure_coach = ROOT / 'work/wavedog-punengbho/model/coach'
for coach in [main_coach, pure_coach]:
    card = {'at': stamp, 'source': 'operator-ground-sword-shield-20261116',
            'focus': 'COMBO', 'text': lesson, 'lesson': lesson,
            'evidenceMatchId': match_id, 'authorship': 'operator teaching; not a completed Qwen review'}
    append_once(coach / 'shared-lessons.jsonl', card)
    append_once(coach / 'player-experience.jsonl', card)
    teaching = coach / 'operator-critical-defense.json'
    data = json.loads(teaching.read_text(encoding='utf-8')) if teaching.exists() else {}
    data['groundSwordShieldCurriculum'] = {'at': stamp, 'instruction': lesson,
        'verify': ['legal entry first hit', 'native sword damage', 'native consecutive sword criticals',
                   'native shield disable after axe switch', 'sword follow-up after shield disable',
                   'net exchange', 'bout outcome'],
        'notEstablished': ['flawless instant switch', 'wasplan behavior-cloning update', 'skills mastered']}
    teaching.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
append_once(ROOT / 'work/pvp-player-client/new-learning/selfplay/player-experience.jsonl', card)

# Inactive-opponent wins must not be presented as tactical success in reviews.
flags_path = main_coach / 'quality-flags.jsonl'
known = set()
if flags_path.exists():
    for line in flags_path.open(encoding='utf-8'):
        try:
            row = json.loads(line)
            if row.get('source') == 'learning-frame-listener-audit-20261116':
                known.add(row.get('matchId'))
        except ValueError:
            pass
flagged = []
with flags_path.open('a', encoding='utf-8') as output:
    for line in (main_coach / 'rounds.jsonl').open(encoding='utf-8'):
        row = json.loads(line)
        if not ('2026-11-15T15:29:' <= row.get('at', '') < '2026-11-15T16:09:30'):
            continue
        fighters = list(row.get('fighters', {}).values())
        if not fighters or not any(f.get('framesSeen') == 0 for f in fighters):
            continue
        key = row.get('matchId')
        if key in known:
            continue
        flag = {'at': stamp, 'matchId': key, 'status': 'review-invalid',
            'source': 'learning-frame-listener-audit-20261116',
            'reason': 'at least one fighter had zero observation frames; not valid tactical evaluation',
            'rawDataRetained': True, 'checkpointRolledBack': False}
        output.write(json.dumps(flag) + '\n')
        flagged.append(key)

current = json.loads((ROOT / 'work/pvp-8.6-dual-fresh/model/checkpoint.json').read_text())
rollout_counts = collections.Counter()
for path in sorted((ROOT / 'work/pvp-8.6-dual-fresh/model/rollouts').glob('*.json.gz'))[-12:]:
    data = json.loads(gzip.decompress(path.read_bytes()))
    for frame in data['episode']:
        if frame.get('context', {}).get('entryCurriculum', 0) >= 10:
            rollout_counts['v10Frames'] += 1
            if frame.get('executedHeads', [False] * 9)[5] and frame['actions'][5] == 1:
                rollout_counts['executedSwordChoices'] += 1
receipt = {'at': stamp, 'mainCheckpointSha256': current['sha256'],
    'mainCounters': current['counters'], 'recentActualRollouts': rollout_counts,
    'newlyFlaggedInactiveOpponentBouts': len(flagged),
    'skillsMastered': False, 'wasplanBehaviorCloningClaimed': False}
(OUT / 'curriculum-publish-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
