import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { biasedActionLogits, maskActionLogits } from './fresh-policy.js'
import { advance, disposeState } from './human-imitation.js'

await tf.setBackend('cpu'); await tf.ready()
const [source, candidate, destination, ...args] = process.argv.slice(2)
const sameDistribution = args.includes('--same-distribution')
const adaptedArg=args.find(x=>x.startsWith('--adapted-heads='))
const adaptedHeads=adaptedArg?adaptedArg.split('=')[1].split(',').map(Number):[]
if(adaptedHeads.some(h=>!Number.isSafeInteger(h)||h<0||h>8))throw Error('Invalid adapted heads')
const rollouts = args.filter(x => x !== '--same-distribution' && x!==adaptedArg)
if (!rollouts.length) throw Error('Need independent previously recorded PPO rollouts')
const left = loadDualCheckpoint(source), right = loadDualCheckpoint(candidate)
left.adam.dispose(); right.adam.dispose()
if (sameDistribution) {
  left.model.config.distributionVersion = right.model.config.distributionVersion
  left.model.config.calibratedHeads = right.model.config.calibratedHeads
  left.model.config.weaponConditionedAttack = right.model.config.weaponConditionedAttack || 0
}
const report = { sourceSha256: left.manifest.sha256, candidateSha256: right.manifest.sha256,
  rollouts: [], heads: {}, sameDistribution,
  modelWeightsChanged: left.manifest.sha256 !== right.manifest.sha256, livePvpImprovementVerified: false,
  intentionallyAdaptedHeads:adaptedHeads,adaptedHeadQualityRequiresSeparateLiveValidation:true }
try {
  for (const file of rollouts) {
    const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)))
    let beforeState = left.model.initialState(), afterState = right.model.initialState()
    try {
      for (const frame of rollout.episode) {
        const before = advance(left.model, beforeState, frame.observation, true, frame.legalMasks, frame.publicHealthFeatures); beforeState = before.state
        const after = advance(right.model, afterState, frame.observation, true, frame.legalMasks, frame.publicHealthFeatures); afterState = after.state
        const probabilities = [before, after].map((result, index) => tf.tidy(() => {
          const logits = result.logits.map(values => tf.tensor2d([values]))
          const policy = index ? right.model : left.model
          const context = { ...frame.context, distributionVersion: policy.config.distributionVersion || 1,
            weaponConditionedAttack: policy.config.weaponConditionedAttack || 0,
            ...(policy.config.distributionVersion >= 3 ? { calibratedHeads: policy.config.calibratedHeads || [2,5] } : {}) }
          return maskActionLogits(biasedActionLogits(logits, frame.observation, context, frame.actions,
            policy, frame.publicHealthFeatures), frame.legalMasks)
            .map(head => [...tf.softmax(head).dataSync()])
        }))
        for (let h = 0; h < probabilities[0].length; h++) {
          if (!frame.executedHeads[h]) continue
          const p = probabilities[0][h], q = probabilities[1][h]
          const kl = Math.max(0, p.reduce((sum, value, i) => sum + (value ? value * Math.log(value / Math.max(1e-30, q[i])) : 0), 0))
          const item = report.heads[h] ||= { frames: 0, klSum: 0, maxKL: 0, argmaxChanges: 0 }
          item.frames++; item.klSum += kl; item.maxKL = Math.max(item.maxKL, kl)
          item.argmaxChanges += p.indexOf(Math.max(...p)) !== q.indexOf(Math.max(...q)) ? 1 : 0
        }
      }
    } finally { disposeState(beforeState); disposeState(afterState) }
    report.rollouts.push({ path: file, rolloutSeq: rollout.rolloutSeq, frames: rollout.episode.length })
    console.log(JSON.stringify({ auditedRollout: rollout.rolloutSeq, frames: rollout.episode.length }))
  }
  for (const item of Object.values(report.heads)) { item.meanKL = item.klSum / item.frames; delete item.klSum }
  report.preservedHeads=Array.from({length:9},(_,h)=>h)
    .filter(h=>!(adaptedArg?adaptedHeads:[4,5]).includes(h))
  report.retentionPassed = report.preservedHeads.every(head => !report.heads[head] || report.heads[head].meanKL < .02)
  fs.writeFileSync(destination, JSON.stringify(report, null, 2))
  console.log(JSON.stringify(report))
} finally { left.model.dispose(); right.model.dispose() }
