// Explicit, hash-checked V8 LiveEdit. No process restart or actor reset.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const hash = text => crypto.createHash('sha256').update(text).digest('hex')
async function main () {
  const plan = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'))
  const target = Number(plan.pid)
  if (!Number.isInteger(target) || target <= 0) throw Error('Invalid explicit PID')
  process._debugProcess(target)
  let entries
  for (let attempt = 0; attempt < 30; attempt++) {
    try { entries = await (await fetch('http://127.0.0.1:9229/json/list')).json(); break }
    catch { await new Promise(resolve => setTimeout(resolve, 100)) }
  }
  if (!entries?.[0]?.webSocketDebuggerUrl) throw Error('No local inspector')
  const ws = new WebSocket(entries[0].webSocketDebuggerUrl)
  let next = 0
  const pending = new Map(), scripts = [], workers = [], changed = [], receipts = []
  let paused=null,resolvePause,waitBreakpoint
  const received = (data, sessionId = '') => {
    const key = sessionId + ':' + data.id
    if (data.id) { pending.get(key)?.(data); pending.delete(key) }
    else if(data.method==='Debugger.paused'){paused=data.params;resolvePause?.(data.params)}
    else if (data.method === 'Debugger.scriptParsed') scripts.push({ ...data.params, sessionId })
    else if (data.method === 'NodeWorker.attachedToWorker') workers.push(data.params)
    else if (data.method === 'NodeWorker.receivedMessageFromWorker')
      received(JSON.parse(data.params.message), data.params.sessionId)
  }
  ws.addEventListener('message', event => received(JSON.parse(event.data)))
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve); ws.addEventListener('error', reject)
  })
  const call = (method, params = {}, sessionId = '') => new Promise((resolve, reject) => {
    const id = ++next
    const timer = setTimeout(() => reject(Error('Inspector timeout: ' + method)), 10000)
    pending.set(sessionId + ':' + id, row => { clearTimeout(timer); row.error ? reject(Error(JSON.stringify(row.error))) : resolve(row.result) })
    ws.send(JSON.stringify(sessionId ? { id: ++next, method: 'NodeWorker.sendMessageToWorker',
      params: { sessionId, message: JSON.stringify({ id, method, params }) } } : { id, method, params }))
  })
  let verifiedTarget = false
  try {
    const pid = await call('Runtime.evaluate', { expression: 'process.pid', returnByValue: true })
    if (pid.result.value !== target) throw Error('Inspector belongs to another process; refusing changes')
    verifiedTarget = true
    await call('Debugger.enable')
    if(plan.waitBeforeCall){
      const script=scripts.find(s=>decodeURI(s.url).endsWith('/'+plan.waitBeforeCall.file))
      if(!script)throw Error('Deferred update caller not found')
      const source=(await call('Debugger.getScriptSource',{scriptId:script.scriptId})).scriptSource.split('\n')
      const lineNumber=source.findIndex(line=>line.includes(plan.waitBeforeCall.contains))
      if(lineNumber<0)throw Error('Deferred update boundary not found')
      const ready=new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>reject(Error('Deferred update boundary timed out')),plan.waitBeforeCall.timeoutMs||600000)
        resolvePause=value=>{clearTimeout(timer);resolve(value)}
      })
      waitBreakpoint=await call('Debugger.setBreakpoint',{location:{scriptId:script.scriptId,lineNumber}})
      console.log(JSON.stringify({pid:target,waitingForInactiveCallee:true,boundary:plan.waitBeforeCall.contains}))
      await ready
    }
    if (plan.files.some(file => file.worker)) {
      await call('NodeWorker.enable', { waitForDebuggerOnStart: false })
      for (let attempt = 0; !workers.length && attempt < 30; attempt++)
        await new Promise(resolve => setTimeout(resolve, 100))
      if (!workers.length) throw Error('Training worker not attached')
      for (const worker of workers) await call('Debugger.enable', {}, worker.sessionId)
    }
    const updates = []
    for (const change of plan.files) {
      const suffix = '/' + path.resolve(change.path).replaceAll('\\', '/').split('/').slice(-3).join('/')
      const old = fs.readFileSync(change.before, 'utf8')
      const candidates = scripts.filter(script => decodeURI(script.url).endsWith(suffix)
        && Boolean(script.sessionId) === Boolean(change.worker)
        && (change.scriptId === undefined || script.scriptId === String(change.scriptId)))
      const matches = []
      for (const script of candidates) {
        const source = (await call('Debugger.getScriptSource', { scriptId: script.scriptId }, script.sessionId)).scriptSource
        if (source === old) matches.push({ ...script, source })
      }
      if (matches.length !== 1) throw Error('Expected exactly one script with the verified source: '
        + change.path + ' (URL candidates=' + candidates.length + ', source matches=' + matches.length + ')')
      const scriptId = matches[0].scriptId
      const sessionId = matches[0].sessionId
      const current = matches[0].source
      const replacement = fs.readFileSync(change.path, 'utf8')
      if (current !== old) throw Error('Live source differs from verified backup: ' + change.path)
      let preflight
      for (let attempt = 0; attempt < 80; attempt++) {
        preflight = await call('Debugger.setScriptSource', { scriptId, scriptSource: replacement, dryRun: true }, sessionId)
        if (preflight.status !== 'BlockedByActiveFunction') break
        await new Promise(resolve => setTimeout(resolve, 50))
      }
      if (preflight.status !== 'Ok') throw Error('Preflight refused ' + change.path
        + (sessionId ? ' worker' : ' main') + ': ' + JSON.stringify(preflight))
      updates.push({ scriptId, sessionId, current, replacement, path: change.path })
    }
    for (const update of updates) {
      if (!plan.dryRun) {
        const result = await call('Debugger.setScriptSource', { scriptId: update.scriptId, scriptSource: update.replacement }, update.sessionId)
        if (result.status !== 'Ok') throw Error('LiveEdit refused: ' + JSON.stringify(result))
        changed.push(update)
        const actual = (await call('Debugger.getScriptSource', { scriptId: update.scriptId }, update.sessionId)).scriptSource
        if (actual !== update.replacement) throw Error('LiveEdit source verification failed')
      }
      receipts.push({ file: update.path, thread: update.sessionId ? 'trainer-worker' : 'main',
        before: hash(update.current), after: hash(update.replacement) })
    }
    const receipt = { at: new Date().toISOString(), pid: target, dryRun: !!plan.dryRun,
      processRestarted: false, actorReset: false, files: receipts }
    fs.writeFileSync(plan.receipt, JSON.stringify(receipt, null, 2))
    console.log(JSON.stringify(receipt))
  } catch (error) {
    for (const update of changed.reverse())
      await call('Debugger.setScriptSource', { scriptId: update.scriptId, scriptSource: update.current }, update.sessionId)
    throw error
  } finally {
    if(waitBreakpoint)await call('Debugger.removeBreakpoint',{breakpointId:waitBreakpoint.breakpointId})
    if(paused)await call('Debugger.resume')
    if (verifiedTarget) {
      // Leave no debugging listener on the running service.
      await call('Runtime.evaluate', { expression: 'setTimeout(() => process.getBuiltinModule("inspector").close(), 100); true' })
    }
    ws.close()
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
