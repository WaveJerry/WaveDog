import * as tf from '@tensorflow/tfjs'
import { OBS_SIZE, biasedActionLogits, maskActionLogits, ppoLoss } from './fresh-policy.js'

const tensors = state => state ? [...new Set([state.fast, state.slow, ...state.pending,
  ...state.caches.flatMap(c => c ? [c.key, c.value] : [])].filter(Boolean))] : []
export function releaseState (state, next = null) {
  const retained = new Set(tensors(next))
  for (const tensor of tensors(state)) if (!retained.has(tensor)) tensor.dispose()
}
function advance (model, state, frame) {
  const next = tf.tidy(() => model.step(tf.tensor2d([frame.observation], [1, OBS_SIZE]), state,
    frame.legalMasks, frame.publicHealthFeatures,frame.publicSpatialFeatures,frame.publicThreatFeatures,frame.publicMotionFeatures).state)
  releaseState(state, next)
  return next
}

export function rolloutHealth (episode) {
  const reasons = [], hashes = new Set(episode.map(f => f.checkpointSha256).filter(Boolean))
  const executedFrames=episode.filter(f=>f.executedHeads?.some(Boolean)).length
  if(!executedFrames)reasons.push('no-model-owned-actions')
  if (hashes.size > 1) reasons.push('weights-changed-within-bout')
  if (episode.some(f => !Number.isFinite(f.reward) || !Number.isFinite(f.oldValue)))
    reasons.push('non-finite-feedback')
  let opportunities = 0, attacks = 0, weaponChanges = 0, lastWeapon = null
  for (const f of episode) {
    const x = f.observation
    if (f.executedHeads[4]) {
      attacks += f.actions[4] === 2
      if (x[31] > .5 && x[97] <= 0 && x[1] >= .85 && x[8] < .5 && x[23] < .5
          && !f.context?.fallingMeleeThreat && !f.context?.swordRisingWindow) opportunities++
    }
    if (f.executedHeads[5]) {
      if (lastWeapon !== null && lastWeapon !== f.actions[5]) weaponChanges++
      lastWeapon = f.actions[5]
    }
  }
  if (opportunities >= 40 && attacks === 0) reasons.push('prolonged-legal-melee-with-zero-attacks')
  return { passed: reasons.length === 0, reasons, opportunities, attacks, weaponChanges,
    frames: episode.length, executedFrames, policyVersions: [...hashes] }
}

// TBPTT boundaries truncate gradients, not experience. Parameters stay fixed
// for the ENTIRE pass. All window gradients are frame-weighted and applied in
// one Adam step, so a stalled 2,000-frame bout cannot cause 63 sequential steps.
export function completeRolloutUpdate (model, optimizer, episode, { width = 32, ...options } = {}) {
  if (!episode.length) throw Error('Cannot train an empty rollout')
  let state = model.initialState(), accumulated = {}, totalLoss = 0, windows = 0
  try {
    for (let start = 0; start < episode.length; start += width) {
      const segment = episode.slice(start, start + width)
      segment.initialState = state
      const { loss, grads } = tf.tidy(() => {
        const { value, grads } = tf.variableGrads(() => ppoLoss(model, [segment], options), model.params)
        return { loss: value.dataSync()[0], grads }
      })
      if (!Number.isFinite(loss)) {
        Object.values(grads).forEach(t => t.dispose())
        throw Error('Non-finite complete-rollout PPO loss')
      }
      const fraction = segment.length / episode.length
      for (const [name, grad] of Object.entries(grads)) {
        const previous = accumulated[name]
        accumulated[name] = tf.tidy(() => previous
          ? tf.add(previous, tf.mul(grad, fraction)) : tf.mul(grad, fraction))
        previous?.dispose(); grad.dispose()
      }
      totalLoss += fraction * loss; windows++
      for (const frame of segment) state = advance(model, state, frame)
    }
    const gradientNorm = tf.tidy(() => Math.sqrt(tf.addN(Object.values(accumulated)
      .map(t => tf.sum(tf.square(t)))).dataSync()[0]))
    if (!Number.isFinite(gradientNorm)) throw Error('Non-finite accumulated PPO gradient')
    const clipScale = Math.min(1, 1 / Math.max(gradientNorm, 1e-12))
    tf.tidy(() => optimizer.applyGradients(Object.fromEntries(Object.entries(accumulated)
      .map(([name, grad]) => [name, tf.mul(grad, clipScale)]))))
    return { loss: totalLoss, gradientNorm, clipScale, windows,
      trainedFrames: episode.length, optimizerSteps: 1 }
  } finally {
    releaseState(state)
    Object.values(accumulated).forEach(t => t.dispose())
  }
}

export function replayPolicyHealth (model, episode) {
  let state = model.initialState(), kl = 0, klHeads = 0, entropy = 0, heads = 0
  const headKL = Array(9).fill(0), headCounts = Array(9).fill(0)
  let attackProbability = 0, opportunities = 0
  try {
    for (const f of episode) {
      const previous = state
      const result = tf.tidy(() => {
        const output = model.step(tf.tensor2d([f.observation], [1, OBS_SIZE]), state, f.legalMasks, f.publicHealthFeatures,f.publicSpatialFeatures,f.publicThreatFeatures,f.publicMotionFeatures)
        const logits = maskActionLogits(biasedActionLogits(output.logits,
          f.observation, f.context, f.actions, model, f.publicHealthFeatures), f.legalMasks)
        return { state: output.state, p: logits.map(h => [...tf.softmax(h).dataSync()]) }
      })
      state = result.state; releaseState(previous, state)
      for (const [h, p] of result.p.entries()) {
        if (!f.executedHeads[h]) continue
        entropy -= p.reduce((sum, v) => sum + (v > 0 ? v * Math.log(v) : 0), 0); heads++
        const old = f.oldHeadProbabilities?.[h]
        if (old) {
          const divergence = Math.max(0, old.reduce((sum, v, i) => sum + (v > 0
            ? v * Math.log(v / Math.max(1e-30, p[i])) : 0), 0))
          kl += divergence; klHeads++
          headKL[h] += divergence; headCounts[h]++
        }
      }
      const x = f.observation
      if (f.executedHeads[4] && x[31] > .5 && x[97] <= 0 && x[1] >= .85
          && x[8] < .5 && x[23] < .5 && !f.context?.fallingMeleeThreat
          && !f.context?.swordRisingWindow) {
        attackProbability += result.p[4][2]; opportunities++
      }
    }
  } finally { releaseState(state) }
  const meanHeadKL = headKL.map((sum, h) => headCounts[h] ? sum / headCounts[h] : null)
  return { meanKL: klHeads ? kl / klHeads : null, klHeads, meanHeadKL,
    maxMeanHeadKL: Math.max(0, ...meanHeadKL.filter(v => v !== null)),
    meanEntropy: heads ? entropy / heads : 0, opportunities,
    meanAttackProbability: opportunities ? attackProbability / opportunities : null }
}
