import assert from 'node:assert/strict'
import fs from 'node:fs'
import zlib from 'node:zlib'
import * as tf from '@tensorflow/tfjs'
import { meleeEntryContext, meleeTechniqueGoal } from './fresh-melee-progress.js'
import { biasedActionLogits, curriculumLogitBias, maskActionLogits, ACTION_WIDTHS, OBS_SIZE } from './fresh-policy.js'
import { biasedActionLogits as previousPolicy } from './runtime/sword-cycle/before/fresh-policy.js'

const base = { tick: 1, matchId: 'sword-bout', opponent: 'B', focus: 'FREE',
  self: { x: 0, y: 0, z: 0, eyeY: 1.62, ground: true, vy: 0,
    health: 20, held: 0, charge: .5, shieldAvailable: false, shielding: false, using: false },
  seen: { visible: true, x: 0, y: 0, z: 1.8, yaw: 180, shield: false, held: 'DIAMOND_AXE' } }
const middle = { ...base, tick: 2 }, current = { ...base, tick: 3 }
const context = meleeEntryContext(middle, current, meleeEntryContext(base, middle))
assert(context.swordSustainWindow && context.swordCriticalSetupWindow)
assert.equal(meleeTechniqueGoal(current, context).focus, 'CRITICAL')
for (const change of [{ matchId: 'other' }, { opponent: 'C' }, { tick: 8 },
  { self: { ...base.self, shieldAvailable: true } },
  { self: { ...base.self, using: true } },
  { seen: { ...base.seen, visible: false } },
  { seen: { ...base.seen, z: 5 } }]) {
  const result = meleeEntryContext(middle, { ...current, ...change }, context)
  assert(!result.swordSustainWindow && !result.swordCriticalSetupWindow)
}
const rising = meleeEntryContext(middle, { ...current,
  self: { ...base.self, ground: false, vy: .22, charge: .95 } }, context)
assert(rising.swordRisingWindow && !rising.swordCriticalSetupWindow)
const shield = { ...current, seen: { ...base.seen, shield: true } }
const facing = meleeEntryContext(middle, shield, context)
assert(facing.swordShieldBreakWindow && !facing.swordSustainWindow)
assert.equal(meleeTechniqueGoal(shield, facing).focus, 'AXE_BREAK')
assert(!meleeEntryContext(middle, { ...shield,
  seen: { ...shield.seen, yaw: 0 } }, context).swordShieldBreakWindow)
assert(!meleeEntryContext(middle, { ...shield,
  seen: { ...shield.seen, shield: false, shieldRaised: true } }, context).swordShieldBreakWindow)
assert(!meleeEntryContext(middle, { ...shield,
  seen: { ...shield.seen, z: 4 } }, context).swordShieldBreakWindow)
const axe = meleeEntryContext(middle, { ...shield,
  self: { ...base.self, held: 7, charge: .1 } }, context)
assert(axe.axeShieldBreakWindow && !axe.swordShieldBreakWindow)

const x = Array(OBS_SIZE).fill(0)
x[0] = 1; x[1] = .5; x[2] = 1; x[31] = 1; x[97] = -.6
const masks = ACTION_WIDTHS.map(width => Array(width).fill(true))
masks[5] = [true, true, false, false, false]
masks[4] = [true, false, true, false, false]
const raw = ACTION_WIDTHS.map(width => Array(width).fill(0))
raw[5] = [13.92, -4.65, 4.76, 2.97, .76]
raw[2] = [20, -20]
raw[4] = [8, 0, -9, 0, 0]
const logits = raw.map(head => tf.tensor2d([head]))
const probabilities = (obs, ctx, policy = biasedActionLogits) => tf.tidy(() =>
  maskActionLogits(policy(logits, obs, ctx), masks).map(head => [...tf.softmax(head).dataSync()]))
const before = probabilities(x, { ...context, entryCurriculum: 7 })
const after = probabilities(x, context)
assert(before[5][1] < 1e-5 && after[5][1] > .96 && after[5][1] < 1,
  'the demonstrated one-frame sword reversal becomes a sustained, still sampled choice')
assert(after[5][1] ** 13 > .5, 'enough probability mass to experience an actual sword charge')
assert(after[2][1] > .1 && after[2][1] < .6,
  'close sword jump exploration exists without forcing every-frame jumps')
for (const index of [0, 1, 3, 4, 6, 7, 8]) assert.deepEqual(after[index], before[index])
const airborne = [...x]; airborne[2] = 0; airborne[1] = .95; airborne[4] = .22
assert(curriculumLogitBias(airborne, rising)[4][2]
  < curriculumLogitBias(airborne, { ...rising, entryCurriculum: 7 })[4][2],
  'ascending sword setup is not flooded by the full-charge ground-hit cue')
const shieldX = [...x]; shieldX[23] = 1
const shieldP = probabilities(shieldX, facing)
assert(shieldP[5][0] > 0 && shieldP[5][1] > 0, 'shield response remains a learned choice')
const axeX = [...shieldX]; axeX[12] = .875; axeX[1] = .1
assert(probabilities(axeX, axe)[4][2] > probabilities(axeX, { entryCurriculum: 7 })[4][2])
const swordParameter = tf.variable(tf.tensor2d([raw[5]]))
const grads = tf.variableGrads(() => tf.tidy(() => {
  const source = logits.map((head, i) => i === 5 ? swordParameter : head)
  return tf.logSoftmax(maskActionLogits(biasedActionLogits(source, x, context), masks)[5])
    .slice([0, 1], [1, 1]).sum()
}), [swordParameter])
assert([...grads.grads[swordParameter.name].dataSync()].every(Number.isFinite))
assert(grads.grads[swordParameter.name].dataSync()[1] > 1e-6,
  'PPO still differentiates through the sampled weapon distribution')

const rollout = JSON.parse(zlib.gunzipSync(fs.readFileSync(
  new URL('../pvp-8.6-dual-fresh/model/rollouts/rollout-000000001924.json.gz', import.meta.url))))
for (const frame of rollout.episode) {
  const old = probabilities(frame.observation, frame.context, previousPolicy)
  const replay = probabilities(frame.observation, frame.context)
  assert.deepEqual(replay, old, 'pending version-7 PPO data must retain exact old probabilities')
}
tf.dispose([...logits, swordParameter, grads.value, ...Object.values(grads.grads)])
console.log(JSON.stringify({ event: 'SWORD_CYCLE_LEARNING_PASS',
  beforeSwordProbability: before[5][1], sustainedSwordProbability: after[5][1],
  closeJumpExploration: after[2][1], oldReplayFrames: rollout.episode.length,
  mechanicalActionsAdded: false, weightsReset: false }))
