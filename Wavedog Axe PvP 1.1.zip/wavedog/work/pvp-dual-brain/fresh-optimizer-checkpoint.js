import * as tf from '@tensorflow/tfjs'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { DualPolicy } from './fresh-policy.js'

export class SharedAdam {
  constructor (parameters, { learningRate = .00015, beta1 = .9,
    beta2 = .999, epsilon = 1e-8 } = {}) {
    this.parameters = parameters
    this.learningRate = learningRate
    this.beta1 = beta1
    this.beta2 = beta2
    this.epsilon = epsilon
    this.steps = 0
    this.first = parameters.map(parameter => tf.zerosLike(parameter))
    this.second = parameters.map(parameter => tf.zerosLike(parameter))
  }
  applyGradients (gradients) {
    this.steps++
    for (let index = 0; index < this.parameters.length; index++) {
      const parameter = this.parameters[index]
      const gradient = gradients[parameter.name]
      if (!gradient) continue
      const oldFirst = this.first[index], oldSecond = this.second[index]
      const [first, second] = tf.tidy(() => {
        const first = tf.add(tf.mul(this.beta1, oldFirst),
          tf.mul(1 - this.beta1, gradient))
        const second = tf.add(tf.mul(this.beta2, oldSecond),
          tf.mul(1 - this.beta2, tf.square(gradient)))
        const correctedFirst = tf.div(first, 1 - this.beta1 ** this.steps)
        const correctedSecond = tf.div(second, 1 - this.beta2 ** this.steps)
        // Optional per-parameter rates are used only by isolated supervised
        // adaptation. PPO has no multipliers and retains identical Adam math.
        const rate = this.parameterLearningRates?.get(parameter.name) ?? 1
        const update = tf.div(tf.mul(tf.mul(this.learningRate, rate), correctedFirst),
          tf.add(tf.sqrt(correctedSecond), this.epsilon))
        parameter.assign(tf.sub(parameter, update))
        return [tf.keep(first), tf.keep(second)]
      })
      oldFirst.dispose(); oldSecond.dispose()
      this.first[index] = first; this.second[index] = second
    }
  }
  dispose () {
    this.first.forEach(tensor => tensor.dispose())
    this.second.forEach(tensor => tensor.dispose())
  }
}

function bytes (tensor) {
  const data = tensor.dataSync()
  return Buffer.from(data.buffer, data.byteOffset, data.byteLength)
}
export function saveDualCheckpoint (manifestPath, model, adam, counters = {}) {
  if (adam.parameters.length !== model.params.length)
    throw Error('Optimizer and model parameter counts differ')
  const destination = path.resolve(manifestPath)
  fs.mkdirSync(path.dirname(destination), { recursive: true })
  const groups = [model.params, adam.first, adam.second]
  const layout = []
  const chunks = []
  let offset = 0
  for (const [groupIndex, tensors] of groups.entries()) for (const tensor of tensors) {
    const chunk = bytes(tensor)
    layout.push({ group: groupIndex, shape: tensor.shape, offset,
      bytes: chunk.length })
    chunks.push(chunk)
    offset += chunk.length
  }
  const payload = Buffer.concat(chunks)
  const sha256 = crypto.createHash('sha256').update(payload).digest('hex')
  const binaryName = `${path.parse(destination).name}-${sha256.slice(0, 16)}.bin`
  const binaryPath = path.join(path.dirname(destination), binaryName)
  if (!fs.existsSync(binaryPath)) {
    const temporary = binaryPath + '.tmp'
    fs.writeFileSync(temporary, payload)
    fs.renameSync(temporary, binaryPath)
  }
  const manifest = { format: 1, created: new Date().toISOString(),
    config: model.config, gateMode: model.gateMode,
    optimizer: { learningRate: adam.learningRate, beta1: adam.beta1,
      beta2: adam.beta2, epsilon: adam.epsilon, steps: adam.steps },
    counters, binary: binaryName, bytes: payload.length, sha256, layout }
  const temporary = destination + '.tmp'
  fs.writeFileSync(temporary, JSON.stringify(manifest))
  fs.renameSync(temporary, destination)
  return { manifest: destination, sha256, bytes: payload.length,
    steps: adam.steps, counters }
}
export function loadDualCheckpoint (manifestPath) {
  const destination = path.resolve(manifestPath)
  const manifest = JSON.parse(fs.readFileSync(destination, 'utf8'))
  if (manifest.format !== 1) throw Error('Unsupported dual policy checkpoint')
  if (typeof manifest.binary !== 'string'
      || path.basename(manifest.binary) !== manifest.binary
      || !/^[a-zA-Z0-9_.-]+\.bin$/.test(manifest.binary))
    throw Error('Dual policy checkpoint binary name invalid')
  const payload = fs.readFileSync(path.join(path.dirname(destination), manifest.binary))
  if (payload.length !== manifest.bytes
      || crypto.createHash('sha256').update(payload).digest('hex') !== manifest.sha256)
    throw Error('Dual policy checkpoint hash mismatch')
  const model = new DualPolicy(manifest.config, manifest.gateMode)
  const adam = new SharedAdam(model.params, manifest.optimizer)
  try {
    if (!Number.isSafeInteger(manifest.optimizer.steps) || manifest.optimizer.steps < 0)
      throw Error('Dual policy checkpoint optimizer steps invalid')
    adam.steps = manifest.optimizer.steps
    const groups = [model.params, adam.first, adam.second]
    if (!Array.isArray(manifest.layout)
        || manifest.layout.length !== 3 * model.params.length)
      throw Error('Dual policy checkpoint layout length mismatch')
    let expectedOffset = 0
    for (const [index, item] of manifest.layout.entries()) {
      const groupIndex = Math.floor(index / model.params.length)
      const targetIndex = index % model.params.length
      const target = groups[groupIndex][targetIndex]
      if (item.group !== groupIndex || item.offset !== expectedOffset
          || item.bytes !== target.size * 4
          || JSON.stringify(target.shape) !== JSON.stringify(item.shape))
        throw Error(`Dual policy checkpoint layout mismatch at ${index}`)
      expectedOffset += item.bytes
      const raw = payload.subarray(item.offset, expectedOffset)
      const values = new Float32Array(item.bytes / 4)
      for (let value = 0; value < values.length; value++)
        values[value] = raw.readFloatLE(value * 4)
      const tensor = tf.tensor(values, item.shape)
      if (groupIndex === 0) { target.assign(tensor); tensor.dispose() }
      else {
        target.dispose()
        groups[groupIndex][targetIndex] = tensor
      }
    }
    if (expectedOffset !== payload.length)
      throw Error('Dual policy checkpoint layout byte count mismatch')
    return { model, adam, counters: manifest.counters, manifest }
  } catch (error) {
    adam.dispose()
    model.dispose()
    throw error
  }
}
