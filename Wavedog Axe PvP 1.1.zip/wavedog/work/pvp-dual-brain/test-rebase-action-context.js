import assert from 'node:assert/strict'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './fresh-policy.js'
import { SharedAdam } from './fresh-optimizer-checkpoint.js'
import { addPublicHealthInput, addActionContextInput, addAttackContextOutput } from './migrate-public-health.js'
import { rebaseActionContext } from './rebase-action-context.js'

await tf.setBackend('cpu'); await tf.ready()
const base=new DualPolicy({fast:8,slow:16,heads:2,layers:1,ff:24,interval:2,memory:4})
const adam=new SharedAdam(base.params);adam.steps=19
adam.first[0].dispose();adam.first[0]=tf.fill(base.params[0].shape,.123)
adam.second[0].dispose();adam.second[0]=tf.fill(base.params[0].shape,.456)
const manifest={optimizer:{},sha256:'latest-live'}
const live={model:base,adam,manifest,counters:{lastRolloutSeq:17,dualUpdates:19}}
const health=addPublicHealthInput(live)
const context=addActionContextInput({...health,manifest})
const source={...addAttackContextOutput({...context,manifest},[1,2,4,7,8,12,19,23,31,97]),
  manifest:{...manifest,sha256:'donor-base'}}
const donorModel=new DualPolicy(source.model.config)
const donorAdam=new SharedAdam(donorModel.params);donorAdam.steps=source.adam.steps
for(let i=0;i<donorModel.params.length;i++){
  donorModel.params[i].assign(source.model.params[i])
  for(const key of ['first','second']){donorAdam[key][i].dispose();donorAdam[key][i]=source.adam[key][i].clone()}
}
tf.tidy(()=>donorModel.actionContextOut[2].b.assign(tf.tensor1d([0,0,2,0,0])))
donorModel.config.distributionVersion=3;donorModel.config.calibratedHeads=[2,4,5]
donorModel.config.weaponConditionedAttack=2
const donor={model:donorModel,adam:donorAdam,manifest:{...manifest,sha256:'donor'},counters:source.counters}
let merged
try {
  merged=rebaseActionContext(live,donor,source)
  assert.deepEqual(merged.model.config.actionContextHeads,[2,5,4])
  assert.deepEqual(merged.model.config.attackContextFeatures,donorModel.config.attackContextFeatures)
  assert.equal(merged.model.config.weaponConditionedAttack,2)
  assert.deepEqual([...merged.model.actionContextOut[2].b.dataSync()],[0,0,2,0,0])
  assert.equal(merged.adam.steps,19)
  assert.equal(merged.counters.lastRolloutSeq,17)
  for(let i=0;i<base.params.length;i++){
    assert.deepEqual([...merged.model.params[i].dataSync()],[...base.params[i].dataSync()])
    for(const key of ['first','second'])
      assert.deepEqual([...merged.adam[key][i].dataSync()],[...adam[key][i].dataSync()])
  }
  assert.throws(()=>rebaseActionContext({...source,manifest},donor,source),/already has an adapter/)
  console.log('CONTEXT_REBASE_PASS: three learned heads, physical timing schema, latest live parameters and Adam preserved')
} finally {
  for(const item of [live,health,context,source,donor,merged].filter(Boolean)){
    item.adam.dispose();item.model.dispose()
  }
}
