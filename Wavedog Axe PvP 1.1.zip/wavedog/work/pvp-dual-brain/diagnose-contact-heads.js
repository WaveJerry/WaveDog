import fs from 'node:fs'
import * as tf from '@tensorflow/tfjs'
import { loadDualCheckpoint } from './fresh-optimizer-checkpoint.js'
import { deployedImitationLogits, disposeState } from './human-imitation.js'
await tf.setBackend('cpu'); await tf.ready()
const [checkpoint, datasetPath, destination] = process.argv.slice(2)
const loaded=loadDualCheckpoint(checkpoint);loaded.adam.dispose()
const dataset=JSON.parse(fs.readFileSync(datasetPath))
const report={checkpointSha256:loaded.manifest.sha256, groups:{},examples:[]}
try {
  for(const trace of dataset.trajectories.filter(t=>!t.sourceKind)){
    let state=loaded.model.initialState()
    try {
      for(const frame of trace.frames){
        const result=tf.tidy(()=>{
          const output=loaded.model.step(tf.tensor2d([frame.observation]),state,frame.legalMasks,frame.publicHealthFeatures)
          const deployed=deployedImitationLogits(loaded.model,output.logits,frame)
          return {state:output.state,raw:[...output.logits[5].dataSync()],
            probability:tf.softmax(deployed[5]).dataSync()[1],gate:output.gate.dataSync()[5],
            fast:[...output.fastLogits[5].dataSync()],slow:[...output.slowLogits[5].dataSync()]}
        })
        disposeState(state,result.state);state=result.state
        if(frame.labels['5']!==1)continue
        const key=[trace.split,frame.publicRequest.self.shieldAvailable?'shield-available':'shield-unavailable',
          frame.context.swordSustainWindow?'sustain':frame.context.swordDpsWindow?'followup':'other'].join(':')
        const group=report.groups[key]||={count:0,swordProbability:0,rawAxeSwordGap:0,gate:0}
        group.count++;group.swordProbability+=result.probability;group.rawAxeSwordGap+=result.raw[0]-result.raw[1];group.gate+=result.gate
        if(report.examples.filter(e=>e.group===key).length<2)report.examples.push({group:key,tick:frame.tick,
          probability:result.probability,fast:result.fast,slow:result.slow,gate:result.gate,phase:frame.analysisPhase})
      }
    }finally{disposeState(state)}
  }
  for(const group of Object.values(report.groups))for(const key of ['swordProbability','rawAxeSwordGap','gate'])group[key]/=group.count
  fs.writeFileSync(destination,JSON.stringify(report,null,2));console.log(JSON.stringify(report.groups))
}finally{loaded.model.dispose()}
