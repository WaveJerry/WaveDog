// Reuse the deployed causal context and technique conditioning. Never derive
// a context from the next frame, a damage receipt or hidden opponent state.
import fs from 'node:fs'
import { meleeEntryContext, meleeTechniqueGoal } from './fresh-melee-progress.js'
import { conditionTechniqueObservation } from './technique-conditioning.js'

const [source, destination] = process.argv.slice(2)
if (!source || !destination || source === destination) throw Error('Need separate input/output dataset paths')
const dataset = JSON.parse(fs.readFileSync(source, 'utf8'))
for (const trace of dataset.trajectories) {
  let previous = null, previousContext = null
  for (const frame of trace.frames) {
    const request = frame.publicRequest
    if (!request || request.tick !== frame.tick || request.matchId !== trace.matchId)
      throw Error('Missing aligned public request')
    const context = meleeEntryContext(previous, request, previousContext)
    const { focus, techniqueCues } = meleeTechniqueGoal(request, context)
    frame.context = context
    frame.tacticalGoal = { requestedFocus: request.focus, effectiveFocus: focus, techniqueCues }
    frame.observation = conditionTechniqueObservation(frame.observation, focus, techniqueCues)
    previous = request; previousContext = context
  }
}
dataset.contextConditioning = 'deployed-meleeEntryContext-and-meleeTechniqueGoal; past/current-public-requests-only'
fs.writeFileSync(destination, JSON.stringify(dataset))
console.log(JSON.stringify({ destination, trajectories: dataset.trajectories.length,
  frames: dataset.trajectories.reduce((sum, trace) => sum + trace.frames.length, 0) }))
