"""Reproduce the two requested duels from durable frames and PPO journals.

Read-only with respect to the server, controllers, model weights and optimizer.
"""
import collections
import gzip
import hashlib
import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUNTIME = ROOT / 'work/wavedog-protocol/runtime'
JOURNAL = ROOT / 'work/pvp-8.6-dual-fresh/model/rollouts'
OUT = ROOT / 'outputs/wavejerry-duels-20261116-1334'
SELECTED = [
    ('14eaa075-216d-4e57-ab38-1db61ad5b5c8', 3785),
    ('0d61d7c9-b661-4f9b-adf7-f438913278b8', 3786),
]


def read_rows(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def load_rollout(seq):
    path = JOURNAL / f'rollout-{seq:012d}.json.gz'
    return path, json.loads(gzip.decompress(path.read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def attack_probability(frame):
    # Exactly two legal hand choices: wait / attack. Float32 rounding may
    # store wait=1 and therefore loses the tiny complementary probability.
    assert [i for i, legal in enumerate(frame['legalMasks'][4]) if legal] == [0, 2]
    logp = frame['oldHeadLogProbs'][4]
    return math.exp(logp) if frame['actions'][4] == 2 else -math.expm1(logp)


def main():
    events = read_rows(RUNTIME / 'client-events.jsonl')
    report = {'created': datetime.now(timezone.utc).isoformat(),
              'serverRestarted': False, 'weightsChanged': False,
              'gameCommandsSent': False, 'matches': []}
    for match_id, seq in SELECTED:
        source = RUNTIME / f'{match_id}-frames.jsonl'
        frames = read_rows(source)
        neural = [f for f in frames if f['mode'] == 'NEURAL']
        journal_path, rollout = load_rollout(seq)
        episode = rollout['episode']
        match_events = [e for e in events if e.get('matchId') == match_id]
        expired = [f for f in neural if f['owners']['movement'] == 'neutral-expired']
        runs = []
        for f in expired:
            if runs and f['tick'] == runs[-1][1] + 1:
                runs[-1][1] = f['tick']
            else:
                runs.append([f['tick'], f['tick']])
        attacks = []
        for f in neural:
            if not f['attackPacket']:
                continue
            attacks.append({'tick': f['tick'], 'slot': f['command']['slot'],
                            'preExecutionCharge': f['self']['charge'],
                            'reach': f['observation']['reach']})
        model_decisions = [f for f in episode if f['executedHeads'][4]]
        legal = [f for f in model_decisions if f['observation'][97] <= 0
                 and f['observation'][1] >= .85
                 and f['observation'][8] < .5 and f['observation'][23] < .5]
        model_by_weapon = {}
        for weapon in ['sword', 'axe']:
            sample = [f for f in legal if (f['observation'][12] < .25) == (weapon == 'sword')]
            model_by_weapon[weapon] = {'chargedInReachExecutedDecisions': len(sample),
                'attackChoices': sum(f['actions'][4] == 2 for f in sample),
                'meanOriginalAttackProbability': sum(map(attack_probability, sample)) / len(sample)
                if sample else None}
        positive_incoming = [e for e in match_events if e['type'] == 'damage'
                             and e.get('victim') == 'WaveDog' and e.get('amount', 0) > 0
                             and not e.get('cancelled')]
        receipts = [e for e in match_events if e['type'] == 'training-receipt']
        report['matches'].append({
            'matchId': match_id, 'rolloutSeq': seq,
            'start': next(e['at'] for e in match_events if e['type'] == 'start'),
            'end': next(e['at'] for e in match_events if e['type'] == 'end'),
            'originalPolicySha': episode[0]['checkpointSha256'],
            'source': str(source), 'sourceSha256': sha(source),
            'rollout': str(journal_path), 'rolloutSha256': sha(journal_path),
            'physicalFrames': len(frames), 'neuralFrames': len(neural),
            'neuralAttackPackets': len(attacks),
            'neuralSwordAttackPackets': sum(a['slot'] == 0 for a in attacks),
            'neuralAxeAttackPackets': sum(a['slot'] == 7 for a in attacks),
            'expiredMovementFrames': len(expired), 'expiredMovementRuns': runs,
            'longestExpiredRunTicks': max((b-a+1 for a, b in runs), default=0),
            'modelMovements': dict(collections.Counter(
                (f"{f['modelAction']['forward']},{f['modelAction']['side']}")
                for f in neural if f.get('modelAction'))),
            'neuralJumpCommandFrames': sum(f['command']['jump'] for f in neural),
            'modelByObservedWeapon': model_by_weapon,
            'actualAttacks': attacks,
            'neuralWeaponSwitchTicks': [f['tick'] for f in neural
                                       if 'held_item_slot' in f['actualPackets']],
            'incomingPositiveHits': len(positive_incoming),
            'incomingNativeCriticalHits': sum(e.get('nativeCritical', False) for e in positive_incoming),
            'neuralDamageDealt': sum(f.get('nativeDealt', 0) for f in neural),
            'neuralDamageReceived': sum(f.get('nativeReceived', 0) for f in neural),
            'modeFrames': dict(collections.Counter(f['mode'] for f in frames)),
            'handoffs': [e for e in match_events if e['type'] == 'handoff'],
            'trainingReceipts': receipts,
        })
    trend = []
    for seq in range(3718, 3785):
        path, r = load_rollout(seq)
        executable = [f for f in r['episode'] if f['executedHeads'][4]]
        trend.append({'seq': seq, 'fighter': r['fighter'], 'partial': r['partial'],
            'savedAtLocal': datetime.fromtimestamp(path.stat().st_mtime,
                timezone(timedelta(hours=8))).isoformat(),
            'modelFrames': len(r['episode']), 'executedHandDecisions': len(executable),
            'attackChoices': sum(f['actions'][4] == 2 for f in executable),
            'policySha': r['episode'][0]['checkpointSha256']})
    report['trainingTrend'] = trend
    report['consecutiveZeroAttackRollouts'] = sum(r['attackChoices'] == 0 for r in trend if r['seq'] >= 3723)
    report['caveats'] = [
        'Physical frames and model decisions differ. Cached decisions can control more than one physical frame.',
        'Weapon in the model observation is before a selected switch; packet weapon counts use command.slot.',
        'Old sampled log probability can round to zero for wait=1. This is not proof that the alternative was mathematically impossible.',
        'PPO trained_frames includes observation-only value/gate training; it is not a count of executed model attacks.',
        'Replay JSON uses the post-match checkpoint, not retired weights. No exact gradient that initiated collapse has been identified.',
    ]
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'duel-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'saved': str(OUT / 'duel-audit.json'),
                      'matches': [(m['matchId'], m['neuralAttackPackets']) for m in report['matches']],
                      'consecutiveZeroAttackRollouts': report['consecutiveZeroAttackRollouts']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
