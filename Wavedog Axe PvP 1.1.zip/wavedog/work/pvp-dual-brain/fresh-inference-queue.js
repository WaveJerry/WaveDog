// Keep one latest public observation per fighter. Stale work must not make a
// valid boundary action arrive several ticks after the opponent's first hit.
export class LatestObservationQueue {
  constructor (run, { schedule = setImmediate, onDrop = () => {}, onError = () => {} } = {}) {
    this.run = run; this.schedule = schedule; this.onDrop = onDrop; this.onError = onError
    this.jobs = new Map(); this.scheduled = false; this.priorityBurst = 0
    this.stats = { processed: 0, coalesced: 0, discarded: 0, maxQueued: 0, maxWaitMs: 0 }
  }
  push (fighter, job) {
    const previous = this.jobs.get(fighter)
    if (previous) {
      if (previous.matchId === job.matchId && previous.tick >= job.tick) {
        this.stats.discarded++; this.onDrop(job); return
      }
      this.stats.coalesced++; this.onDrop(previous)
    }
    this.jobs.set(fighter, { ...job, queuedAt: Date.now() })
    this.stats.maxQueued = Math.max(this.stats.maxQueued, this.jobs.size)
    this.wake()
  }
  clearFighter (fighter) {
    const job = this.jobs.get(fighter)
    if (job) { this.jobs.delete(fighter); this.onDrop(job) }
  }
  wake () {
    if (this.scheduled || !this.jobs.size) return
    this.scheduled = true; this.schedule(() => this.drainOne())
  }
  drainOne () {
    this.scheduled = false
    const entries = [...this.jobs.entries()]
    const priority = entries.find(([, job]) => job.priority)
    const ordinary = entries.find(([, job]) => !job.priority)
    const selected = priority && (!ordinary || this.priorityBurst < 2) ? priority : ordinary || priority
    if (!selected) return
    const [fighter, job] = selected; this.jobs.delete(fighter)
    this.priorityBurst = job.priority ? this.priorityBurst + 1 : 0
    this.stats.maxWaitMs = Math.max(this.stats.maxWaitMs, Date.now() - job.queuedAt)
    try { this.run(job); this.stats.processed++ } catch (failure) { this.onError(failure) }
    this.wake()
  }
}

export function applyDefaultGoal (request, defaultFocus) {
  if (!request.focus && defaultFocus) request.focus = defaultFocus
  return request
}
