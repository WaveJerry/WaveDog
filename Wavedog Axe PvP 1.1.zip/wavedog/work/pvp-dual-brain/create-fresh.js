import path from 'node:path'
import fs from 'node:fs'
import * as tf from '@tensorflow/tfjs'
import { DualPolicy } from './dual-policy.js'
import { SharedAdam, loadDualCheckpoint, saveDualCheckpoint } from './optimizer-checkpoint.js'

await tf.setBackend('cpu')
await tf.ready()
const destination = path.resolve(process.argv[2] || '')
if (!process.argv[2] || fs.existsSync(destination))
  throw Error('Provide a new checkpoint path; existing training data is never overwritten')
const model = new DualPolicy()
const adam = new SharedAdam(model.params)
try {
  const saved = saveDualCheckpoint(destination, model, adam, {
    source: 'fresh-8.6-hybrid', inheritedGruUpdates: 0,
    dualUpdates: 0, dualEpisodes: 0, lastRolloutSeq: 0
  })
  const verified = loadDualCheckpoint(destination)
  try {
    if (verified.manifest.sha256 !== saved.sha256 || verified.adam.steps !== 0)
      throw Error('Fresh checkpoint verification failed')
  } finally {
    verified.adam.dispose(); verified.model.dispose()
  }
  process.stdout.write(JSON.stringify(saved) + '\n')
} finally {
  adam.dispose(); model.dispose()
}
