"""Read-only evidence for the live proximity lesson and recent human ownership."""
from collections import Counter, deque
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / "work/pvp-8.6-dual-fresh/model"
manifest = json.loads((MODEL / "checkpoint.json").read_text(encoding="utf-8"))
result = {"counters": manifest["counters"], "recent_rollouts": [], "recent_human_bouts": []}
for path in sorted((MODEL / "rollouts").glob("rollout-*.json.gz"))[-4:]:
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        row = json.load(stream)
    frames = row["episode"]
    def executed(frame, head):
        return frame.get("executedHeads", [False] * 9)[head]
    result["recent_rollouts"].append({
        "sequence": row["rolloutSeq"], "fighter": row["fighter"], "frames": len(frames),
        "context_versions": dict(Counter(str(f.get("context", {}).get("entryCurriculum")) for f in frames)),
        "entry_events": sum(bool(f.get("context", {}).get("enteredReach")) for f in frames),
        "executed_forward_sprints": sum(executed(f, 0) and executed(f, 1)
            and f["actions"][0] in (1, 5, 6) and f["actions"][1] == 1 for f in frames),
        "executed_attack_choices": sum(executed(f, 4) and f["actions"][4] == 2 for f in frames),
    })
with (MODEL / "coach/bouts.jsonl").open(encoding="utf-8") as stream:
    recent = deque(stream, maxlen=4)
for line in recent:
    row = json.loads(line)
    frames = row.get("frames", [])
    dual = [f for f in frames if f.get("owner") == "dual"]
    result["recent_human_bouts"].append({
        "received": row.get("receivedAt"), "fighter": row.get("fighter"),
        "opponent": row.get("opponent"), "frames": len(frames), "dual": len(dual),
        "status": dict(Counter(f.get("neuralStatus") for f in dual)),
        "executed": sum(bool(f.get("executed")) for f in dual),
        "attack_packets": sum(bool(f.get("attackPacket")) for f in dual),
    })
print(json.dumps(result, ensure_ascii=False, indent=2))
