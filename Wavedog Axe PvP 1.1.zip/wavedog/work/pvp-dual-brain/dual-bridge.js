import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { Worker } from 'node:worker_threads'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import { ACTION_WIDTHS, OBS_SIZE, maskActionLogits } from './dual-policy.js'
import { loadDualCheckpoint } from './optimizer-checkpoint.js'
import { conditionTechniqueObservation } from './technique-conditioning.js'
import { RolloutJournal } from './rollout-journal.js'

await tf.setBackend('cpu')
await tf.ready()
const checkpointPath = path.resolve(process.argv[2] || '')
const project = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\//, '')),
  '../pvp-player-client')
const server = path.join('D:', 'Walt Disney', 'Minecraft-1.21.1-Server')
const classpath = [path.join(project, 'bridge-classes'),
  path.resolve(project, '../pvp-neural-lab/classes'),
  path.join(server, 'versions/1.21.1/paper-1.21.1.jar'),
  path.join(server, 'libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')]
  .join(path.delimiter)
const historyFolders = new Map([
  ['history-44kk', path.resolve(project, '../pvp-dual-brain/models/history-44kk')],
  ['history-48k', path.resolve(project,
    'new-learning/backups/before-hybrid-wavedog-20261112-122357/work/pvp-player-client/new-learning/models')],
  ['history-53k', path.resolve(project,
    'new-learning/backups/before-shield-handover-20261112-162729')],
  ['history-119k', path.resolve(project,
    'new-learning/backups/before-shared-clones-20261113-170732/models')]
])
for (const [role, folder] of historyFolders)
  if (!fs.existsSync(path.join(folder, 'recurrent-ppo.json')))
    throw Error(`Missing frozen checkpoint ${role}: ${folder}`)
if (!fs.existsSync(checkpointPath)) throw Error(`Missing dual checkpoint: ${checkpointPath}`)
let loaded = loadDualCheckpoint(checkpointPath)
let model = loaded.model
loaded.adam.dispose()
const journal = new RolloutJournal(path.join(path.dirname(checkpointPath), 'rollouts'),
  loaded.counters.lastRolloutSeq || 0)
const recoveredRollouts = journal.pending(loaded.counters.lastRolloutSeq || 0)
const recoveryPending = new Set(recoveredRollouts.map(row => row.rolloutSeq))
const sidecar = spawn(path.join(server, 'runtime/java21/bin/java.exe'),
  ['-cp', classpath, 'local.wavedog.lab.ProtocolPlayerBridge',
    path.join(project, 'new-learning/models'), '--observe-only'],
  { cwd: project, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
const histories = new Map([...historyFolders].map(([role, folder]) => [role,
  spawn(path.join(server, 'runtime/java21/bin/java.exe'),
    ['-cp', classpath, 'local.wavedog.lab.ProtocolPlayerBridge', folder],
    { cwd: project, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })]))
const trainer = new Worker(new URL('./dual-trainer-worker.js', import.meta.url),
  { workerData: { checkpointPath } })
const actors = new Map(), pending = new Map(), historicalPending = new Map()
let sidecarReady = false, trainerReady = false, ready = false
const historiesReady = new Set()
const FORWARD = [0, 1, -1, 0, 0, 1, 1, -1, -1]
const SIDE = [0, 0, 0, -1, 1, -1, 1, -1, 1]
const SLOT = [7, 0, 1, 4, -1]
function emit (value) { process.stdout.write(JSON.stringify(value) + '\n') }
function error (message) { emit({ event: 'error', message: String(message) }) }
function stateTensors (state) {
  if (!state) return []
  return [state.fast, state.slow, ...state.pending,
    ...state.caches.flatMap(cache => cache ? [cache.key, cache.value] : [])]
    .filter(Boolean)
}
function disposeState (state, next = null) {
  const retained = new Set(next ? stateTensors(next) : [])
  for (const tensor of new Set(stateTensors(state)))
    if (!retained.has(tensor)) tensor.dispose()
}
function maybeReady () {
  if (sidecarReady && historiesReady.size === histories.size && trainerReady
      && !recoveryPending.size && !ready) {
    ready = true
    emit({ event: 'ready', model: 'DUAL-GRU-GTRXL',
      architecture: 'GRU64+GTrXL4x256+learned-gate PPO Adam',
      checkpoint: checkpointPath, dualUpdates: loaded.counters.dualUpdates || 0 })
  }
}
function legalMasks (req) {
  const masks = ACTION_WIDTHS.map(width => Array(width).fill(true))
  if (req.self?.ground === false) masks[2][1] = false
  if (!req.self?.shieldAvailable) masks[4][1] = false
  const bowReady = req.self?.hasBow && req.self?.arrows > 0
  const crossbowReady = req.self?.hasCrossbow
    && (req.self?.arrows > 0 || req.self?.crossbowLoaded)
  if (!bowReady && !crossbowReady) masks[4][3] = false
  if (!bowReady) masks[5][2] = false
  if (!crossbowReady) masks[5][3] = false
  return masks
}
function sample (probabilities) {
  let draw = Math.random()
  for (let action = 0; action < probabilities.length; action++) {
    draw -= probabilities[action]
    if (draw <= 0) return action
  }
  return probabilities.length - 1
}
function decode (req, actions) {
  const hand = actions[4]
  return { model: 'DUAL-GRU-GTRXL', fighter: req.fighter,
    opponent: req.opponent, requestId: req.requestId,
    decidedTick: req.tick, focus: req.focus,
    yaw: req.yaw, pitch: req.pitch,
    forward: FORWARD[actions[0]], side: SIDE[actions[0]],
    sprint: actions[1] === 1, jump: actions[2] === 1,
    sneak: actions[3] === 1, shield: hand === 1,
    attack: hand === 2, slot: SLOT[actions[5]] < 0
      ? (req.self?.held ?? 7) : SLOT[actions[5]],
    use: hand === 3, release: hand === 4,
    observedArrows: req.seen?.arrows?.length || 0 }
}
function observed (message) {
  const req = pending.get(message.requestId)
  pending.delete(message.requestId)
  const actor = actors.get(message.fighter)
  if (!req || !actor || actor.opponent !== message.opponent
      || req.fighter !== message.fighter) return
  if (!Array.isArray(message.observation)
      || message.observation.length !== OBS_SIZE)
    throw Error('Public observation shape mismatch')
  const conditioned = conditionTechniqueObservation(message.observation,
    req.focus, req.techniqueCues)
  const previous = actor.state
  const masks = legalMasks(req)
  const outcome = tf.tidy(() => {
    const observation = tf.tensor2d([conditioned], [1, OBS_SIZE])
    const output = model.step(observation, previous)
    const masked = maskActionLogits(output.logits, masks)
    const probabilities = masked.map(head => [...tf.softmax(head).dataSync()])
    const actions = probabilities.map(sample)
    return { state: output.state, actions,
      oldHeadLogProbs: probabilities.map((head, index) =>
        Math.log(Math.max(1e-30, head[actions[index]]))),
      oldValue: output.value.dataSync()[0],
      gate: [...output.gate.dataSync()] }
  })
  actor.state = outcome.state
  disposeState(previous, actor.state)
  const frame = { observation: conditioned, actions: outcome.actions,
    oldHeadLogProbs: outcome.oldHeadLogProbs,
    oldValue: outcome.oldValue, reward: 0, done: false,
    executedHeads: ACTION_WIDTHS.map(() => false), legalMasks: masks,
    decidedTick: req.tick }
  actor.frames.push(frame)
  actor.byTick.set(req.tick, frame)
  actor.gateSum += outcome.gate.reduce((sum, weight) => sum + weight, 0)
  actor.gateCount += outcome.gate.length
  emit(decode(req, outcome.actions))
}
function handleSidecar (message) {
  if (message.event === 'ready') {
    if (message.architecture !== 'PUBLIC-OBS-98')
      throw Error(`Unexpected Java observation bridge: ${message.architecture}`)
    sidecarReady = true; maybeReady(); return
  }
  if (message.model === 'DUAL-OBS') { observed(message); return }
  if (message.event === 'error') error(`observation bridge: ${message.message}`)
}
function handleHistory (role, message) {
  if (message.event === 'ready') {
    if (message.architecture !== 'GRU64-PPO')
      throw Error(`Unexpected historical bridge: ${message.architecture}`)
    historiesReady.add(role); maybeReady(); return
  }
  if (message.model === 'GRU64-PPO') {
    const actor = actors.get(message.fighter)
    const req = historicalPending.get(message.requestId)
    historicalPending.delete(message.requestId)
    if (actor?.role === role && actor.opponent === message.opponent
        && req?.fighter === message.fighter) {
      const available = message.slot === 1 ? req.self?.hasBow
        : message.slot === 4 ? req.self?.hasCrossbow : true
      emit({ ...message, leagueRole: role,
        slot: available ? message.slot : 7,
        use: available ? message.use : false,
        release: available ? message.release : false })
    }
    return
  }
  if (message.event === 'error') error(`historical bridge: ${message.message}`)
}
function handleTrainer (message) {
  if (message.event === 'trainer_ready') {
    trainerReady = true
    for (const row of recoveredRollouts) trainer.postMessage(row)
    maybeReady(); return
  }
  if (message.event === 'training_error') { emit(message); return }
  if (message.event !== 'trained' && message.event !== 'trained_partial') return
  const refreshed = loadDualCheckpoint(checkpointPath)
  const old = model
  model = refreshed.model
  refreshed.adam.dispose()
  loaded = refreshed
  old.dispose()
  recoveryPending.delete(message.rolloutSeq)
  emit(message)
  maybeReady()
}
readline.createInterface({ input: sidecar.stdout }).on('line', line => {
  try { handleSidecar(JSON.parse(line)) } catch (failure) { error(failure.stack || failure) }
})
sidecar.stderr.on('data', data => process.stderr.write(data))
sidecar.on('exit', code => { error(`Observation bridge exited ${code}`); process.exit(1) })
for (const [role, history] of histories) {
  readline.createInterface({ input: history.stdout }).on('line', line => {
    try { handleHistory(role, JSON.parse(line)) }
    catch (failure) { error(failure.stack || failure) }
  })
  history.stderr.on('data', data => process.stderr.write(data))
  history.on('exit', code => { error(`${role} bridge exited ${code}`); process.exit(1) })
}
trainer.on('message', message => {
  try { handleTrainer(message) } catch (failure) { error(failure.stack || failure) }
})
trainer.on('error', failure => { error(failure.stack || failure); process.exit(1) })
trainer.on('exit', code => { if (code) { error(`Trainer exited ${code}`); process.exit(1) } })

readline.createInterface({ input: process.stdin }).on('line', line => {
  try {
    const req = JSON.parse(line)
    const actor = actors.get(req.fighter)
    switch (req.command) {
      case 'reset': {
        if (actor) disposeState(actor.state)
        actors.set(req.fighter, { opponent: req.opponent,
          role: historyFolders.has(req.role) ? req.role : 'current',
          state: historyFolders.has(req.role) ? null : model.initialState(),
          frames: [], byTick: new Map(),
          gateSum: 0, gateCount: 0 })
        const destination = histories.get(req.role) || sidecar
        destination.stdin.write(JSON.stringify({ ...req, learning: false }) + '\n')
        break
      }
      case 'act':
        if (!actor || actor.opponent !== req.opponent)
          throw Error('Missing or changed named opponent')
        if (historyFolders.has(actor.role)) {
          historicalPending.set(req.requestId, req)
          histories.get(actor.role).stdin.write(line + '\n')
        }
        else { pending.set(req.requestId, req); sidecar.stdin.write(line + '\n') }
        break
      case 'executed': {
        const frame = actor?.byTick.get(req.decidedTick)
        if (frame) frame.executedHeads = ACTION_WIDTHS.map((_, index) =>
          !req.ignoredHeads.includes(index))
        break
      }
      case 'native_step': {
        const frame = actor?.byTick.get(req.decidedTick)
        if (frame && Number.isFinite(req.reward)) frame.reward += req.reward
        break
      }
      case 'feedback': {
        const frame = actor?.frames.at(-1)
        if (frame) frame.reward += ((req.dealt || 0) - (req.received || 0)) / 20
        break
      }
      case 'finish':
      case 'partial': {
        if (!actor) throw Error('Missing fighter to train')
        if (historyFolders.has(actor.role)) {
          emit({ event: 'history_finished', fighter: req.fighter, round: req.round,
            role: actor.role, checkpoint: path.join(historyFolders.get(actor.role),
              'recurrent-ppo.json'), frozen: true })
          break
        }
        const frames = actor.frames
        if (!frames.length) throw Error('Fighter has no rollout frames')
        const terminal = req.command === 'finish'
          ? (req.win ? 1 + Math.max(0, req.health || 0) / 40 : -1) : 0
        if (terminal) {
          const shared = .4 * terminal / frames.length
          for (const frame of frames) frame.reward += shared
          frames.at(-1).reward += .6 * terminal
        }
        try {
          const durable = journal.append({ episode: frames, fighter: req.fighter,
            round: req.round, partial: req.command === 'partial',
            requestId: req.requestId || `${req.fighter}:${req.round}:${req.command}` })
          trainer.postMessage(durable)
        } catch (failure) {
          emit({ event: 'training_error', fighter: req.fighter, round: req.round,
            error: `PPO journal write failed: ${failure.stack || failure}` })
          break
        }
        actor.frames = []; actor.byTick.clear()
        break
      }
      case 'close':
        sidecar.stdin.end()
        for (const history of histories.values()) history.stdin.end()
        trainer.terminate(); process.exit(0)
        break
      default: throw Error(`Unknown bridge command: ${req.command}`)
    }
  } catch (failure) { error(failure.stack || failure) }
})
