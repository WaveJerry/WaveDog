// Prove V8 LiveEdit supports this process's ESM shape before touching a learner.
const fs = require('node:fs')
const path = require('node:path')
const { spawn } = require('node:child_process')
const assert = require('node:assert/strict')
async function main () {
  const folder = path.join(__dirname, 'runtime/live-edit-test')
  fs.mkdirSync(folder, { recursive: true })
  const file = path.join(folder, 'probe.mjs')
  const before = 'await Promise.resolve();\nexport function tactic(x) { return x + 1 }\nsetInterval(() => process.stdout.write(String(tactic(1)) + "\\n"), 100);\n'
  fs.writeFileSync(file, before)
  const child = spawn(process.execPath, ['--inspect=127.0.0.1:0', file],
    { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
  let ws
  try {
    const url = await new Promise((resolve, reject) => {
      let buffer = ''
      child.stderr.on('data', block => {
        buffer += block
        const match = buffer.match(/ws:\/\/127\.0\.0\.1:\d+\/[a-z0-9-]+/)
        if (match) resolve(match[0])
      })
      child.on('error', reject)
    })
    ws = new WebSocket(url)
    const pending = new Map(), scripts = []
    let next = 0
    ws.addEventListener('message', event => {
      const data = JSON.parse(event.data)
      if (data.id) { pending.get(data.id)?.(data); pending.delete(data.id) }
      else if (data.method === 'Debugger.scriptParsed') scripts.push(data.params)
    })
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve); ws.addEventListener('error', reject)
    })
    const call = (method, params = {}) => new Promise((resolve, reject) => {
      const id = ++next
      const timer = setTimeout(() => reject(Error('Inspector timeout')), 10000)
      pending.set(id, row => { clearTimeout(timer); row.error ? reject(Error(JSON.stringify(row.error))) : resolve(row.result) })
      ws.send(JSON.stringify({ id, method, params }))
    })
    await call('Debugger.enable')
    const script = scripts.find(row => row.url.endsWith('/probe.mjs'))
    assert(script, 'probe script found')
    const changed = before.replace('return x + 1', 'return x + 2')
    const preflight = await call('Debugger.setScriptSource', { scriptId: script.scriptId, scriptSource: changed, dryRun: true })
    assert.equal(preflight.status, 'Ok')
    const result = await call('Debugger.setScriptSource', { scriptId: script.scriptId, scriptSource: changed })
    assert.equal(result.status, 'Ok')
    const observed = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Error('Changed function did not run')), 3000)
      child.stdout.on('data', block => {
        if (String(block).split(/\s+/).includes('3')) { clearTimeout(timer); resolve(true) }
      })
    })
    console.log(JSON.stringify({ result: 'LIVE_EDIT_ESM_PASS', topLevelAwait: true, observed }))
  } finally {
    ws?.close(); child.kill()
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
