import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import * as tf from '@tensorflow/tfjs'
import { addPublicHealthInput, addActionContextInput, addAttackContextOutput } from './migrate-public-health.js'
import { loadDualCheckpoint, saveDualCheckpoint } from './fresh-optimizer-checkpoint.js'

const equal = (a, b) => {
  const x = a.dataSync(), y = b.dataSync()
  return Buffer.from(x.buffer, x.byteOffset, x.byteLength)
    .equals(Buffer.from(y.buffer, y.byteOffset, y.byteLength))
}
const contextParams = model => [model.actionContextIn, ...model.actionContextOut].flatMap(x => x.params)

// Transfer ONLY the new supervised residual. Production PPO progress, moments,
// learning rate and sequence counters always come from the latest production.
export function rebaseActionContext (live, donor, source) {
  const donorContext = contextParams(donor.model)
  const start = donor.model.params.indexOf(donorContext[0])
  assert.equal(start, source.model.params.indexOf(contextParams(source.model)[0]))
  assert.equal(donor.adam.steps, source.adam.steps, 'donor must not contain independent PPO')
  assert.equal(donor.counters.lastRolloutSeq, source.counters.lastRolloutSeq)
  for (let i = 0; i < start; i++) {
    assert(equal(donor.model.params[i], source.model.params[i]), 'donor changed original trunk/head')
    for (const key of ['first', 'second']) assert(equal(donor.adam[key][i], source.adam[key][i]), 'donor changed PPO moments')
  }
  const intermediates = []; let merged = live
  try {
    if (!merged.model.config.publicHealthInputs) {
      merged = addPublicHealthInput(merged); intermediates.push(merged)
    }
    if (!merged.model.config.actionContextHeads) {
      merged = addActionContextInput({ ...merged, manifest: live.manifest }); intermediates.push(merged)
    } else throw Error('Production already has an adapter; refuse to overwrite its new PPO learning')
    if (donor.model.config.actionContextHeads.includes(4)) {
      merged = addAttackContextOutput({ ...merged, manifest: live.manifest }, donor.model.config.attackContextFeatures)
      intermediates.push(merged)
    }
    const target = contextParams(merged.model)
    assert.equal(target.length, donorContext.length)
    for (let i = 0; i < target.length; i++) target[i].assign(donorContext[i])
    merged.model.config.distributionVersion = donor.model.config.distributionVersion
    merged.model.config.calibratedHeads = [...donor.model.config.calibratedHeads]
    merged.model.config.weaponConditionedAttack = donor.model.config.weaponConditionedAttack || 0
    merged.counters = { ...live.counters, publicHealthInputVersion: 1, actionContextInputVersion: 1,
      actionContextRebase: { liveSha256: live.manifest.sha256, donorSha256: donor.manifest.sha256,
        donorBaseSha256: source.manifest.sha256, originalWeightsAndAdamPreserved: true } }
    assert.equal(merged.adam.steps, live.adam.steps)
    for (let i = 0; i < live.model.params.length; i++) {
      assert(equal(live.model.params[i], merged.model.params[i]), 'production weight must survive bit-for-bit')
      for (const key of ['first', 'second']) assert(equal(live.adam[key][i], merged.adam[key][i]), 'production Adam must survive bit-for-bit')
    }
    for (const item of intermediates.slice(0, -1)) { item.adam.dispose(); item.model.dispose() }
    return merged
  } catch (error) {
    for (const item of intermediates) { item.adam.dispose(); item.model.dispose() }
    throw error
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  await tf.setBackend('cpu'); await tf.ready()
  const [liveFile, donorFile, sourceFile, destination] = process.argv.slice(2)
  if (!destination || fs.existsSync(destination)) throw Error('Need live donor base and NEW destination manifest')
  const live = loadDualCheckpoint(liveFile), donor = loadDualCheckpoint(donorFile), source = loadDualCheckpoint(sourceFile)
  let merged
  try {
    merged = rebaseActionContext(live, donor, source)
    const saved = saveDualCheckpoint(destination, merged.model, merged.adam, merged.counters)
    const receipt = { ...merged.counters.actionContextRebase, saved,
      sourceSha256: live.manifest.sha256, trainingPerformed: false, installed: false }
    fs.writeFileSync(path.join(path.dirname(destination), 'rebase-receipt.json'), JSON.stringify(receipt, null, 2))
    console.log(JSON.stringify(receipt))
  } finally {
    for (const item of [live, donor, source, merged].filter(Boolean)) { item.adam.dispose(); item.model.dispose() }
  }
}
