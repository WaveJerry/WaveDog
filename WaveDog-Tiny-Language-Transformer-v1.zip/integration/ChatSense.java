package local.wavedog.chatsense;

import com.google.gson.Gson;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPlaceEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Routes regular player chat to the current duel or to the lobby dialogue. */
public final class ChatSense extends JavaPlugin implements Listener {
    private final Gson json=new Gson();
    private final ExecutorService io=Executors.newSingleThreadExecutor(r->{
        var thread=new Thread(r,"WaveDog-chat-capture");thread.setDaemon(true);return thread;
    });
    private final Path log=Path.of(System.getProperty("wavedog.workspace","D:/CodexWorkspace/ban"))
        .resolve("outputs/pvp-perception-language/player-chat.jsonl");

    @Override public void onEnable(){Bukkit.getPluginManager().registerEvents(this,this);}
    @Override public void onDisable(){
        io.shutdown();
        try{io.awaitTermination(5,TimeUnit.SECONDS);}catch(InterruptedException error){Thread.currentThread().interrupt();}
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void chat(AsyncChatEvent event){
        String text=PlainTextComponentSerializer.plainText().serialize(event.message()).strip();
        if(text.isEmpty()||text.length()>160||text.chars().anyMatch(Character::isISOControl))return;
        UUID id=event.getPlayer().getUniqueId();
        Bukkit.getScheduler().runTask(this,()->capture(id,text));
    }
    private void capture(UUID id,String text){
        Player player=Bukkit.getPlayer(id);
        if(player==null||player.hasMetadata("wavedog-native-player"))return;
        Plugin nativeControl=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
        if(nativeControl==null||!nativeControl.isEnabled())return;
        try{
            if(!recordDuel(nativeControl,player,"text",text))
                nativeControl.getClass().getMethod("receiveLobbyChat",UUID.class,String.class).invoke(nativeControl,id,text);
        }catch(ReflectiveOperationException error){getLogger().warning("Could not route player chat: "+error);}
    }

    private boolean recordDuel(Plugin nativeControl,Player player,String key,String value)throws ReflectiveOperationException{
        Field actorsField=nativeControl.getClass().getDeclaredField("actors");actorsField.setAccessible(true);
        @SuppressWarnings("unchecked") Map<String,Object> actors=(Map<String,Object>)actorsField.get(nativeControl);
        for(MetadataValue owner:player.getMetadata("wavedog-duel-owner")){
            String speaker=owner.asString();Object actor=actors.get(speaker);
            if(actor==null)continue;
            Class<?> type=actor.getClass();
            Field matchField=type.getDeclaredField("match"),opponentField=type.getDeclaredField("opponent"),activeField=type.getDeclaredField("active");
            matchField.setAccessible(true);opponentField.setAccessible(true);activeField.setAccessible(true);
            String match=(String)matchField.get(actor),opponent=(String)opponentField.get(actor);
            if(match==null||!player.getName().equals(opponent)
                ||!activeField.getBoolean(actor)&&!(key.equals("text")&&player.hasMetadata("wavedog-preparation-cage")))continue;
            var row=new LinkedHashMap<String,Object>();
            row.put("id",UUID.randomUUID().toString());row.put("speaker",speaker);row.put("matchId",match);
            row.put("player",player.getName());row.put(key,value);
            row.put("tick",Bukkit.getCurrentTick());row.put("submittedAt",System.currentTimeMillis());
            if(key.equals("technique"))row.put("kind","combat-action");
            String line=json.toJson(row)+"\n";
            io.execute(()->{
                try{Files.createDirectories(log.getParent());Files.writeString(log,line,StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
                catch(Exception error){getLogger().warning("Could not record duel input: "+error);}
            });
            return true;
        }
        return false;
    }

    private void technique(Player player,String name){
        if(player==null||player.hasMetadata("wavedog-native-player")||!player.hasMetadata("wavedog-duel-owner"))return;
        Plugin control=Bukkit.getPluginManager().getPlugin("WaveDogNativeControl");
        if(control==null||!control.isEnabled())return;
        try{recordDuel(control,player,"technique",name);}
        catch(ReflectiveOperationException error){getLogger().warning("Could not route combat observation: "+error);}
    }

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void blockPlaced(BlockPlaceEvent event){
        if(!event.canBuild())return;
        var material=event.getBlockPlaced().getType();
        if(material==Material.RESPAWN_ANCHOR)technique(event.getPlayer(),"anchor");
        else if(material==Material.COBWEB||material==Material.OBSIDIAN)technique(event.getPlayer(),"utility");
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void entityPlaced(EntityPlaceEvent event){
        if(event.getEntity().getType()==EntityType.END_CRYSTAL)technique(event.getPlayer(),"crystal");
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void bucketUsed(PlayerBucketEmptyEvent event){
        if(event.getBucket()==Material.WATER_BUCKET||event.getBucket()==Material.LAVA_BUCKET)
            technique(event.getPlayer(),"utility");
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void thrown(ProjectileLaunchEvent event){
        if(!(event.getEntity().getShooter() instanceof Player player))return;
        if(event.getEntity().getType()==EntityType.ENDER_PEARL)technique(player,"pearl");
        else if(switch(event.getEntity().getType()){
            case SPLASH_POTION,LINGERING_POTION,TRIDENT,SNOWBALL,EGG -> true;
            default -> false;
        })technique(player,"projectile");
    }
}
