// Routing identifies what the player said. Supervision teaches the decoder
// how to answer it in the lobby, during a duel, or under pressure.
export const chatLessons = {
  greeting:{
    match:/^(?:你好|您好|嗨|哈喽|哈啰|在吗|在不在|早上好|晚上好|hello|hi|hey|yo)(?:呀|啊|嘛|吗|哈)?$/iu,
    prompts:['你好','嗨','hi','hey','hello','在吗','哈喽'],
    lodge:['在呢。','嗨，来练吗？'], duel:['嗨，接着打。','在呢，先打这把。']
  },
  ready:{
    match:/^(?:来(?:打)?一把|来一局|准备好了|开打吧|glhf|goodluck|再来(?:一把|一局)?|重开一把)$/iu,
    prompts:['来一把','准备好了','再来一局','开打吧','glhf','good luck'],
    lodge:['来，点对战按钮。','glhf，竞技场见。'],duel:['glhf','来，开打。','行，这把见。']
  },
  gg:{
    match:/^(?:gg|ggwp|wp|gf|好局|打得(?:好|漂亮|不错)|承让)$/iu,
    prompts:['gg','wp','gf','好局','打得好','打得不错'],
    lodge:['gg，有空再打。','好局，下回再来。'],duel:['gg，先打完。','还没完呢，打完再 gg。']
  },
  thanks:{
    match:/^(?:谢谢(?:你|啦|了)?|多谢|谢了|谢啦|thanks|thx|ty)$/iu,
    prompts:['谢谢','多谢','谢了','thanks','thx'],
    lodge:['客气啥。','没事。'],duel:['没事，专心打。','客气啥，来。']
  },
  joke:{
    match:/^(?:哈{2,}|笑死(?:我了)?|lol|666|6|人机|好人机|你(?:是|怎么这么)人机|你是机器人吗|l|ez)$/iu,
    prompts:['哈哈','笑死','666','人机','你是机器人吗','好人机','L','ez'],
    lodge:['被你看出来了。','哈哈，来打一把。','先别急着判。'],
    duel:['哈哈，还能打。','你先打完再说。','行，我记住了。']
  },
  duel:{
    match:/^(?:怎么|怎样|如何|在哪)(?:对战|开打|开局|开始|匹配|进竞技场)(?:呀|啊|嘛|呢)?$/u,
    prompts:['怎么对战','怎么开打','怎么开局','如何开局','在哪对战'],
    lodge:['去竞技场点对战按钮。','竞技场有按钮，点一个就行。'],
    duel:['已经开打了。','这把正在打呢。']
  },
  capability:{
    match:/^(?:你会什么|你会啥|你能做什么|你有什么功能|你能干啥|你能做啥|你能干什么)(?:呀|啊|呢)?$/u,
    prompts:['你会什么','你会啥','你有什么功能','你能做啥','你能干什么'],
    lodge:['我可以陪你练 PvP。','想练 PvP 就来找我。'],
    duel:['现在我正跟你打 PvP。','打完这把，还能换个模式。']
  },
  tactical:{
    match:/(?:为什么|为啥|怎么|怎样|刚才).*(?:弓|盾|暴击|连招|控距|后撤|走位)|(?:弓|盾|暴击|连招|控距|后撤|走位).*(?:怎么|为啥|吗)$/u,
    prompts:['你怎么一直举盾','怎么控距','为啥刚才后撤','刚才怎么接上连招的'],
    lodge:['开一把，我边打边跟你说。','进竞技场再试一下？'],
    duel:['你说刚才哪一下？','刚才哪一刀？我得看当时的距离。']
  },
  meme:{
    match:/^(?:魔怔|来点魔怔|来句魔怔的|来句狠的|弓狗|诗人啊|挖去|逃逸|锚锚虫|相思了|你跑个得儿|开了|没一个是人|梅夷阁诗人|根本不是人|根本不诗人|就不是人|九步诗人)$/u,
    prompts:['来点魔怔','来句魔怔的','弓狗','诗人啊','挖去','逃逸','锚锚虫','相思了','没一个是人','梅夷阁诗人','根本不诗人','九步诗人'],
    lodge:['梅夷阁诗人，来跟我打一把。','九步诗人，竞技场见。'],
    duel:['根本不诗人，还没打完呢。','九步诗人，这把还有得打。']
  }
}

export function normalizeChat(text){
  return text.trim().replace(/^(?:WaveDog(?:Son|Brother|Father|Sister)?)[\s，,:：]+/iu,'')
    .replace(/[\p{P}\s]+/gu,'')
}
export function chatTopic(text){
  const clean=normalizeChat(text)
  if(/^(?:你好|嗨)(?:来(?:打)?一把|开打吧)$/u.test(clean))return 'ready'
  return Object.entries(chatLessons).find(([,lesson])=>lesson.match.test(clean))?.[0]??null
}

export function replyKey(text){
  return text?.replace(/[\p{P}\s]+/gu,'').toLowerCase()??''
}

export function fluentReply(text,lastText=null){
  if(!text||text.length>40||/^\s*[/@]/u.test(text)||
    /[，、,:：]\s*(?:$|[。！？])|[\p{Cc}\p{Cf}]/u.test(text))return false
  const plain=replyKey(text)
  if(plain===replyKey(lastText))return false
  return plain.length>0&&!/(.{2,8})\1|(.)(?:\2){3,}/u.test(plain)&&
    !/(?:第一敲|继续打。$|还能接着打|东方明珠塔跑得|血线快[。！？]|这颗真打完)/u.test(text)
}
