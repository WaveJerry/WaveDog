import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {spawn} from 'node:child_process'
import readline from 'node:readline'
import {openLobbyLearning} from './lobby-learning.js'
import {createTokenSpeech} from './generation-live.js'
import {loadReplyModel, split} from './generation-runtime.mjs'
import {memeVocabulary, victoryLessons} from './combat-memes.js'

const root=path.resolve('outputs/pvp-perception-language')
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'wavedog-live-online-'))
const checkpoint=path.join(directory,'checkpoint.json')
fs.copyFileSync(path.join(root,'checkpoint.json'),checkpoint)
const profilePath=path.join(root,'speech-profile.json')
const intentOnly=fs.existsSync(profilePath)&&JSON.parse(fs.readFileSync(profilePath,'utf8')).mode==='intent-v1'
if(intentOnly)fs.copyFileSync(profilePath,path.join(directory,'speech-profile.json'))
const tokenPath=process.argv[2]
if(tokenPath)fs.copyFileSync(tokenPath,path.join(directory,'reply.int8.bin'))
const contextualPath=process.argv[3]
if(contextualPath)fs.copyFileSync(contextualPath,path.join(directory,'reply-context.int8.bin'))
const combatPath=process.argv[4]
if(combatPath)fs.copyFileSync(combatPath,path.join(directory,'reply-combat.int8.bin'))
const frame={
  self:{x:1000,y:221,z:1000,eyeY:222.62,health:20,charge:1,ground:true,
    vx:0,vy:0,vz:0,shieldAvailable:true,shielding:false,using:false,useTicks:0,
    arrows:8,crossbowLoaded:false,held:0,nativeYaw:-90,nativePitch:0},
  seen:{x:1004,y:221,z:1000,visible:true,using:false,held:'DIAMOND_SWORD',nativeYaw:90,arrows:[]},
  observation:{tick:100,reach:3.7,distance:4,targetShieldRaised:false}
}
const child=spawn(process.execPath,[path.resolve('work/pvp-dual-brain/perception-language/live-worker.js'),checkpoint],
  {stdio:['pipe','pipe','pipe']})
const rows=[],lines=readline.createInterface({input:child.stdout})
lines.on('line',line=>{try{rows.push(JSON.parse(line))}catch{}})
let errors='';child.stderr.on('data',chunk=>{errors+=chunk})
async function until(predicate,limitMs=15000){
  const started=Date.now()
  while(Date.now()-started<limitMs){
    const found=rows.find(predicate)
    if(found)return found
    if(child.exitCode!==null)throw Error('speech worker exited: '+errors)
    await new Promise(resolve=>setTimeout(resolve,100))
  }
  throw Error('speech worker timed out: '+JSON.stringify(rows)+' '+errors)
}
try{
  const ready=await until(row=>row.ready)
  assert.equal(ready.contextualSpeech,Boolean(tokenPath&&contextualPath))
  if(combatPath){
    assert.equal(ready.combatMemes,true)
    const {vocabulary}=loadReplyModel(combatPath)
    for(const phrase of memeVocabulary)
      assert(split(phrase,vocabulary).every(token=>vocabulary.has(token)),phrase)
  }
  if(tokenPath){
    assert.equal(ready.tokenSpeech,true)
    for(const sample of [
      {speaker:'WaveDogSister',playerId:'wrong-bot',text:'你好'},
      {speaker:'WaveDog',playerId:'irrelevant',text:'今天天气如何'},
      {speaker:'WaveDog',playerId:'tester',text:'怎么开打'},
      {speaker:'WaveDog',playerId:'second',text:'你有什么功能'}
    ]) child.stdin.write(JSON.stringify({kind:'lobby',...sample})+'\n')
    const lobby=await until(row=>row.kind==='lobby')
    assert.equal(lobby.speaker,'WaveDog')
    assert.equal(lobby.playerId,'tester')
    assert.match(lobby.text,/竞技场.*按钮/u)
    await new Promise(resolve=>setTimeout(resolve,200))
    assert.equal(rows.filter(row=>row.kind==='lobby').length,1)
    const learned=openLobbyLearning(path.join(directory,'lobby-chat-learning.json'))
    assert.equal(learned.recognize('嗯你有什么功能'),'capability')
    assert.equal(learned.recognize('今天天气如何'),null)
    assert(createTokenSpeech(tokenPath,learned).lobby('嗯你有什么功能'))
  }
  await until(row=>row.trainingReady)
  child.stdin.write(JSON.stringify({speaker:'WaveDogSon',matchId:'test-live-online',
    frame,kind:'prepare'})+'\n')
  if(!ready.combatMemes){
    const greeting=await until(row=>row.speaker==='WaveDogSon'&&row.kind==='prepare')
    assert.equal(greeting.intent,'opener')
    assert(greeting.text.length>0)
    child.stdin.write(JSON.stringify({speaker:'WaveDogSon',matchId:'test-live-online',
      frame,kind:'prepare'})+'\n')
  }
  await new Promise(resolve=>setTimeout(resolve,700))
  assert.equal(rows.filter(row=>row.speaker==='WaveDogSon'&&row.kind==='prepare').length,ready.combatMemes?0:1)
  const chatLog=path.join(directory,'player-chat.jsonl')
  const message={speaker:'WaveDogSon',matchId:'test-live-online',player:'WaveJerry',tick:frame.observation.tick}
  if(ready.conversationalSpeech){
    fs.writeFileSync(chatLog,JSON.stringify({...message,id:'greeting-without-command',text:'hi'})+'\n')
    const reply=await until(row=>row.speaker==='WaveDogSon'&&row.intent==='chat')
    assert.match(reply.text,/在|^嗨|^hi|你好/iu)
    assert.equal(reply.kind,'prepare')
  }
  fs.appendFileSync(chatLog,JSON.stringify({...message,id:'not-a-bow-hit',text:'好箭'})+'\n')
  await new Promise(resolve=>setTimeout(resolve,650))
  const adapterFile=path.join(directory,...(intentOnly?['intent-v1']:[]),'online-adapter.json')
  assert(!fs.existsSync(adapterFile),'a spoken claim alone must not train an event intent')
  fs.appendFileSync(chatLog,JSON.stringify({...message,id:'plain-chat',text:'你好，来打一把'})+'\n')
  if(intentOnly){
    await new Promise(resolve=>setTimeout(resolve,650))
    assert(!fs.existsSync(adapterFile),'v1 learns only from explicit teaching')
  }else{
    const auto=await until(row=>row.chatLearning&&row.mode==='duel')
    assert.equal(auto.revision,1)
    const automaticAdapter=JSON.parse(fs.readFileSync(adapterFile,'utf8'))
    assert(automaticAdapter.chatWeights.some(value=>value!==0))
    assert.deepEqual(automaticAdapter.phrases,{})
  }
  assert(!fs.existsSync(path.join(directory,'live-feedback.jsonl')))
  const teaching={id:'test-live-1',teacher:'WaveJerry',speaker:'WaveDogSon',
    matchId:'test-live-online',intent:'opener',phrase:'来，认真打一把',
    tick:frame.observation.tick,submittedAt:Date.now()}
  fs.writeFileSync(path.join(directory,'live-feedback.jsonl'),JSON.stringify(teaching)+'\n')
  const result=await until(row=>row.feedbackStatus&&row.teacher==='WaveJerry')
  assert(result.message.includes('已学到'),result.message)
  const adapter=JSON.parse(fs.readFileSync(adapterFile,'utf8'))
  assert.equal(adapter.revision,intentOnly?1:2)
  assert(adapter.chatWeights.some(value=>value!==0))
  if(ready.combatMemes){
    const shot={...frame,observation:{...frame.observation,tick:150,targetShotEvent:1,targetShotTick:150}}
    const send=row=>child.stdin.write(JSON.stringify(row)+'\n')
    const bout={speaker:'WaveDogFather',matchId:'test-action-without-chat'}
    const holdingBow={...frame,seen:{...frame.seen,held:'BOW',using:true}}
    send({...bout,kind:'frame',frame:{...frame,nativeEvents:[
      {type:'damage',attacker:'WaveJerry',victim:bout.speaker,amount:3,melee:true}
    ]}})
    send({...bout,kind:'frame',frame:holdingBow})
    await new Promise(resolve=>setTimeout(resolve,250))
    assert(!rows.some(row=>row.matchId===bout.matchId),'melee and bow draw should stay quiet')
    send({...bout,kind:'frame',frame:shot})
    const bow=await until(row=>row.matchId===bout.matchId&&row.intent==='meme_bow')
    assert.match(bow.text,/弓|箭|射/u)
    assert.equal(rows.filter(row=>row.matchId===bout.matchId&&row.kind==='frame').length,1)
    send({...bout,kind:'end',frame:shot,winner:'WaveJerry'})
    send({...bout,kind:'end',frame:shot,winner:'WaveJerry'})
    const ending=await until(row=>row.matchId===bout.matchId&&row.kind==='end')
    assert.equal(ending.text,'错了错了')

    const next={speaker:'WaveDogBrother',matchId:'test-server-action'}
    const actions=[
      [next,'anchor',/锚/u],
      [{speaker:'WaveDogSister',matchId:'test-crystal'},'crystal',/水晶/u],
      [{speaker:'WaveDog',matchId:'test-pearl'},'pearl',/珍珠|逃逸|跑个得儿/u],
      [{speaker:'WaveDogUtilityProbe',matchId:'test-utility'},'utility',/地形|方块|网|水|岩浆/u],
      [{speaker:'WaveDogProjectileProbe',matchId:'test-projectile'},'projectile',/飞|扔|投掷/u]
    ]
    for(const [actor] of actions)send({...actor,kind:'frame',frame})
    await new Promise(resolve=>setTimeout(resolve,250))
    fs.appendFileSync(chatLog,actions.map(([actor,technique])=>
      JSON.stringify({...actor,tick:101,kind:'combat-action',technique})).join('\n')+'\n')
    await new Promise(resolve=>setTimeout(resolve,650))
    const actionFrame={...frame,observation:{...frame.observation,tick:102}}
    for(const [actor] of actions)send({...actor,kind:'frame',frame:actionFrame})
    for(const [actor,technique,expected] of actions){
      const reaction=await until(row=>row.matchId===actor.matchId&&row.intent==='meme_'+technique)
      assert.match(reaction.text,expected)
    }
    send({...next,kind:'end',frame:actionFrame,winner:next.speaker})
    const win=await until(row=>row.matchId===next.matchId&&row.kind==='end')
    assert.equal(win.intent,'gg_win')
    assert(victoryLessons.includes(win.text)||/^(?:L{1,2}|ez)$|666|诗人|是人|相思了|挖去|卧槽颗秒了/u.test(win.text),win.text)
    const draw={speaker:'WaveDogDrawProbe',matchId:'test-draw'}
    send({...draw,kind:'end',frame,winner:''})
    await new Promise(resolve=>setTimeout(resolve,250))
    assert(!rows.some(row=>row.matchId===draw.matchId),'a draw should stay quiet')
    assert.equal(rows.filter(row=>row.matchId===bout.matchId&&row.kind==='end').length,1)
  }
  console.log(JSON.stringify({pass:true,revision:adapter.revision,
    adapterBytes:fs.statSync(adapterFile).size}))
}finally{
  child.kill()
  if(child.exitCode===null)await new Promise(resolve=>child.once('exit',resolve))
  assert(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep))
  assert(path.basename(directory).startsWith('wavedog-live-online-'))
  fs.rmSync(directory,{recursive:true,force:true})
}
