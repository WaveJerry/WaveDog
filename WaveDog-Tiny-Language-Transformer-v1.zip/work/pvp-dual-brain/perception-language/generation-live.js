import {canSpeak, frame, PHRASES} from './dialogue.js'
import {SON_WIDTH, PVP_WIDTH} from './model.js'
import {loadReplyModel, split} from './generation-runtime.mjs'
import {contextualIntents, groundedMeme, groundedReply, replyHistory} from './generation-context.js'
import {chatLessons, chatTopic, fluentReply, normalizeChat, replyKey} from './conversation.js'
import {combatTechniques, reactionAsides, reactionClauses, retreatAsides, victoryLessons} from './combat-memes.js'

const lobbyTopics = [
  ['greeting', /^(?:你好|您好|嗨|哈喽|哈啰|在吗|在不在|早上好|晚上好|hello|hi)(?:呀|啊|嘛|吗|哈)?$/iu,
    '你好', ['你好，想练哪种对战？', '我在，随时可以开打。']],
  ['duel', /^(?:怎么|怎样|如何|在哪)(?:对战|开打|开局|开始|匹配|进竞技场)(?:呀|啊|嘛|呢)?$/u,
    '怎么开打', ['去竞技场点我的对战按钮。', '点竞技场里的对战按钮就能开打。']],
  ['capability', /^(?:你会什么|你会啥|你能做什么|你有什么功能|你能干啥|你能做啥|你能干什么)(?:呀|啊|呢)?$/u,
    '你会什么', ['我能陪你练 PvP。', '我可以在竞技场和你对战。']]
]
const clauses = {
  nice_bow: {zh:['这箭挺准','这箭漂亮'], en:['Nice shot','Good arrow']},
  combo_hype: {zh:['这波连上了','这套连得挺顺'], en:['That combo landed','Clean combo']},
  shield_respect: {zh:['这盾举得及时','这下盾防得好'], en:['Good block','Nice shield']}
}
const endings = {
  zh:{steady:['，继续打。','，还能接着打。'],low:['，我得缓一下。','，我得先稳一下。']},
  en:{steady:[', keep going.',', we can keep fighting.'],low:[', I need a breather.',', I need to reset.']}
}
const hasChinese = text => /\p{Script=Han}/u.test(text)

// Each approved sample contributes only local transitions. The next token
// is predicted by the Transformer. A shared token may lead to another
// sample's continuation without making that complete sentence an entry.
export function tokenTransitions(vocabulary, phrases) {
  const edges = new Map()
  for (const phrase of phrases) {
    const ids = split(phrase,vocabulary).map(token => vocabulary.get(token))
    if (!ids.length || ids.some(id => id === undefined)) continue
    let previous = 2
    for (const next of [...ids,3]) {
      if (!edges.has(previous)) edges.set(previous,new Set())
      edges.get(previous).add(next)
      previous = next
    }
  }
  return previous => edges.get(previous) ?? new Set()
}

function constrainedReply(model,sample,phrases,random,verify){
  const root=new Map()
  for(const phrase of phrases){
    if(!verify(phrase))continue
    const ids=split(phrase,model.vocabulary).map(token=>model.vocabulary.get(token))
    if(ids.some(id=>id===undefined))continue
    let node=root
    for(const id of [...ids,3]){
      if(!node.has(id))node.set(id,new Map())
      node=node.get(id)
    }
  }
  if(!root.size)return null
  let node=root
  return model.generate(sample,random,(previous,step)=>{
    if(step)node=node.get(previous)
    return new Set(node.keys())
  })
}

export function createTokenSpeech(checkpoint,lobbyLearning=null,contextualCheckpoint=null,combatCheckpoint=null) {
  const model = loadReplyModel(checkpoint)
  const contextual = contextualCheckpoint ? loadReplyModel(contextualCheckpoint) : null
  const combat = combatCheckpoint ? loadReplyModel(combatCheckpoint) : contextual
  const conversational=(contextual?.contextWidth??0)>=16
  const combatMemes=(combat?.contextWidth??0)>=30
  function generateContext({intent,history,chat,random,lastText,avoid,verify=()=>true}){
    const sample={intent,history:replyHistory(history,contextual.history),chat}
    const valid=text=>fluentReply(text,lastText)&&!avoid?.has(replyKey(text))&&verify(text)
    const first=contextual.generate(sample)
    if(valid(first))return first
    if(random)for(let i=0;i<4;i++){
      const {text,steps}=contextual.trace(sample,null,random)
      if(valid(text)&&steps.every(step=>step.logProbability>=-1.5))return text
    }
    return null
  }
  function lobbyFrame(){
    const sonVector=Array(SON_WIDTH).fill(0)
    sonVector[0]=sonVector[2]=sonVector[31]=sonVector[96]=1
    return frame({sonVector,pvpVector:Array(PVP_WIDTH).fill(0)})
  }
  function chat({text,history,topic=chatTopic(text),lastText,avoid,random=Math.random}){
    if(!conversational||!topic||!chatLessons[topic]||!history.length||
        !contextual.vocabulary.has('<intent:chat_'+topic+'>'))return null
    return generateContext({intent:'chat_'+topic,history,chat:text,random,lastText,avoid,verify(text){
      const latest=history.at(-1)
      if(/拉弓|弓都拉开/u.test(text)&&!(latest.replyContext?.[8]>=.3))return false
      if(/这点血|差点把我打没/u.test(text)&&latest.son[0]>.3)return false
      if(/正在打|打完这把|先打这把|先打完/u.test(text)&&latest.son[96]===1)return false
      if(topic==='greeting')return /^(?:在呢|在啊|嗨|hi|你好)/iu.test(text)
      if(topic==='gg')return /gg|好局|下回/iu.test(text)
      if(topic==='duel'&&latest.son[96]===1)return /竞技场.*按钮/u.test(text)
      if(topic==='capability')return /pvp|练|模式/i.test(text)
      if(topic==='tactical')return /哪一[下刀]|再试一下|[拉]弓|弓都拉开/u.test(text)
      if(topic==='meme')return groundedMeme(text,latest)
      return true
    }})
  }
  function render({intent, history, phrases, chat, prompt, lastText, random, verify = () => true}) {
    const transitions = tokenTransitions(model.vocabulary,phrases)
    for (const [message, sample] of [[chat || prompt,random],[prompt,random],[prompt,null]]) {
      const text = model.generate({history,chat:message,intent},sample,transitions)
      if (text && text.length <= 40 && text !== lastText && verify(text)) return text
    }
    return null
  }
  return {
    conversational,combatMemes,chat,
    reaction({technique,history,lastText,avoid,random}){
      if(!combatMemes||!combatTechniques.includes(technique)||!history.length)return null
      const latest=history.at(-1)
      if(latest.replyContext?.[24+combatTechniques.indexOf(technique)]!==1)return null
      const intent='reaction_'+technique
      if(!combat.vocabulary.has('<intent:'+intent+'>'))return null
      const sample={intent,history:replyHistory(history,combat.history),chat:''}
      const valid=text=>fluentReply(text,lastText)&&!avoid?.has(replyKey(text))&&groundedMeme(text,latest,technique)
      const line=combat.generate(sample,random)
      if(valid(line))return line
      const asides=technique==='pearl'?[...reactionAsides,...retreatAsides]:reactionAsides
      const phrases=reactionClauses[technique].flatMap(clause=>
        asides.flatMap(aside=>[aside+'，'+clause+'。',clause+'，'+aside+'。']))
      return constrainedReply(combat,sample,phrases,random,valid)
    },
    finish({events,history,quickWin=false,random=Math.random}){
      if(!combatMemes||!events.boutEnd)return null
      if(events.lost)return '错了错了'
      if(!events.won||!history.length)return null
      const sample={intent:'gg_win',history:replyHistory(history,combat.history),chat:''}
      const approved=new Set(victoryLessons)
      if(quickWin)approved.add('卧槽颗秒了')
      const valid=text=>approved.has(text)||fluentReply(text)
        &&/^(?:L{1,2}|ez)$|666|诗人|是人|相思了|挖去/u.test(text)
        &&!/还没打完|继续打|秒了/u.test(text)
        &&groundedMeme(text,history.at(-1))
      const line=combat.generate(sample,random)
      if(valid(line))return line
      const phrases=[...approved,...reactionAsides.flatMap(aside=>[aside,aside+'，这局收了。',aside+'，gg。'])]
      return constrainedReply(combat,sample,phrases,random,valid)
    },
    lobby(message,reply=true,lastText=null) {
      const prompt = normalizeChat(message)
      const recognized = lobbyTopics.find(([, matches]) => matches.test(prompt))
      const remembered = recognized ? null : lobbyLearning?.recognize(prompt)
      if(recognized)lobbyLearning?.remember(prompt,recognized[0])
      const observation=lobbyFrame()
      if(conversational){
        if(!reply)return null
        return chat({text:message,topic:chatTopic(message)??remembered,history:[observation],lastText})
      }
      const topic = recognized ?? lobbyTopics.find(([key])=>key===remembered)
      if (!topic) return null
      const [key,, canonical, phrases] = topic
      if(!reply)return null
      return render({intent:'lobby_'+key, history:[observation,observation],
        phrases, chat:prompt, prompt:canonical, random:Math.random})
    },
    battle({intent, history, events, chat, shieldBlocked, low, lastText, random, avoid,directQuestion=false}) {
      if (!history.length || !canSpeak(intent,events) || !PHRASES[intent] ||
          intent === 'shield_respect' && !shieldBlocked) return null
      const explicitEnglish = /英文|英语|english/i.test(chat)
      const explicitChinese = /中文|汉语|chinese/i.test(chat)
      const latest = history.at(-1)
      if(conversational&&latest.replyContext){
        const factual=contextualIntents.includes(intent)
        return generateContext({intent,history,chat,random,lastText,avoid,verify(text){
          if(/(?:^|[^a-z])(?:ez|l)(?:$|[^a-z])/i.test(text)&&intent!=='gg_win'&&intent!=='tilt')return false
          if(directQuestion&&intent==='nice_bow'&&!/远|距离/u.test(text))return false
          if(factual&&!explicitEnglish)return groundedReply(text,intent,latest,lastText)
          return true
        }})
      }
      if(contextual && latest.replyContext && contextualIntents.includes(intent) &&
          !explicitEnglish && !(chat && !hasChinese(chat) && /[a-z]/i.test(chat))){
        const input={intent,history:replyHistory(history,contextual.history),chat}
        const spoken=contextual.generate(input)
        if(groundedReply(spoken,intent,latest,lastText))return spoken
        if(random){
          const varied=contextual.generate(input,random)
          if(groundedReply(varied,intent,latest,lastText))return varied
        }
      }
      if(directQuestion)return null
      const locale = explicitEnglish ? 'en' : 'zh'
      const prompt = locale === 'en' ? '请讲英文' : '请讲中文'
      const states = low ? 'low' : 'steady'
      const corpus = PHRASES[intent]
      const localized = explicitEnglish || explicitChinese
        ? corpus.filter(text=>hasChinese(text)===!explicitEnglish)
        : corpus
      const relevant = clauses[intent]?.[locale] ?? []
      const phrases = [...(localized.length ? localized : corpus)]
      // The held-out pair stays absent here as well. It can be reached
      // through the shared punctuation and subsequent token transitions.
      for (const [first,second] of [[0,0],[0,1],[1,0]])
        if (relevant[first]) phrases.push(relevant[first]+endings[locale][states][second])
      const last = history.at(-1)
      return render({intent, history:[history.at(-2) ?? last,last], phrases,
        chat,prompt,lastText,random,
        verify: text => !/\p{Cc}/u.test(text) && (
          !localized.length || !explicitEnglish && !explicitChinese || hasChinese(text)===!explicitEnglish)
      })
    }
  }
}
