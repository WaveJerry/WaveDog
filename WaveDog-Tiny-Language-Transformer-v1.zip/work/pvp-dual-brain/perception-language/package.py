"""Package the shared WaveDog speech worker without combat data or player logs."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--v1', action='store_true', help='export the original intent-based model')
options = parser.parse_args()
root = Path(__file__).resolve().parent
workspace = root.parents[2]
output = workspace / 'outputs/pvp-perception-language'
sources = [file for file in root.iterdir()
    if file.suffix in ('.js', '.mjs', '.md', '.py')]
dependencies = [root.parent / name for name in ('package.json', 'package-lock.json',
    'native-observation.js', 'technique-conditioning.js', 'combat-observation.js')]
artifact_names = ['checkpoint.json', 'training-report.json']
if not options.v1:
    artifact_names += ['reply.int8.bin', 'reply-context.int8.bin', 'reply-combat.int8.bin',
        'contextual/report.json', 'contextual/sample-input.jsonl', 'contextual/tokenized-supervision.jsonl']
artifacts = [output / name for name in artifact_names]
files = {file.relative_to(workspace).as_posix(): file.read_bytes()
    for file in sources + dependencies + artifacts}
release = workspace / 'outputs/wavedog-brother-release'
files['integration/PerceptionDialogueBridge.java'] = (release /
    'work/wavedog-native/src/local/wavedog/nativecontrol/PerceptionDialogueBridge.java').read_bytes()
files['integration/ChatSense.java'] = (workspace /
    'work/wavedog-chat-sense/src/local/wavedog/chatsense/ChatSense.java').read_bytes()
files['outputs/pvp-perception-language/speech-profile.json'] = json.dumps(
    {'mode': 'intent-v1' if options.v1 else 'token'}).encode()
if options.v1:
    project = root.relative_to(workspace).as_posix()
    files['integration/WaveDogNativeControl.jar'] = (release /
        'native-online-training/WaveDogNativeControl.jar').read_bytes()
    files['integration/WaveDogChatSense.jar'] = (release /
        'chat-sense-build/WaveDogChatSense.jar').read_bytes()
    readme = (root / 'README.zh-CN.md').read_text(encoding='utf-8')
    files['README.zh-CN.md'] = readme.replace('](./', f']({project}/').encode()
else:
    files['integration/WaveDogChatSense.jar'] = (output / 'chat-sense-techniques/WaveDogChatSense.jar').read_bytes()
    files['README.zh-CN.md'] = (root / 'CONTEXTUAL.zh-CN.md').read_bytes()
manifest = {'ideaBy': 'WaveJ', 'scope': 'PvP perception and teaching' if options.v1 else 'PvP and lobby dialogue for WaveDog',
    'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
archive = output / ('WaveDog-Perception-Transformer-v1.zip' if options.v1 else 'Tiny Language Transformer WaveDog.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipfile_out:
    for name, data in sorted(files.items()):
        zipfile_out.writestr(name, data)
    zipfile_out.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
assert archive.stat().st_size < 25_000_000, archive.stat().st_size
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
    'checkpointBytes': (output / 'checkpoint.json').stat().st_size,
    'files': len(files)}, ensure_ascii=False))
