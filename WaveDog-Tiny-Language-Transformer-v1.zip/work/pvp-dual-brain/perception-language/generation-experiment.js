import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import * as tf from '@tensorflow/tfjs'
import {AttentionBlock, Dense, SON_WIDTH, PVP_WIDTH, EVENT_WIDTH} from './model.js'
import {ACTION_WIDTHS, INTENTS, PHRASES, frame, pvpFromDual} from './dialogue.js'
import {HISTORY as historyLength, CHAT as chatLength, REPLY as replyLength, WIDTH as width,
  HEADS, SPECIAL as symbols, split, choose, promptIds, compactCheckpoint, loadReplyModel,
  eventInput} from './generation-runtime.mjs'

const [pad, unknown, start, end] = symbols.map((_, i) => i)
const locales = {
  zh: {
    prompts: ['用中文', '说中文吧', '来句中文', '请讲中文'],
    heldOutPrompt: '请说中文',
    followUp: {steady: ['，继续打。', '，还能接着打。'], low: ['，我得缓一下。', '，我得先稳一下。']}
  },
  en: {
    prompts: ['用英文', '说英文吧', '来句英文', '请讲英文'],
    heldOutPrompt: '请说英文',
    followUp: {steady: [', keep going.', ', we can keep fighting.'], low: [', I need a breather.', ', I need to reset.']}
  }
}
const situations = {
  bow: {flag: 'enemyBowHit', zh: ['这箭挺准', '这箭漂亮'], en: ['Nice shot', 'Good arrow']},
  combo: {flag: 'ownCombo', zh: ['这波连上了', '这套连得挺顺'], en: ['That combo landed', 'Clean combo']},
  shield: {flag: 'enemyShield', zh: ['这盾举得及时', '这下盾防得好'], en: ['Good block', 'Nice shield']}
}
const lobby = {
  greeting: {
    prompts: ['你好', '哈喽', '嗨', '在吗', '早上好', '你好呀'],
    heldOutPrompt: '嗨呀',
    replies: ['你好，想练哪种对战？', '我在，随时可以开打。']
  },
  duel: {
    prompts: ['怎么对战', '怎么开打', '如何开局', '怎么开始', '在哪对战', '怎么开局'],
    heldOutPrompt: '如何对战',
    replies: ['去竞技场点我的对战按钮。', '点竞技场里的对战按钮就能开打。']
  },
  capability: {
    prompts: ['你会什么', '你会啥', '你能做什么', '你有什么功能', '你能干啥', '你能做啥'],
    heldOutPrompt: '你会干啥',
    replies: ['我能陪你练 PvP。', '我可以在竞技场和你对战。']
  }
}
const topics = Object.keys(situations)
const languages = Object.keys(locales)
const healthStates = ['steady', 'low']
const rows = topics.flatMap(topic => languages.flatMap(language =>
  healthStates.map(health => ({topic, language, health}))))
const replyIntent = {bow:'nice_bow', combo:'combo_hype', shield:'shield_respect'}
const trainingEvents = {
  opener:{boutStart:true}, retreat_roast:{enemyRetreat:true}, nice_bow:{enemyBowHit:true},
  nice_mace:{enemyMaceHit:true}, nice_crystal:{enemyCrystalHit:true}, combo_hype:{ownCombo:true},
  shield_respect:{enemyShield:true}, clutch:{ownLowHealth:true},
  gg_win:{boutEnd:true,won:true}, gg_loss:{boutEnd:true,lost:true},
  tilt:{enemyRetreat:true,ownLowHealth:true}
}

function makeVocabulary() {
  const text = rows.flatMap(({topic, language, health}) => [
    ...locales[language].prompts, ...situations[topic][language], ...locales[language].followUp[health]
  ])
  text.push(...Object.values(lobby).flatMap(row => [...row.prompts, ...row.replies]),
    ...Object.values(PHRASES).flat(), '今天天气如何', '可以吃饭吗')
  return [...symbols, ...Array.from(new Set(text.flatMap(value=>split(value)))).sort(),
    ...INTENTS.concat(Object.keys(lobby).map(topic => 'lobby_'+topic)).map(intent => `<intent:${intent}>`)]
}

function encode(text, vocabulary) {
  return split(text,vocabulary).map(token => vocabulary.get(token) ?? unknown)
}

// Each prefix contains two snapshots of game state plus the player's text.
// Prefix tokens can attend to each other. Reply tokens can only attend to
// that prefix and previously presented reply tokens.
let modelId = 0
export class ReplyTransformer {
  constructor(tokens, config = null) {
    this.tokens = tokens
    this.vocabulary = new Map(tokens.map((token, i) => [token, i]))
    this.config = config
    const {history, chat, reply, width:modelWidth, heads, context} = config ?? {
      history:historyLength, chat:chatLength, reply:replyLength, width, heads:HEADS, context:0
    }
    this.historyLength = history
    this.chatLength = chat
    this.replyLength = reply
    this.width = modelWidth
    this.context = context
    this.prefixLength = history * 3 + chat
    const id = `pvp-reply-${++modelId}`
    this.son = new Dense(SON_WIDTH, modelWidth, `${id}.son`)
    this.pvp = new Dense(PVP_WIDTH, modelWidth, `${id}.pvp`)
    this.event = new Dense(EVENT_WIDTH + context, modelWidth, `${id}.event`)
    this.block = new AttentionBlock(modelWidth, heads, `${id}.block`)
    this.head = new Dense(modelWidth, tokens.length, `${id}.head`)
    this.embedding = tf.tidy(() => tf.variable(tf.randomNormal([tokens.length, modelWidth], 0, .2), true, `${id}.tokens`))
    this.position = tf.tidy(() => tf.variable(tf.randomNormal([this.prefixLength + reply, modelWidth], 0, .2), true, `${id}.position`))
    this.params = [...this.son.params, ...this.pvp.params, ...this.event.params,
      ...this.block.params, ...this.head.params, this.embedding, this.position]
    const total = this.prefixLength + reply
    this.mask = tf.tensor2d(Array.from({length: total}, (_, i) =>
      Array.from({length: total}, (_, j) => j < this.prefixLength || i >= j ? 0 : -1e9)))
  }

  logits(samples, reply) {
    const batch = samples.length
    const history = samples.map(sample => sample.history)
    const game = tf.stack([
      this.son.apply(tf.tensor3d(history.map(frames => frames.map(f => f.son)))),
      this.pvp.apply(tf.tensor3d(history.map(frames => frames.map(f => f.pvp)))),
      this.event.apply(tf.tensor3d(history.map(frames => frames.map(f => eventInput(f,this.context)))))
    ], 2).reshape([batch, this.historyLength * 3, this.width])
    const messages = samples.map(sample => promptIds(sample,this.vocabulary,this.chatLength))
    const ids = tf.tensor2d(messages.map((message, i) => [...message, ...reply[i]]), undefined, 'int32')
    const length = this.prefixLength + reply[0].length
    const inputs = tf.concat([game, tf.gather(this.embedding, ids)], 1)
    const state = this.block.apply(tf.add(inputs, this.position.slice([0, 0], [length, this.width])),
      this.mask.slice([0, 0], [length, length]))
    return this.head.apply(state.slice([0, this.prefixLength, 0], [batch, reply[0].length, this.width]))
  }

  generate(sample, random = null) {
    const ids = [start]
    while (ids.length <= this.replyLength) {
      const scores = tf.tidy(() => Array.from(this.logits([sample], [ids])
        .slice([0, ids.length - 1, 0], [1, 1, this.tokens.length]).dataSync()))
      const chosen = choose(scores, random, null, this.tokens)
      if (chosen === end) break
      ids.push(chosen)
    }
    return ids.slice(1).map(id => this.tokens[id]).join('')
  }

  snapshot() {
    return {
      schema: 'wavedog-reply-experiment-1', tokens: this.tokens, config:this.config || undefined,
      weights: this.params.map(variable => ({shape: variable.shape, values: Array.from(variable.dataSync())}))
    }
  }

  restore(saved) {
    if (saved.schema !== 'wavedog-reply-experiment-1' || saved.weights.length !== this.params.length ||
        JSON.stringify(saved.config ?? null) !== JSON.stringify(this.config))
      throw Error('invalid generation checkpoint')
    this.params.forEach((variable, i) => tf.tidy(() => {
      const weight = saved.weights[i]
      variable.assign(tf.tensor(weight.values, weight.shape))
    }))
  }

  expand(saved) {
    if(saved.tokens.some((token,i)=>this.tokens[i]!==token) || saved.config.width!==this.width ||
        saved.config.context>this.context || saved.config.history!==this.historyLength ||
        saved.config.chat!==this.chatLength || saved.config.reply!==this.replyLength)
      throw Error('incompatible reply model expansion')
    const next=this.snapshot()
    for(const [i,weight] of saved.weights.entries()){
      const {shape,values}=next.weights[i]
      if(JSON.stringify(shape)===JSON.stringify(weight.shape)){
        next.weights[i]=weight
      }else if([4,22,23,24].includes(i)){
        const oldWidth=weight.shape.at(-1),newWidth=shape.at(-1)
        for(const [index,value] of weight.values.entries())
          values[Math.floor(index/oldWidth)*newWidth+index%oldWidth]=value
      }else throw Error('unhandled reply weight expansion: '+i)
    }
    this.restore(next)
  }

  dispose() {
    this.params.forEach(variable => variable.dispose())
    this.mask.dispose()
  }
}

export function seeded(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0
    return seed / 4294967296
  }
}

function context({topic, health, chat, inLobby = false, publicEvents, intent = replyIntent[topic]}, seed) {
  const random = seeded(seed)
  const actions = ACTION_WIDTHS.map(size => Array.from({length: size}, () => 1 + random()))
  const probabilities = actions.map(head => {
    const sum = head.reduce((total, value) => total + value, 0)
    return head.map(value => value / sum)
  })
  const pvpVector = pvpFromDual({probabilities})
  const history = Array.from({length: historyLength}, (_, i) => {
    const sonVector = Array(SON_WIDTH).fill(0)
    sonVector[0] = health === 'low' ? .12 + random() * .13 : .70 + random() * .30
    sonVector[1] = random()
    sonVector[2] = 1
    sonVector[31] = 1
    sonVector[96] = Number(inLobby)
    sonVector[97] = random() * 2 - 1
    const events = i !== historyLength - 1 ? {} : publicEvents ??
      (topic ? {[situations[topic].flag]: true} : {})
    return frame({sonVector, pvpVector, events})
  })
  return {history, chat, intent}
}

const formatReply = (row, first, second) =>
  situations[row.topic][row.language][first] + locales[row.language].followUp[row.health][second]

function teacherExamples() {
  const examples = rows.flatMap(row => locales[row.language].prompts.flatMap(chat => {
    // Hold back the second/second wording combination across all contexts.
    // Each clause is still seen separately during training.
    return [[0, 0], [0, 1], [1, 0]].map(([first, second]) => ({
      ...row, chat, text: formatReply(row, first, second)
    }))
  }))
  examples.push(...languages.flatMap(language => locales[language].prompts.map(chat =>
    ({chat, health: 'steady', text: ''}))))
  for (const [type,row] of Object.entries(lobby))
    for (const chat of row.prompts)
      for (const text of row.replies)
        examples.push({chat, text, health: 'steady', inLobby: true, intent:'lobby_'+type})
  for (const chat of ['今天天气如何', '可以吃饭吗', '多谢', ''])
    examples.push({chat, health: 'steady', inLobby: true, text: ''})
  for (const [intent,phrases] of Object.entries(PHRASES)) {
    const publicEvents=trainingEvents[intent]
    if(!publicEvents)throw Error('missing facts for '+intent)
    for (const text of phrases) examples.push({text,intent,publicEvents,
      health:publicEvents.ownLowHealth?'low':'steady',
      chat:/\p{Script=Han}/u.test(text)?'用中文':'用英文'})
  }
  return examples
}

export function trainReply(model, steps, examples, makeContext = context) {
  const makeBatch = seeded(42)
  const optimizer = tf.train.adam(.0025)
  let loss = null
  try {
    for (let step = 1; step <= steps; step++) {
      const batch = Array.from({length: 10}, () => examples[Math.floor(makeBatch() * examples.length)])
      const inputs = batch.map(row => makeContext(row, Math.floor(makeBatch() * 4294967296)))
      const outputs = batch.map(row => [...(row.replyIds ?? encode(row.text, model.vocabulary)), end])
      const max = Math.max(...outputs.map(ids => ids.length))
      if (max > model.replyLength) throw Error('reply too long for training')
      const target = outputs.map(ids => [...ids, ...Array(max - ids.length).fill(pad)])
      const teacher = target.map(ids => [start, ...ids.slice(0, -1)])
      loss = tf.tidy(() => optimizer.minimize(() => {
        const labels = tf.tensor2d(target, undefined, 'int32')
        const valid = labels.notEqual(pad).toFloat()
        const log = tf.logSoftmax(model.logits(inputs, teacher), -1)
        const perToken = tf.neg(tf.sum(tf.mul(tf.oneHot(labels, model.tokens.length), log), -1))
        return tf.sum(tf.mul(perToken, valid)).div(tf.sum(valid))
      }, true, model.params).dataSync()[0])
      if (step % 100 === 0 || step === steps) console.log(JSON.stringify({step, loss}))
    }
  } finally {
    optimizer.dispose()
  }
  return {loss}
}

function check(text, {topic, language, health}) {
  const allowed = situations[topic][language]
  const suffixes = locales[language].followUp[health]
  return {
    topic: allowed.some(clause => text.startsWith(clause)),
    language: language === 'zh' ? /\p{Script=Han}/u.test(text) : /[a-z]/i.test(text) && !/\p{Script=Han}/u.test(text),
    health: suffixes.some(clause => text.endsWith(clause)),
    composed: allowed.some(first => suffixes.some(last => text === first + last))
  }
}

function evaluate(model) {
  const trainingTexts = new Set(teacherExamples().map(row => row.text))
  const greedy = rows.map((row, i) => {
    const chat = locales[row.language].heldOutPrompt
    const text = model.generate(context({...row, chat}, 900 + i))
    return {...row, chat, text, ...Object.fromEntries(Object.entries(check(text, row))
      .map(([key, passed]) => [key+`Correct`, passed]))}
  })
  const sampled = rows.flatMap((row, i) => {
    const chat = locales[row.language].heldOutPrompt
    const sample = context({...row, chat}, 900 + i)
    return Array.from({length: 8}, (_, attempt) => {
      const text = model.generate(sample, seeded(7007 + i * 719 + attempt * 997))
      return {text, ...check(text, row), novel: !trainingTexts.has(text)}
    })
  })
  const novelCorrect = [...new Set(sampled.filter(row => row.composed && row.novel).map(row => row.text))]
  const quiet = languages.map(language => model.generate(context({
    health: 'steady', chat: locales[language].heldOutPrompt
  }, 919)))
  const paired = [
    {topic: 'bow', health: 'steady', chat: '请讲中文'},
    {topic: 'bow', health: 'steady', chat: '请讲英文'},
    {topic: 'bow', health: 'low', chat: '请讲英文'},
    {topic: 'shield', health: 'low', chat: '请讲英文'}
  ].map(row => ({...row, text: model.generate(context(row, 20261123))}))
  const lobbyReplies = Object.entries(lobby).map(([type, row], i) => {
    const chat = row.heldOutPrompt
    const text = model.generate(context({chat, health:'steady', inLobby:true,intent:'lobby_'+type}, 1020 + i))
    return {type, chat, text, valid: row.replies.includes(text)}
  })
  return {
    trainingUniqueNonemptyReplies: trainingTexts.size - Number(trainingTexts.has('')),
    greedy, sampledCount: sampled.length,
    sampledUniqueNonemptyReplies: new Set(sampled.map(row => row.text).filter(Boolean)).size,
    validSampled: sampled.filter(row => row.composed).length,
    novelCorrect, quiet, paired, lobbyReplies
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const output = path.resolve(process.argv[2] ?? 'outputs/pvp-perception-language/generation-experiment')
  const compactOnly = process.argv[3] === '--compact-eval'
  const prior = compactOnly ? JSON.parse(fs.readFileSync(path.join(output, 'report.json'), 'utf8')) : null
  const steps = Number(compactOnly ? prior.steps : process.argv[3] ?? 350)
  if (!Number.isSafeInteger(steps) || steps < 1) throw Error('steps must be a positive integer')
  await tf.setBackend('cpu')
  await tf.ready()
  fs.mkdirSync(output, {recursive: true})
  const model = new ReplyTransformer(makeVocabulary())
  try {
    const checkpoint = path.join(output, 'checkpoint.json')
    const finalLoss = compactOnly ? prior.finalLoss : trainReply(model, steps, teacherExamples()).loss
    if (!compactOnly) fs.writeFileSync(checkpoint, JSON.stringify(model.snapshot()))
    const saved = JSON.parse(fs.readFileSync(checkpoint, 'utf8'))
    model.restore(saved)
    const binary = compactCheckpoint(saved)
    const binaryPath = path.join(output, 'reply.int8.bin')
    fs.writeFileSync(binaryPath, binary)
    const portable = loadReplyModel(binaryPath)
    const float = evaluate(model)
    const compact = evaluate(portable)
    const samples = compact.paired.map(sample => context(sample, 20261123))
    fs.writeFileSync(path.join(output, 'sample-input.jsonl'), samples.map(sample => JSON.stringify(sample)).join('\n')+'\n')
    const elapsed = []
    for (let i = 0; i < 120; i++) {
      const before = performance.now()
      portable.generate(samples[i % samples.length])
      elapsed.push(performance.now() - before)
    }
    elapsed.sort((a, b) => a - b)
    const result = {steps, parameters: model.params.reduce((sum, value) => sum + value.size, 0),
      finalLoss, binaryBytes: binary.length,
      matchingGreedy: compact.greedy.filter((row,i) => row.text === float.greedy[i].text).length,
      singleReplyMs: {median: elapsed[60], p95: elapsed[113]},
      tokenizedPvpExamples: Object.values(PHRASES).flat().length,
      tokenizedLobbyExamples: Object.values(lobby).flatMap(row=>row.replies).length,
      vocabularySize:saved.tokens.length,
      tokenizationExamples:['没一个是人','梅夷阁诗人','你这后撤步挺熟','这波连招丝滑','Nice shield, we can keep fighting.']
        .map(text=>({text,tokens:split(text)})),
      ...compact}
    fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(result, null, 2) + '\n')
    console.log(JSON.stringify(result))
  } finally {
    model.dispose()
  }
}
