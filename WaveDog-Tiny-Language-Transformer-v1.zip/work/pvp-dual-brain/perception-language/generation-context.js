import {fluentReply} from './conversation.js'
import {combatTechniques} from './combat-memes.js'

const unit = value => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0

// Values describe accepted game state and resolved events, never future actions.
export function replyFeatures({distance, enemyHealth, enemyGround, combo, blocks, damage, critical, elapsed,
  bowDraw, enemyShield, ownShield, loaded, closing, wallMargin, charge, airborne, exchange, technique}) {
  return [
    unit(distance / 16), unit(enemyHealth / 20), Number(Boolean(enemyGround)),
    unit(combo / 5), unit(blocks / 4), unit(damage / 10), Number(Boolean(critical)), unit(elapsed / 100),
    unit(bowDraw/20), Number(Boolean(enemyShield)), Number(Boolean(ownShield)), Number(Boolean(loaded)),
    Number.isFinite(closing)?Math.tanh(closing*4):0, unit(wallMargin/8), unit(charge), Number(Boolean(airborne)),
    unit(exchange?.healthLoss/10),unit(exchange?.hitCount/4),unit(exchange?.criticalCount/3),
    unit(exchange?.arrowCount/3),unit(exchange?.retreatCount/6),unit(exchange?.comboCount/4),
    unit(exchange?.shieldCount/4),unit(exchange?.matchAge/1200),
    ...combatTechniques.map(name=>Number(name===technique))
  ]
}

export function replyFeaturesFromFrame(frame, hits, blocks, lastTick, incoming, exchange, technique) {
  const {self,seen,observation:obs}=frame
  const dx=seen.x-self.x,dz=seen.z-self.z
  const closing=((self.vx-seen.vx)*dx+(self.vz-seen.vz)*dz)/Math.max(.001,Math.hypot(dx,dz))
  return replyFeatures({
    distance:obs.distance, enemyHealth:seen.health, enemyGround:seen.ground,
    combo:hits, blocks, damage:incoming?.amount, critical:incoming?.nativeCritical,
    elapsed:frame.tick-lastTick,bowDraw:obs.targetBow?seen.useTicks:0,enemyShield:obs.targetShieldRaised,
    ownShield:obs.shieldEffective??self.shielding,loaded:obs.loaded,
    closing,wallMargin:obs.wallMargin,charge:obs.charge,airborne:!self.ground,exchange,technique
  })
}

export function exchangeFeatures(recent,latest,firstTick){
  const rows=[...recent,latest].filter(row=>latest.tick-row.tick>=0&&latest.tick-row.tick<=100)
  const counters={
    hitCount:new Set(),criticalCount:new Set(),arrowCount:new Set(),
    retreatCount:new Set(),comboCount:new Set(),shieldCount:new Set()
  }
  let healthLoss=0
  for(const row of rows){
    healthLoss=Math.max(healthLoss,row.hp-latest.hp)
    if(row.hit)counters.hitCount.add(row.tick)
    if(row.critical)counters.criticalCount.add(row.tick)
    if(row.events.enemyBowHit)counters.arrowCount.add(row.tick)
    if(row.events.enemyRetreat)counters.retreatCount.add(row.tick)
    if(row.events.ownCombo)counters.comboCount.add(row.tick)
    if(row.shieldBlocked)counters.shieldCount.add(row.tick)
  }
  return {healthLoss,matchAge:latest.tick-firstTick,...Object.fromEntries(
    Object.entries(counters).map(([key,ticks])=>[key,ticks.size]))}
}

export function groundedMeme(text,frame,technique=null){
  const stress=frame.replyContext??[]
  if(!/诗人|弓狗|是人|盾|挡|卷刃|地图背|血条|手速|连招|锚|水晶|逃逸|跑个得儿|跑男来了|东方明珠塔|挖去|相思|666|开了|^L[，。]|[，]L。$/u.test(text))return false
  if(/血条都快|这点血|残血/u.test(text)&&frame.son[0]>.3)return false
  if(/弓狗|这箭/u.test(text)&&!(stress[19]>=.3||stress[24]===1))return false
  if(/追得|后撤绕|还得追|逃逸|跑个得儿|跑男来了|后撤怪|东方明珠塔/u.test(text)&&!(stress[20]>=.25||stress[27]===1))return false
  if(/连招|三刀/u.test(text)&&!(stress[21]>=.25))return false
  if(/盾把|卷刃|还挡/u.test(text)&&!(stress[22]>=.25))return false
  if(/锚|水晶|珍珠/u.test(text)){
    if(/锚/u.test(text)&&stress[25]!==1||/水晶/u.test(text)&&stress[26]!==1||/珍珠/u.test(text)&&stress[27]!==1)return false
  }
  if(technique==='bow')return /弓|箭|射/u.test(text)
  if(technique==='anchor')return /锚/u.test(text)
  if(technique==='crystal')return /水晶/u.test(text)
  if(technique==='pearl')return /珍珠|逃逸|跑个得儿/u.test(text)
  if(technique==='utility')return /地形|方块|网|水|岩浆/u.test(text)
  if(technique==='projectile')return /飞|扔|投掷/u.test(text)
  return true
}

export function replyHistory(history, size) {
  const rows = history.slice(-size)
  return Array(Math.max(0, size-rows.length)).fill(rows[0]).concat(rows)
}

export const contextualIntents = ['nice_bow', 'combo_hype', 'shield_respect']

export function eventQuestion(chat) {
  if (!/[？?吗么]|几下|几刀|几次/u.test(chat)) return null
  if (/箭/u.test(chat) && /远|距离/u.test(chat)) return 'nice_bow'
  if (/连|接/u.test(chat) && /几下|几刀|几次/u.test(chat)) return 'combo_hype'
  if (/盾|挡住/u.test(chat) && /挡|打到|打上/u.test(chat)) return 'shield_respect'
  return null
}

// Predicates serve as teacher labels and as checks for specific factual claims.
// They are never inserted into the model's input or used as decoder routes.
export function replyFacts(intent, frame) {
  const [distance,,,combo,blocks] = frame.replyContext
  return {
    tired:frame.son[0] <= .3,
    specific: intent === 'nice_bow' ? distance >= .5
      : intent === 'combo_hype' ? combo >= .6 : blocks >= .5
  }
}

export function groundedReply(text, intent, frame, lastText) {
  if (!fluentReply(text,lastText) || text!=='弓狗' && !/^\p{Script=Han}[\p{Script=Han}，。！？、]+[。！？]$/u.test(text))
    return false
  const {tired,specific} = replyFacts(intent,frame)
  if (/残血|没血|血线|快没了|先缓|喘口气|差点寄/u.test(text) && !tired) return false
  if (/这么远|远处|隔老远/u.test(text) && (intent !== 'nice_bow' || !specific)) return false
  if (/没多远/u.test(text) && (intent !== 'nice_bow' || specific)) return false
  if (/打残|一中我就残血/u.test(text)) return false
  if (/贴这么近|近身射/u.test(text) && (intent !== 'nice_bow' || frame.replyContext[0] > .25)) return false
  if (/第三下|三刀|三下/u.test(text) && (intent !== 'combo_hype' || !specific)) return false
  if (/连挡|又挡|又被.*挡|至少挡了两下|两下都.*盾/u.test(text) &&
      (intent !== 'shield_respect' || !specific)) return false
  return {
    nice_bow:/箭|射|远.*中|弓狗/u.test(text),
    combo_hype:/连|刀|接(?:上|得)/u.test(text)&&!/盾/u.test(text),
    shield_respect:/盾|挡/u.test(text)
  }[intent]??false
}
