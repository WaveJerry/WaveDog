import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import * as tf from '@tensorflow/tfjs'
import {nativeObservation} from '../native-observation.js'
import {frame, PHRASES, pvpFromDual} from './dialogue.js'
import {ReplyTransformer, seeded, trainReply} from './generation-experiment.js'
import {COMBAT_MEME as CONTEXTUAL, SPECIAL, compactCheckpoint, loadReplyModel, split} from './generation-runtime.mjs'
import {contextualIntents, groundedReply, replyFacts, replyFeatures, replyFeaturesFromFrame,
  replyHistory} from './generation-context.js'
import {chatLessons, fluentReply} from './conversation.js'
import {memeVocabulary, techniqueLessons, victoryLessons} from './combat-memes.js'

const lessons = {
  nice_bow:{
    event:'enemyBowHit',
    questions:['这箭射得远吗？','刚才这箭离你远吗？','我这一箭算远吗？','刚才那箭距离远吗？'],
    scenes:[
      ['好箭。','这箭够快。','这箭什么角度啊？'],
      ['隔这么远还能中？','你在那么远也能射中我？'],
      ['这箭够疼，我先喘口气。','残血还补一箭啊。'],
      ['隔这么远还中一箭，我都残血了。','你这远处一箭，我血线见底了。']
    ],
    answers:['这箭离我没多远。','隔了这么远，箭还是中了。']
  },
  combo_hype:{
    event:'ownCombo',
    questions:['你连了几下？','刚才接了几刀？','这套连上几下了？','刚才一共连了几刀？'],
    scenes:[
      ['这两下接得顺。','好，第二刀也接上了。'],
      ['三下都连上了。','欸，第三下也接到了。'],
      ['血线这么低，这两下得抓住。','我都残血了，还真给我连上了。'],
      ['残血还能接上第三下。','血线快没了，第三下居然也连住了。']
    ],
    answers:['两下连上了。','至少连了三下。']
  },
  shield_respect:{
    event:'enemyShield',
    questions:['刚才盾挡住了吗？','那下打到盾了吗？','我刚才挡住几下？','刚才有打上盾吗？'],
    scenes:[
      ['好挡。','差一点，你盾抬起来了。'],
      ['又打盾上了。','你怎么又挡住了？'],
      ['我都残血了，这刀还打在盾上。','血线这么低，还被你挡了一下。'],
      ['残血这几刀还让你连挡了。','我都快没血了，你又挡住了。']
    ],
    answers:['挡着了，我这下打在盾上。','至少挡了两下，我又敲到盾了。']
  }
}
const cues = ['','厉害啊','打得可以']
const examples = []
for(const [intent, lesson] of Object.entries(lessons)){
  for(const tired of [false,true]){
    for(const specific of [false,true]){
      const scene = lesson.scenes[2*Number(tired)+Number(specific)]
      for(const text of scene) for(const chat of cues) examples.push({intent,tired,specific,chat,text})
      for(const chat of lesson.questions.slice(0,-1))
        examples.push({intent,tired,specific,chat,text:lesson.answers[Number(specific)],question:true})
    }
  }
}
const otherEvents={
  opener:{boutStart:true},retreat_roast:{enemyRetreat:true},nice_mace:{enemyMaceHit:true},
  nice_crystal:{enemyCrystalHit:true},clutch:{ownLowHealth:true},
  gg_win:{boutEnd:true,won:true},gg_loss:{boutEnd:true,lost:true},tilt:{enemyRetreat:true,ownLowHealth:true}
}
const casual={
  opener:['glhf','来吧','开了啊。'],retreat_roast:['真追不上。','还跑啊？'],
  nice_mace:['好锤。','这下够疼。'],nice_crystal:['好炸。','这颗真准。'],
  clutch:['差点没了。','还能撑一会儿。'],gg_win:['gg','gg，好局。','这把打得紧。'],
  gg_loss:['gg','好局，下把来。','gg，这把你赢了。'],tilt:['又跑啊？','真绷不住了。']
}
for(const [intent,phrases] of Object.entries(PHRASES)){
  for(const text of phrases) examples.push({intent,tired:intent==='clutch'||intent==='tilt',
    specific:false,chat:'来句狠的',text})
  for(const text of casual[intent]??[]) examples.push({intent,tired:intent==='clutch'||intent==='tilt',
    specific:false,chat:'',text})
}
for(const [kind,lesson] of Object.entries(chatLessons)){
  for(const [lobby,replies] of [[true,lesson.lodge],[false,lesson.duel]]){
    for(const chat of lesson.prompts)for(const text of replies)
      examples.push({intent:'chat_'+kind,lobby,tired:false,specific:false,chat,text})
  }
}
for(const chat of ['怎么一直举盾','你怎么举盾了','为啥举盾']) {
  examples.push({intent:'chat_tactical',bowThreat:true,chat,text:'你弓都拉开了，我得挡啊。'},
    {intent:'chat_tactical',bowThreat:true,chat,text:'看你在拉弓，我先挡一下。'},
    {intent:'chat_tactical',bowThreat:false,chat,text:'你说刚才哪一下？'})
}
for(const chat of ['hi','你好','嗨','在吗']){
  examples.push({intent:'chat_greeting',tired:true,chat,text:'嗨，你差点把我打没了。'},
    {intent:'chat_greeting',tired:true,chat,text:'在呢，我剩这点血了。'})
}
const memeScenes={
  arrows:{exchange:{arrowCount:3,hitCount:3},heads:['弓狗，这箭还会拐弯','这箭跟长眼睛似的'],
    tails:['，弓狗算你准。','，九步诗人。'],hot:['，我血条都快扣没了。','，梅夷阁诗人。']},
  shield:{exchange:{shieldCount:4},heads:['你这盾把我节奏全吃了','我的刀都要敲卷刃了'],
    tails:['，根本不诗人。','，还挡得住啊？'],hot:['，我血条都快扣没了。','，九步诗人。']},
  chase:{exchange:{retreatCount:6},heads:['追得我都快把地图背下来了','你这后撤绕着竞技场跑'],
    tails:['，没一个是人。','，梅夷阁诗人。'],hot:['，就剩这点血还得追。','，根本不诗人。']},
  combo:{exchange:{comboCount:4},heads:['这连招一响都停不下来了','三刀接成一条线了'],
    tails:['，九步诗人。','，这就是人机的手速。'],hot:['，残血还能续上。','，就不是人。']}
}
for(const scene of Object.values(memeScenes))for(const tired of [false,true]){
  const tails=tired?scene.hot:scene.tails
  const pairs=[[0,0],[0,1],[1,0]]
  if(!tired)pairs.push([1,1])
  for(const [a,b] of pairs){
    const text=scene.heads[a]+tails[b]
    for(const chat of ['','来点魔怔','来句魔怔的','梅夷阁诗人','根本不诗人']){
      examples.push({intent:'chat_meme',lobby:false,tired,chat,text,exchange:{...scene.exchange,
        healthLoss:tired?8:0,matchAge:740}})
    }
    if(scene===memeScenes.chase&&tired)examples.push({intent:'tilt',tired,chat:'',text,exchange:{...scene.exchange,
      healthLoss:8,matchAge:740}})
  }
}
for(const [technique,phrases] of Object.entries(techniqueLessons)){
  for(const text of phrases)for(const tired of [false,true]){
    const example={technique,tired,text,exchange:{matchAge:800}}
    examples.push({...example,intent:'reaction_'+technique,chat:''},
      {...example,intent:'chat_meme',chat:'来点魔怔'})
  }
}
for(const text of victoryLessons){
  examples.push({intent:'gg_win',tired:false,chat:'',text},{intent:'gg_win',tired:true,chat:'',text})
}
const vocabulary = [...SPECIAL,
  ...new Set([...examples.flatMap(row=>[...split(row.chat),...split(row.text)]),
    ...memeVocabulary.flatMap(word=>split(word)),
    ...Object.values(lessons).flatMap(lesson=>lesson.questions.flatMap(text=>split(text)))]),
  ...new Set(examples.map(row=>`<intent:${row.intent}>`))]

function synthetic({intent,tired,specific,chat,lobby=false,bowThreat=false,exchange,technique}, seed){
  const random = seeded(seed)
  const row = Array.from({length:CONTEXTUAL.history}, (_,index) => {
    const last = index === CONTEXTUAL.history-1
    const distance = technique ? 1.5+random()*14 : intent==='nice_bow' && specific ? 8.5+random()*7 : 1.5+random()*4
    const combo = intent==='combo_hype' ? (specific ? 3+Math.floor(random()*3) : 2) : 0
    const blocks = intent==='shield_respect' ? (specific ? 2+Math.floor(random()*3) : 1) : 0
    const health = tired ? .08+random()*.22 : .4+random()*.6
    const charge = random(), ground = random()>.2
    let son = Array(98).fill(0)
    if(technique){
      const yaw=-180+360*random(), angle=yaw*Math.PI/180
      son=nativeObservation({
        tick:800+index*20,
        self:{x:0,y:0,z:0,eyeY:1.62,health:health*20,charge,ground,vx:0,vy:0,vz:0,
          shieldAvailable:random()>.4,shielding:false,using:false,useTicks:0,arrows:Math.floor(random()*13),
          crossbowLoaded:random()>.8,held:Math.floor(random()*4),nativeYaw:yaw},
        seen:{x:-Math.sin(angle)*distance,y:0,z:Math.cos(angle)*distance,visible:true,using:false,
          held:last&&technique==='bow'?'BOW':random()>.5?'DIAMOND_SWORD':'DIAMOND_AXE'},
        observation:{targetShieldRaised:false,reach:3,distance}
      },{})
    }else{
      son[0]=health
      son[1]=charge
      son[2]=Number(ground)
      son[20]=Math.tanh(distance/6)
      son[23]=Number(intent==='shield_respect')
      son[31]=1
      son[96]=Number(lobby)
    }
    const events = {ownLowHealth:tired}
    if(last&&lessons[intent])events[lessons[intent].event]=true
    if(last&&otherEvents[intent])Object.assign(events,otherEvents[intent])
    const earlierCombo = index===CONTEXTUAL.history-2 ? Math.max(0,combo-1) : Math.floor(random()*6)
    const earlierBlocks = index===CONTEXTUAL.history-2 ? Math.max(0,blocks-1) : Math.floor(random()*5)
    return {...frame({sonVector:son,pvpVector:pvpFromDual(),events}),
      replyContext:replyFeatures({distance,enemyHealth:7+random()*13,enemyGround:random()>.2,
        combo:last?combo:earlierCombo,blocks:last?blocks:earlierBlocks,
        damage:intent==='nice_bow'&&last?1+random()*5:0,elapsed:5+random()*15,
        bowDraw:bowThreat?10+random()*12:0,ownShield:bowThreat,enemyShield:intent==='shield_respect',
        loaded:random()>.8,closing:random()*.3-.15,wallMargin:random()*8,charge:son[1],exchange,
        technique:technique&&(last||random()>.4)?technique:undefined})}
  })
  return {intent,history:row,chat}
}

// Keep complete matches separate. The only text attached to a trace is authored
// supervision for its verified event. Player chat and identities are not exported.
async function replay(file){
  const samples = []
  const recent = []
  let hits=[],blocks=[],lastTick=-Infinity,speaker
  for await(const line of readline.createInterface({input:fs.createReadStream(file),crlfDelay:Infinity})){
    let raw
    try{raw=JSON.parse(line)}catch{continue}
    const tick=raw.observation?.tick
    if(!Number.isFinite(tick)||tick<lastTick||!raw.self||!raw.seen)continue
    const damage=(raw.nativeEvents??[]).filter(row=>row.type==='damage'&&!row.cancelled)
    speaker ??= damage.flatMap(row=>[row.attacker,row.victim]).find(name=>/^WaveDog/i.test(name??''))
    if(!speaker || (!damage.length && tick-lastTick<20))continue
    hits=hits.filter(t=>tick-t<=30)
    blocks=blocks.filter(t=>tick-t<=60)
    const blocked=damage.some(row=>row.attacker===speaker && row.melee && row.amount===0 && row.shieldModifier<0)
    const hit=damage.some(row=>row.attacker===speaker && row.melee && row.amount>0)
    const incoming=damage.find(row=>row.victim===speaker&&row.amount>0)
    const shot=incoming?.melee===false&&['bow','crossbow'].includes(raw.observation.targetShotWeapon)
    if(hit&&hits.at(-1)!==tick)hits.push(tick)
    if(blocked&&blocks.at(-1)!==tick)blocks.push(tick)
    const intent=shot?'nice_bow':blocked?'shield_respect':hit&&hits.length>=2?'combo_hype':null
    const events={ownLowHealth:raw.self.health<=6}
    if(intent)events[lessons[intent].event]=true
    raw.tick=tick
    const observed=frame({sonVector:nativeObservation(raw,{}),
      pvpVector:pvpFromDual(raw.neuralFallback?.proposal??{}),events})
    observed.replyContext=replyFeaturesFromFrame(raw,hits.length,blocks.length,lastTick,incoming)
    recent.push(observed)
    if(recent.length>CONTEXTUAL.history)recent.shift()
    if(intent) samples.push({intent,history:replyHistory(recent,CONTEXTUAL.history),chat:''})
    lastTick=tick
  }
  return samples
}

function sceneChecks(intent, text) {
  const specific={
    nice_bow:/这么远|远处/u,
    combo_hype:/第三下|三下/u,
    shield_respect:/两下|连挡|又挡|又被/u
  }[intent]
  return {specific:specific.test(text),tired:/残血|血线|喘口气|没血|打残/u.test(text)}
}

const output=path.resolve(process.argv[2]??'outputs/pvp-perception-language/contextual')
const steps=Number(process.argv[3]??700)
const resume=process.argv.includes('--resume')
const evaluateOnly=process.argv.includes('--evaluate')
const traceFiles=process.argv.slice(4).filter(value=>!value.startsWith('--'))
if(!Number.isSafeInteger(steps)||steps<1)throw Error('steps must be a positive integer')
await tf.setBackend('cpu')
await tf.ready()
const traces=await Promise.all(traceFiles.map(replay))
const replayExamples=traces.slice(1).flat().map((sample,index)=>{
  const facts=replyFacts(sample.intent,sample.history.at(-1))
  const scene=lessons[sample.intent].scenes[2*Number(facts.tired)+Number(facts.specific)]
  return {...sample,text:scene[index%scene.length]}
})
const take=Math.max(1,Math.ceil(replayExamples.length/(examples.length/3)))
const trainRows=examples.concat(replayExamples.filter((_,i)=>i%take===0))
const focused=process.argv.includes('--combat-focus')
  ?examples.filter(row=>row.question||row.intent.startsWith('reaction_')):[]
console.log(JSON.stringify({examples:trainRows.length,synthetic:examples.length,trainMatches:Math.max(0,traces.length-1),
  replayCounts:traces.map(rows=>rows.length)}))
const previous=resume||evaluateOnly?JSON.parse(fs.readFileSync(path.join(output,'reply-context.float.json'),'utf8')):null
const tokens=previous?[...new Set([...previous.tokens,...vocabulary])]:vocabulary
if(evaluateOnly&&(!previous||tokens.length!==previous.tokens.length||previous.config.context!==CONTEXTUAL.context))
  throw Error('training vocabulary does not match the saved model')
const model=new ReplyTransformer(tokens,CONTEXTUAL)
try{
  if(previous)model.expand(previous)
  const tokenize=({text,...row})=>({...row,replyIds:split(text).map(token=>model.vocabulary.get(token))})
  const prior=evaluateOnly?JSON.parse(fs.readFileSync(path.join(output,'report.json'),'utf8')):null
  const loss=prior?.loss??trainReply(model,steps,trainRows.concat(focused,focused,focused).map(tokenize),
    (row,seed)=>row.history?row:synthetic(row,seed)).loss
  fs.mkdirSync(output,{recursive:true})
  const lessonsByToken=examples.map(tokenize).map(({chat,...row})=>({
    ...row,chatIds:split(chat).map(token=>model.vocabulary.get(token))
  }))
  fs.writeFileSync(path.join(output,'tokenized-supervision.jsonl'),lessonsByToken.map(row=>JSON.stringify(row)).join('\n')+'\n')
  const snapshot=model.snapshot()
  const binary=compactCheckpoint(snapshot)
  const weights=path.join(output,'reply-context.int8.bin')
  fs.writeFileSync(weights,binary)
  fs.writeFileSync(path.join(output,'reply-context.float.json'),JSON.stringify(snapshot))
  const compact=loadReplyModel(weights)
  const evaluate=sample=>{
    const text=compact.generate(sample)
    const latest=sample.history.at(-1)
    const truth=replyFacts(sample.intent,latest)
    return {intent:sample.intent,chat:sample.chat,truth,text,grounded:groundedReply(text,sample.intent,latest),
      ...Object.fromEntries(Object.entries(sceneChecks(sample.intent,text)).map(([key,actual])=>[key+'Correct',truth[key]===actual]))}
  }
  const paired=contextualIntents.flatMap((intent,i)=>[false,true].flatMap(tired=>[false,true].map(specific=>
    evaluate(synthetic({intent,tired,specific,chat:''},900+i)))))
  const questionSamples=contextualIntents.flatMap((intent,i)=>[false,true].map(specific=>
    synthetic({intent,tired:true,specific,chat:lessons[intent].questions.at(-1)},950+i)))
  const questions=questionSamples.map(evaluate)
  fs.writeFileSync(path.join(output,'sample-input.jsonl'),questionSamples.map(sample=>JSON.stringify(sample)).join('\n')+'\n')
  const heldout=(traces[0]??[]).map(evaluate)
  const counts=rows=>({total:rows.length,grounded:rows.filter(row=>row.grounded).length,
    specificCorrect:rows.filter(row=>row.specificCorrect).length,tiredCorrect:rows.filter(row=>row.tiredCorrect).length})
  const heldOutChat=[
    {intent:'chat_greeting',chat:'hi',lobby:true},
    {intent:'chat_greeting',chat:'hi',tired:true},
    {intent:'chat_tactical',chat:'你为啥还举盾呀',bowThreat:true},
    {intent:'chat_tactical',chat:'你为啥还举盾呀'},
    {intent:'chat_gg',chat:'好局',lobby:true},
    {intent:'chat_joke',chat:'好人机'}
  ].map((row,i)=>{
    const input=synthetic(row,850+i)
    const text=compact.generate(input)
    return {...row,text,fluent:fluentReply(text)}
  })
  const trainedText=new Set(trainRows.map(row=>row.text))
  const heldOutMeme=Object.entries(memeScenes).flatMap(([type,scene],index)=>[false,true].map(tired=>{
    const sample=synthetic({intent:'chat_meme',chat:'来点魔怔',tired,exchange:{...scene.exchange,
      healthLoss:tired?8:0,matchAge:740}},1700+index)
    const text=compact.generate(sample)
    const withheld=scene.heads[1]+scene.hot[1]
    return {type,tired,text,fluent:fluentReply(text),unseen:!trainedText.has(text),withheld}
  }))
  const novel=new Set()
  for(const [i,row] of questionSamples.entries()){
    for(let draw=0;draw<24;draw++){
      const text=compact.generate(row,seeded(9000+i*31+draw))
      if(!trainedText.has(text)&&groundedReply(text,row.intent,row.history.at(-1)))novel.add(text)
    }
  }
  const report={steps:prior?.steps??steps,continued:prior?.continued??Boolean(previous),
    loss,bytes:binary.length,parameterCount:model.params.reduce((sum,p)=>sum+p.size,0),
    syntheticExamples:examples.length,replayExamples:trainRows.length-examples.length,
    paired,questions,heldOutChat,heldOutMeme,novel:[...novel],heldout:counts(heldout),holdoutExamples:heldout.slice(0,12)}
  fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n')
  console.log(JSON.stringify({bytes:binary.length,paired:counts(paired),
    heldOutChat,heldOutMeme,novel:novel.size,questions:{total:questions.length,grounded:questions.filter(row=>row.grounded).length,
      specificCorrect:questions.filter(row=>row.specificCorrect).length},heldout:counts(heldout)}))
}finally{model.dispose()}
