# Tiny Language Transformer WaveDog

这个包用于已有 WaveDog Native Control 的 Paper 服。它包含共享聊天模型、词元解码、训练与检查代码，以及聊天桥接源码。战斗插件和竞技场须已具备。大厅由 WaveDog 应答，对战中由当前参战机器人应答。

## 接入

把包内的 `work`、`outputs` 合并到 WaveDog 配置的工作区根目录。在 `work/pvp-dual-brain` 安装 Node.js 依赖 `npm ci --omit=dev`。服务器需要 `WaveDogChatSense.jar` 捕捉普通聊天，并在 `WaveDogNativeControl/config.yml` 设置 `dialogue-enabled: true`。现有插件的 `/wdnative restart-speech` 可单独重载语言进程。

## 词元怎样关联战况

- `generation-context.js` 补充距离、对手血量、落地、近战命中次数、盾挡次数、伤害、暴击、帧间隔、拉弓进度、双方盾状态、弩是否装填、接近速度、墙边余量、蓄力和自身滞空。GRU/Transformer 隐状态只有战斗插件实际提供时才进入语言模型。
- `generation-runtime.mjs` 将最近四帧的 Son、PvP、事件向量和最多 23 个聊天语素投影到 48 维。每个词元有独立的输入嵌入和输出投影。Transformer 在已生成前缀及这些输入上做注意力，再预测下一个词元。
- `train-contextual.js` 用相同提问配不同战况做监督，并用有可核实事件的真人对局补充向量分布。文本进入训练前转换成词元 ID，每个训练位置预测一个 ID。`contextual/tokenized-supervision.jsonl` 展示拆分后的合成语料。真人原始轨迹和聊天保留在本地工作区。
- `reply-attribution.mjs` 固定生成前缀，逐项消融输入以测量每个词元的对数概率变化，同时测量两路向量的交互效应。空列表表示样例里没有达到显示阈值的变化。标点和语气助词通常主要由语言上下文决定。

这一版从玩家的普通聊天识别问候、开打、致谢、玩笑、对局评价和战术提问。对战中优先回复玩家，减少无提示的解说；相关提问可以引用当前对局最近五秒的可验证事件。新版权重逐词元解码，回复经过重复与事实检查。

`L`、`弓狗`、`ez`、`glhf`、`gg` 是可单独生成的词元。魔怔话梗拆到较短的词元，例如 `梅夷阁` 与 `诗人`，再结合前缀和游戏向量生成。训练语料分词结果可在包内的 `contextual/tokenized-supervision.jsonl` 查到。

魔怔口吻默认开启。对局中，实际射弓弩、放锚、放水晶、投珍珠、投掷其他弹射物或使用岩浆、蜘蛛网等非近战手段会触发台词。模型读六类动作以及最近五秒的失血、连招、箭命中和盾挡来逐词元生成。对手输掉时生成魔怔结算语，对手赢了固定说「错了错了」。同一机器人发出的招式吐槽至少间隔八秒。

`combat-memes.js` 集中维护这一版语料，包括「弓狗」「锚锚虫」「逃逸」「你跑个得儿」「相思了」和此前的诗人、后撤、结算梗。自由生成未通过战况校验时，Transformer 仍逐词元解码，该招式对应的短语限定下一词元可以从哪些选项选取。普通聊天和战术问答使用原有 `reply-context.int8.bin`，自动吐槽和胜负结算使用 `reply-combat.int8.bin`。

玩家的放置、投掷和桶操作由包内的 `WaveDogChatSense.jar` 捕获。升级时请用包里的 JAR 更新服务器插件并重新启动。

## 本地训练和检查

从工作区根目录执行以下命令。可在训练步数后追加原生对局轨迹文件，第一局固定用作留出验证。

```powershell
node work/pvp-dual-brain/perception-language/train-contextual.js outputs/pvp-perception-language/contextual 700
node work/pvp-dual-brain/perception-language/reply-attribution.mjs outputs/pvp-perception-language/reply-context.int8.bin outputs/pvp-perception-language/contextual/sample-input.jsonl
node work/pvp-dual-brain/perception-language/test-live-online.js outputs/pvp-perception-language/reply.int8.bin outputs/pvp-perception-language/reply-context.int8.bin outputs/pvp-perception-language/reply-combat.int8.bin
```

训练权重保存在 `outputs/pvp-perception-language/contextual/reply-context.float.json`，量化候选为同目录的 `reply-context.int8.bin`。完成验收后，把候选复制为上一级的 `reply-combat.int8.bin`。包内 `contextual` 的报告和词元监督样本对应对战权重。检查普通聊天或战术问答时，归因命令读取包内原有的普通聊天权重。
