"""Paper subprocess and CLI for WaveDog voice. Python 3.11+, standard library only."""
import argparse
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import threading
import time
import tomllib
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'voice.json'
OUTPUT_LOCK = threading.Lock()


def cc_switch(provider_id=None):
    file = Path.home() / '.cc-switch' / 'cc-switch.db'
    with sqlite3.connect(file.as_uri() + '?mode=ro', uri=True, timeout=2) as db:
        query = 'SELECT id,name,settings_config FROM providers WHERE app_type=? AND '
        row = db.execute(query + ('id=?' if provider_id else 'is_current=1'),
                         ('codex', provider_id) if provider_id else ('codex',)).fetchone()
    if not row:
        raise ValueError('CC Switch Codex provider unavailable')
    identifier, name, settings = row
    settings = json.loads(settings)
    config = tomllib.loads(settings['config'])
    provider = config['model_providers'][config['model_provider']]
    if provider.get('wire_api') != 'responses':
        raise ValueError('CC Switch provider must support the Responses API')
    return identifier, name, provider['base_url'], config['model'], settings['auth'].get('OPENAI_API_KEY')


def endpoint(base_url):
    parts = urllib.parse.urlsplit(base_url)
    if parts.scheme != 'https' or not parts.hostname or any((parts.username, parts.password, parts.query, parts.fragment)):
        raise ValueError('API base URL must be HTTPS without embedded credentials')
    url = base_url.rstrip('/')
    return url if url.endswith('/responses') else url + '/responses'


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Responses:
    def __init__(self, config):
        source = config['api_source']
        if source == 'cc-switch':
            _, _, url, model, key = cc_switch(config['provider_id'])
            if endpoint(url) != endpoint(config['base_url']):
                raise ValueError('CC Switch URL changed; run use-cc-switch to confirm it')
        elif source == 'env':
            url, model, key = config['base_url'], config['model'], os.environ.get('WAVEDOG_API_KEY')
        else:
            raise ValueError('Unknown API source')
        if not key:
            raise ValueError('API key unavailable')
        self.url = endpoint(url)
        self.key = key
        self.model = config.get('model') or model
        self.opener = urllib.request.build_opener(NoRedirect())

    def response(self, instructions, context, timeout):
        payload = {'model': self.model, 'instructions': instructions, 'input': context,
                   'max_output_tokens': 80, 'store': False}
        request = urllib.request.Request(self.url, json.dumps(payload, ensure_ascii=False).encode('utf-8'),
                                         {'Authorization': 'Bearer ' + self.key, 'Content-Type': 'application/json'}, method='POST')
        with self.opener.open(request, timeout=timeout) as reply:
            data = json.loads(reply.read(256 * 1024))
        return ''.join(content.get('text', '') for item in data.get('output', [])
                       if item.get('type') == 'message' and item.get('role') == 'assistant'
                       for content in item.get('content', []) if content.get('type') == 'output_text')


def config_read():
    return json.loads(CONFIG.read_text(encoding='utf-8'))


def configure(source, base_url, model, provider_id=None):
    endpoint(base_url)
    current = config_read()
    if (current.get('api_source'), current.get('base_url'), current.get('provider_id')) != (source, base_url, provider_id):
        current['cloud_enabled'] = False
    current.update(api_source=source, base_url=base_url, model=model)
    current.pop('provider_id', None)
    if provider_id:
        current['provider_id'] = provider_id
    temporary = CONFIG.with_suffix('.tmp')
    temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(CONFIG)


def emit(data):
    with OUTPUT_LOCK:
        print(json.dumps(data, ensure_ascii=False), flush=True)


def safe_text(text):
    text = text.strip().strip('"“”').strip()
    if not text or text == 'SKIP' or len(text) > 36 or text.startswith('/') or '§' in text:
        return ''
    if any(not character.isprintable() for character in text):
        return ''
    return text


def cloud_context(row, views, battle):
    def recent(events):
        return [event for event in events if event['match'] == row['match'] and 0 <= row['tick'] - event['tick'] <= 100]

    def view(state):
        return {key: state[key] for key in ('hp', 'targetRelative') if key in state}

    return {
        'player_message': row['text'],
        'current': view(row['view']),
        'recent_views': [view(event['state']) for event in recent(views)[-4:]],
        'combat_receipts': [
            {'ticks_ago': row['tick'] - event['tick'], **{key: event[key] for key in ('direction', 'cause', 'damage')}}
            for event in recent(battle)[-5:]
        ] if row['match'] else [],
    }


class Conversation:
    def __init__(self, config, phrases):
        self.config = config
        self.phrases = phrases
        self.views = defaultdict(lambda: deque(maxlen=32))
        self.battle = defaultdict(lambda: deque(maxlen=12))
        self.speech = defaultdict(lambda: deque(maxlen=5))
        self.active = set()
        self.calls = deque()
        self.player_last = {}
        self.lock = threading.Lock()
        self.pool = ThreadPoolExecutor(max_workers=2)
        self.api = None
        if config.get('cloud_enabled') is True and config.get('api_source') != 'disabled':
            try:
                self.api = Responses(config)
            except (ValueError, KeyError, OSError, sqlite3.Error):
                emit({'kind': 'api-status', 'status': 'configuration-unavailable'})

    def receive(self, row):
        kind = row['kind']
        bot = row.get('bot')
        if kind == 'view':
            self.views[bot].append(row)
        elif kind == 'combat':
            self.battle[bot].append(row)
        elif kind == 'bot-chat':
            self.speech[bot].append(row['text'])
        elif kind == 'player-chat':
            self.reply(row)

    def reply(self, row):
        bot = row['bot']
        now = time.time()
        if now * 1000 >= row['deadline']:
            return
        normalized = re.sub(r'[\s!?！？。,.，]+$', '', row['text'].lower()).strip()
        recent = tuple(self.speech[bot])
        for rule in self.phrases['direct']:
            if normalized not in rule['input']:
                continue
            if rule.get('combat') and not row.get('match'):
                return
            for line in rule['reply']:
                if line not in recent[-2:]:
                    self.emit_reply(row, line, 'tiny-corpus')
                    self.speech[bot].append(line)
                    return
            return
        if not self.api:
            return
        with self.lock:
            while self.calls and now - self.calls[0] >= 60:
                self.calls.popleft()
            if len(self.calls) >= self.config['api_requests_per_minute'] or len(self.active) >= 2 or bot in self.active:
                return
            if now - self.player_last.get(bot, 0) < 3:
                return
            self.player_last[bot] = now
            self.calls.append(now)
            self.active.add(bot)
        context = cloud_context(row, self.views[bot], self.battle[bot])
        self.pool.submit(self.remote_reply, row, context)

    def remote_reply(self, row, context):
        bot = row['bot']
        try:
            remaining = row['deadline'] / 1000 - time.time() - .15
            if remaining <= 0:
                return
            instructions = self.phrases['instructions'] + '\n常用短句：' + '、'.join(self.phrases['style'])
            answer = safe_text(self.api.response(instructions, json.dumps(context, ensure_ascii=False), remaining))
            if answer and time.time() * 1000 < row['deadline']:
                self.emit_reply(row, answer, 'gpt')
        except urllib.error.HTTPError as error:
            emit({'kind': 'api-status', 'status': 'http-' + str(error.code)})
        except (OSError, ValueError, TypeError, AttributeError):
            emit({'kind': 'api-status', 'status': 'failed-or-timeout'})
        finally:
            with self.lock:
                self.active.discard(bot)

    @staticmethod
    def emit_reply(row, text, source):
        emit({'kind': 'reply', 'id': row['id'], 'source': source, 'text': text})


def main():
    sys.stdin.reconfigure(encoding='utf-8')
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    commands.add_parser('worker')
    commands.add_parser('provider')
    imported = commands.add_parser('use-cc-switch')
    imported.add_argument('--provider-id')
    direct = commands.add_parser('use-api')
    direct.add_argument('base_url')
    direct.add_argument('model')
    commands.add_parser('probe')
    args = parser.parse_args()
    try:
        if args.action == 'use-cc-switch':
            identifier, name, url, model, key = cc_switch(args.provider_id)
            if not key:
                raise ValueError('CC Switch API key unavailable')
            configure('cc-switch', url, model, identifier)
            emit({'provider': name, 'model': model, 'api_source': 'cc-switch'})
        elif args.action == 'use-api':
            configure('env', args.base_url, args.model)
            emit({'model': args.model, 'api_source': 'env', 'key_variable': 'WAVEDOG_API_KEY'})
        elif args.action == 'provider':
            cfg = config_read()
            emit({key: cfg[key] for key in ('api_source', 'provider_id', 'model', 'cloud_enabled') if key in cfg})
        elif args.action == 'probe':
            start = time.monotonic()
            answer = Responses(config_read()).response('Return one short plain answer.', 'Reply with OK.', 15)
            emit({'textReceived': bool(answer.strip()), 'latencyMs': round((time.monotonic() - start) * 1000)})
            return 0 if answer.strip() else 1
        else:
            phrases = json.loads((ROOT / 'tiny-phrases.json').read_text(encoding='utf-8'))
            conversation = Conversation(config_read(), phrases)
            emit({'kind': 'ready', 'apiConfigured': conversation.api is not None})
            for line in sys.stdin:
                try:
                    conversation.receive(json.loads(line))
                except (ValueError, TypeError, KeyError):
                    emit({'kind': 'api-status', 'status': 'bad-bridge-event'})
            conversation.pool.shutdown(wait=False, cancel_futures=True)
    except urllib.error.HTTPError as error:
        emit({'error': 'http-' + str(error.code)})
        return 1
    except (OSError, KeyError, ValueError, sqlite3.Error) as error:
        emit({'error': type(error).__name__})
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
