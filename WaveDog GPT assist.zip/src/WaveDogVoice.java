package local.wavedog.voice;

import com.google.gson.*;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;

/** Paper observations in, one short native-player reply out. */
public final class WaveDogVoice extends JavaPlugin implements Listener {
    private static final Gson JSON = new Gson();
    private static final String NATIVE = "wavedog-native-player";
    private static final String CAGE = "wavedog-preparation-cage";
    private static final List<String> BOTS = List.of("WaveDog", "WaveDogSon", "WaveDogBrother", "WaveDogFather", "WaveDogSister");
    private static final Pattern ADDRESSED = Pattern.compile("^@?(WaveDog(?:Son|Brother|Father|Sister)?|Troalin)(?![A-Za-z0-9_])[\\s:：,，]*", Pattern.CASE_INSENSITIVE);
    private final Map<String, Ticket> pending = new HashMap<>();
    private final Map<String, Long> lastReply = new HashMap<>();
    private final Map<UUID, Long> lastPlayer = new HashMap<>();
    private Map<?, ?> actors;
    private Field match, opponent, active, frames, inference;
    private Object neural;
    private volatile Worker worker;
    private boolean enabled;
    private long retryAt, replies, received, dropped, samples;
    private int replyBudget;
    private String apiStatus = "stopped";

    private record View(String name, Player player, Object actor, String match, boolean active) {}
    private record Ticket(UUID player, String bot, String match, long deadline) {}

    @Override public void onEnable() {
        try {
            Object nativeControl = Objects.requireNonNull(Bukkit.getPluginManager().getPlugin("WaveDogNativeControl"));
            actors = (Map<?, ?>) field(nativeControl, "actors").get(nativeControl);
            Object actor = actors.values().iterator().next();
            match = field(actor, "match"); opponent = field(actor, "opponent");
            active = field(actor, "active"); frames = field(actor, "frames");
            neural = Bukkit.getPluginManager().getPlugin("WaveDogNeuralFallback");
            if (neural != null) inference = field(neural, "latest");
            Files.createDirectories(getDataFolder().toPath());
        } catch (Exception error) {
            throw new IllegalStateException("WaveDog native observation unavailable", error);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::sample, 5, 4);
        enabled = Files.isRegularFile(getDataFolder().toPath().resolve("enabled"));
    }

    private static Field field(Object owner, String name) throws ReflectiveOperationException {
        Field field = owner.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field;
    }

    @Override public void onDisable() { closeWorker(); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            try {
                Path marker = getDataFolder().toPath().resolve("enabled");
                switch (args[0]) {
                    case "start" -> {
                        if (worker == null) startWorker();
                        Files.writeString(marker, "enabled\n");
                        enabled = true;
                    }
                    case "stop" -> { Files.deleteIfExists(marker); enabled = false; closeWorker(); }
                    case "restart" -> {
                        closeWorker(); startWorker(); Files.writeString(marker, "enabled\n"); enabled = true;
                    }
                    case "status" -> {}
                    default -> { return false; }
                }
            } catch (Exception error) {
                sender.sendMessage("WaveDog Voice: " + error.getMessage());
                return true;
            }
            sender.sendMessage(JSON.toJson(Map.of("enabled", enabled, "worker", worker != null && worker.process.isAlive(),
                "api", apiStatus, "events", received, "viewSamples", samples, "replies", replies, "dropped", dropped)));
            return true;
        }
        return false;
    }

    private void startWorker() throws IOException {
        Path dir = getDataFolder().toPath().toAbsolutePath();
        JsonObject settings = JsonParser.parseString(Files.readString(dir.resolve("voice.json"))).getAsJsonObject();
        var tiny = JsonParser.parseString(Files.readString(Path.of(settings.get("tiny_profile").getAsString()))).getAsJsonObject();
        if (!"intent-v1".equals(tiny.get("mode").getAsString()))
            throw new IOException("Tiny must be in intent-v1 mode to use the shared direct-reply path");
        replyBudget = Math.clamp(settings.get("reply_deadline_ms").getAsInt(), 500, 6000);
        var process = new ProcessBuilder(settings.get("python").getAsString(), "-u", dir.resolve("voice.py").toString(), "worker")
            .directory(dir.toFile()).redirectError(ProcessBuilder.Redirect.appendTo(dir.resolve("worker.err.log").toFile())).start();
        apiStatus = "starting";
        worker = new Worker(process);
        worker.start();
    }

    private void closeWorker() {
        Worker previous = worker;
        worker = null;
        pending.clear();
        if (previous != null) previous.close();
        apiStatus = "stopped";
    }

    private void sample() {
        if (!enabled) return;
        long now = System.currentTimeMillis();
        if (worker != null && !worker.process.isAlive()) closeWorker();
        if (worker == null) {
            if (now >= retryAt) {
                retryAt = now + 10_000;
                try { startWorker(); }
                catch (Exception error) { getLogger().warning("Voice worker unavailable: " + error.getMessage()); }
            }
            return;
        }
        pending.values().removeIf(ticket -> ticket.deadline() <= now);
        if (lastPlayer.size() > 128) lastPlayer.values().removeIf(at -> now - at > 60_000);
        int tick = Bukkit.getCurrentTick();
        for (String name : BOTS) {
            View view = bot(name);
            if (view != null && !view.match().isEmpty()) {
                if (worker.offer(Map.of("kind", "view", "bot", name, "match", view.match(), "tick", tick,
                    "state", observation(view, tick)))) samples++;
            }
        }
    }

    private View bot(String name) {
        Object actor = actors.get(name);
        Player player = Bukkit.getPlayerExact(name);
        if (actor == null || player == null || !player.hasMetadata(NATIVE)) return null;
        try {
            boolean fighting = active.getBoolean(actor);
            String duel = fighting || player.hasMetadata(CAGE) ? Objects.toString(match.get(actor), "") : "";
            return new View(name, player, actor, duel, fighting);
        } catch (IllegalAccessException error) { throw new IllegalStateException(error); }
    }

    private static List<Double> position(Location location) {
        return List.of(location.getX(), location.getY(), location.getZ());
    }

    private static Map<String, Object> take(Map<?, ?> original, String... keys) {
        var data = new LinkedHashMap<String, Object>();
        for (String key : keys) if (original.get(key) != null) data.put(key, original.get(key));
        return data;
    }

    private Map<String, Object> observation(View view, int tick) {
        Player self = view.player();
        Location location = self.getLocation();
        var row = new LinkedHashMap<String, Object>();
        row.put("phase", view.active() ? "fight" : view.match().isEmpty() ? "lobby" : "prepare");
        row.put("world", self.getWorld().getEnvironment().name());
        row.put("gameTime", self.getWorld().getTime());
        row.put("raining", self.getWorld().hasStorm());
        row.put("xyz", position(location));
        row.put("yaw", location.getYaw()); row.put("pitch", location.getPitch());
        row.put("hp", self.getHealth()); row.put("shield", self.isBlocking()); row.put("grounded", self.isOnGround());
        row.put("main", self.getInventory().getItemInMainHand().getType().name());
        row.put("off", self.getInventory().getItemInOffHand().getType().name());
        row.put("floor", self.getLocation().subtract(0, 1, 0).getBlock().getType().name());
        if (view.match().isEmpty()) return row;
        try {
            Player target = Bukkit.getPlayerExact(Objects.toString(opponent.get(view.actor()), ""));
            boolean visible = target != null && target.getWorld() == self.getWorld() && firstPerson(self, target);
            row.put("opponentVisible", visible);
            if (visible) {
                row.put("targetRelative", position(target.getLocation().subtract(location)));
                row.put("targetShield", target.isBlocking());
                row.put("targetItem", target.getInventory().getItemInMainHand().getType().name());
                row.put("targetGrounded", target.isOnGround());
            }
            var history = (List<?>) frames.get(view.actor());
            if (!history.isEmpty() && history.getLast() instanceof Map<?, ?> frame && view.match().equals(frame.get("matchId"))
                && frame.get("observation") instanceof Map<?, ?> seen && seen.get("tick") instanceof Number at && tick - at.intValue() <= 20) {
                if (frame.get("plan") instanceof Map<?, ?> plan) row.put("son", take(plan, "phase", "focus", "reason"));
                if (frame.get("actual") instanceof Map<?, ?> actual) row.put("executed", take(actual, "attacked", "jump", "shield", "sprint"));
            }
            if (inference != null && ((Map<?, ?>) inference.get(neural)).get(view.name()) instanceof Map<?, ?> model
                && view.match().equals(model.get("matchId")) && model.get("tick") instanceof Number at && tick - at.intValue() <= 20)
                row.put("transformerProposal", take(model, "model", "tick", "command"));
        } catch (IllegalAccessException error) { throw new IllegalStateException(error); }
        return row;
    }

    private static boolean firstPerson(Player self, Player target) {
        var eye = self.getEyeLocation();
        var delta = target.getEyeLocation().toVector().subtract(eye.toVector());
        double distance = delta.length();
        return distance <= 32 && (distance < .001 || eye.getDirection().dot(delta) / distance >= .5) && self.hasLineOfSight(target);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void chat(AsyncChatEvent event) {
        if (worker == null) return;
        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).strip();
        if (text.isEmpty() || text.length() > 160 || text.codePoints().anyMatch(Character::isISOControl)) return;
        UUID id = event.getPlayer().getUniqueId();
        if (event.isAsynchronous()) Bukkit.getScheduler().runTask(this, () -> capture(id, text));
        else capture(id, text);
    }

    private void capture(UUID uuid, String text) {
        Worker current = worker;
        Player player = Bukkit.getPlayer(uuid);
        if (current == null || player == null) return;
        if (player.hasMetadata(NATIVE)) {
            if (BOTS.contains(player.getName())) current.offer(Map.of("kind", "bot-chat", "bot", player.getName(), "text", text));
            return;
        }
        var mention = ADDRESSED.matcher(text);
        String name = null;
        if (mention.find()) {
            String addressed = mention.group(1);
            name = addressed.equalsIgnoreCase("Troalin") ? "WaveDog" : BOTS.stream().filter(bot -> bot.equalsIgnoreCase(addressed)).findFirst().orElse(null);
            text = text.substring(mention.end()).strip();
            if (text.isEmpty()) return;
        } else {
            for (var owner : player.getMetadata("wavedog-duel-owner")) {
                if (BOTS.contains(owner.asString())) { name = owner.asString(); break; }
            }
        }
        View view = bot(name == null ? "WaveDog" : name);
        if (!canTalk(player, view)) return;
        long now = System.currentTimeMillis();
        if (now - lastPlayer.getOrDefault(uuid, 0L) < 800 || pending.size() >= 12) return;
        lastPlayer.put(uuid, now);
        String id = UUID.randomUUID().toString();
        long deadline = now + replyBudget;
        int tick = Bukkit.getCurrentTick();
        if (current.offer(Map.of("kind", "player-chat", "id", id, "bot", view.name(), "match", view.match(),
            "tick", tick, "deadline", deadline, "text", text, "view", observation(view, tick)))) {
            pending.put(id, new Ticket(uuid, view.name(), view.match(), deadline));
            received++;
        }
    }

    private boolean canTalk(Player player, View view) {
        if (player == null || view == null || view.player().isDead() || player.getWorld() != view.player().getWorld()) return false;
        if (view.match().isEmpty()) return player.getLocation().distanceSquared(view.player().getLocation()) <= 32 * 32;
        try { return player.getName().equals(opponent.get(view.actor())); }
        catch (IllegalAccessException error) { throw new IllegalStateException(error); }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void damage(EntityDamageEvent event) {
        Worker current = worker;
        if (current == null || event.getFinalDamage() <= 0) return;
        Entity attacker = event instanceof EntityDamageByEntityEvent hit ? hit.getDamager() : null;
        if (attacker instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) attacker = shooter;
        Entity victim = event.getEntity();
        for (String name : BOTS) {
            View view = bot(name);
            if (view == null || !view.active()) continue;
            String direction = view.player() == victim ? "taken" : view.player() == attacker ? "landed" : "";
            if (direction.isEmpty()) continue;
            if (direction.equals("landed") && !canTalk(victim instanceof Player target ? target : null, view)) continue;
            current.offer(Map.of("kind", "combat", "bot", name, "match", view.match(), "tick", Bukkit.getCurrentTick(),
                "direction", direction, "cause", event.getCause().name(), "damage", event.getFinalDamage()));
        }
    }

    private void process(Worker from, JsonObject row) {
        if (worker != from) return;
        String kind = row.get("kind").getAsString();
        if (kind.equals("ready")) { apiStatus = row.get("apiConfigured").getAsBoolean() ? "configured" : "local-only"; return; }
        if (kind.equals("api-status")) { apiStatus = row.get("status").getAsString(); return; }
        if (!kind.equals("reply")) return;
        Ticket ticket = pending.remove(row.get("id").getAsString());
        if (ticket == null) return;
        long now = System.currentTimeMillis();
        View view = bot(ticket.bot());
        Player player = Bukkit.getPlayer(ticket.player());
        String text = row.get("text").getAsString().strip();
        if (now >= ticket.deadline() || !canTalk(player, view) || !ticket.match().equals(view.match()) ||
            now - lastReply.getOrDefault(ticket.bot(), 0L) < 1800 || text.isEmpty() || text.length() > 72 ||
            text.startsWith("/") || text.contains("§") || text.codePoints().anyMatch(Character::isISOControl)) {
            dropped++;
            return;
        }
        lastReply.put(ticket.bot(), now);
        view.player().chat(text);
        replies++;
        String source = row.get("source").getAsString();
        if (source.equals("gpt")) apiStatus = "reply-ok";
        getLogger().info("Voice reply from " + source + " as " + ticket.bot());
    }

    private final class Worker {
        private final Process process;
        private final BlockingDeque<String> queue = new LinkedBlockingDeque<>(64);

        Worker(Process process) { this.process = process; }

        boolean offer(Map<String, Object> row) {
            return row.get("kind").equals("player-chat") ? queue.offerFirst(JSON.toJson(row)) : queue.offerLast(JSON.toJson(row));
        }

        void start() {
            thread("writer", () -> {
                try (var output = process.outputWriter(StandardCharsets.UTF_8)) {
                    while (worker == this && process.isAlive()) {
                        String row = queue.poll(250, TimeUnit.MILLISECONDS);
                        if (row != null) { output.write(row); output.newLine(); output.flush(); }
                    }
                } catch (IOException | InterruptedException error) { if (worker == this) process.destroy(); }
            });
            thread("reader", () -> {
                try (var input = process.inputReader(StandardCharsets.UTF_8)) {
                    for (String line; (line = input.readLine()) != null && worker == this;) {
                        JsonObject row = JsonParser.parseString(line).getAsJsonObject();
                        Bukkit.getScheduler().runTask(WaveDogVoice.this, () -> process(this, row));
                    }
                } catch (IOException | RuntimeException error) { if (worker == this) process.destroy(); }
            });
        }

        private void thread(String name, Runnable task) {
            var thread = new Thread(task, "WaveDog-voice-" + name);
            thread.setDaemon(true);
            thread.start();
        }

        void close() { process.destroy(); }
    }
}
