param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('start', 'stop', 'restart', 'status', 'provider', 'probe', 'use-cc-switch', 'use-api')]
    [string]$Action,
    [Parameter(Position = 1)][string]$Value,
    [Parameter(Position = 2)][string]$Model
)

$ErrorActionPreference = 'Stop'
$configuration = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'voice.json') | ConvertFrom-Json
$env:PYTHONIOENCODING = 'utf-8'
switch ($Action) {
    { $_ -in 'start', 'stop', 'restart', 'status' } {
        $server = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
        $localControl = Join-Path $server 'server-control.py'
        if (Test-Path -LiteralPath $localControl) {
            & $configuration.python $localControl wdvoice $Action
        } else {
            Write-Host "Enter wdvoice $Action in your Paper console (or /wdvoice $Action in game as an operator)."
            exit 1
        }
    }
    'use-cc-switch' {
        $arguments = @((Join-Path $PSScriptRoot 'voice.py'), $Action)
        if ($Value) { $arguments += @('--provider-id', $Value) }
        & $configuration.python @arguments
    }
    'use-api' {
        if (!$Value -or !$Model) { throw 'Use voice.ps1 use-api <base URL> <model>' }
        & $configuration.python (Join-Path $PSScriptRoot 'voice.py') $Action $Value $Model
    }
    default { & $configuration.python (Join-Path $PSScriptRoot 'voice.py') $Action }
}
exit $LASTEXITCODE
