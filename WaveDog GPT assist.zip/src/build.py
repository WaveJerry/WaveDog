from pathlib import Path
import os
import subprocess
import sys
import tempfile
import zipfile

base = Path(__file__).resolve().parent
server = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
folders = ('io/papermc/paper/paper-api/1.21.11-R0.1-SNAPSHOT', 'net/kyori', 'net/md-5', 'com/google/code/gson')
classpath = os.pathsep.join(str(jar) for folder in folders for jar in (server / 'libraries' / folder).rglob('*.jar'))
with tempfile.TemporaryDirectory() as directory:
    classes = Path(directory)
    subprocess.run([str(server / 'runtime/java21/bin/javac.exe'), '-proc:none', '--release', '21', '-encoding', 'UTF-8',
                    '-cp', classpath, '-d', directory, str(base / 'WaveDogVoice.java')], check=True)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as jar:
        jar.write(base / 'plugin.yml', 'plugin.yml')
        for entry in classes.rglob('*.class'):
            jar.write(entry, entry.relative_to(classes).as_posix())
print(target)
