param(
    [Parameter(Mandatory = $true)][string]$ServerDir,
    [Parameter(Mandatory = $true)][string]$TinyProfile,
    [string]$Python = 'python'
)

$ErrorActionPreference = 'Stop'
$server = (Resolve-Path -LiteralPath $ServerDir).Path
$profile = (Resolve-Path -LiteralPath $TinyProfile).Path
$plugins = Join-Path $server 'plugins'
if (!(Test-Path -LiteralPath (Join-Path $plugins 'WaveDogNativeControl.jar') -PathType Leaf)) {
    throw 'Install WaveDogNativeControl before installing WaveDog Voice.'
}
if ((Get-Content -Raw -LiteralPath $profile | ConvertFrom-Json).mode -ne 'intent-v1') {
    throw 'The active Tiny speech-profile.json must use intent-v1.'
}
$pythonExe = (Get-Command $Python -CommandType Application | Select-Object -First 1).Source
& $pythonExe -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'
if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or newer is required.' }

$newJar = Join-Path $PSScriptRoot 'dist/WaveDogTroalin.jar'
$source = Join-Path $PSScriptRoot 'src'
if (!(Test-Path -LiteralPath $newJar -PathType Leaf)) { throw 'Release JAR is missing.' }
$data = Join-Path $plugins 'WaveDogTroalin'
$jar = Join-Path $plugins 'WaveDogTroalin.jar'
New-Item -ItemType Directory -Path $data -Force | Out-Null
if (Test-Path -LiteralPath $jar) {
    $backup = Join-Path $data ('WaveDogTroalin-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff') + '.jar.bak')
    Copy-Item -LiteralPath $jar -Destination $backup
}
foreach ($entry in 'voice.py','voice.ps1','tiny-phrases.json') {
    Copy-Item -LiteralPath (Join-Path $source $entry) -Destination (Join-Path $data $entry)
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'README.md') -Destination (Join-Path $data 'README.md')
$config = Join-Path $data 'voice.json'
if (!(Test-Path -LiteralPath $config)) {
    $settings = Get-Content -Raw -LiteralPath (Join-Path $source 'voice.json') | ConvertFrom-Json
    $settings.python = $pythonExe
    $settings.tiny_profile = $profile
    $json = $settings | ConvertTo-Json
    [IO.File]::WriteAllText($config, $json + "`n", [Text.UTF8Encoding]::new($false))
}
Copy-Item -LiteralPath $newJar -Destination $jar
Write-Host "Installed in $data"
Write-Host 'Start Paper, then enter wdvoice start in the Paper console.'
