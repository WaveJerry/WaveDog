# WaveDog Voice

WaveDog Voice 把 Paper 的聊天和第一视角战况接到 WaveDog 家族的发言进程。Tiny 继续负责开局、战况和收局。玩家发话后，补话进程先找合适的 Tiny 短句，再按配置决定是否让 GPT 补一句。工具在本机运行，可在关闭 Codex 后使用。

## 1. 安装到主服

需要 Windows、Paper 1.21.11、Java 21、Python 3.11+，以及已经可用的 WaveDogNativeControl 和 Tiny Language Transformer。本包提供发言桥和补话程序。WaveDog PvP 插件、Tiny 模型和 Minecraft 世界需要另外安装。

先正常停止 Paper。把 ZIP 解压后，在包根目录打开 PowerShell：

```powershell
.\install.ps1 -ServerDir 'D:\MinecraftServer' `
    -TinyProfile 'D:\WaveDog\outputs\pvp-perception-language\speech-profile.json'
```

将路径改为自己的服务器和 **Tiny 实际在用的** `speech-profile.json`。该文件需要设置为 `{"mode":"intent-v1"}`。如果 `python` 还没加入 PATH，可向安装脚本传 `-Python 'E:\python.exe'`。安装后使用原来的方式启动 Paper。

## 2. 选择 API

进入服务器 `plugins\WaveDogTroalin` 目录，复制 CC Switch 当前选中的 Codex 供应商设置，再测一条「Reply with OK.」：

```powershell
.\voice.ps1 use-cc-switch
.\voice.ps1 provider
.\voice.ps1 probe
```

需要 CC Switch 供应商支持 Responses API。`voice.json` 记录地址、模型和供应商 ID，密钥由运行 Paper 的 Windows 用户从自己的 CC Switch 本机数据库读取。选了另一家时，重跑 `use-cc-switch`。如果要手动填 API，使用：

```powershell
.\voice.ps1 use-api 'https://api.openai.com/v1' '<实际可用的模型名>'
.\voice.ps1 probe
```

手动方式从 `WAVEDOG_API_KEY` 环境变量取密钥。请在启动 Paper 的账户里设置它。已运行的 Java 进程需要重新启动才能继承变量。

## 3. 开始说话

默认只做本地词库补话。要打开 GPT 补话，确认可以让配置的 API 供应商处理相关数据，再把服务器 `plugins\WaveDogTroalin\voice.json` 中的 `cloud_enabled` 改成 `true`。

在 Paper 控制台输入命令，游戏内管理员可在前面加 `/`：

```text
wdvoice start
wdvoice status
wdvoice restart
wdvoice stop
```

首次用 `start`。改过 API、配置或语料后用 `restart`。只有本机有 `server-control.py` 的部署，也可以直接运行 `voice.ps1 start` 等对应操作。接入状态在下次开服时保留。`stop` 停止补话，Tiny 照常发言。

进服靠近 WaveDog 发「你好」，应走本地词库。对局里可以发与战况有关的短问句。`wdvoice status` 会显示收到的消息数、观测采样、回复数和 API 状态，Paper 日志有 `tiny-corpus` 或 `gpt` 的回复来源。切局后和超时的回复会跳过。Tiny 台词见 `tiny-phrases.json`。

## 数据和源码

云端补话只发送当句玩家文本、假人生命值、可见对手的相对位置变化与近期伤害回执。服务器的绝对坐标、玩家账号、模型推理结果和日志留在本机。更换供应商或地址会关闭云端补话，重新确认后可再打开。发布包默认关闭云端功能。

`src/` 包含 Paper 插件、Python 进程、配置与词库。`dist/WaveDogTroalin.jar` 可直接安装。若服务器已有该版本的 Paper 库和 `runtime/java21`，可以这样重新编译：

```powershell
python .\src\build.py 'D:\MinecraftServer' '.\dist\WaveDogTroalin.jar'
```

## 上传到 GitHub

GitHub 新建空仓库后，将解压得到的目录作为仓库根目录上传。仓库里应有 `README.md`、`.gitignore`、`install.ps1`、`src/` 和 `dist/`。也可以从 GitHub Releases 单独上传 ZIP 作为安装包。
